package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0000_dex039 {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Ldex039;","Ljava/lang/Object;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        f000_static_field(cv);
        f001_instance_field(cv);
        m000__init_(cv);
        m001_main(cv);
        m002_method_handle_1(cv);
        m003_method_handle_2(cv);
        m004_method_handle_3(cv);
        m005_method_handle_4(cv);
        m006_method_handle_5(cv);
        m007_method_handle_6(cv);
        m008_method_handle_7(cv);
        m009_method_handle_8(cv);
        m010_method_handle_9(cv);
        m011_method_type(cv);
        m012_private_method(cv);
    }
    public static void f000_static_field(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC, new Field("Ldex039;","static_field","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001_instance_field(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC, new Field("Ldex039;","instance_field","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Ldex039;","<init>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/Object;","<init>",new String[]{ },"V"));
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001_main(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Ldex039;","main",new String[]{ "[Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Ldex039;","method_handle_1",new String[]{ },"Ljava/lang/invoke/MethodHandle;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Ldex039;","method_handle_2",new String[]{ },"Ljava/lang/invoke/MethodHandle;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Ldex039;","method_handle_3",new String[]{ },"Ljava/lang/invoke/MethodHandle;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Ldex039;","method_handle_4",new String[]{ },"Ljava/lang/invoke/MethodHandle;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Ldex039;","method_handle_5",new String[]{ },"Ljava/lang/invoke/MethodHandle;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Ldex039;","method_handle_6",new String[]{ },"Ljava/lang/invoke/MethodHandle;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Ldex039;","method_handle_7",new String[]{ },"Ljava/lang/invoke/MethodHandle;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Ldex039;","method_handle_8",new String[]{ },"Ljava/lang/invoke/MethodHandle;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Ldex039;","method_handle_9",new String[]{ },"Ljava/lang/invoke/MethodHandle;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Ldex039;","method_type",new String[]{ },"Ljava/lang/invoke/MethodType;"));
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_method_handle_1(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Ldex039;","method_handle_1",new String[]{ },"Ljava/lang/invoke/MethodHandle;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                code.visitConstStmt(CONST_METHOD_HANDLE,0,new MethodHandle(MethodHandle.STATIC_GET,new Field("Ldex039;","static_field","I")));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_method_handle_2(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Ldex039;","method_handle_2",new String[]{ },"Ljava/lang/invoke/MethodHandle;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                code.visitConstStmt(CONST_METHOD_HANDLE,0,new MethodHandle(MethodHandle.STATIC_PUT,new Field("Ldex039;","static_field","I")));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_method_handle_3(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Ldex039;","method_handle_3",new String[]{ },"Ljava/lang/invoke/MethodHandle;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                code.visitConstStmt(CONST_METHOD_HANDLE,0,new MethodHandle(MethodHandle.INSTANCE_GET,new Field("Ldex039;","instance_field","I")));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_method_handle_4(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Ldex039;","method_handle_4",new String[]{ },"Ljava/lang/invoke/MethodHandle;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                code.visitConstStmt(CONST_METHOD_HANDLE,0,new MethodHandle(MethodHandle.INSTANCE_PUT,new Field("Ldex039;","instance_field","I")));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_method_handle_5(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Ldex039;","method_handle_5",new String[]{ },"Ljava/lang/invoke/MethodHandle;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                code.visitConstStmt(CONST_METHOD_HANDLE,0,new MethodHandle(MethodHandle.INVOKE_INSTANCE,new Method("Ljava/lang/String;","toString",new String[]{ },"Ljava/lang/String;")));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m007_method_handle_6(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Ldex039;","method_handle_6",new String[]{ },"Ljava/lang/invoke/MethodHandle;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                code.visitConstStmt(CONST_METHOD_HANDLE,0,new MethodHandle(MethodHandle.INVOKE_STATIC,new Method("Ljava/lang/String;","valueOf",new String[]{ "I"},"Ljava/lang/String;")));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m008_method_handle_7(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Ldex039;","method_handle_7",new String[]{ },"Ljava/lang/invoke/MethodHandle;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                code.visitConstStmt(CONST_METHOD_HANDLE,0,new MethodHandle(MethodHandle.INVOKE_DIRECT,new Method("Ldex039;","private_method",new String[]{ },"V")));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m009_method_handle_8(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Ldex039;","method_handle_8",new String[]{ },"Ljava/lang/invoke/MethodHandle;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                code.visitConstStmt(CONST_METHOD_HANDLE,0,new MethodHandle(MethodHandle.INVOKE_INTERFACE,new Method("Ljava/util/List;","get",new String[]{ "I"},"Ljava/lang/Object;")));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m010_method_handle_9(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Ldex039;","method_handle_9",new String[]{ },"Ljava/lang/invoke/MethodHandle;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                code.visitConstStmt(CONST_METHOD_HANDLE,0,new MethodHandle(MethodHandle.INVOKE_CONSTRUCTOR,new Method("Ljava/lang/Object;","<init>",new String[]{ },"V")));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m011_method_type(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Ldex039;","method_type",new String[]{ },"Ljava/lang/invoke/MethodType;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                code.visitConstStmt(CONST_METHOD_TYPE,0,new Proto(new String[]{ },"V"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m012_private_method(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PRIVATE, new Method("Ldex039;","private_method",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
