package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0000_dex04 0 {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Ldex04 0;","Ljava/lang/Object;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        f000_static_fiel d(cv);
        m000__init_(cv);
        m001_main(cv);
        m002_private_metho d(cv);
    }
    public static void f000_static_fiel d(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC, new Field("Ldex04 0;","static_fiel d","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Ldex04 0;","<init>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/Object;","<init>",new String[]{ },"V"));
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001_main(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Ldex04 0;","main",new String[]{ "[Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_private_metho d(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PRIVATE, new Method("Ldex04 0;","private_metho d",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
