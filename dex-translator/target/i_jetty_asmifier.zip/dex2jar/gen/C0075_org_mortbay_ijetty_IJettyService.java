package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0075_org_mortbay_ijetty_IJettyService {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/ijetty/IJettyService;","Landroid/app/Service;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("IJettyService.java");
        f000___configurationClasses(cv);
        f001___resources(cv);
        f002__consolePassword(cv);
        f003__port(cv);
        f004__useNIO(cv);
        f005_isDebugEnabled(cv);
        f006_mNM(cv);
        f007_pi(cv);
        f008_preferences(cv);
        f009_server(cv);
        m000__clinit_(cv);
        m001__init_(cv);
        m002_getStreamToRawResource(cv);
        m003_startJetty(cv);
        m004_stopJetty(cv);
        m005_onBind(cv);
        m006_onCreate(cv);
        m007_onDestroy(cv);
        m008_onLowMemory(cv);
        m009_onStart(cv);
    }
    public static void f000___configurationClasses(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/ijetty/IJettyService;","__configurationClasses","[Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001___resources(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC, new Field("Lorg/mortbay/ijetty/IJettyService;","__resources","Landroid/content/res/Resources;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002__consolePassword(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/ijetty/IJettyService;","_consolePassword","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003__port(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/ijetty/IJettyService;","_port","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f004__useNIO(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/ijetty/IJettyService;","_useNIO","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f005_isDebugEnabled(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/ijetty/IJettyService;","isDebugEnabled","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f006_mNM(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/ijetty/IJettyService;","mNM","Landroid/app/NotificationManager;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f007_pi(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/ijetty/IJettyService;","pi","Landroid/content/pm/PackageInfo;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f008_preferences(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/ijetty/IJettyService;","preferences","Landroid/content/SharedPreferences;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f009_server(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/ijetty/IJettyService;","server","Lorg/mortbay/jetty/Server;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__clinit_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/ijetty/IJettyService;","<clinit>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(49,L0);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(4)); // int: 0x00000004  float:0.000000
                code.visitTypeStmt(NEW_ARRAY,0,0,"[Ljava/lang/String;");
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitConstStmt(CONST_STRING,2,"org.mortbay.ijetty.AndroidWebInfConfiguration");
                code.visitStmt3R(APUT_OBJECT,2,0,1);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitConstStmt(CONST_STRING,2,"org.mortbay.jetty.webapp.WebXmlConfiguration");
                code.visitStmt3R(APUT_OBJECT,2,0,1);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitConstStmt(CONST_STRING,2,"org.mortbay.jetty.webapp.JettyWebXmlConfiguration");
                code.visitStmt3R(APUT_OBJECT,2,0,1);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(3)); // int: 0x00000003  float:0.000000
                code.visitConstStmt(CONST_STRING,2,"org.mortbay.jetty.webapp.TagLibConfiguration");
                code.visitStmt3R(APUT_OBJECT,2,0,1);
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/ijetty/IJettyService;","__configurationClasses","[Ljava/lang/String;"));
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/ijetty/IJettyService;","<init>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(45,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(62,L1);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Landroid/app/Service;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_BOOLEAN,0,1,new Field("Lorg/mortbay/ijetty/IJettyService;","isDebugEnabled","Z"));
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_getStreamToRawResource(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/ijetty/IJettyService;","getStreamToRawResource",new String[]{ "I"},"Ljava/io/InputStream;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"id");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(193,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(194,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(196,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/ijetty/IJettyService;","__resources","Landroid/content/res/Resources;"));
                DexLabel L3=new DexLabel();
                code.visitJumpStmt(IF_EQZ,0,-1,L3);
                code.visitLabel(L1);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/ijetty/IJettyService;","__resources","Landroid/content/res/Resources;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Landroid/content/res/Resources;","openRawResource",new String[]{ "I"},"Ljava/io/InputStream;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L2);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_startJetty(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PRIVATE, new Method("Lorg/mortbay/ijetty/IJettyService;","startJetty",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/Exception;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(14);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(207,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(209,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(211,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(212,L3);
                ddv.visitStartLocal(6,L3,"nioConnector","Lorg/mortbay/jetty/nio/SelectChannelConnector;",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(213,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(214,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(222,L6);
                ddv.visitEndLocal(6,L6);
                ddv.visitStartLocal(1,L6,"connector","Lorg/mortbay/jetty/Connector;",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(225,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(226,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(227,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(228,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(229,L11);
                ddv.visitStartLocal(4,L11,"handlers","Lorg/mortbay/jetty/handler/HandlerCollection;",null);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(230,L12);
                ddv.visitStartLocal(3,L12,"contexts","Lorg/mortbay/jetty/handler/ContextHandlerCollection;",null);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(231,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(233,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(236,L15);
                ddv.visitStartLocal(5,L15,"jettyDir","Ljava/io/File;",null);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(238,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(239,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(242,L18);
                ddv.visitStartLocal(9,L18,"staticDeployer","Lorg/mortbay/ijetty/AndroidWebAppDeployer;",null);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(244,L19);
                DexLabel L20=new DexLabel();
                ddv.visitEndLocal(9,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(245,L21);
                ddv.visitRestartLocal(9,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(246,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(247,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(248,L24);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(249,L25);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(251,L26);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(253,L27);
                ddv.visitStartLocal(2,L27,"contextDeployer","Lorg/mortbay/jetty/deployer/ContextDeployer;",null);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(255,L28);
                DexLabel L29=new DexLabel();
                ddv.visitEndLocal(2,L29);
                DexLabel L30=new DexLabel();
                ddv.visitLineNumber(256,L30);
                ddv.visitRestartLocal(2,L30);
                DexLabel L31=new DexLabel();
                ddv.visitLineNumber(257,L31);
                DexLabel L32=new DexLabel();
                ddv.visitLineNumber(258,L32);
                DexLabel L33=new DexLabel();
                ddv.visitLineNumber(260,L33);
                DexLabel L34=new DexLabel();
                ddv.visitLineNumber(261,L34);
                ddv.visitStartLocal(8,L34,"realmProps","Ljava/io/File;",null);
                DexLabel L35=new DexLabel();
                ddv.visitLineNumber(263,L35);
                DexLabel L36=new DexLabel();
                ddv.visitLineNumber(264,L36);
                ddv.visitStartLocal(7,L36,"realm","Lorg/mortbay/jetty/security/HashUserRealm;",null);
                DexLabel L37=new DexLabel();
                ddv.visitLineNumber(265,L37);
                DexLabel L38=new DexLabel();
                ddv.visitLineNumber(266,L38);
                DexLabel L39=new DexLabel();
                ddv.visitLineNumber(267,L39);
                DexLabel L40=new DexLabel();
                ddv.visitLineNumber(270,L40);
                ddv.visitEndLocal(7,L40);
                DexLabel L41=new DexLabel();
                ddv.visitLineNumber(271,L41);
                DexLabel L42=new DexLabel();
                ddv.visitLineNumber(273,L42);
                DexLabel L43=new DexLabel();
                ddv.visitLineNumber(274,L43);
                DexLabel L44=new DexLabel();
                ddv.visitLineNumber(281,L44);
                ddv.visitEndLocal(9,L44);
                ddv.visitEndLocal(2,L44);
                ddv.visitEndLocal(8,L44);
                DexLabel L45=new DexLabel();
                ddv.visitLineNumber(282,L45);
                DexLabel L46=new DexLabel();
                ddv.visitLineNumber(218,L46);
                ddv.visitEndLocal(1,L46);
                ddv.visitEndLocal(4,L46);
                ddv.visitEndLocal(3,L46);
                ddv.visitEndLocal(5,L46);
                DexLabel L47=new DexLabel();
                ddv.visitLineNumber(219,L47);
                ddv.visitStartLocal(0,L47,"bioConnector","Lorg/mortbay/jetty/bio/SocketConnector;",null);
                DexLabel L48=new DexLabel();
                ddv.visitLineNumber(220,L48);
                DexLabel L49=new DexLabel();
                ddv.visitRestartLocal(1,L49);
                DexLabel L50=new DexLabel();
                ddv.visitLineNumber(278,L50);
                ddv.visitEndLocal(0,L50);
                ddv.visitRestartLocal(3,L50);
                ddv.visitRestartLocal(4,L50);
                ddv.visitRestartLocal(5,L50);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,10,-1,"Lorg/mortbay/jetty/Server;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 10},new Method("Lorg/mortbay/jetty/Server;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,10,13,new Field("Lorg/mortbay/ijetty/IJettyService;","server","Lorg/mortbay/jetty/Server;"));
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_BOOLEAN,10,13,new Field("Lorg/mortbay/ijetty/IJettyService;","_useNIO","Z"));
                code.visitJumpStmt(IF_EQZ,10,-1,L46);
                code.visitLabel(L2);
                code.visitTypeStmt(NEW_INSTANCE,6,-1,"Lorg/mortbay/jetty/nio/SelectChannelConnector;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 6},new Method("Lorg/mortbay/jetty/nio/SelectChannelConnector;","<init>",new String[]{ },"V"));
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,10, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,10},new Method("Lorg/mortbay/jetty/nio/SelectChannelConnector;","setUseDirectBuffers",new String[]{ "Z"},"V"));
                code.visitLabel(L4);
                code.visitFieldStmt(IGET,10,13,new Field("Lorg/mortbay/ijetty/IJettyService;","_port","I"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,10},new Method("Lorg/mortbay/jetty/nio/SelectChannelConnector;","setPort",new String[]{ "I"},"V"));
                code.visitLabel(L5);
                code.visitStmt2R(MOVE_OBJECT,1,6);
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,10,13,new Field("Lorg/mortbay/ijetty/IJettyService;","server","Lorg/mortbay/jetty/Server;"));
                code.visitConstStmt(CONST_4,11, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitTypeStmt(NEW_ARRAY,11,11,"[Lorg/mortbay/jetty/Connector;");
                code.visitConstStmt(CONST_4,12, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt3R(APUT_OBJECT,1,11,12);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10,11},new Method("Lorg/mortbay/jetty/Server;","setConnectors",new String[]{ "[Lorg/mortbay/jetty/Connector;"},"V"));
                code.visitLabel(L7);
                code.visitFieldStmt(IGET_BOOLEAN,10,13,new Field("Lorg/mortbay/ijetty/IJettyService;","isDebugEnabled","Z"));
                code.visitFieldStmt(SPUT_BOOLEAN,10,-1,new Field("Lorg/mortbay/ijetty/AndroidLog;","__isDebugEnabled","Z"));
                code.visitLabel(L8);
                code.visitConstStmt(CONST_STRING,10,"org.mortbay.log.class");
                code.visitConstStmt(CONST_STRING,11,"org.mortbay.log.AndroidLog");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 10,11},new Method("Ljava/lang/System;","setProperty",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitLabel(L9);
                code.visitTypeStmt(NEW_INSTANCE,10,-1,"Lorg/mortbay/ijetty/AndroidLog;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 10},new Method("Lorg/mortbay/ijetty/AndroidLog;","<init>",new String[]{ },"V"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 10},new Method("Lorg/mortbay/log/Log;","setLog",new String[]{ "Lorg/mortbay/log/Logger;"},"V"));
                code.visitLabel(L10);
                code.visitTypeStmt(NEW_INSTANCE,4,-1,"Lorg/mortbay/jetty/handler/HandlerCollection;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4},new Method("Lorg/mortbay/jetty/handler/HandlerCollection;","<init>",new String[]{ },"V"));
                code.visitLabel(L11);
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Lorg/mortbay/jetty/handler/ContextHandlerCollection;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3},new Method("Lorg/mortbay/jetty/handler/ContextHandlerCollection;","<init>",new String[]{ },"V"));
                code.visitLabel(L12);
                code.visitConstStmt(CONST_4,10, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitTypeStmt(NEW_ARRAY,10,10,"[Lorg/mortbay/jetty/Handler;");
                code.visitConstStmt(CONST_4,11, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt3R(APUT_OBJECT,3,10,11);
                code.visitConstStmt(CONST_4,11, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitTypeStmt(NEW_INSTANCE,12,-1,"Lorg/mortbay/jetty/handler/DefaultHandler;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 12},new Method("Lorg/mortbay/jetty/handler/DefaultHandler;","<init>",new String[]{ },"V"));
                code.visitStmt3R(APUT_OBJECT,12,10,11);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,10},new Method("Lorg/mortbay/jetty/handler/HandlerCollection;","setHandlers",new String[]{ "[Lorg/mortbay/jetty/Handler;"},"V"));
                code.visitLabel(L13);
                code.visitFieldStmt(IGET_OBJECT,10,13,new Field("Lorg/mortbay/ijetty/IJettyService;","server","Lorg/mortbay/jetty/Server;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10,4},new Method("Lorg/mortbay/jetty/Server;","setHandler",new String[]{ "Lorg/mortbay/jetty/Handler;"},"V"));
                code.visitLabel(L14);
                code.visitTypeStmt(NEW_INSTANCE,5,-1,"Ljava/io/File;");
                code.visitConstStmt(CONST_STRING,10,"/sdcard/jetty");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 5,10},new Method("Ljava/io/File;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L15);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/io/File;","exists",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,10);
                code.visitJumpStmt(IF_EQZ,10,-1,L50);
                code.visitLabel(L16);
                code.visitConstStmt(CONST_STRING,10,"jetty.home");
                code.visitConstStmt(CONST_STRING,11,"/sdcard/jetty");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 10,11},new Method("Ljava/lang/System;","setProperty",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitLabel(L17);
                code.visitConstStmt(CONST_4,9, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L18);
                code.visitTypeStmt(NEW_INSTANCE,10,-1,"Ljava/io/File;");
                code.visitConstStmt(CONST_STRING,11,"webapps");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 10,5,11},new Method("Ljava/io/File;","<init>",new String[]{ "Ljava/io/File;","Ljava/lang/String;"},"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Ljava/io/File;","exists",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,10);
                code.visitJumpStmt(IF_EQZ,10,-1,L26);
                code.visitLabel(L19);
                code.visitTypeStmt(NEW_INSTANCE,9,-1,"Lorg/mortbay/ijetty/AndroidWebAppDeployer;");
                code.visitLabel(L20);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 9},new Method("Lorg/mortbay/ijetty/AndroidWebAppDeployer;","<init>",new String[]{ },"V"));
                code.visitLabel(L21);
                code.visitConstStmt(CONST_STRING,10,"/sdcard/jetty/webapps");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9,10},new Method("Lorg/mortbay/ijetty/AndroidWebAppDeployer;","setWebAppDir",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L22);
                code.visitConstStmt(CONST_STRING,10,"/sdcard/jetty/etc/webdefault.xml");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9,10},new Method("Lorg/mortbay/ijetty/AndroidWebAppDeployer;","setDefaultsDescriptor",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L23);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9,3},new Method("Lorg/mortbay/ijetty/AndroidWebAppDeployer;","setContexts",new String[]{ "Lorg/mortbay/jetty/HandlerContainer;"},"V"));
                code.visitLabel(L24);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13},new Method("Lorg/mortbay/ijetty/IJettyService;","getContentResolver",new String[]{ },"Landroid/content/ContentResolver;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9,10},new Method("Lorg/mortbay/ijetty/AndroidWebAppDeployer;","setContentResolver",new String[]{ "Landroid/content/ContentResolver;"},"V"));
                code.visitLabel(L25);
                code.visitFieldStmt(SGET_OBJECT,10,-1,new Field("Lorg/mortbay/ijetty/IJettyService;","__configurationClasses","[Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9,10},new Method("Lorg/mortbay/ijetty/AndroidWebAppDeployer;","setConfigurationClasses",new String[]{ "[Ljava/lang/String;"},"V"));
                code.visitLabel(L26);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L27);
                code.visitTypeStmt(NEW_INSTANCE,10,-1,"Ljava/io/File;");
                code.visitConstStmt(CONST_STRING,11,"contexts");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 10,5,11},new Method("Ljava/io/File;","<init>",new String[]{ "Ljava/io/File;","Ljava/lang/String;"},"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Ljava/io/File;","exists",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,10);
                code.visitJumpStmt(IF_EQZ,10,-1,L33);
                code.visitLabel(L28);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Lorg/mortbay/jetty/deployer/ContextDeployer;");
                code.visitLabel(L29);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2},new Method("Lorg/mortbay/jetty/deployer/ContextDeployer;","<init>",new String[]{ },"V"));
                code.visitLabel(L30);
                code.visitConstStmt(CONST_4,10, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,10},new Method("Lorg/mortbay/jetty/deployer/ContextDeployer;","setScanInterval",new String[]{ "I"},"V"));
                code.visitLabel(L31);
                code.visitConstStmt(CONST_STRING,10,"/sdcard/jetty/contexts");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,10},new Method("Lorg/mortbay/jetty/deployer/ContextDeployer;","setConfigurationDir",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L32);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Lorg/mortbay/jetty/deployer/ContextDeployer;","setContexts",new String[]{ "Lorg/mortbay/jetty/handler/ContextHandlerCollection;"},"V"));
                code.visitLabel(L33);
                code.visitTypeStmt(NEW_INSTANCE,8,-1,"Ljava/io/File;");
                code.visitConstStmt(CONST_STRING,10,"/sdcard/jetty/etc/realm.properties");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 8,10},new Method("Ljava/io/File;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L34);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Ljava/io/File;","exists",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,10);
                code.visitJumpStmt(IF_EQZ,10,-1,L40);
                code.visitLabel(L35);
                code.visitTypeStmt(NEW_INSTANCE,7,-1,"Lorg/mortbay/jetty/security/HashUserRealm;");
                code.visitConstStmt(CONST_STRING,10,"Console");
                code.visitConstStmt(CONST_STRING,11,"/sdcard/jetty/etc/realm.properties");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 7,10,11},new Method("Lorg/mortbay/jetty/security/HashUserRealm;","<init>",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"V"));
                code.visitLabel(L36);
                code.visitConstStmt(CONST_4,10, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,10},new Method("Lorg/mortbay/jetty/security/HashUserRealm;","setRefreshInterval",new String[]{ "I"},"V"));
                code.visitLabel(L37);
                code.visitFieldStmt(IGET_OBJECT,10,13,new Field("Lorg/mortbay/ijetty/IJettyService;","_consolePassword","Ljava/lang/String;"));
                code.visitJumpStmt(IF_EQZ,10,-1,L39);
                code.visitLabel(L38);
                code.visitConstStmt(CONST_STRING,10,"admin");
                code.visitFieldStmt(IGET_OBJECT,11,13,new Field("Lorg/mortbay/ijetty/IJettyService;","_consolePassword","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,10,11},new Method("Lorg/mortbay/jetty/security/HashUserRealm;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L39);
                code.visitFieldStmt(IGET_OBJECT,10,13,new Field("Lorg/mortbay/ijetty/IJettyService;","server","Lorg/mortbay/jetty/Server;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10,7},new Method("Lorg/mortbay/jetty/Server;","addUserRealm",new String[]{ "Lorg/mortbay/jetty/security/UserRealm;"},"V"));
                code.visitLabel(L40);
                code.visitJumpStmt(IF_EQZ,2,-1,L42);
                code.visitLabel(L41);
                code.visitFieldStmt(IGET_OBJECT,10,13,new Field("Lorg/mortbay/ijetty/IJettyService;","server","Lorg/mortbay/jetty/Server;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10,2},new Method("Lorg/mortbay/jetty/Server;","addLifeCycle",new String[]{ "Lorg/mortbay/component/LifeCycle;"},"V"));
                code.visitLabel(L42);
                code.visitJumpStmt(IF_EQZ,9,-1,L44);
                code.visitLabel(L43);
                code.visitFieldStmt(IGET_OBJECT,10,13,new Field("Lorg/mortbay/ijetty/IJettyService;","server","Lorg/mortbay/jetty/Server;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10,9},new Method("Lorg/mortbay/jetty/Server;","addLifeCycle",new String[]{ "Lorg/mortbay/component/LifeCycle;"},"V"));
                code.visitLabel(L44);
                code.visitFieldStmt(IGET_OBJECT,10,13,new Field("Lorg/mortbay/ijetty/IJettyService;","server","Lorg/mortbay/jetty/Server;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Lorg/mortbay/jetty/Server;","start",new String[]{ },"V"));
                code.visitLabel(L45);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L46);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/jetty/bio/SocketConnector;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Lorg/mortbay/jetty/bio/SocketConnector;","<init>",new String[]{ },"V"));
                code.visitLabel(L47);
                code.visitFieldStmt(IGET,10,13,new Field("Lorg/mortbay/ijetty/IJettyService;","_port","I"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,10},new Method("Lorg/mortbay/jetty/bio/SocketConnector;","setPort",new String[]{ "I"},"V"));
                code.visitLabel(L48);
                code.visitStmt2R(MOVE_OBJECT,1,0);
                code.visitLabel(L49);
                code.visitJumpStmt(GOTO_16,-1,-1,L6);
                code.visitLabel(L50);
                code.visitConstStmt(CONST_STRING,10,"Jetty");
                code.visitConstStmt(CONST_STRING,11,"Not loading any webapps - none on SD card.");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 10,11},new Method("Landroid/util/Log;","w",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"I"));
                code.visitJumpStmt(GOTO,-1,-1,L44);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_stopJetty(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PRIVATE, new Method("Lorg/mortbay/ijetty/IJettyService;","stopJetty",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/Exception;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(286,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(287,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(288,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(289,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(290,L4);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_STRING,0,"Jetty");
                code.visitConstStmt(CONST_STRING,1,"Jetty stopping");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,1},new Method("Landroid/util/Log;","i",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"I"));
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/ijetty/IJettyService;","server","Lorg/mortbay/jetty/Server;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/Server;","stop",new String[]{ },"V"));
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/ijetty/IJettyService;","server","Lorg/mortbay/jetty/Server;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/Server;","join",new String[]{ },"V"));
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/ijetty/IJettyService;","server","Lorg/mortbay/jetty/Server;"));
                code.visitLabel(L4);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_onBind(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/ijetty/IJettyService;","onBind",new String[]{ "Landroid/content/Intent;"},"Landroid/os/IBinder;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"intent");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(202,L0);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_onCreate(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/ijetty/IJettyService;","onCreate",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/lang/Exception;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(70,L3);
                ddv.visitLineNumber(74,L0);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(75,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(76,L5);
                ddv.visitLineNumber(82,L1);
                ddv.visitLineNumber(78,L2);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(80,L6);
                ddv.visitStartLocal(0,L6,"e","Ljava/lang/Exception;",null);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/ijetty/IJettyService;","getResources",new String[]{ },"Landroid/content/res/Resources;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitFieldStmt(SPUT_OBJECT,1,-1,new Field("Lorg/mortbay/ijetty/IJettyService;","__resources","Landroid/content/res/Resources;"));
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/ijetty/IJettyService;","getPackageManager",new String[]{ },"Landroid/content/pm/PackageManager;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/ijetty/IJettyService;","getPackageName",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2,3},new Method("Landroid/content/pm/PackageManager;","getPackageInfo",new String[]{ "Ljava/lang/String;","I"},"Landroid/content/pm/PackageInfo;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitFieldStmt(IPUT_OBJECT,1,4,new Field("Lorg/mortbay/ijetty/IJettyService;","pi","Landroid/content/pm/PackageInfo;"));
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/ijetty/IJettyService;","pi","Landroid/content/pm/PackageInfo;"));
                code.visitFieldStmt(IGET_OBJECT,1,1,new Field("Landroid/content/pm/PackageInfo;","versionName","Ljava/lang/String;"));
                code.visitJumpStmt(IF_EQZ,1,-1,L5);
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/ijetty/IJettyService;","pi","Landroid/content/pm/PackageInfo;"));
                code.visitFieldStmt(IGET_OBJECT,1,1,new Field("Landroid/content/pm/PackageInfo;","versionName","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/lang/String;","toLowerCase",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitConstStmt(CONST_STRING,2,"snapshot");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/lang/String;","endsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_EQZ,1,-1,L1);
                code.visitLabel(L5);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitFieldStmt(IPUT_BOOLEAN,1,4,new Field("Lorg/mortbay/ijetty/IJettyService;","isDebugEnabled","Z"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitStmt2R(MOVE_OBJECT,0,1);
                code.visitLabel(L6);
                code.visitConstStmt(CONST_STRING,1,"Jetty");
                code.visitConstStmt(CONST_STRING,2,"Unable to determine running jetty version");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1,2},new Method("Landroid/util/Log;","e",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"I"));
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m007_onDestroy(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/ijetty/IJettyService;","onDestroy",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/lang/Exception;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(150,L0);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(152,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(154,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(156,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(158,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(159,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(174,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(163,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(164,L11);
                ddv.visitLineNumber(168,L2);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(170,L12);
                ddv.visitStartLocal(0,L12,"e","Ljava/lang/Exception;",null);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(171,L13);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitConstStmt(CONST_STRING,4,"Jetty");
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,1,5,new Field("Lorg/mortbay/ijetty/IJettyService;","server","Lorg/mortbay/jetty/Server;"));
                code.visitJumpStmt(IF_EQZ,1,-1,L10);
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 5},new Method("Lorg/mortbay/ijetty/IJettyService;","stopJetty",new String[]{ },"V"));
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,1,5,new Field("Lorg/mortbay/ijetty/IJettyService;","mNM","Landroid/app/NotificationManager;"));
                code.visitConstStmt(CONST,2, Integer.valueOf(2131099649)); // int: 0x7f060001  float:178116571717588330000000000000000000000.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Landroid/app/NotificationManager;","cancel",new String[]{ "I"},"V"));
                code.visitLabel(L6);
                code.visitConstStmt(CONST,1, Integer.valueOf(2131099652)); // int: 0x7f060004  float:178116632564817140000000000000000000000.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,1},new Method("Lorg/mortbay/ijetty/IJettyService;","getText",new String[]{ "I"},"Ljava/lang/CharSequence;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 5,1,2},new Method("Landroid/widget/Toast;","makeText",new String[]{ "Landroid/content/Context;","Ljava/lang/CharSequence;","I"},"Landroid/widget/Toast;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Landroid/widget/Toast;","show",new String[]{ },"V"));
                code.visitLabel(L7);
                code.visitConstStmt(CONST_STRING,1,"Jetty");
                code.visitConstStmt(CONST_STRING,2,"Jetty stopped");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1,2},new Method("Landroid/util/Log;","i",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"I"));
                code.visitLabel(L8);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(SPUT_OBJECT,1,-1,new Field("Lorg/mortbay/ijetty/IJettyService;","__resources","Landroid/content/res/Resources;"));
                code.visitLabel(L9);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L10);
                code.visitConstStmt(CONST_STRING,1,"Jetty");
                code.visitConstStmt(CONST_STRING,2,"Jetty not running");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1,2},new Method("Landroid/util/Log;","i",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"I"));
                code.visitLabel(L11);
                code.visitConstStmt(CONST,1, Integer.valueOf(2131099654)); // int: 0x7f060006  float:178116673129636350000000000000000000000.000000
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 5,1,2},new Method("Landroid/widget/Toast;","makeText",new String[]{ "Landroid/content/Context;","I","I"},"Landroid/widget/Toast;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Landroid/widget/Toast;","show",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitJumpStmt(GOTO,-1,-1,L9);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitStmt2R(MOVE_OBJECT,0,1);
                code.visitLabel(L12);
                code.visitConstStmt(CONST_STRING,1,"Jetty");
                code.visitConstStmt(CONST_STRING,1,"Error stopping jetty");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 4,1,0},new Method("Landroid/util/Log;","e",new String[]{ "Ljava/lang/String;","Ljava/lang/String;","Ljava/lang/Throwable;"},"I"));
                code.visitLabel(L13);
                code.visitConstStmt(CONST,1, Integer.valueOf(2131099653)); // int: 0x7f060005  float:178116652847226750000000000000000000000.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,1},new Method("Lorg/mortbay/ijetty/IJettyService;","getText",new String[]{ "I"},"Ljava/lang/CharSequence;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 5,1,3},new Method("Landroid/widget/Toast;","makeText",new String[]{ "Landroid/content/Context;","Ljava/lang/CharSequence;","I"},"Landroid/widget/Toast;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Landroid/widget/Toast;","show",new String[]{ },"V"));
                code.visitJumpStmt(GOTO,-1,-1,L9);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m008_onLowMemory(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/ijetty/IJettyService;","onLowMemory",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(180,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(181,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(182,L2);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_STRING,0,"Jetty");
                code.visitConstStmt(CONST_STRING,1,"Low on memory");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,1},new Method("Landroid/util/Log;","i",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"I"));
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 2},new Method("Landroid/app/Service;","onLowMemory",new String[]{ },"V"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m009_onStart(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/ijetty/IJettyService;","onStart",new String[]{ "Landroid/content/Intent;","I"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(17);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/lang/Exception;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"intent");
                ddv.visitParameterName(1,"startId");
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(87,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(89,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(143,L5);
                ddv.visitLineNumber(96,L0);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(98,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(99,L7);
                ddv.visitStartLocal(5,L7,"portDefault","Ljava/lang/String;",null);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(100,L8);
                ddv.visitStartLocal(7,L8,"pwdDefault","Ljava/lang/String;",null);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(102,L9);
                ddv.visitStartLocal(2,L9,"nioDefault","Ljava/lang/String;",null);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(103,L10);
                ddv.visitStartLocal(6,L10,"portKey","Ljava/lang/String;",null);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(104,L11);
                ddv.visitStartLocal(8,L11,"pwdKey","Ljava/lang/String;",null);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(106,L12);
                ddv.visitStartLocal(3,L12,"nioKey","Ljava/lang/String;",null);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(107,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(108,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(110,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(111,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(113,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(115,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(117,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(121,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(124,L21);
                ddv.visitStartLocal(0,L21,"contentIntent","Landroid/app/PendingIntent;",null);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(126,L22);
                ddv.visitStartLocal(9,L22,"text","Ljava/lang/CharSequence;",null);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(130,L23);
                ddv.visitStartLocal(4,L23,"notification","Landroid/app/Notification;",null);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(133,L24);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(134,L25);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(135,L26);
                ddv.visitLineNumber(137,L2);
                ddv.visitEndLocal(5,L2);
                ddv.visitEndLocal(7,L2);
                ddv.visitEndLocal(2,L2);
                ddv.visitEndLocal(6,L2);
                ddv.visitEndLocal(8,L2);
                ddv.visitEndLocal(3,L2);
                ddv.visitEndLocal(0,L2);
                ddv.visitEndLocal(9,L2);
                ddv.visitEndLocal(4,L2);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(139,L27);
                ddv.visitStartLocal(1,L27,"e","Ljava/lang/Exception;",null);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(140,L28);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,10,14,new Field("Lorg/mortbay/ijetty/IJettyService;","server","Lorg/mortbay/jetty/Server;"));
                code.visitJumpStmt(IF_EQZ,10,-1,L0);
                code.visitLabel(L4);
                code.visitConstStmt(CONST,10, Integer.valueOf(2131099651)); // int: 0x7f060003  float:178116612282407540000000000000000000000.000000
                code.visitConstStmt(CONST_4,11, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 14,10,11},new Method("Landroid/widget/Toast;","makeText",new String[]{ "Landroid/content/Context;","I","I"},"Landroid/widget/Toast;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Landroid/widget/Toast;","show",new String[]{ },"V"));
                code.visitLabel(L5);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 14},new Method("Landroid/preference/PreferenceManager;","getDefaultSharedPreferences",new String[]{ "Landroid/content/Context;"},"Landroid/content/SharedPreferences;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,10);
                code.visitFieldStmt(IPUT_OBJECT,10,14,new Field("Lorg/mortbay/ijetty/IJettyService;","preferences","Landroid/content/SharedPreferences;"));
                code.visitLabel(L6);
                code.visitConstStmt(CONST,10, Integer.valueOf(2131099668)); // int: 0x7f060014  float:178116957083370800000000000000000000000.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 14,10},new Method("Lorg/mortbay/ijetty/IJettyService;","getText",new String[]{ "I"},"Ljava/lang/CharSequence;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Ljava/lang/Object;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitLabel(L7);
                code.visitConstStmt(CONST,10, Integer.valueOf(2131099672)); // int: 0x7f060018  float:178117038213009200000000000000000000000.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 14,10},new Method("Lorg/mortbay/ijetty/IJettyService;","getText",new String[]{ "I"},"Ljava/lang/CharSequence;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Ljava/lang/Object;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitLabel(L8);
                code.visitConstStmt(CONST,10, Integer.valueOf(2131099665)); // int: 0x7f060011  float:178116896236142000000000000000000000000.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 14,10},new Method("Lorg/mortbay/ijetty/IJettyService;","getText",new String[]{ "I"},"Ljava/lang/CharSequence;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Ljava/lang/Object;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L9);
                code.visitConstStmt(CONST,10, Integer.valueOf(2131099671)); // int: 0x7f060017  float:178117017930599600000000000000000000000.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 14,10},new Method("Lorg/mortbay/ijetty/IJettyService;","getText",new String[]{ "I"},"Ljava/lang/CharSequence;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Ljava/lang/Object;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitLabel(L10);
                code.visitConstStmt(CONST,10, Integer.valueOf(2131099675)); // int: 0x7f06001b  float:178117099060238030000000000000000000000.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 14,10},new Method("Lorg/mortbay/ijetty/IJettyService;","getText",new String[]{ "I"},"Ljava/lang/CharSequence;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Ljava/lang/Object;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitLabel(L11);
                code.visitConstStmt(CONST,10, Integer.valueOf(2131099667)); // int: 0x7f060013  float:178116936800961200000000000000000000000.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 14,10},new Method("Lorg/mortbay/ijetty/IJettyService;","getText",new String[]{ "I"},"Ljava/lang/CharSequence;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Ljava/lang/Object;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitLabel(L12);
                code.visitFieldStmt(IGET_OBJECT,10,14,new Field("Lorg/mortbay/ijetty/IJettyService;","preferences","Landroid/content/SharedPreferences;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2},new Method("Ljava/lang/Boolean;","valueOf",new String[]{ "Ljava/lang/String;"},"Ljava/lang/Boolean;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,11);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11},new Method("Ljava/lang/Boolean;","booleanValue",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,11);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 10,3,11},new Method("Landroid/content/SharedPreferences;","getBoolean",new String[]{ "Ljava/lang/String;","Z"},"Z"));
                code.visitStmt1R(MOVE_RESULT,10);
                code.visitFieldStmt(IPUT_BOOLEAN,10,14,new Field("Lorg/mortbay/ijetty/IJettyService;","_useNIO","Z"));
                code.visitLabel(L13);
                code.visitFieldStmt(IGET_OBJECT,10,14,new Field("Lorg/mortbay/ijetty/IJettyService;","preferences","Landroid/content/SharedPreferences;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 10,6,5},new Method("Landroid/content/SharedPreferences;","getString",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,10);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 10},new Method("Ljava/lang/Integer;","parseInt",new String[]{ "Ljava/lang/String;"},"I"));
                code.visitStmt1R(MOVE_RESULT,10);
                code.visitFieldStmt(IPUT,10,14,new Field("Lorg/mortbay/ijetty/IJettyService;","_port","I"));
                code.visitLabel(L14);
                code.visitFieldStmt(IGET_OBJECT,10,14,new Field("Lorg/mortbay/ijetty/IJettyService;","preferences","Landroid/content/SharedPreferences;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 10,8,7},new Method("Landroid/content/SharedPreferences;","getString",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,10);
                code.visitFieldStmt(IPUT_OBJECT,10,14,new Field("Lorg/mortbay/ijetty/IJettyService;","_consolePassword","Ljava/lang/String;"));
                code.visitLabel(L15);
                code.visitConstStmt(CONST_STRING,10,"Jetty");
                code.visitTypeStmt(NEW_INSTANCE,11,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 11},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,12,"pref port = ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11,12},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,11);
                code.visitFieldStmt(IGET_OBJECT,12,14,new Field("Lorg/mortbay/ijetty/IJettyService;","preferences","Landroid/content/SharedPreferences;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 12,6,5},new Method("Landroid/content/SharedPreferences;","getString",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,12);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11,12},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,11);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,11);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 10,11},new Method("Landroid/util/Log;","d",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"I"));
                code.visitLabel(L16);
                code.visitConstStmt(CONST_STRING,10,"Jetty");
                code.visitTypeStmt(NEW_INSTANCE,11,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 11},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,12,"pref nio = ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11,12},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,11);
                code.visitFieldStmt(IGET_OBJECT,12,14,new Field("Lorg/mortbay/ijetty/IJettyService;","preferences","Landroid/content/SharedPreferences;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2},new Method("Ljava/lang/Boolean;","valueOf",new String[]{ "Ljava/lang/String;"},"Ljava/lang/Boolean;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,13);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13},new Method("Ljava/lang/Boolean;","booleanValue",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,13);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 12,3,13},new Method("Landroid/content/SharedPreferences;","getBoolean",new String[]{ "Ljava/lang/String;","Z"},"Z"));
                code.visitStmt1R(MOVE_RESULT,12);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11,12},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Z"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,11);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,11);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 10,11},new Method("Landroid/util/Log;","d",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"I"));
                code.visitLabel(L17);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 14},new Method("Lorg/mortbay/ijetty/IJettyService;","startJetty",new String[]{ },"V"));
                code.visitLabel(L18);
                code.visitConstStmt(CONST_STRING,10,"notification");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 14,10},new Method("Lorg/mortbay/ijetty/IJettyService;","getSystemService",new String[]{ "Ljava/lang/String;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Landroid/app/NotificationManager;");
                code.visitFieldStmt(IPUT_OBJECT,0,14,new Field("Lorg/mortbay/ijetty/IJettyService;","mNM","Landroid/app/NotificationManager;"));
                code.visitLabel(L19);
                code.visitConstStmt(CONST,10, Integer.valueOf(2131099649)); // int: 0x7f060001  float:178116571717588330000000000000000000000.000000
                code.visitConstStmt(CONST_4,11, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 14,10,11},new Method("Landroid/widget/Toast;","makeText",new String[]{ "Landroid/content/Context;","I","I"},"Landroid/widget/Toast;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Landroid/widget/Toast;","show",new String[]{ },"V"));
                code.visitLabel(L20);
                code.visitConstStmt(CONST_4,10, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitTypeStmt(NEW_INSTANCE,11,-1,"Landroid/content/Intent;");
                code.visitConstStmt(CONST_CLASS,12,new DexType("Lorg/mortbay/ijetty/IJetty;"));
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 11,14,12},new Method("Landroid/content/Intent;","<init>",new String[]{ "Landroid/content/Context;","Ljava/lang/Class;"},"V"));
                code.visitConstStmt(CONST_4,12, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 14,10,11,12},new Method("Landroid/app/PendingIntent;","getActivity",new String[]{ "Landroid/content/Context;","I","Landroid/content/Intent;","I"},"Landroid/app/PendingIntent;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L21);
                code.visitConstStmt(CONST,10, Integer.valueOf(2131099655)); // int: 0x7f060007  float:178116693412045950000000000000000000000.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 14,10},new Method("Lorg/mortbay/ijetty/IJettyService;","getText",new String[]{ "I"},"Ljava/lang/CharSequence;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitLabel(L22);
                code.visitTypeStmt(NEW_INSTANCE,4,-1,"Landroid/app/Notification;");
                code.visitConstStmt(CONST,10, Integer.valueOf(2130837506)); // int: 0x7f020002  float:172799680016858270000000000000000000000.000000
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Ljava/lang/System;","currentTimeMillis",new String[]{ },"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,11);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4,10,9,11,12},new Method("Landroid/app/Notification;","<init>",new String[]{ "I","Ljava/lang/CharSequence;","J"},"V"));
                code.visitLabel(L23);
                code.visitConstStmt(CONST_HIGH16,10, Integer.valueOf(2131099648)); // int: 0x7f060000  float:178116551435178730000000000000000000000.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 14,10},new Method("Lorg/mortbay/ijetty/IJettyService;","getText",new String[]{ "I"},"Ljava/lang/CharSequence;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,14,10,9,0},new Method("Landroid/app/Notification;","setLatestEventInfo",new String[]{ "Landroid/content/Context;","Ljava/lang/CharSequence;","Ljava/lang/CharSequence;","Landroid/app/PendingIntent;"},"V"));
                code.visitLabel(L24);
                code.visitFieldStmt(IGET_OBJECT,10,14,new Field("Lorg/mortbay/ijetty/IJettyService;","mNM","Landroid/app/NotificationManager;"));
                code.visitConstStmt(CONST,11, Integer.valueOf(2131099649)); // int: 0x7f060001  float:178116571717588330000000000000000000000.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10,11,4},new Method("Landroid/app/NotificationManager;","notify",new String[]{ "I","Landroid/app/Notification;"},"V"));
                code.visitLabel(L25);
                code.visitConstStmt(CONST_STRING,10,"Jetty");
                code.visitConstStmt(CONST_STRING,11,"Jetty started");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 10,11},new Method("Landroid/util/Log;","i",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"I"));
                code.visitLabel(L26);
                code.visitMethodStmt(INVOKE_SUPER_RANGE,new int[]{ 14,15,16},new Method("Landroid/app/Service;","onStart",new String[]{ "Landroid/content/Intent;","I"},"V"));
                code.visitLabel(L1);
                code.visitJumpStmt(GOTO_16,-1,-1,L5);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,10);
                code.visitStmt2R(MOVE_OBJECT,1,10);
                code.visitLabel(L27);
                code.visitConstStmt(CONST_STRING,10,"Jetty");
                code.visitConstStmt(CONST_STRING,11,"Error starting jetty");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 10,11,1},new Method("Landroid/util/Log;","e",new String[]{ "Ljava/lang/String;","Ljava/lang/String;","Ljava/lang/Throwable;"},"I"));
                code.visitLabel(L28);
                code.visitConstStmt(CONST,10, Integer.valueOf(2131099650)); // int: 0x7f060002  float:178116591999997930000000000000000000000.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 14,10},new Method("Lorg/mortbay/ijetty/IJettyService;","getText",new String[]{ "I"},"Ljava/lang/CharSequence;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,10);
                code.visitConstStmt(CONST_4,11, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 14,10,11},new Method("Landroid/widget/Toast;","makeText",new String[]{ "Landroid/content/Context;","Ljava/lang/CharSequence;","I"},"Landroid/widget/Toast;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Landroid/widget/Toast;","show",new String[]{ },"V"));
                code.visitJumpStmt(GOTO_16,-1,-1,L5);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
