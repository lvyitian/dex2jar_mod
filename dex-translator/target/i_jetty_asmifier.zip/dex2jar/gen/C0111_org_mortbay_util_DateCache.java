package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0111_org_mortbay_util_DateCache {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/util/DateCache;","Ljava/lang/Object;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("DateCache.java");
        f000_DEFAULT_FORMAT(cv);
        f001___hitWindow(cv);
        f002__dfs(cv);
        f003__formatString(cv);
        f004__lastMinutes(cv);
        f005__lastMs(cv);
        f006__lastResult(cv);
        f007__lastSeconds(cv);
        f008__locale(cv);
        f009__minFormat(cv);
        f010__minFormatString(cv);
        f011__secFormatString(cv);
        f012__secFormatString0(cv);
        f013__secFormatString1(cv);
        f014__tzFormat(cv);
        f015__tzFormatString(cv);
        m000__clinit_(cv);
        m001__init_(cv);
        m002__init_(cv);
        m003__init_(cv);
        m004__init_(cv);
        m005_setMinFormatString(cv);
        m006_setTzFormatString(cv);
        m007_format(cv);
        m008_format(cv);
        m009_format(cv);
        m010_getFormat(cv);
        m011_getFormatString(cv);
        m012_getTimeZone(cv);
        m013_lastMs(cv);
        m014_now(cv);
        m015_setTimeZone(cv);
        m016_setTimeZoneID(cv);
    }
    public static void f000_DEFAULT_FORMAT(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC, new Field("Lorg/mortbay/util/DateCache;","DEFAULT_FORMAT","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001___hitWindow(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC, new Field("Lorg/mortbay/util/DateCache;","__hitWindow","J"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002__dfs(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/util/DateCache;","_dfs","Ljava/text/DateFormatSymbols;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003__formatString(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/util/DateCache;","_formatString","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f004__lastMinutes(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/util/DateCache;","_lastMinutes","J"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f005__lastMs(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/util/DateCache;","_lastMs","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f006__lastResult(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/util/DateCache;","_lastResult","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f007__lastSeconds(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/util/DateCache;","_lastSeconds","J"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f008__locale(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/util/DateCache;","_locale","Ljava/util/Locale;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f009__minFormat(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/util/DateCache;","_minFormat","Ljava/text/SimpleDateFormat;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f010__minFormatString(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/util/DateCache;","_minFormatString","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f011__secFormatString(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/util/DateCache;","_secFormatString","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f012__secFormatString0(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/util/DateCache;","_secFormatString0","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f013__secFormatString1(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/util/DateCache;","_secFormatString1","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f014__tzFormat(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/util/DateCache;","_tzFormat","Ljava/text/SimpleDateFormat;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f015__tzFormatString(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/util/DateCache;","_tzFormatString","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__clinit_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/util/DateCache;","<clinit>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(44,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(45,L1);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_STRING,0,"EEE MMM dd HH:mm:ss zzz yyyy");
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/util/DateCache;","DEFAULT_FORMAT","Ljava/lang/String;"));
                code.visitLabel(L1);
                code.visitConstStmt(CONST_WIDE_16,0,Long.valueOf(3600L)); // long: 0x0000000000000e10  double:0.000000
                code.visitFieldStmt(SPUT_WIDE,0,-1,new Field("Lorg/mortbay/util/DateCache;","__hitWindow","J"));
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/util/DateCache;","<init>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(73,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(74,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(75,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/util/DateCache;","DEFAULT_FORMAT","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2,0},new Method("Lorg/mortbay/util/DateCache;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/util/DateCache;","getFormat",new String[]{ },"Ljava/text/SimpleDateFormat;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Ljava/util/TimeZone;","getDefault",new String[]{ },"Ljava/util/TimeZone;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/text/SimpleDateFormat;","setTimeZone",new String[]{ "Ljava/util/TimeZone;"},"V"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/util/DateCache;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"format");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(82,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(58,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(59,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(60,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(61,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(63,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(64,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(83,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(84,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(86,L10);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_WIDE_16,2,Long.valueOf(-1L)); // long: 0xffffffffffffffff  double:NaN
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4},new Method("Ljava/lang/Object;","<init>",new String[]{ },"V"));
                code.visitLabel(L2);
                code.visitFieldStmt(IPUT_WIDE,2,4,new Field("Lorg/mortbay/util/DateCache;","_lastMinutes","J"));
                code.visitLabel(L3);
                code.visitFieldStmt(IPUT_WIDE,2,4,new Field("Lorg/mortbay/util/DateCache;","_lastSeconds","J"));
                code.visitLabel(L4);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(-1)); // int: 0xffffffff  float:NaN
                code.visitFieldStmt(IPUT,0,4,new Field("Lorg/mortbay/util/DateCache;","_lastMs","I"));
                code.visitLabel(L5);
                code.visitFieldStmt(IPUT_OBJECT,1,4,new Field("Lorg/mortbay/util/DateCache;","_lastResult","Ljava/lang/String;"));
                code.visitLabel(L6);
                code.visitFieldStmt(IPUT_OBJECT,1,4,new Field("Lorg/mortbay/util/DateCache;","_locale","Ljava/util/Locale;"));
                code.visitLabel(L7);
                code.visitFieldStmt(IPUT_OBJECT,1,4,new Field("Lorg/mortbay/util/DateCache;","_dfs","Ljava/text/DateFormatSymbols;"));
                code.visitLabel(L8);
                code.visitFieldStmt(IPUT_OBJECT,5,4,new Field("Lorg/mortbay/util/DateCache;","_formatString","Ljava/lang/String;"));
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Ljava/util/TimeZone;","getDefault",new String[]{ },"Ljava/util/TimeZone;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,0},new Method("Lorg/mortbay/util/DateCache;","setTimeZone",new String[]{ "Ljava/util/TimeZone;"},"V"));
                code.visitLabel(L10);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/util/DateCache;","<init>",new String[]{ "Ljava/lang/String;","Ljava/text/DateFormatSymbols;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"format");
                ddv.visitParameterName(1,"s");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(98,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(58,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(59,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(60,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(61,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(63,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(64,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(99,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(100,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(101,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(102,L11);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_WIDE_16,2,Long.valueOf(-1L)); // long: 0xffffffffffffffff  double:NaN
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4},new Method("Ljava/lang/Object;","<init>",new String[]{ },"V"));
                code.visitLabel(L2);
                code.visitFieldStmt(IPUT_WIDE,2,4,new Field("Lorg/mortbay/util/DateCache;","_lastMinutes","J"));
                code.visitLabel(L3);
                code.visitFieldStmt(IPUT_WIDE,2,4,new Field("Lorg/mortbay/util/DateCache;","_lastSeconds","J"));
                code.visitLabel(L4);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(-1)); // int: 0xffffffff  float:NaN
                code.visitFieldStmt(IPUT,0,4,new Field("Lorg/mortbay/util/DateCache;","_lastMs","I"));
                code.visitLabel(L5);
                code.visitFieldStmt(IPUT_OBJECT,1,4,new Field("Lorg/mortbay/util/DateCache;","_lastResult","Ljava/lang/String;"));
                code.visitLabel(L6);
                code.visitFieldStmt(IPUT_OBJECT,1,4,new Field("Lorg/mortbay/util/DateCache;","_locale","Ljava/util/Locale;"));
                code.visitLabel(L7);
                code.visitFieldStmt(IPUT_OBJECT,1,4,new Field("Lorg/mortbay/util/DateCache;","_dfs","Ljava/text/DateFormatSymbols;"));
                code.visitLabel(L8);
                code.visitFieldStmt(IPUT_OBJECT,5,4,new Field("Lorg/mortbay/util/DateCache;","_formatString","Ljava/lang/String;"));
                code.visitLabel(L9);
                code.visitFieldStmt(IPUT_OBJECT,6,4,new Field("Lorg/mortbay/util/DateCache;","_dfs","Ljava/text/DateFormatSymbols;"));
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Ljava/util/TimeZone;","getDefault",new String[]{ },"Ljava/util/TimeZone;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,0},new Method("Lorg/mortbay/util/DateCache;","setTimeZone",new String[]{ "Ljava/util/TimeZone;"},"V"));
                code.visitLabel(L11);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/util/DateCache;","<init>",new String[]{ "Ljava/lang/String;","Ljava/util/Locale;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"format");
                ddv.visitParameterName(1,"l");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(90,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(58,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(59,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(60,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(61,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(63,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(64,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(91,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(92,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(93,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(94,L11);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_WIDE_16,2,Long.valueOf(-1L)); // long: 0xffffffffffffffff  double:NaN
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4},new Method("Ljava/lang/Object;","<init>",new String[]{ },"V"));
                code.visitLabel(L2);
                code.visitFieldStmt(IPUT_WIDE,2,4,new Field("Lorg/mortbay/util/DateCache;","_lastMinutes","J"));
                code.visitLabel(L3);
                code.visitFieldStmt(IPUT_WIDE,2,4,new Field("Lorg/mortbay/util/DateCache;","_lastSeconds","J"));
                code.visitLabel(L4);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(-1)); // int: 0xffffffff  float:NaN
                code.visitFieldStmt(IPUT,0,4,new Field("Lorg/mortbay/util/DateCache;","_lastMs","I"));
                code.visitLabel(L5);
                code.visitFieldStmt(IPUT_OBJECT,1,4,new Field("Lorg/mortbay/util/DateCache;","_lastResult","Ljava/lang/String;"));
                code.visitLabel(L6);
                code.visitFieldStmt(IPUT_OBJECT,1,4,new Field("Lorg/mortbay/util/DateCache;","_locale","Ljava/util/Locale;"));
                code.visitLabel(L7);
                code.visitFieldStmt(IPUT_OBJECT,1,4,new Field("Lorg/mortbay/util/DateCache;","_dfs","Ljava/text/DateFormatSymbols;"));
                code.visitLabel(L8);
                code.visitFieldStmt(IPUT_OBJECT,5,4,new Field("Lorg/mortbay/util/DateCache;","_formatString","Ljava/lang/String;"));
                code.visitLabel(L9);
                code.visitFieldStmt(IPUT_OBJECT,6,4,new Field("Lorg/mortbay/util/DateCache;","_locale","Ljava/util/Locale;"));
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Ljava/util/TimeZone;","getDefault",new String[]{ },"Ljava/util/TimeZone;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,0},new Method("Lorg/mortbay/util/DateCache;","setTimeZone",new String[]{ "Ljava/util/TimeZone;"},"V"));
                code.visitLabel(L11);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_setMinFormatString(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PRIVATE, new Method("Lorg/mortbay/util/DateCache;","setMinFormatString",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(193,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(194,L1);
                ddv.visitStartLocal(0,L1,"i","I",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(195,L2);
                ddv.visitStartLocal(1,L2,"l","I",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(196,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(197,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(198,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(201,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(202,L7);
                ddv.visitStartLocal(2,L7,"ss1","Ljava/lang/String;",null);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(203,L8);
                ddv.visitStartLocal(3,L8,"ss2","Ljava/lang/String;",null);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(204,L9);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,4,6,new Field("Lorg/mortbay/util/DateCache;","_tzFormatString","Ljava/lang/String;"));
                code.visitConstStmt(CONST_STRING,5,"ss.SSS");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Ljava/lang/String;","indexOf",new String[]{ "Ljava/lang/String;"},"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(6)); // int: 0x00000006  float:0.000000
                code.visitLabel(L2);
                code.visitJumpStmt(IF_LTZ,0,-1,L4);
                code.visitLabel(L3);
                code.visitTypeStmt(NEW_INSTANCE,4,-1,"Ljava/lang/IllegalStateException;");
                code.visitConstStmt(CONST_STRING,5,"ms not supported");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4,5},new Method("Ljava/lang/IllegalStateException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,4);
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,4,6,new Field("Lorg/mortbay/util/DateCache;","_tzFormatString","Ljava/lang/String;"));
                code.visitConstStmt(CONST_STRING,5,"ss");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Ljava/lang/String;","indexOf",new String[]{ "Ljava/lang/String;"},"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitLabel(L5);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,4,6,new Field("Lorg/mortbay/util/DateCache;","_tzFormatString","Ljava/lang/String;"));
                code.visitConstStmt(CONST_4,5, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5,0},new Method("Ljava/lang/String;","substring",new String[]{ "I","I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L7);
                code.visitFieldStmt(IGET_OBJECT,4,6,new Field("Lorg/mortbay/util/DateCache;","_tzFormatString","Ljava/lang/String;"));
                code.visitStmt3R(ADD_INT,5,0,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Ljava/lang/String;","substring",new String[]{ "I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitLabel(L8);
                code.visitTypeStmt(NEW_INSTANCE,4,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitConstStmt(CONST_STRING,5,"\'ss\'");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitFieldStmt(IPUT_OBJECT,4,6,new Field("Lorg/mortbay/util/DateCache;","_minFormatString","Ljava/lang/String;"));
                code.visitLabel(L9);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_setTzFormatString(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PRIVATE, new Method("Lorg/mortbay/util/DateCache;","setTzFormatString",new String[]{ "Ljava/util/TimeZone;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(14);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"tz");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(151,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(152,L2);
                ddv.visitStartLocal(7,L2,"zIndex","I",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(154,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(155,L4);
                ddv.visitStartLocal(4,L4,"ss1","Ljava/lang/String;",null);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(156,L5);
                ddv.visitStartLocal(5,L5,"ss2","Ljava/lang/String;",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(158,L6);
                ddv.visitStartLocal(6,L6,"tzOffset","I",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(159,L7);
                ddv.visitStartLocal(3,L7,"sb","Ljava/lang/StringBuffer;",null);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(160,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(161,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(162,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(169,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(170,L12);
                ddv.visitStartLocal(2,L12,"raw","I",null);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(171,L13);
                ddv.visitStartLocal(0,L13,"hr","I",null);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(173,L14);
                ddv.visitStartLocal(1,L14,"min","I",null);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(174,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(175,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(176,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(177,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(178,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(179,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(181,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(182,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(186,L23);
                ddv.visitEndLocal(4,L23);
                ddv.visitEndLocal(5,L23);
                ddv.visitEndLocal(6,L23);
                ddv.visitEndLocal(3,L23);
                ddv.visitEndLocal(2,L23);
                ddv.visitEndLocal(0,L23);
                ddv.visitEndLocal(1,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(187,L24);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(165,L25);
                ddv.visitRestartLocal(3,L25);
                ddv.visitRestartLocal(4,L25);
                ddv.visitRestartLocal(5,L25);
                ddv.visitRestartLocal(6,L25);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(166,L26);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(185,L27);
                ddv.visitEndLocal(3,L27);
                ddv.visitEndLocal(4,L27);
                ddv.visitEndLocal(5,L27);
                ddv.visitEndLocal(6,L27);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_16,11, Integer.valueOf(48)); // int: 0x00000030  float:0.000000
                code.visitConstStmt(CONST_16,10, Integer.valueOf(10)); // int: 0x0000000a  float:0.000000
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,8,12,new Field("Lorg/mortbay/util/DateCache;","_formatString","Ljava/lang/String;"));
                code.visitConstStmt(CONST_STRING,9,"ZZZ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,9},new Method("Ljava/lang/String;","indexOf",new String[]{ "Ljava/lang/String;"},"I"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitLabel(L2);
                code.visitJumpStmt(IF_LTZ,7,-1,L27);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,8,12,new Field("Lorg/mortbay/util/DateCache;","_formatString","Ljava/lang/String;"));
                code.visitConstStmt(CONST_4,9, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,9,7},new Method("Ljava/lang/String;","substring",new String[]{ "I","I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,8,12,new Field("Lorg/mortbay/util/DateCache;","_formatString","Ljava/lang/String;"));
                code.visitStmt2R1N(ADD_INT_LIT8,9,7,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,9},new Method("Ljava/lang/String;","substring",new String[]{ "I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13},new Method("Ljava/util/TimeZone;","getRawOffset",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitLabel(L6);
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Ljava/lang/StringBuffer;");
                code.visitFieldStmt(IGET_OBJECT,8,12,new Field("Lorg/mortbay/util/DateCache;","_formatString","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitStmt2R1N(ADD_INT_LIT8,8,8,10);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3,8},new Method("Ljava/lang/StringBuffer;","<init>",new String[]{ "I"},"V"));
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L8);
                code.visitConstStmt(CONST_STRING,8,"\'");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,8},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L9);
                code.visitJumpStmt(IF_LTZ,6,-1,L25);
                code.visitLabel(L10);
                code.visitConstStmt(CONST_16,8, Integer.valueOf(43)); // int: 0x0000002b  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,8},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "C"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L11);
                code.visitConstStmt(CONST,8, Integer.valueOf(60000)); // int: 0x0000ea60  float:0.000000
                code.visitStmt3R(DIV_INT,2,6,8);
                code.visitLabel(L12);
                code.visitStmt2R1N(DIV_INT_LIT8,0,2,60);
                code.visitLabel(L13);
                code.visitStmt2R1N(REM_INT_LIT8,1,2,60);
                code.visitLabel(L14);
                code.visitJumpStmt(IF_GE,0,10,L16);
                code.visitLabel(L15);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,11},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "C"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L16);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,0},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "I"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L17);
                code.visitJumpStmt(IF_GE,1,10,L19);
                code.visitLabel(L18);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,11},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "C"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L19);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,1},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "I"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L20);
                code.visitConstStmt(CONST_16,8, Integer.valueOf(39)); // int: 0x00000027  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,8},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "C"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L21);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,5},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L22);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/lang/StringBuffer;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitFieldStmt(IPUT_OBJECT,8,12,new Field("Lorg/mortbay/util/DateCache;","_tzFormatString","Ljava/lang/String;"));
                code.visitLabel(L23);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 12},new Method("Lorg/mortbay/util/DateCache;","setMinFormatString",new String[]{ },"V"));
                code.visitLabel(L24);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L25);
                code.visitStmt2R(NEG_INT,6,6);
                code.visitLabel(L26);
                code.visitConstStmt(CONST_16,8, Integer.valueOf(45)); // int: 0x0000002d  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,8},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "C"},"Ljava/lang/StringBuffer;"));
                code.visitJumpStmt(GOTO,-1,-1,L11);
                code.visitLabel(L27);
                code.visitFieldStmt(IGET_OBJECT,8,12,new Field("Lorg/mortbay/util/DateCache;","_formatString","Ljava/lang/String;"));
                code.visitFieldStmt(IPUT_OBJECT,8,12,new Field("Lorg/mortbay/util/DateCache;","_tzFormatString","Ljava/lang/String;"));
                code.visitJumpStmt(GOTO,-1,-1,L23);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m007_format(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/DateCache;","format",new String[]{ "J"},"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(16);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L2},new String[]{ null});
                DexLabel L5=new DexLabel();
                DexLabel L6=new DexLabel();
                code.visitTryCatch(L4,L5,new DexLabel[]{L6},new String[]{ null});
                DexLabel L7=new DexLabel();
                code.visitTryCatch(L5,L7,new DexLabel[]{L2},new String[]{ null});
                DexLabel L8=new DexLabel();
                DexLabel L9=new DexLabel();
                code.visitTryCatch(L8,L9,new DexLabel[]{L6},new String[]{ null});
                code.visitTryCatch(L9,L2,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"inDate");
                DexLabel L10=new DexLabel();
                ddv.visitPrologue(L10);
                ddv.visitLineNumber(223,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(226,L11);
                ddv.visitStartLocal(7,L11,"seconds","J",null);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(230,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(231,L13);
                ddv.visitStartLocal(0,L13,"d","Ljava/util/Date;",null);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(269,L14);
                ddv.visitEndLocal(0,L14);
                ddv.visitLineNumber(237,L3);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(238,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(240,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(243,L17);
                ddv.visitRestartLocal(0,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(244,L18);
                ddv.visitStartLocal(3,L18,"minutes","J",null);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(246,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(247,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(249,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(250,L22);
                ddv.visitStartLocal(1,L22,"i","I",null);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(251,L23);
                ddv.visitStartLocal(2,L23,"l","I",null);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(252,L24);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(256,L25);
                ddv.visitEndLocal(1,L25);
                ddv.visitEndLocal(2,L25);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(257,L26);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(258,L27);
                ddv.visitStartLocal(6,L27,"sb","Ljava/lang/StringBuffer;",null);
                ddv.visitLineNumber(260,L4);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(261,L28);
                DexLabel L29=new DexLabel();
                ddv.visitLineNumber(262,L29);
                ddv.visitStartLocal(5,L29,"s","I",null);
                DexLabel L30=new DexLabel();
                ddv.visitLineNumber(263,L30);
                DexLabel L31=new DexLabel();
                ddv.visitLineNumber(264,L31);
                DexLabel L32=new DexLabel();
                ddv.visitLineNumber(265,L32);
                DexLabel L33=new DexLabel();
                ddv.visitLineNumber(266,L33);
                DexLabel L34=new DexLabel();
                ddv.visitLineNumber(267,L34);
                ddv.visitLineNumber(269,L5);
                ddv.visitLineNumber(267,L6);
                ddv.visitEndLocal(5,L6);
                ddv.visitLineNumber(223,L2);
                ddv.visitEndLocal(7,L2);
                ddv.visitEndLocal(0,L2);
                ddv.visitEndLocal(3,L2);
                ddv.visitEndLocal(6,L2);
                code.visitLabel(L10);
                code.visitStmt1R(MONITOR_ENTER,13);
                code.visitConstStmt(CONST_WIDE_16,9,Long.valueOf(1000L)); // long: 0x00000000000003e8  double:0.000000
                code.visitLabel(L0);
                code.visitStmt3R(DIV_LONG,7,14,9);
                code.visitLabel(L11);
                code.visitFieldStmt(IGET_WIDE,9,13,new Field("Lorg/mortbay/util/DateCache;","_lastSeconds","J"));
                code.visitStmt3R(CMP_LONG,9,7,9);
                code.visitJumpStmt(IF_LTZ,9,-1,L12);
                code.visitFieldStmt(IGET_WIDE,9,13,new Field("Lorg/mortbay/util/DateCache;","_lastSeconds","J"));
                code.visitConstStmt(CONST_WIDE_16,11,Long.valueOf(0L)); // long: 0x0000000000000000  double:0.000000
                code.visitStmt3R(CMP_LONG,9,9,11);
                code.visitJumpStmt(IF_LEZ,9,-1,L3);
                code.visitFieldStmt(IGET_WIDE,9,13,new Field("Lorg/mortbay/util/DateCache;","_lastSeconds","J"));
                code.visitFieldStmt(SGET_WIDE,11,-1,new Field("Lorg/mortbay/util/DateCache;","__hitWindow","J"));
                code.visitStmt2R(ADD_LONG_2ADDR,9,11);
                code.visitStmt3R(CMP_LONG,9,7,9);
                code.visitJumpStmt(IF_LEZ,9,-1,L3);
                code.visitLabel(L12);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/util/Date;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,14,15},new Method("Ljava/util/Date;","<init>",new String[]{ "J"},"V"));
                code.visitLabel(L13);
                code.visitFieldStmt(IGET_OBJECT,9,13,new Field("Lorg/mortbay/util/DateCache;","_tzFormat","Ljava/text/SimpleDateFormat;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9,0},new Method("Ljava/text/SimpleDateFormat;","format",new String[]{ "Ljava/util/Date;"},"Ljava/lang/String;"));
                code.visitLabel(L1);
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitLabel(L14);
                code.visitStmt1R(MONITOR_EXIT,13);
                code.visitStmt1R(RETURN_OBJECT,9);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_WIDE,9,13,new Field("Lorg/mortbay/util/DateCache;","_lastSeconds","J"));
                code.visitStmt3R(CMP_LONG,9,9,7);
                code.visitJumpStmt(IF_NEZ,9,-1,L16);
                code.visitLabel(L15);
                code.visitFieldStmt(IGET_OBJECT,9,13,new Field("Lorg/mortbay/util/DateCache;","_lastResult","Ljava/lang/String;"));
                code.visitJumpStmt(GOTO,-1,-1,L14);
                code.visitLabel(L16);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/util/Date;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,14,15},new Method("Ljava/util/Date;","<init>",new String[]{ "J"},"V"));
                code.visitLabel(L17);
                code.visitConstStmt(CONST_WIDE_16,9,Long.valueOf(60L)); // long: 0x000000000000003c  double:0.000000
                code.visitStmt3R(DIV_LONG,3,7,9);
                code.visitLabel(L18);
                code.visitFieldStmt(IGET_WIDE,9,13,new Field("Lorg/mortbay/util/DateCache;","_lastMinutes","J"));
                code.visitStmt3R(CMP_LONG,9,9,3);
                code.visitJumpStmt(IF_EQZ,9,-1,L25);
                code.visitLabel(L19);
                code.visitFieldStmt(IPUT_WIDE,3,13,new Field("Lorg/mortbay/util/DateCache;","_lastMinutes","J"));
                code.visitLabel(L20);
                code.visitFieldStmt(IGET_OBJECT,9,13,new Field("Lorg/mortbay/util/DateCache;","_minFormat","Ljava/text/SimpleDateFormat;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9,0},new Method("Ljava/text/SimpleDateFormat;","format",new String[]{ "Ljava/util/Date;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitFieldStmt(IPUT_OBJECT,9,13,new Field("Lorg/mortbay/util/DateCache;","_secFormatString","Ljava/lang/String;"));
                code.visitLabel(L21);
                code.visitFieldStmt(IGET_OBJECT,9,13,new Field("Lorg/mortbay/util/DateCache;","_secFormatString","Ljava/lang/String;"));
                code.visitConstStmt(CONST_STRING,10,"ss");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9,10},new Method("Ljava/lang/String;","indexOf",new String[]{ "Ljava/lang/String;"},"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitLabel(L22);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitLabel(L23);
                code.visitFieldStmt(IGET_OBJECT,9,13,new Field("Lorg/mortbay/util/DateCache;","_secFormatString","Ljava/lang/String;"));
                code.visitConstStmt(CONST_4,10, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9,10,1},new Method("Ljava/lang/String;","substring",new String[]{ "I","I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitFieldStmt(IPUT_OBJECT,9,13,new Field("Lorg/mortbay/util/DateCache;","_secFormatString0","Ljava/lang/String;"));
                code.visitLabel(L24);
                code.visitFieldStmt(IGET_OBJECT,9,13,new Field("Lorg/mortbay/util/DateCache;","_secFormatString","Ljava/lang/String;"));
                code.visitStmt3R(ADD_INT,10,1,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9,10},new Method("Ljava/lang/String;","substring",new String[]{ "I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitFieldStmt(IPUT_OBJECT,9,13,new Field("Lorg/mortbay/util/DateCache;","_secFormatString1","Ljava/lang/String;"));
                code.visitLabel(L25);
                code.visitFieldStmt(IPUT_WIDE,7,13,new Field("Lorg/mortbay/util/DateCache;","_lastSeconds","J"));
                code.visitLabel(L26);
                code.visitTypeStmt(NEW_INSTANCE,6,-1,"Ljava/lang/StringBuffer;");
                code.visitFieldStmt(IGET_OBJECT,9,13,new Field("Lorg/mortbay/util/DateCache;","_secFormatString","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,9);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 6,9},new Method("Ljava/lang/StringBuffer;","<init>",new String[]{ "I"},"V"));
                code.visitLabel(L27);
                code.visitStmt1R(MONITOR_ENTER,6);
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,9,13,new Field("Lorg/mortbay/util/DateCache;","_secFormatString0","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,9},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L28);
                code.visitConstStmt(CONST_WIDE_16,9,Long.valueOf(60L)); // long: 0x000000000000003c  double:0.000000
                code.visitStmt3R(REM_LONG,9,7,9);
                code.visitStmt2R(LONG_TO_INT,5,9);
                code.visitLabel(L29);
                code.visitConstStmt(CONST_16,9, Integer.valueOf(10)); // int: 0x0000000a  float:0.000000
                code.visitJumpStmt(IF_GE,5,9,L31);
                code.visitLabel(L30);
                code.visitConstStmt(CONST_16,9, Integer.valueOf(48)); // int: 0x00000030  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,9},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "C"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L31);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,5},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "I"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L32);
                code.visitFieldStmt(IGET_OBJECT,9,13,new Field("Lorg/mortbay/util/DateCache;","_secFormatString1","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,9},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L33);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/lang/StringBuffer;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitFieldStmt(IPUT_OBJECT,9,13,new Field("Lorg/mortbay/util/DateCache;","_lastResult","Ljava/lang/String;"));
                code.visitLabel(L34);
                code.visitStmt1R(MONITOR_EXIT,6);
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,9,13,new Field("Lorg/mortbay/util/DateCache;","_lastResult","Ljava/lang/String;"));
                code.visitLabel(L7);
                code.visitJumpStmt(GOTO,-1,-1,L14);
                code.visitLabel(L6);
                code.visitStmt1R(MOVE_EXCEPTION,9);
                code.visitLabel(L8);
                code.visitStmt1R(MONITOR_EXIT,6);
                code.visitLabel(L9);
                code.visitStmt1R(THROW,9);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,9);
                code.visitStmt1R(MONITOR_EXIT,13);
                code.visitStmt1R(THROW,9);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m008_format(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/DateCache;","format",new String[]{ "Ljava/util/Date;"},"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"inDate");
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(213,L3);
                code.visitLabel(L3);
                code.visitStmt1R(MONITOR_ENTER,2);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/util/Date;","getTime",new String[]{ },"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,0,1},new Method("Lorg/mortbay/util/DateCache;","format",new String[]{ "J"},"Ljava/lang/String;"));
                code.visitLabel(L1);
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt1R(MONITOR_EXIT,2);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,0);
                code.visitStmt1R(MONITOR_EXIT,2);
                code.visitStmt1R(THROW,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m009_format(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/DateCache;","format",new String[]{ "J","Ljava/lang/StringBuffer;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"inDate");
                ddv.visitParameterName(1,"buffer");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(279,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(280,L1);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2,3},new Method("Lorg/mortbay/util/DateCache;","format",new String[]{ "J"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,0},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m010_getFormat(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/DateCache;","getFormat",new String[]{ },"Ljava/text/SimpleDateFormat;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(287,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/util/DateCache;","_minFormat","Ljava/text/SimpleDateFormat;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m011_getFormatString(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/DateCache;","getFormatString",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(293,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/util/DateCache;","_formatString","Ljava/lang/String;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m012_getTimeZone(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/DateCache;","getTimeZone",new String[]{ },"Ljava/util/TimeZone;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(135,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/util/DateCache;","_tzFormat","Ljava/text/SimpleDateFormat;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/text/SimpleDateFormat;","getTimeZone",new String[]{ },"Ljava/util/TimeZone;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m013_lastMs(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/DateCache;","lastMs",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(307,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,1,new Field("Lorg/mortbay/util/DateCache;","_lastMs","I"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m014_now(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/DateCache;","now",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(299,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(300,L1);
                ddv.visitStartLocal(0,L1,"now","J",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(301,L2);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Ljava/lang/System;","currentTimeMillis",new String[]{ },"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,0);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_WIDE_16,2,Long.valueOf(1000L)); // long: 0x00000000000003e8  double:0.000000
                code.visitStmt3R(REM_LONG,2,0,2);
                code.visitStmt2R(LONG_TO_INT,2,2);
                code.visitFieldStmt(IPUT,2,4,new Field("Lorg/mortbay/util/DateCache;","_lastMs","I"));
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,0,1},new Method("Lorg/mortbay/util/DateCache;","format",new String[]{ "J"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitStmt1R(RETURN_OBJECT,2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m015_setTimeZone(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/DateCache;","setTimeZone",new String[]{ "Ljava/util/TimeZone;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"tz");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(110,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(111,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(113,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(114,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(126,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(127,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(128,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(129,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(130,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(116,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(118,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(119,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(123,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(124,L14);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_WIDE_16,3,Long.valueOf(-1L)); // long: 0xffffffffffffffff  double:NaN
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 5,6},new Method("Lorg/mortbay/util/DateCache;","setTzFormatString",new String[]{ "Ljava/util/TimeZone;"},"V"));
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,0,5,new Field("Lorg/mortbay/util/DateCache;","_locale","Ljava/util/Locale;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L10);
                code.visitLabel(L3);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/text/SimpleDateFormat;");
                code.visitFieldStmt(IGET_OBJECT,1,5,new Field("Lorg/mortbay/util/DateCache;","_tzFormatString","Ljava/lang/String;"));
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/util/DateCache;","_locale","Ljava/util/Locale;"));
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1,2},new Method("Ljava/text/SimpleDateFormat;","<init>",new String[]{ "Ljava/lang/String;","Ljava/util/Locale;"},"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,5,new Field("Lorg/mortbay/util/DateCache;","_tzFormat","Ljava/text/SimpleDateFormat;"));
                code.visitLabel(L4);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/text/SimpleDateFormat;");
                code.visitFieldStmt(IGET_OBJECT,1,5,new Field("Lorg/mortbay/util/DateCache;","_minFormatString","Ljava/lang/String;"));
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/util/DateCache;","_locale","Ljava/util/Locale;"));
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1,2},new Method("Ljava/text/SimpleDateFormat;","<init>",new String[]{ "Ljava/lang/String;","Ljava/util/Locale;"},"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,5,new Field("Lorg/mortbay/util/DateCache;","_minFormat","Ljava/text/SimpleDateFormat;"));
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,0,5,new Field("Lorg/mortbay/util/DateCache;","_tzFormat","Ljava/text/SimpleDateFormat;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,6},new Method("Ljava/text/SimpleDateFormat;","setTimeZone",new String[]{ "Ljava/util/TimeZone;"},"V"));
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,0,5,new Field("Lorg/mortbay/util/DateCache;","_minFormat","Ljava/text/SimpleDateFormat;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,6},new Method("Ljava/text/SimpleDateFormat;","setTimeZone",new String[]{ "Ljava/util/TimeZone;"},"V"));
                code.visitLabel(L7);
                code.visitFieldStmt(IPUT_WIDE,3,5,new Field("Lorg/mortbay/util/DateCache;","_lastSeconds","J"));
                code.visitLabel(L8);
                code.visitFieldStmt(IPUT_WIDE,3,5,new Field("Lorg/mortbay/util/DateCache;","_lastMinutes","J"));
                code.visitLabel(L9);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L10);
                code.visitFieldStmt(IGET_OBJECT,0,5,new Field("Lorg/mortbay/util/DateCache;","_dfs","Ljava/text/DateFormatSymbols;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L13);
                code.visitLabel(L11);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/text/SimpleDateFormat;");
                code.visitFieldStmt(IGET_OBJECT,1,5,new Field("Lorg/mortbay/util/DateCache;","_tzFormatString","Ljava/lang/String;"));
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/util/DateCache;","_dfs","Ljava/text/DateFormatSymbols;"));
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1,2},new Method("Ljava/text/SimpleDateFormat;","<init>",new String[]{ "Ljava/lang/String;","Ljava/text/DateFormatSymbols;"},"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,5,new Field("Lorg/mortbay/util/DateCache;","_tzFormat","Ljava/text/SimpleDateFormat;"));
                code.visitLabel(L12);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/text/SimpleDateFormat;");
                code.visitFieldStmt(IGET_OBJECT,1,5,new Field("Lorg/mortbay/util/DateCache;","_minFormatString","Ljava/lang/String;"));
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/util/DateCache;","_dfs","Ljava/text/DateFormatSymbols;"));
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1,2},new Method("Ljava/text/SimpleDateFormat;","<init>",new String[]{ "Ljava/lang/String;","Ljava/text/DateFormatSymbols;"},"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,5,new Field("Lorg/mortbay/util/DateCache;","_minFormat","Ljava/text/SimpleDateFormat;"));
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitLabel(L13);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/text/SimpleDateFormat;");
                code.visitFieldStmt(IGET_OBJECT,1,5,new Field("Lorg/mortbay/util/DateCache;","_tzFormatString","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Ljava/text/SimpleDateFormat;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,5,new Field("Lorg/mortbay/util/DateCache;","_tzFormat","Ljava/text/SimpleDateFormat;"));
                code.visitLabel(L14);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/text/SimpleDateFormat;");
                code.visitFieldStmt(IGET_OBJECT,1,5,new Field("Lorg/mortbay/util/DateCache;","_minFormatString","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Ljava/text/SimpleDateFormat;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,5,new Field("Lorg/mortbay/util/DateCache;","_minFormat","Ljava/text/SimpleDateFormat;"));
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m016_setTimeZoneID(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/DateCache;","setTimeZoneID",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"timeZoneId");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(145,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(146,L1);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2},new Method("Ljava/util/TimeZone;","getTimeZone",new String[]{ "Ljava/lang/String;"},"Ljava/util/TimeZone;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,0},new Method("Lorg/mortbay/util/DateCache;","setTimeZone",new String[]{ "Ljava/util/TimeZone;"},"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
