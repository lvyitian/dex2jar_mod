package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0285_org_mortbay_jetty_security_HTAccessHandler {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/jetty/security/HTAccessHandler;","Lorg/mortbay/jetty/security/SecurityHandler;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("HTAccessHandler.java");
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/MemberClasses;", Visibility.SYSTEM);
            if(av00 != null) {
                {
                    DexAnnotationVisitor av01 = av00.visitArray("value");
                    if(av01 != null) {
                        av01.visit(null, new DexType("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;"));
                        av01.visit(null, new DexType("Lorg/mortbay/jetty/security/HTAccessHandler$DummyPrincipal;"));
                        av01.visitEnd();
                    }
                }
                av00.visitEnd();
            }
        }
        f000_log(cv);
        f001__accessFile(cv);
        f002__default(cv);
        f003__htCache(cv);
        f004_protegee(cv);
        m000__clinit_(cv);
        m001__init_(cv);
        m002_access$000(cv);
        m003_getPrincipal(cv);
        m004_getProtegee(cv);
        m005_handle(cv);
        m006_setAccessFile(cv);
        m007_setDefault(cv);
        m008_setProtegee(cv);
    }
    public static void f000_log(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC, new Field("Lorg/mortbay/jetty/security/HTAccessHandler;","log","Lorg/mortbay/log/Logger;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001__accessFile(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/jetty/security/HTAccessHandler;","_accessFile","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002__default(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/jetty/security/HTAccessHandler;","_default","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003__htCache(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_TRANSIENT, new Field("Lorg/mortbay/jetty/security/HTAccessHandler;","_htCache","Ljava/util/HashMap;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f004_protegee(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/security/HTAccessHandler;","protegee","Lorg/mortbay/jetty/Handler;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__clinit_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/security/HTAccessHandler;","<clinit>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(52,L0);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_CLASS,0,new DexType("Lorg/mortbay/jetty/security/HTAccessHandler;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/Class;","getName",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/log/Log;","getLogger",new String[]{ "Ljava/lang/String;"},"Lorg/mortbay/log/Logger;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/security/HTAccessHandler;","log","Lorg/mortbay/log/Logger;"));
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/security/HTAccessHandler;","<init>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(49,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(54,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(55,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(57,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(291,L4);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Lorg/mortbay/jetty/security/SecurityHandler;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/security/HTAccessHandler;","_default","Ljava/lang/String;"));
                code.visitLabel(L2);
                code.visitConstStmt(CONST_STRING,0,".htaccess");
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/security/HTAccessHandler;","_accessFile","Ljava/lang/String;"));
                code.visitLabel(L3);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/util/HashMap;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/util/HashMap;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/security/HTAccessHandler;","_htCache","Ljava/util/HashMap;"));
                code.visitLabel(L4);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_access$000(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_SYNTHETIC, new Method("Lorg/mortbay/jetty/security/HTAccessHandler;","access$000",new String[]{ },"Lorg/mortbay/log/Logger;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(49,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/security/HTAccessHandler;","log","Lorg/mortbay/log/Logger;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_getPrincipal(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/HTAccessHandler;","getPrincipal",new String[]{ "Ljava/lang/String;","Lorg/mortbay/jetty/security/UserRealm;"},"Ljava/security/Principal;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"user");
                ddv.visitParameterName(1,"realm");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(259,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(260,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(262,L2);
                code.visitLabel(L0);
                DexLabel L3=new DexLabel();
                code.visitJumpStmt(IF_NEZ,3,-1,L3);
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/jetty/security/HTAccessHandler$DummyPrincipal;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1,2},new Method("Lorg/mortbay/jetty/security/HTAccessHandler$DummyPrincipal;","<init>",new String[]{ "Lorg/mortbay/jetty/security/HTAccessHandler;","Ljava/lang/String;"},"V"));
                code.visitLabel(L2);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3,2},new Method("Lorg/mortbay/jetty/security/UserRealm;","getPrincipal",new String[]{ "Ljava/lang/String;"},"Ljava/security/Principal;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_getProtegee(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/security/HTAccessHandler;","getProtegee",new String[]{ },"Lorg/mortbay/jetty/Handler;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(862,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/security/HTAccessHandler;","protegee","Lorg/mortbay/jetty/Handler;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_handle(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/HTAccessHandler;","handle",new String[]{ "Ljava/lang/String;","Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;","I"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visit(null, new DexType("Ljavax/servlet/ServletException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(32);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/lang/Exception;"});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L2},new String[]{ "Ljava/lang/Exception;"});
                DexLabel L5=new DexLabel();
                DexLabel L6=new DexLabel();
                code.visitTryCatch(L4,L5,new DexLabel[]{L6},new String[]{ "Ljava/lang/Exception;"});
                DexLabel L7=new DexLabel();
                DexLabel L8=new DexLabel();
                code.visitTryCatch(L7,L8,new DexLabel[]{L2},new String[]{ "Ljava/lang/Exception;"});
                DexLabel L9=new DexLabel();
                DexLabel L10=new DexLabel();
                code.visitTryCatch(L9,L10,new DexLabel[]{L2},new String[]{ "Ljava/lang/Exception;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"target");
                ddv.visitParameterName(1,"request");
                ddv.visitParameterName(2,"response");
                ddv.visitParameterName(3,"dispatch");
                DexLabel L11=new DexLabel();
                ddv.visitPrologue(L11);
                ddv.visitLineNumber(95,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(96,L12);
                ddv.visitStartLocal(6,L12,"base_request","Lorg/mortbay/jetty/Request;",null);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(98,L13);
                ddv.visitStartLocal(7,L13,"base_response","Lorg/mortbay/jetty/Response;",null);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(100,L14);
                ddv.visitStartLocal(18,L14,"pathInContext","Ljava/lang/String;",null);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(101,L15);
                ddv.visitStartLocal(21,L15,"user","Ljava/lang/String;",null);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(102,L16);
                ddv.visitStartLocal(17,L16,"password","Ljava/lang/String;",null);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(104,L17);
                ddv.visitStartLocal(5,L17,"IPValid","Z",null);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(105,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(107,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(109,L20);
                ddv.visitStartLocal(8,L20,"credentials","Ljava/lang/String;",null);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(111,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(112,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(113,L23);
                ddv.visitRestartLocal(8,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(114,L24);
                ddv.visitStartLocal(15,L24,"i","I",null);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(115,L25);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(117,L26);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(118,L27);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(121,L28);
                ddv.visitEndLocal(15,L28);
                DexLabel L29=new DexLabel();
                ddv.visitLineNumber(125,L29);
                ddv.visitStartLocal(12,L29,"ht","Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;",null);
                ddv.visitLineNumber(126,L0);
                ddv.visitStartLocal(19,L0,"resource","Lorg/mortbay/resource/Resource;",null);
                DexLabel L30=new DexLabel();
                ddv.visitLineNumber(129,L30);
                ddv.visitEndLocal(8,L30);
                ddv.visitStartLocal(9,L30,"directory","Ljava/lang/String;",null);
                DexLabel L31=new DexLabel();
                ddv.visitLineNumber(131,L31);
                DexLabel L32=new DexLabel();
                ddv.visitLineNumber(132,L32);
                ddv.visitStartLocal(14,L32,"htPath","Ljava/lang/String;",null);
                DexLabel L33=new DexLabel();
                ddv.visitLineNumber(133,L33);
                DexLabel L34=new DexLabel();
                ddv.visitLineNumber(134,L34);
                DexLabel L35=new DexLabel();
                ddv.visitLineNumber(136,L35);
                DexLabel L36=new DexLabel();
                ddv.visitLineNumber(142,L36);
                ddv.visitEndLocal(14,L36);
                DexLabel L37=new DexLabel();
                ddv.visitLineNumber(145,L37);
                ddv.visitStartLocal(11,L37,"haveHtAccess","Z",null);
                DexLabel L38=new DexLabel();
                ddv.visitLineNumber(147,L38);
                DexLabel L39=new DexLabel();
                ddv.visitLineNumber(148,L39);
                ddv.visitRestartLocal(19,L39);
                DexLabel L40=new DexLabel();
                ddv.visitLineNumber(149,L40);
                DexLabel L41=new DexLabel();
                ddv.visitLineNumber(151,L41);
                DexLabel L42=new DexLabel();
                ddv.visitLineNumber(152,L42);
                DexLabel L43=new DexLabel();
                ddv.visitLineNumber(155,L43);
                DexLabel L44=new DexLabel();
                ddv.visitLineNumber(159,L44);
                DexLabel L45=new DexLabel();
                ddv.visitLineNumber(160,L45);
                ddv.visitLineNumber(247,L1);
                ddv.visitEndLocal(9,L1);
                ddv.visitEndLocal(11,L1);
                DexLabel L46=new DexLabel();
                ddv.visitLineNumber(95,L46);
                ddv.visitEndLocal(6,L46);
                ddv.visitEndLocal(7,L46);
                ddv.visitEndLocal(18,L46);
                ddv.visitEndLocal(5,L46);
                ddv.visitEndLocal(21,L46);
                ddv.visitEndLocal(17,L46);
                ddv.visitEndLocal(12,L46);
                ddv.visitEndLocal(19,L46);
                DexLabel L47=new DexLabel();
                ddv.visitLineNumber(96,L47);
                ddv.visitRestartLocal(6,L47);
                ddv.visitLineNumber(126,L3);
                ddv.visitRestartLocal(5,L3);
                ddv.visitRestartLocal(7,L3);
                ddv.visitRestartLocal(8,L3);
                ddv.visitRestartLocal(12,L3);
                ddv.visitRestartLocal(17,L3);
                ddv.visitRestartLocal(18,L3);
                ddv.visitRestartLocal(19,L3);
                ddv.visitRestartLocal(21,L3);
                DexLabel L48=new DexLabel();
                ddv.visitLineNumber(138,L48);
                ddv.visitEndLocal(8,L48);
                ddv.visitRestartLocal(9,L48);
                ddv.visitRestartLocal(14,L48);
                DexLabel L49=new DexLabel();
                ddv.visitLineNumber(139,L49);
                DexLabel L50=new DexLabel();
                ddv.visitLineNumber(140,L50);
                ddv.visitRestartLocal(9,L50);
                DexLabel L51=new DexLabel();
                ddv.visitLineNumber(164,L51);
                ddv.visitEndLocal(14,L51);
                ddv.visitRestartLocal(11,L51);
                DexLabel L52=new DexLabel();
                ddv.visitLineNumber(166,L52);
                DexLabel L53=new DexLabel();
                ddv.visitLineNumber(167,L53);
                DexLabel L54=new DexLabel();
                ddv.visitLineNumber(169,L54);
                DexLabel L55=new DexLabel();
                ddv.visitLineNumber(170,L55);
                ddv.visitRestartLocal(12,L55);
                DexLabel L56=new DexLabel();
                ddv.visitLineNumber(172,L56);
                ddv.visitLineNumber(173,L4);
                ddv.visitStartLocal(13,L4,"ht","Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;",null);
                DexLabel L57=new DexLabel();
                ddv.visitEndLocal(12,L57);
                DexLabel L58=new DexLabel();
                ddv.visitLineNumber(174,L58);
                DexLabel L59=new DexLabel();
                ddv.visitLineNumber(175,L59);
                ddv.visitLineNumber(179,L7);
                ddv.visitEndLocal(13,L7);
                ddv.visitRestartLocal(12,L7);
                DexLabel L60=new DexLabel();
                ddv.visitLineNumber(181,L60);
                DexLabel L61=new DexLabel();
                ddv.visitLineNumber(182,L61);
                DexLabel L62=new DexLabel();
                ddv.visitLineNumber(183,L62);
                ddv.visitLineNumber(238,L2);
                ddv.visitEndLocal(9,L2);
                ddv.visitEndLocal(11,L2);
                DexLabel L63=new DexLabel();
                ddv.visitLineNumber(240,L63);
                ddv.visitStartLocal(10,L63,"ex","Ljava/lang/Exception;",null);
                DexLabel L64=new DexLabel();
                ddv.visitLineNumber(241,L64);
                DexLabel L65=new DexLabel();
                ddv.visitLineNumber(243,L65);
                DexLabel L66=new DexLabel();
                ddv.visitLineNumber(244,L66);
                ddv.visitLineNumber(188,L9);
                ddv.visitEndLocal(10,L9);
                ddv.visitRestartLocal(9,L9);
                ddv.visitRestartLocal(11,L9);
                DexLabel L67=new DexLabel();
                ddv.visitLineNumber(189,L67);
                ddv.visitStartLocal(16,L67,"methods","Ljava/util/Map;",null);
                DexLabel L68=new DexLabel();
                ddv.visitLineNumber(193,L68);
                DexLabel L69=new DexLabel();
                ddv.visitLineNumber(196,L69);
                ddv.visitStartLocal(20,L69,"satisfy","I",null);
                DexLabel L70=new DexLabel();
                ddv.visitLineNumber(197,L70);
                ddv.visitRestartLocal(5,L70);
                DexLabel L71=new DexLabel();
                ddv.visitLineNumber(198,L71);
                DexLabel L72=new DexLabel();
                ddv.visitLineNumber(201,L72);
                DexLabel L73=new DexLabel();
                ddv.visitLineNumber(206,L73);
                DexLabel L74=new DexLabel();
                ddv.visitLineNumber(208,L74);
                DexLabel L75=new DexLabel();
                ddv.visitLineNumber(209,L75);
                DexLabel L76=new DexLabel();
                ddv.visitLineNumber(214,L76);
                DexLabel L77=new DexLabel();
                ddv.visitLineNumber(216,L77);
                DexLabel L78=new DexLabel();
                ddv.visitLineNumber(217,L78);
                DexLabel L79=new DexLabel();
                ddv.visitLineNumber(218,L79);
                DexLabel L80=new DexLabel();
                ddv.visitLineNumber(219,L80);
                DexLabel L81=new DexLabel();
                ddv.visitLineNumber(220,L81);
                DexLabel L82=new DexLabel();
                ddv.visitLineNumber(225,L82);
                DexLabel L83=new DexLabel();
                ddv.visitLineNumber(227,L83);
                DexLabel L84=new DexLabel();
                ddv.visitLineNumber(228,L84);
                DexLabel L85=new DexLabel();
                ddv.visitLineNumber(232,L85);
                ddv.visitEndLocal(16,L85);
                ddv.visitEndLocal(20,L85);
                DexLabel L86=new DexLabel();
                ddv.visitLineNumber(234,L86);
                ddv.visitLineNumber(238,L6);
                ddv.visitEndLocal(12,L6);
                ddv.visitRestartLocal(13,L6);
                DexLabel L87=new DexLabel();
                ddv.visitRestartLocal(12,L87);
                code.visitLabel(L11);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,29);
                code.visitTypeStmt(INSTANCE_OF,0,0,"Lorg/mortbay/jetty/Request;");
                code.visitStmt2R(MOVE_FROM16,22,0);
                code.visitJumpStmt(IF_EQZ,22,-1,L46);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,29);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Lorg/mortbay/jetty/Request;");
                code.visitStmt2R(MOVE_OBJECT,5,0);
                code.visitStmt2R(MOVE_OBJECT,6,5);
                code.visitLabel(L12);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,30);
                code.visitTypeStmt(INSTANCE_OF,0,0,"Lorg/mortbay/jetty/Response;");
                code.visitStmt2R(MOVE_FROM16,22,0);
                code.visitJumpStmt(IF_EQZ,22,-1,L47);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,30);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Lorg/mortbay/jetty/Response;");
                code.visitStmt2R(MOVE_OBJECT,5,0);
                code.visitStmt2R(MOVE_OBJECT,7,5);
                code.visitLabel(L13);
                code.visitStmt2R(MOVE_OBJECT_FROM16,18,28);
                code.visitLabel(L14);
                code.visitConstStmt(CONST_16,21, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L15);
                code.visitConstStmt(CONST_16,17, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L16);
                code.visitConstStmt(CONST_4,5, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L17);
                code.visitFieldStmt(SGET_OBJECT,22,-1,new Field("Lorg/mortbay/jetty/security/HTAccessHandler;","log","Lorg/mortbay/log/Logger;"));
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 22},new Method("Lorg/mortbay/log/Logger;","isDebugEnabled",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,22);
                code.visitJumpStmt(IF_EQZ,22,-1,L19);
                code.visitLabel(L18);
                code.visitFieldStmt(SGET_OBJECT,22,-1,new Field("Lorg/mortbay/jetty/security/HTAccessHandler;","log","Lorg/mortbay/log/Logger;"));
                code.visitTypeStmt(NEW_INSTANCE,23,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT_RANGE,new int[]{ 23},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,24,"HTAccessHandler pathInContext=");
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 23,24},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,23);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,23);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,18);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,23);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 23},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,23);
                code.visitConstStmt(CONST_16,24, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitConstStmt(CONST_16,25, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 22,23,24,25},new Method("Lorg/mortbay/log/Logger;","debug",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L19);
                code.visitConstStmt(CONST_STRING,22,"Authorization");
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,29);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,22);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1},new Method("Ljavax/servlet/http/HttpServletRequest;","getHeader",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitLabel(L20);
                code.visitJumpStmt(IF_EQZ,8,-1,L28);
                code.visitLabel(L21);
                code.visitConstStmt(CONST_16,22, Integer.valueOf(32)); // int: 0x00000020  float:0.000000
                code.visitStmt2R(MOVE_OBJECT,0,8);
                code.visitStmt2R(MOVE_FROM16,1,22);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/String;","indexOf",new String[]{ "I"},"I"));
                code.visitStmt1R(MOVE_RESULT,22);
                code.visitStmt2R1N(ADD_INT_LIT8,22,22,1);
                code.visitStmt2R(MOVE_OBJECT,0,8);
                code.visitStmt2R(MOVE_FROM16,1,22);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/String;","substring",new String[]{ "I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitLabel(L22);
                code.visitFieldStmt(SGET_OBJECT,22,-1,new Field("Lorg/mortbay/util/StringUtil;","__ISO_8859_1","Ljava/lang/String;"));
                code.visitStmt2R(MOVE_OBJECT,0,8);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,22);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/security/B64Code;","decode",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitLabel(L23);
                code.visitConstStmt(CONST_16,22, Integer.valueOf(58)); // int: 0x0000003a  float:0.000000
                code.visitStmt2R(MOVE_OBJECT,0,8);
                code.visitStmt2R(MOVE_FROM16,1,22);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/String;","indexOf",new String[]{ "I"},"I"));
                code.visitStmt1R(MOVE_RESULT,15);
                code.visitLabel(L24);
                code.visitConstStmt(CONST_16,22, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt2R(MOVE_OBJECT,0,8);
                code.visitStmt2R(MOVE_FROM16,1,22);
                code.visitStmt2R(MOVE,2,15);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Ljava/lang/String;","substring",new String[]{ "I","I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,21);
                code.visitLabel(L25);
                code.visitStmt2R1N(ADD_INT_LIT8,22,15,1);
                code.visitStmt2R(MOVE_OBJECT,0,8);
                code.visitStmt2R(MOVE_FROM16,1,22);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/String;","substring",new String[]{ "I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,17);
                code.visitLabel(L26);
                code.visitFieldStmt(SGET_OBJECT,22,-1,new Field("Lorg/mortbay/jetty/security/HTAccessHandler;","log","Lorg/mortbay/log/Logger;"));
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 22},new Method("Lorg/mortbay/log/Logger;","isDebugEnabled",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,22);
                code.visitJumpStmt(IF_EQZ,22,-1,L28);
                code.visitLabel(L27);
                code.visitFieldStmt(SGET_OBJECT,22,-1,new Field("Lorg/mortbay/jetty/security/HTAccessHandler;","log","Lorg/mortbay/log/Logger;"));
                code.visitTypeStmt(NEW_INSTANCE,23,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT_RANGE,new int[]{ 23},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,24,"User=");
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 23,24},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,23);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,23);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,21);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,23);
                code.visitConstStmt(CONST_STRING,24,", password=");
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 23,24},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,23);
                code.visitConstStmt(CONST_STRING,24,"******************************");
                code.visitConstStmt(CONST_16,25, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 17},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,26);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 24,25,26},new Method("Ljava/lang/String;","substring",new String[]{ "I","I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,24);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 23,24},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,23);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 23},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,23);
                code.visitConstStmt(CONST_16,24, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitConstStmt(CONST_16,25, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 22,23,24,25},new Method("Lorg/mortbay/log/Logger;","debug",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L28);
                code.visitConstStmt(CONST_4,12, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L29);
                code.visitConstStmt(CONST_16,19, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L0);
                code.visitConstStmt(CONST_STRING,22,"/");
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,18);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,22);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/String;","endsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,22);
                code.visitJumpStmt(IF_EQZ,22,-1,L3);
                code.visitStmt2R(MOVE_OBJECT_FROM16,9,18);
                code.visitLabel(L30);
                code.visitJumpStmt(IF_EQZ,9,-1,L36);
                code.visitLabel(L31);
                code.visitTypeStmt(NEW_INSTANCE,22,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT_RANGE,new int[]{ 22},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,22);
                code.visitStmt2R(MOVE_OBJECT,1,9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/security/HTAccessHandler;","_accessFile","Ljava/lang/String;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,23,0);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 22,23},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,22);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 22},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,14);
                code.visitLabel(L32);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 27},new Method("Lorg/mortbay/jetty/security/HTAccessHandler;","getProtegee",new String[]{ },"Lorg/mortbay/jetty/Handler;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitTypeStmt(CHECK_CAST,8,-1,"Lorg/mortbay/jetty/handler/ContextHandler;");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,14},new Method("Lorg/mortbay/jetty/handler/ContextHandler;","getResource",new String[]{ "Ljava/lang/String;"},"Lorg/mortbay/resource/Resource;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,19);
                code.visitLabel(L33);
                code.visitFieldStmt(SGET_OBJECT,22,-1,new Field("Lorg/mortbay/jetty/security/HTAccessHandler;","log","Lorg/mortbay/log/Logger;"));
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 22},new Method("Lorg/mortbay/log/Logger;","isDebugEnabled",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,22);
                code.visitJumpStmt(IF_EQZ,22,-1,L35);
                code.visitLabel(L34);
                code.visitFieldStmt(SGET_OBJECT,22,-1,new Field("Lorg/mortbay/jetty/security/HTAccessHandler;","log","Lorg/mortbay/log/Logger;"));
                code.visitTypeStmt(NEW_INSTANCE,23,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT_RANGE,new int[]{ 23},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,24,"directory=");
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 23,24},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,23);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,23);
                code.visitStmt2R(MOVE_OBJECT,1,9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,23);
                code.visitConstStmt(CONST_STRING,24," resource=");
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 23,24},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,23);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,23);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,19);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,23);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 23},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,23);
                code.visitConstStmt(CONST_16,24, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitConstStmt(CONST_16,25, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 22,23,24,25},new Method("Lorg/mortbay/log/Logger;","debug",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L35);
                code.visitJumpStmt(IF_EQZ,19,-1,L48);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 19},new Method("Lorg/mortbay/resource/Resource;","exists",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,22);
                code.visitJumpStmt(IF_EQZ,22,-1,L48);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 19},new Method("Lorg/mortbay/resource/Resource;","isDirectory",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,22);
                code.visitJumpStmt(IF_NEZ,22,-1,L48);
                code.visitLabel(L36);
                code.visitConstStmt(CONST_4,11, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L37);
                code.visitJumpStmt(IF_NEZ,19,-1,L41);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/security/HTAccessHandler;","_default","Ljava/lang/String;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,0);
                code.visitJumpStmt(IF_EQZ,22,-1,L41);
                code.visitLabel(L38);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/security/HTAccessHandler;","_default","Ljava/lang/String;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,0);
                code.visitMethodStmt(INVOKE_STATIC_RANGE,new int[]{ 22},new Method("Lorg/mortbay/resource/Resource;","newResource",new String[]{ "Ljava/lang/String;"},"Lorg/mortbay/resource/Resource;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,19);
                code.visitLabel(L39);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 19},new Method("Lorg/mortbay/resource/Resource;","exists",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,22);
                code.visitJumpStmt(IF_EQZ,22,-1,L40);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 19},new Method("Lorg/mortbay/resource/Resource;","isDirectory",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,22);
                code.visitJumpStmt(IF_EQZ,22,-1,L41);
                code.visitLabel(L40);
                code.visitConstStmt(CONST_4,11, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L41);
                code.visitJumpStmt(IF_NEZ,19,-1,L43);
                code.visitLabel(L42);
                code.visitConstStmt(CONST_4,11, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L43);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/security/HTAccessHandler;","_accessFile","Ljava/lang/String;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,18);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,22);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/String;","endsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,22);
                code.visitJumpStmt(IF_NEZ,22,-1,L44);
                code.visitTypeStmt(NEW_INSTANCE,22,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT_RANGE,new int[]{ 22},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/security/HTAccessHandler;","_accessFile","Ljava/lang/String;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,23,0);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 22,23},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,22);
                code.visitConstStmt(CONST_STRING,23,"~");
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 22,23},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,22);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 22},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,18);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,22);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/String;","endsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,22);
                code.visitJumpStmt(IF_NEZ,22,-1,L44);
                code.visitTypeStmt(NEW_INSTANCE,22,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT_RANGE,new int[]{ 22},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/security/HTAccessHandler;","_accessFile","Ljava/lang/String;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,23,0);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 22,23},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,22);
                code.visitConstStmt(CONST_STRING,23,".bak");
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 22,23},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,22);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 22},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,18);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,22);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/String;","endsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,22);
                code.visitJumpStmt(IF_EQZ,22,-1,L51);
                code.visitLabel(L44);
                code.visitConstStmt(CONST_16,22, Integer.valueOf(403)); // int: 0x00000193  float:0.000000
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,30);
                code.visitStmt2R(MOVE_FROM16,1,22);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1},new Method("Ljavax/servlet/http/HttpServletResponse;","sendError",new String[]{ "I"},"V"));
                code.visitLabel(L45);
                code.visitConstStmt(CONST_16,22, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt2R(MOVE_OBJECT,0,6);
                code.visitStmt2R(MOVE_FROM16,1,22);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/Request;","setHandled",new String[]{ "Z"},"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L46);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/jetty/HttpConnection;","getCurrentConnection",new String[]{ },"Lorg/mortbay/jetty/HttpConnection;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,22);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 22},new Method("Lorg/mortbay/jetty/HttpConnection;","getRequest",new String[]{ },"Lorg/mortbay/jetty/Request;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,6,22);
                code.visitJumpStmt(GOTO_16,-1,-1,L12);
                code.visitLabel(L47);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/jetty/HttpConnection;","getCurrentConnection",new String[]{ },"Lorg/mortbay/jetty/HttpConnection;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,22);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 22},new Method("Lorg/mortbay/jetty/HttpConnection;","getResponse",new String[]{ },"Lorg/mortbay/jetty/Response;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,7,22);
                code.visitJumpStmt(GOTO_16,-1,-1,L13);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_STATIC_RANGE,new int[]{ 18},new Method("Lorg/mortbay/util/URIUtil;","parentPath",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,9,22);
                code.visitJumpStmt(GOTO_16,-1,-1,L30);
                code.visitLabel(L48);
                code.visitConstStmt(CONST_16,19, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L49);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 9},new Method("Lorg/mortbay/util/URIUtil;","parentPath",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitLabel(L50);
                code.visitJumpStmt(GOTO_16,-1,-1,L30);
                code.visitLabel(L51);
                code.visitJumpStmt(IF_EQZ,11,-1,L85);
                code.visitLabel(L52);
                code.visitFieldStmt(SGET_OBJECT,22,-1,new Field("Lorg/mortbay/jetty/security/HTAccessHandler;","log","Lorg/mortbay/log/Logger;"));
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 22},new Method("Lorg/mortbay/log/Logger;","isDebugEnabled",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,22);
                code.visitJumpStmt(IF_EQZ,22,-1,L54);
                code.visitLabel(L53);
                code.visitFieldStmt(SGET_OBJECT,22,-1,new Field("Lorg/mortbay/jetty/security/HTAccessHandler;","log","Lorg/mortbay/log/Logger;"));
                code.visitTypeStmt(NEW_INSTANCE,23,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT_RANGE,new int[]{ 23},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,24,"HTACCESS=");
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 23,24},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,23);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,23);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,19);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,23);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 23},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,23);
                code.visitConstStmt(CONST_16,24, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitConstStmt(CONST_16,25, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 22,23,24,25},new Method("Lorg/mortbay/log/Logger;","debug",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L54);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/security/HTAccessHandler;","_htCache","Ljava/util/HashMap;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,19);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/util/HashMap;","get",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,13);
                code.visitStmt2R(MOVE_OBJECT,0,13);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;");
                code.visitStmt2R(MOVE_OBJECT,12,0);
                code.visitLabel(L55);
                code.visitJumpStmt(IF_EQZ,12,-1,L56);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12},new Method("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","getLastModified",new String[]{ },"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,22);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 19},new Method("Lorg/mortbay/resource/Resource;","lastModified",new String[]{ },"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,24);
                code.visitStmt3R(CMP_LONG,22,22,24);
                code.visitJumpStmt(IF_EQZ,22,-1,L7);
                code.visitLabel(L56);
                code.visitTypeStmt(NEW_INSTANCE,13,-1,"Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;");
                code.visitStmt2R(MOVE_OBJECT,0,13);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,19);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","<init>",new String[]{ "Lorg/mortbay/resource/Resource;"},"V"));
                code.visitLabel(L4);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/security/HTAccessHandler;","_htCache","Ljava/util/HashMap;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,0);
                code.visitLabel(L57);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,19);
                code.visitStmt2R(MOVE_OBJECT,2,13);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Ljava/util/HashMap;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L58);
                code.visitFieldStmt(SGET_OBJECT,22,-1,new Field("Lorg/mortbay/jetty/security/HTAccessHandler;","log","Lorg/mortbay/log/Logger;"));
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 22},new Method("Lorg/mortbay/log/Logger;","isDebugEnabled",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,22);
                code.visitJumpStmt(IF_EQZ,22,-1,L5);
                code.visitLabel(L59);
                code.visitFieldStmt(SGET_OBJECT,22,-1,new Field("Lorg/mortbay/jetty/security/HTAccessHandler;","log","Lorg/mortbay/log/Logger;"));
                code.visitTypeStmt(NEW_INSTANCE,23,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT_RANGE,new int[]{ 23},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,24,"HTCache loaded ");
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 23,24},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,23);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,23);
                code.visitStmt2R(MOVE_OBJECT,1,13);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,23);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 23},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,23);
                code.visitConstStmt(CONST_16,24, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitConstStmt(CONST_16,25, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 22,23,24,25},new Method("Lorg/mortbay/log/Logger;","debug",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L5);
                code.visitStmt2R(MOVE_OBJECT,12,13);
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12},new Method("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","isForbidden",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,22);
                code.visitJumpStmt(IF_EQZ,22,-1,L9);
                code.visitLabel(L60);
                code.visitFieldStmt(SGET_OBJECT,22,-1,new Field("Lorg/mortbay/jetty/security/HTAccessHandler;","log","Lorg/mortbay/log/Logger;"));
                code.visitTypeStmt(NEW_INSTANCE,23,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT_RANGE,new int[]{ 23},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,24,"Mis-configured htaccess: ");
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 23,24},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,23);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,23);
                code.visitStmt2R(MOVE_OBJECT,1,12);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,23);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 23},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,23);
                code.visitConstStmt(CONST_16,24, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitConstStmt(CONST_16,25, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 22,23,24,25},new Method("Lorg/mortbay/log/Logger;","warn",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L61);
                code.visitConstStmt(CONST_16,22, Integer.valueOf(403)); // int: 0x00000193  float:0.000000
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,30);
                code.visitStmt2R(MOVE_FROM16,1,22);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1},new Method("Ljavax/servlet/http/HttpServletResponse;","sendError",new String[]{ "I"},"V"));
                code.visitLabel(L62);
                code.visitConstStmt(CONST_16,22, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt2R(MOVE_OBJECT,0,6);
                code.visitStmt2R(MOVE_FROM16,1,22);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/Request;","setHandled",new String[]{ "Z"},"V"));
                code.visitLabel(L8);
                code.visitJumpStmt(GOTO_16,-1,-1,L1);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,10,22);
                code.visitLabel(L63);
                code.visitFieldStmt(SGET_OBJECT,22,-1,new Field("Lorg/mortbay/jetty/security/HTAccessHandler;","log","Lorg/mortbay/log/Logger;"));
                code.visitConstStmt(CONST_STRING,23,"Exception");
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,23);
                code.visitStmt2R(MOVE_OBJECT,2,10);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1,2},new Method("Lorg/mortbay/log/Logger;","warn",new String[]{ "Ljava/lang/String;","Ljava/lang/Throwable;"},"V"));
                code.visitLabel(L64);
                code.visitJumpStmt(IF_EQZ,12,-1,L1);
                code.visitLabel(L65);
                code.visitConstStmt(CONST_16,22, Integer.valueOf(500)); // int: 0x000001f4  float:0.000000
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,30);
                code.visitStmt2R(MOVE_FROM16,1,22);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1},new Method("Ljavax/servlet/http/HttpServletResponse;","sendError",new String[]{ "I"},"V"));
                code.visitLabel(L66);
                code.visitConstStmt(CONST_16,22, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt2R(MOVE_OBJECT,0,6);
                code.visitStmt2R(MOVE_FROM16,1,22);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/Request;","setHandled",new String[]{ "Z"},"V"));
                code.visitJumpStmt(GOTO_16,-1,-1,L1);
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12},new Method("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","getMethods",new String[]{ },"Ljava/util/HashMap;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,16);
                code.visitLabel(L67);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 16},new Method("Ljava/util/Map;","size",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,22);
                code.visitJumpStmt(IF_LEZ,22,-1,L68);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 29},new Method("Ljavax/servlet/http/HttpServletRequest;","getMethod",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,16);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,22);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1},new Method("Ljava/util/Map;","containsKey",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,22);
                code.visitJumpStmt(IF_EQZ,22,-1,L1);
                code.visitLabel(L68);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12},new Method("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","getSatisfy",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,20);
                code.visitLabel(L69);
                code.visitConstStmt(CONST_STRING,22,"");
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 29},new Method("Ljavax/servlet/http/HttpServletRequest;","getRemoteAddr",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,23);
                code.visitStmt2R(MOVE_OBJECT,0,12);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,2,23);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","checkAccess",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitLabel(L70);
                code.visitFieldStmt(SGET_OBJECT,22,-1,new Field("Lorg/mortbay/jetty/security/HTAccessHandler;","log","Lorg/mortbay/log/Logger;"));
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 22},new Method("Lorg/mortbay/log/Logger;","isDebugEnabled",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,22);
                code.visitJumpStmt(IF_EQZ,22,-1,L72);
                code.visitLabel(L71);
                code.visitFieldStmt(SGET_OBJECT,22,-1,new Field("Lorg/mortbay/jetty/security/HTAccessHandler;","log","Lorg/mortbay/log/Logger;"));
                code.visitTypeStmt(NEW_INSTANCE,23,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT_RANGE,new int[]{ 23},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,24,"IPValid = ");
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 23,24},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,23);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,23);
                code.visitStmt2R(MOVE,1,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Z"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,23);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 23},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,23);
                code.visitConstStmt(CONST_16,24, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitConstStmt(CONST_16,25, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 22,23,24,25},new Method("Lorg/mortbay/log/Logger;","debug",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L72);
                code.visitConstStmt(CONST_16,22, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt2R(MOVE,0,5);
                code.visitStmt2R(MOVE_FROM16,1,22);
                code.visitJumpStmt(IF_NE,0,1,L73);
                code.visitJumpStmt(IF_EQZ,20,-1,L1);
                code.visitLabel(L73);
                code.visitJumpStmt(IF_NEZ,5,-1,L76);
                code.visitConstStmt(CONST_16,22, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt2R(MOVE_FROM16,0,20);
                code.visitStmt2R(MOVE_FROM16,1,22);
                code.visitJumpStmt(IF_NE,0,1,L76);
                code.visitLabel(L74);
                code.visitConstStmt(CONST_16,22, Integer.valueOf(403)); // int: 0x00000193  float:0.000000
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,30);
                code.visitStmt2R(MOVE_FROM16,1,22);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1},new Method("Ljavax/servlet/http/HttpServletResponse;","sendError",new String[]{ "I"},"V"));
                code.visitLabel(L75);
                code.visitConstStmt(CONST_16,22, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt2R(MOVE_OBJECT,0,6);
                code.visitStmt2R(MOVE_FROM16,1,22);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/Request;","setHandled",new String[]{ "Z"},"V"));
                code.visitJumpStmt(GOTO_16,-1,-1,L1);
                code.visitLabel(L76);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 27},new Method("Lorg/mortbay/jetty/security/HTAccessHandler;","getUserRealm",new String[]{ },"Lorg/mortbay/jetty/security/UserRealm;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,22);
                code.visitStmt2R(MOVE_OBJECT,0,12);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,21);
                code.visitStmt2R(MOVE_OBJECT_FROM16,2,17);
                code.visitStmt2R(MOVE_OBJECT_FROM16,3,22);
                code.visitStmt2R(MOVE_OBJECT,4,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2,3,4},new Method("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","checkAuth",new String[]{ "Ljava/lang/String;","Ljava/lang/String;","Lorg/mortbay/jetty/security/UserRealm;","Lorg/mortbay/jetty/Request;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,22);
                code.visitJumpStmt(IF_NEZ,22,-1,L82);
                code.visitLabel(L77);
                code.visitFieldStmt(SGET_OBJECT,22,-1,new Field("Lorg/mortbay/jetty/security/HTAccessHandler;","log","Lorg/mortbay/log/Logger;"));
                code.visitConstStmt(CONST_STRING,23,"Auth Failed");
                code.visitConstStmt(CONST_16,24, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitConstStmt(CONST_16,25, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 22,23,24,25},new Method("Lorg/mortbay/log/Logger;","debug",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L78);
                code.visitConstStmt(CONST_STRING,22,"WWW-Authenticate");
                code.visitTypeStmt(NEW_INSTANCE,23,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT_RANGE,new int[]{ 23},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,24,"basic realm=");
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 23,24},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,23);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12},new Method("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","getName",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,24);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 23,24},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,23);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 23},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,23);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,30);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,2,23);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1,2},new Method("Ljavax/servlet/http/HttpServletResponse;","setHeader",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"V"));
                code.visitLabel(L79);
                code.visitConstStmt(CONST_16,22, Integer.valueOf(401)); // int: 0x00000191  float:0.000000
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,30);
                code.visitStmt2R(MOVE_FROM16,1,22);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1},new Method("Ljavax/servlet/http/HttpServletResponse;","sendError",new String[]{ "I"},"V"));
                code.visitLabel(L80);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Lorg/mortbay/jetty/Response;","complete",new String[]{ },"V"));
                code.visitLabel(L81);
                code.visitConstStmt(CONST_16,22, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt2R(MOVE_OBJECT,0,6);
                code.visitStmt2R(MOVE_FROM16,1,22);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/Request;","setHandled",new String[]{ "Z"},"V"));
                code.visitJumpStmt(GOTO_16,-1,-1,L1);
                code.visitLabel(L82);
                code.visitJumpStmt(IF_EQZ,21,-1,L85);
                code.visitLabel(L83);
                code.visitConstStmt(CONST_STRING,22,"BASIC");
                code.visitStmt2R(MOVE_OBJECT,0,6);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,22);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/Request;","setAuthType",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L84);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 27},new Method("Lorg/mortbay/jetty/security/HTAccessHandler;","getUserRealm",new String[]{ },"Lorg/mortbay/jetty/security/UserRealm;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,21);
                code.visitStmt2R(MOVE_OBJECT_FROM16,2,22);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Lorg/mortbay/jetty/security/HTAccessHandler;","getPrincipal",new String[]{ "Ljava/lang/String;","Lorg/mortbay/jetty/security/UserRealm;"},"Ljava/security/Principal;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,22);
                code.visitStmt2R(MOVE_OBJECT,0,6);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,22);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/Request;","setUserPrincipal",new String[]{ "Ljava/security/Principal;"},"V"));
                code.visitLabel(L85);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 27},new Method("Lorg/mortbay/jetty/security/HTAccessHandler;","getHandler",new String[]{ },"Lorg/mortbay/jetty/Handler;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,22);
                code.visitJumpStmt(IF_EQZ,22,-1,L1);
                code.visitLabel(L86);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 27},new Method("Lorg/mortbay/jetty/security/HTAccessHandler;","getHandler",new String[]{ },"Lorg/mortbay/jetty/Handler;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,28);
                code.visitStmt2R(MOVE_OBJECT_FROM16,2,29);
                code.visitStmt2R(MOVE_OBJECT_FROM16,3,30);
                code.visitStmt2R(MOVE_FROM16,4,31);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1,2,3,4},new Method("Lorg/mortbay/jetty/Handler;","handle",new String[]{ "Ljava/lang/String;","Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;","I"},"V"));
                code.visitLabel(L10);
                code.visitJumpStmt(GOTO_16,-1,-1,L1);
                code.visitLabel(L6);
                code.visitStmt1R(MOVE_EXCEPTION,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,10,22);
                code.visitStmt2R(MOVE_OBJECT,12,13);
                code.visitLabel(L87);
                code.visitJumpStmt(GOTO_16,-1,-1,L63);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_setAccessFile(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/HTAccessHandler;","setAccessFile",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"anArg");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(282,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(283,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(286,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(285,L3);
                code.visitLabel(L0);
                code.visitJumpStmt(IF_NEZ,2,-1,L3);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_STRING,0,".htaccess");
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/security/HTAccessHandler;","_accessFile","Ljava/lang/String;"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L3);
                code.visitFieldStmt(IPUT_OBJECT,2,1,new Field("Lorg/mortbay/jetty/security/HTAccessHandler;","_accessFile","Ljava/lang/String;"));
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m007_setDefault(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/HTAccessHandler;","setDefault",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"dir");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(276,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(277,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/security/HTAccessHandler;","_default","Ljava/lang/String;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m008_setProtegee(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/HTAccessHandler;","setProtegee",new String[]{ "Lorg/mortbay/jetty/Handler;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"protegee");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(873,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(874,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/security/HTAccessHandler;","protegee","Lorg/mortbay/jetty/Handler;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
