package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0185_org_mortbay_jetty_ResourceCache_Content {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/jetty/ResourceCache$Content;","Ljava/lang/Object;",new String[]{ "Lorg/mortbay/jetty/HttpContent;"});
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("ResourceCache.java");
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/EnclosingClass;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("value", new DexType("Lorg/mortbay/jetty/ResourceCache;"));
                av00.visitEnd();
            }
        }
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/InnerClass;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("accessFlags",  Integer.valueOf(1));
                av00.visit("name", "Content");
                av00.visitEnd();
            }
        }
        f000__buffer(cv);
        f001__contentType(cv);
        f002__key(cv);
        f003__lastModified(cv);
        f004__lastModifiedBytes(cv);
        f005__next(cv);
        f006__prev(cv);
        f007__resource(cv);
        f008_this$0(cv);
        m000__init_(cv);
        m001_cache(cv);
        m002_getBuffer(cv);
        m003_getContentLength(cv);
        m004_getContentType(cv);
        m005_getInputStream(cv);
        m006_getKey(cv);
        m007_getLastModified(cv);
        m008_getResource(cv);
        m009_invalidate(cv);
        m010_isCached(cv);
        m011_isValid(cv);
        m012_release(cv);
        m013_setBuffer(cv);
        m014_setContentType(cv);
    }
    public static void f000__buffer(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/jetty/ResourceCache$Content;","_buffer","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001__contentType(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/jetty/ResourceCache$Content;","_contentType","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002__key(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/jetty/ResourceCache$Content;","_key","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003__lastModified(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/jetty/ResourceCache$Content;","_lastModified","J"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f004__lastModifiedBytes(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/jetty/ResourceCache$Content;","_lastModifiedBytes","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f005__next(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/jetty/ResourceCache$Content;","_next","Lorg/mortbay/jetty/ResourceCache$Content;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f006__prev(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/jetty/ResourceCache$Content;","_prev","Lorg/mortbay/jetty/ResourceCache$Content;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f007__resource(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/jetty/ResourceCache$Content;","_resource","Lorg/mortbay/resource/Resource;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f008_this$0(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_FINAL|ACC_SYNTHETIC, new Field("Lorg/mortbay/jetty/ResourceCache$Content;","this$0","Lorg/mortbay/jetty/ResourceCache;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/ResourceCache$Content;","<init>",new String[]{ "Lorg/mortbay/jetty/ResourceCache;","Lorg/mortbay/resource/Resource;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(1,"resource");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(279,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(280,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(282,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(283,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(284,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(286,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(287,L6);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,3,2,new Field("Lorg/mortbay/jetty/ResourceCache$Content;","this$0","Lorg/mortbay/jetty/ResourceCache;"));
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2},new Method("Ljava/lang/Object;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitFieldStmt(IPUT_OBJECT,4,2,new Field("Lorg/mortbay/jetty/ResourceCache$Content;","_resource","Lorg/mortbay/resource/Resource;"));
                code.visitLabel(L2);
                code.visitFieldStmt(IPUT_OBJECT,2,2,new Field("Lorg/mortbay/jetty/ResourceCache$Content;","_next","Lorg/mortbay/jetty/ResourceCache$Content;"));
                code.visitLabel(L3);
                code.visitFieldStmt(IPUT_OBJECT,2,2,new Field("Lorg/mortbay/jetty/ResourceCache$Content;","_prev","Lorg/mortbay/jetty/ResourceCache$Content;"));
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3},new Method("Lorg/mortbay/jetty/ResourceCache;","access$000",new String[]{ "Lorg/mortbay/jetty/ResourceCache;"},"Lorg/mortbay/jetty/MimeTypes;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/ResourceCache$Content;","_resource","Lorg/mortbay/resource/Resource;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/lang/Object;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/MimeTypes;","getMimeByExtension",new String[]{ "Ljava/lang/String;"},"Lorg/mortbay/io/Buffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/jetty/ResourceCache$Content;","_contentType","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/resource/Resource;","lastModified",new String[]{ },"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,0);
                code.visitFieldStmt(IPUT_WIDE,0,2,new Field("Lorg/mortbay/jetty/ResourceCache$Content;","_lastModified","J"));
                code.visitLabel(L6);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001_cache(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(0, new Method("Lorg/mortbay/jetty/ResourceCache$Content;","cache",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"pathInContext");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(292,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(293,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(294,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(295,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(296,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(297,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(298,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(299,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(301,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(302,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(303,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(304,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(305,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(306,L13);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,5,4,new Field("Lorg/mortbay/jetty/ResourceCache$Content;","_key","Ljava/lang/String;"));
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/jetty/ResourceCache$Content;","this$0","Lorg/mortbay/jetty/ResourceCache;"));
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/ResourceCache;","_mostRecentlyUsed","Lorg/mortbay/jetty/ResourceCache$Content;"));
                code.visitFieldStmt(IPUT_OBJECT,0,4,new Field("Lorg/mortbay/jetty/ResourceCache$Content;","_next","Lorg/mortbay/jetty/ResourceCache$Content;"));
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/jetty/ResourceCache$Content;","this$0","Lorg/mortbay/jetty/ResourceCache;"));
                code.visitFieldStmt(IPUT_OBJECT,4,0,new Field("Lorg/mortbay/jetty/ResourceCache;","_mostRecentlyUsed","Lorg/mortbay/jetty/ResourceCache$Content;"));
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/jetty/ResourceCache$Content;","_next","Lorg/mortbay/jetty/ResourceCache$Content;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L5);
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/jetty/ResourceCache$Content;","_next","Lorg/mortbay/jetty/ResourceCache$Content;"));
                code.visitFieldStmt(IPUT_OBJECT,4,0,new Field("Lorg/mortbay/jetty/ResourceCache$Content;","_prev","Lorg/mortbay/jetty/ResourceCache$Content;"));
                code.visitLabel(L5);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_OBJECT,0,4,new Field("Lorg/mortbay/jetty/ResourceCache$Content;","_prev","Lorg/mortbay/jetty/ResourceCache$Content;"));
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/jetty/ResourceCache$Content;","this$0","Lorg/mortbay/jetty/ResourceCache;"));
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/ResourceCache;","_leastRecentlyUsed","Lorg/mortbay/jetty/ResourceCache$Content;"));
                code.visitJumpStmt(IF_NEZ,0,-1,L8);
                code.visitLabel(L7);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/jetty/ResourceCache$Content;","this$0","Lorg/mortbay/jetty/ResourceCache;"));
                code.visitFieldStmt(IPUT_OBJECT,4,0,new Field("Lorg/mortbay/jetty/ResourceCache;","_leastRecentlyUsed","Lorg/mortbay/jetty/ResourceCache$Content;"));
                code.visitLabel(L8);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/jetty/ResourceCache$Content;","this$0","Lorg/mortbay/jetty/ResourceCache;"));
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/ResourceCache;","_cache","Ljava/util/Map;"));
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/jetty/ResourceCache$Content;","_key","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1,4},new Method("Ljava/util/Map;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L9);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/jetty/ResourceCache$Content;","this$0","Lorg/mortbay/jetty/ResourceCache;"));
                code.visitFieldStmt(IGET,1,0,new Field("Lorg/mortbay/jetty/ResourceCache;","_cachedSize","I"));
                code.visitFieldStmt(IGET_OBJECT,2,4,new Field("Lorg/mortbay/jetty/ResourceCache$Content;","_buffer","Lorg/mortbay/io/Buffer;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2},new Method("Lorg/mortbay/io/Buffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitStmt2R(ADD_INT_2ADDR,1,2);
                code.visitFieldStmt(IPUT,1,0,new Field("Lorg/mortbay/jetty/ResourceCache;","_cachedSize","I"));
                code.visitLabel(L10);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/jetty/ResourceCache$Content;","this$0","Lorg/mortbay/jetty/ResourceCache;"));
                code.visitFieldStmt(IGET,1,0,new Field("Lorg/mortbay/jetty/ResourceCache;","_cachedFiles","I"));
                code.visitStmt2R1N(ADD_INT_LIT8,1,1,1);
                code.visitFieldStmt(IPUT,1,0,new Field("Lorg/mortbay/jetty/ResourceCache;","_cachedFiles","I"));
                code.visitLabel(L11);
                code.visitFieldStmt(IGET_WIDE,0,4,new Field("Lorg/mortbay/jetty/ResourceCache$Content;","_lastModified","J"));
                code.visitConstStmt(CONST_WIDE_16,2,Long.valueOf(-1L)); // long: 0xffffffffffffffff  double:NaN
                code.visitStmt3R(CMP_LONG,0,0,2);
                code.visitJumpStmt(IF_EQZ,0,-1,L13);
                code.visitLabel(L12);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/io/ByteArrayBuffer;");
                code.visitFieldStmt(IGET_WIDE,1,4,new Field("Lorg/mortbay/jetty/ResourceCache$Content;","_lastModified","J"));
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1,2,3},new Method("Lorg/mortbay/jetty/HttpFields;","formatDate",new String[]{ "J","Z"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Lorg/mortbay/io/ByteArrayBuffer;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,4,new Field("Lorg/mortbay/jetty/ResourceCache$Content;","_lastModifiedBytes","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L13);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_getBuffer(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/ResourceCache$Content;","getBuffer",new String[]{ },"Lorg/mortbay/io/Buffer;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(413,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(414,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(415,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/ResourceCache$Content;","_buffer","Lorg/mortbay/io/Buffer;"));
                DexLabel L3=new DexLabel();
                code.visitJumpStmt(IF_NEZ,0,-1,L3);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L2);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L3);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/io/View;");
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/ResourceCache$Content;","_buffer","Lorg/mortbay/io/Buffer;"));
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Lorg/mortbay/io/View;","<init>",new String[]{ "Lorg/mortbay/io/Buffer;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_getContentLength(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/ResourceCache$Content;","getContentLength",new String[]{ },"J"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(427,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(428,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(429,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/ResourceCache$Content;","_buffer","Lorg/mortbay/io/Buffer;"));
                DexLabel L3=new DexLabel();
                code.visitJumpStmt(IF_NEZ,0,-1,L3);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_WIDE_16,0,Long.valueOf(-1L)); // long: 0xffffffffffffffff  double:NaN
                code.visitLabel(L2);
                code.visitStmt1R(RETURN_WIDE,0);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/ResourceCache$Content;","_buffer","Lorg/mortbay/io/Buffer;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Lorg/mortbay/io/Buffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitStmt2R(INT_TO_LONG,0,0);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_getContentType(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/ResourceCache$Content;","getContentType",new String[]{ },"Lorg/mortbay/io/Buffer;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(396,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/ResourceCache$Content;","_contentType","Lorg/mortbay/io/Buffer;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_getInputStream(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/ResourceCache$Content;","getInputStream",new String[]{ },"Ljava/io/InputStream;"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(435,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/ResourceCache$Content;","_resource","Lorg/mortbay/resource/Resource;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/resource/Resource;","getInputStream",new String[]{ },"Ljava/io/InputStream;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_getKey(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/ResourceCache$Content;","getKey",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(311,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/ResourceCache$Content;","_key","Ljava/lang/String;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m007_getLastModified(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/ResourceCache$Content;","getLastModified",new String[]{ },"Lorg/mortbay/io/Buffer;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(390,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/ResourceCache$Content;","_lastModifiedBytes","Lorg/mortbay/io/Buffer;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m008_getResource(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/ResourceCache$Content;","getResource",new String[]{ },"Lorg/mortbay/resource/Resource;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(323,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/ResourceCache$Content;","_resource","Lorg/mortbay/resource/Resource;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m009_invalidate(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/ResourceCache$Content;","invalidate",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L5=new DexLabel();
                ddv.visitPrologue(L5);
                ddv.visitLineNumber(360,L5);
                ddv.visitLineNumber(363,L0);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(364,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(365,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(366,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(368,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(369,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(373,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(374,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(378,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(379,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(380,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(381,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(382,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(384,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(385,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(371,L20);
                ddv.visitLineNumber(384,L2);
                ddv.visitLineNumber(376,L3);
                code.visitLabel(L5);
                code.visitStmt1R(MONITOR_ENTER,3);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/jetty/ResourceCache$Content;","this$0","Lorg/mortbay/jetty/ResourceCache;"));
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/ResourceCache;","_cache","Ljava/util/Map;"));
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/jetty/ResourceCache$Content;","_key","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1},new Method("Ljava/util/Map;","remove",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L6);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_OBJECT,0,3,new Field("Lorg/mortbay/jetty/ResourceCache$Content;","_key","Ljava/lang/String;"));
                code.visitLabel(L7);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/jetty/ResourceCache$Content;","this$0","Lorg/mortbay/jetty/ResourceCache;"));
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/jetty/ResourceCache$Content;","this$0","Lorg/mortbay/jetty/ResourceCache;"));
                code.visitFieldStmt(IGET,1,1,new Field("Lorg/mortbay/jetty/ResourceCache;","_cachedSize","I"));
                code.visitFieldStmt(IGET_OBJECT,2,3,new Field("Lorg/mortbay/jetty/ResourceCache$Content;","_buffer","Lorg/mortbay/io/Buffer;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2},new Method("Lorg/mortbay/io/Buffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitStmt2R(SUB_INT_2ADDR,1,2);
                code.visitFieldStmt(IPUT,1,0,new Field("Lorg/mortbay/jetty/ResourceCache;","_cachedSize","I"));
                code.visitLabel(L8);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/jetty/ResourceCache$Content;","this$0","Lorg/mortbay/jetty/ResourceCache;"));
                code.visitFieldStmt(IGET,1,0,new Field("Lorg/mortbay/jetty/ResourceCache;","_cachedFiles","I"));
                code.visitConstStmt(CONST_4,2, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt2R(SUB_INT_2ADDR,1,2);
                code.visitFieldStmt(IPUT,1,0,new Field("Lorg/mortbay/jetty/ResourceCache;","_cachedFiles","I"));
                code.visitLabel(L9);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/jetty/ResourceCache$Content;","this$0","Lorg/mortbay/jetty/ResourceCache;"));
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/ResourceCache;","_mostRecentlyUsed","Lorg/mortbay/jetty/ResourceCache$Content;"));
                code.visitJumpStmt(IF_NE,0,3,L20);
                code.visitLabel(L10);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/jetty/ResourceCache$Content;","this$0","Lorg/mortbay/jetty/ResourceCache;"));
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/jetty/ResourceCache$Content;","_next","Lorg/mortbay/jetty/ResourceCache$Content;"));
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/ResourceCache;","_mostRecentlyUsed","Lorg/mortbay/jetty/ResourceCache$Content;"));
                code.visitLabel(L11);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/jetty/ResourceCache$Content;","this$0","Lorg/mortbay/jetty/ResourceCache;"));
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/ResourceCache;","_leastRecentlyUsed","Lorg/mortbay/jetty/ResourceCache$Content;"));
                code.visitJumpStmt(IF_NE,0,3,L3);
                code.visitLabel(L12);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/jetty/ResourceCache$Content;","this$0","Lorg/mortbay/jetty/ResourceCache;"));
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/jetty/ResourceCache$Content;","_prev","Lorg/mortbay/jetty/ResourceCache$Content;"));
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/ResourceCache;","_leastRecentlyUsed","Lorg/mortbay/jetty/ResourceCache$Content;"));
                code.visitLabel(L13);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_OBJECT,0,3,new Field("Lorg/mortbay/jetty/ResourceCache$Content;","_prev","Lorg/mortbay/jetty/ResourceCache$Content;"));
                code.visitLabel(L14);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_OBJECT,0,3,new Field("Lorg/mortbay/jetty/ResourceCache$Content;","_next","Lorg/mortbay/jetty/ResourceCache$Content;"));
                code.visitLabel(L15);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/jetty/ResourceCache$Content;","_resource","Lorg/mortbay/resource/Resource;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L17);
                code.visitLabel(L16);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/jetty/ResourceCache$Content;","_resource","Lorg/mortbay/resource/Resource;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/resource/Resource;","release",new String[]{ },"V"));
                code.visitLabel(L17);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_OBJECT,0,3,new Field("Lorg/mortbay/jetty/ResourceCache$Content;","_resource","Lorg/mortbay/resource/Resource;"));
                code.visitLabel(L18);
                code.visitStmt1R(MONITOR_EXIT,3);
                code.visitLabel(L19);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L20);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/jetty/ResourceCache$Content;","_prev","Lorg/mortbay/jetty/ResourceCache$Content;"));
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/jetty/ResourceCache$Content;","_next","Lorg/mortbay/jetty/ResourceCache$Content;"));
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/ResourceCache$Content;","_next","Lorg/mortbay/jetty/ResourceCache$Content;"));
                code.visitJumpStmt(GOTO,-1,-1,L11);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,0);
                code.visitStmt1R(MONITOR_EXIT,3);
                code.visitLabel(L1);
                code.visitStmt1R(THROW,0);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/jetty/ResourceCache$Content;","_next","Lorg/mortbay/jetty/ResourceCache$Content;"));
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/jetty/ResourceCache$Content;","_prev","Lorg/mortbay/jetty/ResourceCache$Content;"));
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/ResourceCache$Content;","_prev","Lorg/mortbay/jetty/ResourceCache$Content;"));
                code.visitLabel(L4);
                code.visitJumpStmt(GOTO,-1,-1,L13);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m010_isCached(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/ResourceCache$Content;","isCached",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(317,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/ResourceCache$Content;","_key","Ljava/lang/String;"));
                DexLabel L1=new DexLabel();
                code.visitJumpStmt(IF_EQZ,0,-1,L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                DexLabel L2=new DexLabel();
                code.visitLabel(L2);
                code.visitStmt1R(RETURN,0);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m011_isValid(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(0, new Method("Lorg/mortbay/jetty/ResourceCache$Content;","isValid",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(329,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(331,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(333,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(334,L3);
                ddv.visitStartLocal(1,L3,"tp","Lorg/mortbay/jetty/ResourceCache$Content;",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(336,L4);
                ddv.visitStartLocal(0,L4,"tn","Lorg/mortbay/jetty/ResourceCache$Content;",null);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(337,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(338,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(339,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(340,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(342,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(343,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(344,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(345,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(347,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(348,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(350,L15);
                ddv.visitEndLocal(1,L15);
                ddv.visitEndLocal(0,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(354,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(353,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(354,L18);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_WIDE,2,6,new Field("Lorg/mortbay/jetty/ResourceCache$Content;","_lastModified","J"));
                code.visitFieldStmt(IGET_OBJECT,4,6,new Field("Lorg/mortbay/jetty/ResourceCache$Content;","_resource","Lorg/mortbay/resource/Resource;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/resource/Resource;","lastModified",new String[]{ },"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,4);
                code.visitStmt3R(CMP_LONG,2,2,4);
                code.visitJumpStmt(IF_NEZ,2,-1,L17);
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,2,6,new Field("Lorg/mortbay/jetty/ResourceCache$Content;","this$0","Lorg/mortbay/jetty/ResourceCache;"));
                code.visitFieldStmt(IGET_OBJECT,2,2,new Field("Lorg/mortbay/jetty/ResourceCache;","_mostRecentlyUsed","Lorg/mortbay/jetty/ResourceCache$Content;"));
                code.visitJumpStmt(IF_EQ,2,6,L15);
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,1,6,new Field("Lorg/mortbay/jetty/ResourceCache$Content;","_prev","Lorg/mortbay/jetty/ResourceCache$Content;"));
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,6,new Field("Lorg/mortbay/jetty/ResourceCache$Content;","_next","Lorg/mortbay/jetty/ResourceCache$Content;"));
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,2,6,new Field("Lorg/mortbay/jetty/ResourceCache$Content;","this$0","Lorg/mortbay/jetty/ResourceCache;"));
                code.visitFieldStmt(IGET_OBJECT,2,2,new Field("Lorg/mortbay/jetty/ResourceCache;","_mostRecentlyUsed","Lorg/mortbay/jetty/ResourceCache$Content;"));
                code.visitFieldStmt(IPUT_OBJECT,2,6,new Field("Lorg/mortbay/jetty/ResourceCache$Content;","_next","Lorg/mortbay/jetty/ResourceCache$Content;"));
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,2,6,new Field("Lorg/mortbay/jetty/ResourceCache$Content;","this$0","Lorg/mortbay/jetty/ResourceCache;"));
                code.visitFieldStmt(IPUT_OBJECT,6,2,new Field("Lorg/mortbay/jetty/ResourceCache;","_mostRecentlyUsed","Lorg/mortbay/jetty/ResourceCache$Content;"));
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,2,6,new Field("Lorg/mortbay/jetty/ResourceCache$Content;","_next","Lorg/mortbay/jetty/ResourceCache$Content;"));
                code.visitJumpStmt(IF_EQZ,2,-1,L8);
                code.visitLabel(L7);
                code.visitFieldStmt(IGET_OBJECT,2,6,new Field("Lorg/mortbay/jetty/ResourceCache$Content;","_next","Lorg/mortbay/jetty/ResourceCache$Content;"));
                code.visitFieldStmt(IPUT_OBJECT,6,2,new Field("Lorg/mortbay/jetty/ResourceCache$Content;","_prev","Lorg/mortbay/jetty/ResourceCache$Content;"));
                code.visitLabel(L8);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_OBJECT,2,6,new Field("Lorg/mortbay/jetty/ResourceCache$Content;","_prev","Lorg/mortbay/jetty/ResourceCache$Content;"));
                code.visitLabel(L9);
                code.visitJumpStmt(IF_EQZ,1,-1,L11);
                code.visitLabel(L10);
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/ResourceCache$Content;","_next","Lorg/mortbay/jetty/ResourceCache$Content;"));
                code.visitLabel(L11);
                code.visitJumpStmt(IF_EQZ,0,-1,L13);
                code.visitLabel(L12);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/ResourceCache$Content;","_prev","Lorg/mortbay/jetty/ResourceCache$Content;"));
                code.visitLabel(L13);
                code.visitFieldStmt(IGET_OBJECT,2,6,new Field("Lorg/mortbay/jetty/ResourceCache$Content;","this$0","Lorg/mortbay/jetty/ResourceCache;"));
                code.visitFieldStmt(IGET_OBJECT,2,2,new Field("Lorg/mortbay/jetty/ResourceCache;","_leastRecentlyUsed","Lorg/mortbay/jetty/ResourceCache$Content;"));
                code.visitJumpStmt(IF_NE,2,6,L15);
                code.visitJumpStmt(IF_EQZ,1,-1,L15);
                code.visitLabel(L14);
                code.visitFieldStmt(IGET_OBJECT,2,6,new Field("Lorg/mortbay/jetty/ResourceCache$Content;","this$0","Lorg/mortbay/jetty/ResourceCache;"));
                code.visitFieldStmt(IPUT_OBJECT,1,2,new Field("Lorg/mortbay/jetty/ResourceCache;","_leastRecentlyUsed","Lorg/mortbay/jetty/ResourceCache$Content;"));
                code.visitLabel(L15);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L16);
                code.visitStmt1R(RETURN,2);
                code.visitLabel(L17);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/ResourceCache$Content;","invalidate",new String[]{ },"V"));
                code.visitLabel(L18);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L16);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m012_release(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/ResourceCache$Content;","release",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(408,L0);
                code.visitLabel(L0);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m013_setBuffer(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/ResourceCache$Content;","setBuffer",new String[]{ "Lorg/mortbay/io/Buffer;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"buffer");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(421,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(422,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/ResourceCache$Content;","_buffer","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m014_setContentType(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/ResourceCache$Content;","setContentType",new String[]{ "Lorg/mortbay/io/Buffer;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"type");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(402,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(403,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/ResourceCache$Content;","_contentType","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
