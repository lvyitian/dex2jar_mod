package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0198_org_mortbay_jetty_Server {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/jetty/Server;","Lorg/mortbay/jetty/handler/HandlerWrapper;",new String[]{ "Lorg/mortbay/util/Attributes;"});
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("Server.java");
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/MemberClasses;", Visibility.SYSTEM);
            if(av00 != null) {
                {
                    DexAnnotationVisitor av01 = av00.visitArray("value");
                    if(av01 != null) {
                        av01.visit(null, new DexType("Lorg/mortbay/jetty/Server$1;"));
                        av01.visit(null, new DexType("Lorg/mortbay/jetty/Server$Graceful;"));
                        av01.visit(null, new DexType("Lorg/mortbay/jetty/Server$ShutdownHookThread;"));
                        av01.visitEnd();
                    }
                }
                av00.visitEnd();
            }
        }
        f000__version(cv);
        f001_hookThread(cv);
        f002__attributes(cv);
        f003__connectors(cv);
        f004__container(cv);
        f005__dependentLifeCycles(cv);
        f006__graceful(cv);
        f007__realms(cv);
        f008__sendDateHeader(cv);
        f009__sendServerVersion(cv);
        f010__sessionIdManager(cv);
        f011__threadPool(cv);
        m000__clinit_(cv);
        m001__init_(cv);
        m002__init_(cv);
        m003_getVersion(cv);
        m004_addConnector(cv);
        m005_addHandler(cv);
        m006_addLifeCycle(cv);
        m007_addUserRealm(cv);
        m008_clearAttributes(cv);
        m009_doStart(cv);
        m010_doStop(cv);
        m011_getAttribute(cv);
        m012_getAttributeNames(cv);
        m013_getConnectors(cv);
        m014_getContainer(cv);
        m015_getGracefulShutdown(cv);
        m016_getHandlers(cv);
        m017_getSendDateHeader(cv);
        m018_getSendServerVersion(cv);
        m019_getSessionIdManager(cv);
        m020_getStopAtShutdown(cv);
        m021_getThreadPool(cv);
        m022_getUserRealms(cv);
        m023_handle(cv);
        m024_join(cv);
        m025_removeAttribute(cv);
        m026_removeConnector(cv);
        m027_removeHandler(cv);
        m028_removeLifeCycle(cv);
        m029_removeUserRealm(cv);
        m030_setAttribute(cv);
        m031_setConnectors(cv);
        m032_setGracefulShutdown(cv);
        m033_setHandlers(cv);
        m034_setSendDateHeader(cv);
        m035_setSendServerVersion(cv);
        m036_setSessionIdManager(cv);
        m037_setStopAtShutdown(cv);
        m038_setThreadPool(cv);
        m039_setUserRealms(cv);
    }
    public static void f000__version(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC, new Field("Lorg/mortbay/jetty/Server;","_version","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001_hookThread(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC, new Field("Lorg/mortbay/jetty/Server;","hookThread","Lorg/mortbay/jetty/Server$ShutdownHookThread;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002__attributes(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/Server;","_attributes","Lorg/mortbay/util/AttributesMap;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003__connectors(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/Server;","_connectors","[Lorg/mortbay/jetty/Connector;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f004__container(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/Server;","_container","Lorg/mortbay/component/Container;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f005__dependentLifeCycles(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/Server;","_dependentLifeCycles","Ljava/util/List;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f006__graceful(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/Server;","_graceful","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f007__realms(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/Server;","_realms","[Lorg/mortbay/jetty/security/UserRealm;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f008__sendDateHeader(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/Server;","_sendDateHeader","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f009__sendServerVersion(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/Server;","_sendServerVersion","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f010__sessionIdManager(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/Server;","_sessionIdManager","Lorg/mortbay/jetty/SessionIdManager;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f011__threadPool(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/Server;","_threadPool","Lorg/mortbay/thread/ThreadPool;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__clinit_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/Server;","<clinit>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(53,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(54,L2);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_CLASS,2,new DexType("Lorg/mortbay/jetty/Server;"));
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/jetty/Server$ShutdownHookThread;");
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/Server$ShutdownHookThread;","<init>",new String[]{ "Lorg/mortbay/jetty/Server$1;"},"V"));
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/Server;","hookThread","Lorg/mortbay/jetty/Server$ShutdownHookThread;"));
                code.visitLabel(L2);
                code.visitConstStmt(CONST_CLASS,0,new DexType("Lorg/mortbay/jetty/Server;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/lang/Class;","getPackage",new String[]{ },"Ljava/lang/Package;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                DexLabel L3=new DexLabel();
                code.visitJumpStmt(IF_EQZ,0,-1,L3);
                code.visitConstStmt(CONST_CLASS,0,new DexType("Lorg/mortbay/jetty/Server;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/lang/Class;","getPackage",new String[]{ },"Ljava/lang/Package;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/Package;","getImplementationVersion",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L3);
                code.visitConstStmt(CONST_CLASS,0,new DexType("Lorg/mortbay/jetty/Server;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/lang/Class;","getPackage",new String[]{ },"Ljava/lang/Package;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/Package;","getImplementationVersion",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                DexLabel L4=new DexLabel();
                code.visitLabel(L4);
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/Server;","_version","Ljava/lang/String;"));
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_STRING,0,"6.1.x");
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/Server;","<init>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(71,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(61,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(63,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(64,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(65,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(66,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(67,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(72,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(73,L9);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2},new Method("Lorg/mortbay/jetty/handler/HandlerWrapper;","<init>",new String[]{ },"V"));
                code.visitLabel(L2);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/component/Container;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Lorg/mortbay/component/Container;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/jetty/Server;","_container","Lorg/mortbay/component/Container;"));
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitFieldStmt(IPUT_BOOLEAN,0,2,new Field("Lorg/mortbay/jetty/Server;","_sendServerVersion","Z"));
                code.visitLabel(L4);
                code.visitFieldStmt(IPUT_BOOLEAN,1,2,new Field("Lorg/mortbay/jetty/Server;","_sendDateHeader","Z"));
                code.visitLabel(L5);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/util/AttributesMap;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Lorg/mortbay/util/AttributesMap;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/jetty/Server;","_attributes","Lorg/mortbay/util/AttributesMap;"));
                code.visitLabel(L6);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/util/ArrayList;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/util/ArrayList;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/jetty/Server;","_dependentLifeCycles","Ljava/util/List;"));
                code.visitLabel(L7);
                code.visitFieldStmt(IPUT,1,2,new Field("Lorg/mortbay/jetty/Server;","_graceful","I"));
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,2},new Method("Lorg/mortbay/jetty/Server;","setServer",new String[]{ "Lorg/mortbay/jetty/Server;"},"V"));
                code.visitLabel(L9);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/Server;","<init>",new String[]{ "I"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"port");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(80,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(61,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(63,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(64,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(65,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(66,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(67,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(81,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(83,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(84,L10);
                ddv.visitStartLocal(0,L10,"connector","Lorg/mortbay/jetty/Connector;",null);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(85,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(86,L12);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4},new Method("Lorg/mortbay/jetty/handler/HandlerWrapper;","<init>",new String[]{ },"V"));
                code.visitLabel(L2);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Lorg/mortbay/component/Container;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Lorg/mortbay/component/Container;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,1,4,new Field("Lorg/mortbay/jetty/Server;","_container","Lorg/mortbay/component/Container;"));
                code.visitLabel(L3);
                code.visitFieldStmt(IPUT_BOOLEAN,3,4,new Field("Lorg/mortbay/jetty/Server;","_sendServerVersion","Z"));
                code.visitLabel(L4);
                code.visitFieldStmt(IPUT_BOOLEAN,2,4,new Field("Lorg/mortbay/jetty/Server;","_sendDateHeader","Z"));
                code.visitLabel(L5);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Lorg/mortbay/util/AttributesMap;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Lorg/mortbay/util/AttributesMap;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,1,4,new Field("Lorg/mortbay/jetty/Server;","_attributes","Lorg/mortbay/util/AttributesMap;"));
                code.visitLabel(L6);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/util/ArrayList;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljava/util/ArrayList;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,1,4,new Field("Lorg/mortbay/jetty/Server;","_dependentLifeCycles","Ljava/util/List;"));
                code.visitLabel(L7);
                code.visitFieldStmt(IPUT,2,4,new Field("Lorg/mortbay/jetty/Server;","_graceful","I"));
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,4},new Method("Lorg/mortbay/jetty/Server;","setServer",new String[]{ "Lorg/mortbay/jetty/Server;"},"V"));
                code.visitLabel(L9);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/jetty/bio/SocketConnector;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Lorg/mortbay/jetty/bio/SocketConnector;","<init>",new String[]{ },"V"));
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,5},new Method("Lorg/mortbay/jetty/Connector;","setPort",new String[]{ "I"},"V"));
                code.visitLabel(L11);
                code.visitTypeStmt(NEW_ARRAY,1,3,"[Lorg/mortbay/jetty/Connector;");
                code.visitStmt3R(APUT_OBJECT,0,1,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,1},new Method("Lorg/mortbay/jetty/Server;","setConnectors",new String[]{ "[Lorg/mortbay/jetty/Connector;"},"V"));
                code.visitLabel(L12);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_getVersion(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/jetty/Server;","getVersion",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(92,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/Server;","_version","Ljava/lang/String;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_addConnector(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Server;","addConnector",new String[]{ "Lorg/mortbay/jetty/Connector;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"connector");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(132,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(133,L1);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/Server;","getConnectors",new String[]{ },"[Lorg/mortbay/jetty/Connector;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitConstStmt(CONST_CLASS,1,new DexType("Lorg/mortbay/jetty/Connector;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,3,1},new Method("Lorg/mortbay/util/LazyList;","addToArray",new String[]{ "[Ljava/lang/Object;","Ljava/lang/Object;","Ljava/lang/Class;"},"[Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitTypeStmt(CHECK_CAST,0,-1,"[Lorg/mortbay/jetty/Connector;");
                code.visitTypeStmt(CHECK_CAST,0,-1,"[Lorg/mortbay/jetty/Connector;");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,0},new Method("Lorg/mortbay/jetty/Server;","setConnectors",new String[]{ "[Lorg/mortbay/jetty/Connector;"},"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_addHandler(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Server;","addHandler",new String[]{ "Lorg/mortbay/jetty/Handler;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"handler");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(588,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(589,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(598,L2);
                ddv.visitEndLocal(4,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(590,L3);
                ddv.visitRestartLocal(4,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(591,L4);
                DexLabel L5=new DexLabel();
                ddv.visitEndLocal(4,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(594,L6);
                ddv.visitRestartLocal(4,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(595,L7);
                ddv.visitStartLocal(0,L7,"collection","Lorg/mortbay/jetty/handler/HandlerCollection;",null);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(596,L8);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/jetty/Server;","getHandler",new String[]{ },"Lorg/mortbay/jetty/Handler;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitJumpStmt(IF_NEZ,1,-1,L3);
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Lorg/mortbay/jetty/Server;","setHandler",new String[]{ "Lorg/mortbay/jetty/Handler;"},"V"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/jetty/Server;","getHandler",new String[]{ },"Lorg/mortbay/jetty/Handler;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitTypeStmt(INSTANCE_OF,1,1,"Lorg/mortbay/jetty/handler/HandlerCollection;");
                code.visitJumpStmt(IF_EQZ,1,-1,L6);
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/jetty/Server;","getHandler",new String[]{ },"Lorg/mortbay/jetty/Handler;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitLabel(L5);
                code.visitTypeStmt(CHECK_CAST,4,-1,"Lorg/mortbay/jetty/handler/HandlerCollection;");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Lorg/mortbay/jetty/handler/HandlerCollection;","addHandler",new String[]{ "Lorg/mortbay/jetty/Handler;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L6);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/jetty/handler/HandlerCollection;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Lorg/mortbay/jetty/handler/HandlerCollection;","<init>",new String[]{ },"V"));
                code.visitLabel(L7);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitTypeStmt(NEW_ARRAY,1,1,"[Lorg/mortbay/jetty/Handler;");
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/jetty/Server;","getHandler",new String[]{ },"Lorg/mortbay/jetty/Handler;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitStmt3R(APUT_OBJECT,3,1,2);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt3R(APUT_OBJECT,5,1,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/handler/HandlerCollection;","setHandlers",new String[]{ "[Lorg/mortbay/jetty/Handler;"},"V"));
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,0},new Method("Lorg/mortbay/jetty/Server;","setHandler",new String[]{ "Lorg/mortbay/jetty/Handler;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_addLifeCycle(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Server;","addLifeCycle",new String[]{ "Lorg/mortbay/component/LifeCycle;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/lang/Exception;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"c");
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(420,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(436,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(422,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(424,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(425,L7);
                ddv.visitLineNumber(429,L0);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(430,L8);
                ddv.visitLineNumber(432,L2);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(434,L9);
                ddv.visitStartLocal(0,L9,"e","Ljava/lang/Exception;",null);
                code.visitLabel(L3);
                code.visitJumpStmt(IF_NEZ,3,-1,L5);
                code.visitLabel(L4);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/Server;","_dependentLifeCycles","Ljava/util/List;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1,3},new Method("Ljava/util/List;","contains",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_NEZ,1,-1,L0);
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/Server;","_dependentLifeCycles","Ljava/util/List;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1,3},new Method("Ljava/util/List;","add",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitLabel(L7);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/Server;","_container","Lorg/mortbay/component/Container;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,3},new Method("Lorg/mortbay/component/Container;","addBean",new String[]{ "Ljava/lang/Object;"},"V"));
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/Server;","isStarted",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_EQZ,1,-1,L4);
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3},new Method("Lorg/mortbay/component/LifeCycle;","start",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitStmt2R(MOVE_OBJECT,0,1);
                code.visitLabel(L9);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/lang/RuntimeException;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,0},new Method("Ljava/lang/RuntimeException;","<init>",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitStmt1R(THROW,1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m007_addUserRealm(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Server;","addUserRealm",new String[]{ "Lorg/mortbay/jetty/security/UserRealm;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"realm");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(355,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(356,L1);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/Server;","getUserRealms",new String[]{ },"[Lorg/mortbay/jetty/security/UserRealm;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitConstStmt(CONST_CLASS,1,new DexType("Lorg/mortbay/jetty/security/UserRealm;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,3,1},new Method("Lorg/mortbay/util/LazyList;","addToArray",new String[]{ "[Ljava/lang/Object;","Ljava/lang/Object;","Ljava/lang/Class;"},"[Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitTypeStmt(CHECK_CAST,0,-1,"[Lorg/mortbay/jetty/security/UserRealm;");
                code.visitTypeStmt(CHECK_CAST,0,-1,"[Lorg/mortbay/jetty/security/UserRealm;");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,0},new Method("Lorg/mortbay/jetty/Server;","setUserRealms",new String[]{ "[Lorg/mortbay/jetty/security/UserRealm;"},"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m008_clearAttributes(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Server;","clearAttributes",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(643,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(644,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/Server;","_attributes","Lorg/mortbay/util/AttributesMap;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/util/AttributesMap;","clearAttributes",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m009_doStart(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/Server;","doStart",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/Exception;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(8);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/lang/Throwable;"});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                DexLabel L5=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L5},new String[]{ "Ljava/lang/Throwable;"});
                DexLabel L6=new DexLabel();
                DexLabel L7=new DexLabel();
                code.visitTryCatch(L4,L6,new DexLabel[]{L7},new String[]{ "Ljava/lang/Throwable;"});
                DexLabel L8=new DexLabel();
                DexLabel L9=new DexLabel();
                DexLabel L10=new DexLabel();
                code.visitTryCatch(L8,L9,new DexLabel[]{L10},new String[]{ "Ljava/lang/Throwable;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L11=new DexLabel();
                ddv.visitPrologue(L11);
                ddv.visitLineNumber(184,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(185,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(186,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(188,L14);
                ddv.visitStartLocal(3,L14,"mex","Lorg/mortbay/util/MultiException;",null);
                DexLabel L15=new DexLabel();
                ddv.visitStartLocal(1,L15,"i","I",null);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(190,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(191,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(188,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(194,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(195,L20);
                ddv.visitStartLocal(2,L20,"itor","Ljava/util/Iterator;",null);
                ddv.visitLineNumber(199,L0);
                ddv.visitLineNumber(201,L2);
                DexLabel L21=new DexLabel();
                ddv.visitStartLocal(0,L21,"e","Ljava/lang/Throwable;",null);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(204,L22);
                ddv.visitEndLocal(0,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(206,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(207,L24);
                ddv.visitStartLocal(4,L24,"tp","Lorg/mortbay/thread/QueuedThreadPool;",null);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(210,L25);
                ddv.visitEndLocal(4,L25);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(211,L26);
                ddv.visitLineNumber(215,L3);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(216,L27);
                ddv.visitLineNumber(222,L4);
                ddv.visitLineNumber(229,L6);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(231,L28);
                ddv.visitLineNumber(233,L8);
                ddv.visitLineNumber(231,L9);
                ddv.visitLineNumber(218,L5);
                DexLabel L29=new DexLabel();
                ddv.visitRestartLocal(0,L29);
                ddv.visitLineNumber(224,L7);
                ddv.visitEndLocal(0,L7);
                DexLabel L30=new DexLabel();
                ddv.visitLineNumber(226,L30);
                ddv.visitRestartLocal(0,L30);
                ddv.visitLineNumber(234,L10);
                ddv.visitEndLocal(0,L10);
                DexLabel L31=new DexLabel();
                ddv.visitLineNumber(236,L31);
                ddv.visitRestartLocal(0,L31);
                DexLabel L32=new DexLabel();
                ddv.visitLineNumber(240,L32);
                ddv.visitEndLocal(0,L32);
                DexLabel L33=new DexLabel();
                ddv.visitLineNumber(241,L33);
                code.visitLabel(L11);
                code.visitTypeStmt(NEW_INSTANCE,5,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 5},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,6,"jetty-");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitFieldStmt(SGET_OBJECT,6,-1,new Field("Lorg/mortbay/jetty/Server;","_version","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 5},new Method("Lorg/mortbay/log/Log;","info",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L12);
                code.visitFieldStmt(SGET_OBJECT,5,-1,new Field("Lorg/mortbay/jetty/Server;","_version","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 5},new Method("Lorg/mortbay/jetty/HttpGenerator;","setServerVersion",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L13);
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Lorg/mortbay/util/MultiException;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3},new Method("Lorg/mortbay/util/MultiException;","<init>",new String[]{ },"V"));
                code.visitLabel(L14);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L15);
                code.visitFieldStmt(IGET_OBJECT,5,7,new Field("Lorg/mortbay/jetty/Server;","_realms","[Lorg/mortbay/jetty/security/UserRealm;"));
                code.visitJumpStmt(IF_EQZ,5,-1,L19);
                code.visitFieldStmt(IGET_OBJECT,5,7,new Field("Lorg/mortbay/jetty/Server;","_realms","[Lorg/mortbay/jetty/security/UserRealm;"));
                code.visitStmt2R(ARRAY_LENGTH,5,5);
                code.visitJumpStmt(IF_GE,1,5,L19);
                code.visitLabel(L16);
                code.visitFieldStmt(IGET_OBJECT,5,7,new Field("Lorg/mortbay/jetty/Server;","_realms","[Lorg/mortbay/jetty/security/UserRealm;"));
                code.visitStmt3R(AGET_OBJECT,5,5,1);
                code.visitTypeStmt(INSTANCE_OF,5,5,"Lorg/mortbay/component/LifeCycle;");
                code.visitJumpStmt(IF_EQZ,5,-1,L18);
                code.visitLabel(L17);
                code.visitFieldStmt(IGET_OBJECT,5,7,new Field("Lorg/mortbay/jetty/Server;","_realms","[Lorg/mortbay/jetty/security/UserRealm;"));
                code.visitStmt3R(AGET_OBJECT,5,5,1);
                code.visitTypeStmt(CHECK_CAST,5,-1,"Lorg/mortbay/component/LifeCycle;");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 5},new Method("Lorg/mortbay/component/LifeCycle;","start",new String[]{ },"V"));
                code.visitLabel(L18);
                code.visitStmt2R1N(ADD_INT_LIT8,1,1,1);
                code.visitJumpStmt(GOTO,-1,-1,L15);
                code.visitLabel(L19);
                code.visitFieldStmt(IGET_OBJECT,5,7,new Field("Lorg/mortbay/jetty/Server;","_dependentLifeCycles","Ljava/util/List;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 5},new Method("Ljava/util/List;","iterator",new String[]{ },"Ljava/util/Iterator;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L20);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2},new Method("Ljava/util/Iterator;","hasNext",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitJumpStmt(IF_EQZ,5,-1,L22);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2},new Method("Ljava/util/Iterator;","next",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitTypeStmt(CHECK_CAST,5,-1,"Lorg/mortbay/component/LifeCycle;");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 5},new Method("Lorg/mortbay/component/LifeCycle;","start",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitJumpStmt(GOTO,-1,-1,L20);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,5);
                code.visitStmt2R(MOVE_OBJECT,0,5);
                code.visitLabel(L21);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,0},new Method("Lorg/mortbay/util/MultiException;","add",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L20);
                code.visitLabel(L22);
                code.visitFieldStmt(IGET_OBJECT,5,7,new Field("Lorg/mortbay/jetty/Server;","_threadPool","Lorg/mortbay/thread/ThreadPool;"));
                code.visitJumpStmt(IF_NEZ,5,-1,L25);
                code.visitLabel(L23);
                code.visitTypeStmt(NEW_INSTANCE,4,-1,"Lorg/mortbay/thread/QueuedThreadPool;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4},new Method("Lorg/mortbay/thread/QueuedThreadPool;","<init>",new String[]{ },"V"));
                code.visitLabel(L24);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,4},new Method("Lorg/mortbay/jetty/Server;","setThreadPool",new String[]{ "Lorg/mortbay/thread/ThreadPool;"},"V"));
                code.visitLabel(L25);
                code.visitFieldStmt(IGET_OBJECT,5,7,new Field("Lorg/mortbay/jetty/Server;","_sessionIdManager","Lorg/mortbay/jetty/SessionIdManager;"));
                code.visitJumpStmt(IF_EQZ,5,-1,L3);
                code.visitLabel(L26);
                code.visitFieldStmt(IGET_OBJECT,5,7,new Field("Lorg/mortbay/jetty/Server;","_sessionIdManager","Lorg/mortbay/jetty/SessionIdManager;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 5},new Method("Lorg/mortbay/jetty/SessionIdManager;","start",new String[]{ },"V"));
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,5,7,new Field("Lorg/mortbay/jetty/Server;","_threadPool","Lorg/mortbay/thread/ThreadPool;"));
                code.visitTypeStmt(INSTANCE_OF,5,5,"Lorg/mortbay/component/LifeCycle;");
                code.visitJumpStmt(IF_EQZ,5,-1,L4);
                code.visitLabel(L27);
                code.visitFieldStmt(IGET_OBJECT,5,7,new Field("Lorg/mortbay/jetty/Server;","_threadPool","Lorg/mortbay/thread/ThreadPool;"));
                code.visitTypeStmt(CHECK_CAST,5,-1,"Lorg/mortbay/component/LifeCycle;");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 5},new Method("Lorg/mortbay/component/LifeCycle;","start",new String[]{ },"V"));
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 7},new Method("Lorg/mortbay/jetty/handler/HandlerWrapper;","doStart",new String[]{ },"V"));
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,5,7,new Field("Lorg/mortbay/jetty/Server;","_connectors","[Lorg/mortbay/jetty/Connector;"));
                code.visitJumpStmt(IF_EQZ,5,-1,L32);
                code.visitLabel(L28);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                DexLabel L34=new DexLabel();
                code.visitLabel(L34);
                code.visitFieldStmt(IGET_OBJECT,5,7,new Field("Lorg/mortbay/jetty/Server;","_connectors","[Lorg/mortbay/jetty/Connector;"));
                code.visitStmt2R(ARRAY_LENGTH,5,5);
                code.visitJumpStmt(IF_GE,1,5,L32);
                code.visitLabel(L8);
                code.visitFieldStmt(IGET_OBJECT,5,7,new Field("Lorg/mortbay/jetty/Server;","_connectors","[Lorg/mortbay/jetty/Connector;"));
                code.visitStmt3R(AGET_OBJECT,5,5,1);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 5},new Method("Lorg/mortbay/jetty/Connector;","start",new String[]{ },"V"));
                code.visitLabel(L9);
                code.visitStmt2R1N(ADD_INT_LIT8,1,1,1);
                code.visitJumpStmt(GOTO,-1,-1,L34);
                code.visitLabel(L5);
                code.visitStmt1R(MOVE_EXCEPTION,5);
                code.visitStmt2R(MOVE_OBJECT,0,5);
                code.visitLabel(L29);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,0},new Method("Lorg/mortbay/util/MultiException;","add",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitLabel(L7);
                code.visitStmt1R(MOVE_EXCEPTION,0);
                code.visitLabel(L30);
                code.visitConstStmt(CONST_STRING,5,"Error starting handlers");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 5,0},new Method("Lorg/mortbay/log/Log;","warn",new String[]{ "Ljava/lang/String;","Ljava/lang/Throwable;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L6);
                code.visitLabel(L10);
                code.visitStmt1R(MOVE_EXCEPTION,5);
                code.visitStmt2R(MOVE_OBJECT,0,5);
                code.visitLabel(L31);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,0},new Method("Lorg/mortbay/util/MultiException;","add",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L9);
                code.visitLabel(L32);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/util/MultiException;","ifExceptionThrow",new String[]{ },"V"));
                code.visitLabel(L33);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m010_doStop(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/Server;","doStop",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/Exception;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(12);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/lang/Throwable;"});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                DexLabel L5=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L5},new String[]{ "Ljava/lang/Throwable;"});
                DexLabel L6=new DexLabel();
                DexLabel L7=new DexLabel();
                DexLabel L8=new DexLabel();
                code.visitTryCatch(L6,L7,new DexLabel[]{L8},new String[]{ "Ljava/lang/Throwable;"});
                DexLabel L9=new DexLabel();
                DexLabel L10=new DexLabel();
                DexLabel L11=new DexLabel();
                code.visitTryCatch(L9,L10,new DexLabel[]{L11},new String[]{ "Ljava/lang/Throwable;"});
                DexLabel L12=new DexLabel();
                DexLabel L13=new DexLabel();
                DexLabel L14=new DexLabel();
                code.visitTryCatch(L12,L13,new DexLabel[]{L14},new String[]{ "Ljava/lang/Throwable;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L15=new DexLabel();
                ddv.visitPrologue(L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(246,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(248,L17);
                ddv.visitStartLocal(7,L17,"mex","Lorg/mortbay/util/MultiException;",null);
                DexLabel L18=new DexLabel();
                ddv.visitStartLocal(4,L18,"i","I",null);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(250,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(251,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(248,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(254,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(256,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(258,L24);
                DexLabel L25=new DexLabel();
                ddv.visitEndLocal(4,L25);
                ddv.visitStartLocal(5,L25,"i","I",null);
                DexLabel L26=new DexLabel();
                ddv.visitRestartLocal(4,L26);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(260,L27);
                ddv.visitEndLocal(5,L27);
                ddv.visitLineNumber(261,L0);
                DexLabel L28=new DexLabel();
                ddv.visitRestartLocal(5,L28);
                ddv.visitEndLocal(5,L2);
                DexLabel L29=new DexLabel();
                ddv.visitStartLocal(3,L29,"e","Ljava/lang/Throwable;",null);
                DexLabel L30=new DexLabel();
                ddv.visitRestartLocal(5,L30);
                DexLabel L31=new DexLabel();
                ddv.visitLineNumber(265,L31);
                ddv.visitEndLocal(3,L31);
                ddv.visitEndLocal(5,L31);
                DexLabel L32=new DexLabel();
                ddv.visitLineNumber(266,L32);
                ddv.visitStartLocal(2,L32,"contexts","[Lorg/mortbay/jetty/Handler;",null);
                DexLabel L33=new DexLabel();
                ddv.visitStartLocal(0,L33,"c","I",null);
                DexLabel L34=new DexLabel();
                ddv.visitLineNumber(268,L34);
                DexLabel L35=new DexLabel();
                ddv.visitLineNumber(269,L35);
                ddv.visitStartLocal(1,L35,"context","Lorg/mortbay/jetty/Server$Graceful;",null);
                DexLabel L36=new DexLabel();
                ddv.visitLineNumber(270,L36);
                DexLabel L37=new DexLabel();
                ddv.visitLineNumber(266,L37);
                DexLabel L38=new DexLabel();
                ddv.visitLineNumber(272,L38);
                ddv.visitEndLocal(1,L38);
                DexLabel L39=new DexLabel();
                ddv.visitLineNumber(275,L39);
                ddv.visitEndLocal(2,L39);
                ddv.visitEndLocal(0,L39);
                DexLabel L40=new DexLabel();
                ddv.visitLineNumber(277,L40);
                DexLabel L41=new DexLabel();
                ddv.visitRestartLocal(4,L41);
                DexLabel L42=new DexLabel();
                ddv.visitEndLocal(4,L42);
                ddv.visitRestartLocal(5,L42);
                DexLabel L43=new DexLabel();
                ddv.visitRestartLocal(4,L43);
                ddv.visitLineNumber(278,L3);
                ddv.visitEndLocal(5,L3);
                DexLabel L44=new DexLabel();
                ddv.visitRestartLocal(5,L44);
                ddv.visitEndLocal(5,L5);
                DexLabel L45=new DexLabel();
                ddv.visitRestartLocal(3,L45);
                DexLabel L46=new DexLabel();
                ddv.visitRestartLocal(5,L46);
                ddv.visitLineNumber(281,L6);
                ddv.visitEndLocal(3,L6);
                ddv.visitEndLocal(5,L6);
                ddv.visitLineNumber(283,L7);
                DexLabel L47=new DexLabel();
                ddv.visitLineNumber(284,L47);
                ddv.visitLineNumber(288,L9);
                DexLabel L48=new DexLabel();
                ddv.visitLineNumber(289,L48);
                ddv.visitLineNumber(293,L10);
                DexLabel L49=new DexLabel();
                ddv.visitLineNumber(295,L49);
                DexLabel L50=new DexLabel();
                ddv.visitLineNumber(296,L50);
                ddv.visitEndLocal(11,L50);
                ddv.visitStartLocal(6,L50,"itor","Ljava/util/ListIterator;",null);
                ddv.visitLineNumber(300,L12);
                ddv.visitLineNumber(302,L14);
                DexLabel L51=new DexLabel();
                ddv.visitRestartLocal(3,L51);
                ddv.visitLineNumber(281,L8);
                ddv.visitEndLocal(6,L8);
                ddv.visitEndLocal(3,L8);
                ddv.visitRestartLocal(11,L8);
                DexLabel L52=new DexLabel();
                ddv.visitRestartLocal(3,L52);
                ddv.visitLineNumber(291,L11);
                ddv.visitEndLocal(3,L11);
                DexLabel L53=new DexLabel();
                ddv.visitRestartLocal(3,L53);
                DexLabel L54=new DexLabel();
                ddv.visitLineNumber(306,L54);
                ddv.visitEndLocal(11,L54);
                ddv.visitEndLocal(3,L54);
                DexLabel L55=new DexLabel();
                ddv.visitLineNumber(307,L55);
                code.visitLabel(L15);
                code.visitConstStmt(CONST_4,10, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitConstStmt(CONST_STRING,9,"Graceful shutdown {}");
                code.visitLabel(L16);
                code.visitTypeStmt(NEW_INSTANCE,7,-1,"Lorg/mortbay/util/MultiException;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 7},new Method("Lorg/mortbay/util/MultiException;","<init>",new String[]{ },"V"));
                code.visitLabel(L17);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L18);
                code.visitFieldStmt(IGET_OBJECT,8,11,new Field("Lorg/mortbay/jetty/Server;","_realms","[Lorg/mortbay/jetty/security/UserRealm;"));
                code.visitJumpStmt(IF_EQZ,8,-1,L22);
                code.visitFieldStmt(IGET_OBJECT,8,11,new Field("Lorg/mortbay/jetty/Server;","_realms","[Lorg/mortbay/jetty/security/UserRealm;"));
                code.visitStmt2R(ARRAY_LENGTH,8,8);
                code.visitJumpStmt(IF_GE,4,8,L22);
                code.visitLabel(L19);
                code.visitFieldStmt(IGET_OBJECT,8,11,new Field("Lorg/mortbay/jetty/Server;","_realms","[Lorg/mortbay/jetty/security/UserRealm;"));
                code.visitStmt3R(AGET_OBJECT,8,8,4);
                code.visitTypeStmt(INSTANCE_OF,8,8,"Lorg/mortbay/component/LifeCycle;");
                code.visitJumpStmt(IF_EQZ,8,-1,L21);
                code.visitLabel(L20);
                code.visitFieldStmt(IGET_OBJECT,8,11,new Field("Lorg/mortbay/jetty/Server;","_realms","[Lorg/mortbay/jetty/security/UserRealm;"));
                code.visitStmt3R(AGET_OBJECT,8,8,4);
                code.visitTypeStmt(CHECK_CAST,8,-1,"Lorg/mortbay/component/LifeCycle;");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 8},new Method("Lorg/mortbay/component/LifeCycle;","stop",new String[]{ },"V"));
                code.visitLabel(L21);
                code.visitStmt2R1N(ADD_INT_LIT8,4,4,1);
                code.visitJumpStmt(GOTO,-1,-1,L18);
                code.visitLabel(L22);
                code.visitFieldStmt(IGET,8,11,new Field("Lorg/mortbay/jetty/Server;","_graceful","I"));
                code.visitJumpStmt(IF_LEZ,8,-1,L39);
                code.visitLabel(L23);
                code.visitFieldStmt(IGET_OBJECT,8,11,new Field("Lorg/mortbay/jetty/Server;","_connectors","[Lorg/mortbay/jetty/Connector;"));
                code.visitJumpStmt(IF_EQZ,8,-1,L31);
                code.visitLabel(L24);
                code.visitFieldStmt(IGET_OBJECT,8,11,new Field("Lorg/mortbay/jetty/Server;","_connectors","[Lorg/mortbay/jetty/Connector;"));
                code.visitStmt2R(ARRAY_LENGTH,4,8);
                code.visitStmt2R(MOVE,5,4);
                code.visitLabel(L25);
                code.visitStmt3R(SUB_INT,4,5,10);
                code.visitLabel(L26);
                code.visitJumpStmt(IF_LEZ,5,-1,L31);
                code.visitLabel(L27);
                code.visitConstStmt(CONST_STRING,8,"Graceful shutdown {}");
                code.visitFieldStmt(IGET_OBJECT,8,11,new Field("Lorg/mortbay/jetty/Server;","_connectors","[Lorg/mortbay/jetty/Connector;"));
                code.visitStmt3R(AGET_OBJECT,8,8,4);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 9,8},new Method("Lorg/mortbay/log/Log;","info",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,8,11,new Field("Lorg/mortbay/jetty/Server;","_connectors","[Lorg/mortbay/jetty/Connector;"));
                code.visitStmt3R(AGET_OBJECT,8,8,4);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 8},new Method("Lorg/mortbay/jetty/Connector;","close",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitStmt2R(MOVE,5,4);
                code.visitLabel(L28);
                code.visitJumpStmt(GOTO,-1,-1,L25);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,8);
                code.visitStmt2R(MOVE_OBJECT,3,8);
                code.visitLabel(L29);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,3},new Method("Lorg/mortbay/util/MultiException;","add",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitStmt2R(MOVE,5,4);
                code.visitLabel(L30);
                code.visitJumpStmt(GOTO,-1,-1,L25);
                code.visitLabel(L31);
                code.visitConstStmt(CONST_CLASS,8,new DexType("Lorg/mortbay/jetty/Server$Graceful;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11,8},new Method("Lorg/mortbay/jetty/Server;","getChildHandlersByClass",new String[]{ "Ljava/lang/Class;"},"[Lorg/mortbay/jetty/Handler;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L32);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L33);
                code.visitStmt2R(ARRAY_LENGTH,8,2);
                code.visitJumpStmt(IF_GE,0,8,L38);
                code.visitLabel(L34);
                code.visitStmt3R(AGET_OBJECT,1,2,0);
                code.visitTypeStmt(CHECK_CAST,1,-1,"Lorg/mortbay/jetty/Server$Graceful;");
                code.visitLabel(L35);
                code.visitConstStmt(CONST_STRING,8,"Graceful shutdown {}");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 9,1},new Method("Lorg/mortbay/log/Log;","info",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L36);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1,10},new Method("Lorg/mortbay/jetty/Server$Graceful;","setShutdown",new String[]{ "Z"},"V"));
                code.visitLabel(L37);
                code.visitStmt2R1N(ADD_INT_LIT8,0,0,1);
                code.visitJumpStmt(GOTO,-1,-1,L33);
                code.visitLabel(L38);
                code.visitFieldStmt(IGET,8,11,new Field("Lorg/mortbay/jetty/Server;","_graceful","I"));
                code.visitStmt2R(INT_TO_LONG,8,8);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 8,9},new Method("Ljava/lang/Thread;","sleep",new String[]{ "J"},"V"));
                code.visitLabel(L39);
                code.visitFieldStmt(IGET_OBJECT,8,11,new Field("Lorg/mortbay/jetty/Server;","_connectors","[Lorg/mortbay/jetty/Connector;"));
                code.visitJumpStmt(IF_EQZ,8,-1,L6);
                code.visitLabel(L40);
                code.visitFieldStmt(IGET_OBJECT,8,11,new Field("Lorg/mortbay/jetty/Server;","_connectors","[Lorg/mortbay/jetty/Connector;"));
                code.visitStmt2R(ARRAY_LENGTH,4,8);
                code.visitLabel(L41);
                code.visitStmt2R(MOVE,5,4);
                code.visitLabel(L42);
                code.visitStmt3R(SUB_INT,4,5,10);
                code.visitLabel(L43);
                code.visitJumpStmt(IF_LEZ,5,-1,L6);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,8,11,new Field("Lorg/mortbay/jetty/Server;","_connectors","[Lorg/mortbay/jetty/Connector;"));
                code.visitStmt3R(AGET_OBJECT,8,8,4);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 8},new Method("Lorg/mortbay/jetty/Connector;","stop",new String[]{ },"V"));
                code.visitLabel(L4);
                code.visitStmt2R(MOVE,5,4);
                code.visitLabel(L44);
                code.visitJumpStmt(GOTO,-1,-1,L42);
                code.visitLabel(L5);
                code.visitStmt1R(MOVE_EXCEPTION,8);
                code.visitStmt2R(MOVE_OBJECT,3,8);
                code.visitLabel(L45);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,3},new Method("Lorg/mortbay/util/MultiException;","add",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitStmt2R(MOVE,5,4);
                code.visitLabel(L46);
                code.visitJumpStmt(GOTO,-1,-1,L42);
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 11},new Method("Lorg/mortbay/jetty/handler/HandlerWrapper;","doStop",new String[]{ },"V"));
                code.visitLabel(L7);
                code.visitFieldStmt(IGET_OBJECT,8,11,new Field("Lorg/mortbay/jetty/Server;","_sessionIdManager","Lorg/mortbay/jetty/SessionIdManager;"));
                code.visitJumpStmt(IF_EQZ,8,-1,L9);
                code.visitLabel(L47);
                code.visitFieldStmt(IGET_OBJECT,8,11,new Field("Lorg/mortbay/jetty/Server;","_sessionIdManager","Lorg/mortbay/jetty/SessionIdManager;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 8},new Method("Lorg/mortbay/jetty/SessionIdManager;","stop",new String[]{ },"V"));
                code.visitLabel(L9);
                code.visitFieldStmt(IGET_OBJECT,8,11,new Field("Lorg/mortbay/jetty/Server;","_threadPool","Lorg/mortbay/thread/ThreadPool;"));
                code.visitTypeStmt(INSTANCE_OF,8,8,"Lorg/mortbay/component/LifeCycle;");
                code.visitJumpStmt(IF_EQZ,8,-1,L10);
                code.visitLabel(L48);
                code.visitFieldStmt(IGET_OBJECT,8,11,new Field("Lorg/mortbay/jetty/Server;","_threadPool","Lorg/mortbay/thread/ThreadPool;"));
                code.visitTypeStmt(CHECK_CAST,8,-1,"Lorg/mortbay/component/LifeCycle;");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 8},new Method("Lorg/mortbay/component/LifeCycle;","stop",new String[]{ },"V"));
                code.visitLabel(L10);
                code.visitFieldStmt(IGET_OBJECT,8,11,new Field("Lorg/mortbay/jetty/Server;","_dependentLifeCycles","Ljava/util/List;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 8},new Method("Ljava/util/List;","isEmpty",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitJumpStmt(IF_NEZ,8,-1,L54);
                code.visitLabel(L49);
                code.visitFieldStmt(IGET_OBJECT,8,11,new Field("Lorg/mortbay/jetty/Server;","_dependentLifeCycles","Ljava/util/List;"));
                code.visitFieldStmt(IGET_OBJECT,9,11,new Field("Lorg/mortbay/jetty/Server;","_dependentLifeCycles","Ljava/util/List;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 9},new Method("Ljava/util/List;","size",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,9);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 8,9},new Method("Ljava/util/List;","listIterator",new String[]{ "I"},"Ljava/util/ListIterator;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitLabel(L50);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 6},new Method("Ljava/util/ListIterator;","hasPrevious",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitJumpStmt(IF_EQZ,8,-1,L54);
                code.visitLabel(L12);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 6},new Method("Ljava/util/ListIterator;","previous",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,11);
                code.visitTypeStmt(CHECK_CAST,11,-1,"Lorg/mortbay/component/LifeCycle;");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 11},new Method("Lorg/mortbay/component/LifeCycle;","stop",new String[]{ },"V"));
                code.visitLabel(L13);
                code.visitJumpStmt(GOTO,-1,-1,L50);
                code.visitLabel(L14);
                code.visitStmt1R(MOVE_EXCEPTION,8);
                code.visitStmt2R(MOVE_OBJECT,3,8);
                code.visitLabel(L51);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,3},new Method("Lorg/mortbay/util/MultiException;","add",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L50);
                code.visitLabel(L8);
                code.visitStmt1R(MOVE_EXCEPTION,3);
                code.visitLabel(L52);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,3},new Method("Lorg/mortbay/util/MultiException;","add",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L7);
                code.visitLabel(L11);
                code.visitStmt1R(MOVE_EXCEPTION,8);
                code.visitStmt2R(MOVE_OBJECT,3,8);
                code.visitLabel(L53);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,3},new Method("Lorg/mortbay/util/MultiException;","add",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L10);
                code.visitLabel(L54);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Lorg/mortbay/util/MultiException;","ifExceptionThrow",new String[]{ },"V"));
                code.visitLabel(L55);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m011_getAttribute(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Server;","getAttribute",new String[]{ "Ljava/lang/String;"},"Ljava/lang/Object;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(652,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/Server;","_attributes","Lorg/mortbay/util/AttributesMap;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,2},new Method("Lorg/mortbay/util/AttributesMap;","getAttribute",new String[]{ "Ljava/lang/String;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m012_getAttributeNames(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Server;","getAttributeNames",new String[]{ },"Ljava/util/Enumeration;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(661,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/Server;","_attributes","Lorg/mortbay/util/AttributesMap;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/util/AttributesMap;","getAttributeNamesCopy",new String[]{ "Lorg/mortbay/util/Attributes;"},"Ljava/util/Enumeration;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m013_getConnectors(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Server;","getConnectors",new String[]{ },"[Lorg/mortbay/jetty/Connector;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(125,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/Server;","_connectors","[Lorg/mortbay/jetty/Connector;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m014_getContainer(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Server;","getContainer",new String[]{ },"Lorg/mortbay/component/Container;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(101,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/Server;","_container","Lorg/mortbay/component/Container;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m015_getGracefulShutdown(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Server;","getGracefulShutdown",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(688,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,1,new Field("Lorg/mortbay/jetty/Server;","_graceful","I"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m016_getHandlers(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Server;","getHandlers",new String[]{ },"[Lorg/mortbay/jetty/Handler;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(614,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(615,L1);
                DexLabel L2=new DexLabel();
                ddv.visitEndLocal(1,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(617,L3);
                DexLabel L4=new DexLabel();
                ddv.visitRestartLocal(1,L4);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/jetty/Server;","getHandler",new String[]{ },"Lorg/mortbay/jetty/Handler;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitTypeStmt(INSTANCE_OF,0,0,"Lorg/mortbay/jetty/handler/HandlerCollection;");
                code.visitJumpStmt(IF_EQZ,0,-1,L4);
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/jetty/Server;","getHandler",new String[]{ },"Lorg/mortbay/jetty/Handler;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L2);
                code.visitTypeStmt(CHECK_CAST,1,-1,"Lorg/mortbay/jetty/handler/HandlerCollection;");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/jetty/handler/HandlerCollection;","getHandlers",new String[]{ },"[Lorg/mortbay/jetty/Handler;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L3);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L4);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m017_getSendDateHeader(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Server;","getSendDateHeader",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(409,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_BOOLEAN,0,1,new Field("Lorg/mortbay/jetty/Server;","_sendDateHeader","Z"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m018_getSendServerVersion(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Server;","getSendServerVersion",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(394,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_BOOLEAN,0,1,new Field("Lorg/mortbay/jetty/Server;","_sendServerVersion","Z"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m019_getSessionIdManager(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Server;","getSessionIdManager",new String[]{ },"Lorg/mortbay/jetty/SessionIdManager;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(371,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/Server;","_sessionIdManager","Lorg/mortbay/jetty/SessionIdManager;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m020_getStopAtShutdown(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Server;","getStopAtShutdown",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(107,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/Server;","hookThread","Lorg/mortbay/jetty/Server$ShutdownHookThread;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/Server$ShutdownHookThread;","contains",new String[]{ "Lorg/mortbay/jetty/Server;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m021_getThreadPool(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Server;","getThreadPool",new String[]{ },"Lorg/mortbay/thread/ThreadPool;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(168,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/Server;","_threadPool","Lorg/mortbay/thread/ThreadPool;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m022_getUserRealms(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Server;","getUserRealms",new String[]{ },"[Lorg/mortbay/jetty/security/UserRealm;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(339,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/Server;","_realms","[Lorg/mortbay/jetty/security/UserRealm;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m023_handle(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Server;","handle",new String[]{ "Lorg/mortbay/jetty/HttpConnection;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visit(null, new DexType("Ljavax/servlet/ServletException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"connection");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(316,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(317,L2);
                ddv.visitStartLocal(0,L2,"target","Ljava/lang/String;",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(319,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(320,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(321,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(325,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(324,L7);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/jetty/HttpConnection;","getRequest",new String[]{ },"Lorg/mortbay/jetty/Request;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/jetty/Request;","getPathInfo",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/log/Log;","isDebugEnabled",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_EQZ,1,-1,L7);
                code.visitLabel(L3);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,2,"REQUEST ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,0},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitConstStmt(CONST_STRING,2," on ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/jetty/HttpConnection;","getRequest",new String[]{ },"Lorg/mortbay/jetty/Request;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/jetty/HttpConnection;","getResponse",new String[]{ },"Lorg/mortbay/jetty/Response;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,0,1,2,3},new Method("Lorg/mortbay/jetty/Server;","handle",new String[]{ "Ljava/lang/String;","Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;","I"},"V"));
                code.visitLabel(L5);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,2,"RESPONSE ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,0},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitConstStmt(CONST_STRING,2,"  ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/jetty/HttpConnection;","getResponse",new String[]{ },"Lorg/mortbay/jetty/Response;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/Response;","getStatus",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "I"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L6);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/jetty/HttpConnection;","getRequest",new String[]{ },"Lorg/mortbay/jetty/Request;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/jetty/HttpConnection;","getResponse",new String[]{ },"Lorg/mortbay/jetty/Response;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,0,1,2,3},new Method("Lorg/mortbay/jetty/Server;","handle",new String[]{ "Ljava/lang/String;","Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;","I"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L6);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m024_join(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Server;","join",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/InterruptedException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(330,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(331,L1);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/jetty/Server;","getThreadPool",new String[]{ },"Lorg/mortbay/thread/ThreadPool;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Lorg/mortbay/thread/ThreadPool;","join",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m025_removeAttribute(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Server;","removeAttribute",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(670,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(671,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/Server;","_attributes","Lorg/mortbay/util/AttributesMap;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,2},new Method("Lorg/mortbay/util/AttributesMap;","removeAttribute",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m026_removeConnector(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Server;","removeConnector",new String[]{ "Lorg/mortbay/jetty/Connector;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"connector");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(142,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(143,L1);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/jetty/Server;","getConnectors",new String[]{ },"[Lorg/mortbay/jetty/Connector;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,2},new Method("Lorg/mortbay/util/LazyList;","removeFromArray",new String[]{ "[Ljava/lang/Object;","Ljava/lang/Object;"},"[Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitTypeStmt(CHECK_CAST,0,-1,"[Lorg/mortbay/jetty/Connector;");
                code.visitTypeStmt(CHECK_CAST,0,-1,"[Lorg/mortbay/jetty/Connector;");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,0},new Method("Lorg/mortbay/jetty/Server;","setConnectors",new String[]{ "[Lorg/mortbay/jetty/Connector;"},"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m027_removeHandler(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Server;","removeHandler",new String[]{ "Lorg/mortbay/jetty/Handler;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"handler");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(605,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(606,L1);
                DexLabel L2=new DexLabel();
                ddv.visitEndLocal(1,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(607,L3);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/jetty/Server;","getHandler",new String[]{ },"Lorg/mortbay/jetty/Handler;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitTypeStmt(INSTANCE_OF,0,0,"Lorg/mortbay/jetty/handler/HandlerCollection;");
                code.visitJumpStmt(IF_EQZ,0,-1,L3);
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/jetty/Server;","getHandler",new String[]{ },"Lorg/mortbay/jetty/Handler;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L2);
                code.visitTypeStmt(CHECK_CAST,1,-1,"Lorg/mortbay/jetty/handler/HandlerCollection;");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Lorg/mortbay/jetty/handler/HandlerCollection;","removeHandler",new String[]{ "Lorg/mortbay/jetty/Handler;"},"V"));
                code.visitLabel(L3);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m028_removeLifeCycle(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Server;","removeLifeCycle",new String[]{ "Lorg/mortbay/component/LifeCycle;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"c");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(445,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(449,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(447,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(448,L3);
                code.visitLabel(L0);
                code.visitJumpStmt(IF_NEZ,2,-1,L2);
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/Server;","_dependentLifeCycles","Ljava/util/List;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,2},new Method("Ljava/util/List;","remove",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/Server;","_container","Lorg/mortbay/component/Container;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,2},new Method("Lorg/mortbay/component/Container;","removeBean",new String[]{ "Ljava/lang/Object;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m029_removeUserRealm(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Server;","removeUserRealm",new String[]{ "Lorg/mortbay/jetty/security/UserRealm;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"realm");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(361,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(362,L1);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/jetty/Server;","getUserRealms",new String[]{ },"[Lorg/mortbay/jetty/security/UserRealm;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,2},new Method("Lorg/mortbay/util/LazyList;","removeFromArray",new String[]{ "[Ljava/lang/Object;","Ljava/lang/Object;"},"[Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitTypeStmt(CHECK_CAST,0,-1,"[Lorg/mortbay/jetty/security/UserRealm;");
                code.visitTypeStmt(CHECK_CAST,0,-1,"[Lorg/mortbay/jetty/security/UserRealm;");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,0},new Method("Lorg/mortbay/jetty/Server;","setUserRealms",new String[]{ "[Lorg/mortbay/jetty/security/UserRealm;"},"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m030_setAttribute(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Server;","setAttribute",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                ddv.visitParameterName(1,"attribute");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(679,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(680,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/Server;","_attributes","Lorg/mortbay/util/AttributesMap;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,2,3},new Method("Lorg/mortbay/util/AttributesMap;","setAttribute",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m031_setConnectors(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Server;","setConnectors",new String[]{ "[Lorg/mortbay/jetty/Connector;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"connectors");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(152,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(154,L1);
                DexLabel L2=new DexLabel();
                ddv.visitStartLocal(0,L2,"i","I",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(155,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(154,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(158,L5);
                ddv.visitEndLocal(0,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(159,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(160,L7);
                code.visitLabel(L0);
                code.visitJumpStmt(IF_EQZ,5,-1,L5);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L2);
                code.visitStmt2R(ARRAY_LENGTH,1,5);
                code.visitJumpStmt(IF_GE,0,1,L5);
                code.visitLabel(L3);
                code.visitStmt3R(AGET_OBJECT,1,5,0);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1,4},new Method("Lorg/mortbay/jetty/Connector;","setServer",new String[]{ "Lorg/mortbay/jetty/Server;"},"V"));
                code.visitLabel(L4);
                code.visitStmt2R1N(ADD_INT_LIT8,0,0,1);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/jetty/Server;","_container","Lorg/mortbay/component/Container;"));
                code.visitFieldStmt(IGET_OBJECT,2,4,new Field("Lorg/mortbay/jetty/Server;","_connectors","[Lorg/mortbay/jetty/Connector;"));
                code.visitConstStmt(CONST_STRING,3,"connector");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,4,2,5,3},new Method("Lorg/mortbay/component/Container;","update",new String[]{ "Ljava/lang/Object;","[Ljava/lang/Object;","[Ljava/lang/Object;","Ljava/lang/String;"},"V"));
                code.visitLabel(L6);
                code.visitFieldStmt(IPUT_OBJECT,5,4,new Field("Lorg/mortbay/jetty/Server;","_connectors","[Lorg/mortbay/jetty/Connector;"));
                code.visitLabel(L7);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m032_setGracefulShutdown(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Server;","setGracefulShutdown",new String[]{ "I"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"timeoutMS");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(703,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(704,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT,1,0,new Field("Lorg/mortbay/jetty/Server;","_graceful","I"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m033_setHandlers(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Server;","setHandlers",new String[]{ "[Lorg/mortbay/jetty/Handler;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"handlers");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(626,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(627,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(634,L2);
                ddv.visitStartLocal(0,L2,"collection","Lorg/mortbay/jetty/handler/HandlerCollection;",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(635,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(630,L4);
                ddv.visitEndLocal(0,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(631,L5);
                ddv.visitRestartLocal(0,L5);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/Server;","getHandler",new String[]{ },"Lorg/mortbay/jetty/Handler;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitTypeStmt(INSTANCE_OF,1,1,"Lorg/mortbay/jetty/handler/HandlerCollection;");
                code.visitJumpStmt(IF_EQZ,1,-1,L4);
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/Server;","getHandler",new String[]{ },"Lorg/mortbay/jetty/Handler;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Lorg/mortbay/jetty/handler/HandlerCollection;");
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,3},new Method("Lorg/mortbay/jetty/handler/HandlerCollection;","setHandlers",new String[]{ "[Lorg/mortbay/jetty/Handler;"},"V"));
                code.visitLabel(L3);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L4);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/jetty/handler/HandlerCollection;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Lorg/mortbay/jetty/handler/HandlerCollection;","<init>",new String[]{ },"V"));
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,0},new Method("Lorg/mortbay/jetty/Server;","setHandler",new String[]{ "Lorg/mortbay/jetty/Handler;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m034_setSendDateHeader(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Server;","setSendDateHeader",new String[]{ "Z"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"sendDateHeader");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(403,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(404,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_BOOLEAN,1,0,new Field("Lorg/mortbay/jetty/Server;","_sendDateHeader","Z"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m035_setSendServerVersion(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Server;","setSendServerVersion",new String[]{ "Z"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"sendServerVersion");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(388,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(389,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_BOOLEAN,1,0,new Field("Lorg/mortbay/jetty/Server;","_sendServerVersion","Z"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m036_setSessionIdManager(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Server;","setSessionIdManager",new String[]{ "Lorg/mortbay/jetty/SessionIdManager;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(8);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"sessionIdManager");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(381,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(382,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(383,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,6,new Field("Lorg/mortbay/jetty/Server;","_container","Lorg/mortbay/component/Container;"));
                code.visitFieldStmt(IGET_OBJECT,2,6,new Field("Lorg/mortbay/jetty/Server;","_sessionIdManager","Lorg/mortbay/jetty/SessionIdManager;"));
                code.visitConstStmt(CONST_STRING,4,"sessionIdManager");
                code.visitConstStmt(CONST_4,5, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt2R(MOVE_OBJECT,1,6);
                code.visitStmt2R(MOVE_OBJECT,3,7);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 0,1,2,3,4,5},new Method("Lorg/mortbay/component/Container;","update",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;","Ljava/lang/Object;","Ljava/lang/String;","Z"},"V"));
                code.visitLabel(L1);
                code.visitFieldStmt(IPUT_OBJECT,7,6,new Field("Lorg/mortbay/jetty/Server;","_sessionIdManager","Lorg/mortbay/jetty/SessionIdManager;"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m037_setStopAtShutdown(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Server;","setStopAtShutdown",new String[]{ "Z"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"stop");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(113,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(114,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(117,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(116,L3);
                code.visitLabel(L0);
                code.visitJumpStmt(IF_EQZ,2,-1,L3);
                code.visitLabel(L1);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/Server;","hookThread","Lorg/mortbay/jetty/Server$ShutdownHookThread;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/Server$ShutdownHookThread;","add",new String[]{ "Lorg/mortbay/jetty/Server;"},"Z"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L3);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/Server;","hookThread","Lorg/mortbay/jetty/Server$ShutdownHookThread;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/Server$ShutdownHookThread;","remove",new String[]{ "Lorg/mortbay/jetty/Server;"},"Z"));
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m038_setThreadPool(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Server;","setThreadPool",new String[]{ "Lorg/mortbay/thread/ThreadPool;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(8);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"threadPool");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(177,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(178,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(179,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,6,new Field("Lorg/mortbay/jetty/Server;","_container","Lorg/mortbay/component/Container;"));
                code.visitFieldStmt(IGET_OBJECT,2,6,new Field("Lorg/mortbay/jetty/Server;","_threadPool","Lorg/mortbay/thread/ThreadPool;"));
                code.visitConstStmt(CONST_STRING,4,"threadpool");
                code.visitConstStmt(CONST_4,5, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt2R(MOVE_OBJECT,1,6);
                code.visitStmt2R(MOVE_OBJECT,3,7);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 0,1,2,3,4,5},new Method("Lorg/mortbay/component/Container;","update",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;","Ljava/lang/Object;","Ljava/lang/String;","Z"},"V"));
                code.visitLabel(L1);
                code.visitFieldStmt(IPUT_OBJECT,7,6,new Field("Lorg/mortbay/jetty/Server;","_threadPool","Lorg/mortbay/thread/ThreadPool;"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m039_setUserRealms(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Server;","setUserRealms",new String[]{ "[Lorg/mortbay/jetty/security/UserRealm;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(8);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"realms");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(348,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(349,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(350,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,6,new Field("Lorg/mortbay/jetty/Server;","_container","Lorg/mortbay/component/Container;"));
                code.visitFieldStmt(IGET_OBJECT,2,6,new Field("Lorg/mortbay/jetty/Server;","_realms","[Lorg/mortbay/jetty/security/UserRealm;"));
                code.visitConstStmt(CONST_STRING,4,"realm");
                code.visitConstStmt(CONST_4,5, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt2R(MOVE_OBJECT,1,6);
                code.visitStmt2R(MOVE_OBJECT,3,7);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 0,1,2,3,4,5},new Method("Lorg/mortbay/component/Container;","update",new String[]{ "Ljava/lang/Object;","[Ljava/lang/Object;","[Ljava/lang/Object;","Ljava/lang/String;","Z"},"V"));
                code.visitLabel(L1);
                code.visitFieldStmt(IPUT_OBJECT,7,6,new Field("Lorg/mortbay/jetty/Server;","_realms","[Lorg/mortbay/jetty/security/UserRealm;"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
