package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0129_org_mortbay_io_nio_IndirectNIOBuffer {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/io/nio/IndirectNIOBuffer;","Lorg/mortbay/io/ByteArrayBuffer;",new String[]{ "Lorg/mortbay/io/nio/NIOBuffer;"});
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("IndirectNIOBuffer.java");
        f000__buf(cv);
        m000__init_(cv);
        m001__init_(cv);
        m002_getByteBuffer(cv);
        m003_isDirect(cv);
    }
    public static void f000__buf(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/io/nio/IndirectNIOBuffer;","_buf","Ljava/nio/ByteBuffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/io/nio/IndirectNIOBuffer;","<init>",new String[]{ "I"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"size");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(27,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(28,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(29,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(30,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(31,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(32,L6);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2,0,1},new Method("Lorg/mortbay/io/ByteArrayBuffer;","<init>",new String[]{ "I","Z"},"V"));
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3},new Method("Ljava/nio/ByteBuffer;","allocate",new String[]{ "I"},"Ljava/nio/ByteBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/io/nio/IndirectNIOBuffer;","_buf","Ljava/nio/ByteBuffer;"));
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/io/nio/IndirectNIOBuffer;","_buf","Ljava/nio/ByteBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/nio/ByteBuffer;","position",new String[]{ "I"},"Ljava/nio/Buffer;"));
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/io/nio/IndirectNIOBuffer;","_buf","Ljava/nio/ByteBuffer;"));
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/io/nio/IndirectNIOBuffer;","_buf","Ljava/nio/ByteBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/nio/ByteBuffer;","capacity",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/nio/ByteBuffer;","limit",new String[]{ "I"},"Ljava/nio/Buffer;"));
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/io/nio/IndirectNIOBuffer;","_buf","Ljava/nio/ByteBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/nio/ByteBuffer;","array",new String[]{ },"[B"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/io/nio/IndirectNIOBuffer;","_bytes","[B"));
                code.visitLabel(L6);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/io/nio/IndirectNIOBuffer;","<init>",new String[]{ "Ljava/nio/ByteBuffer;","Z"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"buffer");
                ddv.visitParameterName(1,"immutable");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(37,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(38,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(39,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(37,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(40,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(41,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(42,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(43,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(44,L9);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitJumpStmt(IF_EQZ,4,-1,L4);
                code.visitStmt2R(MOVE,0,1);
                DexLabel L10=new DexLabel();
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2,0,1},new Method("Lorg/mortbay/io/ByteArrayBuffer;","<init>",new String[]{ "I","Z"},"V"));
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/nio/ByteBuffer;","isDirect",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L5);
                code.visitLabel(L3);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/IllegalArgumentException;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/IllegalArgumentException;","<init>",new String[]{ },"V"));
                code.visitStmt1R(THROW,0);
                code.visitLabel(L4);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L10);
                code.visitLabel(L5);
                code.visitFieldStmt(IPUT_OBJECT,3,2,new Field("Lorg/mortbay/io/nio/IndirectNIOBuffer;","_buf","Ljava/nio/ByteBuffer;"));
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/nio/ByteBuffer;","position",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,0},new Method("Lorg/mortbay/io/nio/IndirectNIOBuffer;","setGetIndex",new String[]{ "I"},"V"));
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/nio/ByteBuffer;","limit",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,0},new Method("Lorg/mortbay/io/nio/IndirectNIOBuffer;","setPutIndex",new String[]{ "I"},"V"));
                code.visitLabel(L8);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/io/nio/IndirectNIOBuffer;","_buf","Ljava/nio/ByteBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/nio/ByteBuffer;","array",new String[]{ },"[B"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/io/nio/IndirectNIOBuffer;","_bytes","[B"));
                code.visitLabel(L9);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_getByteBuffer(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/nio/IndirectNIOBuffer;","getByteBuffer",new String[]{ },"Ljava/nio/ByteBuffer;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(49,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/io/nio/IndirectNIOBuffer;","_buf","Ljava/nio/ByteBuffer;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_isDirect(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/nio/IndirectNIOBuffer;","isDirect",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(55,L0);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
