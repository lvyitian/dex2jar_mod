package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0079_org_mortbay_ijetty_R_id {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC|ACC_FINAL,"Lorg/mortbay/ijetty/R$id;","Ljava/lang/Object;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("R.java");
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/EnclosingClass;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("value", new DexType("Lorg/mortbay/ijetty/R;"));
                av00.visitEnd();
            }
        }
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/InnerClass;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("accessFlags",  Integer.valueOf(25));
                av00.visit("name", "id");
                av00.visitEnd();
            }
        }
        f000_config(cv);
        f001_context_path(cv);
        f002_download(cv);
        f003_download_url(cv);
        f004_heading(cv);
        f005_list(cv);
        f006_loading(cv);
        f007_progress(cv);
        f008_start(cv);
        f009_start_download(cv);
        f010_stop(cv);
        m000__init_(cv);
    }
    public static void f000_config(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/ijetty/R$id;","config","I"),  Integer.valueOf(2131165187));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001_context_path(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/ijetty/R$id;","context_path","I"),  Integer.valueOf(2131165191));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002_download(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/ijetty/R$id;","download","I"),  Integer.valueOf(2131165188));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003_download_url(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/ijetty/R$id;","download_url","I"),  Integer.valueOf(2131165190));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f004_heading(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/ijetty/R$id;","heading","I"),  Integer.valueOf(2131165184));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f005_list(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/ijetty/R$id;","list","I"),  Integer.valueOf(2131165189));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f006_loading(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/ijetty/R$id;","loading","I"),  Integer.valueOf(2131165194));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f007_progress(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/ijetty/R$id;","progress","I"),  Integer.valueOf(2131165193));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f008_start(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/ijetty/R$id;","start","I"),  Integer.valueOf(2131165185));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f009_start_download(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/ijetty/R$id;","start_download","I"),  Integer.valueOf(2131165192));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f010_stop(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/ijetty/R$id;","stop","I"),  Integer.valueOf(2131165186));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/ijetty/R$id;","<init>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(18,L0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/Object;","<init>",new String[]{ },"V"));
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
