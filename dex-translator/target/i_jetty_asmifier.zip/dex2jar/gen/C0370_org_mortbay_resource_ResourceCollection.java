package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0370_org_mortbay_resource_ResourceCollection {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/resource/ResourceCollection;","Lorg/mortbay/resource/Resource;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("ResourceCollection.java");
        f000__resources(cv);
        m000__init_(cv);
        m001__init_(cv);
        m002__init_(cv);
        m003__init_(cv);
        m004_addPath(cv);
        m005_delete(cv);
        m006_exists(cv);
        m007_findResource(cv);
        m008_getFile(cv);
        m009_getInputStream(cv);
        m010_getName(cv);
        m011_getOutputStream(cv);
        m012_getResources(cv);
        m013_getURL(cv);
        m014_isDirectory(cv);
        m015_lastModified(cv);
        m016_length(cv);
        m017_list(cv);
        m018_release(cv);
        m019_renameTo(cv);
        m020_setResources(cv);
        m021_setResources(cv);
        m022_setResources(cv);
        m023_setResourcesAsCSV(cv);
        m024_toString(cv);
    }
    public static void f000__resources(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/resource/ResourceCollection;","_resources","[Lorg/mortbay/resource/Resource;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/resource/ResourceCollection;","<init>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(45,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(47,L1);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Lorg/mortbay/resource/Resource;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/resource/ResourceCollection;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"csvResources");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(63,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(64,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(65,L2);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Lorg/mortbay/resource/Resource;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/resource/ResourceCollection;","setResources",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/resource/ResourceCollection;","<init>",new String[]{ "[Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"resources");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(57,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(58,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(59,L2);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Lorg/mortbay/resource/Resource;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/resource/ResourceCollection;","setResources",new String[]{ "[Ljava/lang/String;"},"V"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/resource/ResourceCollection;","<init>",new String[]{ "[Lorg/mortbay/resource/Resource;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"resources");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(51,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(52,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(53,L2);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Lorg/mortbay/resource/Resource;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/resource/ResourceCollection;","setResources",new String[]{ "[Lorg/mortbay/resource/Resource;"},"V"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_addPath(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/resource/ResourceCollection;","addPath",new String[]{ "Ljava/lang/String;"},"Lorg/mortbay/resource/Resource;"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visit(null, new DexType("Ljava/net/MalformedURLException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(8);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"path");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(185,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(186,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(188,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(189,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(191,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(227,L5);
                ddv.visitEndLocal(6,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(194,L6);
                ddv.visitRestartLocal(6,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(195,L7);
                ddv.visitStartLocal(2,L7,"resource","Lorg/mortbay/resource/Resource;",null);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(196,L8);
                ddv.visitStartLocal(3,L8,"resources","Ljava/util/ArrayList;",null);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(197,L9);
                ddv.visitStartLocal(0,L9,"i","I",null);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(199,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(200,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(202,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(208,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(210,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(211,L15);
                ddv.visitStartLocal(1,L15,"r","Lorg/mortbay/resource/Resource;",null);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(213,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(215,L17);
                DexLabel L18=new DexLabel();
                ddv.visitEndLocal(3,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(216,L19);
                ddv.visitRestartLocal(3,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(217,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(219,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(208,L22);
                DexLabel L23=new DexLabel();
                ddv.visitEndLocal(1,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(204,L24);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(197,L25);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(223,L26);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(224,L27);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(225,L28);
                DexLabel L29=new DexLabel();
                ddv.visitLineNumber(226,L29);
                DexLabel L30=new DexLabel();
                ddv.visitEndLocal(6,L30);
                DexLabel L31=new DexLabel();
                ddv.visitLineNumber(227,L31);
                ddv.visitRestartLocal(6,L31);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,4,6,new Field("Lorg/mortbay/resource/ResourceCollection;","_resources","[Lorg/mortbay/resource/Resource;"));
                code.visitJumpStmt(IF_NEZ,4,-1,L2);
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,4,-1,"Ljava/lang/IllegalStateException;");
                code.visitConstStmt(CONST_STRING,5,"*resources* not set.");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4,5},new Method("Ljava/lang/IllegalStateException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,4);
                code.visitLabel(L2);
                code.visitJumpStmt(IF_NEZ,7,-1,L4);
                code.visitLabel(L3);
                code.visitTypeStmt(NEW_INSTANCE,4,-1,"Ljava/net/MalformedURLException;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4},new Method("Ljava/net/MalformedURLException;","<init>",new String[]{ },"V"));
                code.visitStmt1R(THROW,4);
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,4);
                DexLabel L32=new DexLabel();
                code.visitJumpStmt(IF_EQZ,4,-1,L32);
                code.visitConstStmt(CONST_STRING,4,"/");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,7},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitJumpStmt(IF_EQZ,4,-1,L6);
                code.visitLabel(L32);
                code.visitStmt2R(MOVE_OBJECT,4,6);
                code.visitLabel(L5);
                code.visitStmt1R(RETURN_OBJECT,4);
                code.visitLabel(L6);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L7);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L8);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L9);
                code.visitFieldStmt(IGET_OBJECT,4,6,new Field("Lorg/mortbay/resource/ResourceCollection;","_resources","[Lorg/mortbay/resource/Resource;"));
                code.visitStmt2R(ARRAY_LENGTH,4,4);
                code.visitJumpStmt(IF_GE,0,4,L13);
                code.visitLabel(L10);
                code.visitFieldStmt(IGET_OBJECT,4,6,new Field("Lorg/mortbay/resource/ResourceCollection;","_resources","[Lorg/mortbay/resource/Resource;"));
                code.visitStmt3R(AGET_OBJECT,4,4,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,7},new Method("Lorg/mortbay/resource/Resource;","addPath",new String[]{ "Ljava/lang/String;"},"Lorg/mortbay/resource/Resource;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L11);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/resource/Resource;","exists",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitJumpStmt(IF_EQZ,4,-1,L25);
                code.visitLabel(L12);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/resource/Resource;","isDirectory",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitJumpStmt(IF_EQZ,4,-1,L23);
                code.visitLabel(L13);
                code.visitStmt2R1N(ADD_INT_LIT8,0,0,1);
                DexLabel L33=new DexLabel();
                code.visitLabel(L33);
                code.visitFieldStmt(IGET_OBJECT,4,6,new Field("Lorg/mortbay/resource/ResourceCollection;","_resources","[Lorg/mortbay/resource/Resource;"));
                code.visitStmt2R(ARRAY_LENGTH,4,4);
                code.visitJumpStmt(IF_GE,0,4,L26);
                code.visitLabel(L14);
                code.visitFieldStmt(IGET_OBJECT,4,6,new Field("Lorg/mortbay/resource/ResourceCollection;","_resources","[Lorg/mortbay/resource/Resource;"));
                code.visitStmt3R(AGET_OBJECT,4,4,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,7},new Method("Lorg/mortbay/resource/Resource;","addPath",new String[]{ "Ljava/lang/String;"},"Lorg/mortbay/resource/Resource;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L15);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/resource/Resource;","exists",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitJumpStmt(IF_EQZ,4,-1,L22);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/resource/Resource;","isDirectory",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitJumpStmt(IF_EQZ,4,-1,L22);
                code.visitLabel(L16);
                code.visitJumpStmt(IF_EQZ,2,-1,L21);
                code.visitLabel(L17);
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Ljava/util/ArrayList;");
                code.visitLabel(L18);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3},new Method("Ljava/util/ArrayList;","<init>",new String[]{ },"V"));
                code.visitLabel(L19);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,2},new Method("Ljava/util/ArrayList;","add",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitLabel(L20);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L21);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,1},new Method("Ljava/util/ArrayList;","add",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitLabel(L22);
                code.visitStmt2R1N(ADD_INT_LIT8,0,0,1);
                code.visitJumpStmt(GOTO,-1,-1,L33);
                code.visitLabel(L23);
                code.visitStmt2R(MOVE_OBJECT,4,2);
                code.visitLabel(L24);
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitLabel(L25);
                code.visitStmt2R1N(ADD_INT_LIT8,0,0,1);
                code.visitJumpStmt(GOTO,-1,-1,L9);
                code.visitLabel(L26);
                code.visitJumpStmt(IF_EQZ,2,-1,L28);
                code.visitStmt2R(MOVE_OBJECT,4,2);
                code.visitLabel(L27);
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitLabel(L28);
                code.visitJumpStmt(IF_EQZ,3,-1,L31);
                code.visitLabel(L29);
                code.visitTypeStmt(NEW_INSTANCE,4,-1,"Lorg/mortbay/resource/ResourceCollection;");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/util/ArrayList;","size",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitTypeStmt(NEW_ARRAY,5,5,"[Lorg/mortbay/resource/Resource;");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,5},new Method("Ljava/util/ArrayList;","toArray",new String[]{ "[Ljava/lang/Object;"},"[Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitLabel(L30);
                code.visitTypeStmt(CHECK_CAST,6,-1,"[Lorg/mortbay/resource/Resource;");
                code.visitTypeStmt(CHECK_CAST,6,-1,"[Lorg/mortbay/resource/Resource;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4,6},new Method("Lorg/mortbay/resource/ResourceCollection;","<init>",new String[]{ "[Lorg/mortbay/resource/Resource;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitLabel(L31);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_delete(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/resource/ResourceCollection;","delete",new String[]{ },"Z"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/SecurityException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(278,L0);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/UnsupportedOperationException;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/UnsupportedOperationException;","<init>",new String[]{ },"V"));
                code.visitStmt1R(THROW,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_exists(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/resource/ResourceCollection;","exists",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(284,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(285,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(287,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/resource/ResourceCollection;","_resources","[Lorg/mortbay/resource/Resource;"));
                code.visitJumpStmt(IF_NEZ,0,-1,L2);
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/IllegalStateException;");
                code.visitConstStmt(CONST_STRING,1,"*resources* not set.");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Ljava/lang/IllegalStateException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,0);
                code.visitLabel(L2);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m007_findResource(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/resource/ResourceCollection;","findResource",new String[]{ "Ljava/lang/String;"},"Ljava/lang/Object;"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visit(null, new DexType("Ljava/net/MalformedURLException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"path");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(239,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(240,L1);
                ddv.visitStartLocal(2,L1,"resource","Lorg/mortbay/resource/Resource;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(241,L2);
                ddv.visitStartLocal(3,L2,"resources","Ljava/util/ArrayList;",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(242,L3);
                ddv.visitStartLocal(0,L3,"i","I",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(244,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(245,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(247,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(254,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(256,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(257,L9);
                ddv.visitStartLocal(1,L9,"r","Lorg/mortbay/resource/Resource;",null);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(259,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(261,L11);
                DexLabel L12=new DexLabel();
                ddv.visitEndLocal(3,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(262,L13);
                ddv.visitRestartLocal(3,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(264,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(254,L15);
                DexLabel L16=new DexLabel();
                ddv.visitEndLocal(1,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(272,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(242,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(268,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(269,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(270,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(271,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(272,L23);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L2);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,4,5,new Field("Lorg/mortbay/resource/ResourceCollection;","_resources","[Lorg/mortbay/resource/Resource;"));
                code.visitStmt2R(ARRAY_LENGTH,4,4);
                code.visitJumpStmt(IF_GE,0,4,L7);
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,4,5,new Field("Lorg/mortbay/resource/ResourceCollection;","_resources","[Lorg/mortbay/resource/Resource;"));
                code.visitStmt3R(AGET_OBJECT,4,4,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,6},new Method("Lorg/mortbay/resource/Resource;","addPath",new String[]{ "Ljava/lang/String;"},"Lorg/mortbay/resource/Resource;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/resource/Resource;","exists",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitJumpStmt(IF_EQZ,4,-1,L18);
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/resource/Resource;","isDirectory",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitJumpStmt(IF_EQZ,4,-1,L16);
                code.visitLabel(L7);
                code.visitStmt2R1N(ADD_INT_LIT8,0,0,1);
                DexLabel L24=new DexLabel();
                code.visitLabel(L24);
                code.visitFieldStmt(IGET_OBJECT,4,5,new Field("Lorg/mortbay/resource/ResourceCollection;","_resources","[Lorg/mortbay/resource/Resource;"));
                code.visitStmt2R(ARRAY_LENGTH,4,4);
                code.visitJumpStmt(IF_GE,0,4,L19);
                code.visitLabel(L8);
                code.visitFieldStmt(IGET_OBJECT,4,5,new Field("Lorg/mortbay/resource/ResourceCollection;","_resources","[Lorg/mortbay/resource/Resource;"));
                code.visitStmt3R(AGET_OBJECT,4,4,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,6},new Method("Lorg/mortbay/resource/Resource;","addPath",new String[]{ "Ljava/lang/String;"},"Lorg/mortbay/resource/Resource;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/resource/Resource;","exists",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitJumpStmt(IF_EQZ,4,-1,L15);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/resource/Resource;","isDirectory",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitJumpStmt(IF_EQZ,4,-1,L15);
                code.visitLabel(L10);
                code.visitJumpStmt(IF_EQZ,2,-1,L14);
                code.visitLabel(L11);
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Ljava/util/ArrayList;");
                code.visitLabel(L12);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3},new Method("Ljava/util/ArrayList;","<init>",new String[]{ },"V"));
                code.visitLabel(L13);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,2},new Method("Ljava/util/ArrayList;","add",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitLabel(L14);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,1},new Method("Ljava/util/ArrayList;","add",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitLabel(L15);
                code.visitStmt2R1N(ADD_INT_LIT8,0,0,1);
                code.visitJumpStmt(GOTO,-1,-1,L24);
                code.visitLabel(L16);
                code.visitStmt2R(MOVE_OBJECT,4,2);
                code.visitLabel(L17);
                code.visitStmt1R(RETURN_OBJECT,4);
                code.visitLabel(L18);
                code.visitStmt2R1N(ADD_INT_LIT8,0,0,1);
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitLabel(L19);
                code.visitJumpStmt(IF_EQZ,2,-1,L21);
                code.visitStmt2R(MOVE_OBJECT,4,2);
                code.visitLabel(L20);
                code.visitJumpStmt(GOTO,-1,-1,L17);
                code.visitLabel(L21);
                code.visitJumpStmt(IF_EQZ,3,-1,L23);
                code.visitStmt2R(MOVE_OBJECT,4,3);
                code.visitLabel(L22);
                code.visitJumpStmt(GOTO,-1,-1,L17);
                code.visitLabel(L23);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L17);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m008_getFile(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/resource/ResourceCollection;","getFile",new String[]{ },"Ljava/io/File;"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(293,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(294,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(296,L2);
                DexLabel L3=new DexLabel();
                ddv.visitStartLocal(1,L3,"i","I",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(298,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(299,L5);
                ddv.visitStartLocal(0,L5,"f","Ljava/io/File;",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(302,L6);
                ddv.visitEndLocal(0,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(296,L7);
                ddv.visitRestartLocal(0,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(302,L8);
                ddv.visitEndLocal(0,L8);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,2,4,new Field("Lorg/mortbay/resource/ResourceCollection;","_resources","[Lorg/mortbay/resource/Resource;"));
                code.visitJumpStmt(IF_NEZ,2,-1,L2);
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Ljava/lang/IllegalStateException;");
                code.visitConstStmt(CONST_STRING,3,"*resources* not set.");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2,3},new Method("Ljava/lang/IllegalStateException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,2);
                code.visitLabel(L2);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,2,4,new Field("Lorg/mortbay/resource/ResourceCollection;","_resources","[Lorg/mortbay/resource/Resource;"));
                code.visitStmt2R(ARRAY_LENGTH,2,2);
                code.visitJumpStmt(IF_GE,1,2,L8);
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,2,4,new Field("Lorg/mortbay/resource/ResourceCollection;","_resources","[Lorg/mortbay/resource/Resource;"));
                code.visitStmt3R(AGET_OBJECT,2,2,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/resource/Resource;","getFile",new String[]{ },"Ljava/io/File;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L5);
                code.visitJumpStmt(IF_EQZ,0,-1,L7);
                code.visitStmt2R(MOVE_OBJECT,2,0);
                code.visitLabel(L6);
                code.visitStmt1R(RETURN_OBJECT,2);
                code.visitLabel(L7);
                code.visitStmt2R1N(ADD_INT_LIT8,1,1,1);
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitLabel(L8);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L6);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m009_getInputStream(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/resource/ResourceCollection;","getInputStream",new String[]{ },"Ljava/io/InputStream;"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(308,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(309,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(311,L2);
                DexLabel L3=new DexLabel();
                ddv.visitStartLocal(0,L3,"i","I",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(313,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(314,L5);
                ddv.visitStartLocal(1,L5,"is","Ljava/io/InputStream;",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(317,L6);
                ddv.visitEndLocal(1,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(311,L7);
                ddv.visitRestartLocal(1,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(317,L8);
                ddv.visitEndLocal(1,L8);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,2,4,new Field("Lorg/mortbay/resource/ResourceCollection;","_resources","[Lorg/mortbay/resource/Resource;"));
                code.visitJumpStmt(IF_NEZ,2,-1,L2);
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Ljava/lang/IllegalStateException;");
                code.visitConstStmt(CONST_STRING,3,"*resources* not set.");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2,3},new Method("Ljava/lang/IllegalStateException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,2);
                code.visitLabel(L2);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,2,4,new Field("Lorg/mortbay/resource/ResourceCollection;","_resources","[Lorg/mortbay/resource/Resource;"));
                code.visitStmt2R(ARRAY_LENGTH,2,2);
                code.visitJumpStmt(IF_GE,0,2,L8);
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,2,4,new Field("Lorg/mortbay/resource/ResourceCollection;","_resources","[Lorg/mortbay/resource/Resource;"));
                code.visitStmt3R(AGET_OBJECT,2,2,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/resource/Resource;","getInputStream",new String[]{ },"Ljava/io/InputStream;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L5);
                code.visitJumpStmt(IF_EQZ,1,-1,L7);
                code.visitStmt2R(MOVE_OBJECT,2,1);
                code.visitLabel(L6);
                code.visitStmt1R(RETURN_OBJECT,2);
                code.visitLabel(L7);
                code.visitStmt2R1N(ADD_INT_LIT8,0,0,1);
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitLabel(L8);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L6);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m010_getName(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/resource/ResourceCollection;","getName",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(323,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(324,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(326,L2);
                DexLabel L3=new DexLabel();
                ddv.visitStartLocal(0,L3,"i","I",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(328,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(329,L5);
                ddv.visitStartLocal(1,L5,"name","Ljava/lang/String;",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(332,L6);
                ddv.visitEndLocal(1,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(326,L7);
                ddv.visitRestartLocal(1,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(332,L8);
                ddv.visitEndLocal(1,L8);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,2,4,new Field("Lorg/mortbay/resource/ResourceCollection;","_resources","[Lorg/mortbay/resource/Resource;"));
                code.visitJumpStmt(IF_NEZ,2,-1,L2);
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Ljava/lang/IllegalStateException;");
                code.visitConstStmt(CONST_STRING,3,"*resources* not set.");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2,3},new Method("Ljava/lang/IllegalStateException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,2);
                code.visitLabel(L2);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,2,4,new Field("Lorg/mortbay/resource/ResourceCollection;","_resources","[Lorg/mortbay/resource/Resource;"));
                code.visitStmt2R(ARRAY_LENGTH,2,2);
                code.visitJumpStmt(IF_GE,0,2,L8);
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,2,4,new Field("Lorg/mortbay/resource/ResourceCollection;","_resources","[Lorg/mortbay/resource/Resource;"));
                code.visitStmt3R(AGET_OBJECT,2,2,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/resource/Resource;","getName",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L5);
                code.visitJumpStmt(IF_EQZ,1,-1,L7);
                code.visitStmt2R(MOVE_OBJECT,2,1);
                code.visitLabel(L6);
                code.visitStmt1R(RETURN_OBJECT,2);
                code.visitLabel(L7);
                code.visitStmt2R1N(ADD_INT_LIT8,0,0,1);
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitLabel(L8);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L6);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m011_getOutputStream(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/resource/ResourceCollection;","getOutputStream",new String[]{ },"Ljava/io/OutputStream;"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visit(null, new DexType("Ljava/lang/SecurityException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(338,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(339,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(341,L2);
                DexLabel L3=new DexLabel();
                ddv.visitStartLocal(0,L3,"i","I",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(343,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(344,L5);
                ddv.visitStartLocal(1,L5,"os","Ljava/io/OutputStream;",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(347,L6);
                ddv.visitEndLocal(1,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(341,L7);
                ddv.visitRestartLocal(1,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(347,L8);
                ddv.visitEndLocal(1,L8);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,2,4,new Field("Lorg/mortbay/resource/ResourceCollection;","_resources","[Lorg/mortbay/resource/Resource;"));
                code.visitJumpStmt(IF_NEZ,2,-1,L2);
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Ljava/lang/IllegalStateException;");
                code.visitConstStmt(CONST_STRING,3,"*resources* not set.");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2,3},new Method("Ljava/lang/IllegalStateException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,2);
                code.visitLabel(L2);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,2,4,new Field("Lorg/mortbay/resource/ResourceCollection;","_resources","[Lorg/mortbay/resource/Resource;"));
                code.visitStmt2R(ARRAY_LENGTH,2,2);
                code.visitJumpStmt(IF_GE,0,2,L8);
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,2,4,new Field("Lorg/mortbay/resource/ResourceCollection;","_resources","[Lorg/mortbay/resource/Resource;"));
                code.visitStmt3R(AGET_OBJECT,2,2,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/resource/Resource;","getOutputStream",new String[]{ },"Ljava/io/OutputStream;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L5);
                code.visitJumpStmt(IF_EQZ,1,-1,L7);
                code.visitStmt2R(MOVE_OBJECT,2,1);
                code.visitLabel(L6);
                code.visitStmt1R(RETURN_OBJECT,2);
                code.visitLabel(L7);
                code.visitStmt2R1N(ADD_INT_LIT8,0,0,1);
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitLabel(L8);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L6);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m012_getResources(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/resource/ResourceCollection;","getResources",new String[]{ },"[Lorg/mortbay/resource/Resource;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(175,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/resource/ResourceCollection;","_resources","[Lorg/mortbay/resource/Resource;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m013_getURL(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/resource/ResourceCollection;","getURL",new String[]{ },"Ljava/net/URL;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(353,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(354,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(356,L2);
                DexLabel L3=new DexLabel();
                ddv.visitStartLocal(0,L3,"i","I",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(358,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(359,L5);
                ddv.visitStartLocal(1,L5,"url","Ljava/net/URL;",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(362,L6);
                ddv.visitEndLocal(1,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(356,L7);
                ddv.visitRestartLocal(1,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(362,L8);
                ddv.visitEndLocal(1,L8);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,2,4,new Field("Lorg/mortbay/resource/ResourceCollection;","_resources","[Lorg/mortbay/resource/Resource;"));
                code.visitJumpStmt(IF_NEZ,2,-1,L2);
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Ljava/lang/IllegalStateException;");
                code.visitConstStmt(CONST_STRING,3,"*resources* not set.");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2,3},new Method("Ljava/lang/IllegalStateException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,2);
                code.visitLabel(L2);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,2,4,new Field("Lorg/mortbay/resource/ResourceCollection;","_resources","[Lorg/mortbay/resource/Resource;"));
                code.visitStmt2R(ARRAY_LENGTH,2,2);
                code.visitJumpStmt(IF_GE,0,2,L8);
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,2,4,new Field("Lorg/mortbay/resource/ResourceCollection;","_resources","[Lorg/mortbay/resource/Resource;"));
                code.visitStmt3R(AGET_OBJECT,2,2,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/resource/Resource;","getURL",new String[]{ },"Ljava/net/URL;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L5);
                code.visitJumpStmt(IF_EQZ,1,-1,L7);
                code.visitStmt2R(MOVE_OBJECT,2,1);
                code.visitLabel(L6);
                code.visitStmt1R(RETURN_OBJECT,2);
                code.visitLabel(L7);
                code.visitStmt2R1N(ADD_INT_LIT8,0,0,1);
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitLabel(L8);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L6);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m014_isDirectory(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/resource/ResourceCollection;","isDirectory",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(368,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(369,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(371,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/resource/ResourceCollection;","_resources","[Lorg/mortbay/resource/Resource;"));
                code.visitJumpStmt(IF_NEZ,0,-1,L2);
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/IllegalStateException;");
                code.visitConstStmt(CONST_STRING,1,"*resources* not set.");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Ljava/lang/IllegalStateException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,0);
                code.visitLabel(L2);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m015_lastModified(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/resource/ResourceCollection;","lastModified",new String[]{ },"J"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(377,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(378,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(380,L3);
                DexLabel L4=new DexLabel();
                ddv.visitStartLocal(0,L4,"i","I",null);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(382,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(383,L6);
                ddv.visitStartLocal(1,L6,"lm","J",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(386,L7);
                ddv.visitEndLocal(1,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(380,L8);
                ddv.visitRestartLocal(1,L8);
                DexLabel L9=new DexLabel();
                ddv.visitEndLocal(1,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(386,L10);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_WIDE_16,4,Long.valueOf(-1L)); // long: 0xffffffffffffffff  double:NaN
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,3,6,new Field("Lorg/mortbay/resource/ResourceCollection;","_resources","[Lorg/mortbay/resource/Resource;"));
                code.visitJumpStmt(IF_NEZ,3,-1,L3);
                code.visitLabel(L2);
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Ljava/lang/IllegalStateException;");
                code.visitConstStmt(CONST_STRING,4,"*resources* not set.");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3,4},new Method("Ljava/lang/IllegalStateException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,3);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,3,6,new Field("Lorg/mortbay/resource/ResourceCollection;","_resources","[Lorg/mortbay/resource/Resource;"));
                code.visitStmt2R(ARRAY_LENGTH,3,3);
                code.visitJumpStmt(IF_GE,0,3,L9);
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,3,6,new Field("Lorg/mortbay/resource/ResourceCollection;","_resources","[Lorg/mortbay/resource/Resource;"));
                code.visitStmt3R(AGET_OBJECT,3,3,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/resource/Resource;","lastModified",new String[]{ },"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,1);
                code.visitLabel(L6);
                code.visitStmt3R(CMP_LONG,3,1,4);
                code.visitJumpStmt(IF_EQZ,3,-1,L8);
                code.visitStmt2R(MOVE_WIDE,3,1);
                code.visitLabel(L7);
                code.visitStmt1R(RETURN_WIDE,3);
                code.visitLabel(L8);
                code.visitStmt2R1N(ADD_INT_LIT8,0,0,1);
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitLabel(L9);
                code.visitStmt2R(MOVE_WIDE,3,4);
                code.visitLabel(L10);
                code.visitJumpStmt(GOTO,-1,-1,L7);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m016_length(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/resource/ResourceCollection;","length",new String[]{ },"J"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(392,L0);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_WIDE_16,0,Long.valueOf(-1L)); // long: 0xffffffffffffffff  double:NaN
                code.visitStmt1R(RETURN_WIDE,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m017_list(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/resource/ResourceCollection;","list",new String[]{ },"[Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(401,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(402,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(404,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(405,L3);
                ddv.visitStartLocal(3,L3,"set","Ljava/util/HashSet;",null);
                DexLabel L4=new DexLabel();
                ddv.visitStartLocal(0,L4,"i","I",null);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(407,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(408,L6);
                ddv.visitStartLocal(2,L6,"list","[Ljava/lang/String;",null);
                DexLabel L7=new DexLabel();
                ddv.visitStartLocal(1,L7,"j","I",null);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(409,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(408,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(405,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(411,L11);
                ddv.visitEndLocal(2,L11);
                ddv.visitEndLocal(1,L11);
                DexLabel L12=new DexLabel();
                ddv.visitEndLocal(6,L12);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,4,6,new Field("Lorg/mortbay/resource/ResourceCollection;","_resources","[Lorg/mortbay/resource/Resource;"));
                code.visitJumpStmt(IF_NEZ,4,-1,L2);
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,4,-1,"Ljava/lang/IllegalStateException;");
                code.visitConstStmt(CONST_STRING,5,"*resources* not set.");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4,5},new Method("Ljava/lang/IllegalStateException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,4);
                code.visitLabel(L2);
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Ljava/util/HashSet;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3},new Method("Ljava/util/HashSet;","<init>",new String[]{ },"V"));
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,4,6,new Field("Lorg/mortbay/resource/ResourceCollection;","_resources","[Lorg/mortbay/resource/Resource;"));
                code.visitStmt2R(ARRAY_LENGTH,4,4);
                code.visitJumpStmt(IF_GE,0,4,L11);
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,4,6,new Field("Lorg/mortbay/resource/ResourceCollection;","_resources","[Lorg/mortbay/resource/Resource;"));
                code.visitStmt3R(AGET_OBJECT,4,4,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/resource/Resource;","list",new String[]{ },"[Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L6);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L7);
                code.visitStmt2R(ARRAY_LENGTH,4,2);
                code.visitJumpStmt(IF_GE,1,4,L10);
                code.visitLabel(L8);
                code.visitStmt3R(AGET_OBJECT,4,2,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/util/HashSet;","add",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitLabel(L9);
                code.visitStmt2R1N(ADD_INT_LIT8,1,1,1);
                code.visitJumpStmt(GOTO,-1,-1,L7);
                code.visitLabel(L10);
                code.visitStmt2R1N(ADD_INT_LIT8,0,0,1);
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitLabel(L11);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/util/HashSet;","size",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitTypeStmt(NEW_ARRAY,4,4,"[Ljava/lang/String;");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/util/HashSet;","toArray",new String[]{ "[Ljava/lang/Object;"},"[Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitLabel(L12);
                code.visitTypeStmt(CHECK_CAST,6,-1,"[Ljava/lang/String;");
                code.visitTypeStmt(CHECK_CAST,6,-1,"[Ljava/lang/String;");
                code.visitStmt1R(RETURN_OBJECT,6);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m018_release(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/resource/ResourceCollection;","release",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(417,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(418,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(420,L2);
                DexLabel L3=new DexLabel();
                ddv.visitStartLocal(0,L3,"i","I",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(421,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(420,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(422,L6);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/resource/ResourceCollection;","_resources","[Lorg/mortbay/resource/Resource;"));
                code.visitJumpStmt(IF_NEZ,1,-1,L2);
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/lang/IllegalStateException;");
                code.visitConstStmt(CONST_STRING,2,"*resources* not set.");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,2},new Method("Ljava/lang/IllegalStateException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,1);
                code.visitLabel(L2);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/resource/ResourceCollection;","_resources","[Lorg/mortbay/resource/Resource;"));
                code.visitStmt2R(ARRAY_LENGTH,1,1);
                code.visitJumpStmt(IF_GE,0,1,L6);
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/resource/ResourceCollection;","_resources","[Lorg/mortbay/resource/Resource;"));
                code.visitStmt3R(AGET_OBJECT,1,1,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/resource/Resource;","release",new String[]{ },"V"));
                code.visitLabel(L5);
                code.visitStmt2R1N(ADD_INT_LIT8,0,0,1);
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitLabel(L6);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m019_renameTo(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/resource/ResourceCollection;","renameTo",new String[]{ "Lorg/mortbay/resource/Resource;"},"Z"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/SecurityException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"dest");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(427,L0);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/UnsupportedOperationException;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/UnsupportedOperationException;","<init>",new String[]{ },"V"));
                code.visitStmt1R(THROW,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m020_setResources(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/resource/ResourceCollection;","setResources",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(9);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L1},new String[]{ "Ljava/lang/Exception;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"csvResources");
                DexLabel L2=new DexLabel();
                ddv.visitPrologue(L2);
                ddv.visitLineNumber(131,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(132,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(134,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(135,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(137,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(138,L7);
                ddv.visitStartLocal(3,L7,"tokenizer","Ljava/util/StringTokenizer;",null);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(139,L8);
                ddv.visitStartLocal(2,L8,"len","I",null);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(140,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(142,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(145,L11);
                ddv.visitStartLocal(1,L0,"i","I",null);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(147,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(148,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(149,L14);
                ddv.visitLineNumber(152,L1);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(154,L15);
                ddv.visitStartLocal(0,L15,"e","Ljava/lang/Exception;",null);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(145,L16);
                ddv.visitEndLocal(0,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(156,L17);
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,4,7,new Field("Lorg/mortbay/resource/ResourceCollection;","_resources","[Lorg/mortbay/resource/Resource;"));
                code.visitJumpStmt(IF_EQZ,4,-1,L4);
                code.visitLabel(L3);
                code.visitTypeStmt(NEW_INSTANCE,4,-1,"Ljava/lang/IllegalStateException;");
                code.visitConstStmt(CONST_STRING,5,"*resources* already set.");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4,5},new Method("Ljava/lang/IllegalStateException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,4);
                code.visitLabel(L4);
                code.visitJumpStmt(IF_NEZ,8,-1,L6);
                code.visitLabel(L5);
                code.visitTypeStmt(NEW_INSTANCE,4,-1,"Ljava/lang/IllegalArgumentException;");
                code.visitConstStmt(CONST_STRING,5,"*csvResources* must not be null.");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4,5},new Method("Ljava/lang/IllegalArgumentException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,4);
                code.visitLabel(L6);
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Ljava/util/StringTokenizer;");
                code.visitConstStmt(CONST_STRING,4,",;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3,8,4},new Method("Ljava/util/StringTokenizer;","<init>",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"V"));
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/util/StringTokenizer;","countTokens",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitLabel(L8);
                code.visitJumpStmt(IF_NEZ,2,-1,L10);
                code.visitLabel(L9);
                code.visitTypeStmt(NEW_INSTANCE,4,-1,"Ljava/lang/IllegalArgumentException;");
                code.visitConstStmt(CONST_STRING,5,"arg *resources* must be one or more resources.");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4,5},new Method("Ljava/lang/IllegalArgumentException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,4);
                code.visitLabel(L10);
                code.visitTypeStmt(NEW_ARRAY,4,2,"[Lorg/mortbay/resource/Resource;");
                code.visitFieldStmt(IPUT_OBJECT,4,7,new Field("Lorg/mortbay/resource/ResourceCollection;","_resources","[Lorg/mortbay/resource/Resource;"));
                code.visitLabel(L11);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/util/StringTokenizer;","hasMoreTokens",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitJumpStmt(IF_EQZ,4,-1,L17);
                code.visitLabel(L12);
                code.visitFieldStmt(IGET_OBJECT,4,7,new Field("Lorg/mortbay/resource/ResourceCollection;","_resources","[Lorg/mortbay/resource/Resource;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/util/StringTokenizer;","nextToken",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/lang/String;","trim",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 5},new Method("Lorg/mortbay/resource/Resource;","newResource",new String[]{ "Ljava/lang/String;"},"Lorg/mortbay/resource/Resource;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitStmt3R(APUT_OBJECT,5,4,1);
                code.visitLabel(L13);
                code.visitFieldStmt(IGET_OBJECT,4,7,new Field("Lorg/mortbay/resource/ResourceCollection;","_resources","[Lorg/mortbay/resource/Resource;"));
                code.visitStmt3R(AGET_OBJECT,4,4,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/resource/Resource;","exists",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitJumpStmt(IF_EQZ,4,-1,L14);
                code.visitFieldStmt(IGET_OBJECT,4,7,new Field("Lorg/mortbay/resource/ResourceCollection;","_resources","[Lorg/mortbay/resource/Resource;"));
                code.visitStmt3R(AGET_OBJECT,4,4,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/resource/Resource;","isDirectory",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitJumpStmt(IF_NEZ,4,-1,L16);
                code.visitLabel(L14);
                code.visitTypeStmt(NEW_INSTANCE,4,-1,"Ljava/lang/IllegalArgumentException;");
                code.visitTypeStmt(NEW_INSTANCE,5,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 5},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IGET_OBJECT,6,7,new Field("Lorg/mortbay/resource/ResourceCollection;","_resources","[Lorg/mortbay/resource/Resource;"));
                code.visitStmt3R(AGET_OBJECT,6,6,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitConstStmt(CONST_STRING,6," is not an existing directory.");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4,5},new Method("Ljava/lang/IllegalArgumentException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,4);
                code.visitLabel(L1);
                code.visitStmt1R(MOVE_EXCEPTION,4);
                code.visitStmt2R(MOVE_OBJECT,0,4);
                code.visitLabel(L15);
                code.visitTypeStmt(NEW_INSTANCE,4,-1,"Ljava/lang/RuntimeException;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4,0},new Method("Ljava/lang/RuntimeException;","<init>",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitStmt1R(THROW,4);
                code.visitLabel(L16);
                code.visitStmt2R1N(ADD_INT_LIT8,1,1,1);
                code.visitJumpStmt(GOTO,-1,-1,L0);
                code.visitLabel(L17);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m021_setResources(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/resource/ResourceCollection;","setResources",new String[]{ "[Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L1},new String[]{ "Ljava/lang/Exception;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"resources");
                DexLabel L2=new DexLabel();
                ddv.visitPrologue(L2);
                ddv.visitLineNumber(99,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(100,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(102,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(103,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(105,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(106,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(108,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(111,L9);
                ddv.visitStartLocal(1,L0,"i","I",null);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(113,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(114,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(115,L12);
                ddv.visitLineNumber(118,L1);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(120,L13);
                ddv.visitStartLocal(0,L13,"e","Ljava/lang/Exception;",null);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(111,L14);
                ddv.visitEndLocal(0,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(122,L15);
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/resource/ResourceCollection;","_resources","[Lorg/mortbay/resource/Resource;"));
                code.visitJumpStmt(IF_EQZ,2,-1,L4);
                code.visitLabel(L3);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Ljava/lang/IllegalStateException;");
                code.visitConstStmt(CONST_STRING,3,"*resources* already set.");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2,3},new Method("Ljava/lang/IllegalStateException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,2);
                code.visitLabel(L4);
                code.visitJumpStmt(IF_NEZ,6,-1,L6);
                code.visitLabel(L5);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Ljava/lang/IllegalArgumentException;");
                code.visitConstStmt(CONST_STRING,3,"*resources* must not be null.");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2,3},new Method("Ljava/lang/IllegalArgumentException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,2);
                code.visitLabel(L6);
                code.visitStmt2R(ARRAY_LENGTH,2,6);
                code.visitJumpStmt(IF_NEZ,2,-1,L8);
                code.visitLabel(L7);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Ljava/lang/IllegalArgumentException;");
                code.visitConstStmt(CONST_STRING,3,"arg *resources* must be one or more resources.");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2,3},new Method("Ljava/lang/IllegalArgumentException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,2);
                code.visitLabel(L8);
                code.visitStmt2R(ARRAY_LENGTH,2,6);
                code.visitTypeStmt(NEW_ARRAY,2,2,"[Lorg/mortbay/resource/Resource;");
                code.visitFieldStmt(IPUT_OBJECT,2,5,new Field("Lorg/mortbay/resource/ResourceCollection;","_resources","[Lorg/mortbay/resource/Resource;"));
                code.visitLabel(L9);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L0);
                code.visitStmt2R(ARRAY_LENGTH,2,6);
                code.visitJumpStmt(IF_GE,1,2,L15);
                code.visitLabel(L10);
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/resource/ResourceCollection;","_resources","[Lorg/mortbay/resource/Resource;"));
                code.visitStmt3R(AGET_OBJECT,3,6,1);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3},new Method("Lorg/mortbay/resource/Resource;","newResource",new String[]{ "Ljava/lang/String;"},"Lorg/mortbay/resource/Resource;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitStmt3R(APUT_OBJECT,3,2,1);
                code.visitLabel(L11);
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/resource/ResourceCollection;","_resources","[Lorg/mortbay/resource/Resource;"));
                code.visitStmt3R(AGET_OBJECT,2,2,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/resource/Resource;","exists",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_EQZ,2,-1,L12);
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/resource/ResourceCollection;","_resources","[Lorg/mortbay/resource/Resource;"));
                code.visitStmt3R(AGET_OBJECT,2,2,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/resource/Resource;","isDirectory",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_NEZ,2,-1,L14);
                code.visitLabel(L12);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Ljava/lang/IllegalArgumentException;");
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IGET_OBJECT,4,5,new Field("Lorg/mortbay/resource/ResourceCollection;","_resources","[Lorg/mortbay/resource/Resource;"));
                code.visitStmt3R(AGET_OBJECT,4,4,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitConstStmt(CONST_STRING,4," is not an existing directory.");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2,3},new Method("Ljava/lang/IllegalArgumentException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,2);
                code.visitLabel(L1);
                code.visitStmt1R(MOVE_EXCEPTION,2);
                code.visitStmt2R(MOVE_OBJECT,0,2);
                code.visitLabel(L13);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Ljava/lang/RuntimeException;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2,0},new Method("Ljava/lang/RuntimeException;","<init>",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitStmt1R(THROW,2);
                code.visitLabel(L14);
                code.visitStmt2R1N(ADD_INT_LIT8,1,1,1);
                code.visitJumpStmt(GOTO,-1,-1,L0);
                code.visitLabel(L15);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m022_setResources(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/resource/ResourceCollection;","setResources",new String[]{ "[Lorg/mortbay/resource/Resource;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"resources");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(74,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(75,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(77,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(78,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(80,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(81,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(83,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(84,L7);
                DexLabel L8=new DexLabel();
                ddv.visitStartLocal(0,L8,"i","I",null);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(86,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(87,L10);
                ddv.visitStartLocal(1,L10,"r","Lorg/mortbay/resource/Resource;",null);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(88,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(84,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(90,L13);
                ddv.visitEndLocal(1,L13);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/resource/ResourceCollection;","_resources","[Lorg/mortbay/resource/Resource;"));
                code.visitJumpStmt(IF_EQZ,2,-1,L2);
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Ljava/lang/IllegalStateException;");
                code.visitConstStmt(CONST_STRING,3,"*resources* already set.");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2,3},new Method("Ljava/lang/IllegalStateException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,2);
                code.visitLabel(L2);
                code.visitJumpStmt(IF_NEZ,6,-1,L4);
                code.visitLabel(L3);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Ljava/lang/IllegalArgumentException;");
                code.visitConstStmt(CONST_STRING,3,"*resources* must not be null.");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2,3},new Method("Ljava/lang/IllegalArgumentException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,2);
                code.visitLabel(L4);
                code.visitStmt2R(ARRAY_LENGTH,2,6);
                code.visitJumpStmt(IF_NEZ,2,-1,L6);
                code.visitLabel(L5);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Ljava/lang/IllegalArgumentException;");
                code.visitConstStmt(CONST_STRING,3,"arg *resources* must be one or more resources.");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2,3},new Method("Ljava/lang/IllegalArgumentException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,2);
                code.visitLabel(L6);
                code.visitFieldStmt(IPUT_OBJECT,6,5,new Field("Lorg/mortbay/resource/ResourceCollection;","_resources","[Lorg/mortbay/resource/Resource;"));
                code.visitLabel(L7);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L8);
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/resource/ResourceCollection;","_resources","[Lorg/mortbay/resource/Resource;"));
                code.visitStmt2R(ARRAY_LENGTH,2,2);
                code.visitJumpStmt(IF_GE,0,2,L13);
                code.visitLabel(L9);
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/resource/ResourceCollection;","_resources","[Lorg/mortbay/resource/Resource;"));
                code.visitStmt3R(AGET_OBJECT,1,2,0);
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/resource/Resource;","exists",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_EQZ,2,-1,L11);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/resource/Resource;","isDirectory",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_NEZ,2,-1,L12);
                code.visitLabel(L11);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Ljava/lang/IllegalArgumentException;");
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitConstStmt(CONST_STRING,4," is not an existing directory.");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2,3},new Method("Ljava/lang/IllegalArgumentException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,2);
                code.visitLabel(L12);
                code.visitStmt2R1N(ADD_INT_LIT8,0,0,1);
                code.visitJumpStmt(GOTO,-1,-1,L8);
                code.visitLabel(L13);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m023_setResourcesAsCSV(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/resource/ResourceCollection;","setResourcesAsCSV",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"csvResources");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(165,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(166,L1);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/resource/ResourceCollection;","setResources",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m024_toString(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/resource/ResourceCollection;","toString",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(436,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(437,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(439,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(440,L3);
                ddv.visitStartLocal(0,L3,"buffer","Ljava/lang/StringBuffer;",null);
                DexLabel L4=new DexLabel();
                ddv.visitStartLocal(1,L4,"i","I",null);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(441,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(440,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(442,L7);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,2,4,new Field("Lorg/mortbay/resource/ResourceCollection;","_resources","[Lorg/mortbay/resource/Resource;"));
                code.visitJumpStmt(IF_NEZ,2,-1,L2);
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Ljava/lang/IllegalStateException;");
                code.visitConstStmt(CONST_STRING,3,"*resources* not set.");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2,3},new Method("Ljava/lang/IllegalStateException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,2);
                code.visitLabel(L2);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/StringBuffer;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/StringBuffer;","<init>",new String[]{ },"V"));
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,2,4,new Field("Lorg/mortbay/resource/ResourceCollection;","_resources","[Lorg/mortbay/resource/Resource;"));
                code.visitStmt2R(ARRAY_LENGTH,2,2);
                code.visitJumpStmt(IF_GE,1,2,L7);
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,2,4,new Field("Lorg/mortbay/resource/ResourceCollection;","_resources","[Lorg/mortbay/resource/Resource;"));
                code.visitStmt3R(AGET_OBJECT,2,2,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/lang/Object;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,2},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitConstStmt(CONST_16,3, Integer.valueOf(59)); // int: 0x0000003b  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "C"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L6);
                code.visitStmt2R1N(ADD_INT_LIT8,1,1,1);
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/StringBuffer;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitStmt1R(RETURN_OBJECT,2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
