package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0361_org_mortbay_proxy_AsyncProxyServlet {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/proxy/AsyncProxyServlet;","Ljava/lang/Object;",new String[]{ "Ljavax/servlet/Servlet;"});
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("AsyncProxyServlet.java");
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/MemberClasses;", Visibility.SYSTEM);
            if(av00 != null) {
                {
                    DexAnnotationVisitor av01 = av00.visitArray("value");
                    if(av01 != null) {
                        av01.visit(null, new DexType("Lorg/mortbay/proxy/AsyncProxyServlet$Transparent;"));
                        av01.visitEnd();
                    }
                }
                av00.visitEnd();
            }
        }
        f000__DontProxyHeaders(cv);
        f001__client(cv);
        f002_config(cv);
        f003_context(cv);
        m000__init_(cv);
        m001_main(cv);
        m002_destroy(cv);
        m003_getServletConfig(cv);
        m004_getServletInfo(cv);
        m005_handleConnect(cv);
        m006_init(cv);
        m007_proxyHttpURI(cv);
        m008_service(cv);
    }
    public static void f000__DontProxyHeaders(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/proxy/AsyncProxyServlet;","_DontProxyHeaders","Ljava/util/HashSet;"), null);
        if(fv != null) {
            if(fv!=null){
                DexAnnotationVisitor av00 = fv.visitAnnotation("Ldalvik/annotation/Signature;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, "Ljava/util/HashSet");
                            av01.visit(null, "<");
                            av01.visit(null, "Ljava/lang/String;");
                            av01.visit(null, ">;");
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            fv.visitEnd();
        }
    }
    public static void f001__client(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/proxy/AsyncProxyServlet;","_client","Lorg/mortbay/jetty/client/HttpClient;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002_config(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/proxy/AsyncProxyServlet;","config","Ljavax/servlet/ServletConfig;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003_context(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/proxy/AsyncProxyServlet;","context","Ljavax/servlet/ServletContext;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/proxy/AsyncProxyServlet;","<init>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(64,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(68,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(70,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(71,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(72,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(73,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(74,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(75,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(76,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(77,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(78,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(332,L11);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2},new Method("Ljava/lang/Object;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/util/HashSet;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/util/HashSet;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/proxy/AsyncProxyServlet;","_DontProxyHeaders","Ljava/util/HashSet;"));
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/proxy/AsyncProxyServlet;","_DontProxyHeaders","Ljava/util/HashSet;"));
                code.visitConstStmt(CONST_STRING,1,"proxy-connection");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/util/HashSet;","add",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/proxy/AsyncProxyServlet;","_DontProxyHeaders","Ljava/util/HashSet;"));
                code.visitConstStmt(CONST_STRING,1,"connection");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/util/HashSet;","add",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/proxy/AsyncProxyServlet;","_DontProxyHeaders","Ljava/util/HashSet;"));
                code.visitConstStmt(CONST_STRING,1,"keep-alive");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/util/HashSet;","add",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/proxy/AsyncProxyServlet;","_DontProxyHeaders","Ljava/util/HashSet;"));
                code.visitConstStmt(CONST_STRING,1,"transfer-encoding");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/util/HashSet;","add",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/proxy/AsyncProxyServlet;","_DontProxyHeaders","Ljava/util/HashSet;"));
                code.visitConstStmt(CONST_STRING,1,"te");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/util/HashSet;","add",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitLabel(L7);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/proxy/AsyncProxyServlet;","_DontProxyHeaders","Ljava/util/HashSet;"));
                code.visitConstStmt(CONST_STRING,1,"trailer");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/util/HashSet;","add",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitLabel(L8);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/proxy/AsyncProxyServlet;","_DontProxyHeaders","Ljava/util/HashSet;"));
                code.visitConstStmt(CONST_STRING,1,"proxy-authorization");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/util/HashSet;","add",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitLabel(L9);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/proxy/AsyncProxyServlet;","_DontProxyHeaders","Ljava/util/HashSet;"));
                code.visitConstStmt(CONST_STRING,1,"proxy-authenticate");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/util/HashSet;","add",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitLabel(L10);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/proxy/AsyncProxyServlet;","_DontProxyHeaders","Ljava/util/HashSet;"));
                code.visitConstStmt(CONST_STRING,1,"upgrade");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/util/HashSet;","add",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitLabel(L11);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001_main(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/proxy/AsyncProxyServlet;","main",new String[]{ "[Ljava/lang/String;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/Exception;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(10);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"args");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(362,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(364,L2);
                ddv.visitStartLocal(2,L2,"proxy","Lorg/mortbay/jetty/Server;",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(365,L3);
                ddv.visitStartLocal(0,L3,"connector","Lorg/mortbay/jetty/Connector;",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(366,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(367,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(368,L6);
                ddv.visitStartLocal(1,L6,"context","Lorg/mortbay/jetty/servlet/Context;",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(370,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(371,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(372,L9);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_STRING,8,"/");
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Lorg/mortbay/jetty/Server;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2},new Method("Lorg/mortbay/jetty/Server;","<init>",new String[]{ },"V"));
                code.visitLabel(L2);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/jetty/bio/SocketConnector;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Lorg/mortbay/jetty/bio/SocketConnector;","<init>",new String[]{ },"V"));
                code.visitLabel(L3);
                code.visitConstStmt(CONST_16,3, Integer.valueOf(8888)); // int: 0x000022b8  float:0.000000
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,3},new Method("Lorg/mortbay/jetty/Connector;","setPort",new String[]{ "I"},"V"));
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,0},new Method("Lorg/mortbay/jetty/Server;","addConnector",new String[]{ "Lorg/mortbay/jetty/Connector;"},"V"));
                code.visitLabel(L5);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Lorg/mortbay/jetty/servlet/Context;");
                code.visitConstStmt(CONST_STRING,3,"/");
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,2,8,3},new Method("Lorg/mortbay/jetty/servlet/Context;","<init>",new String[]{ "Lorg/mortbay/jetty/HandlerContainer;","Ljava/lang/String;","I"},"V"));
                code.visitLabel(L6);
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Lorg/mortbay/jetty/servlet/ServletHolder;");
                code.visitTypeStmt(NEW_INSTANCE,4,-1,"Lorg/mortbay/proxy/AsyncProxyServlet$Transparent;");
                code.visitConstStmt(CONST_STRING,5,"");
                code.visitConstStmt(CONST_STRING,6,"www.google.com");
                code.visitConstStmt(CONST_16,7, Integer.valueOf(80)); // int: 0x00000050  float:0.000000
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4,5,6,7},new Method("Lorg/mortbay/proxy/AsyncProxyServlet$Transparent;","<init>",new String[]{ "Ljava/lang/String;","Ljava/lang/String;","I"},"V"));
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3,4},new Method("Lorg/mortbay/jetty/servlet/ServletHolder;","<init>",new String[]{ "Ljavax/servlet/Servlet;"},"V"));
                code.visitConstStmt(CONST_STRING,4,"/");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,3,8},new Method("Lorg/mortbay/jetty/servlet/Context;","addServlet",new String[]{ "Lorg/mortbay/jetty/servlet/ServletHolder;","Ljava/lang/String;"},"V"));
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/Server;","start",new String[]{ },"V"));
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/Server;","join",new String[]{ },"V"));
                code.visitLabel(L9);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_destroy(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/proxy/AsyncProxyServlet;","destroy",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(330,L0);
                code.visitLabel(L0);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_getServletConfig(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/proxy/AsyncProxyServlet;","getServletConfig",new String[]{ },"Ljavax/servlet/ServletConfig;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(110,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/proxy/AsyncProxyServlet;","config","Ljavax/servlet/ServletConfig;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_getServletInfo(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/proxy/AsyncProxyServlet;","getServletInfo",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(321,L0);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_STRING,0,"Proxy Servlet");
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_handleConnect(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/proxy/AsyncProxyServlet;","handleConnect",new String[]{ "Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(13);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"request");
                ddv.visitParameterName(1,"response");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(275,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(277,L2);
                ddv.visitStartLocal(7,L2,"uri","Ljava/lang/String;",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(278,L3);
                ddv.visitStartLocal(5,L3,"port","Ljava/lang/String;",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(280,L4);
                ddv.visitStartLocal(1,L4,"host","Ljava/lang/String;",null);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(281,L5);
                ddv.visitStartLocal(0,L5,"c","I",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(283,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(284,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(285,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(286,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(289,L10);
                ddv.visitRestartLocal(1,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(297,L11);
                ddv.visitStartLocal(3,L11,"inetAddress","Ljava/net/InetSocketAddress;",null);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(298,L12);
                ddv.visitStartLocal(2,L12,"in","Ljava/io/InputStream;",null);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(300,L13);
                ddv.visitStartLocal(4,L13,"out","Ljava/io/OutputStream;",null);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(302,L14);
                ddv.visitStartLocal(6,L14,"socket","Ljava/net/Socket;",null);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(303,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(304,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(308,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(309,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(311,L19);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_16,9, Integer.valueOf(47)); // int: 0x0000002f  float:0.000000
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 11},new Method("Ljavax/servlet/http/HttpServletRequest;","getRequestURI",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitLabel(L2);
                code.visitConstStmt(CONST_STRING,5,"");
                code.visitLabel(L3);
                code.visitConstStmt(CONST_STRING,1,"");
                code.visitLabel(L4);
                code.visitConstStmt(CONST_16,8, Integer.valueOf(58)); // int: 0x0000003a  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,8},new Method("Ljava/lang/String;","indexOf",new String[]{ "I"},"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitLabel(L5);
                code.visitJumpStmt(IF_LTZ,0,-1,L10);
                code.visitLabel(L6);
                code.visitStmt2R1N(ADD_INT_LIT8,8,0,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,8},new Method("Ljava/lang/String;","substring",new String[]{ "I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitLabel(L7);
                code.visitConstStmt(CONST_4,8, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,8,0},new Method("Ljava/lang/String;","substring",new String[]{ "I","I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,9},new Method("Ljava/lang/String;","indexOf",new String[]{ "I"},"I"));
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitJumpStmt(IF_LEZ,8,-1,L10);
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,9},new Method("Ljava/lang/String;","indexOf",new String[]{ "I"},"I"));
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitStmt2R1N(ADD_INT_LIT8,8,8,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,8},new Method("Ljava/lang/String;","substring",new String[]{ "I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L10);
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Ljava/net/InetSocketAddress;");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 5},new Method("Ljava/lang/Integer;","parseInt",new String[]{ "Ljava/lang/String;"},"I"));
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3,1,8},new Method("Ljava/net/InetSocketAddress;","<init>",new String[]{ "Ljava/lang/String;","I"},"V"));
                code.visitLabel(L11);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 11},new Method("Ljavax/servlet/http/HttpServletRequest;","getInputStream",new String[]{ },"Ljavax/servlet/ServletInputStream;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L12);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 12},new Method("Ljavax/servlet/http/HttpServletResponse;","getOutputStream",new String[]{ },"Ljavax/servlet/ServletOutputStream;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitLabel(L13);
                code.visitTypeStmt(NEW_INSTANCE,6,-1,"Ljava/net/Socket;");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/net/InetSocketAddress;","getAddress",new String[]{ },"Ljava/net/InetAddress;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/net/InetSocketAddress;","getPort",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,9);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 6,8,9},new Method("Ljava/net/Socket;","<init>",new String[]{ "Ljava/net/InetAddress;","I"},"V"));
                code.visitLabel(L14);
                code.visitConstStmt(CONST_16,8, Integer.valueOf(200)); // int: 0x000000c8  float:0.000000
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 12,8},new Method("Ljavax/servlet/http/HttpServletResponse;","setStatus",new String[]{ "I"},"V"));
                code.visitLabel(L15);
                code.visitConstStmt(CONST_STRING,8,"Connection");
                code.visitConstStmt(CONST_STRING,9,"close");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 12,8,9},new Method("Ljavax/servlet/http/HttpServletResponse;","setHeader",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"V"));
                code.visitLabel(L16);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 12},new Method("Ljavax/servlet/http/HttpServletResponse;","flushBuffer",new String[]{ },"V"));
                code.visitLabel(L17);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/net/Socket;","getInputStream",new String[]{ },"Ljava/io/InputStream;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 8,4},new Method("Lorg/mortbay/util/IO;","copyThread",new String[]{ "Ljava/io/InputStream;","Ljava/io/OutputStream;"},"V"));
                code.visitLabel(L18);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/net/Socket;","getOutputStream",new String[]{ },"Ljava/io/OutputStream;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2,8},new Method("Lorg/mortbay/util/IO;","copy",new String[]{ "Ljava/io/InputStream;","Ljava/io/OutputStream;"},"V"));
                code.visitLabel(L19);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_init(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/proxy/AsyncProxyServlet;","init",new String[]{ "Ljavax/servlet/ServletConfig;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljavax/servlet/ServletException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/lang/Exception;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"config");
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(89,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(90,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(92,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(94,L6);
                ddv.visitLineNumber(97,L0);
                ddv.visitLineNumber(103,L1);
                ddv.visitLineNumber(99,L2);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(101,L7);
                ddv.visitStartLocal(0,L7,"e","Ljava/lang/Exception;",null);
                code.visitLabel(L3);
                code.visitFieldStmt(IPUT_OBJECT,4,3,new Field("Lorg/mortbay/proxy/AsyncProxyServlet;","config","Ljavax/servlet/ServletConfig;"));
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 4},new Method("Ljavax/servlet/ServletConfig;","getServletContext",new String[]{ },"Ljavax/servlet/ServletContext;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitFieldStmt(IPUT_OBJECT,1,3,new Field("Lorg/mortbay/proxy/AsyncProxyServlet;","context","Ljavax/servlet/ServletContext;"));
                code.visitLabel(L5);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Lorg/mortbay/jetty/client/HttpClient;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Lorg/mortbay/jetty/client/HttpClient;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,1,3,new Field("Lorg/mortbay/proxy/AsyncProxyServlet;","_client","Lorg/mortbay/jetty/client/HttpClient;"));
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/proxy/AsyncProxyServlet;","_client","Lorg/mortbay/jetty/client/HttpClient;"));
                code.visitConstStmt(CONST_4,2, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Lorg/mortbay/jetty/client/HttpClient;","setConnectorType",new String[]{ "I"},"V"));
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/proxy/AsyncProxyServlet;","_client","Lorg/mortbay/jetty/client/HttpClient;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/jetty/client/HttpClient;","start",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitStmt2R(MOVE_OBJECT,0,1);
                code.visitLabel(L7);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljavax/servlet/ServletException;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,0},new Method("Ljavax/servlet/ServletException;","<init>",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitStmt1R(THROW,1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m007_proxyHttpURI(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/proxy/AsyncProxyServlet;","proxyHttpURI",new String[]{ "Ljava/lang/String;","Ljava/lang/String;","I","Ljava/lang/String;"},"Lorg/mortbay/jetty/HttpURI;"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/net/MalformedURLException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(8);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"scheme");
                ddv.visitParameterName(1,"serverName");
                ddv.visitParameterName(2,"serverPort");
                ddv.visitParameterName(3,"uri");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(267,L0);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/jetty/HttpURI;");
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitConstStmt(CONST_STRING,2,"://");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitConstStmt(CONST_STRING,2,":");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,6},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "I"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,7},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/HttpURI;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m008_service(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/proxy/AsyncProxyServlet;","service",new String[]{ "Ljavax/servlet/ServletRequest;","Ljavax/servlet/ServletResponse;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljavax/servlet/ServletException;"));
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(30);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"req");
                ddv.visitParameterName(1,"res");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(119,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(120,L1);
                ddv.visitStartLocal(19,L1,"request","Ljavax/servlet/http/HttpServletRequest;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(121,L2);
                ddv.visitStartLocal(10,L2,"response","Ljavax/servlet/http/HttpServletResponse;",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(123,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(260,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(127,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(128,L6);
                ddv.visitStartLocal(17,L6,"in","Ljava/io/InputStream;",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(129,L7);
                ddv.visitStartLocal(9,L7,"out","Ljava/io/OutputStream;",null);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(132,L8);
                ddv.visitStartLocal(7,L8,"continuation","Lorg/mortbay/util/ajax/Continuation;",null);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(134,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(135,L10);
                ddv.visitStartLocal(8,L10,"buffer","[B",null);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(136,L11);
                ddv.visitStartLocal(20,L11,"uri","Ljava/lang/String;",null);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(137,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(139,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(144,L14);
                ddv.visitStartLocal(21,L14,"url","Lorg/mortbay/jetty/HttpURI;",null);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(146,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(150,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(198,L17);
                ddv.visitStartLocal(5,L17,"exchange","Lorg/mortbay/jetty/client/HttpExchange;",null);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(199,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(201,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(204,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(205,L21);
                ddv.visitStartLocal(11,L21,"connectionHdr","Ljava/lang/String;",null);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(207,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(208,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(210,L24);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(214,L25);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(215,L26);
                ddv.visitStartLocal(24,L26,"xForwardedFor","Z",null);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(216,L27);
                ddv.visitStartLocal(15,L27,"hasContent","Z",null);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(217,L28);
                ddv.visitStartLocal(12,L28,"contentLength","J",null);
                DexLabel L29=new DexLabel();
                ddv.visitLineNumber(218,L29);
                ddv.visitStartLocal(14,L29,"enm","Ljava/util/Enumeration;",null);
                DexLabel L30=new DexLabel();
                ddv.visitLineNumber(221,L30);
                DexLabel L31=new DexLabel();
                ddv.visitLineNumber(222,L31);
                ddv.visitStartLocal(16,L31,"hdr","Ljava/lang/String;",null);
                DexLabel L32=new DexLabel();
                ddv.visitLineNumber(224,L32);
                ddv.visitStartLocal(18,L32,"lhdr","Ljava/lang/String;",null);
                DexLabel L33=new DexLabel();
                ddv.visitLineNumber(226,L33);
                DexLabel L34=new DexLabel();
                ddv.visitLineNumber(229,L34);
                DexLabel L35=new DexLabel();
                ddv.visitLineNumber(230,L35);
                DexLabel L36=new DexLabel();
                ddv.visitLineNumber(231,L36);
                DexLabel L37=new DexLabel();
                ddv.visitLineNumber(232,L37);
                DexLabel L38=new DexLabel();
                ddv.visitLineNumber(234,L38);
                DexLabel L39=new DexLabel();
                ddv.visitLineNumber(235,L39);
                ddv.visitStartLocal(23,L39,"vals","Ljava/util/Enumeration;",null);
                DexLabel L40=new DexLabel();
                ddv.visitLineNumber(237,L40);
                DexLabel L41=new DexLabel();
                ddv.visitLineNumber(238,L41);
                ddv.visitStartLocal(22,L41,"val","Ljava/lang/String;",null);
                DexLabel L42=new DexLabel();
                ddv.visitLineNumber(240,L42);
                DexLabel L43=new DexLabel();
                ddv.visitLineNumber(241,L43);
                DexLabel L44=new DexLabel();
                ddv.visitLineNumber(247,L44);
                ddv.visitEndLocal(16,L44);
                ddv.visitEndLocal(18,L44);
                ddv.visitEndLocal(23,L44);
                ddv.visitEndLocal(22,L44);
                DexLabel L45=new DexLabel();
                ddv.visitEndLocal(8,L45);
                DexLabel L46=new DexLabel();
                ddv.visitLineNumber(248,L46);
                DexLabel L47=new DexLabel();
                ddv.visitLineNumber(249,L47);
                DexLabel L48=new DexLabel();
                ddv.visitLineNumber(252,L48);
                DexLabel L49=new DexLabel();
                ddv.visitLineNumber(253,L49);
                DexLabel L50=new DexLabel();
                ddv.visitLineNumber(255,L50);
                DexLabel L51=new DexLabel();
                ddv.visitLineNumber(257,L51);
                code.visitLabel(L0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,28);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Ljavax/servlet/http/HttpServletRequest;");
                code.visitStmt2R(MOVE_OBJECT_FROM16,19,0);
                code.visitLabel(L1);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,29);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Ljavax/servlet/http/HttpServletResponse;");
                code.visitStmt2R(MOVE_OBJECT,10,0);
                code.visitLabel(L2);
                code.visitConstStmt(CONST_STRING,6,"CONNECT");
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 19},new Method("Ljavax/servlet/http/HttpServletRequest;","getMethod",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,7},new Method("Ljava/lang/String;","equalsIgnoreCase",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitJumpStmt(IF_EQZ,6,-1,L5);
                code.visitLabel(L3);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,19);
                code.visitStmt2R(MOVE_OBJECT,2,10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Lorg/mortbay/proxy/AsyncProxyServlet;","handleConnect",new String[]{ "Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;"},"V"));
                code.visitLabel(L4);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 19},new Method("Ljavax/servlet/http/HttpServletRequest;","getInputStream",new String[]{ },"Ljavax/servlet/ServletInputStream;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,17);
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 10},new Method("Ljavax/servlet/http/HttpServletResponse;","getOutputStream",new String[]{ },"Ljavax/servlet/ServletOutputStream;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitLabel(L7);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,19);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,19);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,1},new Method("Lorg/mortbay/util/ajax/ContinuationSupport;","getContinuation",new String[]{ "Ljavax/servlet/http/HttpServletRequest;","Ljava/lang/Object;"},"Lorg/mortbay/util/ajax/Continuation;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 7},new Method("Lorg/mortbay/util/ajax/Continuation;","isPending",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitJumpStmt(IF_NEZ,6,-1,L4);
                code.visitLabel(L9);
                code.visitConstStmt(CONST_16,6, Integer.valueOf(4096)); // int: 0x00001000  float:0.000000
                code.visitTypeStmt(NEW_ARRAY,8,6,"[B");
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 19},new Method("Ljavax/servlet/http/HttpServletRequest;","getRequestURI",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,20);
                code.visitLabel(L11);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 19},new Method("Ljavax/servlet/http/HttpServletRequest;","getQueryString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitJumpStmt(IF_EQZ,6,-1,L13);
                code.visitLabel(L12);
                code.visitTypeStmt(NEW_INSTANCE,6,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 6},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitStmt2R(MOVE_OBJECT,0,6);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,20);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitConstStmt(CONST_STRING,11,"?");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,11},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 19},new Method("Ljavax/servlet/http/HttpServletRequest;","getQueryString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,11);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,11},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,20);
                code.visitLabel(L13);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 19},new Method("Ljavax/servlet/http/HttpServletRequest;","getScheme",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 19},new Method("Ljavax/servlet/http/HttpServletRequest;","getServerName",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,11);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 19},new Method("Ljavax/servlet/http/HttpServletRequest;","getServerPort",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,12);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitStmt2R(MOVE_OBJECT,1,6);
                code.visitStmt2R(MOVE_OBJECT,2,11);
                code.visitStmt2R(MOVE,3,12);
                code.visitStmt2R(MOVE_OBJECT_FROM16,4,20);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2,3,4},new Method("Lorg/mortbay/proxy/AsyncProxyServlet;","proxyHttpURI",new String[]{ "Ljava/lang/String;","Ljava/lang/String;","I","Ljava/lang/String;"},"Lorg/mortbay/jetty/HttpURI;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,21);
                code.visitLabel(L14);
                code.visitJumpStmt(IF_NEZ,21,-1,L16);
                code.visitLabel(L15);
                code.visitConstStmt(CONST_16,6, Integer.valueOf(403)); // int: 0x00000193  float:0.000000
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 10,6},new Method("Ljavax/servlet/http/HttpServletResponse;","sendError",new String[]{ "I"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitLabel(L16);
                code.visitTypeStmt(NEW_INSTANCE,5,-1,"Lorg/mortbay/proxy/AsyncProxyServlet$1;");
                code.visitStmt2R(MOVE_OBJECT_FROM16,6,27);
                code.visitMethodStmt(INVOKE_DIRECT_RANGE,new int[]{ 5,6,7,8,9,10},new Method("Lorg/mortbay/proxy/AsyncProxyServlet$1;","<init>",new String[]{ "Lorg/mortbay/proxy/AsyncProxyServlet;","Lorg/mortbay/util/ajax/Continuation;","[B","Ljava/io/OutputStream;","Ljavax/servlet/http/HttpServletResponse;"},"V"));
                code.visitLabel(L17);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 19},new Method("Ljavax/servlet/http/HttpServletRequest;","getProtocol",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Lorg/mortbay/jetty/client/HttpExchange;","setVersion",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L18);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 19},new Method("Ljavax/servlet/http/HttpServletRequest;","getMethod",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Lorg/mortbay/jetty/client/HttpExchange;","setMethod",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L19);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 21},new Method("Lorg/mortbay/jetty/HttpURI;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Lorg/mortbay/jetty/client/HttpExchange;","setURL",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L20);
                code.visitConstStmt(CONST_STRING,6,"Connection");
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,19);
                code.visitStmt2R(MOVE_OBJECT,1,6);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1},new Method("Ljavax/servlet/http/HttpServletRequest;","getHeader",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,11);
                code.visitLabel(L21);
                code.visitJumpStmt(IF_EQZ,11,-1,L25);
                code.visitLabel(L22);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11},new Method("Ljava/lang/String;","toLowerCase",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,11);
                code.visitLabel(L23);
                code.visitConstStmt(CONST_STRING,6,"keep-alive");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11,6},new Method("Ljava/lang/String;","indexOf",new String[]{ "Ljava/lang/String;"},"I"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitJumpStmt(IF_GEZ,6,-1,L25);
                code.visitConstStmt(CONST_STRING,6,"close");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11,6},new Method("Ljava/lang/String;","indexOf",new String[]{ "Ljava/lang/String;"},"I"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitJumpStmt(IF_GEZ,6,-1,L25);
                code.visitLabel(L24);
                code.visitConstStmt(CONST_4,11, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L25);
                code.visitConstStmt(CONST_16,24, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L26);
                code.visitConstStmt(CONST_4,15, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L27);
                code.visitConstStmt(CONST_WIDE_16,12,Long.valueOf(-1L)); // long: 0xffffffffffffffff  double:NaN
                code.visitLabel(L28);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 19},new Method("Ljavax/servlet/http/HttpServletRequest;","getHeaderNames",new String[]{ },"Ljava/util/Enumeration;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,14);
                code.visitLabel(L29);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 14},new Method("Ljava/util/Enumeration;","hasMoreElements",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitJumpStmt(IF_EQZ,6,-1,L44);
                code.visitLabel(L30);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 14},new Method("Ljava/util/Enumeration;","nextElement",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,16);
                code.visitTypeStmt(CHECK_CAST,16,-1,"Ljava/lang/String;");
                code.visitLabel(L31);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 16},new Method("Ljava/lang/String;","toLowerCase",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,18);
                code.visitLabel(L32);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/proxy/AsyncProxyServlet;","_DontProxyHeaders","Ljava/util/HashSet;"));
                code.visitStmt2R(MOVE_OBJECT,6,0);
                code.visitStmt2R(MOVE_OBJECT,0,6);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,18);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/util/HashSet;","contains",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitJumpStmt(IF_NEZ,6,-1,L29);
                code.visitLabel(L33);
                code.visitJumpStmt(IF_EQZ,11,-1,L34);
                code.visitStmt2R(MOVE_OBJECT,0,11);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,18);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/String;","indexOf",new String[]{ "Ljava/lang/String;"},"I"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitJumpStmt(IF_GEZ,6,-1,L29);
                code.visitLabel(L34);
                code.visitConstStmt(CONST_STRING,6,"content-type");
                code.visitStmt2R(MOVE_OBJECT,0,6);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,18);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitJumpStmt(IF_EQZ,6,-1,L36);
                code.visitLabel(L35);
                code.visitConstStmt(CONST_4,15, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L36);
                code.visitConstStmt(CONST_STRING,6,"content-length");
                code.visitStmt2R(MOVE_OBJECT,0,6);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,18);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitJumpStmt(IF_EQZ,6,-1,L38);
                code.visitLabel(L37);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 19},new Method("Ljavax/servlet/http/HttpServletRequest;","getContentLength",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitStmt2R(INT_TO_LONG,12,6);
                code.visitLabel(L38);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,19);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,16);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1},new Method("Ljavax/servlet/http/HttpServletRequest;","getHeaders",new String[]{ "Ljava/lang/String;"},"Ljava/util/Enumeration;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,23);
                code.visitLabel(L39);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 23},new Method("Ljava/util/Enumeration;","hasMoreElements",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitJumpStmt(IF_EQZ,6,-1,L29);
                code.visitLabel(L40);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 23},new Method("Ljava/util/Enumeration;","nextElement",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,22);
                code.visitTypeStmt(CHECK_CAST,22,-1,"Ljava/lang/String;");
                code.visitLabel(L41);
                code.visitJumpStmt(IF_EQZ,22,-1,L39);
                code.visitLabel(L42);
                code.visitStmt2R(MOVE_OBJECT,0,5);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,18);
                code.visitStmt2R(MOVE_OBJECT_FROM16,2,22);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Lorg/mortbay/jetty/client/HttpExchange;","setRequestHeader",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"V"));
                code.visitLabel(L43);
                code.visitConstStmt(CONST_STRING,6,"X-Forwarded-For");
                code.visitStmt2R(MOVE_OBJECT,0,6);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,16);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/String;","equalsIgnoreCase",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitStmt3R(OR_INT,24,24,6);
                code.visitJumpStmt(GOTO,-1,-1,L39);
                code.visitLabel(L44);
                code.visitConstStmt(CONST_STRING,6,"Via");
                code.visitConstStmt(CONST_STRING,8,"1.1 (jetty)");
                code.visitLabel(L45);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6,8},new Method("Lorg/mortbay/jetty/client/HttpExchange;","setRequestHeader",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"V"));
                code.visitLabel(L46);
                code.visitJumpStmt(IF_NEZ,24,-1,L48);
                code.visitLabel(L47);
                code.visitConstStmt(CONST_STRING,6,"X-Forwarded-For");
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 19},new Method("Ljavax/servlet/http/HttpServletRequest;","getRemoteAddr",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6,8},new Method("Lorg/mortbay/jetty/client/HttpExchange;","addRequestHeader",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"V"));
                code.visitLabel(L48);
                code.visitJumpStmt(IF_EQZ,15,-1,L50);
                code.visitLabel(L49);
                code.visitStmt2R(MOVE_OBJECT,0,5);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,17);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/client/HttpExchange;","setRequestContentSource",new String[]{ "Ljava/io/InputStream;"},"V"));
                code.visitLabel(L50);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/proxy/AsyncProxyServlet;","_client","Lorg/mortbay/jetty/client/HttpClient;"));
                code.visitStmt2R(MOVE_OBJECT,6,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,5},new Method("Lorg/mortbay/jetty/client/HttpClient;","send",new String[]{ "Lorg/mortbay/jetty/client/HttpExchange;"},"V"));
                code.visitLabel(L51);
                code.visitConstStmt(CONST_WIDE_16,25,Long.valueOf(30000L)); // long: 0x0000000000007530  double:0.000000
                code.visitStmt2R(MOVE_OBJECT,0,7);
                code.visitStmt2R(MOVE_WIDE_FROM16,1,25);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1,2},new Method("Lorg/mortbay/util/ajax/Continuation;","suspend",new String[]{ "J"},"Z"));
                code.visitJumpStmt(GOTO_16,-1,-1,L4);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
