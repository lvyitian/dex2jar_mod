package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0027_javax_servlet_http_HttpServletRequest {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC|ACC_INTERFACE|ACC_ABSTRACT,"Ljavax/servlet/http/HttpServletRequest;","Ljava/lang/Object;",new String[]{ "Ljavax/servlet/ServletRequest;"});
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("HttpServletRequest.java");
        f000_BASIC_AUTH(cv);
        f001_CLIENT_CERT_AUTH(cv);
        f002_DIGEST_AUTH(cv);
        f003_FORM_AUTH(cv);
        m000_getAuthType(cv);
        m001_getContextPath(cv);
        m002_getCookies(cv);
        m003_getDateHeader(cv);
        m004_getHeader(cv);
        m005_getHeaderNames(cv);
        m006_getHeaders(cv);
        m007_getIntHeader(cv);
        m008_getMethod(cv);
        m009_getPathInfo(cv);
        m010_getPathTranslated(cv);
        m011_getQueryString(cv);
        m012_getRemoteUser(cv);
        m013_getRequestURI(cv);
        m014_getRequestURL(cv);
        m015_getRequestedSessionId(cv);
        m016_getServletPath(cv);
        m017_getSession(cv);
        m018_getSession(cv);
        m019_getUserPrincipal(cv);
        m020_isRequestedSessionIdFromCookie(cv);
        m021_isRequestedSessionIdFromURL(cv);
        m022_isRequestedSessionIdFromUrl(cv);
        m023_isRequestedSessionIdValid(cv);
        m024_isUserInRole(cv);
    }
    public static void f000_BASIC_AUTH(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Ljavax/servlet/http/HttpServletRequest;","BASIC_AUTH","Ljava/lang/String;"), "BASIC");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001_CLIENT_CERT_AUTH(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Ljavax/servlet/http/HttpServletRequest;","CLIENT_CERT_AUTH","Ljava/lang/String;"), "CLIENT_CERT");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002_DIGEST_AUTH(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Ljavax/servlet/http/HttpServletRequest;","DIGEST_AUTH","Ljava/lang/String;"), "DIGEST");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003_FORM_AUTH(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Ljavax/servlet/http/HttpServletRequest;","FORM_AUTH","Ljava/lang/String;"), "FORM");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000_getAuthType(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Ljavax/servlet/http/HttpServletRequest;","getAuthType",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m001_getContextPath(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Ljavax/servlet/http/HttpServletRequest;","getContextPath",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m002_getCookies(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Ljavax/servlet/http/HttpServletRequest;","getCookies",new String[]{ },"[Ljavax/servlet/http/Cookie;"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m003_getDateHeader(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Ljavax/servlet/http/HttpServletRequest;","getDateHeader",new String[]{ "Ljava/lang/String;"},"J"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m004_getHeader(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Ljavax/servlet/http/HttpServletRequest;","getHeader",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m005_getHeaderNames(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Ljavax/servlet/http/HttpServletRequest;","getHeaderNames",new String[]{ },"Ljava/util/Enumeration;"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m006_getHeaders(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Ljavax/servlet/http/HttpServletRequest;","getHeaders",new String[]{ "Ljava/lang/String;"},"Ljava/util/Enumeration;"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m007_getIntHeader(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Ljavax/servlet/http/HttpServletRequest;","getIntHeader",new String[]{ "Ljava/lang/String;"},"I"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m008_getMethod(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Ljavax/servlet/http/HttpServletRequest;","getMethod",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m009_getPathInfo(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Ljavax/servlet/http/HttpServletRequest;","getPathInfo",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m010_getPathTranslated(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Ljavax/servlet/http/HttpServletRequest;","getPathTranslated",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m011_getQueryString(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Ljavax/servlet/http/HttpServletRequest;","getQueryString",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m012_getRemoteUser(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Ljavax/servlet/http/HttpServletRequest;","getRemoteUser",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m013_getRequestURI(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Ljavax/servlet/http/HttpServletRequest;","getRequestURI",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m014_getRequestURL(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Ljavax/servlet/http/HttpServletRequest;","getRequestURL",new String[]{ },"Ljava/lang/StringBuffer;"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m015_getRequestedSessionId(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Ljavax/servlet/http/HttpServletRequest;","getRequestedSessionId",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m016_getServletPath(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Ljavax/servlet/http/HttpServletRequest;","getServletPath",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m017_getSession(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Ljavax/servlet/http/HttpServletRequest;","getSession",new String[]{ },"Ljavax/servlet/http/HttpSession;"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m018_getSession(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Ljavax/servlet/http/HttpServletRequest;","getSession",new String[]{ "Z"},"Ljavax/servlet/http/HttpSession;"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m019_getUserPrincipal(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Ljavax/servlet/http/HttpServletRequest;","getUserPrincipal",new String[]{ },"Ljava/security/Principal;"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m020_isRequestedSessionIdFromCookie(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Ljavax/servlet/http/HttpServletRequest;","isRequestedSessionIdFromCookie",new String[]{ },"Z"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m021_isRequestedSessionIdFromURL(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Ljavax/servlet/http/HttpServletRequest;","isRequestedSessionIdFromURL",new String[]{ },"Z"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m022_isRequestedSessionIdFromUrl(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Ljavax/servlet/http/HttpServletRequest;","isRequestedSessionIdFromUrl",new String[]{ },"Z"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m023_isRequestedSessionIdValid(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Ljavax/servlet/http/HttpServletRequest;","isRequestedSessionIdValid",new String[]{ },"Z"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m024_isUserInRole(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Ljavax/servlet/http/HttpServletRequest;","isUserInRole",new String[]{ "Ljava/lang/String;"},"Z"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
}
