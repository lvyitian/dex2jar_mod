package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0252_org_mortbay_jetty_handler_MovedContextHandler_Redirector {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(0,"Lorg/mortbay/jetty/handler/MovedContextHandler$Redirector;","Lorg/mortbay/jetty/handler/AbstractHandler;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("MovedContextHandler.java");
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/EnclosingClass;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("value", new DexType("Lorg/mortbay/jetty/handler/MovedContextHandler;"));
                av00.visitEnd();
            }
        }
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/InnerClass;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("accessFlags",  Integer.valueOf(2));
                av00.visit("name", "Redirector");
                av00.visitEnd();
            }
        }
        f000_this$0(cv);
        m000__init_(cv);
        m001__init_(cv);
        m002_handle(cv);
    }
    public static void f000_this$0(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_FINAL|ACC_SYNTHETIC, new Field("Lorg/mortbay/jetty/handler/MovedContextHandler$Redirector;","this$0","Lorg/mortbay/jetty/handler/MovedContextHandler;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PRIVATE|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/handler/MovedContextHandler$Redirector;","<init>",new String[]{ "Lorg/mortbay/jetty/handler/MovedContextHandler;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(96,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/handler/MovedContextHandler$Redirector;","this$0","Lorg/mortbay/jetty/handler/MovedContextHandler;"));
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Lorg/mortbay/jetty/handler/AbstractHandler;","<init>",new String[]{ },"V"));
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_SYNTHETIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/handler/MovedContextHandler$Redirector;","<init>",new String[]{ "Lorg/mortbay/jetty/handler/MovedContextHandler;","Lorg/mortbay/jetty/handler/MovedContextHandler$1;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"x0");
                ddv.visitParameterName(1,"x1");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(96,L0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/handler/MovedContextHandler$Redirector;","<init>",new String[]{ "Lorg/mortbay/jetty/handler/MovedContextHandler;"},"V"));
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_handle(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/handler/MovedContextHandler$Redirector;","handle",new String[]{ "Ljava/lang/String;","Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;","I"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visit(null, new DexType("Ljavax/servlet/ServletException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(10);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"target");
                ddv.visitParameterName(1,"request");
                ddv.visitParameterName(2,"response");
                ddv.visitParameterName(3,"dispatch");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(100,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(116,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(103,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(105,L3);
                ddv.visitStartLocal(1,L3,"base_request","Lorg/mortbay/jetty/Request;",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(106,L4);
                ddv.visitStartLocal(2,L4,"url","Ljava/lang/String;",null);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(107,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(108,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(109,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(111,L8);
                ddv.visitRestartLocal(2,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(112,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(113,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(115,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(103,L12);
                ddv.visitEndLocal(1,L12);
                ddv.visitEndLocal(2,L12);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,3,5,new Field("Lorg/mortbay/jetty/handler/MovedContextHandler$Redirector;","this$0","Lorg/mortbay/jetty/handler/MovedContextHandler;"));
                code.visitFieldStmt(IGET_OBJECT,3,3,new Field("Lorg/mortbay/jetty/handler/MovedContextHandler;","_newContextURL","Ljava/lang/String;"));
                code.visitJumpStmt(IF_NEZ,3,-1,L2);
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitTypeStmt(INSTANCE_OF,3,7,"Lorg/mortbay/jetty/Request;");
                code.visitJumpStmt(IF_EQZ,3,-1,L12);
                code.visitStmt2R(MOVE_OBJECT,0,7);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Lorg/mortbay/jetty/Request;");
                code.visitStmt2R(MOVE_OBJECT,3,0);
                code.visitStmt2R(MOVE_OBJECT,1,3);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,3,5,new Field("Lorg/mortbay/jetty/handler/MovedContextHandler$Redirector;","this$0","Lorg/mortbay/jetty/handler/MovedContextHandler;"));
                code.visitFieldStmt(IGET_OBJECT,2,3,new Field("Lorg/mortbay/jetty/handler/MovedContextHandler;","_newContextURL","Ljava/lang/String;"));
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,3,5,new Field("Lorg/mortbay/jetty/handler/MovedContextHandler$Redirector;","this$0","Lorg/mortbay/jetty/handler/MovedContextHandler;"));
                code.visitFieldStmt(IGET_BOOLEAN,3,3,new Field("Lorg/mortbay/jetty/handler/MovedContextHandler;","_discardPathInfo","Z"));
                code.visitJumpStmt(IF_NEZ,3,-1,L6);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 7},new Method("Ljavax/servlet/http/HttpServletRequest;","getPathInfo",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitJumpStmt(IF_EQZ,3,-1,L6);
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 7},new Method("Ljavax/servlet/http/HttpServletRequest;","getPathInfo",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2,3},new Method("Lorg/mortbay/util/URIUtil;","addPaths",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,3,5,new Field("Lorg/mortbay/jetty/handler/MovedContextHandler$Redirector;","this$0","Lorg/mortbay/jetty/handler/MovedContextHandler;"));
                code.visitFieldStmt(IGET_BOOLEAN,3,3,new Field("Lorg/mortbay/jetty/handler/MovedContextHandler;","_discardQuery","Z"));
                code.visitJumpStmt(IF_NEZ,3,-1,L8);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 7},new Method("Ljavax/servlet/http/HttpServletRequest;","getQueryString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitJumpStmt(IF_EQZ,3,-1,L8);
                code.visitLabel(L7);
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitConstStmt(CONST_STRING,4,"?");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 7},new Method("Ljavax/servlet/http/HttpServletRequest;","getQueryString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 8,2},new Method("Ljavax/servlet/http/HttpServletResponse;","sendRedirect",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L9);
                code.visitFieldStmt(IGET_OBJECT,3,5,new Field("Lorg/mortbay/jetty/handler/MovedContextHandler$Redirector;","this$0","Lorg/mortbay/jetty/handler/MovedContextHandler;"));
                code.visitFieldStmt(IGET_BOOLEAN,3,3,new Field("Lorg/mortbay/jetty/handler/MovedContextHandler;","_permanent","Z"));
                code.visitJumpStmt(IF_EQZ,3,-1,L11);
                code.visitLabel(L10);
                code.visitConstStmt(CONST_16,3, Integer.valueOf(301)); // int: 0x0000012d  float:0.000000
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 8,3},new Method("Ljavax/servlet/http/HttpServletResponse;","setStatus",new String[]{ "I"},"V"));
                code.visitLabel(L11);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,3},new Method("Lorg/mortbay/jetty/Request;","setHandled",new String[]{ "Z"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitLabel(L12);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/jetty/HttpConnection;","getCurrentConnection",new String[]{ },"Lorg/mortbay/jetty/HttpConnection;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/jetty/HttpConnection;","getRequest",new String[]{ },"Lorg/mortbay/jetty/Request;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitStmt2R(MOVE_OBJECT,1,3);
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
