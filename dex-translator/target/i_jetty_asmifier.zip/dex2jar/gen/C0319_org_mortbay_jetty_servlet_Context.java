package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0319_org_mortbay_jetty_servlet_Context {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/jetty/servlet/Context;","Lorg/mortbay/jetty/handler/ContextHandler;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("Context.java");
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/MemberClasses;", Visibility.SYSTEM);
            if(av00 != null) {
                {
                    DexAnnotationVisitor av01 = av00.visitArray("value");
                    if(av01 != null) {
                        av01.visit(null, new DexType("Lorg/mortbay/jetty/servlet/Context$SContext;"));
                        av01.visitEnd();
                    }
                }
                av00.visitEnd();
            }
        }
        f000_NO_SECURITY(cv);
        f001_NO_SESSIONS(cv);
        f002_SECURITY(cv);
        f003_SESSIONS(cv);
        f004__securityHandler(cv);
        f005__servletHandler(cv);
        f006__sessionHandler(cv);
        m000__init_(cv);
        m001__init_(cv);
        m002__init_(cv);
        m003__init_(cv);
        m004__init_(cv);
        m005__init_(cv);
        m006__init_(cv);
        m007_addFilter(cv);
        m008_addFilter(cv);
        m009_addFilter(cv);
        m010_addServlet(cv);
        m011_addServlet(cv);
        m012_addServlet(cv);
        m013_getSecurityHandler(cv);
        m014_getServletHandler(cv);
        m015_getSessionHandler(cv);
        m016_setSecurityHandler(cv);
        m017_setServletHandler(cv);
        m018_setSessionHandler(cv);
        m019_startContext(cv);
    }
    public static void f000_NO_SECURITY(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/servlet/Context;","NO_SECURITY","I"),  Integer.valueOf(0));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001_NO_SESSIONS(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/servlet/Context;","NO_SESSIONS","I"),  Integer.valueOf(0));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002_SECURITY(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/servlet/Context;","SECURITY","I"),  Integer.valueOf(2));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003_SESSIONS(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/servlet/Context;","SESSIONS","I"),  Integer.valueOf(1));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f004__securityHandler(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/jetty/servlet/Context;","_securityHandler","Lorg/mortbay/jetty/security/SecurityHandler;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f005__servletHandler(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/jetty/servlet/Context;","_servletHandler","Lorg/mortbay/jetty/servlet/ServletHandler;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f006__sessionHandler(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/jetty/servlet/Context;","_sessionHandler","Lorg/mortbay/jetty/servlet/SessionHandler;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/servlet/Context;","<init>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(54,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(55,L2);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitStmt2R(MOVE_OBJECT,0,6);
                code.visitStmt2R(MOVE_OBJECT,2,1);
                code.visitStmt2R(MOVE_OBJECT,3,1);
                code.visitStmt2R(MOVE_OBJECT,4,1);
                code.visitStmt2R(MOVE_OBJECT,5,1);
                code.visitMethodStmt(INVOKE_DIRECT_RANGE,new int[]{ 0,1,2,3,4,5},new Method("Lorg/mortbay/jetty/servlet/Context;","<init>",new String[]{ "Lorg/mortbay/jetty/HandlerContainer;","Lorg/mortbay/jetty/servlet/SessionHandler;","Lorg/mortbay/jetty/security/SecurityHandler;","Lorg/mortbay/jetty/servlet/ServletHandler;","Lorg/mortbay/jetty/handler/ErrorHandler;"},"V"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/servlet/Context;","<init>",new String[]{ "I"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"options");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(60,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(61,L2);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,0,0,2},new Method("Lorg/mortbay/jetty/servlet/Context;","<init>",new String[]{ "Lorg/mortbay/jetty/HandlerContainer;","Ljava/lang/String;","I"},"V"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/servlet/Context;","<init>",new String[]{ "Lorg/mortbay/jetty/HandlerContainer;","Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(10);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"parent");
                ddv.visitParameterName(1,"contextPath");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(66,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(67,L2);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitStmt2R(MOVE_OBJECT,0,7);
                code.visitStmt2R(MOVE_OBJECT,1,8);
                code.visitStmt2R(MOVE_OBJECT,2,9);
                code.visitStmt2R(MOVE_OBJECT,4,3);
                code.visitStmt2R(MOVE_OBJECT,5,3);
                code.visitStmt2R(MOVE_OBJECT,6,3);
                code.visitMethodStmt(INVOKE_DIRECT_RANGE,new int[]{ 0,1,2,3,4,5,6},new Method("Lorg/mortbay/jetty/servlet/Context;","<init>",new String[]{ "Lorg/mortbay/jetty/HandlerContainer;","Ljava/lang/String;","Lorg/mortbay/jetty/servlet/SessionHandler;","Lorg/mortbay/jetty/security/SecurityHandler;","Lorg/mortbay/jetty/servlet/ServletHandler;","Lorg/mortbay/jetty/handler/ErrorHandler;"},"V"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/servlet/Context;","<init>",new String[]{ "Lorg/mortbay/jetty/HandlerContainer;","Ljava/lang/String;","I"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(11);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"parent");
                ddv.visitParameterName(1,"contextPath");
                ddv.visitParameterName(2,"options");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(72,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(73,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(72,L3);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,5, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitStmt2R1N(AND_INT_LIT8,0,10,1);
                DexLabel L4=new DexLabel();
                code.visitJumpStmt(IF_EQZ,0,-1,L4);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/jetty/servlet/SessionHandler;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Lorg/mortbay/jetty/servlet/SessionHandler;","<init>",new String[]{ },"V"));
                code.visitStmt2R(MOVE_OBJECT,3,0);
                DexLabel L5=new DexLabel();
                code.visitLabel(L5);
                code.visitStmt2R1N(AND_INT_LIT8,0,10,2);
                DexLabel L6=new DexLabel();
                code.visitJumpStmt(IF_EQZ,0,-1,L6);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/jetty/security/SecurityHandler;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Lorg/mortbay/jetty/security/SecurityHandler;","<init>",new String[]{ },"V"));
                code.visitStmt2R(MOVE_OBJECT,4,0);
                DexLabel L7=new DexLabel();
                code.visitLabel(L7);
                code.visitStmt2R(MOVE_OBJECT,0,7);
                code.visitStmt2R(MOVE_OBJECT,1,8);
                code.visitStmt2R(MOVE_OBJECT,2,9);
                code.visitStmt2R(MOVE_OBJECT,6,5);
                code.visitMethodStmt(INVOKE_DIRECT_RANGE,new int[]{ 0,1,2,3,4,5,6},new Method("Lorg/mortbay/jetty/servlet/Context;","<init>",new String[]{ "Lorg/mortbay/jetty/HandlerContainer;","Ljava/lang/String;","Lorg/mortbay/jetty/servlet/SessionHandler;","Lorg/mortbay/jetty/security/SecurityHandler;","Lorg/mortbay/jetty/servlet/ServletHandler;","Lorg/mortbay/jetty/handler/ErrorHandler;"},"V"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L4);
                code.visitStmt2R(MOVE_OBJECT,3,5);
                code.visitLabel(L3);
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitLabel(L6);
                code.visitStmt2R(MOVE_OBJECT,4,5);
                code.visitJumpStmt(GOTO,-1,-1,L7);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/servlet/Context;","<init>",new String[]{ "Lorg/mortbay/jetty/HandlerContainer;","Ljava/lang/String;","Lorg/mortbay/jetty/servlet/SessionHandler;","Lorg/mortbay/jetty/security/SecurityHandler;","Lorg/mortbay/jetty/servlet/ServletHandler;","Lorg/mortbay/jetty/handler/ErrorHandler;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(9);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"parent");
                ddv.visitParameterName(1,"contextPath");
                ddv.visitParameterName(2,"sessionHandler");
                ddv.visitParameterName(3,"securityHandler");
                ddv.visitParameterName(4,"servletHandler");
                ddv.visitParameterName(5,"errorHandler");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(90,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(91,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(92,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(93,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(94,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(96,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(98,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(100,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(102,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(103,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(120,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(121,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(123,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(124,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(126,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(127,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(128,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(94,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(107,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(110,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(112,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(113,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(117,L22);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitTypeStmt(CHECK_CAST,0,-1,"Lorg/mortbay/jetty/handler/ContextHandler$SContext;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2,0},new Method("Lorg/mortbay/jetty/handler/ContextHandler;","<init>",new String[]{ "Lorg/mortbay/jetty/handler/ContextHandler$SContext;"},"V"));
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/jetty/servlet/Context$SContext;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,2},new Method("Lorg/mortbay/jetty/servlet/Context$SContext;","<init>",new String[]{ "Lorg/mortbay/jetty/servlet/Context;"},"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/jetty/servlet/Context;","_scontext","Lorg/mortbay/jetty/handler/ContextHandler$SContext;"));
                code.visitLabel(L2);
                code.visitFieldStmt(IPUT_OBJECT,5,2,new Field("Lorg/mortbay/jetty/servlet/Context;","_sessionHandler","Lorg/mortbay/jetty/servlet/SessionHandler;"));
                code.visitLabel(L3);
                code.visitFieldStmt(IPUT_OBJECT,6,2,new Field("Lorg/mortbay/jetty/servlet/Context;","_securityHandler","Lorg/mortbay/jetty/security/SecurityHandler;"));
                code.visitLabel(L4);
                code.visitJumpStmt(IF_EQZ,7,-1,L17);
                code.visitStmt2R(MOVE_OBJECT,0,7);
                DexLabel L23=new DexLabel();
                code.visitLabel(L23);
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/jetty/servlet/Context;","_servletHandler","Lorg/mortbay/jetty/servlet/ServletHandler;"));
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/servlet/Context;","_sessionHandler","Lorg/mortbay/jetty/servlet/SessionHandler;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L19);
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/servlet/Context;","_sessionHandler","Lorg/mortbay/jetty/servlet/SessionHandler;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,0},new Method("Lorg/mortbay/jetty/servlet/Context;","setHandler",new String[]{ "Lorg/mortbay/jetty/Handler;"},"V"));
                code.visitLabel(L7);
                code.visitJumpStmt(IF_EQZ,6,-1,L18);
                code.visitLabel(L8);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/servlet/Context;","_sessionHandler","Lorg/mortbay/jetty/servlet/SessionHandler;"));
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/servlet/Context;","_securityHandler","Lorg/mortbay/jetty/security/SecurityHandler;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/servlet/SessionHandler;","setHandler",new String[]{ "Lorg/mortbay/jetty/Handler;"},"V"));
                code.visitLabel(L9);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/servlet/Context;","_securityHandler","Lorg/mortbay/jetty/security/SecurityHandler;"));
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/servlet/Context;","_servletHandler","Lorg/mortbay/jetty/servlet/ServletHandler;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/security/SecurityHandler;","setHandler",new String[]{ "Lorg/mortbay/jetty/Handler;"},"V"));
                code.visitLabel(L10);
                code.visitJumpStmt(IF_EQZ,8,-1,L12);
                code.visitLabel(L11);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,8},new Method("Lorg/mortbay/jetty/servlet/Context;","setErrorHandler",new String[]{ "Lorg/mortbay/jetty/handler/ErrorHandler;"},"V"));
                code.visitLabel(L12);
                code.visitJumpStmt(IF_EQZ,4,-1,L14);
                code.visitLabel(L13);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,4},new Method("Lorg/mortbay/jetty/servlet/Context;","setContextPath",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L14);
                code.visitJumpStmt(IF_EQZ,3,-1,L16);
                code.visitLabel(L15);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3,2},new Method("Lorg/mortbay/jetty/HandlerContainer;","addHandler",new String[]{ "Lorg/mortbay/jetty/Handler;"},"V"));
                code.visitLabel(L16);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L17);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/jetty/servlet/ServletHandler;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","<init>",new String[]{ },"V"));
                code.visitJumpStmt(GOTO,-1,-1,L23);
                code.visitLabel(L18);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/servlet/Context;","_sessionHandler","Lorg/mortbay/jetty/servlet/SessionHandler;"));
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/servlet/Context;","_servletHandler","Lorg/mortbay/jetty/servlet/ServletHandler;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/servlet/SessionHandler;","setHandler",new String[]{ "Lorg/mortbay/jetty/Handler;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L10);
                code.visitLabel(L19);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/servlet/Context;","_securityHandler","Lorg/mortbay/jetty/security/SecurityHandler;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L22);
                code.visitLabel(L20);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/servlet/Context;","_securityHandler","Lorg/mortbay/jetty/security/SecurityHandler;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,0},new Method("Lorg/mortbay/jetty/servlet/Context;","setHandler",new String[]{ "Lorg/mortbay/jetty/Handler;"},"V"));
                code.visitLabel(L21);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/servlet/Context;","_securityHandler","Lorg/mortbay/jetty/security/SecurityHandler;"));
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/servlet/Context;","_servletHandler","Lorg/mortbay/jetty/servlet/ServletHandler;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/security/SecurityHandler;","setHandler",new String[]{ "Lorg/mortbay/jetty/Handler;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L10);
                code.visitLabel(L22);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/servlet/Context;","_servletHandler","Lorg/mortbay/jetty/servlet/ServletHandler;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,0},new Method("Lorg/mortbay/jetty/servlet/Context;","setHandler",new String[]{ "Lorg/mortbay/jetty/Handler;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L10);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/servlet/Context;","<init>",new String[]{ "Lorg/mortbay/jetty/HandlerContainer;","Ljava/lang/String;","Z","Z"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"parent");
                ddv.visitParameterName(1,"contextPath");
                ddv.visitParameterName(2,"sessions");
                ddv.visitParameterName(3,"security");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(78,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(79,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(78,L3);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                DexLabel L4=new DexLabel();
                code.visitJumpStmt(IF_EQZ,5,-1,L4);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                DexLabel L5=new DexLabel();
                code.visitLabel(L5);
                DexLabel L6=new DexLabel();
                code.visitJumpStmt(IF_EQZ,6,-1,L6);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitLabel(L6);
                code.visitStmt2R(OR_INT_2ADDR,0,1);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2,3,4,0},new Method("Lorg/mortbay/jetty/servlet/Context;","<init>",new String[]{ "Lorg/mortbay/jetty/HandlerContainer;","Ljava/lang/String;","I"},"V"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L4);
                code.visitStmt2R(MOVE,0,1);
                code.visitLabel(L3);
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/servlet/Context;","<init>",new String[]{ "Lorg/mortbay/jetty/HandlerContainer;","Lorg/mortbay/jetty/servlet/SessionHandler;","Lorg/mortbay/jetty/security/SecurityHandler;","Lorg/mortbay/jetty/servlet/ServletHandler;","Lorg/mortbay/jetty/handler/ErrorHandler;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(13);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"parent");
                ddv.visitParameterName(1,"sessionHandler");
                ddv.visitParameterName(2,"securityHandler");
                ddv.visitParameterName(3,"servletHandler");
                ddv.visitParameterName(4,"errorHandler");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(84,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(85,L1);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt2R(MOVE_OBJECT,0,7);
                code.visitStmt2R(MOVE_OBJECT,1,8);
                code.visitStmt2R(MOVE_OBJECT,3,9);
                code.visitStmt2R(MOVE_OBJECT,4,10);
                code.visitStmt2R(MOVE_OBJECT,5,11);
                code.visitStmt2R(MOVE_OBJECT,6,12);
                code.visitMethodStmt(INVOKE_DIRECT_RANGE,new int[]{ 0,1,2,3,4,5,6},new Method("Lorg/mortbay/jetty/servlet/Context;","<init>",new String[]{ "Lorg/mortbay/jetty/HandlerContainer;","Ljava/lang/String;","Lorg/mortbay/jetty/servlet/SessionHandler;","Lorg/mortbay/jetty/security/SecurityHandler;","Lorg/mortbay/jetty/servlet/ServletHandler;","Lorg/mortbay/jetty/handler/ErrorHandler;"},"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m007_addFilter(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/Context;","addFilter",new String[]{ "Ljava/lang/Class;","Ljava/lang/String;","I"},"Lorg/mortbay/jetty/servlet/FilterHolder;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"filterClass");
                ddv.visitParameterName(1,"pathSpec");
                ddv.visitParameterName(2,"dispatches");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(207,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/servlet/Context;","_servletHandler","Lorg/mortbay/jetty/servlet/ServletHandler;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,2,3,4},new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","addFilterWithMapping",new String[]{ "Ljava/lang/Class;","Ljava/lang/String;","I"},"Lorg/mortbay/jetty/servlet/FilterHolder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m008_addFilter(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/Context;","addFilter",new String[]{ "Ljava/lang/String;","Ljava/lang/String;","I"},"Lorg/mortbay/jetty/servlet/FilterHolder;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"filterClass");
                ddv.visitParameterName(1,"pathSpec");
                ddv.visitParameterName(2,"dispatches");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(215,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/servlet/Context;","_servletHandler","Lorg/mortbay/jetty/servlet/ServletHandler;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,2,3,4},new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","addFilterWithMapping",new String[]{ "Ljava/lang/String;","Ljava/lang/String;","I"},"Lorg/mortbay/jetty/servlet/FilterHolder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m009_addFilter(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/Context;","addFilter",new String[]{ "Lorg/mortbay/jetty/servlet/FilterHolder;","Ljava/lang/String;","I"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"holder");
                ddv.visitParameterName(1,"pathSpec");
                ddv.visitParameterName(2,"dispatches");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(199,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(200,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/servlet/Context;","_servletHandler","Lorg/mortbay/jetty/servlet/ServletHandler;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,2,3,4},new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","addFilterWithMapping",new String[]{ "Lorg/mortbay/jetty/servlet/FilterHolder;","Ljava/lang/String;","I"},"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m010_addServlet(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/Context;","addServlet",new String[]{ "Ljava/lang/Class;","Ljava/lang/String;"},"Lorg/mortbay/jetty/servlet/ServletHolder;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"servlet");
                ddv.visitParameterName(1,"pathSpec");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(183,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/servlet/Context;","_servletHandler","Lorg/mortbay/jetty/servlet/ServletHandler;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/lang/Class;","getName",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,4},new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","addServletWithMapping",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"Lorg/mortbay/jetty/servlet/ServletHolder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m011_addServlet(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/Context;","addServlet",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"Lorg/mortbay/jetty/servlet/ServletHolder;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"className");
                ddv.visitParameterName(1,"pathSpec");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(175,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/servlet/Context;","_servletHandler","Lorg/mortbay/jetty/servlet/ServletHandler;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,2,3},new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","addServletWithMapping",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"Lorg/mortbay/jetty/servlet/ServletHolder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m012_addServlet(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/Context;","addServlet",new String[]{ "Lorg/mortbay/jetty/servlet/ServletHolder;","Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"servlet");
                ddv.visitParameterName(1,"pathSpec");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(191,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(192,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/servlet/Context;","_servletHandler","Lorg/mortbay/jetty/servlet/ServletHandler;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,2,3},new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","addServletWithMapping",new String[]{ "Lorg/mortbay/jetty/servlet/ServletHolder;","Ljava/lang/String;"},"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m013_getSecurityHandler(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/Context;","getSecurityHandler",new String[]{ },"Lorg/mortbay/jetty/security/SecurityHandler;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(149,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/servlet/Context;","_securityHandler","Lorg/mortbay/jetty/security/SecurityHandler;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m014_getServletHandler(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/Context;","getServletHandler",new String[]{ },"Lorg/mortbay/jetty/servlet/ServletHandler;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(158,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/servlet/Context;","_servletHandler","Lorg/mortbay/jetty/servlet/ServletHandler;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m015_getSessionHandler(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/Context;","getSessionHandler",new String[]{ },"Lorg/mortbay/jetty/servlet/SessionHandler;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(167,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/servlet/Context;","_sessionHandler","Lorg/mortbay/jetty/servlet/SessionHandler;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m016_setSecurityHandler(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/Context;","setSecurityHandler",new String[]{ "Lorg/mortbay/jetty/security/SecurityHandler;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"securityHandler");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(250,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(275,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(253,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(254,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(256,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(258,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(260,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(261,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(263,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(267,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(268,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(272,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(273,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(270,L13);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/servlet/Context;","_securityHandler","Lorg/mortbay/jetty/security/SecurityHandler;"));
                code.visitJumpStmt(IF_NE,0,3,L2);
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/servlet/Context;","_securityHandler","Lorg/mortbay/jetty/security/SecurityHandler;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L4);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/servlet/Context;","_securityHandler","Lorg/mortbay/jetty/security/SecurityHandler;"));
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/security/SecurityHandler;","setHandler",new String[]{ "Lorg/mortbay/jetty/Handler;"},"V"));
                code.visitLabel(L4);
                code.visitFieldStmt(IPUT_OBJECT,3,2,new Field("Lorg/mortbay/jetty/servlet/Context;","_securityHandler","Lorg/mortbay/jetty/security/SecurityHandler;"));
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/servlet/Context;","_securityHandler","Lorg/mortbay/jetty/security/SecurityHandler;"));
                code.visitJumpStmt(IF_NEZ,0,-1,L9);
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/servlet/Context;","_sessionHandler","Lorg/mortbay/jetty/servlet/SessionHandler;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L8);
                code.visitLabel(L7);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/servlet/Context;","_sessionHandler","Lorg/mortbay/jetty/servlet/SessionHandler;"));
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/servlet/Context;","_servletHandler","Lorg/mortbay/jetty/servlet/ServletHandler;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/servlet/SessionHandler;","setHandler",new String[]{ "Lorg/mortbay/jetty/Handler;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitLabel(L8);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/servlet/Context;","_servletHandler","Lorg/mortbay/jetty/servlet/ServletHandler;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,0},new Method("Lorg/mortbay/jetty/servlet/Context;","setHandler",new String[]{ "Lorg/mortbay/jetty/Handler;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitLabel(L9);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/servlet/Context;","_sessionHandler","Lorg/mortbay/jetty/servlet/SessionHandler;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L13);
                code.visitLabel(L10);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/servlet/Context;","_sessionHandler","Lorg/mortbay/jetty/servlet/SessionHandler;"));
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/servlet/Context;","_securityHandler","Lorg/mortbay/jetty/security/SecurityHandler;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/servlet/SessionHandler;","setHandler",new String[]{ "Lorg/mortbay/jetty/Handler;"},"V"));
                code.visitLabel(L11);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/servlet/Context;","_servletHandler","Lorg/mortbay/jetty/servlet/ServletHandler;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L1);
                code.visitLabel(L12);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/servlet/Context;","_securityHandler","Lorg/mortbay/jetty/security/SecurityHandler;"));
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/servlet/Context;","_servletHandler","Lorg/mortbay/jetty/servlet/ServletHandler;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/security/SecurityHandler;","setHandler",new String[]{ "Lorg/mortbay/jetty/Handler;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitLabel(L13);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/servlet/Context;","_securityHandler","Lorg/mortbay/jetty/security/SecurityHandler;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,0},new Method("Lorg/mortbay/jetty/servlet/Context;","setHandler",new String[]{ "Lorg/mortbay/jetty/Handler;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L11);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m017_setServletHandler(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/Context;","setServletHandler",new String[]{ "Lorg/mortbay/jetty/servlet/ServletHandler;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"servletHandler");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(283,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(295,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(286,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(288,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(289,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(290,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(291,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(293,L7);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/servlet/Context;","_servletHandler","Lorg/mortbay/jetty/servlet/ServletHandler;"));
                code.visitJumpStmt(IF_NE,0,3,L2);
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitFieldStmt(IPUT_OBJECT,3,2,new Field("Lorg/mortbay/jetty/servlet/Context;","_servletHandler","Lorg/mortbay/jetty/servlet/ServletHandler;"));
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/servlet/Context;","_securityHandler","Lorg/mortbay/jetty/security/SecurityHandler;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L5);
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/servlet/Context;","_securityHandler","Lorg/mortbay/jetty/security/SecurityHandler;"));
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/servlet/Context;","_servletHandler","Lorg/mortbay/jetty/servlet/ServletHandler;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/security/SecurityHandler;","setHandler",new String[]{ "Lorg/mortbay/jetty/Handler;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/servlet/Context;","_sessionHandler","Lorg/mortbay/jetty/servlet/SessionHandler;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L7);
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/servlet/Context;","_sessionHandler","Lorg/mortbay/jetty/servlet/SessionHandler;"));
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/servlet/Context;","_servletHandler","Lorg/mortbay/jetty/servlet/ServletHandler;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/servlet/SessionHandler;","setHandler",new String[]{ "Lorg/mortbay/jetty/Handler;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitLabel(L7);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/servlet/Context;","_servletHandler","Lorg/mortbay/jetty/servlet/ServletHandler;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,0},new Method("Lorg/mortbay/jetty/servlet/Context;","setHandler",new String[]{ "Lorg/mortbay/jetty/Handler;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m018_setSessionHandler(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/Context;","setSessionHandler",new String[]{ "Lorg/mortbay/jetty/servlet/SessionHandler;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"sessionHandler");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(226,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(242,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(229,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(230,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(232,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(234,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(236,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(237,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(238,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(239,L9);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/servlet/Context;","_sessionHandler","Lorg/mortbay/jetty/servlet/SessionHandler;"));
                code.visitJumpStmt(IF_NE,0,3,L2);
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/servlet/Context;","_sessionHandler","Lorg/mortbay/jetty/servlet/SessionHandler;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L4);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/servlet/Context;","_sessionHandler","Lorg/mortbay/jetty/servlet/SessionHandler;"));
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/servlet/SessionHandler;","setHandler",new String[]{ "Lorg/mortbay/jetty/Handler;"},"V"));
                code.visitLabel(L4);
                code.visitFieldStmt(IPUT_OBJECT,3,2,new Field("Lorg/mortbay/jetty/servlet/Context;","_sessionHandler","Lorg/mortbay/jetty/servlet/SessionHandler;"));
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/servlet/Context;","_sessionHandler","Lorg/mortbay/jetty/servlet/SessionHandler;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,0},new Method("Lorg/mortbay/jetty/servlet/Context;","setHandler",new String[]{ "Lorg/mortbay/jetty/Handler;"},"V"));
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/servlet/Context;","_securityHandler","Lorg/mortbay/jetty/security/SecurityHandler;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L8);
                code.visitLabel(L7);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/servlet/Context;","_sessionHandler","Lorg/mortbay/jetty/servlet/SessionHandler;"));
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/servlet/Context;","_securityHandler","Lorg/mortbay/jetty/security/SecurityHandler;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/servlet/SessionHandler;","setHandler",new String[]{ "Lorg/mortbay/jetty/Handler;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitLabel(L8);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/servlet/Context;","_servletHandler","Lorg/mortbay/jetty/servlet/ServletHandler;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L1);
                code.visitLabel(L9);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/servlet/Context;","_sessionHandler","Lorg/mortbay/jetty/servlet/SessionHandler;"));
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/servlet/Context;","_servletHandler","Lorg/mortbay/jetty/servlet/ServletHandler;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/servlet/SessionHandler;","setHandler",new String[]{ "Lorg/mortbay/jetty/Handler;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m019_startContext(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/servlet/Context;","startContext",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/Exception;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(136,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(139,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(140,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(141,L3);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 1},new Method("Lorg/mortbay/jetty/handler/ContextHandler;","startContext",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/servlet/Context;","_servletHandler","Lorg/mortbay/jetty/servlet/ServletHandler;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L3);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/servlet/Context;","_servletHandler","Lorg/mortbay/jetty/servlet/ServletHandler;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","isStarted",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L3);
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/servlet/Context;","_servletHandler","Lorg/mortbay/jetty/servlet/ServletHandler;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","initialize",new String[]{ },"V"));
                code.visitLabel(L3);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
