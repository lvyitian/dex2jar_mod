package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0384_org_mortbay_servlet_QoSFilter {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/servlet/QoSFilter;","Ljava/lang/Object;",new String[]{ "Ljavax/servlet/Filter;"});
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("QoSFilter.java");
        f000_MAX_PRIORITY_INIT_PARAM(cv);
        f001_MAX_REQUESTS_INIT_PARAM(cv);
        f002_MAX_WAIT_INIT_PARAM(cv);
        f003_SUSPEND_INIT_PARAM(cv);
        f004___DEFAULT_MAX_PRIORITY(cv);
        f005___DEFAULT_PASSES(cv);
        f006___DEFAULT_TIMEOUT_MS(cv);
        f007___DEFAULT_WAIT_MS(cv);
        f008__context(cv);
        f009__continuation(cv);
        f010__passes(cv);
        f011__queue(cv);
        f012__suspendMs(cv);
        f013__suspended(cv);
        f014__waitMs(cv);
        m000__init_(cv);
        m001_destroy(cv);
        m002_doFilter(cv);
        m003_getPriority(cv);
        m004_init(cv);
    }
    public static void f000_MAX_PRIORITY_INIT_PARAM(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/servlet/QoSFilter;","MAX_PRIORITY_INIT_PARAM","Ljava/lang/String;"), "maxPriority");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001_MAX_REQUESTS_INIT_PARAM(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/servlet/QoSFilter;","MAX_REQUESTS_INIT_PARAM","Ljava/lang/String;"), "maxRequests");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002_MAX_WAIT_INIT_PARAM(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/servlet/QoSFilter;","MAX_WAIT_INIT_PARAM","Ljava/lang/String;"), "maxWaitMs");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003_SUSPEND_INIT_PARAM(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/servlet/QoSFilter;","SUSPEND_INIT_PARAM","Ljava/lang/String;"), "suspendMs");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f004___DEFAULT_MAX_PRIORITY(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/servlet/QoSFilter;","__DEFAULT_MAX_PRIORITY","I"),  Integer.valueOf(10));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f005___DEFAULT_PASSES(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/servlet/QoSFilter;","__DEFAULT_PASSES","I"),  Integer.valueOf(10));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f006___DEFAULT_TIMEOUT_MS(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/servlet/QoSFilter;","__DEFAULT_TIMEOUT_MS","J"), Long.valueOf(30000L));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f007___DEFAULT_WAIT_MS(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/servlet/QoSFilter;","__DEFAULT_WAIT_MS","I"),  Integer.valueOf(50));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f008__context(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/servlet/QoSFilter;","_context","Ljavax/servlet/ServletContext;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f009__continuation(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/servlet/QoSFilter;","_continuation","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f010__passes(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/servlet/QoSFilter;","_passes","Ljava/util/concurrent/Semaphore;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f011__queue(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/servlet/QoSFilter;","_queue","[Ljava/util/Queue;"), null);
        if(fv != null) {
            if(fv!=null){
                DexAnnotationVisitor av00 = fv.visitAnnotation("Ldalvik/annotation/Signature;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, "[");
                            av01.visit(null, "Ljava/util/Queue");
                            av01.visit(null, "<");
                            av01.visit(null, "Lorg/mortbay/util/ajax/Continuation;");
                            av01.visit(null, ">;");
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            fv.visitEnd();
        }
    }
    public static void f012__suspendMs(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/servlet/QoSFilter;","_suspendMs","J"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f013__suspended(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/servlet/QoSFilter;","_suspended","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f014__waitMs(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/servlet/QoSFilter;","_waitMs","J"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/servlet/QoSFilter;","<init>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(71,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(88,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(89,L2);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2},new Method("Ljava/lang/Object;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,1,"QoSFilter@");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/lang/Object;","hashCode",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "I"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/servlet/QoSFilter;","_suspended","Ljava/lang/String;"));
                code.visitLabel(L2);
                code.visitConstStmt(CONST_STRING,0,"org.mortbay.jetty.ajax.Continuation");
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/servlet/QoSFilter;","_continuation","Ljava/lang/String;"));
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001_destroy(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/servlet/QoSFilter;","destroy",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(233,L0);
                code.visitLabel(L0);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_doFilter(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/servlet/QoSFilter;","doFilter",new String[]{ "Ljavax/servlet/ServletRequest;","Ljavax/servlet/ServletResponse;","Ljavax/servlet/FilterChain;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visit(null, new DexType("Ljavax/servlet/ServletException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(19);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                DexLabel L3=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2,L3},new String[]{ "Ljava/lang/InterruptedException;",null});
                DexLabel L4=new DexLabel();
                DexLabel L5=new DexLabel();
                DexLabel L6=new DexLabel();
                code.visitTryCatch(L4,L5,new DexLabel[]{L6},new String[]{ null});
                DexLabel L7=new DexLabel();
                DexLabel L8=new DexLabel();
                code.visitTryCatch(L7,L8,new DexLabel[]{L2,L3},new String[]{ "Ljava/lang/InterruptedException;",null});
                DexLabel L9=new DexLabel();
                DexLabel L10=new DexLabel();
                code.visitTryCatch(L8,L9,new DexLabel[]{L10},new String[]{ null});
                code.visitTryCatch(L9,L2,new DexLabel[]{L2,L3},new String[]{ "Ljava/lang/InterruptedException;",null});
                DexLabel L11=new DexLabel();
                DexLabel L12=new DexLabel();
                code.visitTryCatch(L11,L12,new DexLabel[]{L3},new String[]{ null});
                DexLabel L13=new DexLabel();
                DexLabel L14=new DexLabel();
                DexLabel L15=new DexLabel();
                code.visitTryCatch(L13,L14,new DexLabel[]{L15},new String[]{ null});
                DexLabel L16=new DexLabel();
                DexLabel L17=new DexLabel();
                code.visitTryCatch(L16,L17,new DexLabel[]{L2,L3},new String[]{ "Ljava/lang/InterruptedException;",null});
                DexLabel L18=new DexLabel();
                DexLabel L19=new DexLabel();
                DexLabel L20=new DexLabel();
                code.visitTryCatch(L18,L19,new DexLabel[]{L20},new String[]{ null});
                DexLabel L21=new DexLabel();
                DexLabel L22=new DexLabel();
                code.visitTryCatch(L21,L22,new DexLabel[]{L20},new String[]{ null});
                DexLabel L23=new DexLabel();
                DexLabel L24=new DexLabel();
                code.visitTryCatch(L23,L24,new DexLabel[]{L15},new String[]{ null});
                DexLabel L25=new DexLabel();
                DexLabel L26=new DexLabel();
                code.visitTryCatch(L25,L26,new DexLabel[]{L6},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"request");
                ddv.visitParameterName(1,"response");
                ddv.visitParameterName(2,"chain");
                DexLabel L27=new DexLabel();
                ddv.visitPrologue(L27);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(121,L28);
                ddv.visitLineNumber(124,L0);
                ddv.visitStartLocal(3,L0,"accepted","Z",null);
                DexLabel L29=new DexLabel();
                ddv.visitLineNumber(125,L29);
                ddv.visitStartLocal(9,L29,"suspended","Ljava/lang/Boolean;",null);
                DexLabel L30=new DexLabel();
                ddv.visitLineNumber(127,L30);
                DexLabel L31=new DexLabel();
                ddv.visitLineNumber(129,L31);
                DexLabel L32=new DexLabel();
                ddv.visitLineNumber(131,L32);
                DexLabel L33=new DexLabel();
                ddv.visitLineNumber(148,L33);
                DexLabel L34=new DexLabel();
                ddv.visitLineNumber(150,L34);
                DexLabel L35=new DexLabel();
                ddv.visitLineNumber(151,L35);
                DexLabel L36=new DexLabel();
                ddv.visitLineNumber(152,L36);
                ddv.visitStartLocal(4,L36,"continuation","Lorg/mortbay/util/ajax/Continuation;",null);
                DexLabel L37=new DexLabel();
                ddv.visitLineNumber(154,L37);
                DexLabel L38=new DexLabel();
                ddv.visitLineNumber(155,L38);
                DexLabel L39=new DexLabel();
                ddv.visitLineNumber(170,L39);
                ddv.visitEndLocal(4,L39);
                DexLabel L40=new DexLabel();
                ddv.visitLineNumber(172,L40);
                ddv.visitLineNumber(185,L1);
                DexLabel L41=new DexLabel();
                ddv.visitLineNumber(187,L41);
                ddv.visitLineNumber(189,L4);
                DexLabel L42=new DexLabel();
                ddv.visitStartLocal(6,L42,"p","I",null);
                DexLabel L43=new DexLabel();
                ddv.visitEndLocal(6,L43);
                ddv.visitStartLocal(7,L43,"p","I",null);
                DexLabel L44=new DexLabel();
                ddv.visitRestartLocal(6,L44);
                DexLabel L45=new DexLabel();
                ddv.visitLineNumber(191,L45);
                ddv.visitEndLocal(7,L45);
                DexLabel L46=new DexLabel();
                ddv.visitLineNumber(192,L46);
                ddv.visitRestartLocal(4,L46);
                DexLabel L47=new DexLabel();
                ddv.visitLineNumber(194,L47);
                DexLabel L48=new DexLabel();
                ddv.visitLineNumber(198,L48);
                ddv.visitEndLocal(4,L48);
                ddv.visitLineNumber(199,L5);
                DexLabel L49=new DexLabel();
                ddv.visitEndLocal(17,L49);
                ddv.visitEndLocal(9,L49);
                DexLabel L50=new DexLabel();
                ddv.visitLineNumber(202,L50);
                ddv.visitEndLocal(6,L50);
                ddv.visitLineNumber(135,L7);
                ddv.visitRestartLocal(9,L7);
                ddv.visitRestartLocal(17,L7);
                DexLabel L51=new DexLabel();
                ddv.visitLineNumber(136,L51);
                ddv.visitRestartLocal(4,L51);
                DexLabel L52=new DexLabel();
                ddv.visitLineNumber(137,L52);
                ddv.visitStartLocal(8,L52,"priority","I",null);
                DexLabel L53=new DexLabel();
                ddv.visitLineNumber(138,L53);
                ddv.visitRestartLocal(9,L53);
                DexLabel L54=new DexLabel();
                ddv.visitLineNumber(139,L54);
                ddv.visitLineNumber(141,L8);
                DexLabel L55=new DexLabel();
                ddv.visitLineNumber(142,L55);
                DexLabel L56=new DexLabel();
                ddv.visitLineNumber(144,L56);
                ddv.visitLineNumber(178,L2);
                ddv.visitEndLocal(4,L2);
                ddv.visitEndLocal(8,L2);
                ddv.visitEndLocal(9,L2);
                ddv.visitLineNumber(180,L11);
                ddv.visitStartLocal(5,L11,"e","Ljava/lang/InterruptedException;",null);
                DexLabel L57=new DexLabel();
                ddv.visitLineNumber(181,L57);
                DexLabel L58=new DexLabel();
                ddv.visitEndLocal(17,L58);
                ddv.visitLineNumber(185,L12);
                DexLabel L59=new DexLabel();
                ddv.visitLineNumber(187,L59);
                ddv.visitLineNumber(189,L13);
                DexLabel L60=new DexLabel();
                ddv.visitRestartLocal(6,L60);
                DexLabel L61=new DexLabel();
                ddv.visitEndLocal(6,L61);
                ddv.visitRestartLocal(7,L61);
                DexLabel L62=new DexLabel();
                ddv.visitRestartLocal(6,L62);
                DexLabel L63=new DexLabel();
                ddv.visitLineNumber(191,L63);
                ddv.visitEndLocal(7,L63);
                DexLabel L64=new DexLabel();
                ddv.visitLineNumber(192,L64);
                ddv.visitRestartLocal(4,L64);
                DexLabel L65=new DexLabel();
                ddv.visitLineNumber(194,L65);
                DexLabel L66=new DexLabel();
                ddv.visitLineNumber(198,L66);
                ddv.visitEndLocal(4,L66);
                ddv.visitLineNumber(199,L14);
                ddv.visitLineNumber(160,L16);
                ddv.visitEndLocal(5,L16);
                ddv.visitEndLocal(6,L16);
                ddv.visitRestartLocal(4,L16);
                ddv.visitRestartLocal(9,L16);
                ddv.visitRestartLocal(17,L16);
                DexLabel L67=new DexLabel();
                ddv.visitRestartLocal(3,L67);
                DexLabel L68=new DexLabel();
                ddv.visitLineNumber(163,L68);
                ddv.visitEndLocal(4,L68);
                DexLabel L69=new DexLabel();
                ddv.visitLineNumber(166,L69);
                DexLabel L70=new DexLabel();
                ddv.visitLineNumber(167,L70);
                DexLabel L71=new DexLabel();
                ddv.visitLineNumber(175,L71);
                ddv.visitLineNumber(185,L3);
                ddv.visitEndLocal(9,L3);
                ddv.visitEndLocal(17,L3);
                DexLabel L72=new DexLabel();
                ddv.visitLineNumber(187,L72);
                ddv.visitLineNumber(189,L18);
                DexLabel L73=new DexLabel();
                ddv.visitRestartLocal(6,L73);
                DexLabel L74=new DexLabel();
                ddv.visitEndLocal(6,L74);
                ddv.visitRestartLocal(7,L74);
                DexLabel L75=new DexLabel();
                ddv.visitRestartLocal(6,L75);
                DexLabel L76=new DexLabel();
                ddv.visitLineNumber(191,L76);
                ddv.visitEndLocal(7,L76);
                DexLabel L77=new DexLabel();
                ddv.visitLineNumber(192,L77);
                ddv.visitRestartLocal(4,L77);
                DexLabel L78=new DexLabel();
                ddv.visitLineNumber(194,L78);
                DexLabel L79=new DexLabel();
                ddv.visitLineNumber(198,L79);
                ddv.visitEndLocal(4,L79);
                ddv.visitLineNumber(199,L19);
                DexLabel L80=new DexLabel();
                ddv.visitLineNumber(185,L80);
                ddv.visitEndLocal(6,L80);
                ddv.visitLineNumber(198,L20);
                DexLabel L81=new DexLabel();
                ddv.visitRestartLocal(4,L81);
                ddv.visitRestartLocal(6,L81);
                DexLabel L82=new DexLabel();
                ddv.visitLineNumber(197,L82);
                ddv.visitRestartLocal(7,L82);
                ddv.visitLineNumber(198,L15);
                ddv.visitEndLocal(4,L15);
                ddv.visitEndLocal(6,L15);
                ddv.visitEndLocal(7,L15);
                ddv.visitRestartLocal(5,L15);
                DexLabel L83=new DexLabel();
                ddv.visitRestartLocal(4,L83);
                ddv.visitRestartLocal(6,L83);
                DexLabel L84=new DexLabel();
                ddv.visitLineNumber(197,L84);
                ddv.visitRestartLocal(7,L84);
                ddv.visitLineNumber(198,L6);
                ddv.visitEndLocal(5,L6);
                ddv.visitEndLocal(4,L6);
                ddv.visitEndLocal(6,L6);
                ddv.visitEndLocal(7,L6);
                ddv.visitRestartLocal(9,L6);
                ddv.visitRestartLocal(17,L6);
                DexLabel L85=new DexLabel();
                ddv.visitRestartLocal(4,L85);
                ddv.visitRestartLocal(6,L85);
                DexLabel L86=new DexLabel();
                ddv.visitLineNumber(197,L86);
                ddv.visitRestartLocal(7,L86);
                code.visitLabel(L27);
                code.visitConstStmt(CONST_4,14, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L28);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,10,15,new Field("Lorg/mortbay/servlet/QoSFilter;","_suspended","Ljava/lang/String;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,16);
                code.visitStmt2R(MOVE_OBJECT,1,10);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1},new Method("Ljavax/servlet/ServletRequest;","getAttribute",new String[]{ "Ljava/lang/String;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitTypeStmt(CHECK_CAST,9,-1,"Ljava/lang/Boolean;");
                code.visitLabel(L29);
                code.visitJumpStmt(IF_NEZ,9,-1,L33);
                code.visitLabel(L30);
                code.visitFieldStmt(IGET_OBJECT,10,15,new Field("Lorg/mortbay/servlet/QoSFilter;","_passes","Ljava/util/concurrent/Semaphore;"));
                code.visitFieldStmt(IGET_WIDE,11,15,new Field("Lorg/mortbay/servlet/QoSFilter;","_waitMs","J"));
                code.visitFieldStmt(SGET_OBJECT,13,-1,new Field("Ljava/util/concurrent/TimeUnit;","MILLISECONDS","Ljava/util/concurrent/TimeUnit;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10,11,12,13},new Method("Ljava/util/concurrent/Semaphore;","tryAcquire",new String[]{ "J","Ljava/util/concurrent/TimeUnit;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitLabel(L31);
                code.visitJumpStmt(IF_EQZ,3,-1,L7);
                code.visitLabel(L32);
                code.visitFieldStmt(IGET_OBJECT,10,15,new Field("Lorg/mortbay/servlet/QoSFilter;","_suspended","Ljava/lang/String;"));
                code.visitFieldStmt(SGET_OBJECT,11,-1,new Field("Ljava/lang/Boolean;","FALSE","Ljava/lang/Boolean;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,16);
                code.visitStmt2R(MOVE_OBJECT,1,10);
                code.visitStmt2R(MOVE_OBJECT,2,11);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1,2},new Method("Ljavax/servlet/ServletRequest;","setAttribute",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L33);
                code.visitJumpStmt(IF_EQZ,9,-1,L68);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9},new Method("Ljava/lang/Boolean;","booleanValue",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,10);
                code.visitJumpStmt(IF_EQZ,10,-1,L68);
                code.visitLabel(L34);
                code.visitFieldStmt(IGET_OBJECT,10,15,new Field("Lorg/mortbay/servlet/QoSFilter;","_suspended","Ljava/lang/String;"));
                code.visitFieldStmt(SGET_OBJECT,11,-1,new Field("Ljava/lang/Boolean;","FALSE","Ljava/lang/Boolean;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,16);
                code.visitStmt2R(MOVE_OBJECT,1,10);
                code.visitStmt2R(MOVE_OBJECT,2,11);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1,2},new Method("Ljavax/servlet/ServletRequest;","setAttribute",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L35);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,16);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Ljavax/servlet/http/HttpServletRequest;");
                code.visitStmt2R(MOVE_OBJECT,10,0);
                code.visitFieldStmt(IGET_OBJECT,11,15,new Field("Lorg/mortbay/servlet/QoSFilter;","_queue","[Ljava/util/Queue;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 10,11},new Method("Lorg/mortbay/util/ajax/ContinuationSupport;","getContinuation",new String[]{ "Ljavax/servlet/http/HttpServletRequest;","Ljava/lang/Object;"},"Lorg/mortbay/util/ajax/Continuation;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitLabel(L36);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 4},new Method("Lorg/mortbay/util/ajax/Continuation;","isResumed",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,10);
                code.visitJumpStmt(IF_EQZ,10,-1,L16);
                code.visitLabel(L37);
                code.visitFieldStmt(IGET_OBJECT,10,15,new Field("Lorg/mortbay/servlet/QoSFilter;","_passes","Ljava/util/concurrent/Semaphore;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Ljava/util/concurrent/Semaphore;","acquire",new String[]{ },"V"));
                code.visitLabel(L38);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L39);
                code.visitJumpStmt(IF_EQZ,3,-1,L71);
                code.visitLabel(L40);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,18);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,16);
                code.visitStmt2R(MOVE_OBJECT_FROM16,2,17);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1,2},new Method("Ljavax/servlet/FilterChain;","doFilter",new String[]{ "Ljavax/servlet/ServletRequest;","Ljavax/servlet/ServletResponse;"},"V"));
                code.visitLabel(L1);
                code.visitJumpStmt(IF_EQZ,3,-1,L50);
                code.visitLabel(L41);
                code.visitFieldStmt(IGET_OBJECT,10,15,new Field("Lorg/mortbay/servlet/QoSFilter;","_queue","[Ljava/util/Queue;"));
                code.visitStmt1R(MONITOR_ENTER,10);
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,11,15,new Field("Lorg/mortbay/servlet/QoSFilter;","_queue","[Ljava/util/Queue;"));
                code.visitStmt2R(ARRAY_LENGTH,6,11);
                code.visitLabel(L42);
                code.visitStmt2R(MOVE,7,6);
                code.visitLabel(L43);
                code.visitStmt3R(SUB_INT,6,7,14);
                code.visitLabel(L44);
                code.visitJumpStmt(IF_LEZ,7,-1,L48);
                code.visitLabel(L45);
                code.visitFieldStmt(IGET_OBJECT,11,15,new Field("Lorg/mortbay/servlet/QoSFilter;","_queue","[Ljava/util/Queue;"));
                code.visitStmt3R(AGET_OBJECT,11,11,6);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 11},new Method("Ljava/util/Queue;","poll",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitTypeStmt(CHECK_CAST,4,-1,"Lorg/mortbay/util/ajax/Continuation;");
                code.visitLabel(L46);
                code.visitJumpStmt(IF_EQZ,4,-1,L85);
                code.visitLabel(L47);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 4},new Method("Lorg/mortbay/util/ajax/Continuation;","resume",new String[]{ },"V"));
                code.visitLabel(L48);
                code.visitStmt1R(MONITOR_EXIT,10);
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,10,15,new Field("Lorg/mortbay/servlet/QoSFilter;","_passes","Ljava/util/concurrent/Semaphore;"));
                code.visitLabel(L49);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Ljava/util/concurrent/Semaphore;","release",new String[]{ },"V"));
                code.visitLabel(L50);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L7);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,16);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Ljavax/servlet/http/HttpServletRequest;");
                code.visitStmt2R(MOVE_OBJECT,10,0);
                code.visitFieldStmt(IGET_OBJECT,11,15,new Field("Lorg/mortbay/servlet/QoSFilter;","_queue","[Ljava/util/Queue;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 10,11},new Method("Lorg/mortbay/util/ajax/ContinuationSupport;","getContinuation",new String[]{ "Ljavax/servlet/http/HttpServletRequest;","Ljava/lang/Object;"},"Lorg/mortbay/util/ajax/Continuation;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitLabel(L51);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 15,16},new Method("Lorg/mortbay/servlet/QoSFilter;","getPriority",new String[]{ "Ljavax/servlet/ServletRequest;"},"I"));
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitLabel(L52);
                code.visitFieldStmt(SGET_OBJECT,9,-1,new Field("Ljava/lang/Boolean;","TRUE","Ljava/lang/Boolean;"));
                code.visitLabel(L53);
                code.visitFieldStmt(IGET_OBJECT,10,15,new Field("Lorg/mortbay/servlet/QoSFilter;","_suspended","Ljava/lang/String;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,16);
                code.visitStmt2R(MOVE_OBJECT,1,10);
                code.visitStmt2R(MOVE_OBJECT,2,9);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1,2},new Method("Ljavax/servlet/ServletRequest;","setAttribute",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L54);
                code.visitFieldStmt(IGET_OBJECT,10,15,new Field("Lorg/mortbay/servlet/QoSFilter;","_queue","[Ljava/util/Queue;"));
                code.visitStmt1R(MONITOR_ENTER,10);
                code.visitLabel(L8);
                code.visitFieldStmt(IGET_OBJECT,11,15,new Field("Lorg/mortbay/servlet/QoSFilter;","_queue","[Ljava/util/Queue;"));
                code.visitStmt3R(AGET_OBJECT,11,11,8);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 11,4},new Method("Ljava/util/Queue;","add",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitLabel(L55);
                code.visitFieldStmt(IGET_WIDE,11,15,new Field("Lorg/mortbay/servlet/QoSFilter;","_suspendMs","J"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 4,11,12},new Method("Lorg/mortbay/util/ajax/Continuation;","suspend",new String[]{ "J"},"Z"));
                code.visitLabel(L56);
                code.visitStmt1R(MONITOR_EXIT,10);
                code.visitJumpStmt(GOTO_16,-1,-1,L33);
                code.visitLabel(L10);
                code.visitStmt1R(MOVE_EXCEPTION,11);
                code.visitStmt1R(MONITOR_EXIT,10);
                code.visitLabel(L9);
                code.visitStmt1R(THROW,11);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,10);
                code.visitStmt2R(MOVE_OBJECT,5,10);
                code.visitLabel(L11);
                code.visitFieldStmt(IGET_OBJECT,10,15,new Field("Lorg/mortbay/servlet/QoSFilter;","_context","Ljavax/servlet/ServletContext;"));
                code.visitConstStmt(CONST_STRING,11,"QoS");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 10,11,5},new Method("Ljavax/servlet/ServletContext;","log",new String[]{ "Ljava/lang/String;","Ljava/lang/Throwable;"},"V"));
                code.visitLabel(L57);
                code.visitTypeStmt(CHECK_CAST,17,-1,"Ljavax/servlet/http/HttpServletResponse;");
                code.visitLabel(L58);
                code.visitConstStmt(CONST_16,10, Integer.valueOf(503)); // int: 0x000001f7  float:0.000000
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,17);
                code.visitStmt2R(MOVE,1,10);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1},new Method("Ljavax/servlet/http/HttpServletResponse;","sendError",new String[]{ "I"},"V"));
                code.visitLabel(L12);
                code.visitJumpStmt(IF_EQZ,3,-1,L50);
                code.visitLabel(L59);
                code.visitFieldStmt(IGET_OBJECT,10,15,new Field("Lorg/mortbay/servlet/QoSFilter;","_queue","[Ljava/util/Queue;"));
                code.visitStmt1R(MONITOR_ENTER,10);
                code.visitLabel(L13);
                code.visitFieldStmt(IGET_OBJECT,11,15,new Field("Lorg/mortbay/servlet/QoSFilter;","_queue","[Ljava/util/Queue;"));
                code.visitStmt2R(ARRAY_LENGTH,6,11);
                code.visitLabel(L60);
                code.visitStmt2R(MOVE,7,6);
                code.visitLabel(L61);
                code.visitStmt3R(SUB_INT,6,7,14);
                code.visitLabel(L62);
                code.visitJumpStmt(IF_LEZ,7,-1,L66);
                code.visitLabel(L63);
                code.visitFieldStmt(IGET_OBJECT,11,15,new Field("Lorg/mortbay/servlet/QoSFilter;","_queue","[Ljava/util/Queue;"));
                code.visitStmt3R(AGET_OBJECT,11,11,6);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 11},new Method("Ljava/util/Queue;","poll",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitTypeStmt(CHECK_CAST,4,-1,"Lorg/mortbay/util/ajax/Continuation;");
                code.visitLabel(L64);
                code.visitJumpStmt(IF_EQZ,4,-1,L83);
                code.visitLabel(L65);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 4},new Method("Lorg/mortbay/util/ajax/Continuation;","resume",new String[]{ },"V"));
                code.visitLabel(L66);
                code.visitStmt1R(MONITOR_EXIT,10);
                code.visitLabel(L14);
                code.visitFieldStmt(IGET_OBJECT,10,15,new Field("Lorg/mortbay/servlet/QoSFilter;","_passes","Ljava/util/concurrent/Semaphore;"));
                code.visitJumpStmt(GOTO,-1,-1,L49);
                code.visitLabel(L16);
                code.visitFieldStmt(IGET_OBJECT,10,15,new Field("Lorg/mortbay/servlet/QoSFilter;","_passes","Ljava/util/concurrent/Semaphore;"));
                code.visitFieldStmt(IGET_WIDE,11,15,new Field("Lorg/mortbay/servlet/QoSFilter;","_waitMs","J"));
                code.visitFieldStmt(SGET_OBJECT,13,-1,new Field("Ljava/util/concurrent/TimeUnit;","MILLISECONDS","Ljava/util/concurrent/TimeUnit;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10,11,12,13},new Method("Ljava/util/concurrent/Semaphore;","tryAcquire",new String[]{ "J","Ljava/util/concurrent/TimeUnit;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitLabel(L67);
                code.visitJumpStmt(GOTO_16,-1,-1,L39);
                code.visitLabel(L68);
                code.visitJumpStmt(IF_NEZ,3,-1,L39);
                code.visitLabel(L69);
                code.visitFieldStmt(IGET_OBJECT,10,15,new Field("Lorg/mortbay/servlet/QoSFilter;","_passes","Ljava/util/concurrent/Semaphore;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Ljava/util/concurrent/Semaphore;","acquire",new String[]{ },"V"));
                code.visitLabel(L70);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitJumpStmt(GOTO_16,-1,-1,L39);
                code.visitLabel(L71);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,17);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Ljavax/servlet/http/HttpServletResponse;");
                code.visitStmt2R(MOVE_OBJECT,10,0);
                code.visitConstStmt(CONST_16,11, Integer.valueOf(503)); // int: 0x000001f7  float:0.000000
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 10,11},new Method("Ljavax/servlet/http/HttpServletResponse;","sendError",new String[]{ "I"},"V"));
                code.visitLabel(L17);
                code.visitJumpStmt(GOTO_16,-1,-1,L1);
                code.visitLabel(L3);
                code.visitStmt1R(MOVE_EXCEPTION,10);
                code.visitJumpStmt(IF_EQZ,3,-1,L80);
                code.visitLabel(L72);
                code.visitFieldStmt(IGET_OBJECT,11,15,new Field("Lorg/mortbay/servlet/QoSFilter;","_queue","[Ljava/util/Queue;"));
                code.visitStmt1R(MONITOR_ENTER,11);
                code.visitLabel(L18);
                code.visitFieldStmt(IGET_OBJECT,12,15,new Field("Lorg/mortbay/servlet/QoSFilter;","_queue","[Ljava/util/Queue;"));
                code.visitStmt2R(ARRAY_LENGTH,6,12);
                code.visitLabel(L73);
                code.visitStmt2R(MOVE,7,6);
                code.visitLabel(L74);
                code.visitStmt3R(SUB_INT,6,7,14);
                code.visitLabel(L75);
                code.visitJumpStmt(IF_LEZ,7,-1,L79);
                code.visitLabel(L76);
                code.visitFieldStmt(IGET_OBJECT,12,15,new Field("Lorg/mortbay/servlet/QoSFilter;","_queue","[Ljava/util/Queue;"));
                code.visitStmt3R(AGET_OBJECT,12,12,6);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 12},new Method("Ljava/util/Queue;","poll",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitTypeStmt(CHECK_CAST,4,-1,"Lorg/mortbay/util/ajax/Continuation;");
                code.visitLabel(L77);
                code.visitJumpStmt(IF_EQZ,4,-1,L81);
                code.visitLabel(L78);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 4},new Method("Lorg/mortbay/util/ajax/Continuation;","resume",new String[]{ },"V"));
                code.visitLabel(L79);
                code.visitStmt1R(MONITOR_EXIT,11);
                code.visitLabel(L19);
                code.visitFieldStmt(IGET_OBJECT,11,15,new Field("Lorg/mortbay/servlet/QoSFilter;","_passes","Ljava/util/concurrent/Semaphore;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11},new Method("Ljava/util/concurrent/Semaphore;","release",new String[]{ },"V"));
                code.visitLabel(L80);
                code.visitStmt1R(THROW,10);
                code.visitLabel(L20);
                code.visitStmt1R(MOVE_EXCEPTION,10);
                code.visitLabel(L21);
                code.visitStmt1R(MONITOR_EXIT,11);
                code.visitLabel(L22);
                code.visitStmt1R(THROW,10);
                code.visitLabel(L81);
                code.visitStmt2R(MOVE,7,6);
                code.visitLabel(L82);
                code.visitJumpStmt(GOTO,-1,-1,L74);
                code.visitLabel(L15);
                code.visitStmt1R(MOVE_EXCEPTION,11);
                code.visitLabel(L23);
                code.visitStmt1R(MONITOR_EXIT,10);
                code.visitLabel(L24);
                code.visitStmt1R(THROW,11);
                code.visitLabel(L83);
                code.visitStmt2R(MOVE,7,6);
                code.visitLabel(L84);
                code.visitJumpStmt(GOTO,-1,-1,L61);
                code.visitLabel(L6);
                code.visitStmt1R(MOVE_EXCEPTION,11);
                code.visitLabel(L25);
                code.visitStmt1R(MONITOR_EXIT,10);
                code.visitLabel(L26);
                code.visitStmt1R(THROW,11);
                code.visitLabel(L85);
                code.visitStmt2R(MOVE,7,6);
                code.visitLabel(L86);
                code.visitJumpStmt(GOTO_16,-1,-1,L43);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_getPriority(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/servlet/QoSFilter;","getPriority",new String[]{ "Ljavax/servlet/ServletRequest;"},"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"request");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(218,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(219,L2);
                ddv.visitStartLocal(1,L2,"base_request","Ljavax/servlet/http/HttpServletRequest;",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(220,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(227,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(223,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(224,L6);
                ddv.visitStartLocal(2,L6,"session","Ljavax/servlet/http/HttpSession;",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(225,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(227,L8);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitStmt2R(MOVE_OBJECT,0,6);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Ljavax/servlet/http/HttpServletRequest;");
                code.visitStmt2R(MOVE_OBJECT,1,0);
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Ljavax/servlet/http/HttpServletRequest;","getUserPrincipal",new String[]{ },"Ljava/security/Principal;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitJumpStmt(IF_EQZ,3,-1,L5);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitLabel(L4);
                code.visitStmt1R(RETURN,3);
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1,4},new Method("Ljavax/servlet/http/HttpServletRequest;","getSession",new String[]{ "Z"},"Ljavax/servlet/http/HttpSession;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L6);
                DexLabel L9=new DexLabel();
                code.visitJumpStmt(IF_EQZ,2,-1,L9);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2},new Method("Ljavax/servlet/http/HttpSession;","isNew",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_NEZ,3,-1,L9);
                code.visitLabel(L7);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitLabel(L9);
                code.visitStmt2R(MOVE,3,4);
                code.visitLabel(L8);
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_init(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/servlet/QoSFilter;","init",new String[]{ "Ljavax/servlet/FilterConfig;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(14);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"filterConfig");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(93,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(95,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(96,L3);
                ddv.visitStartLocal(0,L3,"max_priority","I",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(97,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(98,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(99,L6);
                DexLabel L7=new DexLabel();
                ddv.visitStartLocal(1,L7,"p","I",null);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(100,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(99,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(102,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(103,L11);
                ddv.visitStartLocal(2,L11,"passes","I",null);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(104,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(105,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(107,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(108,L15);
                ddv.visitStartLocal(5,L15,"wait","J",null);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(109,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(110,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(112,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(113,L19);
                ddv.visitStartLocal(3,L19,"suspend","J",null);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(114,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(115,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(116,L22);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_STRING,11,"suspendMs");
                code.visitConstStmt(CONST_STRING,10,"maxWaitMs");
                code.visitConstStmt(CONST_STRING,9,"maxRequests");
                code.visitConstStmt(CONST_STRING,8,"maxPriority");
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 13},new Method("Ljavax/servlet/FilterConfig;","getServletContext",new String[]{ },"Ljavax/servlet/ServletContext;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitFieldStmt(IPUT_OBJECT,7,12,new Field("Lorg/mortbay/servlet/QoSFilter;","_context","Ljavax/servlet/ServletContext;"));
                code.visitLabel(L2);
                code.visitConstStmt(CONST_16,0, Integer.valueOf(10)); // int: 0x0000000a  float:0.000000
                code.visitLabel(L3);
                code.visitConstStmt(CONST_STRING,7,"maxPriority");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 13,8},new Method("Ljavax/servlet/FilterConfig;","getInitParameter",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitJumpStmt(IF_EQZ,7,-1,L5);
                code.visitLabel(L4);
                code.visitConstStmt(CONST_STRING,7,"maxPriority");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 13,8},new Method("Ljavax/servlet/FilterConfig;","getInitParameter",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 7},new Method("Ljava/lang/Integer;","parseInt",new String[]{ "Ljava/lang/String;"},"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitLabel(L5);
                code.visitStmt2R1N(ADD_INT_LIT8,7,0,1);
                code.visitTypeStmt(NEW_ARRAY,7,7,"[Ljava/util/Queue;");
                code.visitFieldStmt(IPUT_OBJECT,7,12,new Field("Lorg/mortbay/servlet/QoSFilter;","_queue","[Ljava/util/Queue;"));
                code.visitLabel(L6);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L7);
                code.visitFieldStmt(IGET_OBJECT,7,12,new Field("Lorg/mortbay/servlet/QoSFilter;","_queue","[Ljava/util/Queue;"));
                code.visitStmt2R(ARRAY_LENGTH,7,7);
                code.visitJumpStmt(IF_GE,1,7,L10);
                code.visitLabel(L8);
                code.visitFieldStmt(IGET_OBJECT,7,12,new Field("Lorg/mortbay/servlet/QoSFilter;","_queue","[Ljava/util/Queue;"));
                code.visitTypeStmt(NEW_INSTANCE,8,-1,"Lorg/mortbay/util/ArrayQueue;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 8},new Method("Lorg/mortbay/util/ArrayQueue;","<init>",new String[]{ },"V"));
                code.visitStmt3R(APUT_OBJECT,8,7,1);
                code.visitLabel(L9);
                code.visitStmt2R1N(ADD_INT_LIT8,1,1,1);
                code.visitJumpStmt(GOTO,-1,-1,L7);
                code.visitLabel(L10);
                code.visitConstStmt(CONST_16,2, Integer.valueOf(10)); // int: 0x0000000a  float:0.000000
                code.visitLabel(L11);
                code.visitConstStmt(CONST_STRING,7,"maxRequests");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 13,9},new Method("Ljavax/servlet/FilterConfig;","getInitParameter",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitJumpStmt(IF_EQZ,7,-1,L13);
                code.visitLabel(L12);
                code.visitConstStmt(CONST_STRING,7,"maxRequests");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 13,9},new Method("Ljavax/servlet/FilterConfig;","getInitParameter",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 7},new Method("Ljava/lang/Integer;","parseInt",new String[]{ "Ljava/lang/String;"},"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitLabel(L13);
                code.visitTypeStmt(NEW_INSTANCE,7,-1,"Ljava/util/concurrent/Semaphore;");
                code.visitConstStmt(CONST_4,8, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 7,2,8},new Method("Ljava/util/concurrent/Semaphore;","<init>",new String[]{ "I","Z"},"V"));
                code.visitFieldStmt(IPUT_OBJECT,7,12,new Field("Lorg/mortbay/servlet/QoSFilter;","_passes","Ljava/util/concurrent/Semaphore;"));
                code.visitLabel(L14);
                code.visitConstStmt(CONST_WIDE_16,5,Long.valueOf(50L)); // long: 0x0000000000000032  double:0.000000
                code.visitLabel(L15);
                code.visitConstStmt(CONST_STRING,7,"maxWaitMs");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 13,10},new Method("Ljavax/servlet/FilterConfig;","getInitParameter",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitJumpStmt(IF_EQZ,7,-1,L17);
                code.visitLabel(L16);
                code.visitConstStmt(CONST_STRING,7,"maxWaitMs");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 13,10},new Method("Ljavax/servlet/FilterConfig;","getInitParameter",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 7},new Method("Ljava/lang/Integer;","parseInt",new String[]{ "Ljava/lang/String;"},"I"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitStmt2R(INT_TO_LONG,5,7);
                code.visitLabel(L17);
                code.visitFieldStmt(IPUT_WIDE,5,12,new Field("Lorg/mortbay/servlet/QoSFilter;","_waitMs","J"));
                code.visitLabel(L18);
                code.visitConstStmt(CONST_WIDE_16,3,Long.valueOf(30000L)); // long: 0x0000000000007530  double:0.000000
                code.visitLabel(L19);
                code.visitConstStmt(CONST_STRING,7,"suspendMs");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 13,11},new Method("Ljavax/servlet/FilterConfig;","getInitParameter",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitJumpStmt(IF_EQZ,7,-1,L21);
                code.visitLabel(L20);
                code.visitConstStmt(CONST_STRING,7,"suspendMs");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 13,11},new Method("Ljavax/servlet/FilterConfig;","getInitParameter",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 7},new Method("Ljava/lang/Integer;","parseInt",new String[]{ "Ljava/lang/String;"},"I"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitStmt2R(INT_TO_LONG,3,7);
                code.visitLabel(L21);
                code.visitFieldStmt(IPUT_WIDE,3,12,new Field("Lorg/mortbay/servlet/QoSFilter;","_suspendMs","J"));
                code.visitLabel(L22);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
