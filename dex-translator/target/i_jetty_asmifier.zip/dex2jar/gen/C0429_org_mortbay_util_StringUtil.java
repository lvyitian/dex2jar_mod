package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0429_org_mortbay_util_StringUtil {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/util/StringUtil;","Ljava/lang/Object;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("StringUtil.java");
        f000_CRLF(cv);
        f001___ISO_8859_1(cv);
        f002___LINE_SEPARATOR(cv);
        f003___UTF16(cv);
        f004___UTF8(cv);
        f005___UTF8Alt(cv);
        f006_lowercases(cv);
        m000__clinit_(cv);
        m001__init_(cv);
        m002_append(cv);
        m003_append(cv);
        m004_append2digits(cv);
        m005_asciiToLowerCase(cv);
        m006_endsWithIgnoreCase(cv);
        m007_equals(cv);
        m008_indexFrom(cv);
        m009_isUTF8(cv);
        m010_nonNull(cv);
        m011_printable(cv);
        m012_replace(cv);
        m013_startsWithIgnoreCase(cv);
        m014_toString(cv);
        m015_toUTF8String(cv);
        m016_unquote(cv);
    }
    public static void f000_CRLF(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/util/StringUtil;","CRLF","Ljava/lang/String;"), "\r\n");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001___ISO_8859_1(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/util/StringUtil;","__ISO_8859_1","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002___LINE_SEPARATOR(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/util/StringUtil;","__LINE_SEPARATOR","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003___UTF16(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/util/StringUtil;","__UTF16","Ljava/lang/String;"), "UTF-16");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f004___UTF8(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/util/StringUtil;","__UTF8","Ljava/lang/String;"), "UTF-8");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f005___UTF8Alt(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/util/StringUtil;","__UTF8Alt","Ljava/lang/String;"), "UTF8");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f006_lowercases(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC, new Field("Lorg/mortbay/util/StringUtil;","lowercases","[C"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__clinit_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/util/StringUtil;","<clinit>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/io/UnsupportedEncodingException;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(32,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(38,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(39,L5);
                ddv.visitStartLocal(1,L5,"iso","Ljava/lang/String;",null);
                ddv.visitLineNumber(42,L0);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(43,L6);
                ddv.visitLineNumber(50,L1);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(58,L7);
                ddv.visitLineNumber(45,L2);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(47,L8);
                ddv.visitStartLocal(0,L8,"e","Ljava/io/UnsupportedEncodingException;",null);
                DexLabel L9=new DexLabel();
                ddv.visitRestartLocal(1,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(58,L10);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_STRING,2,"line.separator");
                code.visitConstStmt(CONST_STRING,3,"\n");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2,3},new Method("Ljava/lang/System;","getProperty",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitFieldStmt(SPUT_OBJECT,2,-1,new Field("Lorg/mortbay/util/StringUtil;","__LINE_SEPARATOR","Ljava/lang/String;"));
                code.visitLabel(L4);
                code.visitConstStmt(CONST_STRING,2,"ISO_8859_1");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2},new Method("Ljava/lang/System;","getProperty",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L5);
                code.visitJumpStmt(IF_NEZ,1,-1,L1);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Ljava/lang/String;");
                code.visitConstStmt(CONST_4,3, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitTypeStmt(NEW_ARRAY,3,3,"[B");
                code.visitConstStmt(CONST_4,4, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitConstStmt(CONST_16,5, Integer.valueOf(20)); // int: 0x00000014  float:0.000000
                code.visitStmt3R(APUT_BYTE,5,3,4);
                code.visitConstStmt(CONST_STRING,4,"ISO-8859-1");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2,3,4},new Method("Ljava/lang/String;","<init>",new String[]{ "[B","Ljava/lang/String;"},"V"));
                code.visitLabel(L6);
                code.visitConstStmt(CONST_STRING,1,"ISO-8859-1");
                code.visitLabel(L1);
                code.visitFieldStmt(SPUT_OBJECT,1,-1,new Field("Lorg/mortbay/util/StringUtil;","__ISO_8859_1","Ljava/lang/String;"));
                code.visitLabel(L7);
                code.visitConstStmt(CONST_16,2, Integer.valueOf(128)); // int: 0x00000080  float:0.000000
                code.visitTypeStmt(NEW_ARRAY,2,2,"[C");
                code.visitFieldStmt(SPUT_OBJECT,2,-1,new Field("Lorg/mortbay/util/StringUtil;","lowercases","[C"));
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,2);
                code.visitStmt2R(MOVE_OBJECT,0,2);
                code.visitLabel(L8);
                code.visitConstStmt(CONST_STRING,1,"ISO8859_1");
                code.visitLabel(L9);
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitLabel(L10);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/util/StringUtil;","<init>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(29,L0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/Object;","<init>",new String[]{ },"V"));
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_append(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/util/StringUtil;","append",new String[]{ "Ljava/lang/StringBuffer;","B","I"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(9);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"buf");
                ddv.visitParameterName(1,"b");
                ddv.visitParameterName(2,"base");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(254,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(255,L2);
                ddv.visitStartLocal(0,L2,"bi","I",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(256,L3);
                ddv.visitStartLocal(1,L3,"c","I",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(257,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(258,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(259,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(260,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(261,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(262,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(263,L10);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_16,5, Integer.valueOf(57)); // int: 0x00000039  float:0.000000
                code.visitConstStmt(CONST_16,4, Integer.valueOf(48)); // int: 0x00000030  float:0.000000
                code.visitConstStmt(CONST_16,3, Integer.valueOf(10)); // int: 0x0000000a  float:0.000000
                code.visitLabel(L1);
                code.visitStmt2R1N(AND_INT_LIT16,0,7,255);
                code.visitLabel(L2);
                code.visitStmt3R(DIV_INT,2,0,8);
                code.visitStmt2R(REM_INT_2ADDR,2,8);
                code.visitStmt2R1N(ADD_INT_LIT8,1,2,48);
                code.visitLabel(L3);
                code.visitJumpStmt(IF_LE,1,5,L5);
                code.visitLabel(L4);
                code.visitStmt3R(SUB_INT,2,1,4);
                code.visitStmt2R(SUB_INT_2ADDR,2,3);
                code.visitStmt2R1N(ADD_INT_LIT8,1,2,97);
                code.visitLabel(L5);
                code.visitStmt2R(INT_TO_CHAR,2,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,2},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "C"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L6);
                code.visitStmt3R(REM_INT,2,0,8);
                code.visitStmt2R1N(ADD_INT_LIT8,1,2,48);
                code.visitLabel(L7);
                code.visitJumpStmt(IF_LE,1,5,L9);
                code.visitLabel(L8);
                code.visitStmt3R(SUB_INT,2,1,4);
                code.visitStmt2R(SUB_INT_2ADDR,2,3);
                code.visitStmt2R1N(ADD_INT_LIT8,1,2,97);
                code.visitLabel(L9);
                code.visitStmt2R(INT_TO_CHAR,2,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,2},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "C"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L10);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_append(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/util/StringUtil;","append",new String[]{ "Ljava/lang/StringBuffer;","Ljava/lang/String;","I","I"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"buf");
                ddv.visitParameterName(1,"s");
                ddv.visitParameterName(2,"offset");
                ddv.visitParameterName(3,"length");
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(234,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(236,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(237,L5);
                ddv.visitStartLocal(0,L5,"end","I",null);
                DexLabel L6=new DexLabel();
                ddv.visitStartLocal(1,L6,"i","I",null);
                ddv.visitLineNumber(239,L0);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(243,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(244,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(241,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(237,L10);
                ddv.visitLineNumber(243,L2);
                code.visitLabel(L3);
                code.visitStmt1R(MONITOR_ENTER,3);
                code.visitLabel(L4);
                code.visitStmt3R(ADD_INT,0,5,6);
                code.visitLabel(L5);
                code.visitStmt2R(MOVE,1,5);
                code.visitLabel(L6);
                code.visitJumpStmt(IF_GE,1,0,L7);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_LT,1,2,L9);
                code.visitLabel(L7);
                code.visitStmt1R(MONITOR_EXIT,3);
                code.visitLabel(L8);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,1},new Method("Ljava/lang/String;","charAt",new String[]{ "I"},"C"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,2},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "C"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L10);
                code.visitStmt2R1N(ADD_INT_LIT8,1,1,1);
                code.visitJumpStmt(GOTO,-1,-1,L6);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,2);
                code.visitStmt1R(MONITOR_EXIT,3);
                code.visitLabel(L1);
                code.visitStmt1R(THROW,2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_append2digits(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/util/StringUtil;","append2digits",new String[]{ "Ljava/lang/StringBuffer;","I"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"buf");
                ddv.visitParameterName(1,"i");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(269,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(271,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(272,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(274,L3);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_16,0, Integer.valueOf(100)); // int: 0x00000064  float:0.000000
                code.visitJumpStmt(IF_GE,2,0,L3);
                code.visitLabel(L1);
                code.visitStmt2R1N(DIV_INT_LIT8,0,2,10);
                code.visitStmt2R1N(ADD_INT_LIT8,0,0,48);
                code.visitStmt2R(INT_TO_CHAR,0,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,0},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "C"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L2);
                code.visitStmt2R1N(REM_INT_LIT8,0,2,10);
                code.visitStmt2R1N(ADD_INT_LIT8,0,0,48);
                code.visitStmt2R(INT_TO_CHAR,0,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,0},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "C"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L3);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_asciiToLowerCase(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/util/StringUtil;","asciiToLowerCase",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(10);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"s");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(84,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(85,L2);
                ddv.visitStartLocal(0,L2,"c","[C",null);
                DexLabel L3=new DexLabel();
                ddv.visitStartLocal(3,L3,"i","I",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(88,L4);
                ddv.visitEndLocal(3,L4);
                ddv.visitStartLocal(4,L4,"i","I",null);
                DexLabel L5=new DexLabel();
                ddv.visitRestartLocal(3,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(90,L6);
                ddv.visitEndLocal(4,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(91,L7);
                ddv.visitStartLocal(1,L7,"c1","C",null);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(93,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(94,L9);
                ddv.visitStartLocal(2,L9,"c2","C",null);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(96,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(97,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(103,L12);
                ddv.visitEndLocal(3,L12);
                ddv.visitEndLocal(1,L12);
                ddv.visitEndLocal(2,L12);
                ddv.visitRestartLocal(4,L12);
                DexLabel L13=new DexLabel();
                ddv.visitRestartLocal(3,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(105,L14);
                ddv.visitEndLocal(4,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(106,L15);
                DexLabel L16=new DexLabel();
                ddv.visitRestartLocal(4,L16);
                DexLabel L17=new DexLabel();
                ddv.visitEndLocal(4,L17);
                ddv.visitRestartLocal(1,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(101,L18);
                ddv.visitRestartLocal(4,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(109,L19);
                ddv.visitEndLocal(1,L19);
                ddv.visitEndLocal(4,L19);
                DexLabel L20=new DexLabel();
                ddv.visitRestartLocal(4,L20);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_16,8, Integer.valueOf(127)); // int: 0x0000007f  float:0.000000
                code.visitConstStmt(CONST_4,7, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitLabel(L3);
                code.visitStmt2R(MOVE,4,3);
                code.visitLabel(L4);
                code.visitStmt3R(SUB_INT,3,4,7);
                code.visitLabel(L5);
                DexLabel L21=new DexLabel();
                code.visitJumpStmt(IF_LEZ,4,-1,L21);
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9,3},new Method("Ljava/lang/String;","charAt",new String[]{ "I"},"C"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitLabel(L7);
                code.visitJumpStmt(IF_GT,1,8,L17);
                code.visitLabel(L8);
                code.visitFieldStmt(SGET_OBJECT,5,-1,new Field("Lorg/mortbay/util/StringUtil;","lowercases","[C"));
                code.visitStmt3R(AGET_CHAR,2,5,1);
                code.visitLabel(L9);
                code.visitJumpStmt(IF_EQ,1,2,L17);
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9},new Method("Ljava/lang/String;","toCharArray",new String[]{ },"[C"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L11);
                code.visitStmt3R(APUT_CHAR,2,0,3);
                code.visitStmt2R(MOVE,4,3);
                code.visitLabel(L12);
                code.visitStmt3R(SUB_INT,3,4,7);
                code.visitLabel(L13);
                code.visitJumpStmt(IF_LEZ,4,-1,L19);
                code.visitLabel(L14);
                code.visitStmt3R(AGET_CHAR,5,0,3);
                code.visitJumpStmt(IF_GT,5,8,L21);
                code.visitLabel(L15);
                code.visitFieldStmt(SGET_OBJECT,5,-1,new Field("Lorg/mortbay/util/StringUtil;","lowercases","[C"));
                code.visitStmt3R(AGET_CHAR,6,0,3);
                code.visitStmt3R(AGET_CHAR,5,5,6);
                code.visitStmt3R(APUT_CHAR,5,0,3);
                code.visitStmt2R(MOVE,4,3);
                code.visitLabel(L16);
                code.visitJumpStmt(GOTO,-1,-1,L12);
                code.visitLabel(L17);
                code.visitStmt2R(MOVE,4,3);
                code.visitLabel(L18);
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitLabel(L19);
                DexLabel L22=new DexLabel();
                code.visitJumpStmt(IF_NEZ,0,-1,L22);
                code.visitStmt2R(MOVE_OBJECT,5,9);
                DexLabel L23=new DexLabel();
                code.visitLabel(L23);
                code.visitStmt1R(RETURN_OBJECT,5);
                code.visitLabel(L22);
                code.visitTypeStmt(NEW_INSTANCE,5,-1,"Ljava/lang/String;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 5,0},new Method("Ljava/lang/String;","<init>",new String[]{ "[C"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L23);
                code.visitLabel(L21);
                code.visitStmt2R(MOVE,4,3);
                code.visitLabel(L20);
                code.visitJumpStmt(GOTO,-1,-1,L12);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_endsWithIgnoreCase(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/util/StringUtil;","endsWithIgnoreCase",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(12);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"s");
                ddv.visitParameterName(1,"w");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(142,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(168,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(145,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(146,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(148,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(149,L6);
                ddv.visitStartLocal(4,L6,"sl","I",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(151,L7);
                ddv.visitStartLocal(5,L7,"wl","I",null);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(152,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(154,L9);
                DexLabel L10=new DexLabel();
                ddv.visitStartLocal(2,L10,"i","I",null);
                DexLabel L11=new DexLabel();
                ddv.visitEndLocal(2,L11);
                ddv.visitStartLocal(3,L11,"i","I",null);
                DexLabel L12=new DexLabel();
                ddv.visitRestartLocal(2,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(156,L13);
                ddv.visitEndLocal(3,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(157,L14);
                ddv.visitStartLocal(0,L14,"c1","C",null);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(158,L15);
                ddv.visitStartLocal(1,L15,"c2","C",null);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(160,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(161,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(162,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(163,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(164,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(165,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(167,L22);
                ddv.visitRestartLocal(3,L22);
                DexLabel L23=new DexLabel();
                ddv.visitEndLocal(0,L23);
                ddv.visitEndLocal(1,L23);
                ddv.visitEndLocal(3,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(168,L24);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_16,9, Integer.valueOf(127)); // int: 0x0000007f  float:0.000000
                code.visitConstStmt(CONST_4,8, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitConstStmt(CONST_4,7, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitJumpStmt(IF_NEZ,11,-1,L3);
                code.visitStmt2R(MOVE,6,8);
                code.visitLabel(L2);
                code.visitStmt1R(RETURN,6);
                code.visitLabel(L3);
                code.visitJumpStmt(IF_NEZ,10,-1,L5);
                code.visitStmt2R(MOVE,6,7);
                code.visitLabel(L4);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitLabel(L7);
                code.visitJumpStmt(IF_GE,4,5,L9);
                code.visitStmt2R(MOVE,6,7);
                code.visitLabel(L8);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L9);
                code.visitStmt2R(MOVE,2,5);
                code.visitLabel(L10);
                code.visitStmt2R(MOVE,3,2);
                code.visitLabel(L11);
                code.visitStmt3R(SUB_INT,2,3,8);
                code.visitLabel(L12);
                code.visitJumpStmt(IF_LEZ,3,-1,L23);
                code.visitLabel(L13);
                code.visitStmt2R1N(ADD_INT_LIT8,4,4,-1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10,4},new Method("Ljava/lang/String;","charAt",new String[]{ "I"},"C"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitLabel(L14);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11,2},new Method("Ljava/lang/String;","charAt",new String[]{ "I"},"C"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitLabel(L15);
                DexLabel L25=new DexLabel();
                code.visitJumpStmt(IF_EQ,0,1,L25);
                code.visitLabel(L16);
                code.visitJumpStmt(IF_GT,0,9,L18);
                code.visitLabel(L17);
                code.visitFieldStmt(SGET_OBJECT,6,-1,new Field("Lorg/mortbay/util/StringUtil;","lowercases","[C"));
                code.visitStmt3R(AGET_CHAR,0,6,0);
                code.visitLabel(L18);
                code.visitJumpStmt(IF_GT,1,9,L20);
                code.visitLabel(L19);
                code.visitFieldStmt(SGET_OBJECT,6,-1,new Field("Lorg/mortbay/util/StringUtil;","lowercases","[C"));
                code.visitStmt3R(AGET_CHAR,1,6,1);
                code.visitLabel(L20);
                code.visitJumpStmt(IF_EQ,0,1,L25);
                code.visitStmt2R(MOVE,6,7);
                code.visitLabel(L21);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L25);
                code.visitStmt2R(MOVE,3,2);
                code.visitLabel(L22);
                code.visitJumpStmt(GOTO,-1,-1,L11);
                code.visitLabel(L23);
                code.visitStmt2R(MOVE,6,8);
                code.visitLabel(L24);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m007_equals(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/util/StringUtil;","equals",new String[]{ "Ljava/lang/String;","[C","I","I"},"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(8);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"s");
                ddv.visitParameterName(1,"buf");
                ddv.visitParameterName(2,"offset");
                ddv.visitParameterName(3,"length");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(291,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(296,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(293,L3);
                DexLabel L4=new DexLabel();
                ddv.visitStartLocal(0,L4,"i","I",null);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(294,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(295,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(293,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(296,L8);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_EQ,1,7,L3);
                code.visitStmt2R(MOVE,1,3);
                code.visitLabel(L2);
                code.visitStmt1R(RETURN,1);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L4);
                code.visitJumpStmt(IF_GE,0,7,L8);
                code.visitLabel(L5);
                code.visitStmt3R(ADD_INT,1,6,0);
                code.visitStmt3R(AGET_CHAR,1,5,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,0},new Method("Ljava/lang/String;","charAt",new String[]{ "I"},"C"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_EQ,1,2,L7);
                code.visitStmt2R(MOVE,1,3);
                code.visitLabel(L6);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L7);
                code.visitStmt2R1N(ADD_INT_LIT8,0,0,1);
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitLabel(L8);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m008_indexFrom(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/util/StringUtil;","indexFrom",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"s");
                ddv.visitParameterName(1,"chars");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(177,L0);
                DexLabel L1=new DexLabel();
                ddv.visitStartLocal(0,L1,"i","I",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(178,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(180,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(177,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(180,L5);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_GE,0,1,L5);
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,0},new Method("Ljava/lang/String;","charAt",new String[]{ "I"},"C"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,1},new Method("Ljava/lang/String;","indexOf",new String[]{ "I"},"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_LTZ,1,-1,L4);
                code.visitStmt2R(MOVE,1,0);
                code.visitLabel(L3);
                code.visitStmt1R(RETURN,1);
                code.visitLabel(L4);
                code.visitStmt2R1N(ADD_INT_LIT8,0,0,1);
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitLabel(L5);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(-1)); // int: 0xffffffff  float:NaN
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m009_isUTF8(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/util/StringUtil;","isUTF8",new String[]{ "Ljava/lang/String;"},"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"charset");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(341,L1);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_STRING,1,"UTF-8");
                code.visitLabel(L1);
                code.visitConstStmt(CONST_STRING,0,"UTF-8");
                DexLabel L2=new DexLabel();
                code.visitJumpStmt(IF_EQ,2,1,L2);
                code.visitConstStmt(CONST_STRING,0,"UTF-8");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/lang/String;","equalsIgnoreCase",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_NEZ,0,-1,L2);
                code.visitConstStmt(CONST_STRING,0,"UTF8");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,2},new Method("Ljava/lang/String;","equalsIgnoreCase",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                DexLabel L3=new DexLabel();
                code.visitJumpStmt(IF_EQZ,0,-1,L3);
                code.visitLabel(L2);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                DexLabel L4=new DexLabel();
                code.visitLabel(L4);
                code.visitStmt1R(RETURN,0);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m010_nonNull(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/util/StringUtil;","nonNull",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"s");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(283,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(284,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(285,L2);
                code.visitLabel(L0);
                DexLabel L3=new DexLabel();
                code.visitJumpStmt(IF_NEZ,1,-1,L3);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_STRING,0,"");
                code.visitLabel(L2);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L3);
                code.visitStmt2R(MOVE_OBJECT,0,1);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m011_printable(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/util/StringUtil;","printable",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(348,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(349,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(357,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(350,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(351,L4);
                ddv.visitStartLocal(0,L4,"buf","Ljava/lang/StringBuffer;",null);
                DexLabel L5=new DexLabel();
                ddv.visitStartLocal(2,L5,"i","I",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(353,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(354,L7);
                ddv.visitStartLocal(1,L7,"c","C",null);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(355,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(351,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(357,L10);
                ddv.visitEndLocal(1,L10);
                code.visitLabel(L0);
                code.visitJumpStmt(IF_NEZ,4,-1,L3);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L2);
                code.visitStmt1R(RETURN_OBJECT,3);
                code.visitLabel(L3);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/StringBuffer;");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,3},new Method("Ljava/lang/StringBuffer;","<init>",new String[]{ "I"},"V"));
                code.visitLabel(L4);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_GE,2,3,L10);
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,2},new Method("Ljava/lang/String;","charAt",new String[]{ "I"},"C"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1},new Method("Ljava/lang/Character;","isISOControl",new String[]{ "C"},"Z"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_NEZ,3,-1,L9);
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "C"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L9);
                code.visitStmt2R1N(ADD_INT_LIT8,2,2,1);
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/StringBuffer;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m012_replace(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/util/StringUtil;","replace",new String[]{ "Ljava/lang/String;","Ljava/lang/String;","Ljava/lang/String;"},"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(9);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"s");
                ddv.visitParameterName(1,"sub");
                ddv.visitParameterName(2,"with");
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(189,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(190,L5);
                ddv.visitStartLocal(1,L5,"c","I",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(191,L6);
                ddv.visitStartLocal(2,L6,"i","I",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(208,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(194,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(196,L9);
                ddv.visitStartLocal(0,L9,"buf","Ljava/lang/StringBuffer;",null);
                ddv.visitLineNumber(200,L0);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(201,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(202,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(203,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(205,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(206,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(208,L15);
                ddv.visitLineNumber(209,L2);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,5, Integer.valueOf(-1)); // int: 0xffffffff  float:NaN
                code.visitLabel(L4);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,7,1},new Method("Ljava/lang/String;","indexOf",new String[]{ "Ljava/lang/String;","I"},"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitLabel(L6);
                code.visitJumpStmt(IF_NE,2,5,L8);
                code.visitStmt2R(MOVE_OBJECT,3,6);
                code.visitLabel(L7);
                code.visitStmt1R(RETURN_OBJECT,3);
                code.visitLabel(L8);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/StringBuffer;");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitStmt2R(ADD_INT_2ADDR,3,4);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,3},new Method("Ljava/lang/StringBuffer;","<init>",new String[]{ "I"},"V"));
                code.visitLabel(L9);
                code.visitStmt1R(MONITOR_ENTER,0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,1,2},new Method("Ljava/lang/String;","substring",new String[]{ "I","I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,3},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,8},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L11);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitStmt3R(ADD_INT,1,2,3);
                code.visitLabel(L12);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,7,1},new Method("Ljava/lang/String;","indexOf",new String[]{ "Ljava/lang/String;","I"},"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_NE,2,5,L0);
                code.visitLabel(L13);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_GE,1,3,L15);
                code.visitLabel(L14);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,1,3},new Method("Ljava/lang/String;","substring",new String[]{ "I","I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,3},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L15);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/StringBuffer;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitStmt1R(MONITOR_EXIT,0);
                code.visitJumpStmt(GOTO,-1,-1,L7);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,3);
                code.visitStmt1R(MONITOR_EXIT,0);
                code.visitLabel(L1);
                code.visitStmt1R(THROW,3);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m013_startsWithIgnoreCase(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/util/StringUtil;","startsWithIgnoreCase",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(10);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"s");
                ddv.visitParameterName(1,"w");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(116,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(136,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(119,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(120,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(122,L5);
                DexLabel L6=new DexLabel();
                ddv.visitStartLocal(2,L6,"i","I",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(124,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(125,L8);
                ddv.visitStartLocal(0,L8,"c1","C",null);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(126,L9);
                ddv.visitStartLocal(1,L9,"c2","C",null);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(128,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(129,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(130,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(131,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(132,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(133,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(122,L16);
                DexLabel L17=new DexLabel();
                ddv.visitEndLocal(0,L17);
                ddv.visitEndLocal(1,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(136,L18);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_16,7, Integer.valueOf(127)); // int: 0x0000007f  float:0.000000
                code.visitConstStmt(CONST_4,6, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitConstStmt(CONST_4,5, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitJumpStmt(IF_NEZ,9,-1,L3);
                code.visitStmt2R(MOVE,3,6);
                code.visitLabel(L2);
                code.visitStmt1R(RETURN,3);
                code.visitLabel(L3);
                DexLabel L19=new DexLabel();
                code.visitJumpStmt(IF_EQZ,8,-1,L19);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitJumpStmt(IF_GE,3,4,L5);
                code.visitLabel(L19);
                code.visitStmt2R(MOVE,3,5);
                code.visitLabel(L4);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L5);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_GE,2,3,L17);
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,2},new Method("Ljava/lang/String;","charAt",new String[]{ "I"},"C"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9,2},new Method("Ljava/lang/String;","charAt",new String[]{ "I"},"C"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitLabel(L9);
                code.visitJumpStmt(IF_EQ,0,1,L16);
                code.visitLabel(L10);
                code.visitJumpStmt(IF_GT,0,7,L12);
                code.visitLabel(L11);
                code.visitFieldStmt(SGET_OBJECT,3,-1,new Field("Lorg/mortbay/util/StringUtil;","lowercases","[C"));
                code.visitStmt3R(AGET_CHAR,0,3,0);
                code.visitLabel(L12);
                code.visitJumpStmt(IF_GT,1,7,L14);
                code.visitLabel(L13);
                code.visitFieldStmt(SGET_OBJECT,3,-1,new Field("Lorg/mortbay/util/StringUtil;","lowercases","[C"));
                code.visitStmt3R(AGET_CHAR,1,3,1);
                code.visitLabel(L14);
                code.visitJumpStmt(IF_EQ,0,1,L16);
                code.visitStmt2R(MOVE,3,5);
                code.visitLabel(L15);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L16);
                code.visitStmt2R1N(ADD_INT_LIT8,2,2,1);
                code.visitJumpStmt(GOTO,-1,-1,L6);
                code.visitLabel(L17);
                code.visitStmt2R(MOVE,3,6);
                code.visitLabel(L18);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m014_toString(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/util/StringUtil;","toString",new String[]{ "[B","I","I","Ljava/lang/String;"},"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/io/UnsupportedEncodingException;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"b");
                ddv.visitParameterName(1,"offset");
                ddv.visitParameterName(2,"length");
                ddv.visitParameterName(3,"charset");
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(323,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(324,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(333,L5);
                ddv.visitLineNumber(328,L0);
                ddv.visitLineNumber(330,L2);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(332,L6);
                ddv.visitStartLocal(0,L6,"e","Ljava/io/UnsupportedEncodingException;",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(333,L7);
                code.visitLabel(L3);
                code.visitJumpStmt(IF_EQZ,5,-1,L4);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 5},new Method("Lorg/mortbay/util/StringUtil;","isUTF8",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_EQZ,1,-1,L0);
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2,3,4},new Method("Lorg/mortbay/util/StringUtil;","toUTF8String",new String[]{ "[B","I","I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L5);
                code.visitStmt1R(RETURN_OBJECT,1);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/lang/String;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,2,3,4,5},new Method("Ljava/lang/String;","<init>",new String[]{ "[B","I","I","Ljava/lang/String;"},"V"));
                code.visitLabel(L1);
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitStmt2R(MOVE_OBJECT,0,1);
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/io/UnsupportedEncodingException;","printStackTrace",new String[]{ },"V"));
                code.visitLabel(L7);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m015_toUTF8String(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/util/StringUtil;","toUTF8String",new String[]{ "[B","I","I"},"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/io/UnsupportedEncodingException;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"b");
                ddv.visitParameterName(1,"offset");
                ddv.visitParameterName(2,"length");
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(304,L3);
                ddv.visitLineNumber(306,L0);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(307,L4);
                ddv.visitStartLocal(0,L4,"buffer","Lorg/mortbay/util/Utf8StringBuffer;",null);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(308,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(316,L6);
                ddv.visitEndLocal(0,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(311,L7);
                ddv.visitLineNumber(313,L2);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(315,L8);
                ddv.visitStartLocal(1,L8,"e","Ljava/io/UnsupportedEncodingException;",null);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(316,L9);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_16,2, Integer.valueOf(32)); // int: 0x00000020  float:0.000000
                code.visitJumpStmt(IF_GE,6,2,L7);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/util/Utf8StringBuffer;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,6},new Method("Lorg/mortbay/util/Utf8StringBuffer;","<init>",new String[]{ "I"},"V"));
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,4,5,6},new Method("Lorg/mortbay/util/Utf8StringBuffer;","append",new String[]{ "[B","I","I"},"V"));
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/util/Utf8StringBuffer;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L6);
                code.visitStmt1R(RETURN_OBJECT,2);
                code.visitLabel(L7);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Ljava/lang/String;");
                code.visitConstStmt(CONST_STRING,3,"UTF-8");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2,4,5,6,3},new Method("Ljava/lang/String;","<init>",new String[]{ "[B","I","I","Ljava/lang/String;"},"V"));
                code.visitLabel(L1);
                code.visitJumpStmt(GOTO,-1,-1,L6);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,2);
                code.visitStmt2R(MOVE_OBJECT,1,2);
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/io/UnsupportedEncodingException;","printStackTrace",new String[]{ },"V"));
                code.visitLabel(L9);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L6);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m016_unquote(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/util/StringUtil;","unquote",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"s");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(218,L0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1},new Method("Lorg/mortbay/util/QuotedStringTokenizer;","unquote",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
