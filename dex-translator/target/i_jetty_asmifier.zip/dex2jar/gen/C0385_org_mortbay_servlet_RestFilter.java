package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0385_org_mortbay_servlet_RestFilter {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/servlet/RestFilter;","Ljava/lang/Object;",new String[]{ "Ljavax/servlet/Filter;"});
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("RestFilter.java");
        f000_HTTP_METHOD_DELETE(cv);
        f001_HTTP_METHOD_GET(cv);
        f002_HTTP_METHOD_PUT(cv);
        f003__maxPutSize(cv);
        f004_filterConfig(cv);
        m000__init_(cv);
        m001_locateFile(cv);
        m002_destroy(cv);
        m003_doDelete(cv);
        m004_doFilter(cv);
        m005_doPut(cv);
        m006_init(cv);
    }
    public static void f000_HTTP_METHOD_DELETE(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/servlet/RestFilter;","HTTP_METHOD_DELETE","Ljava/lang/String;"), "DELETE");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001_HTTP_METHOD_GET(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/servlet/RestFilter;","HTTP_METHOD_GET","Ljava/lang/String;"), "GET");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002_HTTP_METHOD_PUT(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/servlet/RestFilter;","HTTP_METHOD_PUT","Ljava/lang/String;"), "PUT");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003__maxPutSize(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/servlet/RestFilter;","_maxPutSize","J"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f004_filterConfig(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/servlet/RestFilter;","filterConfig","Ljavax/servlet/FilterConfig;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/servlet/RestFilter;","<init>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(52,L0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/Object;","<init>",new String[]{ },"V"));
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001_locateFile(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PRIVATE, new Method("Lorg/mortbay/servlet/RestFilter;","locateFile",new String[]{ "Ljavax/servlet/http/HttpServletRequest;"},"Ljava/io/File;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"request");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(80,L0);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/io/File;");
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/servlet/RestFilter;","filterConfig","Ljavax/servlet/FilterConfig;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Ljavax/servlet/FilterConfig;","getServletContext",new String[]{ },"Ljavax/servlet/ServletContext;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 5},new Method("Ljavax/servlet/http/HttpServletRequest;","getServletPath",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 5},new Method("Ljavax/servlet/http/HttpServletRequest;","getPathInfo",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2,3},new Method("Lorg/mortbay/util/URIUtil;","addPaths",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1,2},new Method("Ljavax/servlet/ServletContext;","getRealPath",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Ljava/io/File;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_destroy(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/servlet/RestFilter;","destroy",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(192,L0);
                code.visitLabel(L0);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_doDelete(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/servlet/RestFilter;","doDelete",new String[]{ "Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljavax/servlet/ServletException;"));
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"request");
                ddv.visitParameterName(1,"response");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(169,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(171,L1);
                ddv.visitStartLocal(0,L1,"file","Ljava/io/File;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(173,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(187,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(177,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(179,L5);
                ddv.visitStartLocal(1,L5,"success","Z",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(181,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(185,L7);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3,4},new Method("Lorg/mortbay/servlet/RestFilter;","locateFile",new String[]{ "Ljavax/servlet/http/HttpServletRequest;"},"Ljava/io/File;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/io/File;","exists",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_NEZ,2,-1,L4);
                code.visitLabel(L2);
                code.visitConstStmt(CONST_16,2, Integer.valueOf(404)); // int: 0x00000194  float:0.000000
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 5,2},new Method("Ljavax/servlet/http/HttpServletResponse;","sendError",new String[]{ "I"},"V"));
                code.visitLabel(L3);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/util/IO;","delete",new String[]{ "Ljava/io/File;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitLabel(L5);
                code.visitJumpStmt(IF_EQZ,1,-1,L7);
                code.visitLabel(L6);
                code.visitConstStmt(CONST_16,2, Integer.valueOf(204)); // int: 0x000000cc  float:0.000000
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 5,2},new Method("Ljavax/servlet/http/HttpServletResponse;","setStatus",new String[]{ "I"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitLabel(L7);
                code.visitConstStmt(CONST_16,2, Integer.valueOf(500)); // int: 0x000001f4  float:0.000000
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 5,2},new Method("Ljavax/servlet/http/HttpServletResponse;","sendError",new String[]{ "I"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_doFilter(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/servlet/RestFilter;","doFilter",new String[]{ "Ljavax/servlet/ServletRequest;","Ljavax/servlet/ServletResponse;","Ljavax/servlet/FilterChain;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visit(null, new DexType("Ljavax/servlet/ServletException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(9);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"request");
                ddv.visitParameterName(1,"response");
                ddv.visitParameterName(2,"chain");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(89,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(91,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(114,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(95,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(96,L4);
                ddv.visitStartLocal(1,L4,"httpRequest","Ljavax/servlet/http/HttpServletRequest;",null);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(98,L5);
                ddv.visitStartLocal(2,L5,"httpResponse","Ljavax/servlet/http/HttpServletResponse;",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(100,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(102,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(104,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(106,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(108,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(112,L11);
                code.visitLabel(L0);
                code.visitTypeStmt(INSTANCE_OF,3,6,"Ljavax/servlet/http/HttpServletRequest;");
                code.visitJumpStmt(IF_EQZ,3,-1,L1);
                code.visitTypeStmt(INSTANCE_OF,3,7,"Ljavax/servlet/http/HttpServletResponse;");
                code.visitJumpStmt(IF_NEZ,3,-1,L3);
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 8,6,7},new Method("Ljavax/servlet/FilterChain;","doFilter",new String[]{ "Ljavax/servlet/ServletRequest;","Ljavax/servlet/ServletResponse;"},"V"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L3);
                code.visitStmt2R(MOVE_OBJECT,0,6);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Ljavax/servlet/http/HttpServletRequest;");
                code.visitStmt2R(MOVE_OBJECT,1,0);
                code.visitLabel(L4);
                code.visitStmt2R(MOVE_OBJECT,0,7);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Ljavax/servlet/http/HttpServletResponse;");
                code.visitStmt2R(MOVE_OBJECT,2,0);
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Ljavax/servlet/http/HttpServletRequest;","getMethod",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitConstStmt(CONST_STRING,4,"GET");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_EQZ,3,-1,L7);
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 8,1,2},new Method("Ljavax/servlet/FilterChain;","doFilter",new String[]{ "Ljavax/servlet/ServletRequest;","Ljavax/servlet/ServletResponse;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Ljavax/servlet/http/HttpServletRequest;","getMethod",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitConstStmt(CONST_STRING,4,"PUT");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_EQZ,3,-1,L9);
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,1,2},new Method("Lorg/mortbay/servlet/RestFilter;","doPut",new String[]{ "Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Ljavax/servlet/http/HttpServletRequest;","getMethod",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitConstStmt(CONST_STRING,4,"DELETE");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_EQZ,3,-1,L11);
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,1,2},new Method("Lorg/mortbay/servlet/RestFilter;","doDelete",new String[]{ "Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L11);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 8,1,2},new Method("Ljavax/servlet/FilterChain;","doFilter",new String[]{ "Ljavax/servlet/ServletRequest;","Ljavax/servlet/ServletResponse;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_doPut(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/servlet/RestFilter;","doPut",new String[]{ "Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljavax/servlet/ServletException;"));
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(11);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L2},new String[]{ null});
                DexLabel L5=new DexLabel();
                DexLabel L6=new DexLabel();
                code.visitTryCatch(L5,L6,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"request");
                ddv.visitParameterName(1,"response");
                DexLabel L7=new DexLabel();
                ddv.visitPrologue(L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(124,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(126,L9);
                ddv.visitStartLocal(0,L9,"file","Ljava/io/File;",null);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(128,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(129,L11);
                ddv.visitStartLocal(3,L11,"success","Z",null);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(131,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(158,L13);
                ddv.visitEndLocal(3,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(136,L14);
                ddv.visitLineNumber(139,L0);
                ddv.visitStartLocal(2,L0,"out","Ljava/io/FileOutputStream;",null);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(141,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(142,L16);
                ddv.visitStartLocal(1,L16,"length","I",null);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(144,L17);
                ddv.visitLineNumber(154,L1);
                ddv.visitLineNumber(147,L3);
                ddv.visitLineNumber(154,L4);
                ddv.visitEndLocal(1,L4);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(157,L18);
                ddv.visitLineNumber(150,L5);
                ddv.visitLineNumber(154,L2);
                code.visitLabel(L7);
                code.visitConstStmt(CONST_16,5, Integer.valueOf(403)); // int: 0x00000193  float:0.000000
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 8,9},new Method("Lorg/mortbay/servlet/RestFilter;","locateFile",new String[]{ "Ljavax/servlet/http/HttpServletRequest;"},"Ljava/io/File;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/io/File;","exists",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitJumpStmt(IF_EQZ,4,-1,L14);
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/io/File;","delete",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitLabel(L11);
                code.visitJumpStmt(IF_NEZ,3,-1,L14);
                code.visitLabel(L12);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 10,5},new Method("Ljavax/servlet/http/HttpServletResponse;","sendError",new String[]{ "I"},"V"));
                code.visitLabel(L13);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L14);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Ljava/io/FileOutputStream;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2,0},new Method("Ljava/io/FileOutputStream;","<init>",new String[]{ "Ljava/io/File;"},"V"));
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_WIDE,4,8,new Field("Lorg/mortbay/servlet/RestFilter;","_maxPutSize","J"));
                code.visitConstStmt(CONST_WIDE_16,6,Long.valueOf(0L)); // long: 0x0000000000000000  double:0.000000
                code.visitStmt3R(CMP_LONG,4,4,6);
                code.visitJumpStmt(IF_LEZ,4,-1,L5);
                code.visitLabel(L15);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 9},new Method("Ljavax/servlet/http/HttpServletRequest;","getContentLength",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitLabel(L16);
                code.visitStmt2R(INT_TO_LONG,4,1);
                code.visitFieldStmt(IGET_WIDE,6,8,new Field("Lorg/mortbay/servlet/RestFilter;","_maxPutSize","J"));
                code.visitStmt3R(CMP_LONG,4,4,6);
                code.visitJumpStmt(IF_LEZ,4,-1,L3);
                code.visitLabel(L17);
                code.visitConstStmt(CONST_16,4, Integer.valueOf(403)); // int: 0x00000193  float:0.000000
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 10,4},new Method("Ljavax/servlet/http/HttpServletResponse;","sendError",new String[]{ "I"},"V"));
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/io/FileOutputStream;","close",new String[]{ },"V"));
                code.visitJumpStmt(GOTO,-1,-1,L13);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 9},new Method("Ljavax/servlet/http/HttpServletRequest;","getInputStream",new String[]{ },"Ljavax/servlet/ServletInputStream;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitFieldStmt(IGET_WIDE,5,8,new Field("Lorg/mortbay/servlet/RestFilter;","_maxPutSize","J"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 4,2,5,6},new Method("Lorg/mortbay/util/IO;","copy",new String[]{ "Ljava/io/InputStream;","Ljava/io/OutputStream;","J"},"V"));
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/io/FileOutputStream;","close",new String[]{ },"V"));
                code.visitLabel(L18);
                code.visitConstStmt(CONST_16,4, Integer.valueOf(204)); // int: 0x000000cc  float:0.000000
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 10,4},new Method("Ljavax/servlet/http/HttpServletResponse;","setStatus",new String[]{ "I"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L13);
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 9},new Method("Ljavax/servlet/http/HttpServletRequest;","getInputStream",new String[]{ },"Ljavax/servlet/ServletInputStream;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 4,2},new Method("Lorg/mortbay/util/IO;","copy",new String[]{ "Ljava/io/InputStream;","Ljava/io/OutputStream;"},"V"));
                code.visitLabel(L6);
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/io/FileOutputStream;","close",new String[]{ },"V"));
                code.visitStmt1R(THROW,4);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_init(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/servlet/RestFilter;","init",new String[]{ "Ljavax/servlet/FilterConfig;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljavax/servlet/UnavailableException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"filterConfig");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(67,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(68,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(69,L2);
                ddv.visitStartLocal(0,L2,"tmp","Ljava/lang/String;",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(70,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(71,L4);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,4,3,new Field("Lorg/mortbay/servlet/RestFilter;","filterConfig","Ljavax/servlet/FilterConfig;"));
                code.visitLabel(L1);
                code.visitConstStmt(CONST_STRING,1,"maxPutSize");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 4,1},new Method("Ljavax/servlet/FilterConfig;","getInitParameter",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L2);
                code.visitJumpStmt(IF_EQZ,0,-1,L4);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Ljava/lang/Long;","parseLong",new String[]{ "Ljava/lang/String;"},"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,1);
                code.visitFieldStmt(IPUT_WIDE,1,3,new Field("Lorg/mortbay/servlet/RestFilter;","_maxPutSize","J"));
                code.visitLabel(L4);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
