package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0209_org_mortbay_jetty_client_HttpConnection_1 {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(0,"Lorg/mortbay/jetty/client/HttpConnection$1;","Lorg/mortbay/thread/Timeout$Task;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("HttpConnection.java");
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/EnclosingClass;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("value", new DexType("Lorg/mortbay/jetty/client/HttpConnection;"));
                av00.visitEnd();
            }
        }
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/InnerClass;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("accessFlags",  Integer.valueOf(0));
                av00.visit("name", null);
                av00.visitEnd();
            }
        }
        f000_this$0(cv);
        m000__init_(cv);
        m001_expired(cv);
    }
    public static void f000_this$0(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_FINAL|ACC_SYNTHETIC, new Field("Lorg/mortbay/jetty/client/HttpConnection$1;","this$0","Lorg/mortbay/jetty/client/HttpConnection;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/client/HttpConnection$1;","<init>",new String[]{ "Lorg/mortbay/jetty/client/HttpConnection;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(74,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/client/HttpConnection$1;","this$0","Lorg/mortbay/jetty/client/HttpConnection;"));
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Lorg/mortbay/thread/Timeout$Task;","<init>",new String[]{ },"V"));
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001_expired(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/client/HttpConnection$1;","expired",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(9);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                DexLabel L3=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2,L3},new String[]{ "Ljava/lang/Exception;",null});
                DexLabel L4=new DexLabel();
                DexLabel L5=new DexLabel();
                code.visitTryCatch(L1,L4,new DexLabel[]{L5},new String[]{ null});
                DexLabel L6=new DexLabel();
                DexLabel L7=new DexLabel();
                code.visitTryCatch(L4,L6,new DexLabel[]{L7},new String[]{ "Ljava/io/IOException;"});
                DexLabel L8=new DexLabel();
                DexLabel L9=new DexLabel();
                code.visitTryCatch(L8,L9,new DexLabel[]{L5},new String[]{ null});
                code.visitTryCatch(L9,L2,new DexLabel[]{L2,L3},new String[]{ "Ljava/lang/Exception;",null});
                DexLabel L10=new DexLabel();
                DexLabel L11=new DexLabel();
                code.visitTryCatch(L10,L11,new DexLabel[]{L3},new String[]{ null});
                DexLabel L12=new DexLabel();
                DexLabel L13=new DexLabel();
                code.visitTryCatch(L11,L12,new DexLabel[]{L13},new String[]{ "Ljava/io/IOException;"});
                DexLabel L14=new DexLabel();
                DexLabel L15=new DexLabel();
                DexLabel L16=new DexLabel();
                code.visitTryCatch(L14,L15,new DexLabel[]{L16},new String[]{ "Ljava/io/IOException;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L17=new DexLabel();
                ddv.visitPrologue(L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(76,L18);
                ddv.visitLineNumber(79,L0);
                ddv.visitStartLocal(1,L0,"ex","Lorg/mortbay/jetty/client/HttpExchange;",null);
                ddv.visitLineNumber(81,L1);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(82,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(83,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(84,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(85,L22);
                ddv.visitLineNumber(95,L4);
                ddv.visitLineNumber(102,L6);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(104,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(107,L24);
                ddv.visitLineNumber(85,L5);
                ddv.visitLineNumber(87,L2);
                ddv.visitLineNumber(89,L10);
                ddv.visitStartLocal(0,L10,"e","Ljava/lang/Exception;",null);
                ddv.visitLineNumber(95,L11);
                ddv.visitLineNumber(102,L12);
                ddv.visitEndLocal(0,L12);
                ddv.visitLineNumber(97,L16);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(99,L25);
                ddv.visitStartLocal(0,L25,"e","Ljava/io/IOException;",null);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(102,L26);
                ddv.visitEndLocal(0,L26);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(104,L27);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(93,L28);
                ddv.visitLineNumber(95,L14);
                ddv.visitLineNumber(97,L13);
                ddv.visitStartLocal(0,L13,"e","Ljava/lang/Exception;",null);
                DexLabel L29=new DexLabel();
                ddv.visitLineNumber(99,L29);
                ddv.visitStartLocal(0,L29,"e","Ljava/io/IOException;",null);
                ddv.visitLineNumber(97,L7);
                ddv.visitEndLocal(0,L7);
                DexLabel L30=new DexLabel();
                ddv.visitLineNumber(99,L30);
                ddv.visitRestartLocal(0,L30);
                code.visitLabel(L17);
                code.visitConstStmt(CONST_16,7, Integer.valueOf(8)); // int: 0x00000008  float:0.000000
                code.visitConstStmt(CONST_4,6, Integer.valueOf(7)); // int: 0x00000007  float:0.000000
                code.visitLabel(L18);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,2,8,new Field("Lorg/mortbay/jetty/client/HttpConnection$1;","this$0","Lorg/mortbay/jetty/client/HttpConnection;"));
                code.visitStmt1R(MONITOR_ENTER,2);
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,3,8,new Field("Lorg/mortbay/jetty/client/HttpConnection$1;","this$0","Lorg/mortbay/jetty/client/HttpConnection;"));
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_exchange","Lorg/mortbay/jetty/client/HttpExchange;"));
                code.visitLabel(L19);
                code.visitFieldStmt(IGET_OBJECT,3,8,new Field("Lorg/mortbay/jetty/client/HttpConnection$1;","this$0","Lorg/mortbay/jetty/client/HttpConnection;"));
                code.visitConstStmt(CONST_4,4, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_OBJECT,4,3,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_exchange","Lorg/mortbay/jetty/client/HttpExchange;"));
                code.visitLabel(L20);
                code.visitJumpStmt(IF_EQZ,1,-1,L22);
                code.visitLabel(L21);
                code.visitFieldStmt(IGET_OBJECT,3,8,new Field("Lorg/mortbay/jetty/client/HttpConnection$1;","this$0","Lorg/mortbay/jetty/client/HttpConnection;"));
                code.visitFieldStmt(IGET_OBJECT,3,3,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_destination","Lorg/mortbay/jetty/client/HttpDestination;"));
                code.visitFieldStmt(IGET_OBJECT,4,8,new Field("Lorg/mortbay/jetty/client/HttpConnection$1;","this$0","Lorg/mortbay/jetty/client/HttpConnection;"));
                code.visitConstStmt(CONST_4,5, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4,5},new Method("Lorg/mortbay/jetty/client/HttpDestination;","returnConnection",new String[]{ "Lorg/mortbay/jetty/client/HttpConnection;","Z"},"V"));
                code.visitLabel(L22);
                code.visitStmt1R(MONITOR_EXIT,2);
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,2,8,new Field("Lorg/mortbay/jetty/client/HttpConnection$1;","this$0","Lorg/mortbay/jetty/client/HttpConnection;"));
                code.visitFieldStmt(IGET_OBJECT,2,2,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_endp","Lorg/mortbay/io/EndPoint;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2},new Method("Lorg/mortbay/io/EndPoint;","close",new String[]{ },"V"));
                code.visitLabel(L6);
                code.visitJumpStmt(IF_EQZ,1,-1,L24);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/jetty/client/HttpExchange;","getStatus",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_GE,2,6,L24);
                code.visitLabel(L23);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,7},new Method("Lorg/mortbay/jetty/client/HttpExchange;","setStatus",new String[]{ "I"},"V"));
                code.visitLabel(L24);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L5);
                code.visitStmt1R(MOVE_EXCEPTION,3);
                code.visitLabel(L8);
                code.visitStmt1R(MONITOR_EXIT,2);
                code.visitLabel(L9);
                code.visitStmt1R(THROW,3);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,2);
                code.visitStmt2R(MOVE_OBJECT,0,2);
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitLabel(L11);
                code.visitFieldStmt(IGET_OBJECT,2,8,new Field("Lorg/mortbay/jetty/client/HttpConnection$1;","this$0","Lorg/mortbay/jetty/client/HttpConnection;"));
                code.visitFieldStmt(IGET_OBJECT,2,2,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_endp","Lorg/mortbay/io/EndPoint;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2},new Method("Lorg/mortbay/io/EndPoint;","close",new String[]{ },"V"));
                code.visitLabel(L12);
                code.visitJumpStmt(IF_EQZ,1,-1,L24);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/jetty/client/HttpExchange;","getStatus",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_GE,2,6,L24);
                code.visitJumpStmt(GOTO,-1,-1,L23);
                code.visitLabel(L16);
                code.visitStmt1R(MOVE_EXCEPTION,3);
                code.visitStmt2R(MOVE_OBJECT,0,3);
                code.visitLabel(L25);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/log/Log;","ignore",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitLabel(L26);
                code.visitJumpStmt(IF_EQZ,1,-1,L28);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/jetty/client/HttpExchange;","getStatus",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_GE,3,6,L28);
                code.visitLabel(L27);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,7},new Method("Lorg/mortbay/jetty/client/HttpExchange;","setStatus",new String[]{ "I"},"V"));
                code.visitLabel(L28);
                code.visitStmt1R(THROW,2);
                code.visitLabel(L3);
                code.visitStmt1R(MOVE_EXCEPTION,2);
                code.visitLabel(L14);
                code.visitFieldStmt(IGET_OBJECT,3,8,new Field("Lorg/mortbay/jetty/client/HttpConnection$1;","this$0","Lorg/mortbay/jetty/client/HttpConnection;"));
                code.visitFieldStmt(IGET_OBJECT,3,3,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_endp","Lorg/mortbay/io/EndPoint;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3},new Method("Lorg/mortbay/io/EndPoint;","close",new String[]{ },"V"));
                code.visitLabel(L15);
                code.visitJumpStmt(GOTO,-1,-1,L26);
                code.visitLabel(L13);
                code.visitStmt1R(MOVE_EXCEPTION,2);
                code.visitStmt2R(MOVE_OBJECT,0,2);
                code.visitLabel(L29);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/log/Log;","ignore",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L12);
                code.visitLabel(L7);
                code.visitStmt1R(MOVE_EXCEPTION,2);
                code.visitStmt2R(MOVE_OBJECT,0,2);
                code.visitLabel(L30);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/log/Log;","ignore",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L6);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
