package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0087_org_mortbay_ijetty_console_DatabaseCollection {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC|ACC_ABSTRACT,"Lorg/mortbay/ijetty/console/DatabaseCollection;","Ljava/lang/Object;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("DatabaseCollection.java");
        f000_cursor(cv);
        m000__init_(cv);
        m001_close(cv);
        m002_cursorToValues(cv);
        m003_hasNext(cv);
        m004_next(cv);
    }
    public static void f000_cursor(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/ijetty/console/DatabaseCollection;","cursor","Landroid/database/Cursor;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/ijetty/console/DatabaseCollection;","<init>",new String[]{ "Landroid/database/Cursor;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"cursor");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(29,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(30,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(31,L2);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/Object;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/ijetty/console/DatabaseCollection;","cursor","Landroid/database/Cursor;"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001_close(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/ijetty/console/DatabaseCollection;","close",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(52,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(53,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/ijetty/console/DatabaseCollection;","cursor","Landroid/database/Cursor;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Landroid/database/Cursor;","close",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_cursorToValues(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/ijetty/console/DatabaseCollection;","cursorToValues",new String[]{ "Landroid/database/Cursor;"},"Landroid/content/ContentValues;"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m003_hasNext(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/ijetty/console/DatabaseCollection;","hasNext",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(47,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/ijetty/console/DatabaseCollection;","cursor","Landroid/database/Cursor;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Landroid/database/Cursor;","isLast",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                DexLabel L1=new DexLabel();
                code.visitJumpStmt(IF_NEZ,0,-1,L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                DexLabel L2=new DexLabel();
                code.visitLabel(L2);
                code.visitStmt1R(RETURN,0);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_next(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/ijetty/console/DatabaseCollection;","next",new String[]{ },"Landroid/content/ContentValues;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(35,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(37,L1);
                ddv.visitStartLocal(0,L1,"values","Landroid/content/ContentValues;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(39,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(42,L3);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/ijetty/console/DatabaseCollection;","cursor","Landroid/database/Cursor;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Landroid/database/Cursor;","moveToNext",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,1);
                DexLabel L4=new DexLabel();
                code.visitJumpStmt(IF_EQZ,1,-1,L4);
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/ijetty/console/DatabaseCollection;","cursor","Landroid/database/Cursor;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,1},new Method("Lorg/mortbay/ijetty/console/DatabaseCollection;","cursorToValues",new String[]{ "Landroid/database/Cursor;"},"Landroid/content/ContentValues;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L3);
                code.visitStmt1R(RETURN_OBJECT,1);
                code.visitLabel(L4);
                code.visitStmt2R(MOVE_OBJECT,1,0);
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
