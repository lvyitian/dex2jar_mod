package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0274_org_mortbay_jetty_security_Credential {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC|ACC_ABSTRACT,"Lorg/mortbay/jetty/security/Credential;","Ljava/lang/Object;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("Credential.java");
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/MemberClasses;", Visibility.SYSTEM);
            if(av00 != null) {
                {
                    DexAnnotationVisitor av01 = av00.visitArray("value");
                    if(av01 != null) {
                        av01.visit(null, new DexType("Lorg/mortbay/jetty/security/Credential$MD5;"));
                        av01.visit(null, new DexType("Lorg/mortbay/jetty/security/Credential$Crypt;"));
                        av01.visitEnd();
                    }
                }
                av00.visitEnd();
            }
        }
        m000__init_(cv);
        m001_getCredential(cv);
        m002_check(cv);
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/security/Credential;","<init>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(38,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(103,L1);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/Object;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001_getCredential(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/jetty/security/Credential;","getCredential",new String[]{ "Ljava/lang/String;"},"Lorg/mortbay/jetty/security/Credential;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"credential");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(60,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(61,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(65,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(62,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(63,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(65,L5);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_STRING,0,"CRYPT:");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,0},new Method("Ljava/lang/String;","startsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L3);
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/jetty/security/Credential$Crypt;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/security/Credential$Crypt;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L2);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_STRING,0,"MD5:");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,0},new Method("Ljava/lang/String;","startsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L5);
                code.visitLabel(L4);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/jetty/security/Credential$MD5;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/security/Credential$MD5;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L5);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/jetty/security/Password;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/security/Password;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_check(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/jetty/security/Credential;","check",new String[]{ "Ljava/lang/Object;"},"Z"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
}
