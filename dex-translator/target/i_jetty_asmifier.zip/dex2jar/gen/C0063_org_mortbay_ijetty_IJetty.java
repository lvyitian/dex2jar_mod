package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0063_org_mortbay_ijetty_IJetty {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/ijetty/IJetty;","Landroid/app/Activity;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("IJetty.java");
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/MemberClasses;", Visibility.SYSTEM);
            if(av00 != null) {
                {
                    DexAnnotationVisitor av01 = av00.visitArray("value");
                    if(av01 != null) {
                        av01.visit(null, new DexType("Lorg/mortbay/ijetty/IJetty$NetworkListAdapter;"));
                        av01.visit(null, new DexType("Lorg/mortbay/ijetty/IJetty$IPList;"));
                        av01.visitEnd();
                    }
                }
                av00.visitEnd();
            }
        }
        f000___CONSOLE_PWD(cv);
        f001___CONSOLE_PWD_DEFAULT(cv);
        f002___CONTEXTS_DIR(cv);
        f003___ETC_DIR(cv);
        f004___JETTY_DIR(cv);
        f005___NIO(cv);
        f006___NIO_DEFAULT(cv);
        f007___PORT(cv);
        f008___PORT_DEFAULT(cv);
        f009___TMP_DIR(cv);
        f010___WEBAPP_DIR(cv);
        f011__ipList(cv);
        f012_pi(cv);
        m000__init_(cv);
        m001_getStoredJettyVersion(cv);
        m002_onCreate(cv);
        m003_onResume(cv);
        m004_setStoredJettyVersion(cv);
        m005_setupJetty(cv);
    }
    public static void f000___CONSOLE_PWD(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/ijetty/IJetty;","__CONSOLE_PWD","Ljava/lang/String;"), "org.mortbay.ijetty.console");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001___CONSOLE_PWD_DEFAULT(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/ijetty/IJetty;","__CONSOLE_PWD_DEFAULT","Ljava/lang/String;"), "admin");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002___CONTEXTS_DIR(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/ijetty/IJetty;","__CONTEXTS_DIR","Ljava/lang/String;"), "contexts");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003___ETC_DIR(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/ijetty/IJetty;","__ETC_DIR","Ljava/lang/String;"), "etc");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f004___JETTY_DIR(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/ijetty/IJetty;","__JETTY_DIR","Ljava/lang/String;"), "/sdcard/jetty");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f005___NIO(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/ijetty/IJetty;","__NIO","Ljava/lang/String;"), "org.mortbay.ijetty.nio");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f006___NIO_DEFAULT(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/ijetty/IJetty;","__NIO_DEFAULT","Z"), Boolean.valueOf(true));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f007___PORT(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/ijetty/IJetty;","__PORT","Ljava/lang/String;"), "org.mortbay.ijetty.port");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f008___PORT_DEFAULT(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/ijetty/IJetty;","__PORT_DEFAULT","Ljava/lang/String;"), "8080");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f009___TMP_DIR(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/ijetty/IJetty;","__TMP_DIR","Ljava/lang/String;"), "tmp");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f010___WEBAPP_DIR(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/ijetty/IJetty;","__WEBAPP_DIR","Ljava/lang/String;"), "webapps");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f011__ipList(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/ijetty/IJetty;","_ipList","Lorg/mortbay/ijetty/IJetty$IPList;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f012_pi(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/ijetty/IJetty;","pi","Landroid/content/pm/PackageInfo;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/ijetty/IJetty;","<init>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(60,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(77,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(121,L2);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Landroid/app/Activity;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/ijetty/IJetty;","pi","Landroid/content/pm/PackageInfo;"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001_getStoredJettyVersion(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/ijetty/IJetty;","getStoredJettyVersion",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(12);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                DexLabel L3=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2,L3},new String[]{ "Ljava/lang/Exception;",null});
                DexLabel L4=new DexLabel();
                DexLabel L5=new DexLabel();
                DexLabel L6=new DexLabel();
                code.visitTryCatch(L1,L4,new DexLabel[]{L5,L6},new String[]{ "Ljava/lang/Exception;",null});
                DexLabel L7=new DexLabel();
                DexLabel L8=new DexLabel();
                DexLabel L9=new DexLabel();
                code.visitTryCatch(L7,L8,new DexLabel[]{L9},new String[]{ "Ljava/lang/Exception;"});
                DexLabel L10=new DexLabel();
                DexLabel L11=new DexLabel();
                code.visitTryCatch(L10,L11,new DexLabel[]{L3},new String[]{ null});
                DexLabel L12=new DexLabel();
                DexLabel L13=new DexLabel();
                DexLabel L14=new DexLabel();
                code.visitTryCatch(L12,L13,new DexLabel[]{L14},new String[]{ "Ljava/lang/Exception;"});
                DexLabel L15=new DexLabel();
                DexLabel L16=new DexLabel();
                DexLabel L17=new DexLabel();
                code.visitTryCatch(L15,L16,new DexLabel[]{L17},new String[]{ "Ljava/lang/Exception;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L18=new DexLabel();
                ddv.visitPrologue(L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(351,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(352,L20);
                ddv.visitStartLocal(1,L20,"jettyDir","Ljava/io/File;",null);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(368,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(354,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(355,L23);
                ddv.visitStartLocal(5,L23,"versionFile","Ljava/io/File;",null);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(356,L24);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(357,L25);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(358,L26);
                ddv.visitStartLocal(4,L26,"val","I",null);
                ddv.visitLineNumber(361,L0);
                ddv.visitStartLocal(2,L0,"ois","Ljava/io/ObjectInputStream;",null);
                ddv.visitLineNumber(362,L1);
                ddv.visitStartLocal(3,L1,"ois","Ljava/io/ObjectInputStream;",null);
                ddv.visitEndLocal(2,L4);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(372,L27);
                ddv.visitLineNumber(374,L7);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(363,L28);
                ddv.visitLineNumber(365,L2);
                ddv.visitEndLocal(3,L2);
                ddv.visitRestartLocal(2,L2);
                ddv.visitLineNumber(367,L10);
                ddv.visitStartLocal(0,L10,"e","Ljava/lang/Exception;",null);
                ddv.visitLineNumber(372,L11);
                ddv.visitLineNumber(374,L12);
                DexLabel L29=new DexLabel();
                ddv.visitLineNumber(368,L29);
                ddv.visitLineNumber(372,L3);
                ddv.visitEndLocal(0,L3);
                ddv.visitLineNumber(374,L15);
                ddv.visitLineNumber(372,L16);
                ddv.visitLineNumber(374,L17);
                DexLabel L30=new DexLabel();
                ddv.visitRestartLocal(0,L30);
                DexLabel L31=new DexLabel();
                ddv.visitRestartLocal(0,L31);
                ddv.visitEndLocal(2,L9);
                ddv.visitEndLocal(0,L9);
                ddv.visitRestartLocal(3,L9);
                DexLabel L32=new DexLabel();
                ddv.visitRestartLocal(0,L32);
                ddv.visitLineNumber(372,L6);
                ddv.visitEndLocal(0,L6);
                DexLabel L33=new DexLabel();
                ddv.visitRestartLocal(2,L33);
                ddv.visitLineNumber(365,L5);
                ddv.visitEndLocal(2,L5);
                DexLabel L34=new DexLabel();
                ddv.visitRestartLocal(2,L34);
                code.visitLabel(L18);
                code.visitConstStmt(CONST_4,9, Integer.valueOf(-1)); // int: 0xffffffff  float:NaN
                code.visitConstStmt(CONST_STRING,10,"Error closing version.code input stream");
                code.visitConstStmt(CONST_STRING,8,"Jetty");
                code.visitLabel(L19);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/io/File;");
                code.visitConstStmt(CONST_STRING,6,"/sdcard/jetty");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,6},new Method("Ljava/io/File;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L20);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/io/File;","exists",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitJumpStmt(IF_NEZ,6,-1,L22);
                code.visitStmt2R(MOVE,6,9);
                code.visitLabel(L21);
                code.visitStmt1R(RETURN,6);
                code.visitLabel(L22);
                code.visitTypeStmt(NEW_INSTANCE,5,-1,"Ljava/io/File;");
                code.visitConstStmt(CONST_STRING,6,"version.code");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 5,1,6},new Method("Ljava/io/File;","<init>",new String[]{ "Ljava/io/File;","Ljava/lang/String;"},"V"));
                code.visitLabel(L23);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/io/File;","exists",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitJumpStmt(IF_NEZ,6,-1,L25);
                code.visitStmt2R(MOVE,6,9);
                code.visitLabel(L24);
                code.visitJumpStmt(GOTO,-1,-1,L21);
                code.visitLabel(L25);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(-1)); // int: 0xffffffff  float:NaN
                code.visitLabel(L26);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Ljava/io/ObjectInputStream;");
                code.visitTypeStmt(NEW_INSTANCE,6,-1,"Ljava/io/FileInputStream;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 6,5},new Method("Ljava/io/FileInputStream;","<init>",new String[]{ "Ljava/io/File;"},"V"));
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3,6},new Method("Ljava/io/ObjectInputStream;","<init>",new String[]{ "Ljava/io/InputStream;"},"V"));
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/io/ObjectInputStream;","readInt",new String[]{ },"I"));
                code.visitLabel(L4);
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitLabel(L27);
                code.visitJumpStmt(IF_EQZ,3,-1,L8);
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/io/ObjectInputStream;","close",new String[]{ },"V"));
                code.visitLabel(L8);
                code.visitStmt2R(MOVE,6,4);
                code.visitLabel(L28);
                code.visitJumpStmt(GOTO,-1,-1,L21);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,6);
                code.visitStmt2R(MOVE_OBJECT,0,6);
                code.visitLabel(L10);
                code.visitConstStmt(CONST_STRING,6,"Jetty");
                code.visitConstStmt(CONST_STRING,7,"Problem reading version.code");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 6,7,0},new Method("Landroid/util/Log;","e",new String[]{ "Ljava/lang/String;","Ljava/lang/String;","Ljava/lang/Throwable;"},"I"));
                code.visitLabel(L11);
                code.visitJumpStmt(IF_EQZ,2,-1,L13);
                code.visitLabel(L12);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/io/ObjectInputStream;","close",new String[]{ },"V"));
                code.visitLabel(L13);
                code.visitStmt2R(MOVE,6,9);
                code.visitLabel(L29);
                code.visitJumpStmt(GOTO,-1,-1,L21);
                code.visitLabel(L3);
                code.visitStmt1R(MOVE_EXCEPTION,6);
                DexLabel L35=new DexLabel();
                code.visitLabel(L35);
                code.visitJumpStmt(IF_EQZ,2,-1,L16);
                code.visitLabel(L15);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/io/ObjectInputStream;","close",new String[]{ },"V"));
                code.visitLabel(L16);
                code.visitStmt1R(THROW,6);
                code.visitLabel(L17);
                code.visitStmt1R(MOVE_EXCEPTION,0);
                code.visitLabel(L30);
                code.visitConstStmt(CONST_STRING,7,"Jetty");
                code.visitConstStmt(CONST_STRING,7,"Error closing version.code input stream");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 8,10,0},new Method("Landroid/util/Log;","d",new String[]{ "Ljava/lang/String;","Ljava/lang/String;","Ljava/lang/Throwable;"},"I"));
                code.visitJumpStmt(GOTO,-1,-1,L16);
                code.visitLabel(L14);
                code.visitStmt1R(MOVE_EXCEPTION,0);
                code.visitLabel(L31);
                code.visitConstStmt(CONST_STRING,6,"Jetty");
                code.visitConstStmt(CONST_STRING,6,"Error closing version.code input stream");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 8,10,0},new Method("Landroid/util/Log;","d",new String[]{ "Ljava/lang/String;","Ljava/lang/String;","Ljava/lang/Throwable;"},"I"));
                code.visitJumpStmt(GOTO,-1,-1,L13);
                code.visitLabel(L9);
                code.visitStmt1R(MOVE_EXCEPTION,0);
                code.visitLabel(L32);
                code.visitConstStmt(CONST_STRING,6,"Jetty");
                code.visitConstStmt(CONST_STRING,6,"Error closing version.code input stream");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 8,10,0},new Method("Landroid/util/Log;","d",new String[]{ "Ljava/lang/String;","Ljava/lang/String;","Ljava/lang/Throwable;"},"I"));
                code.visitJumpStmt(GOTO,-1,-1,L8);
                code.visitLabel(L6);
                code.visitStmt1R(MOVE_EXCEPTION,6);
                code.visitStmt2R(MOVE_OBJECT,2,3);
                code.visitLabel(L33);
                code.visitJumpStmt(GOTO,-1,-1,L35);
                code.visitLabel(L5);
                code.visitStmt1R(MOVE_EXCEPTION,6);
                code.visitStmt2R(MOVE_OBJECT,0,6);
                code.visitStmt2R(MOVE_OBJECT,2,3);
                code.visitLabel(L34);
                code.visitJumpStmt(GOTO,-1,-1,L10);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_onCreate(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/ijetty/IJetty;","onCreate",new String[]{ "Landroid/os/Bundle;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(12);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/lang/Exception;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"icicle");
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(182,L0);
                ddv.visitLineNumber(188,L1);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(189,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(190,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(193,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(194,L6);
                ddv.visitStartLocal(3,L6,"heading","Landroid/widget/TextView;",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(197,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(198,L8);
                ddv.visitStartLocal(5,L8,"startButton","Landroid/widget/Button;",null);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(213,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(214,L10);
                ddv.visitStartLocal(6,L10,"stopButton","Landroid/widget/Button;",null);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(224,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(225,L12);
                ddv.visitStartLocal(0,L12,"configButton","Landroid/widget/Button;",null);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(235,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(236,L14);
                ddv.visitStartLocal(1,L14,"downloadButton","Landroid/widget/Button;",null);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(246,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(247,L16);
                ddv.visitStartLocal(4,L16,"list","Landroid/widget/ListView;",null);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(248,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(250,L18);
                ddv.visitLineNumber(184,L2);
                ddv.visitEndLocal(3,L2);
                ddv.visitEndLocal(5,L2);
                ddv.visitEndLocal(6,L2);
                ddv.visitEndLocal(0,L2);
                ddv.visitEndLocal(1,L2);
                ddv.visitEndLocal(4,L2);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(186,L19);
                ddv.visitStartLocal(2,L19,"e","Ljava/lang/Exception;",null);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Lorg/mortbay/ijetty/IJetty;","getPackageManager",new String[]{ },"Landroid/content/pm/PackageManager;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Lorg/mortbay/ijetty/IJetty;","getPackageName",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitConstStmt(CONST_4,9, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,8,9},new Method("Landroid/content/pm/PackageManager;","getPackageInfo",new String[]{ "Ljava/lang/String;","I"},"Landroid/content/pm/PackageInfo;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitFieldStmt(IPUT_OBJECT,7,10,new Field("Lorg/mortbay/ijetty/IJetty;","pi","Landroid/content/pm/PackageInfo;"));
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Lorg/mortbay/ijetty/IJetty;","setupJetty",new String[]{ },"V"));
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 10,11},new Method("Landroid/app/Activity;","onCreate",new String[]{ "Landroid/os/Bundle;"},"V"));
                code.visitLabel(L4);
                code.visitConstStmt(CONST_HIGH16,7, Integer.valueOf(2130903040)); // int: 0x7f030000  float:174128867447823980000000000000000000000.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10,7},new Method("Lorg/mortbay/ijetty/IJetty;","setContentView",new String[]{ "I"},"V"));
                code.visitLabel(L5);
                code.visitConstStmt(CONST_HIGH16,7, Integer.valueOf(2131165184)); // int: 0x7f070000  float:179445779430963640000000000000000000000.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10,7},new Method("Lorg/mortbay/ijetty/IJetty;","findViewById",new String[]{ "I"},"Landroid/view/View;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitTypeStmt(CHECK_CAST,3,-1,"Landroid/widget/TextView;");
                code.visitLabel(L6);
                code.visitTypeStmt(NEW_INSTANCE,7,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 7},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,8,"i-jetty ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,8},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitFieldStmt(IGET_OBJECT,8,10,new Field("Lorg/mortbay/ijetty/IJetty;","pi","Landroid/content/pm/PackageInfo;"));
                code.visitFieldStmt(IGET_OBJECT,8,8,new Field("Landroid/content/pm/PackageInfo;","versionName","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,8},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,7},new Method("Landroid/widget/TextView;","setText",new String[]{ "Ljava/lang/CharSequence;"},"V"));
                code.visitLabel(L7);
                code.visitConstStmt(CONST,7, Integer.valueOf(2131165185)); // int: 0x7f070001  float:179445799713373250000000000000000000000.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10,7},new Method("Lorg/mortbay/ijetty/IJetty;","findViewById",new String[]{ "I"},"Landroid/view/View;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitTypeStmt(CHECK_CAST,5,-1,"Landroid/widget/Button;");
                code.visitLabel(L8);
                code.visitTypeStmt(NEW_INSTANCE,7,-1,"Lorg/mortbay/ijetty/IJetty$1;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 7,10},new Method("Lorg/mortbay/ijetty/IJetty$1;","<init>",new String[]{ "Lorg/mortbay/ijetty/IJetty;"},"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,7},new Method("Landroid/widget/Button;","setOnClickListener",new String[]{ "Landroid/view/View$OnClickListener;"},"V"));
                code.visitLabel(L9);
                code.visitConstStmt(CONST,7, Integer.valueOf(2131165186)); // int: 0x7f070002  float:179445819995782850000000000000000000000.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10,7},new Method("Lorg/mortbay/ijetty/IJetty;","findViewById",new String[]{ "I"},"Landroid/view/View;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitTypeStmt(CHECK_CAST,6,-1,"Landroid/widget/Button;");
                code.visitLabel(L10);
                code.visitTypeStmt(NEW_INSTANCE,7,-1,"Lorg/mortbay/ijetty/IJetty$2;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 7,10},new Method("Lorg/mortbay/ijetty/IJetty$2;","<init>",new String[]{ "Lorg/mortbay/ijetty/IJetty;"},"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,7},new Method("Landroid/widget/Button;","setOnClickListener",new String[]{ "Landroid/view/View$OnClickListener;"},"V"));
                code.visitLabel(L11);
                code.visitConstStmt(CONST,7, Integer.valueOf(2131165187)); // int: 0x7f070003  float:179445840278192450000000000000000000000.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10,7},new Method("Lorg/mortbay/ijetty/IJetty;","findViewById",new String[]{ "I"},"Landroid/view/View;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Landroid/widget/Button;");
                code.visitLabel(L12);
                code.visitTypeStmt(NEW_INSTANCE,7,-1,"Lorg/mortbay/ijetty/IJetty$3;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 7,10},new Method("Lorg/mortbay/ijetty/IJetty$3;","<init>",new String[]{ "Lorg/mortbay/ijetty/IJetty;"},"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,7},new Method("Landroid/widget/Button;","setOnClickListener",new String[]{ "Landroid/view/View$OnClickListener;"},"V"));
                code.visitLabel(L13);
                code.visitConstStmt(CONST,7, Integer.valueOf(2131165188)); // int: 0x7f070004  float:179445860560602060000000000000000000000.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10,7},new Method("Lorg/mortbay/ijetty/IJetty;","findViewById",new String[]{ "I"},"Landroid/view/View;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitTypeStmt(CHECK_CAST,1,-1,"Landroid/widget/Button;");
                code.visitLabel(L14);
                code.visitTypeStmt(NEW_INSTANCE,7,-1,"Lorg/mortbay/ijetty/IJetty$4;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 7,10},new Method("Lorg/mortbay/ijetty/IJetty$4;","<init>",new String[]{ "Lorg/mortbay/ijetty/IJetty;"},"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,7},new Method("Landroid/widget/Button;","setOnClickListener",new String[]{ "Landroid/view/View$OnClickListener;"},"V"));
                code.visitLabel(L15);
                code.visitConstStmt(CONST,7, Integer.valueOf(2131165189)); // int: 0x7f070005  float:179445880843011660000000000000000000000.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10,7},new Method("Lorg/mortbay/ijetty/IJetty;","findViewById",new String[]{ "I"},"Landroid/view/View;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitTypeStmt(CHECK_CAST,4,-1,"Landroid/widget/ListView;");
                code.visitLabel(L16);
                code.visitTypeStmt(NEW_INSTANCE,7,-1,"Lorg/mortbay/ijetty/IJetty$IPList;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 7,10},new Method("Lorg/mortbay/ijetty/IJetty$IPList;","<init>",new String[]{ "Lorg/mortbay/ijetty/IJetty;"},"V"));
                code.visitFieldStmt(IPUT_OBJECT,7,10,new Field("Lorg/mortbay/ijetty/IJetty;","_ipList","Lorg/mortbay/ijetty/IJetty$IPList;"));
                code.visitLabel(L17);
                code.visitTypeStmt(NEW_INSTANCE,7,-1,"Lorg/mortbay/ijetty/IJetty$NetworkListAdapter;");
                code.visitFieldStmt(IGET_OBJECT,8,10,new Field("Lorg/mortbay/ijetty/IJetty;","_ipList","Lorg/mortbay/ijetty/IJetty$IPList;"));
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 7,10,10,8},new Method("Lorg/mortbay/ijetty/IJetty$NetworkListAdapter;","<init>",new String[]{ "Lorg/mortbay/ijetty/IJetty;","Landroid/content/Context;","Lorg/mortbay/ijetty/IJetty$IPList;"},"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,7},new Method("Landroid/widget/ListView;","setAdapter",new String[]{ "Landroid/widget/ListAdapter;"},"V"));
                code.visitLabel(L18);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,7);
                code.visitStmt2R(MOVE_OBJECT,2,7);
                code.visitLabel(L19);
                code.visitConstStmt(CONST_STRING,7,"Jetty");
                code.visitConstStmt(CONST_STRING,8,"Unable to determine running jetty version");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 7,8},new Method("Landroid/util/Log;","e",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"I"));
                code.visitJumpStmt(GOTO_16,-1,-1,L1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_onResume(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/ijetty/IJetty;","onResume",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(254,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(255,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(256,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/ijetty/IJetty;","_ipList","Lorg/mortbay/ijetty/IJetty$IPList;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/ijetty/IJetty$IPList;","refresh",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 1},new Method("Landroid/app/Activity;","onResume",new String[]{ },"V"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_setStoredJettyVersion(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/ijetty/IJetty;","setStoredJettyVersion",new String[]{ "I"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(12);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                DexLabel L3=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2,L3},new String[]{ "Ljava/lang/Exception;",null});
                DexLabel L4=new DexLabel();
                DexLabel L5=new DexLabel();
                DexLabel L6=new DexLabel();
                code.visitTryCatch(L1,L4,new DexLabel[]{L5,L6},new String[]{ "Ljava/lang/Exception;",null});
                DexLabel L7=new DexLabel();
                DexLabel L8=new DexLabel();
                DexLabel L9=new DexLabel();
                code.visitTryCatch(L7,L8,new DexLabel[]{L9},new String[]{ "Ljava/lang/Exception;"});
                DexLabel L10=new DexLabel();
                DexLabel L11=new DexLabel();
                code.visitTryCatch(L10,L11,new DexLabel[]{L3},new String[]{ null});
                DexLabel L12=new DexLabel();
                DexLabel L13=new DexLabel();
                DexLabel L14=new DexLabel();
                code.visitTryCatch(L12,L13,new DexLabel[]{L14},new String[]{ "Ljava/lang/Exception;"});
                DexLabel L15=new DexLabel();
                DexLabel L16=new DexLabel();
                DexLabel L17=new DexLabel();
                code.visitTryCatch(L15,L16,new DexLabel[]{L17},new String[]{ "Ljava/lang/Exception;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"version");
                DexLabel L18=new DexLabel();
                ddv.visitPrologue(L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(381,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(382,L20);
                ddv.visitStartLocal(2,L20,"jettyDir","Ljava/io/File;",null);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(404,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(384,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(385,L23);
                ddv.visitStartLocal(5,L23,"versionFile","Ljava/io/File;",null);
                ddv.visitLineNumber(388,L0);
                ddv.visitStartLocal(3,L0,"oos","Ljava/io/ObjectOutputStream;",null);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(389,L24);
                ddv.visitStartLocal(1,L24,"fos","Ljava/io/FileOutputStream;",null);
                ddv.visitLineNumber(390,L1);
                ddv.visitStartLocal(4,L1,"oos","Ljava/io/ObjectOutputStream;",null);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(391,L25);
                ddv.visitEndLocal(3,L25);
                ddv.visitLineNumber(399,L4);
                ddv.visitLineNumber(401,L7);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(403,L26);
                ddv.visitRestartLocal(3,L26);
                ddv.visitLineNumber(393,L2);
                ddv.visitEndLocal(1,L2);
                ddv.visitEndLocal(4,L2);
                ddv.visitLineNumber(395,L10);
                ddv.visitStartLocal(0,L10,"e","Ljava/lang/Exception;",null);
                ddv.visitLineNumber(399,L11);
                ddv.visitLineNumber(401,L12);
                ddv.visitLineNumber(399,L3);
                ddv.visitEndLocal(0,L3);
                ddv.visitLineNumber(401,L15);
                ddv.visitLineNumber(399,L16);
                ddv.visitLineNumber(401,L17);
                DexLabel L27=new DexLabel();
                ddv.visitRestartLocal(0,L27);
                ddv.visitEndLocal(3,L9);
                ddv.visitEndLocal(0,L9);
                ddv.visitRestartLocal(1,L9);
                ddv.visitRestartLocal(4,L9);
                DexLabel L28=new DexLabel();
                ddv.visitRestartLocal(0,L28);
                ddv.visitLineNumber(399,L6);
                ddv.visitEndLocal(0,L6);
                DexLabel L29=new DexLabel();
                ddv.visitRestartLocal(3,L29);
                ddv.visitLineNumber(393,L5);
                ddv.visitEndLocal(3,L5);
                DexLabel L30=new DexLabel();
                ddv.visitRestartLocal(3,L30);
                code.visitLabel(L18);
                code.visitConstStmt(CONST_STRING,9,"Error closing version.code output stream");
                code.visitConstStmt(CONST_STRING,8,"Jetty");
                code.visitLabel(L19);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Ljava/io/File;");
                code.visitConstStmt(CONST_STRING,6,"/sdcard/jetty");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2,6},new Method("Ljava/io/File;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L20);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/io/File;","exists",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitJumpStmt(IF_NEZ,6,-1,L22);
                code.visitLabel(L21);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L22);
                code.visitTypeStmt(NEW_INSTANCE,5,-1,"Ljava/io/File;");
                code.visitConstStmt(CONST_STRING,6,"version.code");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 5,2,6},new Method("Ljava/io/File;","<init>",new String[]{ "Ljava/io/File;","Ljava/lang/String;"},"V"));
                code.visitLabel(L23);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/io/FileOutputStream;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,5},new Method("Ljava/io/FileOutputStream;","<init>",new String[]{ "Ljava/io/File;"},"V"));
                code.visitLabel(L24);
                code.visitTypeStmt(NEW_INSTANCE,4,-1,"Ljava/io/ObjectOutputStream;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4,1},new Method("Ljava/io/ObjectOutputStream;","<init>",new String[]{ "Ljava/io/OutputStream;"},"V"));
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,11},new Method("Ljava/io/ObjectOutputStream;","writeInt",new String[]{ "I"},"V"));
                code.visitLabel(L25);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/io/ObjectOutputStream;","flush",new String[]{ },"V"));
                code.visitLabel(L4);
                code.visitJumpStmt(IF_EQZ,4,-1,L8);
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/io/ObjectOutputStream;","close",new String[]{ },"V"));
                code.visitLabel(L8);
                code.visitStmt2R(MOVE_OBJECT,3,4);
                code.visitLabel(L26);
                code.visitJumpStmt(GOTO,-1,-1,L21);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,6);
                code.visitStmt2R(MOVE_OBJECT,0,6);
                code.visitLabel(L10);
                code.visitConstStmt(CONST_STRING,6,"Jetty");
                code.visitConstStmt(CONST_STRING,7,"Problem writing jetty version");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 6,7,0},new Method("Landroid/util/Log;","e",new String[]{ "Ljava/lang/String;","Ljava/lang/String;","Ljava/lang/Throwable;"},"I"));
                code.visitLabel(L11);
                code.visitJumpStmt(IF_EQZ,3,-1,L21);
                code.visitLabel(L12);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/io/ObjectOutputStream;","close",new String[]{ },"V"));
                code.visitLabel(L13);
                code.visitJumpStmt(GOTO,-1,-1,L21);
                code.visitLabel(L14);
                code.visitStmt1R(MOVE_EXCEPTION,0);
                code.visitConstStmt(CONST_STRING,6,"Jetty");
                code.visitConstStmt(CONST_STRING,6,"Error closing version.code output stream");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 8,9,0},new Method("Landroid/util/Log;","d",new String[]{ "Ljava/lang/String;","Ljava/lang/String;","Ljava/lang/Throwable;"},"I"));
                code.visitJumpStmt(GOTO,-1,-1,L21);
                code.visitLabel(L3);
                code.visitStmt1R(MOVE_EXCEPTION,6);
                DexLabel L31=new DexLabel();
                code.visitLabel(L31);
                code.visitJumpStmt(IF_EQZ,3,-1,L16);
                code.visitLabel(L15);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/io/ObjectOutputStream;","close",new String[]{ },"V"));
                code.visitLabel(L16);
                code.visitStmt1R(THROW,6);
                code.visitLabel(L17);
                code.visitStmt1R(MOVE_EXCEPTION,0);
                code.visitLabel(L27);
                code.visitConstStmt(CONST_STRING,7,"Jetty");
                code.visitConstStmt(CONST_STRING,7,"Error closing version.code output stream");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 8,9,0},new Method("Landroid/util/Log;","d",new String[]{ "Ljava/lang/String;","Ljava/lang/String;","Ljava/lang/Throwable;"},"I"));
                code.visitJumpStmt(GOTO,-1,-1,L16);
                code.visitLabel(L9);
                code.visitStmt1R(MOVE_EXCEPTION,0);
                code.visitLabel(L28);
                code.visitConstStmt(CONST_STRING,6,"Jetty");
                code.visitConstStmt(CONST_STRING,6,"Error closing version.code output stream");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 8,9,0},new Method("Landroid/util/Log;","d",new String[]{ "Ljava/lang/String;","Ljava/lang/String;","Ljava/lang/Throwable;"},"I"));
                code.visitJumpStmt(GOTO,-1,-1,L8);
                code.visitLabel(L6);
                code.visitStmt1R(MOVE_EXCEPTION,6);
                code.visitStmt2R(MOVE_OBJECT,3,4);
                code.visitLabel(L29);
                code.visitJumpStmt(GOTO,-1,-1,L31);
                code.visitLabel(L5);
                code.visitStmt1R(MOVE_EXCEPTION,6);
                code.visitStmt2R(MOVE_OBJECT,0,6);
                code.visitStmt2R(MOVE_OBJECT,3,4);
                code.visitLabel(L30);
                code.visitJumpStmt(GOTO,-1,-1,L10);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_setupJetty(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/ijetty/IJetty;","setupJetty",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(24);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/lang/Exception;"});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                DexLabel L5=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L5},new String[]{ "Ljava/lang/Exception;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L6=new DexLabel();
                ddv.visitPrologue(L6);
                ddv.visitLineNumber(262,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(264,L7);
                ddv.visitStartLocal(17,L7,"update","Z",null);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(266,L8);
                ddv.visitStartLocal(15,L8,"storedVersion","I",null);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(267,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(270,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(271,L11);
                ddv.visitStartLocal(12,L11,"jettyDir","Ljava/io/File;",null);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(272,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(275,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(276,L14);
                ddv.visitStartLocal(16,L14,"tmpDir","Ljava/io/File;",null);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(277,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(280,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(281,L17);
                ddv.visitStartLocal(18,L17,"webappsDir","Ljava/io/File;",null);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(282,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(285,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(286,L20);
                ddv.visitStartLocal(8,L20,"etcDir","Ljava/io/File;",null);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(287,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(289,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(290,L23);
                ddv.visitStartLocal(19,L23,"webdefaults","Ljava/io/File;",null);
                ddv.visitLineNumber(295,L0);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(296,L24);
                ddv.visitStartLocal(11,L24,"is","Ljava/io/InputStream;",null);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(297,L25);
                ddv.visitStartLocal(13,L25,"os","Ljava/io/OutputStream;",null);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(298,L26);
                ddv.visitLineNumber(305,L1);
                ddv.visitEndLocal(11,L1);
                ddv.visitEndLocal(13,L1);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(306,L27);
                ddv.visitStartLocal(14,L27,"realm","Ljava/io/File;",null);
                ddv.visitLineNumber(311,L3);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(312,L28);
                ddv.visitRestartLocal(11,L28);
                DexLabel L29=new DexLabel();
                ddv.visitLineNumber(313,L29);
                ddv.visitRestartLocal(13,L29);
                DexLabel L30=new DexLabel();
                ddv.visitLineNumber(314,L30);
                ddv.visitLineNumber(323,L4);
                ddv.visitEndLocal(11,L4);
                ddv.visitEndLocal(13,L4);
                DexLabel L31=new DexLabel();
                ddv.visitLineNumber(324,L31);
                ddv.visitStartLocal(6,L31,"contextsDir","Ljava/io/File;",null);
                DexLabel L32=new DexLabel();
                ddv.visitLineNumber(325,L32);
                DexLabel L33=new DexLabel();
                ddv.visitLineNumber(330,L33);
                DexLabel L34=new DexLabel();
                ddv.visitLineNumber(331,L34);
                ddv.visitStartLocal(5,L34,"consoleWar","Ljava/io/File;",null);
                DexLabel L35=new DexLabel();
                ddv.visitLineNumber(333,L35);
                DexLabel L36=new DexLabel();
                ddv.visitLineNumber(334,L36);
                DexLabel L37=new DexLabel();
                ddv.visitLineNumber(337,L37);
                DexLabel L38=new DexLabel();
                ddv.visitLineNumber(338,L38);
                ddv.visitStartLocal(9,L38,"exists","Z",null);
                DexLabel L39=new DexLabel();
                ddv.visitLineNumber(339,L39);
                ddv.visitStartLocal(10,L39,"files","[Ljava/lang/String;",null);
                DexLabel L40=new DexLabel();
                ddv.visitLineNumber(341,L40);
                DexLabel L41=new DexLabel();
                ddv.visitLineNumber(342,L41);
                ddv.visitRestartLocal(11,L41);
                DexLabel L42=new DexLabel();
                ddv.visitLineNumber(343,L42);
                DexLabel L43=new DexLabel();
                ddv.visitLineNumber(346,L43);
                ddv.visitEndLocal(11,L43);
                DexLabel L44=new DexLabel();
                ddv.visitLineNumber(347,L44);
                ddv.visitLineNumber(300,L2);
                ddv.visitEndLocal(14,L2);
                ddv.visitEndLocal(6,L2);
                ddv.visitEndLocal(5,L2);
                ddv.visitEndLocal(9,L2);
                ddv.visitEndLocal(10,L2);
                DexLabel L45=new DexLabel();
                ddv.visitLineNumber(302,L45);
                ddv.visitStartLocal(7,L45,"e","Ljava/lang/Exception;",null);
                ddv.visitLineNumber(316,L5);
                ddv.visitEndLocal(7,L5);
                ddv.visitRestartLocal(14,L5);
                DexLabel L46=new DexLabel();
                ddv.visitLineNumber(318,L46);
                ddv.visitRestartLocal(7,L46);
                code.visitLabel(L6);
                code.visitConstStmt(CONST_16,17, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 23},new Method("Lorg/mortbay/ijetty/IJetty;","getStoredJettyVersion",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,15);
                code.visitLabel(L8);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,23);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/ijetty/IJetty;","pi","Landroid/content/pm/PackageInfo;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,20,0);
                code.visitJumpStmt(IF_EQZ,20,-1,L10);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,23);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/ijetty/IJetty;","pi","Landroid/content/pm/PackageInfo;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,20,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,20);
                code.visitFieldStmt(IGET,0,0,new Field("Landroid/content/pm/PackageInfo;","versionCode","I"));
                code.visitStmt2R(MOVE_FROM16,20,0);
                code.visitStmt2R(MOVE_FROM16,0,20);
                code.visitStmt2R(MOVE,1,15);
                code.visitJumpStmt(IF_LE,0,1,L10);
                code.visitLabel(L9);
                code.visitConstStmt(CONST_16,17, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L10);
                code.visitTypeStmt(NEW_INSTANCE,12,-1,"Ljava/io/File;");
                code.visitConstStmt(CONST_STRING,20,"/sdcard/jetty");
                code.visitStmt2R(MOVE_OBJECT,0,12);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,20);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Ljava/io/File;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L11);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12},new Method("Ljava/io/File;","exists",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,20);
                code.visitJumpStmt(IF_NEZ,20,-1,L13);
                code.visitLabel(L12);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12},new Method("Ljava/io/File;","mkdirs",new String[]{ },"Z"));
                code.visitLabel(L13);
                code.visitTypeStmt(NEW_INSTANCE,16,-1,"Ljava/io/File;");
                code.visitConstStmt(CONST_STRING,20,"tmp");
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,16);
                code.visitStmt2R(MOVE_OBJECT,1,12);
                code.visitStmt2R(MOVE_OBJECT_FROM16,2,20);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1,2},new Method("Ljava/io/File;","<init>",new String[]{ "Ljava/io/File;","Ljava/lang/String;"},"V"));
                code.visitLabel(L14);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 16},new Method("Ljava/io/File;","exists",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,20);
                code.visitJumpStmt(IF_NEZ,20,-1,L16);
                code.visitLabel(L15);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 16},new Method("Ljava/io/File;","mkdirs",new String[]{ },"Z"));
                code.visitLabel(L16);
                code.visitTypeStmt(NEW_INSTANCE,18,-1,"Ljava/io/File;");
                code.visitConstStmt(CONST_STRING,20,"webapps");
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,18);
                code.visitStmt2R(MOVE_OBJECT,1,12);
                code.visitStmt2R(MOVE_OBJECT_FROM16,2,20);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1,2},new Method("Ljava/io/File;","<init>",new String[]{ "Ljava/io/File;","Ljava/lang/String;"},"V"));
                code.visitLabel(L17);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 18},new Method("Ljava/io/File;","exists",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,20);
                code.visitJumpStmt(IF_NEZ,20,-1,L19);
                code.visitLabel(L18);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 18},new Method("Ljava/io/File;","mkdirs",new String[]{ },"Z"));
                code.visitLabel(L19);
                code.visitTypeStmt(NEW_INSTANCE,8,-1,"Ljava/io/File;");
                code.visitConstStmt(CONST_STRING,20,"etc");
                code.visitStmt2R(MOVE_OBJECT,0,8);
                code.visitStmt2R(MOVE_OBJECT,1,12);
                code.visitStmt2R(MOVE_OBJECT_FROM16,2,20);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1,2},new Method("Ljava/io/File;","<init>",new String[]{ "Ljava/io/File;","Ljava/lang/String;"},"V"));
                code.visitLabel(L20);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Ljava/io/File;","exists",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,20);
                code.visitJumpStmt(IF_NEZ,20,-1,L22);
                code.visitLabel(L21);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Ljava/io/File;","mkdirs",new String[]{ },"Z"));
                code.visitLabel(L22);
                code.visitTypeStmt(NEW_INSTANCE,19,-1,"Ljava/io/File;");
                code.visitConstStmt(CONST_STRING,20,"webdefault.xml");
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,19);
                code.visitStmt2R(MOVE_OBJECT,1,8);
                code.visitStmt2R(MOVE_OBJECT_FROM16,2,20);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1,2},new Method("Ljava/io/File;","<init>",new String[]{ "Ljava/io/File;","Ljava/lang/String;"},"V"));
                code.visitLabel(L23);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 19},new Method("Ljava/io/File;","exists",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,20);
                code.visitJumpStmt(IF_EQZ,20,-1,L0);
                code.visitJumpStmt(IF_EQZ,17,-1,L1);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 23},new Method("Lorg/mortbay/ijetty/IJetty;","getResources",new String[]{ },"Landroid/content/res/Resources;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,20);
                code.visitConstStmt(CONST,21, Integer.valueOf(2131034113)); // int: 0x7f050001  float:176787343721803400000000000000000000000.000000
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 20,21},new Method("Landroid/content/res/Resources;","openRawResource",new String[]{ "I"},"Ljava/io/InputStream;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,11);
                code.visitLabel(L24);
                code.visitTypeStmt(NEW_INSTANCE,13,-1,"Ljava/io/FileOutputStream;");
                code.visitStmt2R(MOVE_OBJECT,0,13);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,19);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Ljava/io/FileOutputStream;","<init>",new String[]{ "Ljava/io/File;"},"V"));
                code.visitLabel(L25);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 11,13},new Method("Lorg/mortbay/util/IO;","copy",new String[]{ "Ljava/io/InputStream;","Ljava/io/OutputStream;"},"V"));
                code.visitLabel(L26);
                code.visitConstStmt(CONST_STRING,20,"Jetty");
                code.visitConstStmt(CONST_STRING,21,"Loaded webdefault.xml");
                code.visitMethodStmt(INVOKE_STATIC_RANGE,new int[]{ 20,21},new Method("Landroid/util/Log;","i",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"I"));
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,14,-1,"Ljava/io/File;");
                code.visitConstStmt(CONST_STRING,20,"realm.properties");
                code.visitStmt2R(MOVE_OBJECT,0,14);
                code.visitStmt2R(MOVE_OBJECT,1,8);
                code.visitStmt2R(MOVE_OBJECT_FROM16,2,20);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1,2},new Method("Ljava/io/File;","<init>",new String[]{ "Ljava/io/File;","Ljava/lang/String;"},"V"));
                code.visitLabel(L27);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 14},new Method("Ljava/io/File;","exists",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,20);
                code.visitJumpStmt(IF_EQZ,20,-1,L3);
                code.visitJumpStmt(IF_EQZ,17,-1,L4);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 23},new Method("Lorg/mortbay/ijetty/IJetty;","getResources",new String[]{ },"Landroid/content/res/Resources;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,20);
                code.visitConstStmt(CONST_HIGH16,21, Integer.valueOf(2131034112)); // int: 0x7f050000  float:176787323439393800000000000000000000000.000000
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 20,21},new Method("Landroid/content/res/Resources;","openRawResource",new String[]{ "I"},"Ljava/io/InputStream;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,11);
                code.visitLabel(L28);
                code.visitTypeStmt(NEW_INSTANCE,13,-1,"Ljava/io/FileOutputStream;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 13,14},new Method("Ljava/io/FileOutputStream;","<init>",new String[]{ "Ljava/io/File;"},"V"));
                code.visitLabel(L29);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 11,13},new Method("Lorg/mortbay/util/IO;","copy",new String[]{ "Ljava/io/InputStream;","Ljava/io/OutputStream;"},"V"));
                code.visitLabel(L30);
                code.visitConstStmt(CONST_STRING,20,"Jetty");
                code.visitConstStmt(CONST_STRING,21,"Loaded realm.properties");
                code.visitMethodStmt(INVOKE_STATIC_RANGE,new int[]{ 20,21},new Method("Landroid/util/Log;","i",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"I"));
                code.visitLabel(L4);
                code.visitTypeStmt(NEW_INSTANCE,6,-1,"Ljava/io/File;");
                code.visitConstStmt(CONST_STRING,20,"contexts");
                code.visitStmt2R(MOVE_OBJECT,0,6);
                code.visitStmt2R(MOVE_OBJECT,1,12);
                code.visitStmt2R(MOVE_OBJECT_FROM16,2,20);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1,2},new Method("Ljava/io/File;","<init>",new String[]{ "Ljava/io/File;","Ljava/lang/String;"},"V"));
                code.visitLabel(L31);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/io/File;","exists",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,20);
                code.visitJumpStmt(IF_NEZ,20,-1,L33);
                code.visitLabel(L32);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/io/File;","mkdirs",new String[]{ },"Z"));
                code.visitLabel(L33);
                code.visitTypeStmt(NEW_INSTANCE,5,-1,"Ljava/io/File;");
                code.visitConstStmt(CONST_STRING,20,"console");
                code.visitStmt2R(MOVE_OBJECT,0,5);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,18);
                code.visitStmt2R(MOVE_OBJECT_FROM16,2,20);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1,2},new Method("Ljava/io/File;","<init>",new String[]{ "Ljava/io/File;","Ljava/lang/String;"},"V"));
                code.visitLabel(L34);
                code.visitJumpStmt(IF_EQZ,17,-1,L37);
                code.visitLabel(L35);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 5},new Method("Lorg/mortbay/ijetty/Installer;","deleteWebapp",new String[]{ "Ljava/io/File;"},"V"));
                code.visitLabel(L36);
                code.visitConstStmt(CONST_STRING,20,"Jetty");
                code.visitConstStmt(CONST_STRING,21,"Cleaned console webapp for update");
                code.visitMethodStmt(INVOKE_STATIC_RANGE,new int[]{ 20,21},new Method("Landroid/util/Log;","i",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"I"));
                code.visitLabel(L37);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/io/File;","exists",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,9);
                code.visitLabel(L38);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/io/File;","list",new String[]{ },"[Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,10);
                code.visitLabel(L39);
                code.visitJumpStmt(IF_EQZ,9,-1,L40);
                code.visitJumpStmt(IF_EQZ,10,-1,L40);
                code.visitStmt2R(MOVE_OBJECT,0,10);
                code.visitStmt2R(ARRAY_LENGTH,0,0);
                code.visitStmt2R(MOVE_FROM16,20,0);
                code.visitJumpStmt(IF_NEZ,20,-1,L43);
                code.visitLabel(L40);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 23},new Method("Lorg/mortbay/ijetty/IJetty;","getClassLoader",new String[]{ },"Ljava/lang/ClassLoader;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,20);
                code.visitConstStmt(CONST_STRING,21,"console.war");
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 20,21},new Method("Ljava/lang/ClassLoader;","getResourceAsStream",new String[]{ "Ljava/lang/String;"},"Ljava/io/InputStream;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,11);
                code.visitLabel(L41);
                code.visitConstStmt(CONST_STRING,20,"/console");
                code.visitConstStmt(CONST_STRING,21,"console");
                code.visitConstStmt(CONST_16,22, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt2R(MOVE_OBJECT,0,11);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,20);
                code.visitStmt2R(MOVE_OBJECT_FROM16,2,18);
                code.visitStmt2R(MOVE_OBJECT_FROM16,3,21);
                code.visitStmt2R(MOVE_FROM16,4,22);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,1,2,3,4},new Method("Lorg/mortbay/ijetty/Installer;","install",new String[]{ "Ljava/io/InputStream;","Ljava/lang/String;","Ljava/io/File;","Ljava/lang/String;","Z"},"V"));
                code.visitLabel(L42);
                code.visitConstStmt(CONST_STRING,20,"Jetty");
                code.visitConstStmt(CONST_STRING,21,"Loaded console webapp");
                code.visitMethodStmt(INVOKE_STATIC_RANGE,new int[]{ 20,21},new Method("Landroid/util/Log;","i",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"I"));
                code.visitLabel(L43);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,23);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/ijetty/IJetty;","pi","Landroid/content/pm/PackageInfo;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,20,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,20);
                code.visitFieldStmt(IGET,0,0,new Field("Landroid/content/pm/PackageInfo;","versionCode","I"));
                code.visitStmt2R(MOVE_FROM16,20,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,23);
                code.visitStmt2R(MOVE_FROM16,1,20);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/ijetty/IJetty;","setStoredJettyVersion",new String[]{ "I"},"V"));
                code.visitLabel(L44);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,20);
                code.visitStmt2R(MOVE_OBJECT_FROM16,7,20);
                code.visitLabel(L45);
                code.visitConstStmt(CONST_STRING,20,"Jetty");
                code.visitConstStmt(CONST_STRING,21,"Error loading webdefault.xml");
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,20);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,21);
                code.visitStmt2R(MOVE_OBJECT,2,7);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,1,2},new Method("Landroid/util/Log;","e",new String[]{ "Ljava/lang/String;","Ljava/lang/String;","Ljava/lang/Throwable;"},"I"));
                code.visitJumpStmt(GOTO_16,-1,-1,L1);
                code.visitLabel(L5);
                code.visitStmt1R(MOVE_EXCEPTION,20);
                code.visitStmt2R(MOVE_OBJECT_FROM16,7,20);
                code.visitLabel(L46);
                code.visitConstStmt(CONST_STRING,20,"Jetty");
                code.visitConstStmt(CONST_STRING,21,"Error loading realm.propeties");
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,20);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,21);
                code.visitStmt2R(MOVE_OBJECT,2,7);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,1,2},new Method("Landroid/util/Log;","e",new String[]{ "Ljava/lang/String;","Ljava/lang/String;","Ljava/lang/Throwable;"},"I"));
                code.visitJumpStmt(GOTO_16,-1,-1,L4);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
