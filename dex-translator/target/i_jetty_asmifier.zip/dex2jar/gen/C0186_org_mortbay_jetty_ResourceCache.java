package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0186_org_mortbay_jetty_ResourceCache {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/jetty/ResourceCache;","Lorg/mortbay/component/AbstractLifeCycle;",new String[]{ "Ljava/io/Serializable;"});
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("ResourceCache.java");
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/MemberClasses;", Visibility.SYSTEM);
            if(av00 != null) {
                {
                    DexAnnotationVisitor av01 = av00.visitArray("value");
                    if(av01 != null) {
                        av01.visit(null, new DexType("Lorg/mortbay/jetty/ResourceCache$Content;"));
                        av01.visitEnd();
                    }
                }
                av00.visitEnd();
            }
        }
        f000__cache(cv);
        f001__cachedFiles(cv);
        f002__cachedSize(cv);
        f003__leastRecentlyUsed(cv);
        f004__maxCacheSize(cv);
        f005__maxCachedFileSize(cv);
        f006__maxCachedFiles(cv);
        f007__mimeTypes(cv);
        f008__mostRecentlyUsed(cv);
        m000__init_(cv);
        m001_access$000(cv);
        m002_load(cv);
        m003_doStart(cv);
        m004_doStop(cv);
        m005_fill(cv);
        m006_flushCache(cv);
        m007_getCachedFiles(cv);
        m008_getCachedSize(cv);
        m009_getMaxCacheSize(cv);
        m010_getMaxCachedFileSize(cv);
        m011_getMaxCachedFiles(cv);
        m012_lookup(cv);
        m013_lookup(cv);
        m014_setMaxCacheSize(cv);
        m015_setMaxCachedFileSize(cv);
        m016_setMaxCachedFiles(cv);
    }
    public static void f000__cache(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED|ACC_TRANSIENT, new Field("Lorg/mortbay/jetty/ResourceCache;","_cache","Ljava/util/Map;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001__cachedFiles(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED|ACC_TRANSIENT, new Field("Lorg/mortbay/jetty/ResourceCache;","_cachedFiles","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002__cachedSize(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED|ACC_TRANSIENT, new Field("Lorg/mortbay/jetty/ResourceCache;","_cachedSize","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003__leastRecentlyUsed(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED|ACC_TRANSIENT, new Field("Lorg/mortbay/jetty/ResourceCache;","_leastRecentlyUsed","Lorg/mortbay/jetty/ResourceCache$Content;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f004__maxCacheSize(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/ResourceCache;","_maxCacheSize","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f005__maxCachedFileSize(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/ResourceCache;","_maxCachedFileSize","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f006__maxCachedFiles(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/ResourceCache;","_maxCachedFiles","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f007__mimeTypes(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/ResourceCache;","_mimeTypes","Lorg/mortbay/jetty/MimeTypes;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f008__mostRecentlyUsed(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED|ACC_TRANSIENT, new Field("Lorg/mortbay/jetty/ResourceCache;","_mostRecentlyUsed","Lorg/mortbay/jetty/ResourceCache$Content;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/ResourceCache;","<init>",new String[]{ "Lorg/mortbay/jetty/MimeTypes;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"mimeTypes");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(55,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(39,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(40,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(41,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(56,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(57,L5);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Lorg/mortbay/component/AbstractLifeCycle;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitConstStmt(CONST_HIGH16,0, Integer.valueOf(1048576)); // int: 0x00100000  float:0.000000
                code.visitFieldStmt(IPUT,0,1,new Field("Lorg/mortbay/jetty/ResourceCache;","_maxCachedFileSize","I"));
                code.visitLabel(L2);
                code.visitConstStmt(CONST_16,0, Integer.valueOf(2048)); // int: 0x00000800  float:0.000000
                code.visitFieldStmt(IPUT,0,1,new Field("Lorg/mortbay/jetty/ResourceCache;","_maxCachedFiles","I"));
                code.visitLabel(L3);
                code.visitConstStmt(CONST_HIGH16,0, Integer.valueOf(16777216)); // int: 0x01000000  float:0.000000
                code.visitFieldStmt(IPUT,0,1,new Field("Lorg/mortbay/jetty/ResourceCache;","_maxCacheSize","I"));
                code.visitLabel(L4);
                code.visitFieldStmt(IPUT_OBJECT,2,1,new Field("Lorg/mortbay/jetty/ResourceCache;","_mimeTypes","Lorg/mortbay/jetty/MimeTypes;"));
                code.visitLabel(L5);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001_access$000(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_SYNTHETIC, new Method("Lorg/mortbay/jetty/ResourceCache;","access$000",new String[]{ "Lorg/mortbay/jetty/ResourceCache;"},"Lorg/mortbay/jetty/MimeTypes;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"x0");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(37,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/ResourceCache;","_mimeTypes","Lorg/mortbay/jetty/MimeTypes;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_load(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PRIVATE, new Method("Lorg/mortbay/jetty/ResourceCache;","load",new String[]{ "Ljava/lang/String;","Lorg/mortbay/resource/Resource;"},"Lorg/mortbay/jetty/ResourceCache$Content;"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(11);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"pathInContext");
                ddv.visitParameterName(1,"resource");
                DexLabel L5=new DexLabel();
                ddv.visitPrologue(L5);
                ddv.visitLineNumber(191,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(192,L6);
                ddv.visitStartLocal(0,L6,"content","Lorg/mortbay/jetty/ResourceCache$Content;",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(194,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(195,L8);
                ddv.visitStartLocal(2,L8,"len","J",null);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(197,L9);
                DexLabel L10=new DexLabel();
                ddv.visitEndLocal(0,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(198,L11);
                ddv.visitRestartLocal(0,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(200,L12);
                ddv.visitLineNumber(203,L0);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(204,L13);
                ddv.visitStartLocal(1,L13,"content2","Lorg/mortbay/jetty/ResourceCache$Content;",null);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(206,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(207,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(220,L16);
                ddv.visitEndLocal(2,L16);
                ddv.visitEndLocal(1,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(210,L17);
                ddv.visitRestartLocal(1,L17);
                ddv.visitRestartLocal(2,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(211,L18);
                ddv.visitStartLocal(4,L18,"must_be_smaller_than","I",null);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(212,L19);
                ddv.visitLineNumber(216,L2);
                ddv.visitEndLocal(1,L2);
                ddv.visitEndLocal(4,L2);
                ddv.visitLineNumber(213,L3);
                ddv.visitRestartLocal(1,L3);
                ddv.visitRestartLocal(4,L3);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(215,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(220,L21);
                ddv.visitEndLocal(2,L21);
                ddv.visitEndLocal(1,L21);
                ddv.visitEndLocal(4,L21);
                code.visitLabel(L5);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L6);
                code.visitJumpStmt(IF_EQZ,10,-1,L21);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Lorg/mortbay/resource/Resource;","exists",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitJumpStmt(IF_EQZ,5,-1,L21);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Lorg/mortbay/resource/Resource;","isDirectory",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitJumpStmt(IF_NEZ,5,-1,L21);
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Lorg/mortbay/resource/Resource;","length",new String[]{ },"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,2);
                code.visitLabel(L8);
                code.visitConstStmt(CONST_WIDE_16,5,Long.valueOf(0L)); // long: 0x0000000000000000  double:0.000000
                code.visitStmt3R(CMP_LONG,5,2,5);
                code.visitJumpStmt(IF_LEZ,5,-1,L21);
                code.visitFieldStmt(IGET,5,8,new Field("Lorg/mortbay/jetty/ResourceCache;","_maxCachedFileSize","I"));
                code.visitStmt2R(INT_TO_LONG,5,5);
                code.visitStmt3R(CMP_LONG,5,2,5);
                code.visitJumpStmt(IF_GEZ,5,-1,L21);
                code.visitFieldStmt(IGET,5,8,new Field("Lorg/mortbay/jetty/ResourceCache;","_maxCacheSize","I"));
                code.visitStmt2R(INT_TO_LONG,5,5);
                code.visitStmt3R(CMP_LONG,5,2,5);
                code.visitJumpStmt(IF_GEZ,5,-1,L21);
                code.visitLabel(L9);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/jetty/ResourceCache$Content;");
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,8,10},new Method("Lorg/mortbay/jetty/ResourceCache$Content;","<init>",new String[]{ "Lorg/mortbay/jetty/ResourceCache;","Lorg/mortbay/resource/Resource;"},"V"));
                code.visitLabel(L11);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,0},new Method("Lorg/mortbay/jetty/ResourceCache;","fill",new String[]{ "Lorg/mortbay/jetty/ResourceCache$Content;"},"V"));
                code.visitLabel(L12);
                code.visitFieldStmt(IGET_OBJECT,5,8,new Field("Lorg/mortbay/jetty/ResourceCache;","_cache","Ljava/util/Map;"));
                code.visitStmt1R(MONITOR_ENTER,5);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,6,8,new Field("Lorg/mortbay/jetty/ResourceCache;","_cache","Ljava/util/Map;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 6,9},new Method("Ljava/util/Map;","get",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitTypeStmt(CHECK_CAST,1,-1,"Lorg/mortbay/jetty/ResourceCache$Content;");
                code.visitLabel(L13);
                code.visitJumpStmt(IF_EQZ,1,-1,L17);
                code.visitLabel(L14);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/ResourceCache$Content;","release",new String[]{ },"V"));
                code.visitLabel(L15);
                code.visitStmt1R(MONITOR_EXIT,5);
                code.visitStmt2R(MOVE_OBJECT,5,1);
                code.visitLabel(L16);
                code.visitStmt1R(RETURN_OBJECT,5);
                code.visitLabel(L17);
                code.visitFieldStmt(IGET,6,8,new Field("Lorg/mortbay/jetty/ResourceCache;","_maxCacheSize","I"));
                code.visitStmt2R(LONG_TO_INT,7,2);
                code.visitStmt3R(SUB_INT,4,6,7);
                code.visitLabel(L18);
                code.visitFieldStmt(IGET,6,8,new Field("Lorg/mortbay/jetty/ResourceCache;","_cachedSize","I"));
                code.visitJumpStmt(IF_GT,6,4,L19);
                code.visitFieldStmt(IGET,6,8,new Field("Lorg/mortbay/jetty/ResourceCache;","_maxCachedFiles","I"));
                code.visitJumpStmt(IF_LEZ,6,-1,L3);
                code.visitFieldStmt(IGET,6,8,new Field("Lorg/mortbay/jetty/ResourceCache;","_cachedFiles","I"));
                code.visitFieldStmt(IGET,7,8,new Field("Lorg/mortbay/jetty/ResourceCache;","_maxCachedFiles","I"));
                code.visitJumpStmt(IF_LT,6,7,L3);
                code.visitLabel(L19);
                code.visitFieldStmt(IGET_OBJECT,6,8,new Field("Lorg/mortbay/jetty/ResourceCache;","_leastRecentlyUsed","Lorg/mortbay/jetty/ResourceCache$Content;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/ResourceCache$Content;","invalidate",new String[]{ },"V"));
                code.visitJumpStmt(GOTO,-1,-1,L18);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,6);
                code.visitStmt1R(MONITOR_EXIT,5);
                code.visitLabel(L1);
                code.visitStmt1R(THROW,6);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,9},new Method("Lorg/mortbay/jetty/ResourceCache$Content;","cache",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L20);
                code.visitStmt1R(MONITOR_EXIT,5);
                code.visitLabel(L4);
                code.visitStmt2R(MOVE_OBJECT,5,0);
                code.visitJumpStmt(GOTO,-1,-1,L16);
                code.visitLabel(L21);
                code.visitConstStmt(CONST_4,5, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L16);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_doStart(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/ResourceCache;","doStart",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/Exception;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(228,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(229,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(230,L5);
                ddv.visitLineNumber(231,L1);
                ddv.visitLineNumber(228,L2);
                code.visitLabel(L3);
                code.visitStmt1R(MONITOR_ENTER,1);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/util/HashMap;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/util/HashMap;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/ResourceCache;","_cache","Ljava/util/Map;"));
                code.visitLabel(L4);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT,0,1,new Field("Lorg/mortbay/jetty/ResourceCache;","_cachedSize","I"));
                code.visitLabel(L5);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT,0,1,new Field("Lorg/mortbay/jetty/ResourceCache;","_cachedFiles","I"));
                code.visitLabel(L1);
                code.visitStmt1R(MONITOR_EXIT,1);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,0);
                code.visitStmt1R(MONITOR_EXIT,1);
                code.visitStmt1R(THROW,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_doStop(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/ResourceCache;","doStop",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/InterruptedException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(239,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(240,L1);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/ResourceCache;","flushCache",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_fill(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/ResourceCache;","fill",new String[]{ "Lorg/mortbay/jetty/ResourceCache$Content;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"content");
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(248,L0);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(249,L3);
                ddv.visitStartLocal(1,L3,"in","Ljava/io/InputStream;",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(250,L4);
                ddv.visitStartLocal(2,L4,"len","I",null);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(251,L5);
                ddv.visitStartLocal(0,L5,"buffer","Lorg/mortbay/io/Buffer;",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(252,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(253,L7);
                ddv.visitLineNumber(257,L1);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(259,L8);
                ddv.visitLineNumber(257,L2);
                ddv.visitEndLocal(1,L2);
                ddv.visitEndLocal(2,L2);
                ddv.visitEndLocal(0,L2);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/ResourceCache$Content;","getResource",new String[]{ },"Lorg/mortbay/resource/Resource;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/resource/Resource;","getInputStream",new String[]{ },"Ljava/io/InputStream;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/ResourceCache$Content;","getResource",new String[]{ },"Lorg/mortbay/resource/Resource;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/resource/Resource;","length",new String[]{ },"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,3);
                code.visitStmt2R(LONG_TO_INT,2,3);
                code.visitLabel(L4);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/io/ByteArrayBuffer;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,2},new Method("Lorg/mortbay/io/ByteArrayBuffer;","<init>",new String[]{ "I"},"V"));
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1,2},new Method("Lorg/mortbay/io/Buffer;","readFrom",new String[]{ "Ljava/io/InputStream;","I"},"I"));
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/io/InputStream;","close",new String[]{ },"V"));
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,0},new Method("Lorg/mortbay/jetty/ResourceCache$Content;","setBuffer",new String[]{ "Lorg/mortbay/io/Buffer;"},"V"));
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/ResourceCache$Content;","getResource",new String[]{ },"Lorg/mortbay/resource/Resource;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/resource/Resource;","release",new String[]{ },"V"));
                code.visitLabel(L8);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/ResourceCache$Content;","getResource",new String[]{ },"Lorg/mortbay/resource/Resource;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/resource/Resource;","release",new String[]{ },"V"));
                code.visitStmt1R(THROW,3);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_flushCache(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/ResourceCache;","flushCache",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L5=new DexLabel();
                ddv.visitPrologue(L5);
                ddv.visitLineNumber(119,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(121,L6);
                ddv.visitLineNumber(123,L0);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(124,L7);
                ddv.visitStartLocal(2,L7,"values","Ljava/util/ArrayList;",null);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(125,L8);
                ddv.visitStartLocal(1,L8,"iter","Ljava/util/Iterator;",null);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(127,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(128,L10);
                ddv.visitStartLocal(0,L10,"content","Lorg/mortbay/jetty/ResourceCache$Content;",null);
                ddv.visitLineNumber(136,L2);
                ddv.visitEndLocal(2,L2);
                ddv.visitEndLocal(1,L2);
                ddv.visitEndLocal(0,L2);
                ddv.visitLineNumber(131,L3);
                ddv.visitRestartLocal(1,L3);
                ddv.visitRestartLocal(2,L3);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(132,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(133,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(134,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(135,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(136,L15);
                ddv.visitLineNumber(138,L4);
                ddv.visitEndLocal(1,L4);
                ddv.visitEndLocal(2,L4);
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,3,4,new Field("Lorg/mortbay/jetty/ResourceCache;","_cache","Ljava/util/Map;"));
                code.visitJumpStmt(IF_EQZ,3,-1,L4);
                code.visitLabel(L6);
                code.visitStmt1R(MONITOR_ENTER,4);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Ljava/util/ArrayList;");
                code.visitFieldStmt(IGET_OBJECT,3,4,new Field("Lorg/mortbay/jetty/ResourceCache;","_cache","Ljava/util/Map;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3},new Method("Ljava/util/Map;","values",new String[]{ },"Ljava/util/Collection;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2,3},new Method("Ljava/util/ArrayList;","<init>",new String[]{ "Ljava/util/Collection;"},"V"));
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/util/ArrayList;","iterator",new String[]{ },"Ljava/util/Iterator;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Ljava/util/Iterator;","hasNext",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_EQZ,3,-1,L3);
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Ljava/util/Iterator;","next",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Lorg/mortbay/jetty/ResourceCache$Content;");
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/ResourceCache$Content;","invalidate",new String[]{ },"V"));
                code.visitJumpStmt(GOTO,-1,-1,L8);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,3);
                code.visitStmt1R(MONITOR_EXIT,4);
                code.visitLabel(L1);
                code.visitStmt1R(THROW,3);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,3,4,new Field("Lorg/mortbay/jetty/ResourceCache;","_cache","Ljava/util/Map;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3},new Method("Ljava/util/Map;","clear",new String[]{ },"V"));
                code.visitLabel(L11);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT,3,4,new Field("Lorg/mortbay/jetty/ResourceCache;","_cachedSize","I"));
                code.visitLabel(L12);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT,3,4,new Field("Lorg/mortbay/jetty/ResourceCache;","_cachedFiles","I"));
                code.visitLabel(L13);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_OBJECT,3,4,new Field("Lorg/mortbay/jetty/ResourceCache;","_mostRecentlyUsed","Lorg/mortbay/jetty/ResourceCache$Content;"));
                code.visitLabel(L14);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_OBJECT,3,4,new Field("Lorg/mortbay/jetty/ResourceCache;","_leastRecentlyUsed","Lorg/mortbay/jetty/ResourceCache$Content;"));
                code.visitLabel(L15);
                code.visitStmt1R(MONITOR_EXIT,4);
                code.visitLabel(L4);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m007_getCachedFiles(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/ResourceCache;","getCachedFiles",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(68,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,1,new Field("Lorg/mortbay/jetty/ResourceCache;","_cachedFiles","I"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m008_getCachedSize(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/ResourceCache;","getCachedSize",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(62,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,1,new Field("Lorg/mortbay/jetty/ResourceCache;","_cachedSize","I"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m009_getMaxCacheSize(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/ResourceCache;","getMaxCacheSize",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(88,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,1,new Field("Lorg/mortbay/jetty/ResourceCache;","_maxCacheSize","I"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m010_getMaxCachedFileSize(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/ResourceCache;","getMaxCachedFileSize",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(75,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,1,new Field("Lorg/mortbay/jetty/ResourceCache;","_maxCachedFileSize","I"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m011_getMaxCachedFiles(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/ResourceCache;","getMaxCachedFiles",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(104,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,1,new Field("Lorg/mortbay/jetty/ResourceCache;","_maxCachedFiles","I"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m012_lookup(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/ResourceCache;","lookup",new String[]{ "Ljava/lang/String;","Lorg/mortbay/resource/Resource;"},"Lorg/mortbay/jetty/ResourceCache$Content;"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"pathInContext");
                ddv.visitParameterName(1,"resource");
                DexLabel L5=new DexLabel();
                ddv.visitPrologue(L5);
                ddv.visitLineNumber(172,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(175,L6);
                ddv.visitStartLocal(1,L6,"content","Lorg/mortbay/jetty/ResourceCache$Content;",null);
                ddv.visitLineNumber(178,L0);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(180,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(182,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(185,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(184,L10);
                ddv.visitLineNumber(185,L1);
                ddv.visitLineNumber(184,L2);
                code.visitLabel(L5);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,3,4,new Field("Lorg/mortbay/jetty/ResourceCache;","_cache","Ljava/util/Map;"));
                code.visitStmt1R(MONITOR_ENTER,3);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,2,4,new Field("Lorg/mortbay/jetty/ResourceCache;","_cache","Ljava/util/Map;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2,5},new Method("Ljava/util/Map;","get",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitStmt2R(MOVE_OBJECT,0,2);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Lorg/mortbay/jetty/ResourceCache$Content;");
                code.visitStmt2R(MOVE_OBJECT,1,0);
                code.visitLabel(L7);
                code.visitJumpStmt(IF_EQZ,1,-1,L10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/jetty/ResourceCache$Content;","isValid",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_EQZ,2,-1,L10);
                code.visitLabel(L8);
                code.visitStmt1R(MONITOR_EXIT,3);
                code.visitStmt2R(MOVE_OBJECT,2,1);
                code.visitLabel(L9);
                code.visitStmt1R(RETURN_OBJECT,2);
                code.visitLabel(L10);
                code.visitStmt1R(MONITOR_EXIT,3);
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4,5,6},new Method("Lorg/mortbay/jetty/ResourceCache;","load",new String[]{ "Ljava/lang/String;","Lorg/mortbay/resource/Resource;"},"Lorg/mortbay/jetty/ResourceCache$Content;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitJumpStmt(GOTO,-1,-1,L9);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,2);
                code.visitLabel(L3);
                code.visitStmt1R(MONITOR_EXIT,3);
                code.visitLabel(L4);
                code.visitStmt1R(THROW,2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m013_lookup(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/ResourceCache;","lookup",new String[]{ "Ljava/lang/String;","Lorg/mortbay/resource/ResourceFactory;"},"Lorg/mortbay/jetty/ResourceCache$Content;"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(8);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"pathInContext");
                ddv.visitParameterName(1,"factory");
                DexLabel L5=new DexLabel();
                ddv.visitPrologue(L5);
                ddv.visitLineNumber(152,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(155,L6);
                ddv.visitStartLocal(1,L6,"content","Lorg/mortbay/jetty/ResourceCache$Content;",null);
                ddv.visitLineNumber(158,L0);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(160,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(162,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(166,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(164,L10);
                ddv.visitLineNumber(165,L1);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(166,L11);
                ddv.visitStartLocal(2,L11,"resource","Lorg/mortbay/resource/Resource;",null);
                ddv.visitLineNumber(164,L2);
                ddv.visitEndLocal(2,L2);
                code.visitLabel(L5);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,4,5,new Field("Lorg/mortbay/jetty/ResourceCache;","_cache","Ljava/util/Map;"));
                code.visitStmt1R(MONITOR_ENTER,4);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,3,5,new Field("Lorg/mortbay/jetty/ResourceCache;","_cache","Ljava/util/Map;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3,6},new Method("Ljava/util/Map;","get",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitStmt2R(MOVE_OBJECT,0,3);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Lorg/mortbay/jetty/ResourceCache$Content;");
                code.visitStmt2R(MOVE_OBJECT,1,0);
                code.visitLabel(L7);
                code.visitJumpStmt(IF_EQZ,1,-1,L10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/jetty/ResourceCache$Content;","isValid",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_EQZ,3,-1,L10);
                code.visitLabel(L8);
                code.visitStmt1R(MONITOR_EXIT,4);
                code.visitStmt2R(MOVE_OBJECT,3,1);
                code.visitLabel(L9);
                code.visitStmt1R(RETURN_OBJECT,3);
                code.visitLabel(L10);
                code.visitStmt1R(MONITOR_EXIT,4);
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 7,6},new Method("Lorg/mortbay/resource/ResourceFactory;","getResource",new String[]{ "Ljava/lang/String;"},"Lorg/mortbay/resource/Resource;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L11);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 5,6,2},new Method("Lorg/mortbay/jetty/ResourceCache;","load",new String[]{ "Ljava/lang/String;","Lorg/mortbay/resource/Resource;"},"Lorg/mortbay/jetty/ResourceCache$Content;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitJumpStmt(GOTO,-1,-1,L9);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,3);
                code.visitLabel(L3);
                code.visitStmt1R(MONITOR_EXIT,4);
                code.visitLabel(L4);
                code.visitStmt1R(THROW,3);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m014_setMaxCacheSize(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/ResourceCache;","setMaxCacheSize",new String[]{ "I"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"maxCacheSize");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(94,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(95,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(96,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT,1,0,new Field("Lorg/mortbay/jetty/ResourceCache;","_maxCacheSize","I"));
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/ResourceCache;","flushCache",new String[]{ },"V"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m015_setMaxCachedFileSize(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/ResourceCache;","setMaxCachedFileSize",new String[]{ "I"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"maxCachedFileSize");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(81,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(82,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(83,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT,1,0,new Field("Lorg/mortbay/jetty/ResourceCache;","_maxCachedFileSize","I"));
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/ResourceCache;","flushCache",new String[]{ },"V"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m016_setMaxCachedFiles(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/ResourceCache;","setMaxCachedFiles",new String[]{ "I"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"maxCachedFiles");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(113,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(114,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT,1,0,new Field("Lorg/mortbay/jetty/ResourceCache;","_maxCachedFiles","I"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
