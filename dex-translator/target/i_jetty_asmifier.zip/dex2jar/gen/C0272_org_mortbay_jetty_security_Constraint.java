package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0272_org_mortbay_jetty_security_Constraint {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/jetty/security/Constraint;","Ljava/lang/Object;",new String[]{ "Ljava/lang/Cloneable;","Ljava/io/Serializable;"});
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("Constraint.java");
        f000_ANY_ROLE(cv);
        f001_DC_CONFIDENTIAL(cv);
        f002_DC_INTEGRAL(cv);
        f003_DC_NONE(cv);
        f004_DC_UNSET(cv);
        f005_NONE(cv);
        f006___BASIC_AUTH(cv);
        f007___CERT_AUTH(cv);
        f008___CERT_AUTH2(cv);
        f009___DIGEST_AUTH(cv);
        f010___FORM_AUTH(cv);
        f011__anyRole(cv);
        f012__authenticate(cv);
        f013__dataConstraint(cv);
        f014__name(cv);
        f015__roles(cv);
        m000__init_(cv);
        m001__init_(cv);
        m002_clone(cv);
        m003_getAuthenticate(cv);
        m004_getDataConstraint(cv);
        m005_getRoles(cv);
        m006_hasDataConstraint(cv);
        m007_hasRole(cv);
        m008_isAnyRole(cv);
        m009_isForbidden(cv);
        m010_setAuthenticate(cv);
        m011_setDataConstraint(cv);
        m012_setName(cv);
        m013_setRoles(cv);
        m014_toString(cv);
    }
    public static void f000_ANY_ROLE(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/security/Constraint;","ANY_ROLE","Ljava/lang/String;"), "*");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001_DC_CONFIDENTIAL(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/security/Constraint;","DC_CONFIDENTIAL","I"),  Integer.valueOf(2));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002_DC_INTEGRAL(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/security/Constraint;","DC_INTEGRAL","I"),  Integer.valueOf(1));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003_DC_NONE(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/security/Constraint;","DC_NONE","I"),  Integer.valueOf(0));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f004_DC_UNSET(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/security/Constraint;","DC_UNSET","I"),  Integer.valueOf(-1));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f005_NONE(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/security/Constraint;","NONE","Ljava/lang/String;"), "NONE");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f006___BASIC_AUTH(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/security/Constraint;","__BASIC_AUTH","Ljava/lang/String;"), "BASIC");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f007___CERT_AUTH(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/security/Constraint;","__CERT_AUTH","Ljava/lang/String;"), "CLIENT_CERT");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f008___CERT_AUTH2(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/security/Constraint;","__CERT_AUTH2","Ljava/lang/String;"), "CLIENT-CERT");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f009___DIGEST_AUTH(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/security/Constraint;","__DIGEST_AUTH","Ljava/lang/String;"), "DIGEST");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f010___FORM_AUTH(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/security/Constraint;","__FORM_AUTH","Ljava/lang/String;"), "FORM");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f011__anyRole(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/security/Constraint;","_anyRole","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f012__authenticate(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/security/Constraint;","_authenticate","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f013__dataConstraint(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/security/Constraint;","_dataConstraint","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f014__name(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/security/Constraint;","_name","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f015__roles(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/security/Constraint;","_roles","[Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/security/Constraint;","<init>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(52,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(44,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(45,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(46,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(52,L5);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2},new Method("Ljava/lang/Object;","<init>",new String[]{ },"V"));
                code.visitLabel(L2);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(-1)); // int: 0xffffffff  float:NaN
                code.visitFieldStmt(IPUT,0,2,new Field("Lorg/mortbay/jetty/security/Constraint;","_dataConstraint","I"));
                code.visitLabel(L3);
                code.visitFieldStmt(IPUT_BOOLEAN,1,2,new Field("Lorg/mortbay/jetty/security/Constraint;","_anyRole","Z"));
                code.visitLabel(L4);
                code.visitFieldStmt(IPUT_BOOLEAN,1,2,new Field("Lorg/mortbay/jetty/security/Constraint;","_authenticate","Z"));
                code.visitLabel(L5);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/security/Constraint;","<init>",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                ddv.visitParameterName(1,"role");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(60,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(44,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(45,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(46,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(61,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(62,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(63,L7);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2},new Method("Ljava/lang/Object;","<init>",new String[]{ },"V"));
                code.visitLabel(L2);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(-1)); // int: 0xffffffff  float:NaN
                code.visitFieldStmt(IPUT,0,2,new Field("Lorg/mortbay/jetty/security/Constraint;","_dataConstraint","I"));
                code.visitLabel(L3);
                code.visitFieldStmt(IPUT_BOOLEAN,1,2,new Field("Lorg/mortbay/jetty/security/Constraint;","_anyRole","Z"));
                code.visitLabel(L4);
                code.visitFieldStmt(IPUT_BOOLEAN,1,2,new Field("Lorg/mortbay/jetty/security/Constraint;","_authenticate","Z"));
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Lorg/mortbay/jetty/security/Constraint;","setName",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L6);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitTypeStmt(NEW_ARRAY,0,0,"[Ljava/lang/String;");
                code.visitStmt3R(APUT_OBJECT,4,0,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,0},new Method("Lorg/mortbay/jetty/security/Constraint;","setRoles",new String[]{ "[Ljava/lang/String;"},"V"));
                code.visitLabel(L7);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_clone(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/Constraint;","clone",new String[]{ },"Ljava/lang/Object;"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/CloneNotSupportedException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(68,L0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 1},new Method("Ljava/lang/Object;","clone",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_getAuthenticate(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/Constraint;","getAuthenticate",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(139,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_BOOLEAN,0,1,new Field("Lorg/mortbay/jetty/security/Constraint;","_authenticate","Z"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_getDataConstraint(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/Constraint;","getDataConstraint",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(168,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,1,new Field("Lorg/mortbay/jetty/security/Constraint;","_dataConstraint","I"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_getRoles(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/Constraint;","getRoles",new String[]{ },"[Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(105,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/security/Constraint;","_roles","[Ljava/lang/String;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_hasDataConstraint(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/Constraint;","hasDataConstraint",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(177,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,1,new Field("Lorg/mortbay/jetty/security/Constraint;","_dataConstraint","I"));
                DexLabel L1=new DexLabel();
                code.visitJumpStmt(IF_LTZ,0,-1,L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                DexLabel L2=new DexLabel();
                code.visitLabel(L2);
                code.visitStmt1R(RETURN,0);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m007_hasRole(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/Constraint;","hasRole",new String[]{ "Ljava/lang/String;"},"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"role");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(115,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(121,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(117,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(118,L4);
                DexLabel L5=new DexLabel();
                ddv.visitStartLocal(0,L5,"i","I",null);
                DexLabel L6=new DexLabel();
                ddv.visitEndLocal(0,L6);
                ddv.visitStartLocal(1,L6,"i","I",null);
                DexLabel L7=new DexLabel();
                ddv.visitRestartLocal(0,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(119,L8);
                ddv.visitEndLocal(1,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(120,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(121,L10);
                ddv.visitEndLocal(0,L10);
                DexLabel L11=new DexLabel();
                ddv.visitRestartLocal(0,L11);
                DexLabel L12=new DexLabel();
                ddv.visitRestartLocal(1,L12);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_BOOLEAN,2,4,new Field("Lorg/mortbay/jetty/security/Constraint;","_anyRole","Z"));
                code.visitJumpStmt(IF_EQZ,2,-1,L3);
                code.visitStmt2R(MOVE,2,3);
                code.visitLabel(L2);
                code.visitStmt1R(RETURN,2);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,2,4,new Field("Lorg/mortbay/jetty/security/Constraint;","_roles","[Ljava/lang/String;"));
                code.visitJumpStmt(IF_EQZ,2,-1,L10);
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,2,4,new Field("Lorg/mortbay/jetty/security/Constraint;","_roles","[Ljava/lang/String;"));
                code.visitStmt2R(ARRAY_LENGTH,0,2);
                code.visitLabel(L5);
                code.visitStmt2R(MOVE,1,0);
                code.visitLabel(L6);
                code.visitStmt3R(SUB_INT,0,1,3);
                code.visitLabel(L7);
                code.visitJumpStmt(IF_LEZ,1,-1,L10);
                code.visitLabel(L8);
                code.visitFieldStmt(IGET_OBJECT,2,4,new Field("Lorg/mortbay/jetty/security/Constraint;","_roles","[Ljava/lang/String;"));
                code.visitStmt3R(AGET_OBJECT,2,2,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,2},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_EQZ,2,-1,L11);
                code.visitStmt2R(MOVE,2,3);
                code.visitLabel(L9);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L10);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L11);
                code.visitStmt2R(MOVE,1,0);
                code.visitLabel(L12);
                code.visitJumpStmt(GOTO,-1,-1,L6);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m008_isAnyRole(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/Constraint;","isAnyRole",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(96,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_BOOLEAN,0,1,new Field("Lorg/mortbay/jetty/security/Constraint;","_anyRole","Z"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m009_isForbidden(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/Constraint;","isForbidden",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(148,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_BOOLEAN,0,1,new Field("Lorg/mortbay/jetty/security/Constraint;","_authenticate","Z"));
                DexLabel L1=new DexLabel();
                code.visitJumpStmt(IF_EQZ,0,-1,L1);
                code.visitFieldStmt(IGET_BOOLEAN,0,1,new Field("Lorg/mortbay/jetty/security/Constraint;","_anyRole","Z"));
                code.visitJumpStmt(IF_NEZ,0,-1,L1);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/security/Constraint;","_roles","[Ljava/lang/String;"));
                DexLabel L2=new DexLabel();
                code.visitJumpStmt(IF_EQZ,0,-1,L2);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/security/Constraint;","_roles","[Ljava/lang/String;"));
                code.visitStmt2R(ARRAY_LENGTH,0,0);
                code.visitJumpStmt(IF_NEZ,0,-1,L1);
                code.visitLabel(L2);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                DexLabel L3=new DexLabel();
                code.visitLabel(L3);
                code.visitStmt1R(RETURN,0);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m010_setAuthenticate(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/Constraint;","setAuthenticate",new String[]{ "Z"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"authenticate");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(130,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(131,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_BOOLEAN,1,0,new Field("Lorg/mortbay/jetty/security/Constraint;","_authenticate","Z"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m011_setDataConstraint(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/Constraint;","setDataConstraint",new String[]{ "I"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"c");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(157,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(158,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(159,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(160,L3);
                code.visitLabel(L0);
                code.visitJumpStmt(IF_LTZ,3,-1,L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitJumpStmt(IF_LE,3,0,L2);
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/IllegalArgumentException;");
                code.visitConstStmt(CONST_STRING,1,"Constraint out of range");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Ljava/lang/IllegalArgumentException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,0);
                code.visitLabel(L2);
                code.visitFieldStmt(IPUT,3,2,new Field("Lorg/mortbay/jetty/security/Constraint;","_dataConstraint","I"));
                code.visitLabel(L3);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m012_setName(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/Constraint;","setName",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(77,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(78,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/security/Constraint;","_name","Ljava/lang/String;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m013_setRoles(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/Constraint;","setRoles",new String[]{ "[Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"roles");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(83,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(84,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(85,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(86,L3);
                DexLabel L4=new DexLabel();
                ddv.visitStartLocal(0,L4,"i","I",null);
                DexLabel L5=new DexLabel();
                ddv.visitStartLocal(1,L5,"i","I",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(87,L6);
                ddv.visitEndLocal(0,L6);
                DexLabel L7=new DexLabel();
                ddv.visitRestartLocal(0,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(88,L8);
                ddv.visitEndLocal(1,L8);
                ddv.visitEndLocal(0,L8);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,5,4,new Field("Lorg/mortbay/jetty/security/Constraint;","_roles","[Ljava/lang/String;"));
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_BOOLEAN,2,4,new Field("Lorg/mortbay/jetty/security/Constraint;","_anyRole","Z"));
                code.visitLabel(L2);
                code.visitJumpStmt(IF_EQZ,5,-1,L8);
                code.visitLabel(L3);
                code.visitStmt2R(ARRAY_LENGTH,0,5);
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_BOOLEAN,2,4,new Field("Lorg/mortbay/jetty/security/Constraint;","_anyRole","Z"));
                code.visitJumpStmt(IF_NEZ,2,-1,L8);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt3R(SUB_INT,1,0,2);
                code.visitLabel(L5);
                code.visitJumpStmt(IF_LEZ,0,-1,L8);
                code.visitLabel(L6);
                code.visitConstStmt(CONST_STRING,2,"*");
                code.visitStmt3R(AGET_OBJECT,3,5,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitFieldStmt(IPUT_BOOLEAN,2,4,new Field("Lorg/mortbay/jetty/security/Constraint;","_anyRole","Z"));
                code.visitStmt2R(MOVE,0,1);
                code.visitLabel(L7);
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitLabel(L8);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m014_toString(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/Constraint;","toString",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(183,L1);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_STRING,2,",");
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,1,"SC{");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/jetty/security/Constraint;","_name","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitConstStmt(CONST_STRING,1,",");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IGET_BOOLEAN,1,3,new Field("Lorg/mortbay/jetty/security/Constraint;","_anyRole","Z"));
                DexLabel L2=new DexLabel();
                code.visitJumpStmt(IF_EQZ,1,-1,L2);
                code.visitConstStmt(CONST_STRING,1,"*");
                DexLabel L3=new DexLabel();
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitConstStmt(CONST_STRING,1,",");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IGET,1,3,new Field("Lorg/mortbay/jetty/security/Constraint;","_dataConstraint","I"));
                code.visitConstStmt(CONST_4,2, Integer.valueOf(-1)); // int: 0xffffffff  float:NaN
                DexLabel L4=new DexLabel();
                code.visitJumpStmt(IF_NE,1,2,L4);
                code.visitConstStmt(CONST_STRING,1,"DC_UNSET}");
                DexLabel L5=new DexLabel();
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/jetty/security/Constraint;","_roles","[Ljava/lang/String;"));
                DexLabel L6=new DexLabel();
                code.visitJumpStmt(IF_NEZ,1,-1,L6);
                code.visitConstStmt(CONST_STRING,1,"-");
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/jetty/security/Constraint;","_roles","[Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/lang/Object;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitLabel(L4);
                code.visitFieldStmt(IGET,1,3,new Field("Lorg/mortbay/jetty/security/Constraint;","_dataConstraint","I"));
                DexLabel L7=new DexLabel();
                code.visitJumpStmt(IF_NEZ,1,-1,L7);
                code.visitConstStmt(CONST_STRING,1,"NONE}");
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitLabel(L7);
                code.visitFieldStmt(IGET,1,3,new Field("Lorg/mortbay/jetty/security/Constraint;","_dataConstraint","I"));
                code.visitConstStmt(CONST_4,2, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                DexLabel L8=new DexLabel();
                code.visitJumpStmt(IF_NE,1,2,L8);
                code.visitConstStmt(CONST_STRING,1,"INTEGRAL}");
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitLabel(L8);
                code.visitConstStmt(CONST_STRING,1,"CONFIDENTIAL}");
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
