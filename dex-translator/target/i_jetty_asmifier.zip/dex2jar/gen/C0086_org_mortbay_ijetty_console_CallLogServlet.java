package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0086_org_mortbay_ijetty_console_CallLogServlet {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/ijetty/console/CallLogServlet;","Ljavax/servlet/http/HttpServlet;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("CallLogServlet.java");
        f000___ACKNOWLEDGED(cv);
        f001___CSV_DELIM(cv);
        f002___DURATION(cv);
        f003___INCOMING(cv);
        f004___MISSED(cv);
        f005___NO(cv);
        f006___OUTGOING(cv);
        f007___YES(cv);
        f008__logTypeMap(cv);
        f009_resolver(cv);
        m000__init_(cv);
        m001_formatCSV(cv);
        m002_formatCallLog(cv);
        m003_printCSV(cv);
        m004_doContent(cv);
        m005_doGet(cv);
        m006_getContentResolver(cv);
        m007_init(cv);
    }
    public static void f000___ACKNOWLEDGED(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/ijetty/console/CallLogServlet;","__ACKNOWLEDGED","Ljava/lang/String;"), "Acknowledged");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001___CSV_DELIM(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/ijetty/console/CallLogServlet;","__CSV_DELIM","Ljava/lang/String;"), ",");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002___DURATION(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/ijetty/console/CallLogServlet;","__DURATION","Ljava/lang/String;"), "Duration (secs)");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003___INCOMING(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/ijetty/console/CallLogServlet;","__INCOMING","Ljava/lang/String;"), "incoming");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f004___MISSED(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/ijetty/console/CallLogServlet;","__MISSED","Ljava/lang/String;"), "missed");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f005___NO(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/ijetty/console/CallLogServlet;","__NO","Ljava/lang/String;"), "no");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f006___OUTGOING(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/ijetty/console/CallLogServlet;","__OUTGOING","Ljava/lang/String;"), "outgoing");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f007___YES(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/ijetty/console/CallLogServlet;","__YES","Ljava/lang/String;"), "yes");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f008__logTypeMap(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC, new Field("Lorg/mortbay/ijetty/console/CallLogServlet;","_logTypeMap","Ljava/util/Map;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f009_resolver(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/ijetty/console/CallLogServlet;","resolver","Landroid/content/ContentResolver;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/ijetty/console/CallLogServlet;","<init>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(54,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(49,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(55,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(56,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(57,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(58,L5);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3},new Method("Ljavax/servlet/http/HttpServlet;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/util/HashMap;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/util/HashMap;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,3,new Field("Lorg/mortbay/ijetty/console/CallLogServlet;","_logTypeMap","Ljava/util/Map;"));
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/ijetty/console/CallLogServlet;","_logTypeMap","Ljava/util/Map;"));
                code.visitConstStmt(CONST_4,1, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1},new Method("Ljava/lang/Integer;","valueOf",new String[]{ "I"},"Ljava/lang/Integer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitConstStmt(CONST_STRING,2,"incoming");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1,2},new Method("Ljava/util/Map;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/ijetty/console/CallLogServlet;","_logTypeMap","Ljava/util/Map;"));
                code.visitConstStmt(CONST_4,1, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1},new Method("Ljava/lang/Integer;","valueOf",new String[]{ "I"},"Ljava/lang/Integer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitConstStmt(CONST_STRING,2,"outgoing");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1,2},new Method("Ljava/util/Map;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/ijetty/console/CallLogServlet;","_logTypeMap","Ljava/util/Map;"));
                code.visitConstStmt(CONST_4,1, Integer.valueOf(3)); // int: 0x00000003  float:0.000000
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1},new Method("Ljava/lang/Integer;","valueOf",new String[]{ "I"},"Ljava/lang/Integer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitConstStmt(CONST_STRING,2,"missed");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1,2},new Method("Ljava/util/Map;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L5);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001_formatCSV(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PRIVATE, new Method("Lorg/mortbay/ijetty/console/CallLogServlet;","formatCSV",new String[]{ "[Ljava/lang/String;","Landroid/database/Cursor;","Ljava/io/PrintWriter;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(16);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"colNames");
                ddv.visitParameterName(1,"cursor");
                ddv.visitParameterName(2,"writer");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(199,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(201,L2);
                DexLabel L3=new DexLabel();
                ddv.visitStartLocal(1,L3,"i","I",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(203,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(207,L5);
                ddv.visitStartLocal(0,L5,"cname","Ljava/lang/String;",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(212,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(213,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(201,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(216,L9);
                ddv.visitEndLocal(0,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(217,L10);
                ddv.visitStartLocal(3,L10,"row","I",null);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(219,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(220,L12);
                ddv.visitStartLocal(4,L12,"style","Ljava/lang/String;",null);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(222,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(223,L14);
                ddv.visitStartLocal(5,L14,"val","Ljava/lang/String;",null);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(225,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(220,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(227,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(229,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(230,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(232,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(234,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(236,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(238,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(240,L24);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(241,L25);
                ddv.visitStartLocal(2,L25,"name","Ljava/lang/String;",null);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(242,L26);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(245,L27);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(248,L28);
                ddv.visitEndLocal(2,L28);
                DexLabel L29=new DexLabel();
                ddv.visitLineNumber(250,L29);
                ddv.visitEndLocal(5,L29);
                DexLabel L30=new DexLabel();
                ddv.visitLineNumber(251,L30);
                DexLabel L31=new DexLabel();
                ddv.visitLineNumber(253,L31);
                ddv.visitEndLocal(1,L31);
                ddv.visitEndLocal(3,L31);
                ddv.visitEndLocal(4,L31);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_STRING,11,"name");
                code.visitConstStmt(CONST_STRING,10,",");
                code.visitConstStmt(CONST_STRING,9,"\"");
                code.visitLabel(L1);
                code.visitJumpStmt(IF_EQZ,13,-1,L31);
                code.visitJumpStmt(IF_EQZ,14,-1,L31);
                code.visitJumpStmt(IF_EQZ,15,-1,L31);
                code.visitLabel(L2);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L3);
                code.visitStmt2R(ARRAY_LENGTH,6,13);
                code.visitJumpStmt(IF_GE,1,6,L9);
                code.visitLabel(L4);
                code.visitStmt3R(AGET_OBJECT,0,13,1);
                code.visitLabel(L5);
                code.visitStmt2R(ARRAY_LENGTH,6,13);
                code.visitStmt2R1N(ADD_INT_LIT8,6,6,1);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 12,1,6,15,0},new Method("Lorg/mortbay/ijetty/console/CallLogServlet;","printCSV",new String[]{ "I","I","Ljava/io/PrintWriter;","Ljava/lang/String;"},"V"));
                code.visitLabel(L6);
                code.visitStmt3R(AGET_OBJECT,6,13,1);
                code.visitConstStmt(CONST_STRING,7,"name");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,11},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitJumpStmt(IF_EQZ,6,-1,L8);
                code.visitLabel(L7);
                code.visitStmt2R1N(ADD_INT_LIT8,6,1,1);
                code.visitStmt2R(ARRAY_LENGTH,7,13);
                code.visitStmt2R1N(ADD_INT_LIT8,7,7,1);
                code.visitConstStmt(CONST_STRING,8,"contactid");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 12,6,7,15,8},new Method("Lorg/mortbay/ijetty/console/CallLogServlet;","printCSV",new String[]{ "I","I","Ljava/io/PrintWriter;","Ljava/lang/String;"},"V"));
                code.visitLabel(L8);
                code.visitStmt2R1N(ADD_INT_LIT8,1,1,1);
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitLabel(L9);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 14},new Method("Landroid/database/Cursor;","moveToNext",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitJumpStmt(IF_EQZ,6,-1,L31);
                code.visitLabel(L11);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3},new Method("Lorg/mortbay/ijetty/console/HTMLHelper;","getRowStyle",new String[]{ "I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitLabel(L12);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                DexLabel L32=new DexLabel();
                code.visitLabel(L32);
                code.visitStmt2R(ARRAY_LENGTH,6,13);
                code.visitJumpStmt(IF_GE,1,6,L29);
                code.visitLabel(L13);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 14,1},new Method("Landroid/database/Cursor;","getString",new String[]{ "I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitLabel(L14);
                code.visitStmt3R(AGET_OBJECT,6,13,1);
                code.visitConstStmt(CONST_STRING,7,"date");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,7},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitJumpStmt(IF_EQZ,6,-1,L17);
                code.visitLabel(L15);
                code.visitStmt2R(ARRAY_LENGTH,6,13);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 12,1,6,15,5},new Method("Lorg/mortbay/ijetty/console/CallLogServlet;","printCSV",new String[]{ "I","I","Ljava/io/PrintWriter;","Ljava/lang/String;"},"V"));
                code.visitLabel(L16);
                code.visitStmt2R1N(ADD_INT_LIT8,1,1,1);
                code.visitJumpStmt(GOTO,-1,-1,L32);
                code.visitLabel(L17);
                code.visitStmt3R(AGET_OBJECT,6,13,1);
                code.visitConstStmt(CONST_STRING,7,"new");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,7},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitJumpStmt(IF_EQZ,6,-1,L21);
                code.visitLabel(L18);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 14,1},new Method("Landroid/database/Cursor;","getInt",new String[]{ "I"},"I"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitJumpStmt(IF_LEZ,6,-1,L20);
                code.visitLabel(L19);
                code.visitStmt2R(ARRAY_LENGTH,6,13);
                code.visitConstStmt(CONST_STRING,7,"yes");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 12,1,6,15,7},new Method("Lorg/mortbay/ijetty/console/CallLogServlet;","printCSV",new String[]{ "I","I","Ljava/io/PrintWriter;","Ljava/lang/String;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L16);
                code.visitLabel(L20);
                code.visitStmt2R(ARRAY_LENGTH,6,13);
                code.visitConstStmt(CONST_STRING,7,"no");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 12,1,6,15,7},new Method("Lorg/mortbay/ijetty/console/CallLogServlet;","printCSV",new String[]{ "I","I","Ljava/io/PrintWriter;","Ljava/lang/String;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L16);
                code.visitLabel(L21);
                code.visitStmt3R(AGET_OBJECT,6,13,1);
                code.visitConstStmt(CONST_STRING,7,"type");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,7},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitJumpStmt(IF_EQZ,6,-1,L23);
                code.visitLabel(L22);
                code.visitStmt2R(ARRAY_LENGTH,6,13);
                code.visitFieldStmt(IGET_OBJECT,7,12,new Field("Lorg/mortbay/ijetty/console/CallLogServlet;","_logTypeMap","Ljava/util/Map;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 14,1},new Method("Landroid/database/Cursor;","getInt",new String[]{ "I"},"I"));
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 8},new Method("Ljava/lang/Integer;","valueOf",new String[]{ "I"},"Ljava/lang/Integer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 7,8},new Method("Ljava/util/Map;","get",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Ljava/lang/Object;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 12,1,6,15,7},new Method("Lorg/mortbay/ijetty/console/CallLogServlet;","printCSV",new String[]{ "I","I","Ljava/io/PrintWriter;","Ljava/lang/String;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L16);
                code.visitLabel(L23);
                code.visitStmt3R(AGET_OBJECT,6,13,1);
                code.visitConstStmt(CONST_STRING,7,"name");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,11},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitJumpStmt(IF_EQZ,6,-1,L28);
                code.visitLabel(L24);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 14,1},new Method("Landroid/database/Cursor;","getString",new String[]{ "I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L25);
                code.visitJumpStmt(IF_EQZ,2,-1,L27);
                code.visitLabel(L26);
                code.visitStmt2R(ARRAY_LENGTH,6,13);
                code.visitTypeStmt(NEW_INSTANCE,7,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 7},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,8,"\"");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,9},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitConstStmt(CONST_STRING,8,"\"");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,9},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitConstStmt(CONST_STRING,8,",");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,10},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "I"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 12,1,6,15,7},new Method("Lorg/mortbay/ijetty/console/CallLogServlet;","printCSV",new String[]{ "I","I","Ljava/io/PrintWriter;","Ljava/lang/String;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L16);
                code.visitLabel(L27);
                code.visitStmt2R(ARRAY_LENGTH,6,13);
                code.visitConstStmt(CONST_STRING,7,",");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 12,1,6,15,10},new Method("Lorg/mortbay/ijetty/console/CallLogServlet;","printCSV",new String[]{ "I","I","Ljava/io/PrintWriter;","Ljava/lang/String;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L16);
                code.visitLabel(L28);
                code.visitStmt2R(ARRAY_LENGTH,6,13);
                DexLabel L33=new DexLabel();
                code.visitJumpStmt(IF_NEZ,5,-1,L33);
                code.visitConstStmt(CONST_STRING,7,"");
                DexLabel L34=new DexLabel();
                code.visitLabel(L34);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 12,1,6,15,7},new Method("Lorg/mortbay/ijetty/console/CallLogServlet;","printCSV",new String[]{ "I","I","Ljava/io/PrintWriter;","Ljava/lang/String;"},"V"));
                code.visitJumpStmt(GOTO_16,-1,-1,L16);
                code.visitLabel(L33);
                code.visitStmt2R(MOVE_OBJECT,7,5);
                code.visitJumpStmt(GOTO,-1,-1,L34);
                code.visitLabel(L29);
                code.visitStmt2R1N(ADD_INT_LIT8,3,3,1);
                code.visitLabel(L30);
                code.visitJumpStmt(GOTO_16,-1,-1,L10);
                code.visitLabel(L31);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_formatCallLog(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PRIVATE, new Method("Lorg/mortbay/ijetty/console/CallLogServlet;","formatCallLog",new String[]{ "[Ljava/lang/String;","Landroid/database/Cursor;","Ljava/io/PrintWriter;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(15);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"colNames");
                ddv.visitParameterName(1,"cursor");
                ddv.visitParameterName(2,"writer");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(130,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(132,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(133,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(134,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(136,L4);
                DexLabel L5=new DexLabel();
                ddv.visitStartLocal(2,L5,"i","I",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(138,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(140,L7);
                ddv.visitStartLocal(0,L7,"cname","Ljava/lang/String;",null);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(141,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(147,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(136,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(142,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(143,L12);
                DexLabel L13=new DexLabel();
                ddv.visitRestartLocal(0,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(145,L14);
                DexLabel L15=new DexLabel();
                ddv.visitRestartLocal(0,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(149,L16);
                ddv.visitEndLocal(0,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(150,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(151,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(152,L19);
                ddv.visitStartLocal(4,L19,"row","I",null);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(154,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(155,L21);
                ddv.visitStartLocal(5,L21,"style","Ljava/lang/String;",null);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(156,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(158,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(159,L24);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(160,L25);
                ddv.visitStartLocal(6,L25,"val","Ljava/lang/String;",null);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(162,L26);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(163,L27);
                ddv.visitStartLocal(1,L27,"date","Ljava/lang/String;",null);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(186,L28);
                ddv.visitEndLocal(1,L28);
                DexLabel L29=new DexLabel();
                ddv.visitLineNumber(156,L29);
                DexLabel L30=new DexLabel();
                ddv.visitLineNumber(165,L30);
                DexLabel L31=new DexLabel();
                ddv.visitLineNumber(167,L31);
                DexLabel L32=new DexLabel();
                ddv.visitLineNumber(168,L32);
                DexLabel L33=new DexLabel();
                ddv.visitLineNumber(170,L33);
                DexLabel L34=new DexLabel();
                ddv.visitLineNumber(172,L34);
                DexLabel L35=new DexLabel();
                ddv.visitLineNumber(174,L35);
                DexLabel L36=new DexLabel();
                ddv.visitLineNumber(176,L36);
                DexLabel L37=new DexLabel();
                ddv.visitLineNumber(178,L37);
                DexLabel L38=new DexLabel();
                ddv.visitLineNumber(179,L38);
                ddv.visitStartLocal(3,L38,"name","Ljava/lang/String;",null);
                DexLabel L39=new DexLabel();
                ddv.visitLineNumber(180,L39);
                DexLabel L40=new DexLabel();
                ddv.visitLineNumber(182,L40);
                DexLabel L41=new DexLabel();
                ddv.visitLineNumber(185,L41);
                ddv.visitEndLocal(3,L41);
                DexLabel L42=new DexLabel();
                ddv.visitLineNumber(188,L42);
                ddv.visitEndLocal(6,L42);
                DexLabel L43=new DexLabel();
                ddv.visitLineNumber(189,L43);
                DexLabel L44=new DexLabel();
                ddv.visitLineNumber(190,L44);
                DexLabel L45=new DexLabel();
                ddv.visitLineNumber(191,L45);
                ddv.visitEndLocal(5,L45);
                DexLabel L46=new DexLabel();
                ddv.visitLineNumber(192,L46);
                DexLabel L47=new DexLabel();
                ddv.visitLineNumber(195,L47);
                ddv.visitEndLocal(2,L47);
                ddv.visitEndLocal(4,L47);
                code.visitLabel(L0);
                code.visitJumpStmt(IF_EQZ,12,-1,L47);
                code.visitJumpStmt(IF_EQZ,13,-1,L47);
                code.visitJumpStmt(IF_EQZ,14,-1,L47);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_STRING,7,"<table>");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 14,7},new Method("Ljava/io/PrintWriter;","println",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L2);
                code.visitConstStmt(CONST_STRING,7,"<thead>");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 14,7},new Method("Ljava/io/PrintWriter;","println",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L3);
                code.visitConstStmt(CONST_STRING,7,"<tr>");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 14,7},new Method("Ljava/io/PrintWriter;","println",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L4);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L5);
                code.visitStmt2R(ARRAY_LENGTH,7,12);
                code.visitJumpStmt(IF_GE,2,7,L16);
                code.visitLabel(L6);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L7);
                code.visitStmt3R(AGET_OBJECT,7,12,2);
                code.visitConstStmt(CONST_STRING,8,"new");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,8},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitJumpStmt(IF_EQZ,7,-1,L11);
                code.visitLabel(L8);
                code.visitConstStmt(CONST_STRING,0,"Acknowledged");
                code.visitLabel(L9);
                code.visitTypeStmt(NEW_INSTANCE,7,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 7},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,8,"<th>");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,8},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,0},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitConstStmt(CONST_STRING,8,"</th>");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,8},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 14,7},new Method("Ljava/io/PrintWriter;","println",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L10);
                code.visitStmt2R1N(ADD_INT_LIT8,2,2,1);
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitLabel(L11);
                code.visitStmt3R(AGET_OBJECT,7,12,2);
                code.visitConstStmt(CONST_STRING,8,"duration");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,8},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitJumpStmt(IF_EQZ,7,-1,L14);
                code.visitLabel(L12);
                code.visitConstStmt(CONST_STRING,0,"Duration (secs)");
                code.visitLabel(L13);
                code.visitJumpStmt(GOTO,-1,-1,L9);
                code.visitLabel(L14);
                code.visitStmt3R(AGET_OBJECT,0,12,2);
                code.visitLabel(L15);
                code.visitJumpStmt(GOTO,-1,-1,L9);
                code.visitLabel(L16);
                code.visitConstStmt(CONST_STRING,7,"</tr>");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 14,7},new Method("Ljava/io/PrintWriter;","println",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L17);
                code.visitConstStmt(CONST_STRING,7,"</thead><tbody>");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 14,7},new Method("Ljava/io/PrintWriter;","println",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L18);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L19);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 13},new Method("Landroid/database/Cursor;","moveToNext",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitJumpStmt(IF_EQZ,7,-1,L45);
                code.visitLabel(L20);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 4},new Method("Lorg/mortbay/ijetty/console/HTMLHelper;","getRowStyle",new String[]{ "I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitLabel(L21);
                code.visitConstStmt(CONST_STRING,7,"<tr>");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 14,7},new Method("Ljava/io/PrintWriter;","println",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L22);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                DexLabel L48=new DexLabel();
                code.visitLabel(L48);
                code.visitStmt2R(ARRAY_LENGTH,7,12);
                code.visitJumpStmt(IF_GE,2,7,L42);
                code.visitLabel(L23);
                code.visitTypeStmt(NEW_INSTANCE,7,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 7},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,8,"<td");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,8},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitConstStmt(CONST_STRING,8,">");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,8},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 14,7},new Method("Ljava/io/PrintWriter;","println",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L24);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 13,2},new Method("Landroid/database/Cursor;","getString",new String[]{ "I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitLabel(L25);
                code.visitStmt3R(AGET_OBJECT,7,12,2);
                code.visitConstStmt(CONST_STRING,8,"date");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,8},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitJumpStmt(IF_EQZ,7,-1,L30);
                code.visitLabel(L26);
                code.visitTypeStmt(NEW_INSTANCE,7,-1,"Ljava/text/SimpleDateFormat;");
                code.visitConstStmt(CONST_STRING,8,"dd/MM/yyyy HH:mm:ss");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 7,8},new Method("Ljava/text/SimpleDateFormat;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitTypeStmt(NEW_INSTANCE,8,-1,"Ljava/util/Date;");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 13,2},new Method("Landroid/database/Cursor;","getInt",new String[]{ "I"},"I"));
                code.visitStmt1R(MOVE_RESULT,9);
                code.visitStmt2R1N(MUL_INT_LIT16,9,9,1000);
                code.visitStmt2R(INT_TO_LONG,9,9);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 8,9,10},new Method("Ljava/util/Date;","<init>",new String[]{ "J"},"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,8},new Method("Ljava/text/SimpleDateFormat;","format",new String[]{ "Ljava/util/Date;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L27);
                code.visitTypeStmt(NEW_INSTANCE,7,-1,"Ljava/util/Date;");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 13,2},new Method("Landroid/database/Cursor;","getInt",new String[]{ "I"},"I"));
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitStmt2R(INT_TO_LONG,8,8);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 7,8,9},new Method("Ljava/util/Date;","<init>",new String[]{ "J"},"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Ljava/util/Date;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 14,7},new Method("Ljava/io/PrintWriter;","println",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L28);
                code.visitConstStmt(CONST_STRING,7,"</td>");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 14,7},new Method("Ljava/io/PrintWriter;","println",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L29);
                code.visitStmt2R1N(ADD_INT_LIT8,2,2,1);
                code.visitJumpStmt(GOTO,-1,-1,L48);
                code.visitLabel(L30);
                code.visitStmt3R(AGET_OBJECT,7,12,2);
                code.visitConstStmt(CONST_STRING,8,"new");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,8},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitJumpStmt(IF_EQZ,7,-1,L34);
                code.visitLabel(L31);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 13,2},new Method("Landroid/database/Cursor;","getInt",new String[]{ "I"},"I"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitJumpStmt(IF_LEZ,7,-1,L33);
                code.visitLabel(L32);
                code.visitConstStmt(CONST_STRING,7,"yes");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 14,7},new Method("Ljava/io/PrintWriter;","println",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L28);
                code.visitLabel(L33);
                code.visitConstStmt(CONST_STRING,7,"no");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 14,7},new Method("Ljava/io/PrintWriter;","println",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L28);
                code.visitLabel(L34);
                code.visitStmt3R(AGET_OBJECT,7,12,2);
                code.visitConstStmt(CONST_STRING,8,"type");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,8},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitJumpStmt(IF_EQZ,7,-1,L36);
                code.visitLabel(L35);
                code.visitFieldStmt(IGET_OBJECT,7,11,new Field("Lorg/mortbay/ijetty/console/CallLogServlet;","_logTypeMap","Ljava/util/Map;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 13,2},new Method("Landroid/database/Cursor;","getInt",new String[]{ "I"},"I"));
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 8},new Method("Ljava/lang/Integer;","valueOf",new String[]{ "I"},"Ljava/lang/Integer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 7,8},new Method("Ljava/util/Map;","get",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 14,7},new Method("Ljava/io/PrintWriter;","println",new String[]{ "Ljava/lang/Object;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L28);
                code.visitLabel(L36);
                code.visitStmt3R(AGET_OBJECT,7,12,2);
                code.visitConstStmt(CONST_STRING,8,"name");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,8},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitJumpStmt(IF_EQZ,7,-1,L41);
                code.visitLabel(L37);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 13,2},new Method("Landroid/database/Cursor;","getString",new String[]{ "I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitLabel(L38);
                code.visitJumpStmt(IF_EQZ,3,-1,L40);
                code.visitLabel(L39);
                DexLabel L49=new DexLabel();
                code.visitJumpStmt(IF_NEZ,3,-1,L49);
                code.visitConstStmt(CONST_STRING,7,"&nbsp;");
                DexLabel L50=new DexLabel();
                code.visitLabel(L50);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 14,7},new Method("Ljava/io/PrintWriter;","println",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L28);
                code.visitLabel(L49);
                code.visitTypeStmt(NEW_INSTANCE,7,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 7},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,8,"<a href=\'/console/contacts/\'>");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,8},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitConstStmt(CONST_STRING,8,"</a>");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,8},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitJumpStmt(GOTO,-1,-1,L50);
                code.visitLabel(L40);
                code.visitConstStmt(CONST_STRING,7,"&nbsp;");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 14,7},new Method("Ljava/io/PrintWriter;","println",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L28);
                code.visitLabel(L41);
                DexLabel L51=new DexLabel();
                code.visitJumpStmt(IF_NEZ,6,-1,L51);
                code.visitConstStmt(CONST_STRING,7,"&nbsp;");
                DexLabel L52=new DexLabel();
                code.visitLabel(L52);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 14,7},new Method("Ljava/io/PrintWriter;","println",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L28);
                code.visitLabel(L51);
                code.visitStmt2R(MOVE_OBJECT,7,6);
                code.visitJumpStmt(GOTO,-1,-1,L52);
                code.visitLabel(L42);
                code.visitConstStmt(CONST_STRING,7,"</tr>");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 14,7},new Method("Ljava/io/PrintWriter;","println",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L43);
                code.visitStmt2R1N(ADD_INT_LIT8,4,4,1);
                code.visitLabel(L44);
                code.visitJumpStmt(GOTO_16,-1,-1,L19);
                code.visitLabel(L45);
                code.visitConstStmt(CONST_STRING,7,"</tbody>");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 14,7},new Method("Ljava/io/PrintWriter;","println",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L46);
                code.visitConstStmt(CONST_STRING,7,"</table>");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 14,7},new Method("Ljava/io/PrintWriter;","println",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L47);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_printCSV(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PRIVATE, new Method("Lorg/mortbay/ijetty/console/CallLogServlet;","printCSV",new String[]{ "I","I","Ljava/io/PrintWriter;","Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(9);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"col");
                ddv.visitParameterName(1,"length");
                ddv.visitParameterName(2,"writer");
                ddv.visitParameterName(3,"value");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(257,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(259,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(260,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(271,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(262,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(266,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(267,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(269,L8);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitConstStmt(CONST_STRING,3,",");
                code.visitConstStmt(CONST_STRING,2,"\"");
                code.visitLabel(L1);
                code.visitStmt3R(SUB_INT,0,6,1);
                code.visitJumpStmt(IF_EQ,5,0,L6);
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_LE,0,1,L5);
                code.visitConstStmt(CONST_STRING,0,",");
                code.visitJumpStmt(IF_EQ,8,3,L5);
                code.visitConstStmt(CONST_STRING,0,"\"");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,2},new Method("Ljava/lang/String;","startsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_NEZ,0,-1,L5);
                code.visitLabel(L3);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,1,"\"");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,8},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitConstStmt(CONST_STRING,1,"\"");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitConstStmt(CONST_STRING,1,",");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,0},new Method("Ljava/io/PrintWriter;","print",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L4);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L5);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,8},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitConstStmt(CONST_STRING,1,",");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,0},new Method("Ljava/io/PrintWriter;","print",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_LE,0,1,L8);
                code.visitConstStmt(CONST_STRING,0,"\"");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,2},new Method("Ljava/lang/String;","startsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_NEZ,0,-1,L8);
                code.visitLabel(L7);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,1,"\"");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,8},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitConstStmt(CONST_STRING,1,"\"");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,0},new Method("Ljava/io/PrintWriter;","println",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,8},new Method("Ljava/io/PrintWriter;","println",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_doContent(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/ijetty/console/CallLogServlet;","doContent",new String[]{ "Ljava/io/PrintWriter;","Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljavax/servlet/ServletException;"));
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(14);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"writer");
                ddv.visitParameterName(1,"request");
                ddv.visitParameterName(2,"response");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(100,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(110,L2);
                ddv.visitStartLocal(2,L2,"projection","[Ljava/lang/String;",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(111,L3);
                ddv.visitStartLocal(8,L3,"cursor","Landroid/database/Cursor;",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(113,L4);
                ddv.visitStartLocal(6,L4,"cols","[Ljava/lang/String;",null);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(114,L5);
                ddv.visitStartLocal(7,L5,"csv","Ljava/lang/String;",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(116,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(125,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(120,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(121,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(122,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(123,L11);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,9, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(7)); // int: 0x00000007  float:0.000000
                code.visitTypeStmt(NEW_ARRAY,2,0,"[Ljava/lang/String;");
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitConstStmt(CONST_STRING,1,"date");
                code.visitStmt3R(APUT_OBJECT,1,2,0);
                code.visitConstStmt(CONST_STRING,0,"type");
                code.visitStmt3R(APUT_OBJECT,0,2,9);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitConstStmt(CONST_STRING,1,"duration");
                code.visitStmt3R(APUT_OBJECT,1,2,0);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(3)); // int: 0x00000003  float:0.000000
                code.visitConstStmt(CONST_STRING,1,"new");
                code.visitStmt3R(APUT_OBJECT,1,2,0);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(4)); // int: 0x00000004  float:0.000000
                code.visitConstStmt(CONST_STRING,1,"number");
                code.visitStmt3R(APUT_OBJECT,1,2,0);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(5)); // int: 0x00000005  float:0.000000
                code.visitConstStmt(CONST_STRING,1,"numbertype");
                code.visitStmt3R(APUT_OBJECT,1,2,0);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(6)); // int: 0x00000006  float:0.000000
                code.visitConstStmt(CONST_STRING,1,"name");
                code.visitStmt3R(APUT_OBJECT,1,2,0);
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Lorg/mortbay/ijetty/console/CallLogServlet;","getContentResolver",new String[]{ },"Landroid/content/ContentResolver;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(SGET_OBJECT,1,-1,new Field("Landroid/provider/CallLog$Calls;","CONTENT_URI","Landroid/net/Uri;"));
                code.visitStmt2R(MOVE_OBJECT,4,3);
                code.visitStmt2R(MOVE_OBJECT,5,3);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 0,1,2,3,4,5},new Method("Landroid/content/ContentResolver;","query",new String[]{ "Landroid/net/Uri;","[Ljava/lang/String;","Ljava/lang/String;","[Ljava/lang/String;","Ljava/lang/String;"},"Landroid/database/Cursor;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 8},new Method("Landroid/database/Cursor;","getColumnNames",new String[]{ },"[Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitLabel(L4);
                code.visitConstStmt(CONST_STRING,0,"csv");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 12,0},new Method("Ljavax/servlet/http/HttpServletRequest;","getParameter",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitLabel(L5);
                code.visitJumpStmt(IF_EQZ,7,-1,L8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Ljava/lang/String;","trim",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Ljava/lang/Integer;","parseInt",new String[]{ "Ljava/lang/String;"},"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_LT,0,9,L8);
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 10,6,8,11},new Method("Lorg/mortbay/ijetty/console/CallLogServlet;","formatCSV",new String[]{ "[Ljava/lang/String;","Landroid/database/Cursor;","Ljava/io/PrintWriter;"},"V"));
                code.visitLabel(L7);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L8);
                code.visitConstStmt(CONST_STRING,0,"<h1 class=\'pageheader\'>Call Log</h1><div id=\'content\'>");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11,0},new Method("Ljava/io/PrintWriter;","println",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 10,6,8,11},new Method("Lorg/mortbay/ijetty/console/CallLogServlet;","formatCallLog",new String[]{ "[Ljava/lang/String;","Landroid/database/Cursor;","Ljava/io/PrintWriter;"},"V"));
                code.visitLabel(L10);
                code.visitConstStmt(CONST_STRING,0,"<p><small><a href=\'?csv=1\'>Download as CSV</a></small></p>");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11,0},new Method("Ljava/io/PrintWriter;","println",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L11);
                code.visitConstStmt(CONST_STRING,0,"</div>");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11,0},new Method("Ljava/io/PrintWriter;","println",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L7);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_doGet(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/ijetty/console/CallLogServlet;","doGet",new String[]{ "Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljavax/servlet/ServletException;"));
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(10);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"request");
                ddv.visitParameterName(1,"response");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(74,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(76,L2);
                ddv.visitStartLocal(2,L2,"writer","Ljava/io/PrintWriter;",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(77,L3);
                ddv.visitStartLocal(0,L3,"csv","Ljava/lang/String;",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(79,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(80,L5);
                ddv.visitStartLocal(1,L5,"date","Ljava/lang/String;",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(81,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(82,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(83,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(94,L9);
                ddv.visitEndLocal(1,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(87,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(88,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(89,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(90,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(91,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(92,L15);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_16,6, Integer.valueOf(200)); // int: 0x000000c8  float:0.000000
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 9},new Method("Ljavax/servlet/http/HttpServletResponse;","getWriter",new String[]{ },"Ljava/io/PrintWriter;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L2);
                code.visitConstStmt(CONST_STRING,3,"csv");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 8,3},new Method("Ljavax/servlet/http/HttpServletRequest;","getParameter",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L3);
                code.visitJumpStmt(IF_EQZ,0,-1,L10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/String;","trim",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3},new Method("Ljava/lang/Integer;","parseInt",new String[]{ "Ljava/lang/String;"},"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitJumpStmt(IF_LT,3,4,L10);
                code.visitLabel(L4);
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Ljava/text/SimpleDateFormat;");
                code.visitConstStmt(CONST_STRING,4,"yyyyMMdd");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3,4},new Method("Ljava/text/SimpleDateFormat;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitTypeStmt(NEW_INSTANCE,4,-1,"Ljava/util/Date;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4},new Method("Ljava/util/Date;","<init>",new String[]{ },"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/text/SimpleDateFormat;","format",new String[]{ "Ljava/util/Date;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L5);
                code.visitConstStmt(CONST_STRING,3,"text/csv");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 9,3},new Method("Ljavax/servlet/http/HttpServletResponse;","setContentType",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L6);
                code.visitConstStmt(CONST_STRING,3,"Content-Disposition");
                code.visitTypeStmt(NEW_INSTANCE,4,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,5,"attachment; filename=call-log-");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitConstStmt(CONST_STRING,5,".csv");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 9,3,4},new Method("Ljavax/servlet/http/HttpServletResponse;","setHeader",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"V"));
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 9,6},new Method("Ljavax/servlet/http/HttpServletResponse;","setStatus",new String[]{ "I"},"V"));
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,2,8,9},new Method("Lorg/mortbay/ijetty/console/CallLogServlet;","doContent",new String[]{ "Ljava/io/PrintWriter;","Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;"},"V"));
                code.visitLabel(L9);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L10);
                code.visitConstStmt(CONST_STRING,3,"text/html");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 9,3},new Method("Ljavax/servlet/http/HttpServletResponse;","setContentType",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L11);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 9,6},new Method("Ljavax/servlet/http/HttpServletResponse;","setStatus",new String[]{ "I"},"V"));
                code.visitLabel(L12);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2,8,9},new Method("Lorg/mortbay/ijetty/console/HTMLHelper;","doHeader",new String[]{ "Ljava/io/PrintWriter;","Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;"},"V"));
                code.visitLabel(L13);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2,8,9},new Method("Lorg/mortbay/ijetty/console/HTMLHelper;","doMenuBar",new String[]{ "Ljava/io/PrintWriter;","Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;"},"V"));
                code.visitLabel(L14);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,2,8,9},new Method("Lorg/mortbay/ijetty/console/CallLogServlet;","doContent",new String[]{ "Ljava/io/PrintWriter;","Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;"},"V"));
                code.visitLabel(L15);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2,8,9},new Method("Lorg/mortbay/ijetty/console/HTMLHelper;","doFooter",new String[]{ "Ljava/io/PrintWriter;","Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L9);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_getContentResolver(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/ijetty/console/CallLogServlet;","getContentResolver",new String[]{ },"Landroid/content/ContentResolver;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(69,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/ijetty/console/CallLogServlet;","resolver","Landroid/content/ContentResolver;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m007_init(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/ijetty/console/CallLogServlet;","init",new String[]{ "Ljavax/servlet/ServletConfig;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljavax/servlet/ServletException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"config");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(63,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(64,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(65,L2);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 2,3},new Method("Ljavax/servlet/http/HttpServlet;","init",new String[]{ "Ljavax/servlet/ServletConfig;"},"V"));
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/ijetty/console/CallLogServlet;","getServletContext",new String[]{ },"Ljavax/servlet/ServletContext;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitConstStmt(CONST_STRING,1,"contentResolver");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1},new Method("Ljavax/servlet/ServletContext;","getAttribute",new String[]{ "Ljava/lang/String;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Landroid/content/ContentResolver;");
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/ijetty/console/CallLogServlet;","resolver","Landroid/content/ContentResolver;"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
