package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0295_org_mortbay_jetty_security_HashUserRealm {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/jetty/security/HashUserRealm;","Lorg/mortbay/component/AbstractLifeCycle;",new String[]{ "Lorg/mortbay/jetty/security/UserRealm;","Lorg/mortbay/jetty/security/SSORealm;"});
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("HashUserRealm.java");
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/MemberClasses;", Visibility.SYSTEM);
            if(av00 != null) {
                {
                    DexAnnotationVisitor av01 = av00.visitArray("value");
                    if(av01 != null) {
                        av01.visit(null, new DexType("Lorg/mortbay/jetty/security/HashUserRealm$WrappedUser;"));
                        av01.visit(null, new DexType("Lorg/mortbay/jetty/security/HashUserRealm$KnownUser;"));
                        av01.visit(null, new DexType("Lorg/mortbay/jetty/security/HashUserRealm$User;"));
                        av01.visitEnd();
                    }
                }
                av00.visitEnd();
            }
        }
        f000___SSO(cv);
        f001__config(cv);
        f002__configResource(cv);
        f003__realmName(cv);
        f004__refreshInterval(cv);
        f005__roles(cv);
        f006__scanner(cv);
        f007__ssoRealm(cv);
        f008__users(cv);
        m000__init_(cv);
        m001__init_(cv);
        m002__init_(cv);
        m003_access$200(cv);
        m004_access$300(cv);
        m005_addUserToRole(cv);
        m006_authenticate(cv);
        m007_clearSingleSignOn(cv);
        m008_disassociate(cv);
        m009_doStart(cv);
        m010_doStop(cv);
        m011_dump(cv);
        m012_getConfig(cv);
        m013_getConfigResource(cv);
        m014_getName(cv);
        m015_getPrincipal(cv);
        m016_getRefreshInterval(cv);
        m017_getSSORealm(cv);
        m018_getSingleSignOn(cv);
        m019_isUserInRole(cv);
        m020_loadConfig(cv);
        m021_logout(cv);
        m022_popRole(cv);
        m023_pushRole(cv);
        m024_put(cv);
        m025_reauthenticate(cv);
        m026_setConfig(cv);
        m027_setName(cv);
        m028_setRefreshInterval(cv);
        m029_setSSORealm(cv);
        m030_setSingleSignOn(cv);
        m031_toString(cv);
    }
    public static void f000___SSO(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/security/HashUserRealm;","__SSO","Ljava/lang/String;"), "org.mortbay.http.SSO");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001__config(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/security/HashUserRealm;","_config","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002__configResource(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/security/HashUserRealm;","_configResource","Lorg/mortbay/resource/Resource;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003__realmName(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/security/HashUserRealm;","_realmName","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f004__refreshInterval(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/security/HashUserRealm;","_refreshInterval","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f005__roles(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/jetty/security/HashUserRealm;","_roles","Ljava/util/HashMap;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f006__scanner(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/security/HashUserRealm;","_scanner","Lorg/mortbay/util/Scanner;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f007__ssoRealm(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/security/HashUserRealm;","_ssoRealm","Lorg/mortbay/jetty/security/SSORealm;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f008__users(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/jetty/security/HashUserRealm;","_users","Ljava/util/HashMap;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/security/HashUserRealm;","<init>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(86,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(75,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(76,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(79,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(86,L4);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2},new Method("Lorg/mortbay/component/AbstractLifeCycle;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/util/HashMap;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/util/HashMap;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/jetty/security/HashUserRealm;","_users","Ljava/util/HashMap;"));
                code.visitLabel(L2);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/util/HashMap;");
                code.visitConstStmt(CONST_4,1, Integer.valueOf(7)); // int: 0x00000007  float:0.000000
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Ljava/util/HashMap;","<init>",new String[]{ "I"},"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/jetty/security/HashUserRealm;","_roles","Ljava/util/HashMap;"));
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT,0,2,new Field("Lorg/mortbay/jetty/security/HashUserRealm;","_refreshInterval","I"));
                code.visitLabel(L4);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/security/HashUserRealm;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(93,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(75,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(76,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(79,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(94,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(95,L5);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2},new Method("Lorg/mortbay/component/AbstractLifeCycle;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/util/HashMap;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/util/HashMap;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/jetty/security/HashUserRealm;","_users","Ljava/util/HashMap;"));
                code.visitLabel(L2);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/util/HashMap;");
                code.visitConstStmt(CONST_4,1, Integer.valueOf(7)); // int: 0x00000007  float:0.000000
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Ljava/util/HashMap;","<init>",new String[]{ "I"},"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/jetty/security/HashUserRealm;","_roles","Ljava/util/HashMap;"));
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT,0,2,new Field("Lorg/mortbay/jetty/security/HashUserRealm;","_refreshInterval","I"));
                code.visitLabel(L4);
                code.visitFieldStmt(IPUT_OBJECT,3,2,new Field("Lorg/mortbay/jetty/security/HashUserRealm;","_realmName","Ljava/lang/String;"));
                code.visitLabel(L5);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/security/HashUserRealm;","<init>",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                ddv.visitParameterName(1,"config");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(104,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(75,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(76,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(79,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(105,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(106,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(107,L6);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2},new Method("Lorg/mortbay/component/AbstractLifeCycle;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/util/HashMap;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/util/HashMap;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/jetty/security/HashUserRealm;","_users","Ljava/util/HashMap;"));
                code.visitLabel(L2);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/util/HashMap;");
                code.visitConstStmt(CONST_4,1, Integer.valueOf(7)); // int: 0x00000007  float:0.000000
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Ljava/util/HashMap;","<init>",new String[]{ "I"},"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/jetty/security/HashUserRealm;","_roles","Ljava/util/HashMap;"));
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT,0,2,new Field("Lorg/mortbay/jetty/security/HashUserRealm;","_refreshInterval","I"));
                code.visitLabel(L4);
                code.visitFieldStmt(IPUT_OBJECT,3,2,new Field("Lorg/mortbay/jetty/security/HashUserRealm;","_realmName","Ljava/lang/String;"));
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,4},new Method("Lorg/mortbay/jetty/security/HashUserRealm;","setConfig",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L6);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_access$200(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_SYNTHETIC, new Method("Lorg/mortbay/jetty/security/HashUserRealm;","access$200",new String[]{ "Lorg/mortbay/jetty/security/HashUserRealm;"},"Lorg/mortbay/resource/Resource;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"x0");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(64,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/security/HashUserRealm;","_configResource","Lorg/mortbay/resource/Resource;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_access$300(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_SYNTHETIC, new Method("Lorg/mortbay/jetty/security/HashUserRealm;","access$300",new String[]{ "Lorg/mortbay/jetty/security/HashUserRealm;"},"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"x0");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(64,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/security/HashUserRealm;","_config","Ljava/lang/String;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_addUserToRole(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/HashUserRealm;","addUserToRole",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"userName");
                ddv.visitParameterName(1,"roleName");
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(277,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(278,L4);
                ddv.visitStartLocal(0,L4,"userSet","Ljava/util/HashSet;",null);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(280,L5);
                DexLabel L6=new DexLabel();
                ddv.visitEndLocal(0,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(281,L7);
                ddv.visitRestartLocal(0,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(283,L8);
                ddv.visitLineNumber(284,L1);
                ddv.visitLineNumber(277,L2);
                ddv.visitEndLocal(0,L2);
                code.visitLabel(L3);
                code.visitStmt1R(MONITOR_ENTER,2);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/security/HashUserRealm;","_roles","Ljava/util/HashMap;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,4},new Method("Ljava/util/HashMap;","get",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Ljava/util/HashSet;");
                code.visitLabel(L4);
                code.visitJumpStmt(IF_NEZ,0,-1,L8);
                code.visitLabel(L5);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/util/HashSet;");
                code.visitLabel(L6);
                code.visitConstStmt(CONST_16,1, Integer.valueOf(11)); // int: 0x0000000b  float:0.000000
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Ljava/util/HashSet;","<init>",new String[]{ "I"},"V"));
                code.visitLabel(L7);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/security/HashUserRealm;","_roles","Ljava/util/HashMap;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,4,0},new Method("Ljava/util/HashMap;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,3},new Method("Ljava/util/HashSet;","add",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitLabel(L1);
                code.visitStmt1R(MONITOR_EXIT,2);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitStmt1R(MONITOR_EXIT,2);
                code.visitStmt1R(THROW,1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_authenticate(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/HashUserRealm;","authenticate",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;","Lorg/mortbay/jetty/Request;"},"Ljava/security/Principal;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"username");
                ddv.visitParameterName(1,"credentials");
                ddv.visitParameterName(2,"request");
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(217,L4);
                ddv.visitLineNumber(219,L0);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(220,L5);
                ddv.visitStartLocal(0,L5,"user","Lorg/mortbay/jetty/security/HashUserRealm$KnownUser;",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(221,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(227,L7);
                ddv.visitLineNumber(220,L2);
                ddv.visitEndLocal(0,L2);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(224,L8);
                ddv.visitRestartLocal(0,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(225,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(227,L10);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L4);
                code.visitStmt1R(MONITOR_ENTER,3);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/jetty/security/HashUserRealm;","_users","Ljava/util/HashMap;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,4},new Method("Ljava/util/HashMap;","get",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Lorg/mortbay/jetty/security/HashUserRealm$KnownUser;");
                code.visitLabel(L5);
                code.visitStmt1R(MONITOR_EXIT,3);
                code.visitLabel(L6);
                code.visitJumpStmt(IF_NEZ,0,-1,L8);
                code.visitStmt2R(MOVE_OBJECT,1,2);
                code.visitLabel(L7);
                code.visitStmt1R(RETURN_OBJECT,1);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitStmt1R(MONITOR_EXIT,3);
                code.visitLabel(L1);
                code.visitStmt1R(THROW,1);
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,5},new Method("Lorg/mortbay/jetty/security/HashUserRealm$KnownUser;","authenticate",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,1);
                DexLabel L11=new DexLabel();
                code.visitJumpStmt(IF_EQZ,1,-1,L11);
                code.visitStmt2R(MOVE_OBJECT,1,0);
                code.visitLabel(L9);
                code.visitJumpStmt(GOTO,-1,-1,L7);
                code.visitLabel(L11);
                code.visitStmt2R(MOVE_OBJECT,1,2);
                code.visitLabel(L10);
                code.visitJumpStmt(GOTO,-1,-1,L7);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m007_clearSingleSignOn(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/HashUserRealm;","clearSingleSignOn",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"username");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(365,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(366,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(367,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/security/HashUserRealm;","_ssoRealm","Lorg/mortbay/jetty/security/SSORealm;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L2);
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/security/HashUserRealm;","_ssoRealm","Lorg/mortbay/jetty/security/SSORealm;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,2},new Method("Lorg/mortbay/jetty/security/SSORealm;","clearSingleSignOn",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m008_disassociate(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/HashUserRealm;","disassociate",new String[]{ "Ljava/security/Principal;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"user");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(233,L0);
                code.visitLabel(L0);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m009_doStart(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/security/HashUserRealm;","doStart",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/Exception;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(378,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(379,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(380,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(382,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(384,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(385,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(386,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(387,L8);
                ddv.visitStartLocal(0,L8,"dirList","Ljava/util/List;",null);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(388,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(389,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(408,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(425,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(426,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(427,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(429,L15);
                ddv.visitEndLocal(0,L15);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 4},new Method("Lorg/mortbay/component/AbstractLifeCycle;","doStart",new String[]{ },"V"));
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/jetty/security/HashUserRealm;","_scanner","Lorg/mortbay/util/Scanner;"));
                code.visitJumpStmt(IF_EQZ,1,-1,L4);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/jetty/security/HashUserRealm;","_scanner","Lorg/mortbay/util/Scanner;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/util/Scanner;","stop",new String[]{ },"V"));
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/jetty/security/HashUserRealm;","getRefreshInterval",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_LEZ,1,-1,L15);
                code.visitLabel(L5);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Lorg/mortbay/util/Scanner;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Lorg/mortbay/util/Scanner;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,1,4,new Field("Lorg/mortbay/jetty/security/HashUserRealm;","_scanner","Lorg/mortbay/util/Scanner;"));
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/jetty/security/HashUserRealm;","_scanner","Lorg/mortbay/util/Scanner;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/jetty/security/HashUserRealm;","getRefreshInterval",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Lorg/mortbay/util/Scanner;","setScanInterval",new String[]{ "I"},"V"));
                code.visitLabel(L7);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/util/ArrayList;");
                code.visitConstStmt(CONST_4,1, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Ljava/util/ArrayList;","<init>",new String[]{ "I"},"V"));
                code.visitLabel(L8);
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/jetty/security/HashUserRealm;","_configResource","Lorg/mortbay/resource/Resource;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/resource/Resource;","getFile",new String[]{ },"Ljava/io/File;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1},new Method("Ljava/util/List;","add",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitLabel(L9);
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/jetty/security/HashUserRealm;","_scanner","Lorg/mortbay/util/Scanner;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,0},new Method("Lorg/mortbay/util/Scanner;","setScanDirs",new String[]{ "Ljava/util/List;"},"V"));
                code.visitLabel(L10);
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/jetty/security/HashUserRealm;","_scanner","Lorg/mortbay/util/Scanner;"));
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Lorg/mortbay/jetty/security/HashUserRealm$1;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2,4},new Method("Lorg/mortbay/jetty/security/HashUserRealm$1;","<init>",new String[]{ "Lorg/mortbay/jetty/security/HashUserRealm;"},"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Lorg/mortbay/util/Scanner;","setFilenameFilter",new String[]{ "Ljava/io/FilenameFilter;"},"V"));
                code.visitLabel(L11);
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/jetty/security/HashUserRealm;","_scanner","Lorg/mortbay/util/Scanner;"));
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Lorg/mortbay/jetty/security/HashUserRealm$2;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2,4},new Method("Lorg/mortbay/jetty/security/HashUserRealm$2;","<init>",new String[]{ "Lorg/mortbay/jetty/security/HashUserRealm;"},"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Lorg/mortbay/util/Scanner;","addListener",new String[]{ "Lorg/mortbay/util/Scanner$Listener;"},"V"));
                code.visitLabel(L12);
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/jetty/security/HashUserRealm;","_scanner","Lorg/mortbay/util/Scanner;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,3},new Method("Lorg/mortbay/util/Scanner;","setReportExistingFilesOnStartup",new String[]{ "Z"},"V"));
                code.visitLabel(L13);
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/jetty/security/HashUserRealm;","_scanner","Lorg/mortbay/util/Scanner;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,3},new Method("Lorg/mortbay/util/Scanner;","setRecursive",new String[]{ "Z"},"V"));
                code.visitLabel(L14);
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/jetty/security/HashUserRealm;","_scanner","Lorg/mortbay/util/Scanner;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/util/Scanner;","start",new String[]{ },"V"));
                code.visitLabel(L15);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m010_doStop(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/security/HashUserRealm;","doStop",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/Exception;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(436,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(437,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(438,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(439,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(440,L4);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 1},new Method("Lorg/mortbay/component/AbstractLifeCycle;","doStop",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/security/HashUserRealm;","_scanner","Lorg/mortbay/util/Scanner;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L3);
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/security/HashUserRealm;","_scanner","Lorg/mortbay/util/Scanner;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/util/Scanner;","stop",new String[]{ },"V"));
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/security/HashUserRealm;","_scanner","Lorg/mortbay/util/Scanner;"));
                code.visitLabel(L4);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m011_dump(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/HashUserRealm;","dump",new String[]{ "Ljava/io/PrintStream;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"out");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(323,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(324,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(325,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(326,L3);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitConstStmt(CONST_STRING,1,":");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,0},new Method("Ljava/io/PrintStream;","println",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 2},new Method("Ljava/lang/Object;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,0},new Method("Ljava/io/PrintStream;","println",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/security/HashUserRealm;","_roles","Ljava/util/HashMap;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,0},new Method("Ljava/io/PrintStream;","println",new String[]{ "Ljava/lang/Object;"},"V"));
                code.visitLabel(L3);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m012_getConfig(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/HashUserRealm;","getConfig",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(111,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/security/HashUserRealm;","_config","Ljava/lang/String;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m013_getConfigResource(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/HashUserRealm;","getConfigResource",new String[]{ },"Lorg/mortbay/resource/Resource;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(116,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/security/HashUserRealm;","_configResource","Lorg/mortbay/resource/Resource;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m014_getName(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/HashUserRealm;","getName",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(204,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/security/HashUserRealm;","_realmName","Ljava/lang/String;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m015_getPrincipal(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/HashUserRealm;","getPrincipal",new String[]{ "Ljava/lang/String;"},"Ljava/security/Principal;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"username");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(210,L0);
                DexLabel L1=new DexLabel();
                ddv.visitEndLocal(1,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/security/HashUserRealm;","_users","Ljava/util/HashMap;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,2},new Method("Ljava/util/HashMap;","get",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L1);
                code.visitTypeStmt(CHECK_CAST,1,-1,"Ljava/security/Principal;");
                code.visitStmt1R(RETURN_OBJECT,1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m016_getRefreshInterval(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/HashUserRealm;","getRefreshInterval",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(144,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,1,new Field("Lorg/mortbay/jetty/security/HashUserRealm;","_refreshInterval","I"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m017_getSSORealm(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/HashUserRealm;","getSSORealm",new String[]{ },"Lorg/mortbay/jetty/security/SSORealm;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(334,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/security/HashUserRealm;","_ssoRealm","Lorg/mortbay/jetty/security/SSORealm;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m018_getSingleSignOn(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/HashUserRealm;","getSingleSignOn",new String[]{ "Lorg/mortbay/jetty/Request;","Lorg/mortbay/jetty/Response;"},"Lorg/mortbay/jetty/security/Credential;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"request");
                ddv.visitParameterName(1,"response");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(350,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(351,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(352,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/security/HashUserRealm;","_ssoRealm","Lorg/mortbay/jetty/security/SSORealm;"));
                DexLabel L3=new DexLabel();
                code.visitJumpStmt(IF_EQZ,0,-1,L3);
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/security/HashUserRealm;","_ssoRealm","Lorg/mortbay/jetty/security/SSORealm;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,2,3},new Method("Lorg/mortbay/jetty/security/SSORealm;","getSingleSignOn",new String[]{ "Lorg/mortbay/jetty/Request;","Lorg/mortbay/jetty/Response;"},"Lorg/mortbay/jetty/security/Credential;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L2);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m019_isUserInRole(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/HashUserRealm;","isUserInRole",new String[]{ "Ljava/security/Principal;","Ljava/lang/String;"},"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"user");
                ddv.visitParameterName(1,"roleName");
                DexLabel L5=new DexLabel();
                ddv.visitPrologue(L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(300,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(301,L7);
                DexLabel L8=new DexLabel();
                ddv.visitEndLocal(5,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(307,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(303,L10);
                ddv.visitRestartLocal(5,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(304,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(306,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(307,L13);
                ddv.visitStartLocal(1,L13,"userSet","Ljava/util/HashSet;",null);
                ddv.visitLineNumber(300,L2);
                ddv.visitEndLocal(5,L2);
                ddv.visitEndLocal(1,L2);
                code.visitLabel(L5);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L6);
                code.visitStmt1R(MONITOR_ENTER,4);
                code.visitLabel(L0);
                code.visitTypeStmt(INSTANCE_OF,2,5,"Lorg/mortbay/jetty/security/HashUserRealm$WrappedUser;");
                code.visitJumpStmt(IF_EQZ,2,-1,L10);
                code.visitLabel(L7);
                code.visitTypeStmt(CHECK_CAST,5,-1,"Lorg/mortbay/jetty/security/HashUserRealm$WrappedUser;");
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Lorg/mortbay/jetty/security/HashUserRealm$WrappedUser;","isUserInRole",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitLabel(L1);
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitLabel(L9);
                code.visitStmt1R(MONITOR_EXIT,4);
                code.visitStmt1R(RETURN,2);
                code.visitLabel(L10);
                DexLabel L14=new DexLabel();
                code.visitJumpStmt(IF_EQZ,5,-1,L14);
                code.visitLabel(L3);
                code.visitTypeStmt(INSTANCE_OF,2,5,"Lorg/mortbay/jetty/security/HashUserRealm$User;");
                code.visitJumpStmt(IF_EQZ,2,-1,L14);
                code.visitStmt2R(MOVE_OBJECT,0,5);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Lorg/mortbay/jetty/security/HashUserRealm$User;");
                code.visitStmt2R(MOVE_OBJECT,2,0);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2},new Method("Lorg/mortbay/jetty/security/HashUserRealm$User;","access$100",new String[]{ "Lorg/mortbay/jetty/security/HashUserRealm$User;"},"Lorg/mortbay/jetty/security/UserRealm;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitJumpStmt(IF_EQ,2,4,L12);
                code.visitLabel(L14);
                code.visitStmt2R(MOVE,2,3);
                code.visitLabel(L11);
                code.visitJumpStmt(GOTO,-1,-1,L9);
                code.visitLabel(L12);
                code.visitFieldStmt(IGET_OBJECT,2,4,new Field("Lorg/mortbay/jetty/security/HashUserRealm;","_roles","Ljava/util/HashMap;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,6},new Method("Ljava/util/HashMap;","get",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitTypeStmt(CHECK_CAST,1,-1,"Ljava/util/HashSet;");
                code.visitLabel(L13);
                DexLabel L15=new DexLabel();
                code.visitJumpStmt(IF_EQZ,1,-1,L15);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 5},new Method("Ljava/security/Principal;","getName",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/util/HashSet;","contains",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitLabel(L4);
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_EQZ,2,-1,L15);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L9);
                code.visitLabel(L15);
                code.visitStmt2R(MOVE,2,3);
                code.visitJumpStmt(GOTO,-1,-1,L9);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,2);
                code.visitStmt1R(MONITOR_EXIT,4);
                code.visitStmt1R(THROW,2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m020_loadConfig(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/security/HashUserRealm;","loadConfig",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(11);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L5=new DexLabel();
                ddv.visitPrologue(L5);
                ddv.visitLineNumber(150,L5);
                ddv.visitLineNumber(152,L0);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(153,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(155,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(156,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(157,L9);
                ddv.visitStartLocal(4,L9,"properties","Ljava/util/Properties;",null);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(159,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(160,L11);
                ddv.visitStartLocal(3,L11,"iter","Ljava/util/Iterator;",null);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(162,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(164,L13);
                ddv.visitStartLocal(2,L13,"entry","Ljava/util/Map$Entry;",null);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(165,L14);
                ddv.visitStartLocal(7,L14,"username","Ljava/lang/String;",null);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(166,L15);
                ddv.visitStartLocal(1,L15,"credentials","Ljava/lang/String;",null);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(167,L16);
                ddv.visitStartLocal(5,L16,"roles","Ljava/lang/String;",null);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(168,L17);
                ddv.visitStartLocal(0,L17,"c","I",null);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(170,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(171,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(174,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(177,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(178,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(180,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(181,L24);
                ddv.visitStartLocal(6,L24,"tok","Ljava/util/StringTokenizer;",null);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(182,L25);
                ddv.visitLineNumber(186,L2);
                ddv.visitEndLocal(4,L2);
                ddv.visitEndLocal(3,L2);
                ddv.visitEndLocal(2,L2);
                ddv.visitEndLocal(7,L2);
                ddv.visitEndLocal(0,L2);
                ddv.visitEndLocal(5,L2);
                ddv.visitEndLocal(1,L2);
                ddv.visitEndLocal(6,L2);
                ddv.visitRestartLocal(3,L3);
                ddv.visitRestartLocal(4,L3);
                ddv.visitLineNumber(187,L4);
                code.visitLabel(L5);
                code.visitStmt1R(MONITOR_ENTER,10);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,8,10,new Field("Lorg/mortbay/jetty/security/HashUserRealm;","_users","Ljava/util/HashMap;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Ljava/util/HashMap;","clear",new String[]{ },"V"));
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,8,10,new Field("Lorg/mortbay/jetty/security/HashUserRealm;","_roles","Ljava/util/HashMap;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Ljava/util/HashMap;","clear",new String[]{ },"V"));
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/log/Log;","isDebugEnabled",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitJumpStmt(IF_EQZ,8,-1,L8);
                code.visitTypeStmt(NEW_INSTANCE,8,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 8},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,9,"Load ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,9},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,10},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitConstStmt(CONST_STRING,9," from ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,9},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitFieldStmt(IGET_OBJECT,9,10,new Field("Lorg/mortbay/jetty/security/HashUserRealm;","_config","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,9},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 8},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L8);
                code.visitTypeStmt(NEW_INSTANCE,4,-1,"Ljava/util/Properties;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4},new Method("Ljava/util/Properties;","<init>",new String[]{ },"V"));
                code.visitLabel(L9);
                code.visitFieldStmt(IGET_OBJECT,8,10,new Field("Lorg/mortbay/jetty/security/HashUserRealm;","_configResource","Lorg/mortbay/resource/Resource;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Lorg/mortbay/resource/Resource;","getInputStream",new String[]{ },"Ljava/io/InputStream;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,8},new Method("Ljava/util/Properties;","load",new String[]{ "Ljava/io/InputStream;"},"V"));
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/util/Properties;","entrySet",new String[]{ },"Ljava/util/Set;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 8},new Method("Ljava/util/Set;","iterator",new String[]{ },"Ljava/util/Iterator;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitLabel(L11);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3},new Method("Ljava/util/Iterator;","hasNext",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitJumpStmt(IF_EQZ,8,-1,L3);
                code.visitLabel(L12);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3},new Method("Ljava/util/Iterator;","next",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitTypeStmt(CHECK_CAST,2,-1,"Ljava/util/Map$Entry;");
                code.visitLabel(L13);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2},new Method("Ljava/util/Map$Entry;","getKey",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Ljava/lang/Object;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Ljava/lang/String;","trim",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitLabel(L14);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2},new Method("Ljava/util/Map$Entry;","getValue",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Ljava/lang/Object;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Ljava/lang/String;","trim",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L15);
                code.visitConstStmt(CONST_4,5, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L16);
                code.visitConstStmt(CONST_16,8, Integer.valueOf(44)); // int: 0x0000002c  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,8},new Method("Ljava/lang/String;","indexOf",new String[]{ "I"},"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitLabel(L17);
                code.visitJumpStmt(IF_LEZ,0,-1,L20);
                code.visitLabel(L18);
                code.visitStmt2R1N(ADD_INT_LIT8,8,0,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,8},new Method("Ljava/lang/String;","substring",new String[]{ "I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Ljava/lang/String;","trim",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitLabel(L19);
                code.visitConstStmt(CONST_4,8, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,8,0},new Method("Ljava/lang/String;","substring",new String[]{ "I","I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Ljava/lang/String;","trim",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L20);
                code.visitJumpStmt(IF_EQZ,7,-1,L11);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitJumpStmt(IF_LEZ,8,-1,L11);
                code.visitJumpStmt(IF_EQZ,1,-1,L11);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitJumpStmt(IF_LEZ,8,-1,L11);
                code.visitLabel(L21);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10,7,1},new Method("Lorg/mortbay/jetty/security/HashUserRealm;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L22);
                code.visitJumpStmt(IF_EQZ,5,-1,L11);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitJumpStmt(IF_LEZ,8,-1,L11);
                code.visitLabel(L23);
                code.visitTypeStmt(NEW_INSTANCE,6,-1,"Ljava/util/StringTokenizer;");
                code.visitConstStmt(CONST_STRING,8,", ");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 6,5,8},new Method("Ljava/util/StringTokenizer;","<init>",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"V"));
                code.visitLabel(L24);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/util/StringTokenizer;","hasMoreTokens",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitJumpStmt(IF_EQZ,8,-1,L11);
                code.visitLabel(L25);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/util/StringTokenizer;","nextToken",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10,7,8},new Method("Lorg/mortbay/jetty/security/HashUserRealm;","addUserToRole",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L24);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,8);
                code.visitStmt1R(MONITOR_EXIT,10);
                code.visitLabel(L1);
                code.visitStmt1R(THROW,8);
                code.visitLabel(L3);
                code.visitStmt1R(MONITOR_EXIT,10);
                code.visitLabel(L4);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m021_logout(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/HashUserRealm;","logout",new String[]{ "Ljava/security/Principal;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"user");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(312,L0);
                code.visitLabel(L0);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m022_popRole(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/HashUserRealm;","popRole",new String[]{ "Ljava/security/Principal;"},"Ljava/security/Principal;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"user");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(247,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(248,L1);
                ddv.visitStartLocal(1,L1,"wu","Lorg/mortbay/jetty/security/HashUserRealm$WrappedUser;",null);
                code.visitLabel(L0);
                code.visitStmt2R(MOVE_OBJECT,0,4);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Lorg/mortbay/jetty/security/HashUserRealm$WrappedUser;");
                code.visitStmt2R(MOVE_OBJECT,1,0);
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/jetty/security/HashUserRealm$WrappedUser;","getUserPrincipal",new String[]{ },"Ljava/security/Principal;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitStmt1R(RETURN_OBJECT,2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m023_pushRole(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/HashUserRealm;","pushRole",new String[]{ "Ljava/security/Principal;","Ljava/lang/String;"},"Ljava/security/Principal;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"user");
                ddv.visitParameterName(1,"role");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(238,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(239,L1);
                DexLabel L2=new DexLabel();
                ddv.visitEndLocal(2,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(241,L3);
                ddv.visitRestartLocal(2,L3);
                code.visitLabel(L0);
                code.visitJumpStmt(IF_NEZ,2,-1,L3);
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Lorg/mortbay/jetty/security/HashUserRealm$User;");
                code.visitLabel(L2);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2,1,0},new Method("Lorg/mortbay/jetty/security/HashUserRealm$User;","<init>",new String[]{ "Lorg/mortbay/jetty/security/HashUserRealm;","Lorg/mortbay/jetty/security/HashUserRealm$1;"},"V"));
                code.visitLabel(L3);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/jetty/security/HashUserRealm$WrappedUser;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1,2,3},new Method("Lorg/mortbay/jetty/security/HashUserRealm$WrappedUser;","<init>",new String[]{ "Lorg/mortbay/jetty/security/HashUserRealm;","Ljava/security/Principal;","Ljava/lang/String;"},"V"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m024_put(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/HashUserRealm;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                ddv.visitParameterName(1,"credentials");
                DexLabel L5=new DexLabel();
                ddv.visitPrologue(L5);
                ddv.visitLineNumber(260,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(261,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(267,L7);
                ddv.visitEndLocal(6,L7);
                ddv.visitLineNumber(263,L3);
                ddv.visitRestartLocal(6,L3);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(264,L8);
                DexLabel L9=new DexLabel();
                ddv.visitEndLocal(6,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(265,L10);
                ddv.visitRestartLocal(6,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(266,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(267,L12);
                ddv.visitLineNumber(260,L2);
                ddv.visitEndLocal(6,L2);
                code.visitLabel(L5);
                code.visitStmt1R(MONITOR_ENTER,4);
                code.visitLabel(L0);
                code.visitTypeStmt(INSTANCE_OF,0,6,"Ljava/security/Principal;");
                code.visitJumpStmt(IF_EQZ,0,-1,L3);
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/jetty/security/HashUserRealm;","_users","Ljava/util/HashMap;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/lang/Object;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,6},new Method("Ljava/util/HashMap;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L1);
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L7);
                code.visitStmt1R(MONITOR_EXIT,4);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L3);
                code.visitTypeStmt(INSTANCE_OF,0,6,"Lorg/mortbay/jetty/security/Password;");
                code.visitJumpStmt(IF_EQZ,0,-1,L10);
                code.visitLabel(L8);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/jetty/security/HashUserRealm;","_users","Ljava/util/HashMap;"));
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Lorg/mortbay/jetty/security/HashUserRealm$KnownUser;");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/lang/Object;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitTypeStmt(CHECK_CAST,6,-1,"Lorg/mortbay/jetty/security/Password;");
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,4,2,6},new Method("Lorg/mortbay/jetty/security/HashUserRealm$KnownUser;","<init>",new String[]{ "Lorg/mortbay/jetty/security/HashUserRealm;","Ljava/lang/String;","Lorg/mortbay/jetty/security/Credential;"},"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,5,1},new Method("Ljava/util/HashMap;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitJumpStmt(GOTO,-1,-1,L7);
                code.visitLabel(L10);
                code.visitJumpStmt(IF_EQZ,6,-1,L12);
                code.visitLabel(L11);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/jetty/security/HashUserRealm;","_users","Ljava/util/HashMap;"));
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Lorg/mortbay/jetty/security/HashUserRealm$KnownUser;");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/lang/Object;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/lang/Object;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3},new Method("Lorg/mortbay/jetty/security/Credential;","getCredential",new String[]{ "Ljava/lang/String;"},"Lorg/mortbay/jetty/security/Credential;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,4,2,3},new Method("Lorg/mortbay/jetty/security/HashUserRealm$KnownUser;","<init>",new String[]{ "Lorg/mortbay/jetty/security/HashUserRealm;","Ljava/lang/String;","Lorg/mortbay/jetty/security/Credential;"},"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,5,1},new Method("Ljava/util/HashMap;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L4);
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitJumpStmt(GOTO,-1,-1,L7);
                code.visitLabel(L12);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L7);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,0);
                code.visitStmt1R(MONITOR_EXIT,4);
                code.visitStmt1R(THROW,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m025_reauthenticate(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/HashUserRealm;","reauthenticate",new String[]{ "Ljava/security/Principal;"},"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"user");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(289,L0);
                DexLabel L1=new DexLabel();
                ddv.visitEndLocal(2,L1);
                code.visitLabel(L0);
                code.visitTypeStmt(CHECK_CAST,2,-1,"Lorg/mortbay/jetty/security/HashUserRealm$User;");
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/security/HashUserRealm$User;","isAuthenticated",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m026_setConfig(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/HashUserRealm;","setConfig",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"config");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(130,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(131,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(132,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(134,L3);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,2,1,new Field("Lorg/mortbay/jetty/security/HashUserRealm;","_config","Ljava/lang/String;"));
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/security/HashUserRealm;","_config","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/resource/Resource;","newResource",new String[]{ "Ljava/lang/String;"},"Lorg/mortbay/resource/Resource;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/security/HashUserRealm;","_configResource","Lorg/mortbay/resource/Resource;"));
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/jetty/security/HashUserRealm;","loadConfig",new String[]{ },"V"));
                code.visitLabel(L3);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m027_setName(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/HashUserRealm;","setName",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(195,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(196,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/security/HashUserRealm;","_realmName","Ljava/lang/String;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m028_setRefreshInterval(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/HashUserRealm;","setRefreshInterval",new String[]{ "I"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"msec");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(139,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(140,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT,1,0,new Field("Lorg/mortbay/jetty/security/HashUserRealm;","_refreshInterval","I"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m029_setSSORealm(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/HashUserRealm;","setSSORealm",new String[]{ "Lorg/mortbay/jetty/security/SSORealm;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"ssoRealm");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(344,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(345,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/security/HashUserRealm;","_ssoRealm","Lorg/mortbay/jetty/security/SSORealm;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m030_setSingleSignOn(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/HashUserRealm;","setSingleSignOn",new String[]{ "Lorg/mortbay/jetty/Request;","Lorg/mortbay/jetty/Response;","Ljava/security/Principal;","Lorg/mortbay/jetty/security/Credential;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"request");
                ddv.visitParameterName(1,"response");
                ddv.visitParameterName(2,"principal");
                ddv.visitParameterName(3,"credential");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(358,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(359,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(360,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/security/HashUserRealm;","_ssoRealm","Lorg/mortbay/jetty/security/SSORealm;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L2);
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/security/HashUserRealm;","_ssoRealm","Lorg/mortbay/jetty/security/SSORealm;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,2,3,4,5},new Method("Lorg/mortbay/jetty/security/SSORealm;","setSingleSignOn",new String[]{ "Lorg/mortbay/jetty/Request;","Lorg/mortbay/jetty/Response;","Ljava/security/Principal;","Lorg/mortbay/jetty/security/Credential;"},"V"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m031_toString(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/HashUserRealm;","toString",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(317,L0);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,1,"Realm[");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/security/HashUserRealm;","_realmName","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitConstStmt(CONST_STRING,1,"]==");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/security/HashUserRealm;","_users","Ljava/util/HashMap;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/util/HashMap;","keySet",new String[]{ },"Ljava/util/Set;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
