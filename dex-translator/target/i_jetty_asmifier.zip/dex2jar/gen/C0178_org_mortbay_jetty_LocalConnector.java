package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0178_org_mortbay_jetty_LocalConnector {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/jetty/LocalConnector;","Lorg/mortbay/jetty/AbstractConnector;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("LocalConnector.java");
        f000__accepting(cv);
        f001__endp(cv);
        f002__in(cv);
        f003__keepOpen(cv);
        f004__out(cv);
        f005__server(cv);
        m000__init_(cv);
        m001_accept(cv);
        m002_clear(cv);
        m003_close(cv);
        m004_doStart(cv);
        m005_getConnection(cv);
        m006_getLocalPort(cv);
        m007_getResponses(cv);
        m008_getResponses(cv);
        m009_getResponses(cv);
        m010_newBuffer(cv);
        m011_open(cv);
        m012_reopen(cv);
        m013_setServer(cv);
    }
    public static void f000__accepting(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/jetty/LocalConnector;","_accepting","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001__endp(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/jetty/LocalConnector;","_endp","Lorg/mortbay/io/ByteArrayEndPoint;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002__in(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/jetty/LocalConnector;","_in","Lorg/mortbay/io/ByteArrayBuffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003__keepOpen(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/jetty/LocalConnector;","_keepOpen","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f004__out(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/jetty/LocalConnector;","_out","Lorg/mortbay/io/ByteArrayBuffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f005__server(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/jetty/LocalConnector;","_server","Lorg/mortbay/jetty/Server;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/LocalConnector;","<init>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(34,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(35,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(36,L2);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Lorg/mortbay/jetty/AbstractConnector;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,0},new Method("Lorg/mortbay/jetty/LocalConnector;","setPort",new String[]{ "I"},"V"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001_accept(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/LocalConnector;","accept",new String[]{ "I"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visit(null, new DexType("Ljava/lang/InterruptedException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                DexLabel L3=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2,L3},new String[]{ "Ljava/lang/InterruptedException;",null});
                DexLabel L4=new DexLabel();
                DexLabel L5=new DexLabel();
                code.visitTryCatch(L4,L5,new DexLabel[]{L3},new String[]{ null});
                DexLabel L6=new DexLabel();
                DexLabel L7=new DexLabel();
                DexLabel L8=new DexLabel();
                code.visitTryCatch(L6,L7,new DexLabel[]{L8},new String[]{ null});
                DexLabel L9=new DexLabel();
                DexLabel L10=new DexLabel();
                code.visitTryCatch(L7,L9,new DexLabel[]{L10},new String[]{ null});
                DexLabel L11=new DexLabel();
                DexLabel L12=new DexLabel();
                code.visitTryCatch(L11,L12,new DexLabel[]{L8},new String[]{ null});
                DexLabel L13=new DexLabel();
                DexLabel L14=new DexLabel();
                DexLabel L15=new DexLabel();
                code.visitTryCatch(L13,L14,new DexLabel[]{L15},new String[]{ null});
                DexLabel L16=new DexLabel();
                DexLabel L17=new DexLabel();
                code.visitTryCatch(L16,L17,new DexLabel[]{L3},new String[]{ null});
                DexLabel L18=new DexLabel();
                DexLabel L19=new DexLabel();
                code.visitTryCatch(L18,L19,new DexLabel[]{L15},new String[]{ null});
                DexLabel L20=new DexLabel();
                DexLabel L21=new DexLabel();
                DexLabel L22=new DexLabel();
                code.visitTryCatch(L20,L21,new DexLabel[]{L22},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"acceptorID");
                DexLabel L23=new DexLabel();
                ddv.visitPrologue(L23);
                ddv.visitLineNumber(161,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(163,L24);
                ddv.visitStartLocal(0,L24,"connection","Lorg/mortbay/jetty/HttpConnection;",null);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(165,L25);
                ddv.visitLineNumber(169,L0);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(170,L26);
                ddv.visitLineNumber(172,L2);
                ddv.visitLineNumber(174,L4);
                ddv.visitStartLocal(2,L4,"e","Ljava/lang/InterruptedException;",null);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(203,L27);
                ddv.visitEndLocal(2,L27);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(176,L28);
                ddv.visitLineNumber(180,L5);
                ddv.visitLineNumber(182,L6);
                ddv.visitLineNumber(183,L7);
                ddv.visitStartLocal(1,L7,"connection","Lorg/mortbay/jetty/HttpConnection;",null);
                ddv.visitEndLocal(0,L9);
                ddv.visitLineNumber(185,L11);
                ddv.visitEndLocal(1,L11);
                ddv.visitRestartLocal(0,L11);
                DexLabel L29=new DexLabel();
                ddv.visitLineNumber(186,L29);
                ddv.visitLineNumber(190,L8);
                DexLabel L30=new DexLabel();
                ddv.visitLineNumber(192,L30);
                DexLabel L31=new DexLabel();
                ddv.visitLineNumber(193,L31);
                DexLabel L32=new DexLabel();
                ddv.visitLineNumber(194,L32);
                DexLabel L33=new DexLabel();
                ddv.visitLineNumber(196,L33);
                DexLabel L34=new DexLabel();
                ddv.visitLineNumber(198,L34);
                DexLabel L35=new DexLabel();
                ddv.visitLineNumber(199,L35);
                DexLabel L36=new DexLabel();
                ddv.visitLineNumber(200,L36);
                ddv.visitLineNumber(190,L14);
                ddv.visitLineNumber(176,L3);
                ddv.visitLineNumber(200,L15);
                DexLabel L37=new DexLabel();
                ddv.visitLineNumber(190,L37);
                DexLabel L38=new DexLabel();
                ddv.visitLineNumber(192,L38);
                DexLabel L39=new DexLabel();
                ddv.visitLineNumber(193,L39);
                DexLabel L40=new DexLabel();
                ddv.visitLineNumber(194,L40);
                DexLabel L41=new DexLabel();
                ddv.visitLineNumber(196,L41);
                DexLabel L42=new DexLabel();
                ddv.visitLineNumber(198,L42);
                DexLabel L43=new DexLabel();
                ddv.visitLineNumber(199,L43);
                DexLabel L44=new DexLabel();
                ddv.visitLineNumber(200,L44);
                ddv.visitLineNumber(190,L10);
                ddv.visitEndLocal(0,L10);
                ddv.visitRestartLocal(1,L10);
                DexLabel L45=new DexLabel();
                ddv.visitRestartLocal(0,L45);
                code.visitLabel(L23);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L24);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/jetty/LocalConnector;","isRunning",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_EQZ,3,-1,L27);
                code.visitLabel(L25);
                code.visitStmt1R(MONITOR_ENTER,5);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_BOOLEAN,3,5,new Field("Lorg/mortbay/jetty/LocalConnector;","_accepting","Z"));
                code.visitJumpStmt(IF_NEZ,3,-1,L28);
                code.visitLabel(L26);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/lang/Object;","wait",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitJumpStmt(GOTO,-1,-1,L0);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,3);
                code.visitStmt2R(MOVE_OBJECT,2,3);
                code.visitLabel(L4);
                code.visitStmt1R(MONITOR_EXIT,5);
                code.visitLabel(L27);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L28);
                code.visitStmt1R(MONITOR_EXIT,5);
                code.visitLabel(L5);
                code.visitJumpStmt(IF_NEZ,0,-1,L11);
                code.visitLabel(L6);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Lorg/mortbay/jetty/HttpConnection;");
                code.visitFieldStmt(IGET_OBJECT,3,5,new Field("Lorg/mortbay/jetty/LocalConnector;","_endp","Lorg/mortbay/io/ByteArrayEndPoint;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/jetty/LocalConnector;","getServer",new String[]{ },"Lorg/mortbay/jetty/Server;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,5,3,4},new Method("Lorg/mortbay/jetty/HttpConnection;","<init>",new String[]{ "Lorg/mortbay/jetty/Connector;","Lorg/mortbay/io/EndPoint;","Lorg/mortbay/jetty/Server;"},"V"));
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,1},new Method("Lorg/mortbay/jetty/LocalConnector;","connectionOpened",new String[]{ "Lorg/mortbay/jetty/HttpConnection;"},"V"));
                code.visitLabel(L9);
                code.visitStmt2R(MOVE_OBJECT,0,1);
                code.visitLabel(L11);
                code.visitFieldStmt(IGET_OBJECT,3,5,new Field("Lorg/mortbay/jetty/LocalConnector;","_in","Lorg/mortbay/io/ByteArrayBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/io/ByteArrayBuffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_LEZ,3,-1,L37);
                code.visitLabel(L29);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/HttpConnection;","handle",new String[]{ },"V"));
                code.visitLabel(L12);
                code.visitJumpStmt(GOTO,-1,-1,L11);
                code.visitLabel(L8);
                code.visitStmt1R(MOVE_EXCEPTION,3);
                DexLabel L46=new DexLabel();
                code.visitLabel(L46);
                code.visitFieldStmt(IGET_BOOLEAN,4,5,new Field("Lorg/mortbay/jetty/LocalConnector;","_keepOpen","Z"));
                code.visitJumpStmt(IF_NEZ,4,-1,L33);
                code.visitLabel(L30);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,0},new Method("Lorg/mortbay/jetty/LocalConnector;","connectionClosed",new String[]{ "Lorg/mortbay/jetty/HttpConnection;"},"V"));
                code.visitLabel(L31);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/HttpConnection;","destroy",new String[]{ },"V"));
                code.visitLabel(L32);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L33);
                code.visitStmt1R(MONITOR_ENTER,5);
                code.visitLabel(L34);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L13);
                code.visitFieldStmt(IPUT_BOOLEAN,4,5,new Field("Lorg/mortbay/jetty/LocalConnector;","_accepting","Z"));
                code.visitLabel(L35);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/lang/Object;","notify",new String[]{ },"V"));
                code.visitLabel(L36);
                code.visitStmt1R(MONITOR_EXIT,5);
                code.visitLabel(L14);
                code.visitStmt1R(THROW,3);
                code.visitLabel(L3);
                code.visitStmt1R(MOVE_EXCEPTION,3);
                code.visitLabel(L16);
                code.visitStmt1R(MONITOR_EXIT,5);
                code.visitLabel(L17);
                code.visitStmt1R(THROW,3);
                code.visitLabel(L15);
                code.visitStmt1R(MOVE_EXCEPTION,3);
                code.visitLabel(L18);
                code.visitStmt1R(MONITOR_EXIT,5);
                code.visitLabel(L19);
                code.visitStmt1R(THROW,3);
                code.visitLabel(L37);
                code.visitFieldStmt(IGET_BOOLEAN,3,5,new Field("Lorg/mortbay/jetty/LocalConnector;","_keepOpen","Z"));
                code.visitJumpStmt(IF_NEZ,3,-1,L41);
                code.visitLabel(L38);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,0},new Method("Lorg/mortbay/jetty/LocalConnector;","connectionClosed",new String[]{ "Lorg/mortbay/jetty/HttpConnection;"},"V"));
                code.visitLabel(L39);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/HttpConnection;","destroy",new String[]{ },"V"));
                code.visitLabel(L40);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L41);
                code.visitStmt1R(MONITOR_ENTER,5);
                code.visitLabel(L42);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L20);
                code.visitFieldStmt(IPUT_BOOLEAN,3,5,new Field("Lorg/mortbay/jetty/LocalConnector;","_accepting","Z"));
                code.visitLabel(L43);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/lang/Object;","notify",new String[]{ },"V"));
                code.visitLabel(L44);
                code.visitStmt1R(MONITOR_EXIT,5);
                code.visitJumpStmt(GOTO,-1,-1,L24);
                code.visitLabel(L22);
                code.visitStmt1R(MOVE_EXCEPTION,3);
                code.visitStmt1R(MONITOR_EXIT,5);
                code.visitLabel(L21);
                code.visitStmt1R(THROW,3);
                code.visitLabel(L10);
                code.visitStmt1R(MOVE_EXCEPTION,3);
                code.visitStmt2R(MOVE_OBJECT,0,1);
                code.visitLabel(L45);
                code.visitJumpStmt(GOTO,-1,-1,L46);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_clear(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/LocalConnector;","clear",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(55,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(56,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(57,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/LocalConnector;","_in","Lorg/mortbay/io/ByteArrayBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/io/ByteArrayBuffer;","clear",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/LocalConnector;","_out","Lorg/mortbay/io/ByteArrayBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/io/ByteArrayBuffer;","clear",new String[]{ },"V"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_close(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/LocalConnector;","close",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(212,L0);
                code.visitLabel(L0);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_doStart(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/LocalConnector;","doStart",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/Exception;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(75,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(76,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(77,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(78,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(79,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(80,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(81,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(83,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(84,L9);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_16,1, Integer.valueOf(8192)); // int: 0x00002000  float:0.000000
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/io/ByteArrayBuffer;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Lorg/mortbay/io/ByteArrayBuffer;","<init>",new String[]{ "I"},"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/jetty/LocalConnector;","_in","Lorg/mortbay/io/ByteArrayBuffer;"));
                code.visitLabel(L2);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/io/ByteArrayBuffer;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Lorg/mortbay/io/ByteArrayBuffer;","<init>",new String[]{ "I"},"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/jetty/LocalConnector;","_out","Lorg/mortbay/io/ByteArrayBuffer;"));
                code.visitLabel(L3);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/io/ByteArrayEndPoint;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Lorg/mortbay/io/ByteArrayEndPoint;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/jetty/LocalConnector;","_endp","Lorg/mortbay/io/ByteArrayEndPoint;"));
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/LocalConnector;","_endp","Lorg/mortbay/io/ByteArrayEndPoint;"));
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/LocalConnector;","_in","Lorg/mortbay/io/ByteArrayBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/io/ByteArrayEndPoint;","setIn",new String[]{ "Lorg/mortbay/io/ByteArrayBuffer;"},"V"));
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/LocalConnector;","_endp","Lorg/mortbay/io/ByteArrayEndPoint;"));
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/LocalConnector;","_out","Lorg/mortbay/io/ByteArrayBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/io/ByteArrayEndPoint;","setOut",new String[]{ "Lorg/mortbay/io/ByteArrayBuffer;"},"V"));
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/LocalConnector;","_endp","Lorg/mortbay/io/ByteArrayEndPoint;"));
                code.visitConstStmt(CONST_4,1, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/io/ByteArrayEndPoint;","setGrowOutput",new String[]{ "Z"},"V"));
                code.visitLabel(L7);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_BOOLEAN,0,2,new Field("Lorg/mortbay/jetty/LocalConnector;","_accepting","Z"));
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 2},new Method("Lorg/mortbay/jetty/AbstractConnector;","doStart",new String[]{ },"V"));
                code.visitLabel(L9);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_getConnection(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/LocalConnector;","getConnection",new String[]{ },"Ljava/lang/Object;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(41,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/LocalConnector;","_endp","Lorg/mortbay/io/ByteArrayEndPoint;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_getLocalPort(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/LocalConnector;","getLocalPort",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(217,L0);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(-1)); // int: 0xffffffff  float:NaN
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m007_getResponses(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/LocalConnector;","getResponses",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/Exception;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"requests");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(90,L0);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2,0},new Method("Lorg/mortbay/jetty/LocalConnector;","getResponses",new String[]{ "Ljava/lang/String;","Z"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m008_getResponses(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/LocalConnector;","getResponses",new String[]{ "Ljava/lang/String;","Z"},"Ljava/lang/String;"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/Exception;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"requests");
                ddv.visitParameterName(1,"keepOpen");
                DexLabel L5=new DexLabel();
                ddv.visitPrologue(L5);
                ddv.visitLineNumber(99,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(100,L6);
                ddv.visitStartLocal(0,L6,"buf","Lorg/mortbay/io/ByteArrayBuffer;",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(102,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(103,L8);
                ddv.visitStartLocal(1,L8,"n","Lorg/mortbay/io/ByteArrayBuffer;",null);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(104,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(105,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(107,L11);
                ddv.visitEndLocal(1,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(109,L12);
                ddv.visitLineNumber(111,L0);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(112,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(113,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(115,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(116,L16);
                ddv.visitLineNumber(117,L2);
                ddv.visitLineNumber(120,L4);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(121,L17);
                code.visitLabel(L5);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/io/ByteArrayBuffer;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,5},new Method("Lorg/mortbay/io/ByteArrayBuffer;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,2,4,new Field("Lorg/mortbay/jetty/LocalConnector;","_in","Lorg/mortbay/io/ByteArrayBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/io/ByteArrayBuffer;","space",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/io/ByteArrayBuffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_GE,2,3,L11);
                code.visitLabel(L7);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Lorg/mortbay/io/ByteArrayBuffer;");
                code.visitFieldStmt(IGET_OBJECT,2,4,new Field("Lorg/mortbay/jetty/LocalConnector;","_in","Lorg/mortbay/io/ByteArrayBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/io/ByteArrayBuffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/io/ByteArrayBuffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitStmt2R(ADD_INT_2ADDR,2,3);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,2},new Method("Lorg/mortbay/io/ByteArrayBuffer;","<init>",new String[]{ "I"},"V"));
                code.visitLabel(L8);
                code.visitFieldStmt(IGET_OBJECT,2,4,new Field("Lorg/mortbay/jetty/LocalConnector;","_in","Lorg/mortbay/io/ByteArrayBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Lorg/mortbay/io/ByteArrayBuffer;","put",new String[]{ "Lorg/mortbay/io/Buffer;"},"I"));
                code.visitLabel(L9);
                code.visitFieldStmt(IPUT_OBJECT,1,4,new Field("Lorg/mortbay/jetty/LocalConnector;","_in","Lorg/mortbay/io/ByteArrayBuffer;"));
                code.visitLabel(L10);
                code.visitFieldStmt(IGET_OBJECT,2,4,new Field("Lorg/mortbay/jetty/LocalConnector;","_endp","Lorg/mortbay/io/ByteArrayEndPoint;"));
                code.visitFieldStmt(IGET_OBJECT,3,4,new Field("Lorg/mortbay/jetty/LocalConnector;","_in","Lorg/mortbay/io/ByteArrayBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Lorg/mortbay/io/ByteArrayEndPoint;","setIn",new String[]{ "Lorg/mortbay/io/ByteArrayBuffer;"},"V"));
                code.visitLabel(L11);
                code.visitFieldStmt(IGET_OBJECT,2,4,new Field("Lorg/mortbay/jetty/LocalConnector;","_in","Lorg/mortbay/io/ByteArrayBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,0},new Method("Lorg/mortbay/io/ByteArrayBuffer;","put",new String[]{ "Lorg/mortbay/io/Buffer;"},"I"));
                code.visitLabel(L12);
                code.visitStmt1R(MONITOR_ENTER,4);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_BOOLEAN,6,4,new Field("Lorg/mortbay/jetty/LocalConnector;","_keepOpen","Z"));
                code.visitLabel(L13);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitFieldStmt(IPUT_BOOLEAN,2,4,new Field("Lorg/mortbay/jetty/LocalConnector;","_accepting","Z"));
                code.visitLabel(L14);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/lang/Object;","notify",new String[]{ },"V"));
                code.visitLabel(L15);
                code.visitFieldStmt(IGET_BOOLEAN,2,4,new Field("Lorg/mortbay/jetty/LocalConnector;","_accepting","Z"));
                code.visitJumpStmt(IF_EQZ,2,-1,L3);
                code.visitLabel(L16);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/lang/Object;","wait",new String[]{ },"V"));
                code.visitJumpStmt(GOTO,-1,-1,L15);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,2);
                code.visitStmt1R(MONITOR_EXIT,4);
                code.visitLabel(L1);
                code.visitStmt1R(THROW,2);
                code.visitLabel(L3);
                code.visitStmt1R(MONITOR_EXIT,4);
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,2,4,new Field("Lorg/mortbay/jetty/LocalConnector;","_endp","Lorg/mortbay/io/ByteArrayEndPoint;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/io/ByteArrayEndPoint;","getOut",new String[]{ },"Lorg/mortbay/io/ByteArrayBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitFieldStmt(IPUT_OBJECT,2,4,new Field("Lorg/mortbay/jetty/LocalConnector;","_out","Lorg/mortbay/io/ByteArrayBuffer;"));
                code.visitLabel(L17);
                code.visitFieldStmt(IGET_OBJECT,2,4,new Field("Lorg/mortbay/jetty/LocalConnector;","_out","Lorg/mortbay/io/ByteArrayBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/io/ByteArrayBuffer;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitStmt1R(RETURN_OBJECT,2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m009_getResponses(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/LocalConnector;","getResponses",new String[]{ "Lorg/mortbay/io/ByteArrayBuffer;","Z"},"Lorg/mortbay/io/ByteArrayBuffer;"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/Exception;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"buf");
                ddv.visitParameterName(1,"keepOpen");
                DexLabel L5=new DexLabel();
                ddv.visitPrologue(L5);
                ddv.visitLineNumber(128,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(130,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(131,L7);
                ddv.visitStartLocal(0,L7,"n","Lorg/mortbay/io/ByteArrayBuffer;",null);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(132,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(133,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(135,L10);
                ddv.visitEndLocal(0,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(137,L11);
                ddv.visitLineNumber(139,L0);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(140,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(141,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(143,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(144,L15);
                ddv.visitLineNumber(145,L2);
                ddv.visitLineNumber(148,L4);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(149,L16);
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/jetty/LocalConnector;","_in","Lorg/mortbay/io/ByteArrayBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/io/ByteArrayBuffer;","space",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/io/ByteArrayBuffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_GE,1,2,L10);
                code.visitLabel(L6);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/io/ByteArrayBuffer;");
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/jetty/LocalConnector;","_in","Lorg/mortbay/io/ByteArrayBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/io/ByteArrayBuffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/io/ByteArrayBuffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitStmt2R(ADD_INT_2ADDR,1,2);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Lorg/mortbay/io/ByteArrayBuffer;","<init>",new String[]{ "I"},"V"));
                code.visitLabel(L7);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/jetty/LocalConnector;","_in","Lorg/mortbay/io/ByteArrayBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/io/ByteArrayBuffer;","put",new String[]{ "Lorg/mortbay/io/Buffer;"},"I"));
                code.visitLabel(L8);
                code.visitFieldStmt(IPUT_OBJECT,0,3,new Field("Lorg/mortbay/jetty/LocalConnector;","_in","Lorg/mortbay/io/ByteArrayBuffer;"));
                code.visitLabel(L9);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/jetty/LocalConnector;","_endp","Lorg/mortbay/io/ByteArrayEndPoint;"));
                code.visitFieldStmt(IGET_OBJECT,2,3,new Field("Lorg/mortbay/jetty/LocalConnector;","_in","Lorg/mortbay/io/ByteArrayBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Lorg/mortbay/io/ByteArrayEndPoint;","setIn",new String[]{ "Lorg/mortbay/io/ByteArrayBuffer;"},"V"));
                code.visitLabel(L10);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/jetty/LocalConnector;","_in","Lorg/mortbay/io/ByteArrayBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,4},new Method("Lorg/mortbay/io/ByteArrayBuffer;","put",new String[]{ "Lorg/mortbay/io/Buffer;"},"I"));
                code.visitLabel(L11);
                code.visitStmt1R(MONITOR_ENTER,3);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_BOOLEAN,5,3,new Field("Lorg/mortbay/jetty/LocalConnector;","_keepOpen","Z"));
                code.visitLabel(L12);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitFieldStmt(IPUT_BOOLEAN,1,3,new Field("Lorg/mortbay/jetty/LocalConnector;","_accepting","Z"));
                code.visitLabel(L13);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/lang/Object;","notify",new String[]{ },"V"));
                code.visitLabel(L14);
                code.visitFieldStmt(IGET_BOOLEAN,1,3,new Field("Lorg/mortbay/jetty/LocalConnector;","_accepting","Z"));
                code.visitJumpStmt(IF_EQZ,1,-1,L3);
                code.visitLabel(L15);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/lang/Object;","wait",new String[]{ },"V"));
                code.visitJumpStmt(GOTO,-1,-1,L14);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitStmt1R(MONITOR_EXIT,3);
                code.visitLabel(L1);
                code.visitStmt1R(THROW,1);
                code.visitLabel(L3);
                code.visitStmt1R(MONITOR_EXIT,3);
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/jetty/LocalConnector;","_endp","Lorg/mortbay/io/ByteArrayEndPoint;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/io/ByteArrayEndPoint;","getOut",new String[]{ },"Lorg/mortbay/io/ByteArrayBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitFieldStmt(IPUT_OBJECT,1,3,new Field("Lorg/mortbay/jetty/LocalConnector;","_out","Lorg/mortbay/io/ByteArrayBuffer;"));
                code.visitLabel(L16);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/jetty/LocalConnector;","_out","Lorg/mortbay/io/ByteArrayBuffer;"));
                code.visitStmt1R(RETURN_OBJECT,1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m010_newBuffer(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/LocalConnector;","newBuffer",new String[]{ "I"},"Lorg/mortbay/io/Buffer;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"size");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(155,L0);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/io/ByteArrayBuffer;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,2},new Method("Lorg/mortbay/io/ByteArrayBuffer;","<init>",new String[]{ "I"},"V"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m011_open(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/LocalConnector;","open",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(208,L0);
                code.visitLabel(L0);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m012_reopen(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/LocalConnector;","reopen",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(62,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(63,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(64,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(65,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(66,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(67,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(68,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(69,L7);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/LocalConnector;","_in","Lorg/mortbay/io/ByteArrayBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/io/ByteArrayBuffer;","clear",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/LocalConnector;","_out","Lorg/mortbay/io/ByteArrayBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/io/ByteArrayBuffer;","clear",new String[]{ },"V"));
                code.visitLabel(L2);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/io/ByteArrayEndPoint;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Lorg/mortbay/io/ByteArrayEndPoint;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/jetty/LocalConnector;","_endp","Lorg/mortbay/io/ByteArrayEndPoint;"));
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/LocalConnector;","_endp","Lorg/mortbay/io/ByteArrayEndPoint;"));
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/LocalConnector;","_in","Lorg/mortbay/io/ByteArrayBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/io/ByteArrayEndPoint;","setIn",new String[]{ "Lorg/mortbay/io/ByteArrayBuffer;"},"V"));
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/LocalConnector;","_endp","Lorg/mortbay/io/ByteArrayEndPoint;"));
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/LocalConnector;","_out","Lorg/mortbay/io/ByteArrayBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/io/ByteArrayEndPoint;","setOut",new String[]{ "Lorg/mortbay/io/ByteArrayBuffer;"},"V"));
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/LocalConnector;","_endp","Lorg/mortbay/io/ByteArrayEndPoint;"));
                code.visitConstStmt(CONST_4,1, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/io/ByteArrayEndPoint;","setGrowOutput",new String[]{ "Z"},"V"));
                code.visitLabel(L6);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_BOOLEAN,0,2,new Field("Lorg/mortbay/jetty/LocalConnector;","_accepting","Z"));
                code.visitLabel(L7);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m013_setServer(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/LocalConnector;","setServer",new String[]{ "Lorg/mortbay/jetty/Server;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"server");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(48,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(49,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(50,L2);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/AbstractConnector;","setServer",new String[]{ "Lorg/mortbay/jetty/Server;"},"V"));
                code.visitLabel(L1);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/LocalConnector;","_server","Lorg/mortbay/jetty/Server;"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
