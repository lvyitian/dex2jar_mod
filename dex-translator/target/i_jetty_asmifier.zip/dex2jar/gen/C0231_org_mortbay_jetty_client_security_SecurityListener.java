package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0231_org_mortbay_jetty_client_security_SecurityListener {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/jetty/client/security/SecurityListener;","Lorg/mortbay/jetty/client/HttpEventListenerWrapper;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("SecurityListener.java");
        f000__attempts(cv);
        f001__destination(cv);
        f002__exchange(cv);
        f003__needIntercept(cv);
        f004__requestComplete(cv);
        f005__responseComplete(cv);
        m000__init_(cv);
        m001_onRequestComplete(cv);
        m002_onResponseComplete(cv);
        m003_onResponseHeader(cv);
        m004_onResponseStatus(cv);
        m005_onRetry(cv);
        m006_scrapeAuthenticationDetails(cv);
        m007_scrapeAuthenticationType(cv);
    }
    public static void f000__attempts(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/client/security/SecurityListener;","_attempts","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001__destination(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/client/security/SecurityListener;","_destination","Lorg/mortbay/jetty/client/HttpDestination;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002__exchange(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/client/security/SecurityListener;","_exchange","Lorg/mortbay/jetty/client/HttpExchange;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003__needIntercept(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/client/security/SecurityListener;","_needIntercept","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f004__requestComplete(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/client/security/SecurityListener;","_requestComplete","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f005__responseComplete(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/client/security/SecurityListener;","_responseComplete","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/client/security/SecurityListener;","<init>",new String[]{ "Lorg/mortbay/jetty/client/HttpDestination;","Lorg/mortbay/jetty/client/HttpExchange;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"destination");
                ddv.visitParameterName(1,"ex");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(53,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(47,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(54,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(55,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(56,L4);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/jetty/client/HttpExchange;","getEventListener",new String[]{ },"Lorg/mortbay/jetty/client/HttpEventListener;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2,0,1},new Method("Lorg/mortbay/jetty/client/HttpEventListenerWrapper;","<init>",new String[]{ "Lorg/mortbay/jetty/client/HttpEventListener;","Z"},"V"));
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT,0,2,new Field("Lorg/mortbay/jetty/client/security/SecurityListener;","_attempts","I"));
                code.visitLabel(L2);
                code.visitFieldStmt(IPUT_OBJECT,3,2,new Field("Lorg/mortbay/jetty/client/security/SecurityListener;","_destination","Lorg/mortbay/jetty/client/HttpDestination;"));
                code.visitLabel(L3);
                code.visitFieldStmt(IPUT_OBJECT,4,2,new Field("Lorg/mortbay/jetty/client/security/SecurityListener;","_exchange","Lorg/mortbay/jetty/client/HttpExchange;"));
                code.visitLabel(L4);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001_onRequestComplete(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/client/security/SecurityListener;","onRequestComplete",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(189,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(191,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(193,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(195,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(196,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(197,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(198,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(199,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(200,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(201,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(216,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(205,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(206,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(207,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(212,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(213,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(214,L17);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitConstStmt(CONST_4,2, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L1);
                code.visitFieldStmt(IPUT_BOOLEAN,2,4,new Field("Lorg/mortbay/jetty/client/security/SecurityListener;","_requestComplete","Z"));
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_BOOLEAN,0,4,new Field("Lorg/mortbay/jetty/client/security/SecurityListener;","_needIntercept","Z"));
                code.visitJumpStmt(IF_EQZ,0,-1,L15);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_BOOLEAN,0,4,new Field("Lorg/mortbay/jetty/client/security/SecurityListener;","_requestComplete","Z"));
                code.visitJumpStmt(IF_EQZ,0,-1,L12);
                code.visitFieldStmt(IGET_BOOLEAN,0,4,new Field("Lorg/mortbay/jetty/client/security/SecurityListener;","_responseComplete","Z"));
                code.visitJumpStmt(IF_EQZ,0,-1,L12);
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/log/Log;","isDebugEnabled",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L6);
                code.visitLabel(L5);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,1,"onRequestComplete, Both complete: Resending from onResponseComplete ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/jetty/client/security/SecurityListener;","_exchange","Lorg/mortbay/jetty/client/HttpExchange;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L6);
                code.visitFieldStmt(IPUT_BOOLEAN,3,4,new Field("Lorg/mortbay/jetty/client/security/SecurityListener;","_responseComplete","Z"));
                code.visitLabel(L7);
                code.visitFieldStmt(IPUT_BOOLEAN,3,4,new Field("Lorg/mortbay/jetty/client/security/SecurityListener;","_requestComplete","Z"));
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,2},new Method("Lorg/mortbay/jetty/client/security/SecurityListener;","setDelegatingRequests",new String[]{ "Z"},"V"));
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,2},new Method("Lorg/mortbay/jetty/client/security/SecurityListener;","setDelegatingResponses",new String[]{ "Z"},"V"));
                code.visitLabel(L10);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/jetty/client/security/SecurityListener;","_destination","Lorg/mortbay/jetty/client/HttpDestination;"));
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/jetty/client/security/SecurityListener;","_exchange","Lorg/mortbay/jetty/client/HttpExchange;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/client/HttpDestination;","resend",new String[]{ "Lorg/mortbay/jetty/client/HttpExchange;"},"V"));
                code.visitLabel(L11);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L12);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/log/Log;","isDebugEnabled",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L14);
                code.visitLabel(L13);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,1,"onRequestComplete, Response not yet complete onRequestComplete, calling super for ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/jetty/client/security/SecurityListener;","_exchange","Lorg/mortbay/jetty/client/HttpExchange;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L14);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 4},new Method("Lorg/mortbay/jetty/client/HttpEventListenerWrapper;","onRequestComplete",new String[]{ },"V"));
                code.visitJumpStmt(GOTO,-1,-1,L11);
                code.visitLabel(L15);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/log/Log;","isDebugEnabled",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L17);
                code.visitLabel(L16);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,1,"onRequestComplete, delegating to super with Request complete=");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IGET_BOOLEAN,1,4,new Field("Lorg/mortbay/jetty/client/security/SecurityListener;","_requestComplete","Z"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Z"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitConstStmt(CONST_STRING,1,", response complete=");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IGET_BOOLEAN,1,4,new Field("Lorg/mortbay/jetty/client/security/SecurityListener;","_responseComplete","Z"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Z"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitConstStmt(CONST_STRING,1," ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/jetty/client/security/SecurityListener;","_exchange","Lorg/mortbay/jetty/client/HttpExchange;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L17);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 4},new Method("Lorg/mortbay/jetty/client/HttpEventListenerWrapper;","onRequestComplete",new String[]{ },"V"));
                code.visitJumpStmt(GOTO,-1,-1,L11);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_onResponseComplete(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/client/security/SecurityListener;","onResponseComplete",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(221,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(222,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(224,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(226,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(227,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(228,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(229,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(230,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(231,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(232,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(248,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(237,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(238,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(239,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(244,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(245,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(246,L17);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitConstStmt(CONST_4,2, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L1);
                code.visitFieldStmt(IPUT_BOOLEAN,2,4,new Field("Lorg/mortbay/jetty/client/security/SecurityListener;","_responseComplete","Z"));
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_BOOLEAN,0,4,new Field("Lorg/mortbay/jetty/client/security/SecurityListener;","_needIntercept","Z"));
                code.visitJumpStmt(IF_EQZ,0,-1,L15);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_BOOLEAN,0,4,new Field("Lorg/mortbay/jetty/client/security/SecurityListener;","_requestComplete","Z"));
                code.visitJumpStmt(IF_EQZ,0,-1,L12);
                code.visitFieldStmt(IGET_BOOLEAN,0,4,new Field("Lorg/mortbay/jetty/client/security/SecurityListener;","_responseComplete","Z"));
                code.visitJumpStmt(IF_EQZ,0,-1,L12);
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/log/Log;","isDebugEnabled",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L6);
                code.visitLabel(L5);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,1,"onResponseComplete, Both complete: Resending from onResponseComplete");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/jetty/client/security/SecurityListener;","_exchange","Lorg/mortbay/jetty/client/HttpExchange;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L6);
                code.visitFieldStmt(IPUT_BOOLEAN,3,4,new Field("Lorg/mortbay/jetty/client/security/SecurityListener;","_responseComplete","Z"));
                code.visitLabel(L7);
                code.visitFieldStmt(IPUT_BOOLEAN,3,4,new Field("Lorg/mortbay/jetty/client/security/SecurityListener;","_requestComplete","Z"));
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,2},new Method("Lorg/mortbay/jetty/client/security/SecurityListener;","setDelegatingResponses",new String[]{ "Z"},"V"));
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,2},new Method("Lorg/mortbay/jetty/client/security/SecurityListener;","setDelegatingRequests",new String[]{ "Z"},"V"));
                code.visitLabel(L10);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/jetty/client/security/SecurityListener;","_destination","Lorg/mortbay/jetty/client/HttpDestination;"));
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/jetty/client/security/SecurityListener;","_exchange","Lorg/mortbay/jetty/client/HttpExchange;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/client/HttpDestination;","resend",new String[]{ "Lorg/mortbay/jetty/client/HttpExchange;"},"V"));
                code.visitLabel(L11);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L12);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/log/Log;","isDebugEnabled",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L14);
                code.visitLabel(L13);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,1,"onResponseComplete, Request not yet complete from onResponseComplete,  calling super ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/jetty/client/security/SecurityListener;","_exchange","Lorg/mortbay/jetty/client/HttpExchange;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L14);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 4},new Method("Lorg/mortbay/jetty/client/HttpEventListenerWrapper;","onResponseComplete",new String[]{ },"V"));
                code.visitJumpStmt(GOTO,-1,-1,L11);
                code.visitLabel(L15);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/log/Log;","isDebugEnabled",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L17);
                code.visitLabel(L16);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,1,"OnResponseComplete, delegating to super with Request complete=");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IGET_BOOLEAN,1,4,new Field("Lorg/mortbay/jetty/client/security/SecurityListener;","_requestComplete","Z"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Z"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitConstStmt(CONST_STRING,1,", response complete=");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IGET_BOOLEAN,1,4,new Field("Lorg/mortbay/jetty/client/security/SecurityListener;","_responseComplete","Z"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Z"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitConstStmt(CONST_STRING,1," ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/jetty/client/security/SecurityListener;","_exchange","Lorg/mortbay/jetty/client/HttpExchange;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L17);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 4},new Method("Lorg/mortbay/jetty/client/HttpEventListenerWrapper;","onResponseComplete",new String[]{ },"V"));
                code.visitJumpStmt(GOTO,-1,-1,L11);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_onResponseHeader(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/client/security/SecurityListener;","onResponseHeader",new String[]{ "Lorg/mortbay/io/Buffer;","Lorg/mortbay/io/Buffer;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(13);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                ddv.visitParameterName(1,"value");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(139,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(140,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(143,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(145,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(146,L5);
                ddv.visitStartLocal(2,L5,"header","I",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(183,L6);
                ddv.visitEndLocal(2,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(184,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(151,L8);
                ddv.visitRestartLocal(2,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(152,L9);
                ddv.visitStartLocal(0,L9,"authString","Ljava/lang/String;",null);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(155,L10);
                ddv.visitStartLocal(6,L10,"type","Ljava/lang/String;",null);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(156,L11);
                ddv.visitStartLocal(1,L11,"details","Ljava/util/Map;","Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>;");
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(157,L12);
                ddv.visitStartLocal(3,L12,"pathSpec","Ljava/lang/String;",null);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(159,L13);
                ddv.visitStartLocal(5,L13,"realmResolver","Lorg/mortbay/jetty/client/security/RealmResolver;",null);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(164,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(166,L15);
                ddv.visitStartLocal(4,L15,"realm","Lorg/mortbay/jetty/client/security/Realm;",null);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(168,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(170,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(172,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(175,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(177,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(146,L21);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_STRING,9,"realm");
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/log/Log;","isDebugEnabled",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitJumpStmt(IF_EQZ,7,-1,L3);
                code.visitLabel(L2);
                code.visitTypeStmt(NEW_INSTANCE,7,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 7},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,8,"SecurityListener:Header: ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,8},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11},new Method("Ljava/lang/Object;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,8},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitConstStmt(CONST_STRING,8," / ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,8},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12},new Method("Ljava/lang/Object;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,8},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 7},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Lorg/mortbay/jetty/client/security/SecurityListener;","isDelegatingResponses",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitJumpStmt(IF_NEZ,7,-1,L6);
                code.visitLabel(L4);
                code.visitFieldStmt(SGET_OBJECT,7,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","CACHE","Lorg/mortbay/jetty/HttpHeaders;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,11},new Method("Lorg/mortbay/jetty/HttpHeaders;","getOrdinal",new String[]{ "Lorg/mortbay/io/Buffer;"},"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitLabel(L5);
                code.visitSparseSwitchStmt(PACKED_SWITCH,2,51,new DexLabel[]{L8});
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 10,11,12},new Method("Lorg/mortbay/jetty/client/HttpEventListenerWrapper;","onResponseHeader",new String[]{ "Lorg/mortbay/io/Buffer;","Lorg/mortbay/io/Buffer;"},"V"));
                code.visitLabel(L7);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12},new Method("Ljava/lang/Object;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10,0},new Method("Lorg/mortbay/jetty/client/security/SecurityListener;","scrapeAuthenticationType",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10,0},new Method("Lorg/mortbay/jetty/client/security/SecurityListener;","scrapeAuthenticationDetails",new String[]{ "Ljava/lang/String;"},"Ljava/util/Map;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L11);
                code.visitConstStmt(CONST_STRING,3,"/");
                code.visitLabel(L12);
                code.visitFieldStmt(IGET_OBJECT,7,10,new Field("Lorg/mortbay/jetty/client/security/SecurityListener;","_destination","Lorg/mortbay/jetty/client/HttpDestination;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Lorg/mortbay/jetty/client/HttpDestination;","getHttpClient",new String[]{ },"Lorg/mortbay/jetty/client/HttpClient;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Lorg/mortbay/jetty/client/HttpClient;","getRealmResolver",new String[]{ },"Lorg/mortbay/jetty/client/security/RealmResolver;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitLabel(L13);
                code.visitJumpStmt(IF_EQZ,5,-1,L6);
                code.visitLabel(L14);
                code.visitConstStmt(CONST_STRING,7,"realm");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1,9},new Method("Ljava/util/Map;","get",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitTypeStmt(CHECK_CAST,7,-1,"Ljava/lang/String;");
                code.visitFieldStmt(IGET_OBJECT,8,10,new Field("Lorg/mortbay/jetty/client/security/SecurityListener;","_destination","Lorg/mortbay/jetty/client/HttpDestination;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 5,7,8,3},new Method("Lorg/mortbay/jetty/client/security/RealmResolver;","getRealm",new String[]{ "Ljava/lang/String;","Lorg/mortbay/jetty/client/HttpDestination;","Ljava/lang/String;"},"Lorg/mortbay/jetty/client/security/Realm;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitLabel(L15);
                code.visitJumpStmt(IF_NEZ,4,-1,L17);
                code.visitLabel(L16);
                code.visitTypeStmt(NEW_INSTANCE,7,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 7},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,8,"Unknown Security Realm: ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,8},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitConstStmt(CONST_STRING,7,"realm");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1,9},new Method("Ljava/util/Map;","get",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitTypeStmt(CHECK_CAST,7,-1,"Ljava/lang/String;");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,7},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 7},new Method("Lorg/mortbay/log/Log;","warn",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L6);
                code.visitLabel(L17);
                code.visitConstStmt(CONST_STRING,7,"digest");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,6},new Method("Ljava/lang/String;","equalsIgnoreCase",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitJumpStmt(IF_EQZ,7,-1,L19);
                code.visitLabel(L18);
                code.visitFieldStmt(IGET_OBJECT,7,10,new Field("Lorg/mortbay/jetty/client/security/SecurityListener;","_destination","Lorg/mortbay/jetty/client/HttpDestination;"));
                code.visitConstStmt(CONST_STRING,8,"/");
                code.visitTypeStmt(NEW_INSTANCE,9,-1,"Lorg/mortbay/jetty/client/security/DigestAuthorization;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 9,4,1},new Method("Lorg/mortbay/jetty/client/security/DigestAuthorization;","<init>",new String[]{ "Lorg/mortbay/jetty/client/security/Realm;","Ljava/util/Map;"},"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,8,9},new Method("Lorg/mortbay/jetty/client/HttpDestination;","addAuthorization",new String[]{ "Ljava/lang/String;","Lorg/mortbay/jetty/client/security/Authorization;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L6);
                code.visitLabel(L19);
                code.visitConstStmt(CONST_STRING,7,"basic");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,6},new Method("Ljava/lang/String;","equalsIgnoreCase",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitJumpStmt(IF_EQZ,7,-1,L6);
                code.visitLabel(L20);
                code.visitFieldStmt(IGET_OBJECT,7,10,new Field("Lorg/mortbay/jetty/client/security/SecurityListener;","_destination","Lorg/mortbay/jetty/client/HttpDestination;"));
                code.visitTypeStmt(NEW_INSTANCE,8,-1,"Lorg/mortbay/jetty/client/security/BasicAuthorization;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 8,4},new Method("Lorg/mortbay/jetty/client/security/BasicAuthorization;","<init>",new String[]{ "Lorg/mortbay/jetty/client/security/Realm;"},"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,3,8},new Method("Lorg/mortbay/jetty/client/HttpDestination;","addAuthorization",new String[]{ "Ljava/lang/String;","Lorg/mortbay/jetty/client/security/Authorization;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L6);
                code.visitLabel(L21);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_onResponseStatus(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/client/security/SecurityListener;","onResponseStatus",new String[]{ "Lorg/mortbay/io/Buffer;","I","Lorg/mortbay/io/Buffer;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(8);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"version");
                ddv.visitParameterName(1,"status");
                ddv.visitParameterName(2,"reason");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(117,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(118,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(120,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(123,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(124,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(132,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(133,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(128,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(129,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(130,L10);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitConstStmt(CONST_4,2, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/log/Log;","isDebugEnabled",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L3);
                code.visitLabel(L2);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,1,"SecurityListener:Response Status: ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,6},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "I"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L3);
                code.visitConstStmt(CONST_16,0, Integer.valueOf(401)); // int: 0x00000191  float:0.000000
                code.visitJumpStmt(IF_NE,6,0,L8);
                code.visitFieldStmt(IGET,0,4,new Field("Lorg/mortbay/jetty/client/security/SecurityListener;","_attempts","I"));
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/jetty/client/security/SecurityListener;","_destination","Lorg/mortbay/jetty/client/HttpDestination;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/jetty/client/HttpDestination;","getHttpClient",new String[]{ },"Lorg/mortbay/jetty/client/HttpClient;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/jetty/client/HttpClient;","maxRetries",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_GE,0,1,L8);
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,3},new Method("Lorg/mortbay/jetty/client/security/SecurityListener;","setDelegatingResponses",new String[]{ "Z"},"V"));
                code.visitLabel(L5);
                code.visitFieldStmt(IPUT_BOOLEAN,2,4,new Field("Lorg/mortbay/jetty/client/security/SecurityListener;","_needIntercept","Z"));
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 4,5,6,7},new Method("Lorg/mortbay/jetty/client/HttpEventListenerWrapper;","onResponseStatus",new String[]{ "Lorg/mortbay/io/Buffer;","I","Lorg/mortbay/io/Buffer;"},"V"));
                code.visitLabel(L7);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,2},new Method("Lorg/mortbay/jetty/client/security/SecurityListener;","setDelegatingResponses",new String[]{ "Z"},"V"));
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,2},new Method("Lorg/mortbay/jetty/client/security/SecurityListener;","setDelegatingRequests",new String[]{ "Z"},"V"));
                code.visitLabel(L10);
                code.visitFieldStmt(IPUT_BOOLEAN,3,4,new Field("Lorg/mortbay/jetty/client/security/SecurityListener;","_needIntercept","Z"));
                code.visitJumpStmt(GOTO,-1,-1,L6);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_onRetry(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/client/security/SecurityListener;","onRetry",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(252,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(253,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(254,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(255,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(256,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(257,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(258,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(259,L8);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitFieldStmt(IGET,0,3,new Field("Lorg/mortbay/jetty/client/security/SecurityListener;","_attempts","I"));
                code.visitStmt2R1N(ADD_INT_LIT8,0,0,1);
                code.visitFieldStmt(IPUT,0,3,new Field("Lorg/mortbay/jetty/client/security/SecurityListener;","_attempts","I"));
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,2},new Method("Lorg/mortbay/jetty/client/security/SecurityListener;","setDelegatingRequests",new String[]{ "Z"},"V"));
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,2},new Method("Lorg/mortbay/jetty/client/security/SecurityListener;","setDelegatingResponses",new String[]{ "Z"},"V"));
                code.visitLabel(L4);
                code.visitFieldStmt(IPUT_BOOLEAN,1,3,new Field("Lorg/mortbay/jetty/client/security/SecurityListener;","_requestComplete","Z"));
                code.visitLabel(L5);
                code.visitFieldStmt(IPUT_BOOLEAN,1,3,new Field("Lorg/mortbay/jetty/client/security/SecurityListener;","_responseComplete","Z"));
                code.visitLabel(L6);
                code.visitFieldStmt(IPUT_BOOLEAN,1,3,new Field("Lorg/mortbay/jetty/client/security/SecurityListener;","_needIntercept","Z"));
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 3},new Method("Lorg/mortbay/jetty/client/HttpEventListenerWrapper;","onRetry",new String[]{ },"V"));
                code.visitLabel(L8);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_scrapeAuthenticationDetails(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/client/security/SecurityListener;","scrapeAuthenticationDetails",new String[]{ "Ljava/lang/String;"},"Ljava/util/Map;"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Signature;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, "(");
                            av01.visit(null, "Ljava/lang/String;");
                            av01.visit(null, ")");
                            av01.visit(null, "Ljava/util/Map");
                            av01.visit(null, "<");
                            av01.visit(null, "Ljava/lang/String;");
                            av01.visit(null, "Ljava/lang/String;");
                            av01.visit(null, ">;");
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(9);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"authString");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(89,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(90,L1);
                ddv.visitStartLocal(0,L1,"authenticationDetails","Ljava/util/Map;","Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>;");
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(91,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(93,L3);
                ddv.visitStartLocal(4,L3,"strtok","Ljava/util/StringTokenizer;",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(95,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(96,L5);
                ddv.visitStartLocal(3,L5,"pair","[Ljava/lang/String;",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(98,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(99,L7);
                ddv.visitStartLocal(1,L7,"itemName","Ljava/lang/String;",null);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(101,L8);
                ddv.visitStartLocal(2,L8,"itemValue","Ljava/lang/String;",null);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(103,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(107,L10);
                ddv.visitEndLocal(1,L10);
                ddv.visitEndLocal(2,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(110,L11);
                ddv.visitEndLocal(3,L11);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/util/HashMap;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/util/HashMap;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitConstStmt(CONST_STRING,5," ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,5},new Method("Ljava/lang/String;","indexOf",new String[]{ "Ljava/lang/String;"},"I"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitStmt2R1N(ADD_INT_LIT8,5,5,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,5,6},new Method("Ljava/lang/String;","substring",new String[]{ "I","I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitLabel(L2);
                code.visitTypeStmt(NEW_INSTANCE,4,-1,"Ljava/util/StringTokenizer;");
                code.visitConstStmt(CONST_STRING,5,",");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4,8,5},new Method("Ljava/util/StringTokenizer;","<init>",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"V"));
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/util/StringTokenizer;","hasMoreTokens",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitJumpStmt(IF_EQZ,5,-1,L11);
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/util/StringTokenizer;","nextToken",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitConstStmt(CONST_STRING,6,"=");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Ljava/lang/String;","split",new String[]{ "Ljava/lang/String;"},"[Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitLabel(L5);
                code.visitStmt2R(ARRAY_LENGTH,5,3);
                code.visitConstStmt(CONST_4,6, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitJumpStmt(IF_NE,5,6,L10);
                code.visitLabel(L6);
                code.visitConstStmt(CONST_4,5, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt3R(AGET_OBJECT,5,3,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/lang/String;","trim",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L7);
                code.visitConstStmt(CONST_4,5, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt3R(AGET_OBJECT,5,3,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/lang/String;","trim",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2},new Method("Lorg/mortbay/util/StringUtil;","unquote",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1,2},new Method("Ljava/util/Map;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitLabel(L10);
                code.visitTypeStmt(NEW_INSTANCE,5,-1,"Ljava/lang/IllegalArgumentException;");
                code.visitConstStmt(CONST_STRING,6,"unable to process authentication details");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 5,6},new Method("Ljava/lang/IllegalArgumentException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,5);
                code.visitLabel(L11);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m007_scrapeAuthenticationType(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/client/security/SecurityListener;","scrapeAuthenticationType",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"authString");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(69,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(71,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(78,L3);
                ddv.visitStartLocal(1,L3,"authType","Ljava/lang/String;",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(75,L4);
                ddv.visitEndLocal(1,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(76,L5);
                ddv.visitStartLocal(0,L5,"authResponse","Ljava/lang/String;",null);
                DexLabel L6=new DexLabel();
                ddv.visitRestartLocal(1,L6);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_STRING,4," ");
                code.visitLabel(L1);
                code.visitConstStmt(CONST_STRING,2," ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,4},new Method("Ljava/lang/String;","indexOf",new String[]{ "Ljava/lang/String;"},"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(-1)); // int: 0xffffffff  float:NaN
                code.visitJumpStmt(IF_NE,2,3,L4);
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/lang/String;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/lang/String;","trim",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L3);
                code.visitStmt1R(RETURN_OBJECT,1);
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/lang/String;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L5);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitConstStmt(CONST_STRING,3," ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,4},new Method("Ljava/lang/String;","indexOf",new String[]{ "Ljava/lang/String;"},"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,2,3},new Method("Ljava/lang/String;","substring",new String[]{ "I","I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/lang/String;","trim",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L6);
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
