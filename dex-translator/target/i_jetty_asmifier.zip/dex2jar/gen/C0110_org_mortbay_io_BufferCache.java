package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0110_org_mortbay_io_BufferCache {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/io/BufferCache;","Ljava/lang/Object;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("BufferCache.java");
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/MemberClasses;", Visibility.SYSTEM);
            if(av00 != null) {
                {
                    DexAnnotationVisitor av01 = av00.visitArray("value");
                    if(av01 != null) {
                        av01.visit(null, new DexType("Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                        av01.visitEnd();
                    }
                }
                av00.visitEnd();
            }
        }
        f000__bufferMap(cv);
        f001__index(cv);
        f002__stringMap(cv);
        m000__init_(cv);
        m001_add(cv);
        m002_get(cv);
        m003_get(cv);
        m004_get(cv);
        m005_getBest(cv);
        m006_getOrdinal(cv);
        m007_lookup(cv);
        m008_lookup(cv);
        m009_toString(cv);
        m010_toString(cv);
    }
    public static void f000__bufferMap(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/io/BufferCache;","_bufferMap","Ljava/util/HashMap;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001__index(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/io/BufferCache;","_index","Ljava/util/ArrayList;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002__stringMap(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/io/BufferCache;","_stringMap","Lorg/mortbay/util/StringMap;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/io/BufferCache;","<init>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(29,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(31,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(32,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(33,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(113,L4);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2},new Method("Ljava/lang/Object;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/util/HashMap;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/util/HashMap;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/io/BufferCache;","_bufferMap","Ljava/util/HashMap;"));
                code.visitLabel(L2);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/util/StringMap;");
                code.visitConstStmt(CONST_4,1, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Lorg/mortbay/util/StringMap;","<init>",new String[]{ "Z"},"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/io/BufferCache;","_stringMap","Lorg/mortbay/util/StringMap;"));
                code.visitLabel(L3);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/util/ArrayList;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/util/ArrayList;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/io/BufferCache;","_index","Ljava/util/ArrayList;"));
                code.visitLabel(L4);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001_add(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/BufferCache;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"value");
                ddv.visitParameterName(1,"ordinal");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(41,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(42,L1);
                ddv.visitStartLocal(0,L1,"buffer","Lorg/mortbay/io/BufferCache$CachedBuffer;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(43,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(44,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(45,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(46,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(47,L6);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/io/BufferCache$CachedBuffer;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,4,5},new Method("Lorg/mortbay/io/BufferCache$CachedBuffer;","<init>",new String[]{ "Ljava/lang/String;","I"},"V"));
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/io/BufferCache;","_bufferMap","Ljava/util/HashMap;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,0,0},new Method("Ljava/util/HashMap;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/io/BufferCache;","_stringMap","Lorg/mortbay/util/StringMap;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,4,0},new Method("Lorg/mortbay/util/StringMap;","put",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/io/BufferCache;","_index","Ljava/util/ArrayList;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/util/ArrayList;","size",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitStmt3R(SUB_INT,1,5,1);
                code.visitJumpStmt(IF_LEZ,1,-1,L5);
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/io/BufferCache;","_index","Ljava/util/ArrayList;"));
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/util/ArrayList;","add",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/io/BufferCache;","_index","Ljava/util/ArrayList;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,5,0},new Method("Ljava/util/ArrayList;","add",new String[]{ "I","Ljava/lang/Object;"},"V"));
                code.visitLabel(L6);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_get(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/BufferCache;","get",new String[]{ "I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"ordinal");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(52,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(53,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(54,L2);
                ddv.visitEndLocal(1,L2);
                DexLabel L3=new DexLabel();
                ddv.visitRestartLocal(1,L3);
                DexLabel L4=new DexLabel();
                ddv.visitEndLocal(1,L4);
                code.visitLabel(L0);
                code.visitJumpStmt(IF_LTZ,2,-1,L1);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/io/BufferCache;","_index","Ljava/util/ArrayList;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/util/ArrayList;","size",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_LT,2,0,L3);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L2);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/io/BufferCache;","_index","Ljava/util/ArrayList;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,2},new Method("Ljava/util/ArrayList;","get",new String[]{ "I"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L4);
                code.visitTypeStmt(CHECK_CAST,1,-1,"Lorg/mortbay/io/BufferCache$CachedBuffer;");
                code.visitStmt2R(MOVE_OBJECT,0,1);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_get(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/BufferCache;","get",new String[]{ "Ljava/lang/String;"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"value");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(64,L0);
                DexLabel L1=new DexLabel();
                ddv.visitEndLocal(1,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/io/BufferCache;","_stringMap","Lorg/mortbay/util/StringMap;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,2},new Method("Lorg/mortbay/util/StringMap;","get",new String[]{ "Ljava/lang/String;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L1);
                code.visitTypeStmt(CHECK_CAST,1,-1,"Lorg/mortbay/io/BufferCache$CachedBuffer;");
                code.visitStmt1R(RETURN_OBJECT,1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_get(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/BufferCache;","get",new String[]{ "Lorg/mortbay/io/Buffer;"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"buffer");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(59,L0);
                DexLabel L1=new DexLabel();
                ddv.visitEndLocal(1,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/io/BufferCache;","_bufferMap","Ljava/util/HashMap;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,2},new Method("Ljava/util/HashMap;","get",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L1);
                code.visitTypeStmt(CHECK_CAST,1,-1,"Lorg/mortbay/io/BufferCache$CachedBuffer;");
                code.visitStmt1R(RETURN_OBJECT,1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_getBest(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/BufferCache;","getBest",new String[]{ "[B","I","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"value");
                ddv.visitParameterName(1,"offset");
                ddv.visitParameterName(2,"maxLength");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(82,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(83,L1);
                ddv.visitStartLocal(0,L1,"entry","Ljava/util/Map$Entry;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(84,L2);
                DexLabel L3=new DexLabel();
                ddv.visitEndLocal(2,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(85,L4);
                DexLabel L5=new DexLabel();
                ddv.visitRestartLocal(2,L5);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/io/BufferCache;","_stringMap","Lorg/mortbay/util/StringMap;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,3,4,5},new Method("Lorg/mortbay/util/StringMap;","getBestEntry",new String[]{ "[B","I","I"},"Ljava/util/Map$Entry;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L1);
                code.visitJumpStmt(IF_EQZ,0,-1,L5);
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Ljava/util/Map$Entry;","getValue",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L3);
                code.visitTypeStmt(CHECK_CAST,2,-1,"Lorg/mortbay/io/BufferCache$CachedBuffer;");
                code.visitStmt2R(MOVE_OBJECT,1,2);
                code.visitLabel(L4);
                code.visitStmt1R(RETURN_OBJECT,1);
                code.visitLabel(L5);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_getOrdinal(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/BufferCache;","getOrdinal",new String[]{ "Lorg/mortbay/io/Buffer;"},"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"buffer");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(105,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(106,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(110,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(107,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(108,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(109,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(110,L6);
                code.visitLabel(L0);
                code.visitTypeStmt(INSTANCE_OF,1,3,"Lorg/mortbay/io/BufferCache$CachedBuffer;");
                code.visitJumpStmt(IF_EQZ,1,-1,L3);
                code.visitLabel(L1);
                code.visitStmt2R(MOVE_OBJECT,0,3);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Lorg/mortbay/io/BufferCache$CachedBuffer;");
                code.visitStmt2R(MOVE_OBJECT,1,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/io/BufferCache$CachedBuffer;","getOrdinal",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitLabel(L2);
                code.visitStmt1R(RETURN,1);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Lorg/mortbay/io/BufferCache;","lookup",new String[]{ "Lorg/mortbay/io/Buffer;"},"Lorg/mortbay/io/Buffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitLabel(L4);
                code.visitJumpStmt(IF_EQZ,3,-1,L6);
                code.visitTypeStmt(INSTANCE_OF,1,3,"Lorg/mortbay/io/BufferCache$CachedBuffer;");
                code.visitJumpStmt(IF_EQZ,1,-1,L6);
                code.visitLabel(L5);
                code.visitStmt2R(MOVE_OBJECT,0,3);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Lorg/mortbay/io/BufferCache$CachedBuffer;");
                code.visitStmt2R(MOVE_OBJECT,1,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/io/BufferCache$CachedBuffer;","getOrdinal",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L6);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(-1)); // int: 0xffffffff  float:NaN
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m007_lookup(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/BufferCache;","lookup",new String[]{ "Ljava/lang/String;"},"Lorg/mortbay/io/Buffer;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"value");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(90,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(91,L1);
                ddv.visitStartLocal(0,L1,"b","Lorg/mortbay/io/Buffer;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(93,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(95,L3);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Lorg/mortbay/io/BufferCache;","get",new String[]{ "Ljava/lang/String;"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L1);
                DexLabel L4=new DexLabel();
                code.visitJumpStmt(IF_NEZ,0,-1,L4);
                code.visitLabel(L2);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Lorg/mortbay/io/BufferCache$CachedBuffer;");
                code.visitConstStmt(CONST_4,2, Integer.valueOf(-1)); // int: 0xffffffff  float:NaN
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,4,2},new Method("Lorg/mortbay/io/BufferCache$CachedBuffer;","<init>",new String[]{ "Ljava/lang/String;","I"},"V"));
                code.visitLabel(L3);
                code.visitStmt1R(RETURN_OBJECT,1);
                code.visitLabel(L4);
                code.visitStmt2R(MOVE_OBJECT,1,0);
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m008_lookup(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/BufferCache;","lookup",new String[]{ "Lorg/mortbay/io/Buffer;"},"Lorg/mortbay/io/Buffer;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"buffer");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(69,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(70,L1);
                ddv.visitStartLocal(0,L1,"b","Lorg/mortbay/io/Buffer;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(72,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(77,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(74,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(77,L5);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Lorg/mortbay/io/BufferCache;","get",new String[]{ "Lorg/mortbay/io/Buffer;"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L1);
                DexLabel L6=new DexLabel();
                code.visitJumpStmt(IF_NEZ,0,-1,L6);
                code.visitLabel(L2);
                code.visitTypeStmt(INSTANCE_OF,1,3,"Lorg/mortbay/io/Buffer$CaseInsensitve;");
                code.visitJumpStmt(IF_EQZ,1,-1,L4);
                code.visitStmt2R(MOVE_OBJECT,1,3);
                code.visitLabel(L3);
                code.visitStmt1R(RETURN_OBJECT,1);
                code.visitLabel(L4);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Lorg/mortbay/io/View$CaseInsensitive;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,3},new Method("Lorg/mortbay/io/View$CaseInsensitive;","<init>",new String[]{ "Lorg/mortbay/io/Buffer;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitLabel(L6);
                code.visitStmt2R(MOVE_OBJECT,1,0);
                code.visitLabel(L5);
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m009_toString(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/BufferCache;","toString",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(148,L0);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,1,"CACHE[bufferMap=");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/io/BufferCache;","_bufferMap","Ljava/util/HashMap;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitConstStmt(CONST_STRING,1,",stringMap=");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/io/BufferCache;","_stringMap","Lorg/mortbay/util/StringMap;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitConstStmt(CONST_STRING,1,",index=");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/io/BufferCache;","_index","Ljava/util/ArrayList;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitConstStmt(CONST_STRING,1,"]");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m010_toString(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/BufferCache;","toString",new String[]{ "Lorg/mortbay/io/Buffer;"},"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"buffer");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(100,L0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Lorg/mortbay/io/BufferCache;","lookup",new String[]{ "Lorg/mortbay/io/Buffer;"},"Lorg/mortbay/io/Buffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/Object;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
