package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0287_org_mortbay_jetty_security_HashSSORealm {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/jetty/security/HashSSORealm;","Ljava/lang/Object;",new String[]{ "Lorg/mortbay/jetty/security/SSORealm;"});
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("HashSSORealm.java");
        f000_SSO_COOKIE_NAME(cv);
        f001__random(cv);
        f002__ssoId2Principal(cv);
        f003__ssoPrincipal2Credential(cv);
        f004__ssoUsername2Id(cv);
        m000__init_(cv);
        m001_clearSingleSignOn(cv);
        m002_getSingleSignOn(cv);
        m003_setSingleSignOn(cv);
    }
    public static void f000_SSO_COOKIE_NAME(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/security/HashSSORealm;","SSO_COOKIE_NAME","Ljava/lang/String;"), "SSO_ID");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001__random(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_TRANSIENT, new Field("Lorg/mortbay/jetty/security/HashSSORealm;","_random","Ljava/util/Random;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002__ssoId2Principal(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/security/HashSSORealm;","_ssoId2Principal","Ljava/util/HashMap;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003__ssoPrincipal2Credential(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/security/HashSSORealm;","_ssoPrincipal2Credential","Ljava/util/HashMap;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f004__ssoUsername2Id(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/security/HashSSORealm;","_ssoUsername2Id","Ljava/util/HashMap;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/security/HashSSORealm;","<init>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(32,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(37,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(38,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(39,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(40,L4);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljava/lang/Object;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/util/HashMap;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/util/HashMap;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/security/HashSSORealm;","_ssoId2Principal","Ljava/util/HashMap;"));
                code.visitLabel(L2);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/util/HashMap;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/util/HashMap;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/security/HashSSORealm;","_ssoUsername2Id","Ljava/util/HashMap;"));
                code.visitLabel(L3);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/util/HashMap;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/util/HashMap;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/security/HashSSORealm;","_ssoPrincipal2Credential","Ljava/util/HashMap;"));
                code.visitLabel(L4);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/security/SecureRandom;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/security/SecureRandom;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/security/HashSSORealm;","_random","Ljava/util/Random;"));
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001_clearSingleSignOn(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/HashSSORealm;","clearSingleSignOn",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"username");
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(125,L3);
                ddv.visitLineNumber(127,L0);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(128,L4);
                ddv.visitStartLocal(1,L4,"ssoID","Ljava/lang/Object;",null);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(129,L5);
                ddv.visitStartLocal(0,L5,"principal","Ljava/lang/Object;",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(130,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(131,L7);
                ddv.visitLineNumber(130,L2);
                ddv.visitEndLocal(1,L2);
                ddv.visitEndLocal(0,L2);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,2,4,new Field("Lorg/mortbay/jetty/security/HashSSORealm;","_ssoId2Principal","Ljava/util/HashMap;"));
                code.visitStmt1R(MONITOR_ENTER,2);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,3,4,new Field("Lorg/mortbay/jetty/security/HashSSORealm;","_ssoUsername2Id","Ljava/util/HashMap;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,5},new Method("Ljava/util/HashMap;","remove",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,3,4,new Field("Lorg/mortbay/jetty/security/HashSSORealm;","_ssoId2Principal","Ljava/util/HashMap;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,1},new Method("Ljava/util/HashMap;","remove",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,3,4,new Field("Lorg/mortbay/jetty/security/HashSSORealm;","_ssoPrincipal2Credential","Ljava/util/HashMap;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,0},new Method("Ljava/util/HashMap;","remove",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L6);
                code.visitStmt1R(MONITOR_EXIT,2);
                code.visitLabel(L7);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,3);
                code.visitStmt1R(MONITOR_EXIT,2);
                code.visitLabel(L1);
                code.visitStmt1R(THROW,3);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_getSingleSignOn(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/HashSSORealm;","getSingleSignOn",new String[]{ "Lorg/mortbay/jetty/Request;","Lorg/mortbay/jetty/Response;"},"Lorg/mortbay/jetty/security/Credential;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(13);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L2},new String[]{ null});
                DexLabel L5=new DexLabel();
                DexLabel L6=new DexLabel();
                DexLabel L7=new DexLabel();
                code.visitTryCatch(L5,L6,new DexLabel[]{L7},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"request");
                ddv.visitParameterName(1,"response");
                DexLabel L8=new DexLabel();
                ddv.visitPrologue(L8);
                ddv.visitLineNumber(45,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(46,L9);
                ddv.visitStartLocal(6,L9,"ssoID","Ljava/lang/String;",null);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(47,L10);
                ddv.visitStartLocal(1,L10,"cookies","[Ljavax/servlet/http/Cookie;",null);
                DexLabel L11=new DexLabel();
                ddv.visitStartLocal(3,L11,"i","I",null);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(49,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(51,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(55,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(57,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(58,L16);
                ddv.visitStartLocal(4,L16,"principal","Ljava/security/Principal;",null);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(59,L17);
                ddv.visitStartLocal(2,L17,"credential","Lorg/mortbay/jetty/security/Credential;",null);
                ddv.visitLineNumber(61,L0);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(62,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(63,L19);
                ddv.visitLineNumber(65,L1);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(67,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(70,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(71,L22);
                ddv.visitStartLocal(5,L22,"realm","Lorg/mortbay/jetty/security/UserRealm;",null);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(73,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(86,L24);
                ddv.visitEndLocal(5,L24);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(47,L25);
                ddv.visitEndLocal(4,L25);
                ddv.visitEndLocal(2,L25);
                ddv.visitLineNumber(63,L2);
                ddv.visitRestartLocal(2,L2);
                ddv.visitRestartLocal(4,L2);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(78,L26);
                ddv.visitRestartLocal(5,L26);
                ddv.visitLineNumber(80,L5);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(81,L27);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(82,L28);
                DexLabel L29=new DexLabel();
                ddv.visitLineNumber(83,L29);
                DexLabel L30=new DexLabel();
                ddv.visitLineNumber(86,L30);
                ddv.visitEndLocal(5,L30);
                ddv.visitLineNumber(83,L7);
                ddv.visitRestartLocal(5,L7);
                code.visitLabel(L8);
                code.visitConstStmt(CONST_4,6, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11},new Method("Lorg/mortbay/jetty/Request;","getCookies",new String[]{ },"[Ljavax/servlet/http/Cookie;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L10);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L11);
                code.visitJumpStmt(IF_EQZ,1,-1,L14);
                code.visitStmt2R(ARRAY_LENGTH,7,1);
                code.visitJumpStmt(IF_GE,3,7,L14);
                code.visitLabel(L12);
                code.visitStmt3R(AGET_OBJECT,7,1,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Ljavax/servlet/http/Cookie;","getName",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitConstStmt(CONST_STRING,8,"SSO_ID");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,8},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitJumpStmt(IF_EQZ,7,-1,L25);
                code.visitLabel(L13);
                code.visitStmt3R(AGET_OBJECT,7,1,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Ljavax/servlet/http/Cookie;","getValue",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitLabel(L14);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/log/Log;","isDebugEnabled",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitJumpStmt(IF_EQZ,7,-1,L15);
                code.visitTypeStmt(NEW_INSTANCE,7,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 7},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,8,"get ssoID=");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,8},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,6},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 7},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L15);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L16);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L17);
                code.visitFieldStmt(IGET_OBJECT,8,10,new Field("Lorg/mortbay/jetty/security/HashSSORealm;","_ssoId2Principal","Ljava/util/HashMap;"));
                code.visitStmt1R(MONITOR_ENTER,8);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,7,10,new Field("Lorg/mortbay/jetty/security/HashSSORealm;","_ssoId2Principal","Ljava/util/HashMap;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,6},new Method("Ljava/util/HashMap;","get",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitStmt2R(MOVE_OBJECT,0,7);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Ljava/security/Principal;");
                code.visitStmt2R(MOVE_OBJECT,4,0);
                code.visitLabel(L18);
                code.visitFieldStmt(IGET_OBJECT,7,10,new Field("Lorg/mortbay/jetty/security/HashSSORealm;","_ssoPrincipal2Credential","Ljava/util/HashMap;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,4},new Method("Ljava/util/HashMap;","get",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitStmt2R(MOVE_OBJECT,0,7);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Lorg/mortbay/jetty/security/Credential;");
                code.visitStmt2R(MOVE_OBJECT,2,0);
                code.visitLabel(L19);
                code.visitStmt1R(MONITOR_EXIT,8);
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/log/Log;","isDebugEnabled",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitJumpStmt(IF_EQZ,7,-1,L20);
                code.visitTypeStmt(NEW_INSTANCE,7,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 7},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,8,"SSO principal=");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,8},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 7},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L20);
                code.visitJumpStmt(IF_EQZ,4,-1,L30);
                code.visitJumpStmt(IF_EQZ,2,-1,L30);
                code.visitLabel(L21);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11},new Method("Lorg/mortbay/jetty/Request;","getContext",new String[]{ },"Lorg/mortbay/jetty/handler/ContextHandler$SContext;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Lorg/mortbay/jetty/handler/ContextHandler$SContext;","getContextHandler",new String[]{ },"Lorg/mortbay/jetty/handler/ContextHandler;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitTypeStmt(CHECK_CAST,7,-1,"Lorg/mortbay/jetty/webapp/WebAppContext;");
                code.visitTypeStmt(CHECK_CAST,7,-1,"Lorg/mortbay/jetty/webapp/WebAppContext;");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","getSecurityHandler",new String[]{ },"Lorg/mortbay/jetty/security/SecurityHandler;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Lorg/mortbay/jetty/security/SecurityHandler;","getUserRealm",new String[]{ },"Lorg/mortbay/jetty/security/UserRealm;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitLabel(L22);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 5,4},new Method("Lorg/mortbay/jetty/security/UserRealm;","reauthenticate",new String[]{ "Ljava/security/Principal;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitJumpStmt(IF_EQZ,7,-1,L26);
                code.visitLabel(L23);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11,4},new Method("Lorg/mortbay/jetty/Request;","setUserPrincipal",new String[]{ "Ljava/security/Principal;"},"V"));
                code.visitStmt2R(MOVE_OBJECT,7,2);
                code.visitLabel(L24);
                code.visitStmt1R(RETURN_OBJECT,7);
                code.visitLabel(L25);
                code.visitStmt2R1N(ADD_INT_LIT8,3,3,1);
                code.visitJumpStmt(GOTO_16,-1,-1,L11);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,7);
                code.visitLabel(L3);
                code.visitStmt1R(MONITOR_EXIT,8);
                code.visitLabel(L4);
                code.visitStmt1R(THROW,7);
                code.visitLabel(L26);
                code.visitFieldStmt(IGET_OBJECT,7,10,new Field("Lorg/mortbay/jetty/security/HashSSORealm;","_ssoId2Principal","Ljava/util/HashMap;"));
                code.visitStmt1R(MONITOR_ENTER,7);
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,8,10,new Field("Lorg/mortbay/jetty/security/HashSSORealm;","_ssoId2Principal","Ljava/util/HashMap;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,6},new Method("Ljava/util/HashMap;","remove",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L27);
                code.visitFieldStmt(IGET_OBJECT,8,10,new Field("Lorg/mortbay/jetty/security/HashSSORealm;","_ssoPrincipal2Credential","Ljava/util/HashMap;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,4},new Method("Ljava/util/HashMap;","remove",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L28);
                code.visitFieldStmt(IGET_OBJECT,8,10,new Field("Lorg/mortbay/jetty/security/HashSSORealm;","_ssoUsername2Id","Ljava/util/HashMap;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 4},new Method("Ljava/security/Principal;","getName",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,9},new Method("Ljava/util/HashMap;","remove",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L29);
                code.visitStmt1R(MONITOR_EXIT,7);
                code.visitLabel(L30);
                code.visitConstStmt(CONST_4,7, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L24);
                code.visitLabel(L7);
                code.visitStmt1R(MOVE_EXCEPTION,8);
                code.visitStmt1R(MONITOR_EXIT,7);
                code.visitLabel(L6);
                code.visitStmt1R(THROW,8);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_setSingleSignOn(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/HashSSORealm;","setSingleSignOn",new String[]{ "Lorg/mortbay/jetty/Request;","Lorg/mortbay/jetty/Response;","Ljava/security/Principal;","Lorg/mortbay/jetty/security/Credential;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(14);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"request");
                ddv.visitParameterName(1,"response");
                ddv.visitParameterName(2,"principal");
                ddv.visitParameterName(3,"credential");
                DexLabel L5=new DexLabel();
                ddv.visitPrologue(L5);
                ddv.visitLineNumber(97,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(99,L6);
                ddv.visitStartLocal(1,L6,"ssoID","Ljava/lang/String;",null);
                ddv.visitLineNumber(104,L0);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(106,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(110,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(111,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(112,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(113,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(114,L12);
                ddv.visitLineNumber(116,L1);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(117,L13);
                ddv.visitStartLocal(0,L13,"cookie","Ljavax/servlet/http/Cookie;",null);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(118,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(119,L15);
                ddv.visitLineNumber(114,L2);
                ddv.visitEndLocal(0,L2);
                code.visitLabel(L5);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,2,9,new Field("Lorg/mortbay/jetty/security/HashSSORealm;","_ssoId2Principal","Ljava/util/HashMap;"));
                code.visitStmt1R(MONITOR_ENTER,2);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,3,9,new Field("Lorg/mortbay/jetty/security/HashSSORealm;","_random","Ljava/util/Random;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/util/Random;","nextLong",new String[]{ },"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,3);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3,4},new Method("Ljava/lang/Math;","abs",new String[]{ "J"},"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,3);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Ljava/lang/System;","currentTimeMillis",new String[]{ },"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,5);
                code.visitConstStmt(CONST_WIDE_16,7,Long.valueOf(7L)); // long: 0x0000000000000007  double:0.000000
                code.visitStmt2R(REM_LONG_2ADDR,5,7);
                code.visitStmt2R(LONG_TO_INT,5,5);
                code.visitStmt2R1N(ADD_INT_LIT8,5,5,30);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3,4,5},new Method("Ljava/lang/Long;","toString",new String[]{ "J","I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L7);
                code.visitFieldStmt(IGET_OBJECT,3,9,new Field("Lorg/mortbay/jetty/security/HashSSORealm;","_ssoId2Principal","Ljava/util/HashMap;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,1},new Method("Ljava/util/HashMap;","containsKey",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_NEZ,3,-1,L0);
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/log/Log;","isDebugEnabled",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_EQZ,3,-1,L9);
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,4,"set ssoID=");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L9);
                code.visitFieldStmt(IGET_OBJECT,3,9,new Field("Lorg/mortbay/jetty/security/HashSSORealm;","_ssoId2Principal","Ljava/util/HashMap;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,1,12},new Method("Ljava/util/HashMap;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L10);
                code.visitFieldStmt(IGET_OBJECT,3,9,new Field("Lorg/mortbay/jetty/security/HashSSORealm;","_ssoPrincipal2Credential","Ljava/util/HashMap;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,12,13},new Method("Ljava/util/HashMap;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L11);
                code.visitFieldStmt(IGET_OBJECT,3,9,new Field("Lorg/mortbay/jetty/security/HashSSORealm;","_ssoUsername2Id","Ljava/util/HashMap;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 12},new Method("Ljava/security/Principal;","getName",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4,1},new Method("Ljava/util/HashMap;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L12);
                code.visitStmt1R(MONITOR_EXIT,2);
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljavax/servlet/http/Cookie;");
                code.visitConstStmt(CONST_STRING,2,"SSO_ID");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,2,1},new Method("Ljavax/servlet/http/Cookie;","<init>",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"V"));
                code.visitLabel(L13);
                code.visitConstStmt(CONST_STRING,2,"/");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,2},new Method("Ljavax/servlet/http/Cookie;","setPath",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L14);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11,0},new Method("Lorg/mortbay/jetty/Response;","addCookie",new String[]{ "Ljavax/servlet/http/Cookie;"},"V"));
                code.visitLabel(L15);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,3);
                code.visitLabel(L3);
                code.visitStmt1R(MONITOR_EXIT,2);
                code.visitLabel(L4);
                code.visitStmt1R(THROW,3);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
