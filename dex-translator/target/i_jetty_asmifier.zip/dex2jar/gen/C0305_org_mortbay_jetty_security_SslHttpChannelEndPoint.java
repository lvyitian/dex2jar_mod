package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0305_org_mortbay_jetty_security_SslHttpChannelEndPoint {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","Lorg/mortbay/jetty/nio/SelectChannelConnector$ConnectorEndPoint;",new String[]{ "Ljava/lang/Runnable;"});
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("SslHttpChannelEndPoint.java");
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/MemberClasses;", Visibility.SYSTEM);
            if(av00 != null) {
                {
                    DexAnnotationVisitor av01 = av00.visitArray("value");
                    if(av01 != null) {
                        av01.visit(null, new DexType("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint$2;"));
                        av01.visitEnd();
                    }
                }
                av00.visitEnd();
            }
        }
        f000_$assertionsDisabled(cv);
        f001___NO_BUFFERS(cv);
        f002__buffers(cv);
        f003__closing(cv);
        f004__engine(cv);
        f005__gather(cv);
        f006__inBuffer(cv);
        f007__inNIOBuffer(cv);
        f008__last(cv);
        f009__outBuffer(cv);
        f010__outNIOBuffer(cv);
        f011__result(cv);
        f012__reuseBuffer(cv);
        f013__session(cv);
        m000__clinit_(cv);
        m001__init_(cv);
        m002_extractInputBuffer(cv);
        m003_extractOutputBuffer(cv);
        m004_unwrap(cv);
        m005_wrap(cv);
        m006_wrap(cv);
        m007_close(cv);
        m008_doIdleExpired(cv);
        m009_dump(cv);
        m010_fill(cv);
        m011_flush(cv);
        m012_flush(cv);
        m013_flush(cv);
        m014_getSSLEngine(cv);
        m015_idleExpired(cv);
        m016_isBufferingInput(cv);
        m017_isBufferingOutput(cv);
        m018_isBufferred(cv);
        m019_toString(cv);
    }
    public static void f000_$assertionsDisabled(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_STATIC|ACC_FINAL|ACC_SYNTHETIC, new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","$assertionsDisabled","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001___NO_BUFFERS(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","__NO_BUFFERS","[Ljava/nio/ByteBuffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002__buffers(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_buffers","Lorg/mortbay/io/Buffers;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003__closing(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_closing","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f004__engine(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_engine","Ljavax/net/ssl/SSLEngine;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f005__gather(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_gather","[Ljava/nio/ByteBuffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f006__inBuffer(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_inBuffer","Ljava/nio/ByteBuffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f007__inNIOBuffer(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_inNIOBuffer","Lorg/mortbay/io/nio/NIOBuffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f008__last(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_last","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f009__outBuffer(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_outBuffer","Ljava/nio/ByteBuffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f010__outNIOBuffer(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_outNIOBuffer","Lorg/mortbay/io/nio/NIOBuffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f011__result(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_result","Ljavax/net/ssl/SSLEngineResult;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f012__reuseBuffer(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_reuseBuffer","[Lorg/mortbay/io/nio/NIOBuffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f013__session(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_session","Ljavax/net/ssl/SSLSession;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__clinit_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","<clinit>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(43,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(45,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(43,L3);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitConstStmt(CONST_CLASS,0,new DexType("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/Class;","desiredAssertionStatus",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                DexLabel L4=new DexLabel();
                code.visitJumpStmt(IF_NEZ,0,-1,L4);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                DexLabel L5=new DexLabel();
                code.visitLabel(L5);
                code.visitFieldStmt(SPUT_BOOLEAN,0,-1,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","$assertionsDisabled","Z"));
                code.visitLabel(L2);
                code.visitTypeStmt(NEW_ARRAY,0,1,"[Ljava/nio/ByteBuffer;");
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","__NO_BUFFERS","[Ljava/nio/ByteBuffer;"));
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L4);
                code.visitStmt2R(MOVE,0,1);
                code.visitLabel(L3);
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","<init>",new String[]{ "Lorg/mortbay/io/Buffers;","Ljava/nio/channels/SocketChannel;","Lorg/mortbay/io/nio/SelectorManager$SelectSet;","Ljava/nio/channels/SelectionKey;","Ljavax/net/ssl/SSLEngine;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljavax/net/ssl/SSLException;"));
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(8);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"buffers");
                ddv.visitParameterName(1,"channel");
                ddv.visitParameterName(2,"selectSet");
                ddv.visitParameterName(3,"key");
                ddv.visitParameterName(4,"engine");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(72,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(55,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(56,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(58,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(73,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(76,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(77,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(80,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(81,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(82,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(83,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(86,L12);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2,4,5,6},new Method("Lorg/mortbay/jetty/nio/SelectChannelConnector$ConnectorEndPoint;","<init>",new String[]{ "Ljava/nio/channels/SocketChannel;","Lorg/mortbay/io/nio/SelectorManager$SelectSet;","Ljava/nio/channels/SelectionKey;"},"V"));
                code.visitLabel(L2);
                code.visitTypeStmt(NEW_ARRAY,0,1,"[Lorg/mortbay/io/nio/NIOBuffer;");
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_reuseBuffer","[Lorg/mortbay/io/nio/NIOBuffer;"));
                code.visitLabel(L3);
                code.visitTypeStmt(NEW_ARRAY,0,1,"[Ljava/nio/ByteBuffer;");
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_gather","[Ljava/nio/ByteBuffer;"));
                code.visitLabel(L4);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_BOOLEAN,0,2,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_closing","Z"));
                code.visitLabel(L5);
                code.visitFieldStmt(IPUT_OBJECT,3,2,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_buffers","Lorg/mortbay/io/Buffers;"));
                code.visitLabel(L6);
                code.visitFieldStmt(IPUT_OBJECT,7,2,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_engine","Ljavax/net/ssl/SSLEngine;"));
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Ljavax/net/ssl/SSLEngine;","getSession",new String[]{ },"Ljavax/net/ssl/SSLSession;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_session","Ljavax/net/ssl/SSLSession;"));
                code.visitLabel(L8);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_session","Ljavax/net/ssl/SSLSession;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Ljavax/net/ssl/SSLSession;","getPacketBufferSize",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3,0},new Method("Lorg/mortbay/io/Buffers;","getBuffer",new String[]{ "I"},"Lorg/mortbay/io/Buffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Lorg/mortbay/io/nio/NIOBuffer;");
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_outNIOBuffer","Lorg/mortbay/io/nio/NIOBuffer;"));
                code.visitLabel(L9);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_outNIOBuffer","Lorg/mortbay/io/nio/NIOBuffer;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Lorg/mortbay/io/nio/NIOBuffer;","getByteBuffer",new String[]{ },"Ljava/nio/ByteBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_outBuffer","Ljava/nio/ByteBuffer;"));
                code.visitLabel(L10);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_session","Ljavax/net/ssl/SSLSession;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Ljavax/net/ssl/SSLSession;","getPacketBufferSize",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3,0},new Method("Lorg/mortbay/io/Buffers;","getBuffer",new String[]{ "I"},"Lorg/mortbay/io/Buffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Lorg/mortbay/io/nio/NIOBuffer;");
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_inNIOBuffer","Lorg/mortbay/io/nio/NIOBuffer;"));
                code.visitLabel(L11);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_inNIOBuffer","Lorg/mortbay/io/nio/NIOBuffer;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Lorg/mortbay/io/nio/NIOBuffer;","getByteBuffer",new String[]{ },"Ljava/nio/ByteBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_inBuffer","Ljava/nio/ByteBuffer;"));
                code.visitLabel(L12);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_extractInputBuffer(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PRIVATE, new Method("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","extractInputBuffer",new String[]{ "Lorg/mortbay/io/Buffer;"},"Ljava/nio/ByteBuffer;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"buffer");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(510,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(511,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(512,L2);
                ddv.visitStartLocal(2,L2,"nbuf","Lorg/mortbay/io/nio/NIOBuffer;",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(513,L3);
                ddv.visitStartLocal(1,L3,"bbuf","Ljava/nio/ByteBuffer;",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(514,L4);
                code.visitLabel(L0);
                code.visitFieldStmt(SGET_BOOLEAN,3,-1,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","$assertionsDisabled","Z"));
                code.visitJumpStmt(IF_NEZ,3,-1,L1);
                code.visitTypeStmt(INSTANCE_OF,3,5,"Lorg/mortbay/io/nio/NIOBuffer;");
                code.visitJumpStmt(IF_NEZ,3,-1,L1);
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Ljava/lang/AssertionError;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3},new Method("Ljava/lang/AssertionError;","<init>",new String[]{ },"V"));
                code.visitStmt1R(THROW,3);
                code.visitLabel(L1);
                code.visitStmt2R(MOVE_OBJECT,0,5);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Lorg/mortbay/io/nio/NIOBuffer;");
                code.visitStmt2R(MOVE_OBJECT,2,0);
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2},new Method("Lorg/mortbay/io/nio/NIOBuffer;","getByteBuffer",new String[]{ },"Ljava/nio/ByteBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 5},new Method("Lorg/mortbay/io/Buffer;","putIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,3},new Method("Ljava/nio/ByteBuffer;","position",new String[]{ "I"},"Ljava/nio/Buffer;"));
                code.visitLabel(L4);
                code.visitStmt1R(RETURN_OBJECT,1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_extractOutputBuffer(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PRIVATE, new Method("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","extractOutputBuffer",new String[]{ "Lorg/mortbay/io/Buffer;","I"},"Ljava/nio/ByteBuffer;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(8);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"buffer");
                ddv.visitParameterName(1,"n");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(596,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(598,L1);
                ddv.visitStartLocal(1,L1,"nBuf","Lorg/mortbay/io/nio/NIOBuffer;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(600,L2);
                DexLabel L3=new DexLabel();
                ddv.visitEndLocal(1,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(601,L4);
                ddv.visitRestartLocal(1,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(610,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(605,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(606,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(607,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(608,L9);
                ddv.visitStartLocal(0,L9,"buf","Lorg/mortbay/io/nio/NIOBuffer;",null);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(609,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(610,L11);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 6},new Method("Lorg/mortbay/io/Buffer;","buffer",new String[]{ },"Lorg/mortbay/io/Buffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitTypeStmt(INSTANCE_OF,2,2,"Lorg/mortbay/io/nio/NIOBuffer;");
                code.visitJumpStmt(IF_EQZ,2,-1,L6);
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 6},new Method("Lorg/mortbay/io/Buffer;","buffer",new String[]{ },"Lorg/mortbay/io/Buffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L3);
                code.visitTypeStmt(CHECK_CAST,1,-1,"Lorg/mortbay/io/nio/NIOBuffer;");
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Lorg/mortbay/io/nio/NIOBuffer;","getByteBuffer",new String[]{ },"Ljava/nio/ByteBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L5);
                code.visitStmt1R(RETURN_OBJECT,2);
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_reuseBuffer","[Lorg/mortbay/io/nio/NIOBuffer;"));
                code.visitStmt3R(AGET_OBJECT,2,2,7);
                code.visitJumpStmt(IF_NEZ,2,-1,L8);
                code.visitLabel(L7);
                code.visitFieldStmt(IGET_OBJECT,3,5,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_reuseBuffer","[Lorg/mortbay/io/nio/NIOBuffer;"));
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_buffers","Lorg/mortbay/io/Buffers;"));
                code.visitFieldStmt(IGET_OBJECT,4,5,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_session","Ljavax/net/ssl/SSLSession;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 4},new Method("Ljavax/net/ssl/SSLSession;","getApplicationBufferSize",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2,4},new Method("Lorg/mortbay/io/Buffers;","getBuffer",new String[]{ "I"},"Lorg/mortbay/io/Buffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitTypeStmt(CHECK_CAST,2,-1,"Lorg/mortbay/io/nio/NIOBuffer;");
                code.visitStmt3R(APUT_OBJECT,2,3,7);
                code.visitLabel(L8);
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_reuseBuffer","[Lorg/mortbay/io/nio/NIOBuffer;"));
                code.visitStmt3R(AGET_OBJECT,0,2,7);
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Lorg/mortbay/io/nio/NIOBuffer;","clear",new String[]{ },"V"));
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,6},new Method("Lorg/mortbay/io/nio/NIOBuffer;","put",new String[]{ "Lorg/mortbay/io/Buffer;"},"I"));
                code.visitLabel(L11);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Lorg/mortbay/io/nio/NIOBuffer;","getByteBuffer",new String[]{ },"Ljava/nio/ByteBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_unwrap(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PRIVATE, new Method("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","unwrap",new String[]{ "Ljava/nio/ByteBuffer;"},"Z"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(10);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/io/IOException;"});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                DexLabel L5=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L5},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"buffer");
                DexLabel L6=new DexLabel();
                ddv.visitPrologue(L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(523,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(524,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(528,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(529,L10);
                ddv.visitStartLocal(3,L10,"total_filled","I",null);
                ddv.visitLineNumber(533,L0);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(535,L11);
                ddv.visitStartLocal(1,L11,"filled","I",null);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(549,L12);
                ddv.visitEndLocal(1,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(551,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(552,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(526,L15);
                ddv.visitEndLocal(3,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(537,L16);
                ddv.visitRestartLocal(1,L16);
                ddv.visitRestartLocal(3,L16);
                ddv.visitLineNumber(539,L2);
                ddv.visitEndLocal(1,L2);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(541,L17);
                ddv.visitStartLocal(0,L17,"e","Ljava/io/IOException;",null);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(542,L18);
                DexLabel L19=new DexLabel();
                ddv.visitEndLocal(0,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(585,L20);
                ddv.visitLineNumber(558,L3);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(559,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(560,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(561,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(562,L24);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(564,L25);
                ddv.visitLineNumber(568,L4);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(569,L26);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(573,L27);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(587,L28);
                DexLabel L29=new DexLabel();
                ddv.visitLineNumber(588,L29);
                ddv.visitLineNumber(568,L5);
                DexLabel L30=new DexLabel();
                ddv.visitLineNumber(569,L30);
                DexLabel L31=new DexLabel();
                ddv.visitLineNumber(568,L31);
                DexLabel L32=new DexLabel();
                ddv.visitLineNumber(577,L32);
                DexLabel L33=new DexLabel();
                ddv.visitLineNumber(578,L33);
                DexLabel L34=new DexLabel();
                ddv.visitLineNumber(581,L34);
                DexLabel L35=new DexLabel();
                ddv.visitLineNumber(583,L35);
                DexLabel L36=new DexLabel();
                ddv.visitStartLocal(2,L36,"progress","Z",null);
                DexLabel L37=new DexLabel();
                ddv.visitLineNumber(585,L37);
                DexLabel L38=new DexLabel();
                ddv.visitEndLocal(2,L38);
                DexLabel L39=new DexLabel();
                ddv.visitLineNumber(583,L39);
                DexLabel L40=new DexLabel();
                ddv.visitLineNumber(573,L40);
                code.visitLabel(L6);
                code.visitConstStmt(CONST_4,7, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitConstStmt(CONST_4,6, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L7);
                code.visitFieldStmt(IGET_OBJECT,4,8,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_inNIOBuffer","Lorg/mortbay/io/nio/NIOBuffer;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 4},new Method("Lorg/mortbay/io/nio/NIOBuffer;","hasContent",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitJumpStmt(IF_EQZ,4,-1,L15);
                code.visitLabel(L8);
                code.visitFieldStmt(IGET_OBJECT,4,8,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_inNIOBuffer","Lorg/mortbay/io/nio/NIOBuffer;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 4},new Method("Lorg/mortbay/io/nio/NIOBuffer;","compact",new String[]{ },"V"));
                code.visitLabel(L9);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L10);
                code.visitFieldStmt(IGET_OBJECT,4,8,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_inNIOBuffer","Lorg/mortbay/io/nio/NIOBuffer;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 4},new Method("Lorg/mortbay/io/nio/NIOBuffer;","space",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitJumpStmt(IF_LEZ,4,-1,L12);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 8},new Method("Lorg/mortbay/jetty/nio/SelectChannelConnector$ConnectorEndPoint;","isOpen",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitJumpStmt(IF_EQZ,4,-1,L12);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,4,8,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_inNIOBuffer","Lorg/mortbay/io/nio/NIOBuffer;"));
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 8,4},new Method("Lorg/mortbay/jetty/nio/SelectChannelConnector$ConnectorEndPoint;","fill",new String[]{ "Lorg/mortbay/io/Buffer;"},"I"));
                code.visitLabel(L1);
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitLabel(L11);
                code.visitJumpStmt(IF_GTZ,1,-1,L16);
                code.visitLabel(L12);
                code.visitFieldStmt(IGET_OBJECT,4,8,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_inNIOBuffer","Lorg/mortbay/io/nio/NIOBuffer;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 4},new Method("Lorg/mortbay/io/nio/NIOBuffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitJumpStmt(IF_NEZ,4,-1,L3);
                code.visitLabel(L13);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","isOpen",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitJumpStmt(IF_NEZ,4,-1,L19);
                code.visitLabel(L14);
                code.visitTypeStmt(NEW_INSTANCE,4,-1,"Lorg/mortbay/jetty/EofException;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4},new Method("Lorg/mortbay/jetty/EofException;","<init>",new String[]{ },"V"));
                code.visitStmt1R(THROW,4);
                code.visitLabel(L15);
                code.visitFieldStmt(IGET_OBJECT,4,8,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_inNIOBuffer","Lorg/mortbay/io/nio/NIOBuffer;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 4},new Method("Lorg/mortbay/io/nio/NIOBuffer;","clear",new String[]{ },"V"));
                code.visitJumpStmt(GOTO,-1,-1,L9);
                code.visitLabel(L16);
                code.visitStmt2R(ADD_INT_2ADDR,3,1);
                code.visitJumpStmt(GOTO,-1,-1,L10);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,4);
                code.visitStmt2R(MOVE_OBJECT,0,4);
                code.visitLabel(L17);
                code.visitFieldStmt(IGET_OBJECT,4,8,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_inNIOBuffer","Lorg/mortbay/io/nio/NIOBuffer;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 4},new Method("Lorg/mortbay/io/nio/NIOBuffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitJumpStmt(IF_NEZ,4,-1,L12);
                code.visitLabel(L18);
                code.visitStmt1R(THROW,0);
                code.visitLabel(L19);
                code.visitStmt2R(MOVE,4,6);
                code.visitLabel(L20);
                code.visitStmt1R(RETURN,4);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,4,8,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_inBuffer","Ljava/nio/ByteBuffer;"));
                code.visitFieldStmt(IGET_OBJECT,5,8,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_inNIOBuffer","Lorg/mortbay/io/nio/NIOBuffer;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 5},new Method("Lorg/mortbay/io/nio/NIOBuffer;","getIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Ljava/nio/ByteBuffer;","position",new String[]{ "I"},"Ljava/nio/Buffer;"));
                code.visitLabel(L21);
                code.visitFieldStmt(IGET_OBJECT,4,8,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_inBuffer","Ljava/nio/ByteBuffer;"));
                code.visitFieldStmt(IGET_OBJECT,5,8,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_inNIOBuffer","Lorg/mortbay/io/nio/NIOBuffer;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 5},new Method("Lorg/mortbay/io/nio/NIOBuffer;","putIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Ljava/nio/ByteBuffer;","limit",new String[]{ "I"},"Ljava/nio/Buffer;"));
                code.visitLabel(L22);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_OBJECT,4,8,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_result","Ljavax/net/ssl/SSLEngineResult;"));
                code.visitLabel(L23);
                code.visitConstStmt(CONST_STRING,4,"unwrap");
                code.visitFieldStmt(IPUT_OBJECT,4,8,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_last","Ljava/lang/String;"));
                code.visitLabel(L24);
                code.visitFieldStmt(IGET_OBJECT,4,8,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_engine","Ljavax/net/ssl/SSLEngine;"));
                code.visitFieldStmt(IGET_OBJECT,5,8,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_inBuffer","Ljava/nio/ByteBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5,9},new Method("Ljavax/net/ssl/SSLEngine;","unwrap",new String[]{ "Ljava/nio/ByteBuffer;","Ljava/nio/ByteBuffer;"},"Ljavax/net/ssl/SSLEngineResult;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitFieldStmt(IPUT_OBJECT,4,8,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_result","Ljavax/net/ssl/SSLEngineResult;"));
                code.visitLabel(L25);
                code.visitFieldStmt(IGET_OBJECT,4,8,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_inNIOBuffer","Lorg/mortbay/io/nio/NIOBuffer;"));
                code.visitFieldStmt(IGET_OBJECT,5,8,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_result","Ljavax/net/ssl/SSLEngineResult;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljavax/net/ssl/SSLEngineResult;","bytesConsumed",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 4,5},new Method("Lorg/mortbay/io/nio/NIOBuffer;","skip",new String[]{ "I"},"I"));
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,4,8,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_inBuffer","Ljava/nio/ByteBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,6},new Method("Ljava/nio/ByteBuffer;","position",new String[]{ "I"},"Ljava/nio/Buffer;"));
                code.visitLabel(L26);
                code.visitFieldStmt(IGET_OBJECT,4,8,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_inBuffer","Ljava/nio/ByteBuffer;"));
                code.visitFieldStmt(IGET_OBJECT,5,8,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_inBuffer","Ljava/nio/ByteBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/nio/ByteBuffer;","capacity",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Ljava/nio/ByteBuffer;","limit",new String[]{ "I"},"Ljava/nio/Buffer;"));
                code.visitLabel(L27);
                code.visitFieldStmt(SGET_OBJECT,4,-1,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint$2;","$SwitchMap$javax$net$ssl$SSLEngineResult$Status","[I"));
                code.visitFieldStmt(IGET_OBJECT,5,8,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_result","Ljavax/net/ssl/SSLEngineResult;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljavax/net/ssl/SSLEngineResult;","getStatus",new String[]{ },"Ljavax/net/ssl/SSLEngineResult$Status;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljavax/net/ssl/SSLEngineResult$Status;","ordinal",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitStmt3R(AGET,4,4,5);
                code.visitSparseSwitchStmt(PACKED_SWITCH,4,1,new DexLabel[]{L32,L32,L34,L35});
                code.visitLabel(L28);
                code.visitTypeStmt(NEW_INSTANCE,4,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,5,"unwrap ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitFieldStmt(IGET_OBJECT,5,8,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_result","Ljavax/net/ssl/SSLEngineResult;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 4},new Method("Lorg/mortbay/log/Log;","warn",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L29);
                code.visitTypeStmt(NEW_INSTANCE,4,-1,"Ljava/io/IOException;");
                code.visitFieldStmt(IGET_OBJECT,5,8,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_result","Ljavax/net/ssl/SSLEngineResult;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljavax/net/ssl/SSLEngineResult;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4,5},new Method("Ljava/io/IOException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,4);
                code.visitLabel(L5);
                code.visitStmt1R(MOVE_EXCEPTION,4);
                code.visitFieldStmt(IGET_OBJECT,5,8,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_inBuffer","Ljava/nio/ByteBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Ljava/nio/ByteBuffer;","position",new String[]{ "I"},"Ljava/nio/Buffer;"));
                code.visitLabel(L30);
                code.visitFieldStmt(IGET_OBJECT,5,8,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_inBuffer","Ljava/nio/ByteBuffer;"));
                code.visitFieldStmt(IGET_OBJECT,6,8,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_inBuffer","Ljava/nio/ByteBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/nio/ByteBuffer;","capacity",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Ljava/nio/ByteBuffer;","limit",new String[]{ "I"},"Ljava/nio/Buffer;"));
                code.visitLabel(L31);
                code.visitStmt1R(THROW,4);
                code.visitLabel(L32);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/log/Log;","isDebugEnabled",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitJumpStmt(IF_EQZ,4,-1,L33);
                code.visitConstStmt(CONST_STRING,4,"unwrap {}");
                code.visitFieldStmt(IGET_OBJECT,5,8,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_result","Ljavax/net/ssl/SSLEngineResult;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 4,5},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L33);
                DexLabel L41=new DexLabel();
                code.visitJumpStmt(IF_LEZ,3,-1,L41);
                code.visitStmt2R(MOVE,4,7);
                code.visitJumpStmt(GOTO_16,-1,-1,L20);
                code.visitLabel(L41);
                code.visitStmt2R(MOVE,4,6);
                code.visitJumpStmt(GOTO_16,-1,-1,L20);
                code.visitLabel(L34);
                code.visitFieldStmt(IPUT_BOOLEAN,7,8,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_closing","Z"));
                code.visitLabel(L35);
                DexLabel L42=new DexLabel();
                code.visitJumpStmt(IF_GTZ,3,-1,L42);
                code.visitFieldStmt(IGET_OBJECT,4,8,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_result","Ljavax/net/ssl/SSLEngineResult;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljavax/net/ssl/SSLEngineResult;","bytesConsumed",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitJumpStmt(IF_GTZ,4,-1,L42);
                code.visitFieldStmt(IGET_OBJECT,4,8,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_result","Ljavax/net/ssl/SSLEngineResult;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljavax/net/ssl/SSLEngineResult;","bytesProduced",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitJumpStmt(IF_LEZ,4,-1,L38);
                code.visitLabel(L42);
                code.visitStmt2R(MOVE,2,7);
                code.visitLabel(L36);
                code.visitStmt2R(MOVE,4,2);
                code.visitLabel(L37);
                code.visitJumpStmt(GOTO_16,-1,-1,L20);
                code.visitLabel(L38);
                code.visitStmt2R(MOVE,2,6);
                code.visitLabel(L39);
                code.visitJumpStmt(GOTO,-1,-1,L36);
                code.visitLabel(L40);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_wrap(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PRIVATE, new Method("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","wrap",new String[]{ "Lorg/mortbay/io/Buffer;"},"I"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(10);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                code.visitTryCatch(L1,L3,new DexLabel[]{L4},new String[]{ null});
                DexLabel L5=new DexLabel();
                DexLabel L6=new DexLabel();
                DexLabel L7=new DexLabel();
                code.visitTryCatch(L5,L6,new DexLabel[]{L7},new String[]{ null});
                DexLabel L8=new DexLabel();
                code.visitTryCatch(L6,L8,new DexLabel[]{L2},new String[]{ null});
                DexLabel L9=new DexLabel();
                DexLabel L10=new DexLabel();
                code.visitTryCatch(L9,L10,new DexLabel[]{L7},new String[]{ null});
                DexLabel L11=new DexLabel();
                code.visitTryCatch(L10,L11,new DexLabel[]{L2},new String[]{ null});
                DexLabel L12=new DexLabel();
                DexLabel L13=new DexLabel();
                code.visitTryCatch(L12,L13,new DexLabel[]{L7},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"header");
                DexLabel L14=new DexLabel();
                ddv.visitPrologue(L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(695,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(696,L16);
                ddv.visitLineNumber(698,L0);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(699,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(701,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(702,L19);
                ddv.visitStartLocal(0,L19,"consumed","I",null);
                ddv.visitLineNumber(706,L1);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(707,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(708,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(709,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(710,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(711,L24);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(713,L25);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(714,L26);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(715,L27);
                ddv.visitLineNumber(719,L5);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(721,L28);
                DexLabel L29=new DexLabel();
                ddv.visitLineNumber(723,L29);
                DexLabel L30=new DexLabel();
                ddv.visitLineNumber(724,L30);
                ddv.visitStartLocal(1,L30,"len","I",null);
                DexLabel L31=new DexLabel();
                ddv.visitLineNumber(725,L31);
                DexLabel L32=new DexLabel();
                ddv.visitLineNumber(726,L32);
                DexLabel L33=new DexLabel();
                ddv.visitLineNumber(727,L33);
                DexLabel L34=new DexLabel();
                ddv.visitLineNumber(729,L34);
                ddv.visitEndLocal(1,L34);
                ddv.visitLineNumber(731,L7);
                ddv.visitLineNumber(732,L2);
                ddv.visitEndLocal(0,L2);
                ddv.visitLineNumber(719,L9);
                ddv.visitRestartLocal(0,L9);
                DexLabel L35=new DexLabel();
                ddv.visitLineNumber(731,L35);
                ddv.visitLineNumber(732,L10);
                ddv.visitLineNumber(733,L11);
                DexLabel L36=new DexLabel();
                ddv.visitLineNumber(746,L36);
                DexLabel L37=new DexLabel();
                ddv.visitLineNumber(747,L37);
                DexLabel L38=new DexLabel();
                ddv.visitLineNumber(737,L38);
                DexLabel L39=new DexLabel();
                ddv.visitLineNumber(740,L39);
                DexLabel L40=new DexLabel();
                ddv.visitLineNumber(743,L40);
                DexLabel L41=new DexLabel();
                ddv.visitLineNumber(742,L41);
                DexLabel L42=new DexLabel();
                ddv.visitLineNumber(743,L42);
                ddv.visitLineNumber(719,L4);
                DexLabel L43=new DexLabel();
                ddv.visitLineNumber(721,L43);
                DexLabel L44=new DexLabel();
                ddv.visitLineNumber(723,L44);
                DexLabel L45=new DexLabel();
                ddv.visitLineNumber(724,L45);
                ddv.visitRestartLocal(1,L45);
                DexLabel L46=new DexLabel();
                ddv.visitLineNumber(725,L46);
                DexLabel L47=new DexLabel();
                ddv.visitLineNumber(726,L47);
                DexLabel L48=new DexLabel();
                ddv.visitLineNumber(727,L48);
                DexLabel L49=new DexLabel();
                ddv.visitLineNumber(729,L49);
                ddv.visitEndLocal(1,L49);
                DexLabel L50=new DexLabel();
                ddv.visitLineNumber(723,L50);
                DexLabel L51=new DexLabel();
                ddv.visitLineNumber(733,L51);
                code.visitLabel(L14);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L15);
                code.visitFieldStmt(IGET_OBJECT,2,8,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_gather","[Ljava/nio/ByteBuffer;"));
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 8,9,4},new Method("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","extractOutputBuffer",new String[]{ "Lorg/mortbay/io/Buffer;","I"},"Ljava/nio/ByteBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitStmt3R(APUT_OBJECT,3,2,4);
                code.visitLabel(L16);
                code.visitFieldStmt(IGET_OBJECT,2,8,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_gather","[Ljava/nio/ByteBuffer;"));
                code.visitStmt3R(AGET_OBJECT,2,2,4);
                code.visitStmt1R(MONITOR_ENTER,2);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,3,8,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_gather","[Ljava/nio/ByteBuffer;"));
                code.visitConstStmt(CONST_4,4, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt3R(AGET_OBJECT,3,3,4);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 9},new Method("Lorg/mortbay/io/Buffer;","getIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/nio/ByteBuffer;","position",new String[]{ "I"},"Ljava/nio/Buffer;"));
                code.visitLabel(L17);
                code.visitFieldStmt(IGET_OBJECT,3,8,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_gather","[Ljava/nio/ByteBuffer;"));
                code.visitConstStmt(CONST_4,4, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt3R(AGET_OBJECT,3,3,4);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 9},new Method("Lorg/mortbay/io/Buffer;","putIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/nio/ByteBuffer;","limit",new String[]{ "I"},"Ljava/nio/Buffer;"));
                code.visitLabel(L18);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L19);
                code.visitFieldStmt(IGET_OBJECT,3,8,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_outBuffer","Ljava/nio/ByteBuffer;"));
                code.visitStmt1R(MONITOR_ENTER,3);
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,4,8,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_outNIOBuffer","Lorg/mortbay/io/nio/NIOBuffer;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 4},new Method("Lorg/mortbay/io/nio/NIOBuffer;","clear",new String[]{ },"V"));
                code.visitLabel(L20);
                code.visitFieldStmt(IGET_OBJECT,4,8,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_outBuffer","Ljava/nio/ByteBuffer;"));
                code.visitConstStmt(CONST_4,5, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Ljava/nio/ByteBuffer;","position",new String[]{ "I"},"Ljava/nio/Buffer;"));
                code.visitLabel(L21);
                code.visitFieldStmt(IGET_OBJECT,4,8,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_outBuffer","Ljava/nio/ByteBuffer;"));
                code.visitFieldStmt(IGET_OBJECT,5,8,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_outBuffer","Ljava/nio/ByteBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/nio/ByteBuffer;","capacity",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Ljava/nio/ByteBuffer;","limit",new String[]{ "I"},"Ljava/nio/Buffer;"));
                code.visitLabel(L22);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_OBJECT,4,8,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_result","Ljavax/net/ssl/SSLEngineResult;"));
                code.visitLabel(L23);
                code.visitConstStmt(CONST_STRING,4,"wrap wrap");
                code.visitFieldStmt(IPUT_OBJECT,4,8,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_last","Ljava/lang/String;"));
                code.visitLabel(L24);
                code.visitFieldStmt(IGET_OBJECT,4,8,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_engine","Ljavax/net/ssl/SSLEngine;"));
                code.visitFieldStmt(IGET_OBJECT,5,8,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_gather","[Ljava/nio/ByteBuffer;"));
                code.visitConstStmt(CONST_4,6, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt3R(AGET_OBJECT,5,5,6);
                code.visitFieldStmt(IGET_OBJECT,6,8,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_outBuffer","Ljava/nio/ByteBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5,6},new Method("Ljavax/net/ssl/SSLEngine;","wrap",new String[]{ "Ljava/nio/ByteBuffer;","Ljava/nio/ByteBuffer;"},"Ljavax/net/ssl/SSLEngineResult;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitFieldStmt(IPUT_OBJECT,4,8,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_result","Ljavax/net/ssl/SSLEngineResult;"));
                code.visitLabel(L25);
                code.visitFieldStmt(IGET_OBJECT,4,8,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_outNIOBuffer","Lorg/mortbay/io/nio/NIOBuffer;"));
                code.visitConstStmt(CONST_4,5, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 4,5},new Method("Lorg/mortbay/io/nio/NIOBuffer;","setGetIndex",new String[]{ "I"},"V"));
                code.visitLabel(L26);
                code.visitFieldStmt(IGET_OBJECT,4,8,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_outNIOBuffer","Lorg/mortbay/io/nio/NIOBuffer;"));
                code.visitFieldStmt(IGET_OBJECT,5,8,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_result","Ljavax/net/ssl/SSLEngineResult;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljavax/net/ssl/SSLEngineResult;","bytesProduced",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 4,5},new Method("Lorg/mortbay/io/nio/NIOBuffer;","setPutIndex",new String[]{ "I"},"V"));
                code.visitLabel(L27);
                code.visitFieldStmt(IGET_OBJECT,4,8,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_result","Ljavax/net/ssl/SSLEngineResult;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljavax/net/ssl/SSLEngineResult;","bytesConsumed",new String[]{ },"I"));
                code.visitLabel(L3);
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,4,8,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_outBuffer","Ljava/nio/ByteBuffer;"));
                code.visitConstStmt(CONST_4,5, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Ljava/nio/ByteBuffer;","position",new String[]{ "I"},"Ljava/nio/Buffer;"));
                code.visitLabel(L28);
                code.visitJumpStmt(IF_LEZ,0,-1,L34);
                code.visitJumpStmt(IF_EQZ,9,-1,L34);
                code.visitLabel(L29);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 9},new Method("Lorg/mortbay/io/Buffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,4);
                DexLabel L52=new DexLabel();
                code.visitJumpStmt(IF_GE,0,4,L52);
                code.visitStmt2R(MOVE,1,0);
                code.visitLabel(L30);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 9,1},new Method("Lorg/mortbay/io/Buffer;","skip",new String[]{ "I"},"I"));
                code.visitLabel(L31);
                code.visitStmt2R(SUB_INT_2ADDR,0,1);
                code.visitLabel(L32);
                code.visitFieldStmt(IGET_OBJECT,4,8,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_gather","[Ljava/nio/ByteBuffer;"));
                code.visitConstStmt(CONST_4,5, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt3R(AGET_OBJECT,4,4,5);
                code.visitConstStmt(CONST_4,5, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Ljava/nio/ByteBuffer;","position",new String[]{ "I"},"Ljava/nio/Buffer;"));
                code.visitLabel(L33);
                code.visitFieldStmt(IGET_OBJECT,4,8,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_gather","[Ljava/nio/ByteBuffer;"));
                code.visitConstStmt(CONST_4,5, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt3R(AGET_OBJECT,4,4,5);
                code.visitFieldStmt(IGET_OBJECT,5,8,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_gather","[Ljava/nio/ByteBuffer;"));
                code.visitConstStmt(CONST_4,6, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt3R(AGET_OBJECT,5,5,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/nio/ByteBuffer;","capacity",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Ljava/nio/ByteBuffer;","limit",new String[]{ "I"},"Ljava/nio/Buffer;"));
                code.visitLabel(L34);
                code.visitFieldStmt(SGET_BOOLEAN,4,-1,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","$assertionsDisabled","Z"));
                code.visitJumpStmt(IF_NEZ,4,-1,L35);
                code.visitJumpStmt(IF_EQZ,0,-1,L35);
                code.visitTypeStmt(NEW_INSTANCE,4,-1,"Ljava/lang/AssertionError;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4},new Method("Ljava/lang/AssertionError;","<init>",new String[]{ },"V"));
                code.visitStmt1R(THROW,4);
                code.visitLabel(L7);
                code.visitStmt1R(MOVE_EXCEPTION,4);
                code.visitStmt1R(MONITOR_EXIT,3);
                code.visitLabel(L6);
                code.visitStmt1R(THROW,4);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,3);
                code.visitStmt1R(MONITOR_EXIT,2);
                code.visitLabel(L8);
                code.visitStmt1R(THROW,3);
                code.visitLabel(L9);
                code.visitStmt1R(THROW,4);
                code.visitLabel(L35);
                code.visitStmt1R(MONITOR_EXIT,3);
                code.visitLabel(L10);
                code.visitStmt1R(MONITOR_EXIT,2);
                code.visitLabel(L11);
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint$2;","$SwitchMap$javax$net$ssl$SSLEngineResult$Status","[I"));
                code.visitFieldStmt(IGET_OBJECT,3,8,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_result","Ljavax/net/ssl/SSLEngineResult;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljavax/net/ssl/SSLEngineResult;","getStatus",new String[]{ },"Ljavax/net/ssl/SSLEngineResult$Status;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljavax/net/ssl/SSLEngineResult$Status;","ordinal",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitStmt3R(AGET,2,2,3);
                code.visitSparseSwitchStmt(PACKED_SWITCH,2,1,new DexLabel[]{L38,L38,L41,L39});
                code.visitLabel(L36);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,3,"wrap ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitFieldStmt(IGET_OBJECT,3,8,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_result","Ljavax/net/ssl/SSLEngineResult;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2},new Method("Lorg/mortbay/log/Log;","warn",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L37);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Ljava/io/IOException;");
                code.visitFieldStmt(IGET_OBJECT,3,8,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_result","Ljavax/net/ssl/SSLEngineResult;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljavax/net/ssl/SSLEngineResult;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2,3},new Method("Ljava/io/IOException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,2);
                code.visitLabel(L38);
                code.visitConstStmt(CONST_STRING,2,"wrap {}");
                code.visitFieldStmt(IGET_OBJECT,3,8,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_result","Ljavax/net/ssl/SSLEngineResult;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2,3},new Method("Lorg/mortbay/log/Log;","warn",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L39);
                code.visitFieldStmt(IGET_OBJECT,2,8,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_result","Ljavax/net/ssl/SSLEngineResult;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljavax/net/ssl/SSLEngineResult;","bytesConsumed",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitLabel(L40);
                code.visitStmt1R(RETURN,2);
                code.visitLabel(L41);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitFieldStmt(IPUT_BOOLEAN,2,8,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_closing","Z"));
                code.visitLabel(L42);
                code.visitFieldStmt(IGET_OBJECT,2,8,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_result","Ljavax/net/ssl/SSLEngineResult;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljavax/net/ssl/SSLEngineResult;","bytesConsumed",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                DexLabel L53=new DexLabel();
                code.visitJumpStmt(IF_LEZ,2,-1,L53);
                code.visitFieldStmt(IGET_OBJECT,2,8,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_result","Ljavax/net/ssl/SSLEngineResult;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljavax/net/ssl/SSLEngineResult;","bytesConsumed",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(GOTO,-1,-1,L40);
                code.visitLabel(L53);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(-1)); // int: 0xffffffff  float:NaN
                code.visitJumpStmt(GOTO,-1,-1,L40);
                code.visitLabel(L4);
                code.visitStmt1R(MOVE_EXCEPTION,4);
                code.visitLabel(L12);
                code.visitFieldStmt(IGET_OBJECT,5,8,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_outBuffer","Ljava/nio/ByteBuffer;"));
                code.visitConstStmt(CONST_4,6, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Ljava/nio/ByteBuffer;","position",new String[]{ "I"},"Ljava/nio/Buffer;"));
                code.visitLabel(L43);
                code.visitJumpStmt(IF_LEZ,0,-1,L49);
                code.visitJumpStmt(IF_EQZ,9,-1,L49);
                code.visitLabel(L44);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 9},new Method("Lorg/mortbay/io/Buffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitJumpStmt(IF_GE,0,5,L50);
                code.visitStmt2R(MOVE,1,0);
                code.visitLabel(L45);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 9,1},new Method("Lorg/mortbay/io/Buffer;","skip",new String[]{ "I"},"I"));
                code.visitLabel(L46);
                code.visitStmt2R(SUB_INT_2ADDR,0,1);
                code.visitLabel(L47);
                code.visitFieldStmt(IGET_OBJECT,5,8,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_gather","[Ljava/nio/ByteBuffer;"));
                code.visitConstStmt(CONST_4,6, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt3R(AGET_OBJECT,5,5,6);
                code.visitConstStmt(CONST_4,6, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Ljava/nio/ByteBuffer;","position",new String[]{ "I"},"Ljava/nio/Buffer;"));
                code.visitLabel(L48);
                code.visitFieldStmt(IGET_OBJECT,5,8,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_gather","[Ljava/nio/ByteBuffer;"));
                code.visitConstStmt(CONST_4,6, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt3R(AGET_OBJECT,5,5,6);
                code.visitFieldStmt(IGET_OBJECT,6,8,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_gather","[Ljava/nio/ByteBuffer;"));
                code.visitConstStmt(CONST_4,7, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt3R(AGET_OBJECT,6,6,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/nio/ByteBuffer;","capacity",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Ljava/nio/ByteBuffer;","limit",new String[]{ "I"},"Ljava/nio/Buffer;"));
                code.visitLabel(L49);
                code.visitFieldStmt(SGET_BOOLEAN,5,-1,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","$assertionsDisabled","Z"));
                code.visitJumpStmt(IF_NEZ,5,-1,L9);
                code.visitJumpStmt(IF_EQZ,0,-1,L9);
                code.visitTypeStmt(NEW_INSTANCE,4,-1,"Ljava/lang/AssertionError;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4},new Method("Ljava/lang/AssertionError;","<init>",new String[]{ },"V"));
                code.visitStmt1R(THROW,4);
                code.visitLabel(L50);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 9},new Method("Lorg/mortbay/io/Buffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitStmt2R(MOVE,1,5);
                code.visitJumpStmt(GOTO,-1,-1,L45);
                code.visitLabel(L52);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 9},new Method("Lorg/mortbay/io/Buffer;","length",new String[]{ },"I"));
                code.visitLabel(L13);
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitStmt2R(MOVE,1,4);
                code.visitJumpStmt(GOTO_16,-1,-1,L30);
                code.visitLabel(L51);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_wrap(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PRIVATE, new Method("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","wrap",new String[]{ "Lorg/mortbay/io/Buffer;","Lorg/mortbay/io/Buffer;"},"I"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(12);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                code.visitTryCatch(L1,L3,new DexLabel[]{L4},new String[]{ null});
                DexLabel L5=new DexLabel();
                DexLabel L6=new DexLabel();
                DexLabel L7=new DexLabel();
                code.visitTryCatch(L5,L6,new DexLabel[]{L7},new String[]{ null});
                DexLabel L8=new DexLabel();
                DexLabel L9=new DexLabel();
                DexLabel L10=new DexLabel();
                code.visitTryCatch(L8,L9,new DexLabel[]{L10},new String[]{ null});
                DexLabel L11=new DexLabel();
                code.visitTryCatch(L9,L11,new DexLabel[]{L4},new String[]{ null});
                DexLabel L12=new DexLabel();
                code.visitTryCatch(L11,L12,new DexLabel[]{L2},new String[]{ null});
                DexLabel L13=new DexLabel();
                DexLabel L14=new DexLabel();
                code.visitTryCatch(L13,L14,new DexLabel[]{L10},new String[]{ null});
                DexLabel L15=new DexLabel();
                code.visitTryCatch(L14,L15,new DexLabel[]{L4},new String[]{ null});
                DexLabel L16=new DexLabel();
                code.visitTryCatch(L15,L16,new DexLabel[]{L2},new String[]{ null});
                DexLabel L17=new DexLabel();
                DexLabel L18=new DexLabel();
                code.visitTryCatch(L17,L18,new DexLabel[]{L10},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"header");
                ddv.visitParameterName(1,"buffer");
                DexLabel L19=new DexLabel();
                ddv.visitPrologue(L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(617,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(618,L21);
                ddv.visitLineNumber(620,L0);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(621,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(623,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(625,L24);
                ddv.visitLineNumber(627,L1);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(628,L25);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(630,L26);
                ddv.visitLineNumber(632,L3);
                ddv.visitLineNumber(635,L5);
                ddv.visitStartLocal(0,L5,"consumed","I",null);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(636,L27);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(637,L28);
                DexLabel L29=new DexLabel();
                ddv.visitLineNumber(639,L29);
                DexLabel L30=new DexLabel();
                ddv.visitLineNumber(640,L30);
                DexLabel L31=new DexLabel();
                ddv.visitLineNumber(641,L31);
                DexLabel L32=new DexLabel();
                ddv.visitLineNumber(643,L32);
                DexLabel L33=new DexLabel();
                ddv.visitLineNumber(644,L33);
                DexLabel L34=new DexLabel();
                ddv.visitLineNumber(645,L34);
                ddv.visitLineNumber(649,L8);
                DexLabel L35=new DexLabel();
                ddv.visitLineNumber(651,L35);
                DexLabel L36=new DexLabel();
                ddv.visitLineNumber(653,L36);
                DexLabel L37=new DexLabel();
                ddv.visitLineNumber(654,L37);
                ddv.visitStartLocal(1,L37,"len","I",null);
                DexLabel L38=new DexLabel();
                ddv.visitLineNumber(655,L38);
                DexLabel L39=new DexLabel();
                ddv.visitLineNumber(656,L39);
                DexLabel L40=new DexLabel();
                ddv.visitLineNumber(657,L40);
                DexLabel L41=new DexLabel();
                ddv.visitLineNumber(659,L41);
                ddv.visitEndLocal(1,L41);
                DexLabel L42=new DexLabel();
                ddv.visitLineNumber(661,L42);
                DexLabel L43=new DexLabel();
                ddv.visitLineNumber(662,L43);
                ddv.visitRestartLocal(1,L43);
                DexLabel L44=new DexLabel();
                ddv.visitLineNumber(663,L44);
                DexLabel L45=new DexLabel();
                ddv.visitLineNumber(664,L45);
                DexLabel L46=new DexLabel();
                ddv.visitLineNumber(665,L46);
                DexLabel L47=new DexLabel();
                ddv.visitLineNumber(667,L47);
                ddv.visitEndLocal(1,L47);
                ddv.visitLineNumber(669,L10);
                ddv.visitLineNumber(670,L4);
                ddv.visitEndLocal(0,L4);
                ddv.visitLineNumber(671,L2);
                ddv.visitLineNumber(649,L13);
                ddv.visitRestartLocal(0,L13);
                DexLabel L48=new DexLabel();
                ddv.visitLineNumber(669,L48);
                ddv.visitLineNumber(670,L14);
                ddv.visitLineNumber(671,L15);
                ddv.visitLineNumber(674,L16);
                DexLabel L49=new DexLabel();
                ddv.visitLineNumber(687,L49);
                DexLabel L50=new DexLabel();
                ddv.visitLineNumber(688,L50);
                DexLabel L51=new DexLabel();
                ddv.visitLineNumber(678,L51);
                DexLabel L52=new DexLabel();
                ddv.visitLineNumber(681,L52);
                DexLabel L53=new DexLabel();
                ddv.visitLineNumber(684,L53);
                DexLabel L54=new DexLabel();
                ddv.visitLineNumber(683,L54);
                DexLabel L55=new DexLabel();
                ddv.visitLineNumber(684,L55);
                ddv.visitLineNumber(649,L7);
                DexLabel L56=new DexLabel();
                ddv.visitLineNumber(651,L56);
                DexLabel L57=new DexLabel();
                ddv.visitLineNumber(653,L57);
                DexLabel L58=new DexLabel();
                ddv.visitLineNumber(654,L58);
                ddv.visitRestartLocal(1,L58);
                DexLabel L59=new DexLabel();
                ddv.visitLineNumber(655,L59);
                DexLabel L60=new DexLabel();
                ddv.visitLineNumber(656,L60);
                DexLabel L61=new DexLabel();
                ddv.visitLineNumber(657,L61);
                DexLabel L62=new DexLabel();
                ddv.visitLineNumber(659,L62);
                ddv.visitEndLocal(1,L62);
                DexLabel L63=new DexLabel();
                ddv.visitLineNumber(661,L63);
                DexLabel L64=new DexLabel();
                ddv.visitLineNumber(662,L64);
                ddv.visitRestartLocal(1,L64);
                DexLabel L65=new DexLabel();
                ddv.visitLineNumber(663,L65);
                DexLabel L66=new DexLabel();
                ddv.visitLineNumber(664,L66);
                DexLabel L67=new DexLabel();
                ddv.visitLineNumber(665,L67);
                DexLabel L68=new DexLabel();
                ddv.visitLineNumber(667,L68);
                ddv.visitEndLocal(1,L68);
                DexLabel L69=new DexLabel();
                ddv.visitLineNumber(653,L69);
                DexLabel L70=new DexLabel();
                ddv.visitLineNumber(661,L70);
                DexLabel L71=new DexLabel();
                ddv.visitLineNumber(653,L71);
                DexLabel L72=new DexLabel();
                ddv.visitLineNumber(661,L72);
                DexLabel L73=new DexLabel();
                ddv.visitLineNumber(674,L73);
                code.visitLabel(L19);
                code.visitConstStmt(CONST_4,8, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitConstStmt(CONST_4,4, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L20);
                code.visitFieldStmt(IGET_OBJECT,2,9,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_gather","[Ljava/nio/ByteBuffer;"));
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 9,10,4},new Method("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","extractOutputBuffer",new String[]{ "Lorg/mortbay/io/Buffer;","I"},"Ljava/nio/ByteBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitStmt3R(APUT_OBJECT,3,2,4);
                code.visitLabel(L21);
                code.visitFieldStmt(IGET_OBJECT,2,9,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_gather","[Ljava/nio/ByteBuffer;"));
                code.visitStmt3R(AGET_OBJECT,2,2,4);
                code.visitStmt1R(MONITOR_ENTER,2);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,3,9,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_gather","[Ljava/nio/ByteBuffer;"));
                code.visitConstStmt(CONST_4,4, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt3R(AGET_OBJECT,3,3,4);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 10},new Method("Lorg/mortbay/io/Buffer;","getIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/nio/ByteBuffer;","position",new String[]{ "I"},"Ljava/nio/Buffer;"));
                code.visitLabel(L22);
                code.visitFieldStmt(IGET_OBJECT,3,9,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_gather","[Ljava/nio/ByteBuffer;"));
                code.visitConstStmt(CONST_4,4, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt3R(AGET_OBJECT,3,3,4);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 10},new Method("Lorg/mortbay/io/Buffer;","putIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/nio/ByteBuffer;","limit",new String[]{ "I"},"Ljava/nio/Buffer;"));
                code.visitLabel(L23);
                code.visitFieldStmt(IGET_OBJECT,3,9,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_gather","[Ljava/nio/ByteBuffer;"));
                code.visitConstStmt(CONST_4,4, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitConstStmt(CONST_4,5, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 9,11,5},new Method("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","extractOutputBuffer",new String[]{ "Lorg/mortbay/io/Buffer;","I"},"Ljava/nio/ByteBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitStmt3R(APUT_OBJECT,5,3,4);
                code.visitLabel(L24);
                code.visitFieldStmt(IGET_OBJECT,3,9,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_gather","[Ljava/nio/ByteBuffer;"));
                code.visitConstStmt(CONST_4,4, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt3R(AGET_OBJECT,3,3,4);
                code.visitStmt1R(MONITOR_ENTER,3);
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,4,9,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_gather","[Ljava/nio/ByteBuffer;"));
                code.visitConstStmt(CONST_4,5, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt3R(AGET_OBJECT,4,4,5);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 11},new Method("Lorg/mortbay/io/Buffer;","getIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Ljava/nio/ByteBuffer;","position",new String[]{ "I"},"Ljava/nio/Buffer;"));
                code.visitLabel(L25);
                code.visitFieldStmt(IGET_OBJECT,4,9,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_gather","[Ljava/nio/ByteBuffer;"));
                code.visitConstStmt(CONST_4,5, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt3R(AGET_OBJECT,4,4,5);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 11},new Method("Lorg/mortbay/io/Buffer;","putIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Ljava/nio/ByteBuffer;","limit",new String[]{ "I"},"Ljava/nio/Buffer;"));
                code.visitLabel(L26);
                code.visitFieldStmt(IGET_OBJECT,4,9,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_outBuffer","Ljava/nio/ByteBuffer;"));
                code.visitStmt1R(MONITOR_ENTER,4);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,5,9,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_outNIOBuffer","Lorg/mortbay/io/nio/NIOBuffer;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 5},new Method("Lorg/mortbay/io/nio/NIOBuffer;","clear",new String[]{ },"V"));
                code.visitLabel(L27);
                code.visitFieldStmt(IGET_OBJECT,5,9,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_outBuffer","Ljava/nio/ByteBuffer;"));
                code.visitConstStmt(CONST_4,6, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Ljava/nio/ByteBuffer;","position",new String[]{ "I"},"Ljava/nio/Buffer;"));
                code.visitLabel(L28);
                code.visitFieldStmt(IGET_OBJECT,5,9,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_outBuffer","Ljava/nio/ByteBuffer;"));
                code.visitFieldStmt(IGET_OBJECT,6,9,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_outBuffer","Ljava/nio/ByteBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/nio/ByteBuffer;","capacity",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Ljava/nio/ByteBuffer;","limit",new String[]{ "I"},"Ljava/nio/Buffer;"));
                code.visitLabel(L29);
                code.visitConstStmt(CONST_4,5, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_OBJECT,5,9,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_result","Ljavax/net/ssl/SSLEngineResult;"));
                code.visitLabel(L30);
                code.visitConstStmt(CONST_STRING,5,"wrap wrap");
                code.visitFieldStmt(IPUT_OBJECT,5,9,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_last","Ljava/lang/String;"));
                code.visitLabel(L31);
                code.visitFieldStmt(IGET_OBJECT,5,9,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_engine","Ljavax/net/ssl/SSLEngine;"));
                code.visitFieldStmt(IGET_OBJECT,6,9,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_gather","[Ljava/nio/ByteBuffer;"));
                code.visitFieldStmt(IGET_OBJECT,7,9,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_outBuffer","Ljava/nio/ByteBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6,7},new Method("Ljavax/net/ssl/SSLEngine;","wrap",new String[]{ "[Ljava/nio/ByteBuffer;","Ljava/nio/ByteBuffer;"},"Ljavax/net/ssl/SSLEngineResult;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitFieldStmt(IPUT_OBJECT,5,9,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_result","Ljavax/net/ssl/SSLEngineResult;"));
                code.visitLabel(L32);
                code.visitFieldStmt(IGET_OBJECT,5,9,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_outNIOBuffer","Lorg/mortbay/io/nio/NIOBuffer;"));
                code.visitConstStmt(CONST_4,6, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 5,6},new Method("Lorg/mortbay/io/nio/NIOBuffer;","setGetIndex",new String[]{ "I"},"V"));
                code.visitLabel(L33);
                code.visitFieldStmt(IGET_OBJECT,5,9,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_outNIOBuffer","Lorg/mortbay/io/nio/NIOBuffer;"));
                code.visitFieldStmt(IGET_OBJECT,6,9,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_result","Ljavax/net/ssl/SSLEngineResult;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljavax/net/ssl/SSLEngineResult;","bytesProduced",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 5,6},new Method("Lorg/mortbay/io/nio/NIOBuffer;","setPutIndex",new String[]{ "I"},"V"));
                code.visitLabel(L34);
                code.visitFieldStmt(IGET_OBJECT,5,9,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_result","Ljavax/net/ssl/SSLEngineResult;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljavax/net/ssl/SSLEngineResult;","bytesConsumed",new String[]{ },"I"));
                code.visitLabel(L6);
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitLabel(L8);
                code.visitFieldStmt(IGET_OBJECT,5,9,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_outBuffer","Ljava/nio/ByteBuffer;"));
                code.visitConstStmt(CONST_4,6, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Ljava/nio/ByteBuffer;","position",new String[]{ "I"},"Ljava/nio/Buffer;"));
                code.visitLabel(L35);
                code.visitJumpStmt(IF_LEZ,0,-1,L41);
                code.visitJumpStmt(IF_EQZ,10,-1,L41);
                code.visitLabel(L36);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 10},new Method("Lorg/mortbay/io/Buffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitJumpStmt(IF_GE,0,5,L71);
                code.visitStmt2R(MOVE,1,0);
                code.visitLabel(L37);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 10,1},new Method("Lorg/mortbay/io/Buffer;","skip",new String[]{ "I"},"I"));
                code.visitLabel(L38);
                code.visitStmt2R(SUB_INT_2ADDR,0,1);
                code.visitLabel(L39);
                code.visitFieldStmt(IGET_OBJECT,5,9,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_gather","[Ljava/nio/ByteBuffer;"));
                code.visitConstStmt(CONST_4,6, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt3R(AGET_OBJECT,5,5,6);
                code.visitConstStmt(CONST_4,6, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Ljava/nio/ByteBuffer;","position",new String[]{ "I"},"Ljava/nio/Buffer;"));
                code.visitLabel(L40);
                code.visitFieldStmt(IGET_OBJECT,5,9,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_gather","[Ljava/nio/ByteBuffer;"));
                code.visitConstStmt(CONST_4,6, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt3R(AGET_OBJECT,5,5,6);
                code.visitFieldStmt(IGET_OBJECT,6,9,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_gather","[Ljava/nio/ByteBuffer;"));
                code.visitConstStmt(CONST_4,7, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt3R(AGET_OBJECT,6,6,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/nio/ByteBuffer;","capacity",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Ljava/nio/ByteBuffer;","limit",new String[]{ "I"},"Ljava/nio/Buffer;"));
                code.visitLabel(L41);
                code.visitJumpStmt(IF_LEZ,0,-1,L47);
                code.visitJumpStmt(IF_EQZ,11,-1,L47);
                code.visitLabel(L42);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 11},new Method("Lorg/mortbay/io/Buffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitJumpStmt(IF_GE,0,5,L72);
                code.visitStmt2R(MOVE,1,0);
                code.visitLabel(L43);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 11,1},new Method("Lorg/mortbay/io/Buffer;","skip",new String[]{ "I"},"I"));
                code.visitLabel(L44);
                code.visitStmt2R(SUB_INT_2ADDR,0,1);
                code.visitLabel(L45);
                code.visitFieldStmt(IGET_OBJECT,5,9,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_gather","[Ljava/nio/ByteBuffer;"));
                code.visitConstStmt(CONST_4,6, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt3R(AGET_OBJECT,5,5,6);
                code.visitConstStmt(CONST_4,6, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Ljava/nio/ByteBuffer;","position",new String[]{ "I"},"Ljava/nio/Buffer;"));
                code.visitLabel(L46);
                code.visitFieldStmt(IGET_OBJECT,5,9,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_gather","[Ljava/nio/ByteBuffer;"));
                code.visitConstStmt(CONST_4,6, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt3R(AGET_OBJECT,5,5,6);
                code.visitFieldStmt(IGET_OBJECT,6,9,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_gather","[Ljava/nio/ByteBuffer;"));
                code.visitConstStmt(CONST_4,7, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt3R(AGET_OBJECT,6,6,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/nio/ByteBuffer;","capacity",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Ljava/nio/ByteBuffer;","limit",new String[]{ "I"},"Ljava/nio/Buffer;"));
                code.visitLabel(L47);
                code.visitFieldStmt(SGET_BOOLEAN,5,-1,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","$assertionsDisabled","Z"));
                code.visitJumpStmt(IF_NEZ,5,-1,L48);
                code.visitJumpStmt(IF_EQZ,0,-1,L48);
                code.visitTypeStmt(NEW_INSTANCE,5,-1,"Ljava/lang/AssertionError;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 5},new Method("Ljava/lang/AssertionError;","<init>",new String[]{ },"V"));
                code.visitStmt1R(THROW,5);
                code.visitLabel(L10);
                code.visitStmt1R(MOVE_EXCEPTION,5);
                code.visitStmt1R(MONITOR_EXIT,4);
                code.visitLabel(L9);
                code.visitStmt1R(THROW,5);
                code.visitLabel(L4);
                code.visitStmt1R(MOVE_EXCEPTION,4);
                code.visitStmt1R(MONITOR_EXIT,3);
                code.visitLabel(L11);
                code.visitStmt1R(THROW,4);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,3);
                code.visitStmt1R(MONITOR_EXIT,2);
                code.visitLabel(L12);
                code.visitStmt1R(THROW,3);
                code.visitLabel(L13);
                code.visitStmt1R(THROW,5);
                code.visitLabel(L48);
                code.visitStmt1R(MONITOR_EXIT,4);
                code.visitLabel(L14);
                code.visitStmt1R(MONITOR_EXIT,3);
                code.visitLabel(L15);
                code.visitStmt1R(MONITOR_EXIT,2);
                code.visitLabel(L16);
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint$2;","$SwitchMap$javax$net$ssl$SSLEngineResult$Status","[I"));
                code.visitFieldStmt(IGET_OBJECT,3,9,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_result","Ljavax/net/ssl/SSLEngineResult;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljavax/net/ssl/SSLEngineResult;","getStatus",new String[]{ },"Ljavax/net/ssl/SSLEngineResult$Status;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljavax/net/ssl/SSLEngineResult$Status;","ordinal",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitStmt3R(AGET,2,2,3);
                code.visitSparseSwitchStmt(PACKED_SWITCH,2,1,new DexLabel[]{L51,L51,L54,L52});
                code.visitLabel(L49);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,3,"wrap ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitFieldStmt(IGET_OBJECT,3,9,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_result","Ljavax/net/ssl/SSLEngineResult;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2},new Method("Lorg/mortbay/log/Log;","warn",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L50);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Ljava/io/IOException;");
                code.visitFieldStmt(IGET_OBJECT,3,9,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_result","Ljavax/net/ssl/SSLEngineResult;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljavax/net/ssl/SSLEngineResult;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2,3},new Method("Ljava/io/IOException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,2);
                code.visitLabel(L51);
                code.visitConstStmt(CONST_STRING,2,"wrap {}");
                code.visitFieldStmt(IGET_OBJECT,3,9,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_result","Ljavax/net/ssl/SSLEngineResult;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2,3},new Method("Lorg/mortbay/log/Log;","warn",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L52);
                code.visitFieldStmt(IGET_OBJECT,2,9,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_result","Ljavax/net/ssl/SSLEngineResult;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljavax/net/ssl/SSLEngineResult;","bytesConsumed",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitLabel(L53);
                code.visitStmt1R(RETURN,2);
                code.visitLabel(L54);
                code.visitFieldStmt(IPUT_BOOLEAN,8,9,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_closing","Z"));
                code.visitLabel(L55);
                code.visitFieldStmt(IGET_OBJECT,2,9,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_result","Ljavax/net/ssl/SSLEngineResult;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljavax/net/ssl/SSLEngineResult;","bytesConsumed",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                DexLabel L74=new DexLabel();
                code.visitJumpStmt(IF_LEZ,2,-1,L74);
                code.visitFieldStmt(IGET_OBJECT,2,9,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_result","Ljavax/net/ssl/SSLEngineResult;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljavax/net/ssl/SSLEngineResult;","bytesConsumed",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(GOTO,-1,-1,L53);
                code.visitLabel(L74);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(-1)); // int: 0xffffffff  float:NaN
                code.visitJumpStmt(GOTO,-1,-1,L53);
                code.visitLabel(L7);
                code.visitStmt1R(MOVE_EXCEPTION,5);
                code.visitLabel(L17);
                code.visitFieldStmt(IGET_OBJECT,6,9,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_outBuffer","Ljava/nio/ByteBuffer;"));
                code.visitConstStmt(CONST_4,7, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,7},new Method("Ljava/nio/ByteBuffer;","position",new String[]{ "I"},"Ljava/nio/Buffer;"));
                code.visitLabel(L56);
                code.visitJumpStmt(IF_LEZ,0,-1,L62);
                code.visitJumpStmt(IF_EQZ,10,-1,L62);
                code.visitLabel(L57);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 10},new Method("Lorg/mortbay/io/Buffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitJumpStmt(IF_GE,0,6,L69);
                code.visitStmt2R(MOVE,1,0);
                code.visitLabel(L58);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 10,1},new Method("Lorg/mortbay/io/Buffer;","skip",new String[]{ "I"},"I"));
                code.visitLabel(L59);
                code.visitStmt2R(SUB_INT_2ADDR,0,1);
                code.visitLabel(L60);
                code.visitFieldStmt(IGET_OBJECT,6,9,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_gather","[Ljava/nio/ByteBuffer;"));
                code.visitConstStmt(CONST_4,7, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt3R(AGET_OBJECT,6,6,7);
                code.visitConstStmt(CONST_4,7, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,7},new Method("Ljava/nio/ByteBuffer;","position",new String[]{ "I"},"Ljava/nio/Buffer;"));
                code.visitLabel(L61);
                code.visitFieldStmt(IGET_OBJECT,6,9,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_gather","[Ljava/nio/ByteBuffer;"));
                code.visitConstStmt(CONST_4,7, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt3R(AGET_OBJECT,6,6,7);
                code.visitFieldStmt(IGET_OBJECT,7,9,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_gather","[Ljava/nio/ByteBuffer;"));
                code.visitConstStmt(CONST_4,8, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt3R(AGET_OBJECT,7,7,8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Ljava/nio/ByteBuffer;","capacity",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,7},new Method("Ljava/nio/ByteBuffer;","limit",new String[]{ "I"},"Ljava/nio/Buffer;"));
                code.visitLabel(L62);
                code.visitJumpStmt(IF_LEZ,0,-1,L68);
                code.visitJumpStmt(IF_EQZ,11,-1,L68);
                code.visitLabel(L63);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 11},new Method("Lorg/mortbay/io/Buffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitJumpStmt(IF_GE,0,6,L70);
                code.visitStmt2R(MOVE,1,0);
                code.visitLabel(L64);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 11,1},new Method("Lorg/mortbay/io/Buffer;","skip",new String[]{ "I"},"I"));
                code.visitLabel(L65);
                code.visitStmt2R(SUB_INT_2ADDR,0,1);
                code.visitLabel(L66);
                code.visitFieldStmt(IGET_OBJECT,6,9,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_gather","[Ljava/nio/ByteBuffer;"));
                code.visitConstStmt(CONST_4,7, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt3R(AGET_OBJECT,6,6,7);
                code.visitConstStmt(CONST_4,7, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,7},new Method("Ljava/nio/ByteBuffer;","position",new String[]{ "I"},"Ljava/nio/Buffer;"));
                code.visitLabel(L67);
                code.visitFieldStmt(IGET_OBJECT,6,9,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_gather","[Ljava/nio/ByteBuffer;"));
                code.visitConstStmt(CONST_4,7, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt3R(AGET_OBJECT,6,6,7);
                code.visitFieldStmt(IGET_OBJECT,7,9,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_gather","[Ljava/nio/ByteBuffer;"));
                code.visitConstStmt(CONST_4,8, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt3R(AGET_OBJECT,7,7,8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Ljava/nio/ByteBuffer;","capacity",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,7},new Method("Ljava/nio/ByteBuffer;","limit",new String[]{ "I"},"Ljava/nio/Buffer;"));
                code.visitLabel(L68);
                code.visitFieldStmt(SGET_BOOLEAN,6,-1,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","$assertionsDisabled","Z"));
                code.visitJumpStmt(IF_NEZ,6,-1,L13);
                code.visitJumpStmt(IF_EQZ,0,-1,L13);
                code.visitTypeStmt(NEW_INSTANCE,5,-1,"Ljava/lang/AssertionError;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 5},new Method("Ljava/lang/AssertionError;","<init>",new String[]{ },"V"));
                code.visitStmt1R(THROW,5);
                code.visitLabel(L69);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 10},new Method("Lorg/mortbay/io/Buffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitStmt2R(MOVE,1,6);
                code.visitJumpStmt(GOTO,-1,-1,L58);
                code.visitLabel(L70);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 11},new Method("Lorg/mortbay/io/Buffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitStmt2R(MOVE,1,6);
                code.visitJumpStmt(GOTO,-1,-1,L64);
                code.visitLabel(L71);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 10},new Method("Lorg/mortbay/io/Buffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitStmt2R(MOVE,1,5);
                code.visitJumpStmt(GOTO_16,-1,-1,L37);
                code.visitLabel(L72);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 11},new Method("Lorg/mortbay/io/Buffer;","length",new String[]{ },"I"));
                code.visitLabel(L18);
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitStmt2R(MOVE,1,5);
                code.visitJumpStmt(GOTO_16,-1,-1,L43);
                code.visitLabel(L73);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m007_close(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","close",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(15);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2,L3,L4},new String[]{ "Ljava/io/IOException;","Ljava/lang/InterruptedException;",null});
                DexLabel L5=new DexLabel();
                DexLabel L6=new DexLabel();
                DexLabel L7=new DexLabel();
                code.visitTryCatch(L5,L6,new DexLabel[]{L6,L7,L4},new String[]{ "Ljava/io/IOException;","Ljava/lang/InterruptedException;",null});
                DexLabel L8=new DexLabel();
                DexLabel L9=new DexLabel();
                code.visitTryCatch(L8,L9,new DexLabel[]{L4},new String[]{ null});
                DexLabel L10=new DexLabel();
                DexLabel L11=new DexLabel();
                code.visitTryCatch(L10,L11,new DexLabel[]{L6,L7,L4},new String[]{ "Ljava/io/IOException;","Ljava/lang/InterruptedException;",null});
                DexLabel L12=new DexLabel();
                DexLabel L13=new DexLabel();
                code.visitTryCatch(L12,L13,new DexLabel[]{L2,L3,L4},new String[]{ "Ljava/io/IOException;","Ljava/lang/InterruptedException;",null});
                DexLabel L14=new DexLabel();
                code.visitTryCatch(L14,L7,new DexLabel[]{L6,L7,L4},new String[]{ "Ljava/io/IOException;","Ljava/lang/InterruptedException;",null});
                DexLabel L15=new DexLabel();
                DexLabel L16=new DexLabel();
                code.visitTryCatch(L15,L16,new DexLabel[]{L4},new String[]{ null});
                DexLabel L17=new DexLabel();
                DexLabel L18=new DexLabel();
                code.visitTryCatch(L17,L18,new DexLabel[]{L6,L7,L4},new String[]{ "Ljava/io/IOException;","Ljava/lang/InterruptedException;",null});
                DexLabel L19=new DexLabel();
                DexLabel L20=new DexLabel();
                DexLabel L21=new DexLabel();
                DexLabel L22=new DexLabel();
                code.visitTryCatch(L19,L20,new DexLabel[]{L21,L22},new String[]{ "Ljavax/net/ssl/SSLException;",null});
                DexLabel L23=new DexLabel();
                DexLabel L24=new DexLabel();
                code.visitTryCatch(L23,L24,new DexLabel[]{L6,L7,L4},new String[]{ "Ljava/io/IOException;","Ljava/lang/InterruptedException;",null});
                DexLabel L25=new DexLabel();
                DexLabel L26=new DexLabel();
                code.visitTryCatch(L25,L26,new DexLabel[]{L22},new String[]{ null});
                DexLabel L27=new DexLabel();
                code.visitTryCatch(L26,L27,new DexLabel[]{L6,L7,L4},new String[]{ "Ljava/io/IOException;","Ljava/lang/InterruptedException;",null});
                DexLabel L28=new DexLabel();
                DexLabel L29=new DexLabel();
                code.visitTryCatch(L28,L29,new DexLabel[]{L6,L7,L4},new String[]{ "Ljava/io/IOException;","Ljava/lang/InterruptedException;",null});
                DexLabel L30=new DexLabel();
                DexLabel L31=new DexLabel();
                code.visitTryCatch(L29,L30,new DexLabel[]{L31},new String[]{ null});
                DexLabel L32=new DexLabel();
                code.visitTryCatch(L30,L32,new DexLabel[]{L6,L7,L4},new String[]{ "Ljava/io/IOException;","Ljava/lang/InterruptedException;",null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L33=new DexLabel();
                ddv.visitPrologue(L33);
                DexLabel L34=new DexLabel();
                ddv.visitLineNumber(131,L34);
                DexLabel L35=new DexLabel();
                ddv.visitLineNumber(134,L35);
                DexLabel L36=new DexLabel();
                ddv.visitStartLocal(6,L36,"tries","I",null);
                ddv.visitLineNumber(136,L0);
                ddv.visitEndLocal(6,L0);
                ddv.visitStartLocal(7,L0,"tries","I",null);
                DexLabel L37=new DexLabel();
                ddv.visitLineNumber(139,L37);
                DexLabel L38=new DexLabel();
                ddv.visitRestartLocal(6,L38);
                ddv.visitLineNumber(140,L5);
                ddv.visitEndLocal(7,L5);
                ddv.visitLineNumber(223,L6);
                ddv.visitLineNumber(225,L8);
                ddv.visitStartLocal(3,L8,"e","Ljava/io/IOException;",null);
                ddv.visitLineNumber(233,L9);
                DexLabel L39=new DexLabel();
                ddv.visitLineNumber(235,L39);
                DexLabel L40=new DexLabel();
                ddv.visitLineNumber(236,L40);
                DexLabel L41=new DexLabel();
                ddv.visitLineNumber(237,L41);
                DexLabel L42=new DexLabel();
                ddv.visitLineNumber(238,L42);
                DexLabel L43=new DexLabel();
                ddv.visitLineNumber(239,L43);
                DexLabel L44=new DexLabel();
                ddv.visitLineNumber(240,L44);
                DexLabel L45=new DexLabel();
                ddv.visitLineNumber(241,L45);
                DexLabel L46=new DexLabel();
                ddv.visitLineNumber(242,L46);
                DexLabel L47=new DexLabel();
                ddv.visitEndLocal(3,L47);
                DexLabel L48=new DexLabel();
                ddv.visitLineNumber(244,L48);
                ddv.visitLineNumber(141,L10);
                DexLabel L49=new DexLabel();
                ddv.visitLineNumber(142,L49);
                DexLabel L50=new DexLabel();
                ddv.visitRestartLocal(7,L50);
                ddv.visitLineNumber(145,L12);
                ddv.visitEndLocal(6,L12);
                DexLabel L51=new DexLabel();
                ddv.visitLineNumber(147,L51);
                DexLabel L52=new DexLabel();
                ddv.visitLineNumber(150,L52);
                DexLabel L53=new DexLabel();
                ddv.visitRestartLocal(6,L53);
                ddv.visitLineNumber(151,L14);
                ddv.visitEndLocal(7,L14);
                ddv.visitLineNumber(227,L7);
                ddv.visitLineNumber(229,L15);
                ddv.visitStartLocal(3,L15,"e","Ljava/lang/InterruptedException;",null);
                ddv.visitLineNumber(233,L16);
                DexLabel L54=new DexLabel();
                ddv.visitLineNumber(235,L54);
                DexLabel L55=new DexLabel();
                ddv.visitLineNumber(236,L55);
                DexLabel L56=new DexLabel();
                ddv.visitLineNumber(237,L56);
                DexLabel L57=new DexLabel();
                ddv.visitLineNumber(238,L57);
                DexLabel L58=new DexLabel();
                ddv.visitLineNumber(239,L58);
                DexLabel L59=new DexLabel();
                ddv.visitLineNumber(240,L59);
                DexLabel L60=new DexLabel();
                ddv.visitLineNumber(241,L60);
                DexLabel L61=new DexLabel();
                ddv.visitLineNumber(242,L61);
                ddv.visitLineNumber(153,L17);
                ddv.visitEndLocal(3,L17);
                DexLabel L62=new DexLabel();
                ddv.visitLineNumber(155,L62);
                DexLabel L63=new DexLabel();
                ddv.visitLineNumber(156,L63);
                DexLabel L64=new DexLabel();
                ddv.visitLineNumber(159,L64);
                DexLabel L65=new DexLabel();
                ddv.visitLineNumber(218,L65);
                ddv.visitRestartLocal(7,L65);
                DexLabel L66=new DexLabel();
                ddv.visitLineNumber(166,L66);
                ddv.visitEndLocal(7,L66);
                ddv.visitLineNumber(169,L19);
                ddv.visitStartLocal(2,L19,"buffer","Lorg/mortbay/io/Buffer;",null);
                DexLabel L67=new DexLabel();
                ddv.visitLineNumber(170,L67);
                ddv.visitStartLocal(1,L67,"bbuffer","Ljava/nio/ByteBuffer;",null);
                ddv.visitLineNumber(182,L23);
                ddv.visitLineNumber(233,L24);
                ddv.visitEndLocal(2,L24);
                ddv.visitEndLocal(1,L24);
                DexLabel L68=new DexLabel();
                ddv.visitLineNumber(235,L68);
                DexLabel L69=new DexLabel();
                ddv.visitLineNumber(236,L69);
                DexLabel L70=new DexLabel();
                ddv.visitLineNumber(237,L70);
                DexLabel L71=new DexLabel();
                ddv.visitLineNumber(238,L71);
                DexLabel L72=new DexLabel();
                ddv.visitLineNumber(239,L72);
                DexLabel L73=new DexLabel();
                ddv.visitLineNumber(240,L73);
                DexLabel L74=new DexLabel();
                ddv.visitLineNumber(241,L74);
                DexLabel L75=new DexLabel();
                ddv.visitLineNumber(242,L75);
                ddv.visitLineNumber(176,L21);
                ddv.visitRestartLocal(2,L21);
                ddv.visitLineNumber(178,L25);
                ddv.visitStartLocal(3,L25,"e","Ljavax/net/ssl/SSLException;",null);
                ddv.visitLineNumber(182,L26);
                ddv.visitLineNumber(233,L4);
                ddv.visitEndLocal(6,L4);
                ddv.visitEndLocal(2,L4);
                ddv.visitEndLocal(3,L4);
                DexLabel L76=new DexLabel();
                ddv.visitLineNumber(235,L76);
                DexLabel L77=new DexLabel();
                ddv.visitLineNumber(236,L77);
                DexLabel L78=new DexLabel();
                ddv.visitLineNumber(237,L78);
                DexLabel L79=new DexLabel();
                ddv.visitLineNumber(238,L79);
                DexLabel L80=new DexLabel();
                ddv.visitLineNumber(239,L80);
                DexLabel L81=new DexLabel();
                ddv.visitLineNumber(240,L81);
                DexLabel L82=new DexLabel();
                ddv.visitLineNumber(241,L82);
                DexLabel L83=new DexLabel();
                ddv.visitLineNumber(242,L83);
                DexLabel L84=new DexLabel();
                ddv.visitLineNumber(233,L84);
                ddv.visitLineNumber(182,L22);
                ddv.visitRestartLocal(2,L22);
                ddv.visitRestartLocal(6,L22);
                DexLabel L85=new DexLabel();
                ddv.visitLineNumber(189,L85);
                ddv.visitEndLocal(2,L85);
                DexLabel L86=new DexLabel();
                ddv.visitStartLocal(5,L86,"task","Ljava/lang/Runnable;",null);
                DexLabel L87=new DexLabel();
                ddv.visitLineNumber(191,L87);
                DexLabel L88=new DexLabel();
                ddv.visitLineNumber(198,L88);
                ddv.visitEndLocal(5,L88);
                DexLabel L89=new DexLabel();
                ddv.visitLineNumber(199,L89);
                ddv.visitLineNumber(203,L29);
                DexLabel L90=new DexLabel();
                ddv.visitLineNumber(204,L90);
                DexLabel L91=new DexLabel();
                ddv.visitLineNumber(205,L91);
                ddv.visitStartLocal(4,L91,"put","I",null);
                DexLabel L92=new DexLabel();
                ddv.visitLineNumber(206,L92);
                DexLabel L93=new DexLabel();
                ddv.visitLineNumber(207,L93);
                DexLabel L94=new DexLabel();
                ddv.visitLineNumber(208,L94);
                DexLabel L95=new DexLabel();
                ddv.visitLineNumber(209,L95);
                ddv.visitLineNumber(213,L30);
                DexLabel L96=new DexLabel();
                ddv.visitLineNumber(216,L96);
                ddv.visitLineNumber(213,L31);
                ddv.visitEndLocal(4,L31);
                DexLabel L97=new DexLabel();
                ddv.visitLineNumber(182,L97);
                ddv.visitRestartLocal(1,L97);
                ddv.visitRestartLocal(2,L97);
                ddv.visitLineNumber(227,L3);
                ddv.visitEndLocal(6,L3);
                ddv.visitEndLocal(1,L3);
                ddv.visitEndLocal(2,L3);
                ddv.visitRestartLocal(7,L3);
                DexLabel L98=new DexLabel();
                ddv.visitRestartLocal(6,L98);
                ddv.visitLineNumber(223,L2);
                ddv.visitEndLocal(6,L2);
                DexLabel L99=new DexLabel();
                ddv.visitRestartLocal(6,L99);
                DexLabel L100=new DexLabel();
                ddv.visitEndLocal(6,L100);
                DexLabel L101=new DexLabel();
                ddv.visitRestartLocal(6,L101);
                DexLabel L102=new DexLabel();
                ddv.visitLineNumber(159,L102);
                code.visitLabel(L33);
                code.visitConstStmt(CONST_16,13, Integer.valueOf(100)); // int: 0x00000064  float:0.000000
                code.visitConstStmt(CONST_4,12, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitConstStmt(CONST_4,11, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L34);
                code.visitFieldStmt(IPUT_BOOLEAN,12,14,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_closing","Z"));
                code.visitLabel(L35);
                code.visitConstStmt(CONST_4,6, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L36);
                code.visitStmt2R(MOVE,7,6);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,8,14,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_outNIOBuffer","Lorg/mortbay/io/nio/NIOBuffer;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 8},new Method("Lorg/mortbay/io/nio/NIOBuffer;","length",new String[]{ },"I"));
                code.visitLabel(L1);
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitJumpStmt(IF_LEZ,8,-1,L12);
                code.visitLabel(L37);
                code.visitStmt2R1N(ADD_INT_LIT8,6,7,1);
                code.visitLabel(L38);
                code.visitJumpStmt(IF_LE,7,13,L10);
                code.visitLabel(L5);
                code.visitTypeStmt(NEW_INSTANCE,8,-1,"Ljava/lang/IllegalStateException;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 8},new Method("Ljava/lang/IllegalStateException;","<init>",new String[]{ },"V"));
                code.visitStmt1R(THROW,8);
                code.visitLabel(L6);
                code.visitStmt1R(MOVE_EXCEPTION,8);
                code.visitStmt2R(MOVE_OBJECT,3,8);
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3},new Method("Lorg/mortbay/log/Log;","ignore",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 14},new Method("Lorg/mortbay/jetty/nio/SelectChannelConnector$ConnectorEndPoint;","close",new String[]{ },"V"));
                code.visitLabel(L39);
                code.visitFieldStmt(IGET_OBJECT,8,14,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_inNIOBuffer","Lorg/mortbay/io/nio/NIOBuffer;"));
                code.visitJumpStmt(IF_EQZ,8,-1,L41);
                code.visitLabel(L40);
                code.visitFieldStmt(IGET_OBJECT,8,14,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_buffers","Lorg/mortbay/io/Buffers;"));
                code.visitFieldStmt(IGET_OBJECT,9,14,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_inNIOBuffer","Lorg/mortbay/io/nio/NIOBuffer;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 8,9},new Method("Lorg/mortbay/io/Buffers;","returnBuffer",new String[]{ "Lorg/mortbay/io/Buffer;"},"V"));
                code.visitLabel(L41);
                code.visitFieldStmt(IGET_OBJECT,8,14,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_outNIOBuffer","Lorg/mortbay/io/nio/NIOBuffer;"));
                code.visitJumpStmt(IF_EQZ,8,-1,L43);
                code.visitLabel(L42);
                code.visitFieldStmt(IGET_OBJECT,8,14,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_buffers","Lorg/mortbay/io/Buffers;"));
                code.visitFieldStmt(IGET_OBJECT,9,14,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_outNIOBuffer","Lorg/mortbay/io/nio/NIOBuffer;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 8,9},new Method("Lorg/mortbay/io/Buffers;","returnBuffer",new String[]{ "Lorg/mortbay/io/Buffer;"},"V"));
                code.visitLabel(L43);
                code.visitFieldStmt(IGET_OBJECT,8,14,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_reuseBuffer","[Lorg/mortbay/io/nio/NIOBuffer;"));
                code.visitStmt3R(AGET_OBJECT,8,8,11);
                code.visitJumpStmt(IF_EQZ,8,-1,L45);
                code.visitLabel(L44);
                code.visitFieldStmt(IGET_OBJECT,8,14,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_buffers","Lorg/mortbay/io/Buffers;"));
                code.visitFieldStmt(IGET_OBJECT,9,14,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_reuseBuffer","[Lorg/mortbay/io/nio/NIOBuffer;"));
                code.visitStmt3R(AGET_OBJECT,9,9,11);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 8,9},new Method("Lorg/mortbay/io/Buffers;","returnBuffer",new String[]{ "Lorg/mortbay/io/Buffer;"},"V"));
                code.visitLabel(L45);
                code.visitFieldStmt(IGET_OBJECT,8,14,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_reuseBuffer","[Lorg/mortbay/io/nio/NIOBuffer;"));
                code.visitStmt3R(AGET_OBJECT,8,8,12);
                code.visitJumpStmt(IF_EQZ,8,-1,L48);
                code.visitLabel(L46);
                code.visitFieldStmt(IGET_OBJECT,8,14,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_buffers","Lorg/mortbay/io/Buffers;"));
                code.visitFieldStmt(IGET_OBJECT,9,14,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_reuseBuffer","[Lorg/mortbay/io/nio/NIOBuffer;"));
                code.visitStmt3R(AGET_OBJECT,9,9,12);
                code.visitLabel(L47);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 8,9},new Method("Lorg/mortbay/io/Buffers;","returnBuffer",new String[]{ "Lorg/mortbay/io/Buffer;"},"V"));
                code.visitLabel(L48);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 14},new Method("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","flush",new String[]{ },"V"));
                code.visitLabel(L49);
                code.visitConstStmt(CONST_WIDE_16,8,Long.valueOf(100L)); // long: 0x0000000000000064  double:0.000000
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 8,9},new Method("Ljava/lang/Thread;","sleep",new String[]{ "J"},"V"));
                code.visitLabel(L11);
                code.visitStmt2R(MOVE,7,6);
                code.visitLabel(L50);
                code.visitJumpStmt(GOTO,-1,-1,L0);
                code.visitLabel(L12);
                code.visitFieldStmt(IGET_OBJECT,8,14,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_engine","Ljavax/net/ssl/SSLEngine;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Ljavax/net/ssl/SSLEngine;","closeOutbound",new String[]{ },"V"));
                code.visitLabel(L51);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 14},new Method("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","isOpen",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitJumpStmt(IF_EQZ,8,-1,L100);
                code.visitFieldStmt(IGET_OBJECT,8,14,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_engine","Ljavax/net/ssl/SSLEngine;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Ljavax/net/ssl/SSLEngine;","isInboundDone",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitJumpStmt(IF_EQZ,8,-1,L52);
                code.visitFieldStmt(IGET_OBJECT,8,14,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_engine","Ljavax/net/ssl/SSLEngine;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Ljavax/net/ssl/SSLEngine;","isOutboundDone",new String[]{ },"Z"));
                code.visitLabel(L13);
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitJumpStmt(IF_NEZ,8,-1,L100);
                code.visitLabel(L52);
                code.visitStmt2R1N(ADD_INT_LIT8,6,7,1);
                code.visitLabel(L53);
                code.visitJumpStmt(IF_LE,7,13,L17);
                code.visitLabel(L14);
                code.visitTypeStmt(NEW_INSTANCE,8,-1,"Ljava/lang/IllegalStateException;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 8},new Method("Ljava/lang/IllegalStateException;","<init>",new String[]{ },"V"));
                code.visitStmt1R(THROW,8);
                code.visitLabel(L7);
                code.visitStmt1R(MOVE_EXCEPTION,8);
                code.visitStmt2R(MOVE_OBJECT,3,8);
                code.visitLabel(L15);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3},new Method("Lorg/mortbay/log/Log;","ignore",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitLabel(L16);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 14},new Method("Lorg/mortbay/jetty/nio/SelectChannelConnector$ConnectorEndPoint;","close",new String[]{ },"V"));
                code.visitLabel(L54);
                code.visitFieldStmt(IGET_OBJECT,8,14,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_inNIOBuffer","Lorg/mortbay/io/nio/NIOBuffer;"));
                code.visitJumpStmt(IF_EQZ,8,-1,L56);
                code.visitLabel(L55);
                code.visitFieldStmt(IGET_OBJECT,8,14,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_buffers","Lorg/mortbay/io/Buffers;"));
                code.visitFieldStmt(IGET_OBJECT,9,14,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_inNIOBuffer","Lorg/mortbay/io/nio/NIOBuffer;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 8,9},new Method("Lorg/mortbay/io/Buffers;","returnBuffer",new String[]{ "Lorg/mortbay/io/Buffer;"},"V"));
                code.visitLabel(L56);
                code.visitFieldStmt(IGET_OBJECT,8,14,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_outNIOBuffer","Lorg/mortbay/io/nio/NIOBuffer;"));
                code.visitJumpStmt(IF_EQZ,8,-1,L58);
                code.visitLabel(L57);
                code.visitFieldStmt(IGET_OBJECT,8,14,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_buffers","Lorg/mortbay/io/Buffers;"));
                code.visitFieldStmt(IGET_OBJECT,9,14,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_outNIOBuffer","Lorg/mortbay/io/nio/NIOBuffer;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 8,9},new Method("Lorg/mortbay/io/Buffers;","returnBuffer",new String[]{ "Lorg/mortbay/io/Buffer;"},"V"));
                code.visitLabel(L58);
                code.visitFieldStmt(IGET_OBJECT,8,14,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_reuseBuffer","[Lorg/mortbay/io/nio/NIOBuffer;"));
                code.visitStmt3R(AGET_OBJECT,8,8,11);
                code.visitJumpStmt(IF_EQZ,8,-1,L60);
                code.visitLabel(L59);
                code.visitFieldStmt(IGET_OBJECT,8,14,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_buffers","Lorg/mortbay/io/Buffers;"));
                code.visitFieldStmt(IGET_OBJECT,9,14,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_reuseBuffer","[Lorg/mortbay/io/nio/NIOBuffer;"));
                code.visitStmt3R(AGET_OBJECT,9,9,11);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 8,9},new Method("Lorg/mortbay/io/Buffers;","returnBuffer",new String[]{ "Lorg/mortbay/io/Buffer;"},"V"));
                code.visitLabel(L60);
                code.visitFieldStmt(IGET_OBJECT,8,14,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_reuseBuffer","[Lorg/mortbay/io/nio/NIOBuffer;"));
                code.visitStmt3R(AGET_OBJECT,8,8,12);
                code.visitJumpStmt(IF_EQZ,8,-1,L48);
                code.visitLabel(L61);
                code.visitFieldStmt(IGET_OBJECT,8,14,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_buffers","Lorg/mortbay/io/Buffers;"));
                code.visitFieldStmt(IGET_OBJECT,9,14,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_reuseBuffer","[Lorg/mortbay/io/nio/NIOBuffer;"));
                code.visitStmt3R(AGET_OBJECT,9,9,12);
                code.visitJumpStmt(GOTO,-1,-1,L47);
                code.visitLabel(L17);
                code.visitFieldStmt(IGET_OBJECT,8,14,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_outNIOBuffer","Lorg/mortbay/io/nio/NIOBuffer;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 8},new Method("Lorg/mortbay/io/nio/NIOBuffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitJumpStmt(IF_LEZ,8,-1,L64);
                code.visitLabel(L62);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 14},new Method("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","flush",new String[]{ },"V"));
                code.visitLabel(L63);
                code.visitConstStmt(CONST_WIDE_16,8,Long.valueOf(100L)); // long: 0x0000000000000064  double:0.000000
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 8,9},new Method("Ljava/lang/Thread;","sleep",new String[]{ "J"},"V"));
                code.visitLabel(L64);
                code.visitFieldStmt(SGET_OBJECT,8,-1,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint$2;","$SwitchMap$javax$net$ssl$SSLEngineResult$HandshakeStatus","[I"));
                code.visitFieldStmt(IGET_OBJECT,9,14,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_engine","Ljavax/net/ssl/SSLEngine;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9},new Method("Ljavax/net/ssl/SSLEngine;","getHandshakeStatus",new String[]{ },"Ljavax/net/ssl/SSLEngineResult$HandshakeStatus;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9},new Method("Ljavax/net/ssl/SSLEngineResult$HandshakeStatus;","ordinal",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,9);
                code.visitStmt3R(AGET,8,8,9);
                code.visitSparseSwitchStmt(PACKED_SWITCH,8,1,new DexLabel[]{L24,L24,L66,L85,L88});
                DexLabel L103=new DexLabel();
                code.visitLabel(L103);
                code.visitStmt2R(MOVE,7,6);
                code.visitLabel(L65);
                code.visitJumpStmt(GOTO,-1,-1,L51);
                code.visitLabel(L66);
                code.visitFieldStmt(IGET_OBJECT,8,14,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_buffers","Lorg/mortbay/io/Buffers;"));
                code.visitFieldStmt(IGET_OBJECT,9,14,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_engine","Ljavax/net/ssl/SSLEngine;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9},new Method("Ljavax/net/ssl/SSLEngine;","getSession",new String[]{ },"Ljavax/net/ssl/SSLSession;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 9},new Method("Ljavax/net/ssl/SSLSession;","getApplicationBufferSize",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,9);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 8,9},new Method("Lorg/mortbay/io/Buffers;","getBuffer",new String[]{ "I"},"Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L18);
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L19);
                code.visitStmt2R(MOVE_OBJECT,0,2);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Lorg/mortbay/io/nio/NIOBuffer;");
                code.visitStmt2R(MOVE_OBJECT,8,0);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 8},new Method("Lorg/mortbay/io/nio/NIOBuffer;","getByteBuffer",new String[]{ },"Ljava/nio/ByteBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L67);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 14,1},new Method("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","unwrap",new String[]{ "Ljava/nio/ByteBuffer;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitJumpStmt(IF_NEZ,8,-1,L97);
                code.visitFieldStmt(IGET_OBJECT,8,14,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_engine","Ljavax/net/ssl/SSLEngine;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Ljavax/net/ssl/SSLEngine;","getHandshakeStatus",new String[]{ },"Ljavax/net/ssl/SSLEngineResult$HandshakeStatus;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitFieldStmt(SGET_OBJECT,9,-1,new Field("Ljavax/net/ssl/SSLEngineResult$HandshakeStatus;","NEED_UNWRAP","Ljavax/net/ssl/SSLEngineResult$HandshakeStatus;"));
                code.visitLabel(L20);
                code.visitJumpStmt(IF_NE,8,9,L97);
                code.visitLabel(L23);
                code.visitFieldStmt(IGET_OBJECT,8,14,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_buffers","Lorg/mortbay/io/Buffers;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 8,2},new Method("Lorg/mortbay/io/Buffers;","returnBuffer",new String[]{ "Lorg/mortbay/io/Buffer;"},"V"));
                code.visitLabel(L24);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 14},new Method("Lorg/mortbay/jetty/nio/SelectChannelConnector$ConnectorEndPoint;","close",new String[]{ },"V"));
                code.visitLabel(L68);
                code.visitFieldStmt(IGET_OBJECT,8,14,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_inNIOBuffer","Lorg/mortbay/io/nio/NIOBuffer;"));
                code.visitJumpStmt(IF_EQZ,8,-1,L70);
                code.visitLabel(L69);
                code.visitFieldStmt(IGET_OBJECT,8,14,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_buffers","Lorg/mortbay/io/Buffers;"));
                code.visitFieldStmt(IGET_OBJECT,9,14,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_inNIOBuffer","Lorg/mortbay/io/nio/NIOBuffer;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 8,9},new Method("Lorg/mortbay/io/Buffers;","returnBuffer",new String[]{ "Lorg/mortbay/io/Buffer;"},"V"));
                code.visitLabel(L70);
                code.visitFieldStmt(IGET_OBJECT,8,14,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_outNIOBuffer","Lorg/mortbay/io/nio/NIOBuffer;"));
                code.visitJumpStmt(IF_EQZ,8,-1,L72);
                code.visitLabel(L71);
                code.visitFieldStmt(IGET_OBJECT,8,14,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_buffers","Lorg/mortbay/io/Buffers;"));
                code.visitFieldStmt(IGET_OBJECT,9,14,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_outNIOBuffer","Lorg/mortbay/io/nio/NIOBuffer;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 8,9},new Method("Lorg/mortbay/io/Buffers;","returnBuffer",new String[]{ "Lorg/mortbay/io/Buffer;"},"V"));
                code.visitLabel(L72);
                code.visitFieldStmt(IGET_OBJECT,8,14,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_reuseBuffer","[Lorg/mortbay/io/nio/NIOBuffer;"));
                code.visitStmt3R(AGET_OBJECT,8,8,11);
                code.visitJumpStmt(IF_EQZ,8,-1,L74);
                code.visitLabel(L73);
                code.visitFieldStmt(IGET_OBJECT,8,14,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_buffers","Lorg/mortbay/io/Buffers;"));
                code.visitFieldStmt(IGET_OBJECT,9,14,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_reuseBuffer","[Lorg/mortbay/io/nio/NIOBuffer;"));
                code.visitStmt3R(AGET_OBJECT,9,9,11);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 8,9},new Method("Lorg/mortbay/io/Buffers;","returnBuffer",new String[]{ "Lorg/mortbay/io/Buffer;"},"V"));
                code.visitLabel(L74);
                code.visitFieldStmt(IGET_OBJECT,8,14,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_reuseBuffer","[Lorg/mortbay/io/nio/NIOBuffer;"));
                code.visitStmt3R(AGET_OBJECT,8,8,12);
                code.visitJumpStmt(IF_EQZ,8,-1,L48);
                code.visitLabel(L75);
                code.visitFieldStmt(IGET_OBJECT,8,14,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_buffers","Lorg/mortbay/io/Buffers;"));
                code.visitFieldStmt(IGET_OBJECT,9,14,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_reuseBuffer","[Lorg/mortbay/io/nio/NIOBuffer;"));
                code.visitStmt3R(AGET_OBJECT,9,9,12);
                code.visitJumpStmt(GOTO_16,-1,-1,L47);
                code.visitLabel(L21);
                code.visitStmt1R(MOVE_EXCEPTION,8);
                code.visitStmt2R(MOVE_OBJECT,3,8);
                code.visitLabel(L25);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3},new Method("Lorg/mortbay/log/Log;","ignore",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitLabel(L26);
                code.visitFieldStmt(IGET_OBJECT,8,14,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_buffers","Lorg/mortbay/io/Buffers;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 8,2},new Method("Lorg/mortbay/io/Buffers;","returnBuffer",new String[]{ "Lorg/mortbay/io/Buffer;"},"V"));
                code.visitLabel(L27);
                code.visitJumpStmt(GOTO,-1,-1,L103);
                code.visitLabel(L4);
                code.visitStmt1R(MOVE_EXCEPTION,8);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 14},new Method("Lorg/mortbay/jetty/nio/SelectChannelConnector$ConnectorEndPoint;","close",new String[]{ },"V"));
                code.visitLabel(L76);
                code.visitFieldStmt(IGET_OBJECT,9,14,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_inNIOBuffer","Lorg/mortbay/io/nio/NIOBuffer;"));
                code.visitJumpStmt(IF_EQZ,9,-1,L78);
                code.visitLabel(L77);
                code.visitFieldStmt(IGET_OBJECT,9,14,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_buffers","Lorg/mortbay/io/Buffers;"));
                code.visitFieldStmt(IGET_OBJECT,10,14,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_inNIOBuffer","Lorg/mortbay/io/nio/NIOBuffer;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 9,10},new Method("Lorg/mortbay/io/Buffers;","returnBuffer",new String[]{ "Lorg/mortbay/io/Buffer;"},"V"));
                code.visitLabel(L78);
                code.visitFieldStmt(IGET_OBJECT,9,14,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_outNIOBuffer","Lorg/mortbay/io/nio/NIOBuffer;"));
                code.visitJumpStmt(IF_EQZ,9,-1,L80);
                code.visitLabel(L79);
                code.visitFieldStmt(IGET_OBJECT,9,14,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_buffers","Lorg/mortbay/io/Buffers;"));
                code.visitFieldStmt(IGET_OBJECT,10,14,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_outNIOBuffer","Lorg/mortbay/io/nio/NIOBuffer;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 9,10},new Method("Lorg/mortbay/io/Buffers;","returnBuffer",new String[]{ "Lorg/mortbay/io/Buffer;"},"V"));
                code.visitLabel(L80);
                code.visitFieldStmt(IGET_OBJECT,9,14,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_reuseBuffer","[Lorg/mortbay/io/nio/NIOBuffer;"));
                code.visitStmt3R(AGET_OBJECT,9,9,11);
                code.visitJumpStmt(IF_EQZ,9,-1,L82);
                code.visitLabel(L81);
                code.visitFieldStmt(IGET_OBJECT,9,14,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_buffers","Lorg/mortbay/io/Buffers;"));
                code.visitFieldStmt(IGET_OBJECT,10,14,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_reuseBuffer","[Lorg/mortbay/io/nio/NIOBuffer;"));
                code.visitStmt3R(AGET_OBJECT,10,10,11);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 9,10},new Method("Lorg/mortbay/io/Buffers;","returnBuffer",new String[]{ "Lorg/mortbay/io/Buffer;"},"V"));
                code.visitLabel(L82);
                code.visitFieldStmt(IGET_OBJECT,9,14,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_reuseBuffer","[Lorg/mortbay/io/nio/NIOBuffer;"));
                code.visitStmt3R(AGET_OBJECT,9,9,12);
                code.visitJumpStmt(IF_EQZ,9,-1,L84);
                code.visitLabel(L83);
                code.visitFieldStmt(IGET_OBJECT,9,14,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_buffers","Lorg/mortbay/io/Buffers;"));
                code.visitFieldStmt(IGET_OBJECT,10,14,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_reuseBuffer","[Lorg/mortbay/io/nio/NIOBuffer;"));
                code.visitStmt3R(AGET_OBJECT,10,10,12);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 9,10},new Method("Lorg/mortbay/io/Buffers;","returnBuffer",new String[]{ "Lorg/mortbay/io/Buffer;"},"V"));
                code.visitLabel(L84);
                code.visitStmt1R(THROW,8);
                code.visitLabel(L22);
                code.visitStmt1R(MOVE_EXCEPTION,8);
                code.visitLabel(L28);
                code.visitFieldStmt(IGET_OBJECT,9,14,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_buffers","Lorg/mortbay/io/Buffers;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 9,2},new Method("Lorg/mortbay/io/Buffers;","returnBuffer",new String[]{ "Lorg/mortbay/io/Buffer;"},"V"));
                code.visitStmt1R(THROW,8);
                code.visitLabel(L85);
                code.visitFieldStmt(IGET_OBJECT,8,14,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_engine","Ljavax/net/ssl/SSLEngine;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Ljavax/net/ssl/SSLEngine;","getDelegatedTask",new String[]{ },"Ljava/lang/Runnable;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitLabel(L86);
                code.visitJumpStmt(IF_EQZ,5,-1,L103);
                code.visitLabel(L87);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 5},new Method("Ljava/lang/Runnable;","run",new String[]{ },"V"));
                code.visitJumpStmt(GOTO,-1,-1,L85);
                code.visitLabel(L88);
                code.visitFieldStmt(IGET_OBJECT,8,14,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_outNIOBuffer","Lorg/mortbay/io/nio/NIOBuffer;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 8},new Method("Lorg/mortbay/io/nio/NIOBuffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitJumpStmt(IF_LEZ,8,-1,L29);
                code.visitLabel(L89);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 14},new Method("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","flush",new String[]{ },"V"));
                code.visitLabel(L29);
                code.visitFieldStmt(IGET_OBJECT,8,14,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_outNIOBuffer","Lorg/mortbay/io/nio/NIOBuffer;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 8},new Method("Lorg/mortbay/io/nio/NIOBuffer;","compact",new String[]{ },"V"));
                code.visitLabel(L90);
                code.visitFieldStmt(IGET_OBJECT,8,14,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_outNIOBuffer","Lorg/mortbay/io/nio/NIOBuffer;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 8},new Method("Lorg/mortbay/io/nio/NIOBuffer;","putIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitLabel(L91);
                code.visitFieldStmt(IGET_OBJECT,8,14,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_outBuffer","Ljava/nio/ByteBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,4},new Method("Ljava/nio/ByteBuffer;","position",new String[]{ "I"},"Ljava/nio/Buffer;"));
                code.visitLabel(L92);
                code.visitConstStmt(CONST_4,8, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_OBJECT,8,14,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_result","Ljavax/net/ssl/SSLEngineResult;"));
                code.visitLabel(L93);
                code.visitConstStmt(CONST_STRING,8,"close wrap");
                code.visitFieldStmt(IPUT_OBJECT,8,14,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_last","Ljava/lang/String;"));
                code.visitLabel(L94);
                code.visitFieldStmt(IGET_OBJECT,8,14,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_engine","Ljavax/net/ssl/SSLEngine;"));
                code.visitFieldStmt(SGET_OBJECT,9,-1,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","__NO_BUFFERS","[Ljava/nio/ByteBuffer;"));
                code.visitFieldStmt(IGET_OBJECT,10,14,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_outBuffer","Ljava/nio/ByteBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,9,10},new Method("Ljavax/net/ssl/SSLEngine;","wrap",new String[]{ "[Ljava/nio/ByteBuffer;","Ljava/nio/ByteBuffer;"},"Ljavax/net/ssl/SSLEngineResult;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitFieldStmt(IPUT_OBJECT,8,14,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_result","Ljavax/net/ssl/SSLEngineResult;"));
                code.visitLabel(L95);
                code.visitFieldStmt(IGET_OBJECT,8,14,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_outNIOBuffer","Lorg/mortbay/io/nio/NIOBuffer;"));
                code.visitFieldStmt(IGET_OBJECT,9,14,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_result","Ljavax/net/ssl/SSLEngineResult;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9},new Method("Ljavax/net/ssl/SSLEngineResult;","bytesProduced",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,9);
                code.visitStmt2R(ADD_INT_2ADDR,9,4);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 8,9},new Method("Lorg/mortbay/io/nio/NIOBuffer;","setPutIndex",new String[]{ "I"},"V"));
                code.visitLabel(L30);
                code.visitFieldStmt(IGET_OBJECT,8,14,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_outBuffer","Ljava/nio/ByteBuffer;"));
                code.visitConstStmt(CONST_4,9, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,9},new Method("Ljava/nio/ByteBuffer;","position",new String[]{ "I"},"Ljava/nio/Buffer;"));
                code.visitLabel(L96);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 14},new Method("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","flush",new String[]{ },"V"));
                code.visitJumpStmt(GOTO_16,-1,-1,L103);
                code.visitLabel(L31);
                code.visitStmt1R(MOVE_EXCEPTION,8);
                code.visitFieldStmt(IGET_OBJECT,9,14,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_outBuffer","Ljava/nio/ByteBuffer;"));
                code.visitConstStmt(CONST_4,10, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9,10},new Method("Ljava/nio/ByteBuffer;","position",new String[]{ "I"},"Ljava/nio/Buffer;"));
                code.visitStmt1R(THROW,8);
                code.visitLabel(L97);
                code.visitFieldStmt(IGET_OBJECT,8,14,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_buffers","Lorg/mortbay/io/Buffers;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 8,2},new Method("Lorg/mortbay/io/Buffers;","returnBuffer",new String[]{ "Lorg/mortbay/io/Buffer;"},"V"));
                code.visitLabel(L32);
                code.visitJumpStmt(GOTO_16,-1,-1,L103);
                code.visitLabel(L3);
                code.visitStmt1R(MOVE_EXCEPTION,8);
                code.visitStmt2R(MOVE_OBJECT,3,8);
                code.visitStmt2R(MOVE,6,7);
                code.visitLabel(L98);
                code.visitJumpStmt(GOTO_16,-1,-1,L15);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,8);
                code.visitStmt2R(MOVE_OBJECT,3,8);
                code.visitStmt2R(MOVE,6,7);
                code.visitLabel(L99);
                code.visitJumpStmt(GOTO_16,-1,-1,L8);
                code.visitLabel(L100);
                code.visitStmt2R(MOVE,6,7);
                code.visitLabel(L101);
                code.visitJumpStmt(GOTO_16,-1,-1,L24);
                code.visitLabel(L102);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m008_doIdleExpired(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","doIdleExpired",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(122,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(123,L1);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 0},new Method("Lorg/mortbay/jetty/nio/SelectChannelConnector$ConnectorEndPoint;","idleExpired",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m009_dump(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","dump",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(91,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(94,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Ljava/lang/System;","err","Ljava/io/PrintStream;"));
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_result","Ljavax/net/ssl/SSLEngineResult;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/io/PrintStream;","println",new String[]{ "Ljava/lang/Object;"},"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m010_fill(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","fill",new String[]{ "Lorg/mortbay/io/Buffer;"},"I"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(16);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L1,L2},new String[]{ "Ljavax/net/ssl/SSLException;",null});
                DexLabel L3=new DexLabel();
                code.visitTryCatch(L3,L2,new DexLabel[]{L2},new String[]{ null});
                DexLabel L4=new DexLabel();
                DexLabel L5=new DexLabel();
                DexLabel L6=new DexLabel();
                code.visitTryCatch(L4,L5,new DexLabel[]{L6},new String[]{ null});
                DexLabel L7=new DexLabel();
                DexLabel L8=new DexLabel();
                code.visitTryCatch(L7,L8,new DexLabel[]{L1,L2},new String[]{ "Ljavax/net/ssl/SSLException;",null});
                DexLabel L9=new DexLabel();
                DexLabel L10=new DexLabel();
                code.visitTryCatch(L9,L10,new DexLabel[]{L6},new String[]{ null});
                DexLabel L11=new DexLabel();
                DexLabel L12=new DexLabel();
                code.visitTryCatch(L11,L12,new DexLabel[]{L1,L2},new String[]{ "Ljavax/net/ssl/SSLException;",null});
                DexLabel L13=new DexLabel();
                DexLabel L14=new DexLabel();
                code.visitTryCatch(L13,L14,new DexLabel[]{L6},new String[]{ null});
                DexLabel L15=new DexLabel();
                DexLabel L16=new DexLabel();
                code.visitTryCatch(L15,L16,new DexLabel[]{L1,L2},new String[]{ "Ljavax/net/ssl/SSLException;",null});
                DexLabel L17=new DexLabel();
                DexLabel L18=new DexLabel();
                code.visitTryCatch(L17,L18,new DexLabel[]{L6},new String[]{ null});
                DexLabel L19=new DexLabel();
                DexLabel L20=new DexLabel();
                code.visitTryCatch(L19,L20,new DexLabel[]{L1,L2},new String[]{ "Ljavax/net/ssl/SSLException;",null});
                DexLabel L21=new DexLabel();
                DexLabel L22=new DexLabel();
                code.visitTryCatch(L20,L21,new DexLabel[]{L22},new String[]{ null});
                DexLabel L23=new DexLabel();
                DexLabel L24=new DexLabel();
                code.visitTryCatch(L21,L23,new DexLabel[]{L24},new String[]{ null});
                DexLabel L25=new DexLabel();
                code.visitTryCatch(L23,L25,new DexLabel[]{L1,L2},new String[]{ "Ljavax/net/ssl/SSLException;",null});
                DexLabel L26=new DexLabel();
                DexLabel L27=new DexLabel();
                code.visitTryCatch(L26,L27,new DexLabel[]{L22},new String[]{ null});
                DexLabel L28=new DexLabel();
                DexLabel L29=new DexLabel();
                code.visitTryCatch(L28,L29,new DexLabel[]{L24},new String[]{ null});
                DexLabel L30=new DexLabel();
                code.visitTryCatch(L29,L30,new DexLabel[]{L1,L2},new String[]{ "Ljavax/net/ssl/SSLException;",null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"buffer");
                DexLabel L31=new DexLabel();
                ddv.visitPrologue(L31);
                DexLabel L32=new DexLabel();
                ddv.visitLineNumber(251,L32);
                DexLabel L33=new DexLabel();
                ddv.visitLineNumber(252,L33);
                ddv.visitStartLocal(0,L33,"bbuf","Ljava/nio/ByteBuffer;",null);
                DexLabel L34=new DexLabel();
                ddv.visitLineNumber(253,L34);
                ddv.visitStartLocal(4,L34,"size","I",null);
                DexLabel L35=new DexLabel();
                ddv.visitLineNumber(254,L35);
                ddv.visitStartLocal(2,L35,"initialStatus","Ljavax/net/ssl/SSLEngineResult$HandshakeStatus;",null);
                ddv.visitLineNumber(258,L0);
                DexLabel L36=new DexLabel();
                ddv.visitLineNumber(260,L36);
                DexLabel L37=new DexLabel();
                ddv.visitStartLocal(6,L37,"tries","I",null);
                DexLabel L38=new DexLabel();
                ddv.visitStartLocal(8,L38,"wraps","I",null);
                DexLabel L39=new DexLabel();
                ddv.visitLineNumber(264,L39);
                ddv.visitEndLocal(6,L39);
                ddv.visitStartLocal(7,L39,"tries","I",null);
                DexLabel L40=new DexLabel();
                ddv.visitRestartLocal(6,L40);
                DexLabel L41=new DexLabel();
                ddv.visitLineNumber(265,L41);
                ddv.visitEndLocal(7,L41);
                ddv.visitLineNumber(347,L1);
                ddv.visitEndLocal(8,L1);
                ddv.visitEndLocal(6,L1);
                ddv.visitLineNumber(349,L3);
                ddv.visitStartLocal(1,L3,"e","Ljavax/net/ssl/SSLException;",null);
                DexLabel L42=new DexLabel();
                ddv.visitLineNumber(350,L42);
                DexLabel L43=new DexLabel();
                ddv.visitLineNumber(351,L43);
                ddv.visitLineNumber(355,L2);
                ddv.visitEndLocal(1,L2);
                DexLabel L44=new DexLabel();
                ddv.visitLineNumber(356,L44);
                DexLabel L45=new DexLabel();
                ddv.visitLineNumber(355,L45);
                ddv.visitLineNumber(358,L6);
                ddv.visitLineNumber(269,L7);
                ddv.visitRestartLocal(6,L7);
                ddv.visitRestartLocal(8,L7);
                DexLabel L46=new DexLabel();
                ddv.visitLineNumber(270,L46);
                DexLabel L47=new DexLabel();
                ddv.visitLineNumber(273,L47);
                DexLabel L48=new DexLabel();
                ddv.visitLineNumber(342,L48);
                ddv.visitRestartLocal(7,L48);
                DexLabel L49=new DexLabel();
                ddv.visitLineNumber(277,L49);
                ddv.visitEndLocal(7,L49);
                ddv.visitLineNumber(355,L9);
                DexLabel L50=new DexLabel();
                ddv.visitLineNumber(356,L50);
                DexLabel L51=new DexLabel();
                ddv.visitLineNumber(278,L51);
                DexLabel L52=new DexLabel();
                ddv.visitLineNumber(359,L52);
                ddv.visitLineNumber(282,L11);
                ddv.visitLineNumber(355,L13);
                DexLabel L53=new DexLabel();
                ddv.visitLineNumber(356,L53);
                DexLabel L54=new DexLabel();
                ddv.visitLineNumber(358,L54);
                ddv.visitLineNumber(359,L14);
                ddv.visitLineNumber(292,L15);
                DexLabel L55=new DexLabel();
                ddv.visitStartLocal(5,L55,"task","Ljava/lang/Runnable;",null);
                DexLabel L56=new DexLabel();
                ddv.visitLineNumber(295,L56);
                DexLabel L57=new DexLabel();
                ddv.visitLineNumber(297,L57);
                ddv.visitLineNumber(355,L17);
                DexLabel L58=new DexLabel();
                ddv.visitLineNumber(356,L58);
                DexLabel L59=new DexLabel();
                ddv.visitLineNumber(304,L59);
                DexLabel L60=new DexLabel();
                ddv.visitLineNumber(311,L60);
                ddv.visitEndLocal(5,L60);
                ddv.visitLineNumber(312,L19);
                ddv.visitLineNumber(316,L20);
                DexLabel L61=new DexLabel();
                ddv.visitLineNumber(317,L61);
                DexLabel L62=new DexLabel();
                ddv.visitLineNumber(318,L62);
                ddv.visitStartLocal(3,L62,"put","I",null);
                DexLabel L63=new DexLabel();
                ddv.visitLineNumber(319,L63);
                DexLabel L64=new DexLabel();
                ddv.visitLineNumber(320,L64);
                DexLabel L65=new DexLabel();
                ddv.visitLineNumber(321,L65);
                DexLabel L66=new DexLabel();
                ddv.visitLineNumber(322,L66);
                DexLabel L67=new DexLabel();
                ddv.visitLineNumber(332,L67);
                ddv.visitLineNumber(336,L21);
                DexLabel L68=new DexLabel();
                ddv.visitLineNumber(338,L68);
                ddv.visitLineNumber(340,L23);
                ddv.visitLineNumber(326,L26);
                DexLabel L69=new DexLabel();
                ddv.visitLineNumber(328,L69);
                ddv.visitLineNumber(336,L22);
                ddv.visitEndLocal(3,L22);
                ddv.visitLineNumber(338,L24);
                ddv.visitLineNumber(273,L30);
                DexLabel L70=new DexLabel();
                ddv.visitLineNumber(322,L70);
                code.visitLabel(L31);
                code.visitConstStmt(CONST_4,13, Integer.valueOf(-1)); // int: 0xffffffff  float:NaN
                code.visitLabel(L32);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 14,15},new Method("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","extractInputBuffer",new String[]{ "Lorg/mortbay/io/Buffer;"},"Ljava/nio/ByteBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L33);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 15},new Method("Lorg/mortbay/io/Buffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitLabel(L34);
                code.visitFieldStmt(IGET_OBJECT,9,14,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_engine","Ljavax/net/ssl/SSLEngine;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9},new Method("Ljavax/net/ssl/SSLEngine;","getHandshakeStatus",new String[]{ },"Ljavax/net/ssl/SSLEngineResult$HandshakeStatus;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L35);
                code.visitStmt1R(MONITOR_ENTER,0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 14,0},new Method("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","unwrap",new String[]{ "Ljava/nio/ByteBuffer;"},"Z"));
                code.visitLabel(L36);
                code.visitConstStmt(CONST_4,6, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L37);
                code.visitConstStmt(CONST_4,8, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L38);
                code.visitStmt2R(MOVE,7,6);
                code.visitLabel(L39);
                code.visitStmt2R1N(ADD_INT_LIT8,6,7,1);
                code.visitLabel(L40);
                code.visitConstStmt(CONST_16,9, Integer.valueOf(100)); // int: 0x00000064  float:0.000000
                code.visitJumpStmt(IF_LE,7,9,L7);
                code.visitLabel(L41);
                code.visitTypeStmt(NEW_INSTANCE,9,-1,"Ljava/lang/IllegalStateException;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 9},new Method("Ljava/lang/IllegalStateException;","<init>",new String[]{ },"V"));
                code.visitStmt1R(THROW,9);
                code.visitLabel(L1);
                code.visitStmt1R(MOVE_EXCEPTION,9);
                code.visitStmt2R(MOVE_OBJECT,1,9);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljavax/net/ssl/SSLException;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 9},new Method("Lorg/mortbay/log/Log;","warn",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L42);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitLabel(L43);
                code.visitStmt1R(THROW,1);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,9);
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/nio/ByteBuffer;","position",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,10);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 15,10},new Method("Lorg/mortbay/io/Buffer;","setPutIndex",new String[]{ "I"},"V"));
                code.visitLabel(L44);
                code.visitConstStmt(CONST_4,10, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,10},new Method("Ljava/nio/ByteBuffer;","position",new String[]{ "I"},"Ljava/nio/Buffer;"));
                code.visitLabel(L45);
                code.visitStmt1R(THROW,9);
                code.visitLabel(L6);
                code.visitStmt1R(MOVE_EXCEPTION,9);
                code.visitStmt1R(MONITOR_EXIT,0);
                code.visitLabel(L5);
                code.visitStmt1R(THROW,9);
                code.visitLabel(L7);
                code.visitFieldStmt(IGET_OBJECT,9,14,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_outNIOBuffer","Lorg/mortbay/io/nio/NIOBuffer;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 9},new Method("Lorg/mortbay/io/nio/NIOBuffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,9);
                code.visitJumpStmt(IF_LEZ,9,-1,L47);
                code.visitLabel(L46);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 14},new Method("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","flush",new String[]{ },"V"));
                code.visitLabel(L47);
                code.visitFieldStmt(SGET_OBJECT,9,-1,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint$2;","$SwitchMap$javax$net$ssl$SSLEngineResult$HandshakeStatus","[I"));
                code.visitFieldStmt(IGET_OBJECT,10,14,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_engine","Ljavax/net/ssl/SSLEngine;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Ljavax/net/ssl/SSLEngine;","getHandshakeStatus",new String[]{ },"Ljavax/net/ssl/SSLEngineResult$HandshakeStatus;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Ljavax/net/ssl/SSLEngineResult$HandshakeStatus;","ordinal",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,10);
                code.visitStmt3R(AGET,9,9,10);
                code.visitSparseSwitchStmt(PACKED_SWITCH,9,1,new DexLabel[]{L49,L49,L11,L15,L60});
                DexLabel L71=new DexLabel();
                code.visitLabel(L71);
                code.visitStmt2R(MOVE,7,6);
                code.visitLabel(L48);
                code.visitJumpStmt(GOTO,-1,-1,L39);
                code.visitLabel(L49);
                code.visitFieldStmt(IGET_BOOLEAN,9,14,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_closing","Z"));
                code.visitLabel(L8);
                code.visitJumpStmt(IF_EQZ,9,-1,L13);
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/nio/ByteBuffer;","position",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,9);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 15,9},new Method("Lorg/mortbay/io/Buffer;","setPutIndex",new String[]{ "I"},"V"));
                code.visitLabel(L50);
                code.visitConstStmt(CONST_4,9, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,9},new Method("Ljava/nio/ByteBuffer;","position",new String[]{ "I"},"Ljava/nio/Buffer;"));
                code.visitLabel(L51);
                code.visitStmt1R(MONITOR_EXIT,0);
                code.visitLabel(L10);
                code.visitStmt2R(MOVE,9,13);
                code.visitLabel(L52);
                code.visitStmt1R(RETURN,9);
                code.visitLabel(L11);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 14,0},new Method("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","unwrap",new String[]{ "Ljava/nio/ByteBuffer;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,9);
                code.visitJumpStmt(IF_NEZ,9,-1,L71);
                code.visitFieldStmt(IGET_OBJECT,9,14,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_engine","Ljavax/net/ssl/SSLEngine;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9},new Method("Ljavax/net/ssl/SSLEngine;","getHandshakeStatus",new String[]{ },"Ljavax/net/ssl/SSLEngineResult$HandshakeStatus;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitFieldStmt(SGET_OBJECT,10,-1,new Field("Ljavax/net/ssl/SSLEngineResult$HandshakeStatus;","NEED_UNWRAP","Ljavax/net/ssl/SSLEngineResult$HandshakeStatus;"));
                code.visitLabel(L12);
                code.visitJumpStmt(IF_NE,9,10,L71);
                code.visitLabel(L13);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/nio/ByteBuffer;","position",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,9);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 15,9},new Method("Lorg/mortbay/io/Buffer;","setPutIndex",new String[]{ "I"},"V"));
                code.visitLabel(L53);
                code.visitConstStmt(CONST_4,9, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,9},new Method("Ljava/nio/ByteBuffer;","position",new String[]{ "I"},"Ljava/nio/Buffer;"));
                code.visitLabel(L54);
                code.visitStmt1R(MONITOR_EXIT,0);
                code.visitLabel(L14);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 15},new Method("Lorg/mortbay/io/Buffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,9);
                code.visitStmt2R(SUB_INT_2ADDR,9,4);
                code.visitJumpStmt(GOTO,-1,-1,L52);
                code.visitLabel(L15);
                code.visitFieldStmt(IGET_OBJECT,9,14,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_engine","Ljavax/net/ssl/SSLEngine;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9},new Method("Ljavax/net/ssl/SSLEngine;","getDelegatedTask",new String[]{ },"Ljava/lang/Runnable;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitLabel(L55);
                code.visitJumpStmt(IF_EQZ,5,-1,L57);
                code.visitLabel(L56);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 5},new Method("Ljava/lang/Runnable;","run",new String[]{ },"V"));
                code.visitJumpStmt(GOTO,-1,-1,L15);
                code.visitLabel(L57);
                code.visitFieldStmt(SGET_OBJECT,9,-1,new Field("Ljavax/net/ssl/SSLEngineResult$HandshakeStatus;","NOT_HANDSHAKING","Ljavax/net/ssl/SSLEngineResult$HandshakeStatus;"));
                code.visitJumpStmt(IF_NE,2,9,L71);
                code.visitFieldStmt(SGET_OBJECT,9,-1,new Field("Ljavax/net/ssl/SSLEngineResult$HandshakeStatus;","NEED_UNWRAP","Ljavax/net/ssl/SSLEngineResult$HandshakeStatus;"));
                code.visitFieldStmt(IGET_OBJECT,10,14,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_engine","Ljavax/net/ssl/SSLEngine;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Ljavax/net/ssl/SSLEngine;","getHandshakeStatus",new String[]{ },"Ljavax/net/ssl/SSLEngineResult$HandshakeStatus;"));
                code.visitLabel(L16);
                code.visitStmt1R(MOVE_RESULT_OBJECT,10);
                code.visitJumpStmt(IF_NE,9,10,L71);
                code.visitJumpStmt(IF_NEZ,8,-1,L71);
                code.visitLabel(L17);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/nio/ByteBuffer;","position",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,9);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 15,9},new Method("Lorg/mortbay/io/Buffer;","setPutIndex",new String[]{ "I"},"V"));
                code.visitLabel(L58);
                code.visitConstStmt(CONST_4,9, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,9},new Method("Ljava/nio/ByteBuffer;","position",new String[]{ "I"},"Ljava/nio/Buffer;"));
                code.visitLabel(L59);
                code.visitStmt1R(MONITOR_EXIT,0);
                code.visitLabel(L18);
                code.visitStmt2R(MOVE,9,13);
                code.visitJumpStmt(GOTO,-1,-1,L52);
                code.visitLabel(L60);
                code.visitStmt2R1N(ADD_INT_LIT8,8,8,1);
                code.visitLabel(L19);
                code.visitFieldStmt(IGET_OBJECT,9,14,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_outBuffer","Ljava/nio/ByteBuffer;"));
                code.visitStmt1R(MONITOR_ENTER,9);
                code.visitLabel(L20);
                code.visitFieldStmt(IGET_OBJECT,10,14,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_outNIOBuffer","Lorg/mortbay/io/nio/NIOBuffer;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 10},new Method("Lorg/mortbay/io/nio/NIOBuffer;","compact",new String[]{ },"V"));
                code.visitLabel(L61);
                code.visitFieldStmt(IGET_OBJECT,10,14,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_outNIOBuffer","Lorg/mortbay/io/nio/NIOBuffer;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 10},new Method("Lorg/mortbay/io/nio/NIOBuffer;","putIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitLabel(L62);
                code.visitFieldStmt(IGET_OBJECT,10,14,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_outBuffer","Ljava/nio/ByteBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Ljava/nio/ByteBuffer;","position",new String[]{ },"I"));
                code.visitLabel(L63);
                code.visitConstStmt(CONST_4,10, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_OBJECT,10,14,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_result","Ljavax/net/ssl/SSLEngineResult;"));
                code.visitLabel(L64);
                code.visitConstStmt(CONST_STRING,10,"fill wrap");
                code.visitFieldStmt(IPUT_OBJECT,10,14,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_last","Ljava/lang/String;"));
                code.visitLabel(L65);
                code.visitFieldStmt(IGET_OBJECT,10,14,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_engine","Ljavax/net/ssl/SSLEngine;"));
                code.visitFieldStmt(SGET_OBJECT,11,-1,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","__NO_BUFFERS","[Ljava/nio/ByteBuffer;"));
                code.visitFieldStmt(IGET_OBJECT,12,14,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_outBuffer","Ljava/nio/ByteBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10,11,12},new Method("Ljavax/net/ssl/SSLEngine;","wrap",new String[]{ "[Ljava/nio/ByteBuffer;","Ljava/nio/ByteBuffer;"},"Ljavax/net/ssl/SSLEngineResult;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,10);
                code.visitFieldStmt(IPUT_OBJECT,10,14,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_result","Ljavax/net/ssl/SSLEngineResult;"));
                code.visitLabel(L66);
                code.visitFieldStmt(SGET_OBJECT,10,-1,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint$2;","$SwitchMap$javax$net$ssl$SSLEngineResult$Status","[I"));
                code.visitFieldStmt(IGET_OBJECT,11,14,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_result","Ljavax/net/ssl/SSLEngineResult;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11},new Method("Ljavax/net/ssl/SSLEngineResult;","getStatus",new String[]{ },"Ljavax/net/ssl/SSLEngineResult$Status;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,11);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11},new Method("Ljavax/net/ssl/SSLEngineResult$Status;","ordinal",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,11);
                code.visitStmt3R(AGET,10,10,11);
                code.visitSparseSwitchStmt(PACKED_SWITCH,10,1,new DexLabel[]{L26,L26,L69});
                code.visitLabel(L67);
                code.visitFieldStmt(IGET_OBJECT,10,14,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_outNIOBuffer","Lorg/mortbay/io/nio/NIOBuffer;"));
                code.visitFieldStmt(IGET_OBJECT,11,14,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_result","Ljavax/net/ssl/SSLEngineResult;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11},new Method("Ljavax/net/ssl/SSLEngineResult;","bytesProduced",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,11);
                code.visitStmt2R(ADD_INT_2ADDR,11,3);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 10,11},new Method("Lorg/mortbay/io/nio/NIOBuffer;","setPutIndex",new String[]{ "I"},"V"));
                code.visitLabel(L21);
                code.visitFieldStmt(IGET_OBJECT,10,14,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_outBuffer","Ljava/nio/ByteBuffer;"));
                code.visitConstStmt(CONST_4,11, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10,11},new Method("Ljava/nio/ByteBuffer;","position",new String[]{ "I"},"Ljava/nio/Buffer;"));
                code.visitLabel(L68);
                code.visitStmt1R(MONITOR_EXIT,9);
                code.visitLabel(L23);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 14},new Method("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","flush",new String[]{ },"V"));
                code.visitLabel(L25);
                code.visitJumpStmt(GOTO_16,-1,-1,L71);
                code.visitLabel(L26);
                code.visitConstStmt(CONST_STRING,10,"wrap {}");
                code.visitFieldStmt(IGET_OBJECT,11,14,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_result","Ljavax/net/ssl/SSLEngineResult;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 10,11},new Method("Lorg/mortbay/log/Log;","warn",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L69);
                code.visitConstStmt(CONST_4,10, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitFieldStmt(IPUT_BOOLEAN,10,14,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_closing","Z"));
                code.visitLabel(L27);
                code.visitJumpStmt(GOTO,-1,-1,L67);
                code.visitLabel(L22);
                code.visitStmt1R(MOVE_EXCEPTION,10);
                code.visitLabel(L28);
                code.visitFieldStmt(IGET_OBJECT,11,14,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_outBuffer","Ljava/nio/ByteBuffer;"));
                code.visitConstStmt(CONST_4,12, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11,12},new Method("Ljava/nio/ByteBuffer;","position",new String[]{ "I"},"Ljava/nio/Buffer;"));
                code.visitStmt1R(THROW,10);
                code.visitLabel(L24);
                code.visitStmt1R(MOVE_EXCEPTION,10);
                code.visitStmt1R(MONITOR_EXIT,9);
                code.visitLabel(L29);
                code.visitStmt1R(THROW,10);
                code.visitLabel(L30);
                code.visitLabel(L70);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m011_flush(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","flush",new String[]{ "Lorg/mortbay/io/Buffer;"},"I"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"buffer");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(366,L1);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2,0,0},new Method("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","flush",new String[]{ "Lorg/mortbay/io/Buffer;","Lorg/mortbay/io/Buffer;","Lorg/mortbay/io/Buffer;"},"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m012_flush(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","flush",new String[]{ "Lorg/mortbay/io/Buffer;","Lorg/mortbay/io/Buffer;","Lorg/mortbay/io/Buffer;"},"I"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(18);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                DexLabel L5=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L5},new String[]{ null});
                DexLabel L6=new DexLabel();
                DexLabel L7=new DexLabel();
                code.visitTryCatch(L4,L6,new DexLabel[]{L7},new String[]{ null});
                DexLabel L8=new DexLabel();
                DexLabel L9=new DexLabel();
                code.visitTryCatch(L8,L9,new DexLabel[]{L5},new String[]{ null});
                DexLabel L10=new DexLabel();
                DexLabel L11=new DexLabel();
                code.visitTryCatch(L10,L11,new DexLabel[]{L7},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"header");
                ddv.visitParameterName(1,"buffer");
                ddv.visitParameterName(2,"trailer");
                DexLabel L12=new DexLabel();
                ddv.visitPrologue(L12);
                ddv.visitLineNumber(375,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(376,L13);
                ddv.visitStartLocal(5,L13,"consumed","I",null);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(377,L14);
                ddv.visitStartLocal(1,L14,"available","I",null);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(378,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(380,L16);
                DexLabel L17=new DexLabel();
                ddv.visitStartLocal(8,L17,"tries","I",null);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(384,L18);
                ddv.visitEndLocal(8,L18);
                ddv.visitStartLocal(9,L18,"tries","I",null);
                DexLabel L19=new DexLabel();
                ddv.visitRestartLocal(8,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(385,L20);
                ddv.visitEndLocal(9,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(389,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(390,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(394,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(481,L24);
                ddv.visitRestartLocal(9,L24);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(399,L25);
                ddv.visitEndLocal(9,L25);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(401,L26);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(402,L27);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(486,L28);
                DexLabel L29=new DexLabel();
                ddv.visitLineNumber(406,L29);
                DexLabel L30=new DexLabel();
                ddv.visitLineNumber(407,L30);
                ddv.visitStartLocal(4,L30,"c","I",null);
                DexLabel L31=new DexLabel();
                ddv.visitLineNumber(409,L31);
                DexLabel L32=new DexLabel();
                ddv.visitLineNumber(410,L32);
                DexLabel L33=new DexLabel();
                ddv.visitLineNumber(406,L33);
                ddv.visitEndLocal(4,L33);
                DexLabel L34=new DexLabel();
                ddv.visitLineNumber(412,L34);
                ddv.visitRestartLocal(4,L34);
                DexLabel L35=new DexLabel();
                ddv.visitLineNumber(414,L35);
                DexLabel L36=new DexLabel();
                ddv.visitLineNumber(415,L36);
                DexLabel L37=new DexLabel();
                ddv.visitLineNumber(422,L37);
                ddv.visitEndLocal(4,L37);
                ddv.visitLineNumber(425,L0);
                ddv.visitStartLocal(3,L0,"buf","Lorg/mortbay/io/Buffer;",null);
                DexLabel L38=new DexLabel();
                ddv.visitLineNumber(426,L38);
                ddv.visitStartLocal(2,L38,"bbuf","Ljava/nio/ByteBuffer;",null);
                DexLabel L39=new DexLabel();
                ddv.visitLineNumber(434,L39);
                ddv.visitEndLocal(2,L2);
                DexLabel L40=new DexLabel();
                ddv.visitLineNumber(442,L40);
                ddv.visitEndLocal(3,L40);
                DexLabel L41=new DexLabel();
                ddv.visitStartLocal(7,L41,"task","Ljava/lang/Runnable;",null);
                DexLabel L42=new DexLabel();
                ddv.visitLineNumber(445,L42);
                DexLabel L43=new DexLabel();
                ddv.visitLineNumber(452,L43);
                ddv.visitEndLocal(7,L43);
                ddv.visitLineNumber(456,L3);
                DexLabel L44=new DexLabel();
                ddv.visitLineNumber(457,L44);
                DexLabel L45=new DexLabel();
                ddv.visitLineNumber(458,L45);
                ddv.visitStartLocal(6,L45,"put","I",null);
                DexLabel L46=new DexLabel();
                ddv.visitLineNumber(459,L46);
                DexLabel L47=new DexLabel();
                ddv.visitLineNumber(460,L47);
                DexLabel L48=new DexLabel();
                ddv.visitLineNumber(461,L48);
                DexLabel L49=new DexLabel();
                ddv.visitLineNumber(462,L49);
                DexLabel L50=new DexLabel();
                ddv.visitLineNumber(471,L50);
                ddv.visitLineNumber(475,L4);
                DexLabel L51=new DexLabel();
                ddv.visitLineNumber(477,L51);
                ddv.visitLineNumber(479,L6);
                ddv.visitLineNumber(466,L8);
                DexLabel L52=new DexLabel();
                ddv.visitLineNumber(468,L52);
                ddv.visitLineNumber(475,L5);
                ddv.visitEndLocal(6,L5);
                ddv.visitLineNumber(477,L7);
                DexLabel L53=new DexLabel();
                ddv.visitLineNumber(434,L53);
                ddv.visitRestartLocal(2,L53);
                ddv.visitRestartLocal(3,L53);
                DexLabel L54=new DexLabel();
                ddv.visitLineNumber(394,L54);
                DexLabel L55=new DexLabel();
                ddv.visitLineNumber(462,L55);
                code.visitLabel(L12);
                code.visitConstStmt(CONST_4,5, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L13);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 15},new Method("Lorg/mortbay/io/Buffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitLabel(L14);
                code.visitJumpStmt(IF_EQZ,16,-1,L16);
                code.visitLabel(L15);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 16},new Method("Lorg/mortbay/io/Buffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,10);
                code.visitStmt2R(ADD_INT_2ADDR,1,10);
                code.visitLabel(L16);
                code.visitConstStmt(CONST_4,8, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L17);
                code.visitStmt2R(MOVE,9,8);
                code.visitLabel(L18);
                code.visitStmt2R1N(ADD_INT_LIT8,8,9,1);
                code.visitLabel(L19);
                code.visitConstStmt(CONST_16,10, Integer.valueOf(100)); // int: 0x00000064  float:0.000000
                code.visitJumpStmt(IF_LE,9,10,L21);
                code.visitLabel(L20);
                code.visitTypeStmt(NEW_INSTANCE,10,-1,"Ljava/lang/IllegalStateException;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 10},new Method("Ljava/lang/IllegalStateException;","<init>",new String[]{ },"V"));
                code.visitStmt1R(THROW,10);
                code.visitLabel(L21);
                code.visitFieldStmt(IGET_OBJECT,10,14,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_outNIOBuffer","Lorg/mortbay/io/nio/NIOBuffer;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 10},new Method("Lorg/mortbay/io/nio/NIOBuffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,10);
                code.visitJumpStmt(IF_LEZ,10,-1,L23);
                code.visitLabel(L22);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 14},new Method("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","flush",new String[]{ },"V"));
                code.visitLabel(L23);
                code.visitFieldStmt(SGET_OBJECT,10,-1,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint$2;","$SwitchMap$javax$net$ssl$SSLEngineResult$HandshakeStatus","[I"));
                code.visitFieldStmt(IGET_OBJECT,11,14,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_engine","Ljavax/net/ssl/SSLEngine;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11},new Method("Ljavax/net/ssl/SSLEngine;","getHandshakeStatus",new String[]{ },"Ljavax/net/ssl/SSLEngineResult$HandshakeStatus;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,11);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11},new Method("Ljavax/net/ssl/SSLEngineResult$HandshakeStatus;","ordinal",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,11);
                code.visitStmt3R(AGET,10,10,11);
                code.visitSparseSwitchStmt(PACKED_SWITCH,10,1,new DexLabel[]{L25,L25,L37,L40,L43});
                DexLabel L56=new DexLabel();
                code.visitLabel(L56);
                code.visitStmt2R(MOVE,9,8);
                code.visitLabel(L24);
                code.visitJumpStmt(GOTO,-1,-1,L18);
                code.visitLabel(L25);
                code.visitFieldStmt(IGET_BOOLEAN,10,14,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_closing","Z"));
                code.visitJumpStmt(IF_NEZ,10,-1,L26);
                code.visitJumpStmt(IF_NEZ,1,-1,L29);
                code.visitLabel(L26);
                code.visitJumpStmt(IF_NEZ,5,-1,L28);
                code.visitLabel(L27);
                code.visitConstStmt(CONST_4,5, Integer.valueOf(-1)); // int: 0xffffffff  float:NaN
                code.visitLabel(L28);
                code.visitStmt1R(RETURN,5);
                code.visitLabel(L29);
                code.visitJumpStmt(IF_EQZ,15,-1,L33);
                code.visitJumpStmt(IF_EQZ,16,-1,L33);
                code.visitMethodStmt(INVOKE_DIRECT_RANGE,new int[]{ 14,15,16},new Method("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","wrap",new String[]{ "Lorg/mortbay/io/Buffer;","Lorg/mortbay/io/Buffer;"},"I"));
                code.visitStmt1R(MOVE_RESULT,10);
                code.visitStmt2R(MOVE,4,10);
                code.visitLabel(L30);
                code.visitJumpStmt(IF_LEZ,4,-1,L34);
                code.visitLabel(L31);
                code.visitStmt2R(ADD_INT_2ADDR,5,4);
                code.visitLabel(L32);
                code.visitStmt2R(SUB_INT_2ADDR,1,4);
                code.visitJumpStmt(GOTO,-1,-1,L56);
                code.visitLabel(L33);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 14,15},new Method("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","wrap",new String[]{ "Lorg/mortbay/io/Buffer;"},"I"));
                code.visitStmt1R(MOVE_RESULT,10);
                code.visitStmt2R(MOVE,4,10);
                code.visitJumpStmt(GOTO,-1,-1,L30);
                code.visitLabel(L34);
                code.visitJumpStmt(IF_GEZ,4,-1,L56);
                code.visitLabel(L35);
                code.visitJumpStmt(IF_NEZ,5,-1,L28);
                code.visitLabel(L36);
                code.visitConstStmt(CONST_4,5, Integer.valueOf(-1)); // int: 0xffffffff  float:NaN
                code.visitJumpStmt(GOTO,-1,-1,L28);
                code.visitLabel(L37);
                code.visitFieldStmt(IGET_OBJECT,10,14,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_buffers","Lorg/mortbay/io/Buffers;"));
                code.visitFieldStmt(IGET_OBJECT,11,14,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_engine","Ljavax/net/ssl/SSLEngine;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11},new Method("Ljavax/net/ssl/SSLEngine;","getSession",new String[]{ },"Ljavax/net/ssl/SSLSession;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,11);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 11},new Method("Ljavax/net/ssl/SSLSession;","getApplicationBufferSize",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,11);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 10,11},new Method("Lorg/mortbay/io/Buffers;","getBuffer",new String[]{ "I"},"Lorg/mortbay/io/Buffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitLabel(L0);
                code.visitStmt2R(MOVE_OBJECT,0,3);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Lorg/mortbay/io/nio/NIOBuffer;");
                code.visitStmt2R(MOVE_OBJECT,4,0);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 4},new Method("Lorg/mortbay/io/nio/NIOBuffer;","getByteBuffer",new String[]{ },"Ljava/nio/ByteBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L38);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 14,2},new Method("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","unwrap",new String[]{ "Ljava/nio/ByteBuffer;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,10);
                code.visitJumpStmt(IF_NEZ,10,-1,L53);
                code.visitFieldStmt(IGET_OBJECT,10,14,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_engine","Ljavax/net/ssl/SSLEngine;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Ljavax/net/ssl/SSLEngine;","getHandshakeStatus",new String[]{ },"Ljavax/net/ssl/SSLEngineResult$HandshakeStatus;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,10);
                code.visitFieldStmt(SGET_OBJECT,11,-1,new Field("Ljavax/net/ssl/SSLEngineResult$HandshakeStatus;","NEED_UNWRAP","Ljavax/net/ssl/SSLEngineResult$HandshakeStatus;"));
                code.visitLabel(L1);
                code.visitJumpStmt(IF_NE,10,11,L53);
                code.visitLabel(L39);
                code.visitFieldStmt(IGET_OBJECT,10,14,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_buffers","Lorg/mortbay/io/Buffers;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 10,3},new Method("Lorg/mortbay/io/Buffers;","returnBuffer",new String[]{ "Lorg/mortbay/io/Buffer;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L28);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,10);
                code.visitFieldStmt(IGET_OBJECT,11,14,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_buffers","Lorg/mortbay/io/Buffers;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 11,3},new Method("Lorg/mortbay/io/Buffers;","returnBuffer",new String[]{ "Lorg/mortbay/io/Buffer;"},"V"));
                code.visitStmt1R(THROW,10);
                code.visitLabel(L40);
                code.visitFieldStmt(IGET_OBJECT,10,14,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_engine","Ljavax/net/ssl/SSLEngine;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Ljavax/net/ssl/SSLEngine;","getDelegatedTask",new String[]{ },"Ljava/lang/Runnable;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitLabel(L41);
                code.visitJumpStmt(IF_EQZ,7,-1,L56);
                code.visitLabel(L42);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 7},new Method("Ljava/lang/Runnable;","run",new String[]{ },"V"));
                code.visitJumpStmt(GOTO,-1,-1,L40);
                code.visitLabel(L43);
                code.visitFieldStmt(IGET_OBJECT,10,14,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_outBuffer","Ljava/nio/ByteBuffer;"));
                code.visitStmt1R(MONITOR_ENTER,10);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,11,14,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_outNIOBuffer","Lorg/mortbay/io/nio/NIOBuffer;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 11},new Method("Lorg/mortbay/io/nio/NIOBuffer;","compact",new String[]{ },"V"));
                code.visitLabel(L44);
                code.visitFieldStmt(IGET_OBJECT,11,14,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_outNIOBuffer","Lorg/mortbay/io/nio/NIOBuffer;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 11},new Method("Lorg/mortbay/io/nio/NIOBuffer;","putIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitLabel(L45);
                code.visitFieldStmt(IGET_OBJECT,11,14,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_outBuffer","Ljava/nio/ByteBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11},new Method("Ljava/nio/ByteBuffer;","position",new String[]{ },"I"));
                code.visitLabel(L46);
                code.visitConstStmt(CONST_4,11, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_OBJECT,11,14,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_result","Ljavax/net/ssl/SSLEngineResult;"));
                code.visitLabel(L47);
                code.visitConstStmt(CONST_STRING,11,"flush wrap");
                code.visitFieldStmt(IPUT_OBJECT,11,14,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_last","Ljava/lang/String;"));
                code.visitLabel(L48);
                code.visitFieldStmt(IGET_OBJECT,11,14,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_engine","Ljavax/net/ssl/SSLEngine;"));
                code.visitFieldStmt(SGET_OBJECT,12,-1,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","__NO_BUFFERS","[Ljava/nio/ByteBuffer;"));
                code.visitFieldStmt(IGET_OBJECT,13,14,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_outBuffer","Ljava/nio/ByteBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11,12,13},new Method("Ljavax/net/ssl/SSLEngine;","wrap",new String[]{ "[Ljava/nio/ByteBuffer;","Ljava/nio/ByteBuffer;"},"Ljavax/net/ssl/SSLEngineResult;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,11);
                code.visitFieldStmt(IPUT_OBJECT,11,14,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_result","Ljavax/net/ssl/SSLEngineResult;"));
                code.visitLabel(L49);
                code.visitFieldStmt(SGET_OBJECT,11,-1,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint$2;","$SwitchMap$javax$net$ssl$SSLEngineResult$Status","[I"));
                code.visitFieldStmt(IGET_OBJECT,12,14,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_result","Ljavax/net/ssl/SSLEngineResult;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12},new Method("Ljavax/net/ssl/SSLEngineResult;","getStatus",new String[]{ },"Ljavax/net/ssl/SSLEngineResult$Status;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,12);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12},new Method("Ljavax/net/ssl/SSLEngineResult$Status;","ordinal",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,12);
                code.visitStmt3R(AGET,11,11,12);
                code.visitSparseSwitchStmt(PACKED_SWITCH,11,1,new DexLabel[]{L8,L8,L52});
                code.visitLabel(L50);
                code.visitFieldStmt(IGET_OBJECT,11,14,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_outNIOBuffer","Lorg/mortbay/io/nio/NIOBuffer;"));
                code.visitFieldStmt(IGET_OBJECT,12,14,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_result","Ljavax/net/ssl/SSLEngineResult;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12},new Method("Ljavax/net/ssl/SSLEngineResult;","bytesProduced",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,12);
                code.visitStmt2R(ADD_INT_2ADDR,12,6);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 11,12},new Method("Lorg/mortbay/io/nio/NIOBuffer;","setPutIndex",new String[]{ "I"},"V"));
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,11,14,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_outBuffer","Ljava/nio/ByteBuffer;"));
                code.visitConstStmt(CONST_4,12, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11,12},new Method("Ljava/nio/ByteBuffer;","position",new String[]{ "I"},"Ljava/nio/Buffer;"));
                code.visitLabel(L51);
                code.visitStmt1R(MONITOR_EXIT,10);
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 14},new Method("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","flush",new String[]{ },"V"));
                code.visitJumpStmt(GOTO_16,-1,-1,L56);
                code.visitLabel(L8);
                code.visitConstStmt(CONST_STRING,11,"wrap {}");
                code.visitFieldStmt(IGET_OBJECT,12,14,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_result","Ljavax/net/ssl/SSLEngineResult;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 11,12},new Method("Lorg/mortbay/log/Log;","warn",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L52);
                code.visitConstStmt(CONST_4,11, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitFieldStmt(IPUT_BOOLEAN,11,14,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_closing","Z"));
                code.visitLabel(L9);
                code.visitJumpStmt(GOTO,-1,-1,L50);
                code.visitLabel(L5);
                code.visitStmt1R(MOVE_EXCEPTION,11);
                code.visitLabel(L10);
                code.visitFieldStmt(IGET_OBJECT,12,14,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_outBuffer","Ljava/nio/ByteBuffer;"));
                code.visitConstStmt(CONST_4,13, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12,13},new Method("Ljava/nio/ByteBuffer;","position",new String[]{ "I"},"Ljava/nio/Buffer;"));
                code.visitStmt1R(THROW,11);
                code.visitLabel(L7);
                code.visitStmt1R(MOVE_EXCEPTION,11);
                code.visitStmt1R(MONITOR_EXIT,10);
                code.visitLabel(L11);
                code.visitStmt1R(THROW,11);
                code.visitLabel(L53);
                code.visitFieldStmt(IGET_OBJECT,10,14,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_buffers","Lorg/mortbay/io/Buffers;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 10,3},new Method("Lorg/mortbay/io/Buffers;","returnBuffer",new String[]{ "Lorg/mortbay/io/Buffer;"},"V"));
                code.visitJumpStmt(GOTO_16,-1,-1,L56);
                code.visitLabel(L54);
                code.visitLabel(L55);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m013_flush(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","flush",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(493,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(495,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(498,L2);
                ddv.visitStartLocal(0,L2,"flushed","I",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(500,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(501,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(505,L5);
                ddv.visitEndLocal(0,L5);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_outNIOBuffer","Lorg/mortbay/io/nio/NIOBuffer;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Lorg/mortbay/io/nio/NIOBuffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_LEZ,1,-1,L5);
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_outNIOBuffer","Lorg/mortbay/io/nio/NIOBuffer;"));
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 2,1},new Method("Lorg/mortbay/jetty/nio/SelectChannelConnector$ConnectorEndPoint;","flush",new String[]{ "Lorg/mortbay/io/Buffer;"},"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitLabel(L2);
                code.visitJumpStmt(IF_NEZ,0,-1,L0);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Ljava/lang/Thread;","yield",new String[]{ },"V"));
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_outNIOBuffer","Lorg/mortbay/io/nio/NIOBuffer;"));
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 2,1},new Method("Lorg/mortbay/jetty/nio/SelectChannelConnector$ConnectorEndPoint;","flush",new String[]{ "Lorg/mortbay/io/Buffer;"},"I"));
                code.visitJumpStmt(GOTO,-1,-1,L0);
                code.visitLabel(L5);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m014_getSSLEngine(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","getSSLEngine",new String[]{ },"Ljavax/net/ssl/SSLEngine;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(772,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_engine","Ljavax/net/ssl/SSLEngine;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m015_idleExpired(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","idleExpired",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/lang/Exception;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(104,L0);
                ddv.visitLineNumber(116,L1);
                ddv.visitLineNumber(112,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(114,L3);
                ddv.visitStartLocal(0,L3,"e","Ljava/lang/Exception;",null);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_selectSet","Lorg/mortbay/io/nio/SelectorManager$SelectSet;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/io/nio/SelectorManager$SelectSet;","getManager",new String[]{ },"Lorg/mortbay/io/nio/SelectorManager;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Lorg/mortbay/jetty/security/SslHttpChannelEndPoint$1;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2,3},new Method("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint$1;","<init>",new String[]{ "Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;"},"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Lorg/mortbay/io/nio/SelectorManager;","dispatch",new String[]{ "Ljava/lang/Runnable;"},"Z"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitStmt2R(MOVE_OBJECT,0,1);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/log/Log;","ignore",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m016_isBufferingInput(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","isBufferingInput",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(754,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_inNIOBuffer","Lorg/mortbay/io/nio/NIOBuffer;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Lorg/mortbay/io/nio/NIOBuffer;","hasContent",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m017_isBufferingOutput(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","isBufferingOutput",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(760,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_outNIOBuffer","Lorg/mortbay/io/nio/NIOBuffer;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Lorg/mortbay/io/nio/NIOBuffer;","hasContent",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m018_isBufferred(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","isBufferred",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(766,L0);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m019_toString(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","toString",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(778,L0);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 2},new Method("Lorg/mortbay/jetty/nio/SelectChannelConnector$ConnectorEndPoint;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitConstStmt(CONST_STRING,1,",");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_engine","Ljavax/net/ssl/SSLEngine;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljavax/net/ssl/SSLEngine;","getHandshakeStatus",new String[]{ },"Ljavax/net/ssl/SSLEngineResult$HandshakeStatus;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitConstStmt(CONST_STRING,1,", in/out=");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_inNIOBuffer","Lorg/mortbay/io/nio/NIOBuffer;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Lorg/mortbay/io/nio/NIOBuffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "I"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitConstStmt(CONST_STRING,1,"/");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_outNIOBuffer","Lorg/mortbay/io/nio/NIOBuffer;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Lorg/mortbay/io/nio/NIOBuffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "I"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitConstStmt(CONST_STRING,1," last ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_last","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitConstStmt(CONST_STRING,1," ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","_result","Ljavax/net/ssl/SSLEngineResult;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
