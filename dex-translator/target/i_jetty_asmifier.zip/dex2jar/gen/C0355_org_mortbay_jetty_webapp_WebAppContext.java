package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0355_org_mortbay_jetty_webapp_WebAppContext {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/jetty/webapp/WebAppContext;","Lorg/mortbay/jetty/servlet/Context;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("WebAppContext.java");
        f000_ERROR_PAGE(cv);
        f001_WEB_DEFAULTS_XML(cv);
        f002___dftConfigurationClasses(cv);
        f003__configurationClasses(cv);
        f004__configurations(cv);
        f005__copyDir(cv);
        f006__defaultsDescriptor(cv);
        f007__descriptor(cv);
        f008__distributable(cv);
        f009__extraClasspath(cv);
        f010__extractWAR(cv);
        f011__isExistingTmpDir(cv);
        f012__logUrlOnStart(cv);
        f013__overrideDescriptor(cv);
        f014__ownClassLoader(cv);
        f015__parentLoaderPriority(cv);
        f016__permissions(cv);
        f017__resourceAliases(cv);
        f018__serverClasses(cv);
        f019__systemClasses(cv);
        f020__tmpDir(cv);
        f021__unavailable(cv);
        f022__unavailableException(cv);
        f023__war(cv);
        m000__clinit_(cv);
        m001__init_(cv);
        m002__init_(cv);
        m003__init_(cv);
        m004__init_(cv);
        m005_addWebApplications(cv);
        m006_addWebApplications(cv);
        m007_addWebApplications(cv);
        m008_addWebApplications(cv);
        m009_getCanonicalNameForWebAppTmpDir(cv);
        m010_getCurrentWebAppContext(cv);
        m011_addEventListener(cv);
        m012_doStart(cv);
        m013_doStop(cv);
        m014_dumpUrl(cv);
        m015_getConfigurationClasses(cv);
        m016_getConfigurations(cv);
        m017_getDefaultsDescriptor(cv);
        m018_getDescriptor(cv);
        m019_getExtraClasspath(cv);
        m020_getOverrideDescriptor(cv);
        m021_getPermissions(cv);
        m022_getResource(cv);
        m023_getResourceAlias(cv);
        m024_getResourceAliases(cv);
        m025_getServerClasses(cv);
        m026_getSystemClasses(cv);
        m027_getTempDirectory(cv);
        m028_getUnavailableException(cv);
        m029_getWar(cv);
        m030_getWebInf(cv);
        m031_handle(cv);
        m032_isCopyWebDir(cv);
        m033_isDistributable(cv);
        m034_isExtractWAR(cv);
        m035_isLogUrlOnStart(cv);
        m036_isParentLoaderPriority(cv);
        m037_isProtectedTarget(cv);
        m038_isTempWorkDirectory(cv);
        m039_loadConfigurations(cv);
        m040_removeResourceAlias(cv);
        m041_resolveWebApp(cv);
        m042_setClassLoader(cv);
        m043_setConfigurationClasses(cv);
        m044_setConfigurations(cv);
        m045_setCopyWebDir(cv);
        m046_setDefaultsDescriptor(cv);
        m047_setDescriptor(cv);
        m048_setDistributable(cv);
        m049_setEventListeners(cv);
        m050_setExtraClasspath(cv);
        m051_setExtractWAR(cv);
        m052_setLogUrlOnStart(cv);
        m053_setOverrideDescriptor(cv);
        m054_setParentLoaderPriority(cv);
        m055_setPermissions(cv);
        m056_setResourceAlias(cv);
        m057_setResourceAliases(cv);
        m058_setServerClasses(cv);
        m059_setSystemClasses(cv);
        m060_setTempDirectory(cv);
        m061_setWar(cv);
        m062_startContext(cv);
        m063_toString(cv);
    }
    public static void f000_ERROR_PAGE(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","ERROR_PAGE","Ljava/lang/String;"), "org.mortbay.jetty.error_page");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001_WEB_DEFAULTS_XML(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","WEB_DEFAULTS_XML","Ljava/lang/String;"), "org/mortbay/jetty/webapp/webdefault.xml");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002___dftConfigurationClasses(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC, new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","__dftConfigurationClasses","[Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003__configurationClasses(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_configurationClasses","[Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f004__configurations(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_configurations","[Lorg/mortbay/jetty/webapp/Configuration;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f005__copyDir(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_copyDir","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f006__defaultsDescriptor(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_defaultsDescriptor","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f007__descriptor(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_descriptor","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f008__distributable(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_distributable","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f009__extraClasspath(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_extraClasspath","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f010__extractWAR(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_extractWAR","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f011__isExistingTmpDir(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_isExistingTmpDir","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f012__logUrlOnStart(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_logUrlOnStart","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f013__overrideDescriptor(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_overrideDescriptor","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f014__ownClassLoader(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_TRANSIENT, new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_ownClassLoader","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f015__parentLoaderPriority(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_parentLoaderPriority","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f016__permissions(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_permissions","Ljava/security/PermissionCollection;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f017__resourceAliases(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_TRANSIENT, new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_resourceAliases","Ljava/util/Map;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f018__serverClasses(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_serverClasses","[Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f019__systemClasses(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_systemClasses","[Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f020__tmpDir(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_tmpDir","Ljava/io/File;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f021__unavailable(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_TRANSIENT, new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_unavailable","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f022__unavailableException(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_unavailableException","Ljava/lang/Throwable;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f023__war(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_war","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__clinit_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","<clinit>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(78,L0);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(4)); // int: 0x00000004  float:0.000000
                code.visitTypeStmt(NEW_ARRAY,0,0,"[Ljava/lang/String;");
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitConstStmt(CONST_STRING,2,"org.mortbay.ijetty.AndroidWebInfConfiguration");
                code.visitStmt3R(APUT_OBJECT,2,0,1);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitConstStmt(CONST_STRING,2,"org.mortbay.jetty.webapp.WebXmlConfiguration");
                code.visitStmt3R(APUT_OBJECT,2,0,1);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitConstStmt(CONST_STRING,2,"org.mortbay.jetty.webapp.JettyWebXmlConfiguration");
                code.visitStmt3R(APUT_OBJECT,2,0,1);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(3)); // int: 0x00000003  float:0.000000
                code.visitConstStmt(CONST_STRING,2,"org.mortbay.jetty.webapp.TagLibConfiguration");
                code.visitStmt3R(APUT_OBJECT,2,0,1);
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","__dftConfigurationClasses","[Ljava/lang/String;"));
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","<init>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(265,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(266,L2);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,0,0,0,0},new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","<init>",new String[]{ "Lorg/mortbay/jetty/security/SecurityHandler;","Lorg/mortbay/jetty/servlet/SessionHandler;","Lorg/mortbay/jetty/servlet/ServletHandler;","Lorg/mortbay/jetty/handler/ErrorHandler;"},"V"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","<init>",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(10);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"webApp");
                ddv.visitParameterName(1,"contextPath");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(275,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(85,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(87,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(88,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(89,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(90,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(91,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(92,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(93,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(94,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(96,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(97,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(106,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(276,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(277,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(278,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(279,L17);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,6, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitConstStmt(CONST_4,5, Integer.valueOf(3)); // int: 0x00000003  float:0.000000
                code.visitConstStmt(CONST_4,4, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 7,1,9,5},new Method("Lorg/mortbay/jetty/servlet/Context;","<init>",new String[]{ "Lorg/mortbay/jetty/HandlerContainer;","Ljava/lang/String;","I"},"V"));
                code.visitLabel(L2);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","__dftConfigurationClasses","[Ljava/lang/String;"));
                code.visitFieldStmt(IPUT_OBJECT,0,7,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_configurationClasses","[Ljava/lang/String;"));
                code.visitLabel(L3);
                code.visitConstStmt(CONST_STRING,0,"org/mortbay/jetty/webapp/webdefault.xml");
                code.visitFieldStmt(IPUT_OBJECT,0,7,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_defaultsDescriptor","Ljava/lang/String;"));
                code.visitLabel(L4);
                code.visitFieldStmt(IPUT_OBJECT,1,7,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_descriptor","Ljava/lang/String;"));
                code.visitLabel(L5);
                code.visitFieldStmt(IPUT_OBJECT,1,7,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_overrideDescriptor","Ljava/lang/String;"));
                code.visitLabel(L6);
                code.visitFieldStmt(IPUT_BOOLEAN,3,7,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_distributable","Z"));
                code.visitLabel(L7);
                code.visitFieldStmt(IPUT_BOOLEAN,4,7,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_extractWAR","Z"));
                code.visitLabel(L8);
                code.visitFieldStmt(IPUT_BOOLEAN,3,7,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_copyDir","Z"));
                code.visitLabel(L9);
                code.visitFieldStmt(IPUT_BOOLEAN,3,7,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_logUrlOnStart","Z"));
                code.visitLabel(L10);
                code.visitConstStmt(CONST_STRING,0,"org.mortbay.jetty.webapp.parentLoaderPriority");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Ljava/lang/Boolean;","getBoolean",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitFieldStmt(IPUT_BOOLEAN,0,7,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_parentLoaderPriority","Z"));
                code.visitLabel(L11);
                code.visitConstStmt(CONST_16,0, Integer.valueOf(8)); // int: 0x00000008  float:0.000000
                code.visitTypeStmt(NEW_ARRAY,0,0,"[Ljava/lang/String;");
                code.visitConstStmt(CONST_STRING,1,"java.");
                code.visitStmt3R(APUT_OBJECT,1,0,3);
                code.visitConstStmt(CONST_STRING,1,"javax.servlet.");
                code.visitStmt3R(APUT_OBJECT,1,0,4);
                code.visitConstStmt(CONST_STRING,1,"javax.xml.");
                code.visitStmt3R(APUT_OBJECT,1,0,6);
                code.visitConstStmt(CONST_STRING,1,"org.mortbay.");
                code.visitStmt3R(APUT_OBJECT,1,0,5);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(4)); // int: 0x00000004  float:0.000000
                code.visitConstStmt(CONST_STRING,2,"org.xml.");
                code.visitStmt3R(APUT_OBJECT,2,0,1);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(5)); // int: 0x00000005  float:0.000000
                code.visitConstStmt(CONST_STRING,2,"org.w3c.");
                code.visitStmt3R(APUT_OBJECT,2,0,1);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(6)); // int: 0x00000006  float:0.000000
                code.visitConstStmt(CONST_STRING,2,"org.apache.commons.logging.");
                code.visitStmt3R(APUT_OBJECT,2,0,1);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(7)); // int: 0x00000007  float:0.000000
                code.visitConstStmt(CONST_STRING,2,"org.apache.log4j.");
                code.visitStmt3R(APUT_OBJECT,2,0,1);
                code.visitFieldStmt(IPUT_OBJECT,0,7,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_systemClasses","[Ljava/lang/String;"));
                code.visitLabel(L12);
                code.visitTypeStmt(NEW_ARRAY,0,5,"[Ljava/lang/String;");
                code.visitConstStmt(CONST_STRING,1,"-org.mortbay.jetty.plus.jaas.");
                code.visitStmt3R(APUT_OBJECT,1,0,3);
                code.visitConstStmt(CONST_STRING,1,"org.mortbay.jetty.");
                code.visitStmt3R(APUT_OBJECT,1,0,4);
                code.visitConstStmt(CONST_STRING,1,"org.slf4j.");
                code.visitStmt3R(APUT_OBJECT,1,0,6);
                code.visitFieldStmt(IPUT_OBJECT,0,7,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_serverClasses","[Ljava/lang/String;"));
                code.visitLabel(L13);
                code.visitFieldStmt(IPUT_BOOLEAN,3,7,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_ownClassLoader","Z"));
                code.visitLabel(L14);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,9},new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","setContextPath",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L15);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,8},new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","setWar",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L16);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/jetty/servlet/ErrorPageErrorHandler;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Lorg/mortbay/jetty/servlet/ErrorPageErrorHandler;","<init>",new String[]{ },"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,0},new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","setErrorHandler",new String[]{ "Lorg/mortbay/jetty/handler/ErrorHandler;"},"V"));
                code.visitLabel(L17);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","<init>",new String[]{ "Lorg/mortbay/jetty/HandlerContainer;","Ljava/lang/String;","Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(11);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"parent");
                ddv.visitParameterName(1,"webApp");
                ddv.visitParameterName(2,"contextPath");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(289,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(85,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(87,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(88,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(89,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(90,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(91,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(92,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(93,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(94,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(96,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(97,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(106,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(290,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(291,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(292,L16);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitConstStmt(CONST_4,6, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitConstStmt(CONST_4,5, Integer.valueOf(3)); // int: 0x00000003  float:0.000000
                code.visitConstStmt(CONST_4,4, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 7,8,10,5},new Method("Lorg/mortbay/jetty/servlet/Context;","<init>",new String[]{ "Lorg/mortbay/jetty/HandlerContainer;","Ljava/lang/String;","I"},"V"));
                code.visitLabel(L2);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","__dftConfigurationClasses","[Ljava/lang/String;"));
                code.visitFieldStmt(IPUT_OBJECT,0,7,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_configurationClasses","[Ljava/lang/String;"));
                code.visitLabel(L3);
                code.visitConstStmt(CONST_STRING,0,"org/mortbay/jetty/webapp/webdefault.xml");
                code.visitFieldStmt(IPUT_OBJECT,0,7,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_defaultsDescriptor","Ljava/lang/String;"));
                code.visitLabel(L4);
                code.visitFieldStmt(IPUT_OBJECT,1,7,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_descriptor","Ljava/lang/String;"));
                code.visitLabel(L5);
                code.visitFieldStmt(IPUT_OBJECT,1,7,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_overrideDescriptor","Ljava/lang/String;"));
                code.visitLabel(L6);
                code.visitFieldStmt(IPUT_BOOLEAN,3,7,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_distributable","Z"));
                code.visitLabel(L7);
                code.visitFieldStmt(IPUT_BOOLEAN,4,7,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_extractWAR","Z"));
                code.visitLabel(L8);
                code.visitFieldStmt(IPUT_BOOLEAN,3,7,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_copyDir","Z"));
                code.visitLabel(L9);
                code.visitFieldStmt(IPUT_BOOLEAN,3,7,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_logUrlOnStart","Z"));
                code.visitLabel(L10);
                code.visitConstStmt(CONST_STRING,0,"org.mortbay.jetty.webapp.parentLoaderPriority");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Ljava/lang/Boolean;","getBoolean",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitFieldStmt(IPUT_BOOLEAN,0,7,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_parentLoaderPriority","Z"));
                code.visitLabel(L11);
                code.visitConstStmt(CONST_16,0, Integer.valueOf(8)); // int: 0x00000008  float:0.000000
                code.visitTypeStmt(NEW_ARRAY,0,0,"[Ljava/lang/String;");
                code.visitConstStmt(CONST_STRING,1,"java.");
                code.visitStmt3R(APUT_OBJECT,1,0,3);
                code.visitConstStmt(CONST_STRING,1,"javax.servlet.");
                code.visitStmt3R(APUT_OBJECT,1,0,4);
                code.visitConstStmt(CONST_STRING,1,"javax.xml.");
                code.visitStmt3R(APUT_OBJECT,1,0,6);
                code.visitConstStmt(CONST_STRING,1,"org.mortbay.");
                code.visitStmt3R(APUT_OBJECT,1,0,5);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(4)); // int: 0x00000004  float:0.000000
                code.visitConstStmt(CONST_STRING,2,"org.xml.");
                code.visitStmt3R(APUT_OBJECT,2,0,1);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(5)); // int: 0x00000005  float:0.000000
                code.visitConstStmt(CONST_STRING,2,"org.w3c.");
                code.visitStmt3R(APUT_OBJECT,2,0,1);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(6)); // int: 0x00000006  float:0.000000
                code.visitConstStmt(CONST_STRING,2,"org.apache.commons.logging.");
                code.visitStmt3R(APUT_OBJECT,2,0,1);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(7)); // int: 0x00000007  float:0.000000
                code.visitConstStmt(CONST_STRING,2,"org.apache.log4j.");
                code.visitStmt3R(APUT_OBJECT,2,0,1);
                code.visitFieldStmt(IPUT_OBJECT,0,7,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_systemClasses","[Ljava/lang/String;"));
                code.visitLabel(L12);
                code.visitTypeStmt(NEW_ARRAY,0,5,"[Ljava/lang/String;");
                code.visitConstStmt(CONST_STRING,1,"-org.mortbay.jetty.plus.jaas.");
                code.visitStmt3R(APUT_OBJECT,1,0,3);
                code.visitConstStmt(CONST_STRING,1,"org.mortbay.jetty.");
                code.visitStmt3R(APUT_OBJECT,1,0,4);
                code.visitConstStmt(CONST_STRING,1,"org.slf4j.");
                code.visitStmt3R(APUT_OBJECT,1,0,6);
                code.visitFieldStmt(IPUT_OBJECT,0,7,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_serverClasses","[Ljava/lang/String;"));
                code.visitLabel(L13);
                code.visitFieldStmt(IPUT_BOOLEAN,3,7,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_ownClassLoader","Z"));
                code.visitLabel(L14);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,9},new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","setWar",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L15);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/jetty/servlet/ErrorPageErrorHandler;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Lorg/mortbay/jetty/servlet/ErrorPageErrorHandler;","<init>",new String[]{ },"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,0},new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","setErrorHandler",new String[]{ "Lorg/mortbay/jetty/handler/ErrorHandler;"},"V"));
                code.visitLabel(L16);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","<init>",new String[]{ "Lorg/mortbay/jetty/security/SecurityHandler;","Lorg/mortbay/jetty/servlet/SessionHandler;","Lorg/mortbay/jetty/servlet/ServletHandler;","Lorg/mortbay/jetty/handler/ErrorHandler;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(15);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"securityHandler");
                ddv.visitParameterName(1,"sessionHandler");
                ddv.visitParameterName(2,"servletHandler");
                ddv.visitParameterName(3,"errorHandler");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(299,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(85,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(87,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(88,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(89,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(90,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(91,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(92,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(93,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(94,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(96,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(97,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(106,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(305,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(306,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(299,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(305,L17);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,9, Integer.valueOf(3)); // int: 0x00000003  float:0.000000
                code.visitConstStmt(CONST_4,8, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitConstStmt(CONST_4,7, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitConstStmt(CONST_4,6, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitJumpStmt(IF_EQZ,12,-1,L16);
                code.visitStmt2R(MOVE_OBJECT,2,12);
                DexLabel L18=new DexLabel();
                code.visitLabel(L18);
                DexLabel L19=new DexLabel();
                code.visitJumpStmt(IF_EQZ,11,-1,L19);
                code.visitStmt2R(MOVE_OBJECT,3,11);
                DexLabel L20=new DexLabel();
                code.visitLabel(L20);
                DexLabel L21=new DexLabel();
                code.visitJumpStmt(IF_EQZ,13,-1,L21);
                code.visitStmt2R(MOVE_OBJECT,4,13);
                DexLabel L22=new DexLabel();
                code.visitLabel(L22);
                code.visitStmt2R(MOVE_OBJECT,0,10);
                code.visitStmt2R(MOVE_OBJECT,5,1);
                code.visitMethodStmt(INVOKE_DIRECT_RANGE,new int[]{ 0,1,2,3,4,5},new Method("Lorg/mortbay/jetty/servlet/Context;","<init>",new String[]{ "Lorg/mortbay/jetty/HandlerContainer;","Lorg/mortbay/jetty/servlet/SessionHandler;","Lorg/mortbay/jetty/security/SecurityHandler;","Lorg/mortbay/jetty/servlet/ServletHandler;","Lorg/mortbay/jetty/handler/ErrorHandler;"},"V"));
                code.visitLabel(L2);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","__dftConfigurationClasses","[Ljava/lang/String;"));
                code.visitFieldStmt(IPUT_OBJECT,0,10,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_configurationClasses","[Ljava/lang/String;"));
                code.visitLabel(L3);
                code.visitConstStmt(CONST_STRING,0,"org/mortbay/jetty/webapp/webdefault.xml");
                code.visitFieldStmt(IPUT_OBJECT,0,10,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_defaultsDescriptor","Ljava/lang/String;"));
                code.visitLabel(L4);
                code.visitFieldStmt(IPUT_OBJECT,1,10,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_descriptor","Ljava/lang/String;"));
                code.visitLabel(L5);
                code.visitFieldStmt(IPUT_OBJECT,1,10,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_overrideDescriptor","Ljava/lang/String;"));
                code.visitLabel(L6);
                code.visitFieldStmt(IPUT_BOOLEAN,6,10,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_distributable","Z"));
                code.visitLabel(L7);
                code.visitFieldStmt(IPUT_BOOLEAN,7,10,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_extractWAR","Z"));
                code.visitLabel(L8);
                code.visitFieldStmt(IPUT_BOOLEAN,6,10,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_copyDir","Z"));
                code.visitLabel(L9);
                code.visitFieldStmt(IPUT_BOOLEAN,6,10,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_logUrlOnStart","Z"));
                code.visitLabel(L10);
                code.visitConstStmt(CONST_STRING,0,"org.mortbay.jetty.webapp.parentLoaderPriority");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Ljava/lang/Boolean;","getBoolean",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitFieldStmt(IPUT_BOOLEAN,0,10,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_parentLoaderPriority","Z"));
                code.visitLabel(L11);
                code.visitConstStmt(CONST_16,0, Integer.valueOf(8)); // int: 0x00000008  float:0.000000
                code.visitTypeStmt(NEW_ARRAY,0,0,"[Ljava/lang/String;");
                code.visitConstStmt(CONST_STRING,1,"java.");
                code.visitStmt3R(APUT_OBJECT,1,0,6);
                code.visitConstStmt(CONST_STRING,1,"javax.servlet.");
                code.visitStmt3R(APUT_OBJECT,1,0,7);
                code.visitConstStmt(CONST_STRING,1,"javax.xml.");
                code.visitStmt3R(APUT_OBJECT,1,0,8);
                code.visitConstStmt(CONST_STRING,1,"org.mortbay.");
                code.visitStmt3R(APUT_OBJECT,1,0,9);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(4)); // int: 0x00000004  float:0.000000
                code.visitConstStmt(CONST_STRING,2,"org.xml.");
                code.visitStmt3R(APUT_OBJECT,2,0,1);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(5)); // int: 0x00000005  float:0.000000
                code.visitConstStmt(CONST_STRING,2,"org.w3c.");
                code.visitStmt3R(APUT_OBJECT,2,0,1);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(6)); // int: 0x00000006  float:0.000000
                code.visitConstStmt(CONST_STRING,2,"org.apache.commons.logging.");
                code.visitStmt3R(APUT_OBJECT,2,0,1);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(7)); // int: 0x00000007  float:0.000000
                code.visitConstStmt(CONST_STRING,2,"org.apache.log4j.");
                code.visitStmt3R(APUT_OBJECT,2,0,1);
                code.visitFieldStmt(IPUT_OBJECT,0,10,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_systemClasses","[Ljava/lang/String;"));
                code.visitLabel(L12);
                code.visitTypeStmt(NEW_ARRAY,0,9,"[Ljava/lang/String;");
                code.visitConstStmt(CONST_STRING,1,"-org.mortbay.jetty.plus.jaas.");
                code.visitStmt3R(APUT_OBJECT,1,0,6);
                code.visitConstStmt(CONST_STRING,1,"org.mortbay.jetty.");
                code.visitStmt3R(APUT_OBJECT,1,0,7);
                code.visitConstStmt(CONST_STRING,1,"org.slf4j.");
                code.visitStmt3R(APUT_OBJECT,1,0,8);
                code.visitFieldStmt(IPUT_OBJECT,0,10,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_serverClasses","[Ljava/lang/String;"));
                code.visitLabel(L13);
                code.visitFieldStmt(IPUT_BOOLEAN,6,10,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_ownClassLoader","Z"));
                code.visitLabel(L14);
                code.visitJumpStmt(IF_EQZ,14,-1,L17);
                code.visitStmt2R(MOVE_OBJECT,0,14);
                DexLabel L23=new DexLabel();
                code.visitLabel(L23);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10,0},new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","setErrorHandler",new String[]{ "Lorg/mortbay/jetty/handler/ErrorHandler;"},"V"));
                code.visitLabel(L15);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L16);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/jetty/servlet/SessionHandler;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Lorg/mortbay/jetty/servlet/SessionHandler;","<init>",new String[]{ },"V"));
                code.visitStmt2R(MOVE_OBJECT,2,0);
                code.visitJumpStmt(GOTO,-1,-1,L18);
                code.visitLabel(L19);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/jetty/security/SecurityHandler;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Lorg/mortbay/jetty/security/SecurityHandler;","<init>",new String[]{ },"V"));
                code.visitStmt2R(MOVE_OBJECT,3,0);
                code.visitJumpStmt(GOTO,-1,-1,L20);
                code.visitLabel(L21);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/jetty/servlet/ServletHandler;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","<init>",new String[]{ },"V"));
                code.visitStmt2R(MOVE_OBJECT,4,0);
                code.visitJumpStmt(GOTO,-1,-1,L22);
                code.visitLabel(L17);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/jetty/servlet/ErrorPageErrorHandler;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Lorg/mortbay/jetty/servlet/ErrorPageErrorHandler;","<init>",new String[]{ },"V"));
                code.visitJumpStmt(GOTO,-1,-1,L23);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_addWebApplications(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","addWebApplications",new String[]{ "Lorg/mortbay/jetty/HandlerContainer;","Ljava/lang/String;","Ljava/lang/String;","Z","Z"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(11);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"contexts");
                ddv.visitParameterName(1,"webapps");
                ddv.visitParameterName(2,"defaults");
                ddv.visitParameterName(3,"extract");
                ddv.visitParameterName(4,"java2CompliantClassLoader");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(210,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(211,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(SGET_OBJECT,3,-1,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","__dftConfigurationClasses","[Ljava/lang/String;"));
                code.visitStmt2R(MOVE_OBJECT,0,6);
                code.visitStmt2R(MOVE_OBJECT,1,7);
                code.visitStmt2R(MOVE_OBJECT,2,8);
                code.visitStmt2R(MOVE,4,9);
                code.visitStmt2R(MOVE,5,10);
                code.visitMethodStmt(INVOKE_STATIC_RANGE,new int[]{ 0,1,2,3,4,5},new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","addWebApplications",new String[]{ "Lorg/mortbay/jetty/HandlerContainer;","Ljava/lang/String;","Ljava/lang/String;","[Ljava/lang/String;","Z","Z"},"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_addWebApplications(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","addWebApplications",new String[]{ "Lorg/mortbay/jetty/HandlerContainer;","Ljava/lang/String;","Ljava/lang/String;","[Ljava/lang/String;","Z","Z"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(10);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                DexLabel L3=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2,L3},new String[]{ "Ljava/io/IOException;","Ljava/lang/Exception;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"contexts");
                ddv.visitParameterName(1,"webapps");
                ddv.visitParameterName(2,"defaults");
                ddv.visitParameterName(3,"configurations");
                ddv.visitParameterName(4,"extract");
                ddv.visitParameterName(5,"java2CompliantClassLoader");
                DexLabel L4=new DexLabel();
                ddv.visitPrologue(L4);
                ddv.visitLineNumber(241,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(242,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(243,L6);
                ddv.visitStartLocal(0,L6,"deployer","Lorg/mortbay/jetty/deployer/WebAppDeployer;",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(244,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(245,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(246,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(247,L10);
                ddv.visitLineNumber(250,L0);
                ddv.visitLineNumber(260,L1);
                ddv.visitLineNumber(252,L2);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(254,L11);
                ddv.visitStartLocal(1,L11,"e","Ljava/io/IOException;",null);
                ddv.visitLineNumber(256,L3);
                ddv.visitEndLocal(1,L3);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(258,L12);
                ddv.visitStartLocal(1,L12,"e","Ljava/lang/Exception;",null);
                code.visitLabel(L4);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,3,"Deprecated configuration used for ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2},new Method("Lorg/mortbay/log/Log;","warn",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L5);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/jetty/deployer/WebAppDeployer;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Lorg/mortbay/jetty/deployer/WebAppDeployer;","<init>",new String[]{ },"V"));
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,4},new Method("Lorg/mortbay/jetty/deployer/WebAppDeployer;","setContexts",new String[]{ "Lorg/mortbay/jetty/HandlerContainer;"},"V"));
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,5},new Method("Lorg/mortbay/jetty/deployer/WebAppDeployer;","setWebAppDir",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,7},new Method("Lorg/mortbay/jetty/deployer/WebAppDeployer;","setConfigurationClasses",new String[]{ "[Ljava/lang/String;"},"V"));
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,8},new Method("Lorg/mortbay/jetty/deployer/WebAppDeployer;","setExtract",new String[]{ "Z"},"V"));
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,9},new Method("Lorg/mortbay/jetty/deployer/WebAppDeployer;","setParentLoaderPriority",new String[]{ "Z"},"V"));
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/deployer/WebAppDeployer;","start",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitLabel(L11);
                code.visitStmt1R(THROW,1);
                code.visitLabel(L3);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitLabel(L12);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Ljava/lang/RuntimeException;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2,1},new Method("Ljava/lang/RuntimeException;","<init>",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitStmt1R(THROW,2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m007_addWebApplications(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","addWebApplications",new String[]{ "Lorg/mortbay/jetty/Server;","Ljava/lang/String;","Ljava/lang/String;","Z","Z"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(11);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"server");
                ddv.visitParameterName(1,"webapps");
                ddv.visitParameterName(2,"defaults");
                ddv.visitParameterName(3,"extract");
                ddv.visitParameterName(4,"java2CompliantClassLoader");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(145,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(146,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(SGET_OBJECT,3,-1,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","__dftConfigurationClasses","[Ljava/lang/String;"));
                code.visitStmt2R(MOVE_OBJECT,0,6);
                code.visitStmt2R(MOVE_OBJECT,1,7);
                code.visitStmt2R(MOVE_OBJECT,2,8);
                code.visitStmt2R(MOVE,4,9);
                code.visitStmt2R(MOVE,5,10);
                code.visitMethodStmt(INVOKE_STATIC_RANGE,new int[]{ 0,1,2,3,4,5},new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","addWebApplications",new String[]{ "Lorg/mortbay/jetty/Server;","Ljava/lang/String;","Ljava/lang/String;","[Ljava/lang/String;","Z","Z"},"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m008_addWebApplications(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","addWebApplications",new String[]{ "Lorg/mortbay/jetty/Server;","Ljava/lang/String;","Ljava/lang/String;","[Ljava/lang/String;","Z","Z"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(12);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"server");
                ddv.visitParameterName(1,"webapps");
                ddv.visitParameterName(2,"defaults");
                ddv.visitParameterName(3,"configurations");
                ddv.visitParameterName(4,"extract");
                ddv.visitParameterName(5,"java2CompliantClassLoader");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(176,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(177,L1);
                ddv.visitStartLocal(0,L1,"contexts","Lorg/mortbay/jetty/handler/HandlerCollection;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(178,L2);
                DexLabel L3=new DexLabel();
                ddv.visitEndLocal(0,L3);
                DexLabel L4=new DexLabel();
                ddv.visitRestartLocal(0,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(180,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(181,L6);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_CLASS,1,new DexType("Lorg/mortbay/jetty/handler/ContextHandlerCollection;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,1},new Method("Lorg/mortbay/jetty/Server;","getChildHandlerByClass",new String[]{ "Ljava/lang/Class;"},"Lorg/mortbay/jetty/Handler;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Lorg/mortbay/jetty/handler/HandlerCollection;");
                code.visitLabel(L1);
                code.visitJumpStmt(IF_NEZ,0,-1,L4);
                code.visitLabel(L2);
                code.visitConstStmt(CONST_CLASS,1,new DexType("Lorg/mortbay/jetty/handler/HandlerCollection;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,1},new Method("Lorg/mortbay/jetty/Server;","getChildHandlerByClass",new String[]{ "Ljava/lang/Class;"},"Lorg/mortbay/jetty/Handler;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L3);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Lorg/mortbay/jetty/handler/HandlerCollection;");
                code.visitLabel(L4);
                code.visitStmt2R(MOVE_OBJECT,1,7);
                code.visitStmt2R(MOVE_OBJECT,2,8);
                code.visitStmt2R(MOVE_OBJECT,3,9);
                code.visitStmt2R(MOVE,4,10);
                code.visitStmt2R(MOVE,5,11);
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_STATIC_RANGE,new int[]{ 0,1,2,3,4,5},new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","addWebApplications",new String[]{ "Lorg/mortbay/jetty/HandlerContainer;","Ljava/lang/String;","Ljava/lang/String;","[Ljava/lang/String;","Z","Z"},"V"));
                code.visitLabel(L6);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m009_getCanonicalNameForWebAppTmpDir(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PRIVATE, new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","getCanonicalNameForWebAppTmpDir",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(16);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/lang/Exception;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(1253,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(1254,L4);
                ddv.visitStartLocal(1,L4,"canonicalName","Ljava/lang/StringBuffer;",null);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(1257,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(1261,L6);
                ddv.visitStartLocal(2,L6,"connectors","[Lorg/mortbay/jetty/Connector;",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(1262,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(1263,L8);
                ddv.visitStartLocal(6,L8,"host","Ljava/lang/String;",null);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(1264,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(1265,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(1268,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(1270,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(1273,L13);
                ddv.visitStartLocal(8,L13,"port","I",null);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(1274,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(1275,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(1279,L16);
                ddv.visitLineNumber(1282,L0);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(1283,L17);
                ddv.visitStartLocal(9,L17,"resource","Lorg/mortbay/resource/Resource;",null);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(1285,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(1286,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(1289,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(1292,L21);
                ddv.visitRestartLocal(9,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(1293,L22);
                ddv.visitStartLocal(10,L22,"tmp","Ljava/lang/String;",null);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(1294,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(1295,L24);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(1296,L25);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(1298,L26);
                ddv.visitRestartLocal(10,L26);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(1300,L27);
                ddv.visitStartLocal(7,L27,"i","I",null);
                ddv.visitLineNumber(1308,L1);
                ddv.visitEndLocal(9,L1);
                ddv.visitEndLocal(10,L1);
                ddv.visitEndLocal(7,L1);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(1309,L28);
                DexLabel L29=new DexLabel();
                ddv.visitLineNumber(1310,L29);
                ddv.visitStartLocal(3,L29,"contextPath","Ljava/lang/String;",null);
                DexLabel L30=new DexLabel();
                ddv.visitLineNumber(1311,L30);
                DexLabel L31=new DexLabel();
                ddv.visitLineNumber(1312,L31);
                ddv.visitRestartLocal(3,L31);
                DexLabel L32=new DexLabel();
                ddv.visitLineNumber(1315,L32);
                DexLabel L33=new DexLabel();
                ddv.visitLineNumber(1316,L33);
                DexLabel L34=new DexLabel();
                ddv.visitLineNumber(1317,L34);
                ddv.visitStartLocal(11,L34,"vhosts","[Ljava/lang/String;",null);
                DexLabel L35=new DexLabel();
                ddv.visitLineNumber(1320,L35);
                DexLabel L36=new DexLabel();
                ddv.visitLineNumber(1321,L36);
                ddv.visitStartLocal(5,L36,"hash","Ljava/lang/String;",null);
                DexLabel L37=new DexLabel();
                ddv.visitLineNumber(1322,L37);
                DexLabel L38=new DexLabel();
                ddv.visitLineNumber(1325,L38);
                DexLabel L39=new DexLabel();
                ddv.visitRestartLocal(7,L39);
                DexLabel L40=new DexLabel();
                ddv.visitLineNumber(1327,L40);
                DexLabel L41=new DexLabel();
                ddv.visitLineNumber(1328,L41);
                ddv.visitStartLocal(0,L41,"c","C",null);
                DexLabel L42=new DexLabel();
                ddv.visitLineNumber(1329,L42);
                DexLabel L43=new DexLabel();
                ddv.visitLineNumber(1325,L43);
                DexLabel L44=new DexLabel();
                ddv.visitLineNumber(1262,L44);
                ddv.visitEndLocal(6,L44);
                ddv.visitEndLocal(8,L44);
                ddv.visitEndLocal(3,L44);
                ddv.visitEndLocal(11,L44);
                ddv.visitEndLocal(5,L44);
                ddv.visitEndLocal(7,L44);
                ddv.visitEndLocal(0,L44);
                DexLabel L45=new DexLabel();
                ddv.visitLineNumber(1270,L45);
                ddv.visitRestartLocal(6,L45);
                ddv.visitLineNumber(1302,L2);
                ddv.visitRestartLocal(8,L2);
                DexLabel L46=new DexLabel();
                ddv.visitLineNumber(1304,L46);
                ddv.visitStartLocal(4,L46,"e","Ljava/lang/Exception;",null);
                DexLabel L47=new DexLabel();
                ddv.visitLineNumber(1317,L47);
                ddv.visitEndLocal(4,L47);
                ddv.visitRestartLocal(3,L47);
                ddv.visitRestartLocal(11,L47);
                DexLabel L48=new DexLabel();
                ddv.visitLineNumber(1332,L48);
                ddv.visitRestartLocal(5,L48);
                ddv.visitRestartLocal(7,L48);
                code.visitLabel(L3);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/lang/StringBuffer;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljava/lang/StringBuffer;","<init>",new String[]{ },"V"));
                code.visitLabel(L4);
                code.visitConstStmt(CONST_STRING,12,"Jetty");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,12},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 15},new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","getServer",new String[]{ },"Lorg/mortbay/jetty/Server;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,12);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12},new Method("Lorg/mortbay/jetty/Server;","getConnectors",new String[]{ },"[Lorg/mortbay/jetty/Connector;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L6);
                code.visitConstStmt(CONST_STRING,12,"_");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,12},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L7);
                DexLabel L49=new DexLabel();
                code.visitJumpStmt(IF_EQZ,2,-1,L49);
                code.visitConstStmt(CONST_4,12, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt3R(AGET_OBJECT,12,2,12);
                code.visitJumpStmt(IF_NEZ,12,-1,L44);
                code.visitLabel(L49);
                code.visitConstStmt(CONST_STRING,12,"");
                code.visitStmt2R(MOVE_OBJECT,6,12);
                code.visitLabel(L8);
                code.visitJumpStmt(IF_NEZ,6,-1,L10);
                code.visitLabel(L9);
                code.visitConstStmt(CONST_STRING,6,"0.0.0.0");
                code.visitLabel(L10);
                code.visitConstStmt(CONST_16,12, Integer.valueOf(46)); // int: 0x0000002e  float:0.000000
                code.visitConstStmt(CONST_16,13, Integer.valueOf(95)); // int: 0x0000005f  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,12,13},new Method("Ljava/lang/String;","replace",new String[]{ "C","C"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,12);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,12},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L11);
                code.visitConstStmt(CONST_STRING,12,"_");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,12},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L12);
                DexLabel L50=new DexLabel();
                code.visitJumpStmt(IF_EQZ,2,-1,L50);
                code.visitConstStmt(CONST_4,12, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt3R(AGET_OBJECT,12,2,12);
                code.visitJumpStmt(IF_NEZ,12,-1,L45);
                code.visitLabel(L50);
                code.visitConstStmt(CONST_4,12, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt2R(MOVE,8,12);
                code.visitLabel(L13);
                code.visitJumpStmt(IF_GEZ,8,-1,L15);
                code.visitLabel(L14);
                code.visitConstStmt(CONST_4,12, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt3R(AGET_OBJECT,12,2,12);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 12},new Method("Lorg/mortbay/jetty/Connector;","getPort",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitLabel(L15);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,8},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "I"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L16);
                code.visitConstStmt(CONST_STRING,12,"_");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,12},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 15},new Method("Lorg/mortbay/jetty/servlet/Context;","getBaseResource",new String[]{ },"Lorg/mortbay/resource/Resource;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitLabel(L17);
                code.visitJumpStmt(IF_NEZ,9,-1,L21);
                code.visitLabel(L18);
                code.visitFieldStmt(IGET_OBJECT,12,15,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_war","Ljava/lang/String;"));
                code.visitJumpStmt(IF_EQZ,12,-1,L19);
                code.visitFieldStmt(IGET_OBJECT,12,15,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_war","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,12);
                code.visitJumpStmt(IF_NEZ,12,-1,L20);
                code.visitLabel(L19);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 15},new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","getResourceBase",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,12);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 12},new Method("Lorg/mortbay/resource/Resource;","newResource",new String[]{ "Ljava/lang/String;"},"Lorg/mortbay/resource/Resource;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitLabel(L20);
                code.visitFieldStmt(IGET_OBJECT,12,15,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_war","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 12},new Method("Lorg/mortbay/resource/Resource;","newResource",new String[]{ "Ljava/lang/String;"},"Lorg/mortbay/resource/Resource;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitLabel(L21);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9},new Method("Lorg/mortbay/resource/Resource;","getURL",new String[]{ },"Ljava/net/URL;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,12);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12},new Method("Ljava/net/URL;","getPath",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,12);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 12},new Method("Lorg/mortbay/util/URIUtil;","decodePath",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,10);
                code.visitLabel(L22);
                code.visitConstStmt(CONST_STRING,12,"/");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10,12},new Method("Ljava/lang/String;","endsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,12);
                code.visitJumpStmt(IF_EQZ,12,-1,L24);
                code.visitLabel(L23);
                code.visitConstStmt(CONST_4,12, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,13);
                code.visitConstStmt(CONST_4,14, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt2R(SUB_INT_2ADDR,13,14);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10,12,13},new Method("Ljava/lang/String;","substring",new String[]{ "I","I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,10);
                code.visitLabel(L24);
                code.visitConstStmt(CONST_STRING,12,"!");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10,12},new Method("Ljava/lang/String;","endsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,12);
                code.visitJumpStmt(IF_EQZ,12,-1,L26);
                code.visitLabel(L25);
                code.visitConstStmt(CONST_4,12, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,13);
                code.visitConstStmt(CONST_4,14, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt2R(SUB_INT_2ADDR,13,14);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10,12,13},new Method("Ljava/lang/String;","substring",new String[]{ "I","I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,10);
                code.visitLabel(L26);
                code.visitConstStmt(CONST_STRING,12,"/");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10,12},new Method("Ljava/lang/String;","lastIndexOf",new String[]{ "Ljava/lang/String;"},"I"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitLabel(L27);
                code.visitStmt2R1N(ADD_INT_LIT8,12,7,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,13);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10,12,13},new Method("Ljava/lang/String;","substring",new String[]{ "I","I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,12);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,12},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L1);
                code.visitConstStmt(CONST_STRING,12,"_");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,12},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L28);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 15},new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","getContextPath",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitLabel(L29);
                code.visitConstStmt(CONST_16,12, Integer.valueOf(47)); // int: 0x0000002f  float:0.000000
                code.visitConstStmt(CONST_16,13, Integer.valueOf(95)); // int: 0x0000005f  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,12,13},new Method("Ljava/lang/String;","replace",new String[]{ "C","C"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitLabel(L30);
                code.visitConstStmt(CONST_16,12, Integer.valueOf(92)); // int: 0x0000005c  float:0.000000
                code.visitConstStmt(CONST_16,13, Integer.valueOf(95)); // int: 0x0000005f  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,12,13},new Method("Ljava/lang/String;","replace",new String[]{ "C","C"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitLabel(L31);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,3},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L32);
                code.visitConstStmt(CONST_STRING,12,"_");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,12},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L33);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 15},new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","getVirtualHosts",new String[]{ },"[Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,11);
                code.visitLabel(L34);
                DexLabel L51=new DexLabel();
                code.visitJumpStmt(IF_EQZ,11,-1,L51);
                code.visitConstStmt(CONST_4,12, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt3R(AGET_OBJECT,12,11,12);
                code.visitJumpStmt(IF_NEZ,12,-1,L47);
                code.visitLabel(L51);
                code.visitConstStmt(CONST_STRING,12,"");
                DexLabel L52=new DexLabel();
                code.visitLabel(L52);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,12},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L35);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/lang/StringBuffer;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,12);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12},new Method("Ljava/lang/String;","hashCode",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,12);
                code.visitConstStmt(CONST_16,13, Integer.valueOf(36)); // int: 0x00000024  float:0.000000
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 12,13},new Method("Ljava/lang/Integer;","toString",new String[]{ "I","I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitLabel(L36);
                code.visitConstStmt(CONST_STRING,12,"_");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,12},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L37);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,5},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L38);
                code.visitConstStmt(CONST_4,7, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L39);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/lang/StringBuffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,12);
                code.visitJumpStmt(IF_GE,7,12,L48);
                code.visitLabel(L40);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,7},new Method("Ljava/lang/StringBuffer;","charAt",new String[]{ "I"},"C"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitLabel(L41);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Ljava/lang/Character;","isJavaIdentifierPart",new String[]{ "C"},"Z"));
                code.visitStmt1R(MOVE_RESULT,12);
                code.visitJumpStmt(IF_NEZ,12,-1,L43);
                code.visitLabel(L42);
                code.visitConstStmt(CONST_16,12, Integer.valueOf(46)); // int: 0x0000002e  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,7,12},new Method("Ljava/lang/StringBuffer;","setCharAt",new String[]{ "I","C"},"V"));
                code.visitLabel(L43);
                code.visitStmt2R1N(ADD_INT_LIT8,7,7,1);
                code.visitJumpStmt(GOTO,-1,-1,L39);
                code.visitLabel(L44);
                code.visitConstStmt(CONST_4,12, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt3R(AGET_OBJECT,12,2,12);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 12},new Method("Lorg/mortbay/jetty/Connector;","getHost",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,12);
                code.visitStmt2R(MOVE_OBJECT,6,12);
                code.visitJumpStmt(GOTO_16,-1,-1,L8);
                code.visitLabel(L45);
                code.visitConstStmt(CONST_4,12, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt3R(AGET_OBJECT,12,2,12);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 12},new Method("Lorg/mortbay/jetty/Connector;","getLocalPort",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,12);
                code.visitStmt2R(MOVE,8,12);
                code.visitJumpStmt(GOTO_16,-1,-1,L13);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,12);
                code.visitStmt2R(MOVE_OBJECT,4,12);
                code.visitLabel(L46);
                code.visitConstStmt(CONST_STRING,12,"Can\'t generate resourceBase as part of webapp tmp dir name");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 12,4},new Method("Lorg/mortbay/log/Log;","warn",new String[]{ "Ljava/lang/String;","Ljava/lang/Throwable;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitLabel(L47);
                code.visitConstStmt(CONST_4,12, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt3R(AGET_OBJECT,12,11,12);
                code.visitJumpStmt(GOTO,-1,-1,L52);
                code.visitLabel(L48);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/lang/StringBuffer;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,12);
                code.visitStmt1R(RETURN_OBJECT,12);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m010_getCurrentWebAppContext(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","getCurrentWebAppContext",new String[]{ },"Lorg/mortbay/jetty/handler/ContextHandler;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(111,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(112,L1);
                ddv.visitStartLocal(0,L1,"context","Lorg/mortbay/jetty/handler/ContextHandler$SContext;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(114,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(115,L3);
                ddv.visitStartLocal(1,L3,"handler","Lorg/mortbay/jetty/handler/ContextHandler;",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(118,L4);
                ddv.visitEndLocal(1,L4);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/jetty/handler/ContextHandler;","getCurrentContext",new String[]{ },"Lorg/mortbay/jetty/handler/ContextHandler$SContext;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L1);
                DexLabel L5=new DexLabel();
                code.visitJumpStmt(IF_EQZ,0,-1,L5);
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/handler/ContextHandler$SContext;","getContextHandler",new String[]{ },"Lorg/mortbay/jetty/handler/ContextHandler;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L3);
                code.visitTypeStmt(INSTANCE_OF,2,1,"Lorg/mortbay/jetty/webapp/WebAppContext;");
                code.visitJumpStmt(IF_EQZ,2,-1,L5);
                code.visitStmt2R(MOVE_OBJECT,2,1);
                code.visitLabel(L4);
                code.visitStmt1R(RETURN_OBJECT,2);
                code.visitLabel(L5);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m011_addEventListener(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","addEventListener",new String[]{ "Ljava/util/EventListener;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"listener");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1073,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(1074,L1);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","getEventListeners",new String[]{ },"[Ljava/util/EventListener;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitConstStmt(CONST_CLASS,1,new DexType("Ljava/util/EventListener;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,3,1},new Method("Lorg/mortbay/util/LazyList;","addToArray",new String[]{ "[Ljava/lang/Object;","Ljava/lang/Object;","Ljava/lang/Class;"},"[Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitTypeStmt(CHECK_CAST,0,-1,"[Ljava/util/EventListener;");
                code.visitTypeStmt(CHECK_CAST,0,-1,"[Ljava/util/EventListener;");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,0},new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","setEventListeners",new String[]{ "[Ljava/util/EventListener;"},"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m012_doStart(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","doStart",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/Exception;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(9);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/lang/Exception;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(429,L0);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(431,L4);
                DexLabel L5=new DexLabel();
                ddv.visitStartLocal(2,L5,"i","I",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(432,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(431,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(435,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(436,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(438,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(439,L11);
                ddv.visitStartLocal(0,L11,"classLoader","Lorg/mortbay/jetty/webapp/WebAppClassLoader;",null);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(440,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(443,L13);
                ddv.visitEndLocal(0,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(445,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(446,L15);
                ddv.visitStartLocal(3,L15,"loader","Ljava/lang/ClassLoader;",null);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(447,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(448,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(450,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(451,L19);
                DexLabel L20=new DexLabel();
                ddv.visitRestartLocal(3,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(455,L21);
                ddv.visitEndLocal(3,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(456,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(455,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(458,L24);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(459,L25);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(461,L26);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(462,L27);
                ddv.visitStartLocal(4,L27,"sentinel","Ljava/io/File;",null);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(463,L28);
                DexLabel L29=new DexLabel();
                ddv.visitLineNumber(466,L29);
                ddv.visitEndLocal(4,L29);
                DexLabel L30=new DexLabel();
                ddv.visitLineNumber(468,L30);
                DexLabel L31=new DexLabel();
                ddv.visitLineNumber(469,L31);
                ddv.visitLineNumber(478,L1);
                ddv.visitEndLocal(2,L1);
                ddv.visitLineNumber(471,L2);
                DexLabel L32=new DexLabel();
                ddv.visitLineNumber(474,L32);
                ddv.visitStartLocal(1,L32,"e","Ljava/lang/Exception;",null);
                DexLabel L33=new DexLabel();
                ddv.visitLineNumber(475,L33);
                DexLabel L34=new DexLabel();
                ddv.visitLineNumber(476,L34);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,7, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","loadConfigurations",new String[]{ },"V"));
                code.visitLabel(L4);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,5,8,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_configurations","[Lorg/mortbay/jetty/webapp/Configuration;"));
                code.visitStmt2R(ARRAY_LENGTH,5,5);
                code.visitJumpStmt(IF_GE,2,5,L8);
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,5,8,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_configurations","[Lorg/mortbay/jetty/webapp/Configuration;"));
                code.visitStmt3R(AGET_OBJECT,5,5,2);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 5,8},new Method("Lorg/mortbay/jetty/webapp/Configuration;","setWebAppContext",new String[]{ "Lorg/mortbay/jetty/webapp/WebAppContext;"},"V"));
                code.visitLabel(L7);
                code.visitStmt2R1N(ADD_INT_LIT8,2,2,1);
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitLabel(L8);
                code.visitConstStmt(CONST_4,5, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_BOOLEAN,5,8,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_ownClassLoader","Z"));
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","getClassLoader",new String[]{ },"Ljava/lang/ClassLoader;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitJumpStmt(IF_NEZ,5,-1,L13);
                code.visitLabel(L10);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/jetty/webapp/WebAppClassLoader;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,8},new Method("Lorg/mortbay/jetty/webapp/WebAppClassLoader;","<init>",new String[]{ "Lorg/mortbay/jetty/webapp/WebAppContext;"},"V"));
                code.visitLabel(L11);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,0},new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","setClassLoader",new String[]{ "Ljava/lang/ClassLoader;"},"V"));
                code.visitLabel(L12);
                code.visitConstStmt(CONST_4,5, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitFieldStmt(IPUT_BOOLEAN,5,8,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_ownClassLoader","Z"));
                code.visitLabel(L13);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/log/Log;","isDebugEnabled",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitJumpStmt(IF_EQZ,5,-1,L21);
                code.visitLabel(L14);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","getClassLoader",new String[]{ },"Ljava/lang/ClassLoader;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitLabel(L15);
                code.visitTypeStmt(NEW_INSTANCE,5,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 5},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,6,"Thread Context class loader is: ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 5},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L16);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/lang/ClassLoader;","getParent",new String[]{ },"Ljava/lang/ClassLoader;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitLabel(L17);
                code.visitJumpStmt(IF_EQZ,3,-1,L21);
                code.visitLabel(L18);
                code.visitTypeStmt(NEW_INSTANCE,5,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 5},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,6,"Parent class loader is: ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 5},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L19);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/lang/ClassLoader;","getParent",new String[]{ },"Ljava/lang/ClassLoader;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitLabel(L20);
                code.visitJumpStmt(GOTO,-1,-1,L17);
                code.visitLabel(L21);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                DexLabel L35=new DexLabel();
                code.visitLabel(L35);
                code.visitFieldStmt(IGET_OBJECT,5,8,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_configurations","[Lorg/mortbay/jetty/webapp/Configuration;"));
                code.visitStmt2R(ARRAY_LENGTH,5,5);
                code.visitJumpStmt(IF_GE,2,5,L24);
                code.visitLabel(L22);
                code.visitFieldStmt(IGET_OBJECT,5,8,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_configurations","[Lorg/mortbay/jetty/webapp/Configuration;"));
                code.visitStmt3R(AGET_OBJECT,5,5,2);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 5},new Method("Lorg/mortbay/jetty/webapp/Configuration;","configureClassLoader",new String[]{ },"V"));
                code.visitLabel(L23);
                code.visitStmt2R1N(ADD_INT_LIT8,2,2,1);
                code.visitJumpStmt(GOTO,-1,-1,L35);
                code.visitLabel(L24);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","getTempDirectory",new String[]{ },"Ljava/io/File;"));
                code.visitLabel(L25);
                code.visitFieldStmt(IGET_OBJECT,5,8,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_tmpDir","Ljava/io/File;"));
                code.visitJumpStmt(IF_EQZ,5,-1,L29);
                code.visitFieldStmt(IGET_BOOLEAN,5,8,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_isExistingTmpDir","Z"));
                code.visitJumpStmt(IF_NEZ,5,-1,L29);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","isTempWorkDirectory",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitJumpStmt(IF_NEZ,5,-1,L29);
                code.visitLabel(L26);
                code.visitTypeStmt(NEW_INSTANCE,4,-1,"Ljava/io/File;");
                code.visitFieldStmt(IGET_OBJECT,5,8,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_tmpDir","Ljava/io/File;"));
                code.visitConstStmt(CONST_STRING,6,".active");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4,5,6},new Method("Ljava/io/File;","<init>",new String[]{ "Ljava/io/File;","Ljava/lang/String;"},"V"));
                code.visitLabel(L27);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/io/File;","exists",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitJumpStmt(IF_NEZ,5,-1,L29);
                code.visitLabel(L28);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/io/File;","mkdir",new String[]{ },"Z"));
                code.visitLabel(L29);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 8},new Method("Lorg/mortbay/jetty/servlet/Context;","doStart",new String[]{ },"V"));
                code.visitLabel(L30);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","isLogUrlOnStart",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitJumpStmt(IF_EQZ,5,-1,L1);
                code.visitLabel(L31);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","dumpUrl",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,5);
                code.visitStmt2R(MOVE_OBJECT,1,5);
                code.visitLabel(L32);
                code.visitTypeStmt(NEW_INSTANCE,5,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 5},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,6,"Failed startup of context ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,8},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 5,1},new Method("Lorg/mortbay/log/Log;","warn",new String[]{ "Ljava/lang/String;","Ljava/lang/Throwable;"},"V"));
                code.visitLabel(L33);
                code.visitFieldStmt(IPUT_OBJECT,1,8,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_unavailableException","Ljava/lang/Throwable;"));
                code.visitLabel(L34);
                code.visitFieldStmt(IPUT_BOOLEAN,7,8,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_unavailable","Z"));
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m013_doStop(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","doStop",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/Exception;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(504,L4);
                ddv.visitLineNumber(509,L0);
                DexLabel L5=new DexLabel();
                ddv.visitStartLocal(0,L5,"i","I",null);
                DexLabel L6=new DexLabel();
                ddv.visitEndLocal(0,L6);
                ddv.visitStartLocal(1,L6,"i","I",null);
                DexLabel L7=new DexLabel();
                ddv.visitRestartLocal(0,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(510,L8);
                ddv.visitEndLocal(1,L8);
                DexLabel L9=new DexLabel();
                ddv.visitRestartLocal(1,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(511,L10);
                ddv.visitEndLocal(1,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(514,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(516,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(517,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(521,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(523,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(524,L16);
                ddv.visitLineNumber(529,L1);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(530,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(532,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(533,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(535,L20);
                ddv.visitLineNumber(529,L2);
                ddv.visitEndLocal(0,L2);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(530,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(532,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(533,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(529,L24);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,5, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitConstStmt(CONST_4,4, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 6},new Method("Lorg/mortbay/jetty/servlet/Context;","doStop",new String[]{ },"V"));
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,2,6,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_configurations","[Lorg/mortbay/jetty/webapp/Configuration;"));
                code.visitStmt2R(ARRAY_LENGTH,0,2);
                code.visitLabel(L5);
                code.visitStmt2R(MOVE,1,0);
                code.visitLabel(L6);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt3R(SUB_INT,0,1,2);
                code.visitLabel(L7);
                code.visitJumpStmt(IF_LEZ,1,-1,L10);
                code.visitLabel(L8);
                code.visitFieldStmt(IGET_OBJECT,2,6,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_configurations","[Lorg/mortbay/jetty/webapp/Configuration;"));
                code.visitStmt3R(AGET_OBJECT,2,2,0);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2},new Method("Lorg/mortbay/jetty/webapp/Configuration;","deconfigureWebApp",new String[]{ },"V"));
                code.visitStmt2R(MOVE,1,0);
                code.visitLabel(L9);
                code.visitJumpStmt(GOTO,-1,-1,L6);
                code.visitLabel(L10);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_OBJECT,2,6,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_configurations","[Lorg/mortbay/jetty/webapp/Configuration;"));
                code.visitLabel(L11);
                code.visitFieldStmt(IGET_OBJECT,2,6,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_securityHandler","Lorg/mortbay/jetty/security/SecurityHandler;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/security/SecurityHandler;","getHandler",new String[]{ },"Lorg/mortbay/jetty/Handler;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitJumpStmt(IF_NEZ,2,-1,L14);
                code.visitLabel(L12);
                code.visitFieldStmt(IGET_OBJECT,2,6,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_sessionHandler","Lorg/mortbay/jetty/servlet/SessionHandler;"));
                code.visitFieldStmt(IGET_OBJECT,3,6,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_securityHandler","Lorg/mortbay/jetty/security/SecurityHandler;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Lorg/mortbay/jetty/servlet/SessionHandler;","setHandler",new String[]{ "Lorg/mortbay/jetty/Handler;"},"V"));
                code.visitLabel(L13);
                code.visitFieldStmt(IGET_OBJECT,2,6,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_securityHandler","Lorg/mortbay/jetty/security/SecurityHandler;"));
                code.visitFieldStmt(IGET_OBJECT,3,6,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_servletHandler","Lorg/mortbay/jetty/servlet/ServletHandler;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Lorg/mortbay/jetty/security/SecurityHandler;","setHandler",new String[]{ "Lorg/mortbay/jetty/Handler;"},"V"));
                code.visitLabel(L14);
                code.visitFieldStmt(IGET_OBJECT,2,6,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_tmpDir","Ljava/io/File;"));
                code.visitJumpStmt(IF_EQZ,2,-1,L1);
                code.visitFieldStmt(IGET_BOOLEAN,2,6,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_isExistingTmpDir","Z"));
                code.visitJumpStmt(IF_NEZ,2,-1,L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","isTempWorkDirectory",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_NEZ,2,-1,L1);
                code.visitLabel(L15);
                code.visitFieldStmt(IGET_OBJECT,2,6,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_tmpDir","Ljava/io/File;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2},new Method("Lorg/mortbay/util/IO;","delete",new String[]{ "Ljava/io/File;"},"Z"));
                code.visitLabel(L16);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_OBJECT,2,6,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_tmpDir","Ljava/io/File;"));
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_BOOLEAN,2,6,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_ownClassLoader","Z"));
                code.visitJumpStmt(IF_EQZ,2,-1,L18);
                code.visitLabel(L17);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,4},new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","setClassLoader",new String[]{ "Ljava/lang/ClassLoader;"},"V"));
                code.visitLabel(L18);
                code.visitFieldStmt(IPUT_BOOLEAN,5,6,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_unavailable","Z"));
                code.visitLabel(L19);
                code.visitFieldStmt(IPUT_OBJECT,4,6,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_unavailableException","Ljava/lang/Throwable;"));
                code.visitLabel(L20);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,2);
                code.visitFieldStmt(IGET_BOOLEAN,3,6,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_ownClassLoader","Z"));
                code.visitJumpStmt(IF_EQZ,3,-1,L22);
                code.visitLabel(L21);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,4},new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","setClassLoader",new String[]{ "Ljava/lang/ClassLoader;"},"V"));
                code.visitLabel(L22);
                code.visitFieldStmt(IPUT_BOOLEAN,5,6,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_unavailable","Z"));
                code.visitLabel(L23);
                code.visitFieldStmt(IPUT_OBJECT,4,6,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_unavailableException","Ljava/lang/Throwable;"));
                code.visitLabel(L24);
                code.visitStmt1R(THROW,2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m014_dumpUrl(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","dumpUrl",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(486,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(487,L1);
                ddv.visitStartLocal(1,L1,"connectors","[Lorg/mortbay/jetty/Connector;",null);
                DexLabel L2=new DexLabel();
                ddv.visitStartLocal(3,L2,"i","I",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(489,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(490,L4);
                ddv.visitStartLocal(0,L4,"connectorName","Ljava/lang/String;",null);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(491,L5);
                ddv.visitStartLocal(2,L5,"displayName","Ljava/lang/String;",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(492,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(494,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(487,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(496,L9);
                ddv.visitEndLocal(0,L9);
                ddv.visitEndLocal(2,L9);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","getServer",new String[]{ },"Lorg/mortbay/jetty/Server;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/jetty/Server;","getConnectors",new String[]{ },"[Lorg/mortbay/jetty/Connector;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L2);
                code.visitStmt2R(ARRAY_LENGTH,4,1);
                code.visitJumpStmt(IF_GE,3,4,L9);
                code.visitLabel(L3);
                code.visitStmt3R(AGET_OBJECT,4,1,3);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 4},new Method("Lorg/mortbay/jetty/Connector;","getName",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","getDisplayName",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L5);
                code.visitJumpStmt(IF_NEZ,2,-1,L7);
                code.visitLabel(L6);
                code.visitTypeStmt(NEW_INSTANCE,4,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,5,"WebApp@");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/lang/Object;","hashCode",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "I"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L7);
                code.visitTypeStmt(NEW_INSTANCE,4,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitConstStmt(CONST_STRING,5," at http://");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,0},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","getContextPath",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 4},new Method("Lorg/mortbay/log/Log;","info",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L8);
                code.visitStmt2R1N(ADD_INT_LIT8,3,3,1);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L9);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m015_getConfigurationClasses(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","getConfigurationClasses",new String[]{ },"[Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(543,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_configurationClasses","[Ljava/lang/String;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m016_getConfigurations(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","getConfigurations",new String[]{ },"[Lorg/mortbay/jetty/webapp/Configuration;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(552,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_configurations","[Lorg/mortbay/jetty/webapp/Configuration;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m017_getDefaultsDescriptor(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","getDefaultsDescriptor",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(562,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_defaultsDescriptor","Ljava/lang/String;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m018_getDescriptor(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","getDescriptor",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1021,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_descriptor","Ljava/lang/String;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m019_getExtraClasspath(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","getExtraClasspath",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1182,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_extraClasspath","Ljava/lang/String;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m020_getOverrideDescriptor(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","getOverrideDescriptor",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(572,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_overrideDescriptor","Ljava/lang/String;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m021_getPermissions(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","getPermissions",new String[]{ },"Ljava/security/PermissionCollection;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(581,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_permissions","Ljava/security/PermissionCollection;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m022_getResource(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","getResource",new String[]{ "Ljava/lang/String;"},"Lorg/mortbay/resource/Resource;"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/net/MalformedURLException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(9);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/io/IOException;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"uriInContext");
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(377,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(378,L4);
                ddv.visitStartLocal(1,L4,"ioe","Ljava/io/IOException;",null);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(379,L5);
                ddv.visitStartLocal(4,L5,"resource","Lorg/mortbay/resource/Resource;",null);
                DexLabel L6=new DexLabel();
                ddv.visitStartLocal(2,L6,"loop","I",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(380,L7);
                ddv.visitEndLocal(2,L7);
                ddv.visitStartLocal(3,L7,"loop","I",null);
                DexLabel L8=new DexLabel();
                ddv.visitRestartLocal(2,L8);
                ddv.visitLineNumber(384,L0);
                ddv.visitEndLocal(3,L0);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(385,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(401,L10);
                ddv.visitEndLocal(4,L10);
                ddv.visitStartLocal(5,L10,"resource","Lorg/mortbay/resource/Resource;",null);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(388,L11);
                ddv.visitEndLocal(5,L11);
                ddv.visitRestartLocal(4,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(395,L12);
                ddv.visitRestartLocal(3,L12);
                ddv.visitLineNumber(390,L2);
                ddv.visitEndLocal(3,L2);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(392,L13);
                ddv.visitStartLocal(0,L13,"e","Ljava/io/IOException;",null);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(393,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(394,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(395,L16);
                ddv.visitRestartLocal(3,L16);
                DexLabel L17=new DexLabel();
                ddv.visitEndLocal(2,L17);
                ddv.visitEndLocal(0,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(398,L18);
                ddv.visitEndLocal(3,L18);
                ddv.visitRestartLocal(2,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(399,L19);
                DexLabel L20=new DexLabel();
                ddv.visitEndLocal(1,L20);
                DexLabel L21=new DexLabel();
                ddv.visitRestartLocal(1,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(401,L22);
                ddv.visitRestartLocal(5,L22);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L4);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L5);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L6);
                code.visitStmt2R(MOVE,3,2);
                code.visitLabel(L7);
                code.visitJumpStmt(IF_EQZ,8,-1,L17);
                code.visitStmt2R1N(ADD_INT_LIT8,2,3,1);
                code.visitLabel(L8);
                code.visitConstStmt(CONST_16,6, Integer.valueOf(100)); // int: 0x00000064  float:0.000000
                code.visitJumpStmt(IF_GE,3,6,L18);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 7,8},new Method("Lorg/mortbay/jetty/servlet/Context;","getResource",new String[]{ "Ljava/lang/String;"},"Lorg/mortbay/resource/Resource;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitLabel(L9);
                code.visitJumpStmt(IF_EQZ,4,-1,L11);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/resource/Resource;","exists",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitJumpStmt(IF_EQZ,6,-1,L11);
                code.visitStmt2R(MOVE_OBJECT,5,4);
                code.visitLabel(L10);
                code.visitStmt1R(RETURN_OBJECT,5);
                code.visitLabel(L11);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,8},new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","getResourceAlias",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitLabel(L1);
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitStmt2R(MOVE,3,2);
                code.visitLabel(L12);
                code.visitJumpStmt(GOTO,-1,-1,L7);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,6);
                code.visitStmt2R(MOVE_OBJECT,0,6);
                code.visitLabel(L13);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/log/Log;","ignore",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitLabel(L14);
                DexLabel L23=new DexLabel();
                code.visitJumpStmt(IF_NEZ,1,-1,L23);
                code.visitLabel(L15);
                code.visitStmt2R(MOVE_OBJECT,1,0);
                code.visitLabel(L23);
                code.visitStmt2R(MOVE,3,2);
                code.visitLabel(L16);
                code.visitJumpStmt(GOTO,-1,-1,L7);
                code.visitLabel(L17);
                code.visitStmt2R(MOVE,2,3);
                code.visitLabel(L18);
                code.visitJumpStmt(IF_EQZ,1,-1,L21);
                code.visitTypeStmt(INSTANCE_OF,6,1,"Ljava/net/MalformedURLException;");
                code.visitJumpStmt(IF_EQZ,6,-1,L21);
                code.visitLabel(L19);
                code.visitTypeStmt(CHECK_CAST,1,-1,"Ljava/net/MalformedURLException;");
                code.visitLabel(L20);
                code.visitStmt1R(THROW,1);
                code.visitLabel(L21);
                code.visitStmt2R(MOVE_OBJECT,5,4);
                code.visitLabel(L22);
                code.visitJumpStmt(GOTO,-1,-1,L10);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m023_getResourceAlias(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","getResourceAlias",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"alias");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(350,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(351,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(352,L2);
                ddv.visitEndLocal(1,L2);
                DexLabel L3=new DexLabel();
                ddv.visitRestartLocal(1,L3);
                DexLabel L4=new DexLabel();
                ddv.visitEndLocal(1,L4);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_resourceAliases","Ljava/util/Map;"));
                code.visitJumpStmt(IF_NEZ,0,-1,L3);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L2);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_resourceAliases","Ljava/util/Map;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,2},new Method("Ljava/util/Map;","get",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L4);
                code.visitTypeStmt(CHECK_CAST,1,-1,"Ljava/lang/String;");
                code.visitStmt2R(MOVE_OBJECT,0,1);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m024_getResourceAliases(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","getResourceAliases",new String[]{ },"Ljava/util/Map;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(336,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(337,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(338,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_resourceAliases","Ljava/util/Map;"));
                DexLabel L3=new DexLabel();
                code.visitJumpStmt(IF_NEZ,0,-1,L3);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L2);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_resourceAliases","Ljava/util/Map;"));
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m025_getServerClasses(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","getServerClasses",new String[]{ },"[Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(591,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_serverClasses","[Ljava/lang/String;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m026_getSystemClasses(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","getSystemClasses",new String[]{ },"[Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(601,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_systemClasses","[Ljava/lang/String;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m027_getTempDirectory(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","getTempDirectory",new String[]{ },"Ljava/io/File;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(12);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/lang/Exception;"});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                DexLabel L5=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L5},new String[]{ "Ljava/lang/Exception;"});
                DexLabel L6=new DexLabel();
                DexLabel L7=new DexLabel();
                DexLabel L8=new DexLabel();
                code.visitTryCatch(L6,L7,new DexLabel[]{L8},new String[]{ "Ljava/lang/Exception;"});
                DexLabel L9=new DexLabel();
                DexLabel L10=new DexLabel();
                DexLabel L11=new DexLabel();
                code.visitTryCatch(L9,L10,new DexLabel[]{L11},new String[]{ "Ljava/io/IOException;"});
                DexLabel L12=new DexLabel();
                DexLabel L13=new DexLabel();
                code.visitTryCatch(L12,L13,new DexLabel[]{L5},new String[]{ "Ljava/lang/Exception;"});
                DexLabel L14=new DexLabel();
                DexLabel L15=new DexLabel();
                code.visitTryCatch(L14,L15,new DexLabel[]{L8},new String[]{ "Ljava/lang/Exception;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L16=new DexLabel();
                ddv.visitPrologue(L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(644,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(645,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(765,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(651,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(653,L21);
                ddv.visitStartLocal(3,L21,"t","Ljava/lang/Object;",null);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(655,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(656,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(657,L24);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(660,L25);
                ddv.visitLineNumber(664,L0);
                DexLabel L26=new DexLabel();
                ddv.visitEndLocal(3,L26);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(666,L27);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(668,L28);
                DexLabel L29=new DexLabel();
                ddv.visitLineNumber(669,L29);
                DexLabel L30=new DexLabel();
                ddv.visitLineNumber(670,L30);
                ddv.visitLineNumber(673,L2);
                DexLabel L31=new DexLabel();
                ddv.visitLineNumber(675,L31);
                ddv.visitStartLocal(1,L31,"e","Ljava/lang/Exception;",null);
                DexLabel L32=new DexLabel();
                ddv.visitLineNumber(680,L32);
                ddv.visitEndLocal(1,L32);
                ddv.visitLineNumber(683,L3);
                ddv.visitStartLocal(7,L3,"work","Ljava/io/File;",null);
                DexLabel L33=new DexLabel();
                ddv.visitLineNumber(684,L33);
                ddv.visitStartLocal(5,L33,"w","Ljava/io/File;",null);
                DexLabel L34=new DexLabel();
                ddv.visitLineNumber(685,L34);
                ddv.visitLineNumber(706,L6);
                ddv.visitEndLocal(5,L6);
                DexLabel L35=new DexLabel();
                ddv.visitLineNumber(708,L35);
                ddv.visitStartLocal(4,L35,"temp","Ljava/lang/String;",null);
                DexLabel L36=new DexLabel();
                ddv.visitLineNumber(709,L36);
                DexLabel L37=new DexLabel();
                ddv.visitLineNumber(733,L37);
                DexLabel L38=new DexLabel();
                ddv.visitLineNumber(734,L38);
                DexLabel L39=new DexLabel();
                ddv.visitLineNumber(737,L39);
                DexLabel L40=new DexLabel();
                ddv.visitLineNumber(738,L40);
                DexLabel L41=new DexLabel();
                ddv.visitLineNumber(739,L41);
                ddv.visitLineNumber(747,L7);
                ddv.visitEndLocal(4,L7);
                ddv.visitLineNumber(751,L9);
                DexLabel L42=new DexLabel();
                ddv.visitLineNumber(752,L42);
                DexLabel L43=new DexLabel();
                ddv.visitLineNumber(753,L43);
                DexLabel L44=new DexLabel();
                ddv.visitLineNumber(754,L44);
                DexLabel L45=new DexLabel();
                ddv.visitLineNumber(755,L45);
                DexLabel L46=new DexLabel();
                ddv.visitLineNumber(756,L46);
                ddv.visitLineNumber(764,L10);
                DexLabel L47=new DexLabel();
                ddv.visitLineNumber(765,L47);
                ddv.visitLineNumber(686,L12);
                ddv.visitRestartLocal(5,L12);
                DexLabel L48=new DexLabel();
                ddv.visitLineNumber(688,L48);
                DexLabel L49=new DexLabel();
                ddv.visitLineNumber(689,L49);
                ddv.visitStartLocal(6,L49,"web_inf","Lorg/mortbay/resource/Resource;",null);
                DexLabel L50=new DexLabel();
                ddv.visitLineNumber(691,L50);
                DexLabel L51=new DexLabel();
                ddv.visitEndLocal(5,L51);
                DexLabel L52=new DexLabel();
                ddv.visitLineNumber(692,L52);
                ddv.visitRestartLocal(5,L52);
                DexLabel L53=new DexLabel();
                ddv.visitLineNumber(693,L53);
                ddv.visitLineNumber(697,L5);
                ddv.visitEndLocal(6,L5);
                ddv.visitEndLocal(5,L5);
                DexLabel L54=new DexLabel();
                ddv.visitLineNumber(699,L54);
                ddv.visitRestartLocal(1,L54);
                ddv.visitLineNumber(712,L14);
                ddv.visitEndLocal(1,L14);
                ddv.visitRestartLocal(4,L14);
                DexLabel L55=new DexLabel();
                ddv.visitLineNumber(714,L55);
                DexLabel L56=new DexLabel();
                ddv.visitLineNumber(716,L56);
                DexLabel L57=new DexLabel();
                ddv.visitLineNumber(717,L57);
                DexLabel L58=new DexLabel();
                ddv.visitLineNumber(719,L58);
                DexLabel L59=new DexLabel();
                ddv.visitLineNumber(722,L59);
                DexLabel L60=new DexLabel();
                ddv.visitLineNumber(724,L60);
                DexLabel L61=new DexLabel();
                ddv.visitLineNumber(725,L61);
                ddv.visitStartLocal(2,L61,"old","Ljava/lang/String;",null);
                DexLabel L62=new DexLabel();
                ddv.visitLineNumber(726,L62);
                DexLabel L63=new DexLabel();
                ddv.visitLineNumber(727,L63);
                DexLabel L64=new DexLabel();
                ddv.visitLineNumber(728,L64);
                ddv.visitLineNumber(741,L8);
                ddv.visitEndLocal(4,L8);
                ddv.visitEndLocal(2,L8);
                DexLabel L65=new DexLabel();
                ddv.visitLineNumber(743,L65);
                ddv.visitRestartLocal(1,L65);
                DexLabel L66=new DexLabel();
                ddv.visitLineNumber(744,L66);
                ddv.visitLineNumber(758,L11);
                ddv.visitEndLocal(1,L11);
                DexLabel L67=new DexLabel();
                ddv.visitLineNumber(760,L67);
                ddv.visitStartLocal(1,L67,"e","Ljava/io/IOException;",null);
                code.visitLabel(L16);
                code.visitConstStmt(CONST_STRING,8,"work");
                code.visitConstStmt(CONST_STRING,8,"Created temp dir ");
                code.visitConstStmt(CONST_STRING,8,"");
                code.visitConstStmt(CONST_STRING,10,"javax.servlet.context.tempdir");
                code.visitConstStmt(CONST_STRING,8," for ");
                code.visitLabel(L17);
                code.visitFieldStmt(IGET_OBJECT,8,11,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_tmpDir","Ljava/io/File;"));
                code.visitJumpStmt(IF_EQZ,8,-1,L20);
                code.visitFieldStmt(IGET_OBJECT,8,11,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_tmpDir","Ljava/io/File;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Ljava/io/File;","isDirectory",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitJumpStmt(IF_EQZ,8,-1,L20);
                code.visitFieldStmt(IGET_OBJECT,8,11,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_tmpDir","Ljava/io/File;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Ljava/io/File;","canWrite",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitJumpStmt(IF_EQZ,8,-1,L20);
                code.visitLabel(L18);
                code.visitFieldStmt(IGET_OBJECT,8,11,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_tmpDir","Ljava/io/File;"));
                code.visitLabel(L19);
                code.visitStmt1R(RETURN_OBJECT,8);
                code.visitLabel(L20);
                code.visitConstStmt(CONST_STRING,8,"javax.servlet.context.tempdir");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11,10},new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","getAttribute",new String[]{ "Ljava/lang/String;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitLabel(L21);
                code.visitJumpStmt(IF_EQZ,3,-1,L25);
                code.visitTypeStmt(INSTANCE_OF,8,3,"Ljava/io/File;");
                code.visitJumpStmt(IF_EQZ,8,-1,L25);
                code.visitLabel(L22);
                code.visitStmt2R(MOVE_OBJECT,0,3);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Ljava/io/File;");
                code.visitStmt2R(MOVE_OBJECT,8,0);
                code.visitFieldStmt(IPUT_OBJECT,8,11,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_tmpDir","Ljava/io/File;"));
                code.visitLabel(L23);
                code.visitFieldStmt(IGET_OBJECT,8,11,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_tmpDir","Ljava/io/File;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Ljava/io/File;","isDirectory",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitJumpStmt(IF_EQZ,8,-1,L25);
                code.visitFieldStmt(IGET_OBJECT,8,11,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_tmpDir","Ljava/io/File;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Ljava/io/File;","canWrite",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitJumpStmt(IF_EQZ,8,-1,L25);
                code.visitLabel(L24);
                code.visitFieldStmt(IGET_OBJECT,8,11,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_tmpDir","Ljava/io/File;"));
                code.visitJumpStmt(GOTO,-1,-1,L19);
                code.visitLabel(L25);
                code.visitJumpStmt(IF_EQZ,3,-1,L32);
                code.visitTypeStmt(INSTANCE_OF,8,3,"Ljava/lang/String;");
                code.visitJumpStmt(IF_EQZ,8,-1,L32);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,8,-1,"Ljava/io/File;");
                code.visitTypeStmt(CHECK_CAST,3,-1,"Ljava/lang/String;");
                code.visitLabel(L26);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 8,3},new Method("Ljava/io/File;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitFieldStmt(IPUT_OBJECT,8,11,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_tmpDir","Ljava/io/File;"));
                code.visitLabel(L27);
                code.visitFieldStmt(IGET_OBJECT,8,11,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_tmpDir","Ljava/io/File;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Ljava/io/File;","isDirectory",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitJumpStmt(IF_EQZ,8,-1,L32);
                code.visitFieldStmt(IGET_OBJECT,8,11,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_tmpDir","Ljava/io/File;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Ljava/io/File;","canWrite",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitJumpStmt(IF_EQZ,8,-1,L32);
                code.visitLabel(L28);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/log/Log;","isDebugEnabled",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitJumpStmt(IF_EQZ,8,-1,L29);
                code.visitTypeStmt(NEW_INSTANCE,8,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 8},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,9,"Converted to File ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,9},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitFieldStmt(IGET_OBJECT,9,11,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_tmpDir","Ljava/io/File;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,9},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitConstStmt(CONST_STRING,9," for ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,9},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,11},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 8},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L29);
                code.visitConstStmt(CONST_STRING,8,"javax.servlet.context.tempdir");
                code.visitFieldStmt(IGET_OBJECT,9,11,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_tmpDir","Ljava/io/File;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11,8,9},new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","setAttribute",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L30);
                code.visitFieldStmt(IGET_OBJECT,8,11,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_tmpDir","Ljava/io/File;"));
                code.visitLabel(L1);
                code.visitJumpStmt(GOTO,-1,-1,L19);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,8);
                code.visitStmt2R(MOVE_OBJECT,1,8);
                code.visitLabel(L31);
                code.visitConstStmt(CONST_STRING,8,"EXCEPTION ");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 8,1},new Method("Lorg/mortbay/log/Log;","warn",new String[]{ "Ljava/lang/String;","Ljava/lang/Throwable;"},"V"));
                code.visitLabel(L32);
                code.visitConstStmt(CONST_4,7, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L3);
                code.visitTypeStmt(NEW_INSTANCE,5,-1,"Ljava/io/File;");
                code.visitConstStmt(CONST_STRING,8,"jetty.home");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 8},new Method("Ljava/lang/System;","getProperty",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitConstStmt(CONST_STRING,9,"work");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 5,8,9},new Method("Ljava/io/File;","<init>",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"V"));
                code.visitLabel(L33);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/io/File;","exists",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitJumpStmt(IF_EQZ,8,-1,L12);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/io/File;","canWrite",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitJumpStmt(IF_EQZ,8,-1,L12);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/io/File;","isDirectory",new String[]{ },"Z"));
                code.visitLabel(L4);
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitJumpStmt(IF_EQZ,8,-1,L12);
                code.visitLabel(L34);
                code.visitStmt2R(MOVE_OBJECT,7,5);
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 11},new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","getCanonicalNameForWebAppTmpDir",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitLabel(L35);
                code.visitJumpStmt(IF_EQZ,7,-1,L14);
                code.visitLabel(L36);
                code.visitTypeStmt(NEW_INSTANCE,8,-1,"Ljava/io/File;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 8,7,4},new Method("Ljava/io/File;","<init>",new String[]{ "Ljava/io/File;","Ljava/lang/String;"},"V"));
                code.visitFieldStmt(IPUT_OBJECT,8,11,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_tmpDir","Ljava/io/File;"));
                code.visitLabel(L37);
                code.visitFieldStmt(IGET_OBJECT,8,11,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_tmpDir","Ljava/io/File;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Ljava/io/File;","exists",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitJumpStmt(IF_NEZ,8,-1,L39);
                code.visitLabel(L38);
                code.visitFieldStmt(IGET_OBJECT,8,11,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_tmpDir","Ljava/io/File;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Ljava/io/File;","mkdir",new String[]{ },"Z"));
                code.visitLabel(L39);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11},new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","isTempWorkDirectory",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitJumpStmt(IF_NEZ,8,-1,L41);
                code.visitLabel(L40);
                code.visitFieldStmt(IGET_OBJECT,8,11,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_tmpDir","Ljava/io/File;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Ljava/io/File;","deleteOnExit",new String[]{ },"V"));
                code.visitLabel(L41);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/log/Log;","isDebugEnabled",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitJumpStmt(IF_EQZ,8,-1,L7);
                code.visitTypeStmt(NEW_INSTANCE,8,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 8},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,9,"Created temp dir ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,9},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitFieldStmt(IGET_OBJECT,9,11,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_tmpDir","Ljava/io/File;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,9},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitConstStmt(CONST_STRING,9," for ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,9},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,11},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 8},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L7);
                code.visitFieldStmt(IGET_OBJECT,8,11,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_tmpDir","Ljava/io/File;"));
                code.visitJumpStmt(IF_NEZ,8,-1,L10);
                code.visitLabel(L9);
                code.visitConstStmt(CONST_STRING,8,"JettyContext");
                code.visitConstStmt(CONST_STRING,9,"");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 8,9},new Method("Ljava/io/File;","createTempFile",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"Ljava/io/File;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitFieldStmt(IPUT_OBJECT,8,11,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_tmpDir","Ljava/io/File;"));
                code.visitLabel(L42);
                code.visitFieldStmt(IGET_OBJECT,8,11,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_tmpDir","Ljava/io/File;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Ljava/io/File;","exists",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitJumpStmt(IF_EQZ,8,-1,L44);
                code.visitLabel(L43);
                code.visitFieldStmt(IGET_OBJECT,8,11,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_tmpDir","Ljava/io/File;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Ljava/io/File;","delete",new String[]{ },"Z"));
                code.visitLabel(L44);
                code.visitFieldStmt(IGET_OBJECT,8,11,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_tmpDir","Ljava/io/File;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Ljava/io/File;","mkdir",new String[]{ },"Z"));
                code.visitLabel(L45);
                code.visitFieldStmt(IGET_OBJECT,8,11,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_tmpDir","Ljava/io/File;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Ljava/io/File;","deleteOnExit",new String[]{ },"V"));
                code.visitLabel(L46);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/log/Log;","isDebugEnabled",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitJumpStmt(IF_EQZ,8,-1,L10);
                code.visitTypeStmt(NEW_INSTANCE,8,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 8},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,9,"Created temp dir ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,9},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitFieldStmt(IGET_OBJECT,9,11,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_tmpDir","Ljava/io/File;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,9},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitConstStmt(CONST_STRING,9," for ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,9},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,11},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 8},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L10);
                code.visitConstStmt(CONST_STRING,8,"javax.servlet.context.tempdir");
                code.visitFieldStmt(IGET_OBJECT,8,11,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_tmpDir","Ljava/io/File;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11,10,8},new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","setAttribute",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L47);
                code.visitFieldStmt(IGET_OBJECT,8,11,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_tmpDir","Ljava/io/File;"));
                code.visitJumpStmt(GOTO_16,-1,-1,L19);
                code.visitLabel(L12);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11},new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","getBaseResource",new String[]{ },"Lorg/mortbay/resource/Resource;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitJumpStmt(IF_EQZ,8,-1,L6);
                code.visitLabel(L48);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11},new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","getWebInf",new String[]{ },"Lorg/mortbay/resource/Resource;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitLabel(L49);
                code.visitJumpStmt(IF_EQZ,6,-1,L6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/resource/Resource;","exists",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitJumpStmt(IF_EQZ,8,-1,L6);
                code.visitLabel(L50);
                code.visitTypeStmt(NEW_INSTANCE,5,-1,"Ljava/io/File;");
                code.visitLabel(L51);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/resource/Resource;","getFile",new String[]{ },"Ljava/io/File;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitConstStmt(CONST_STRING,9,"work");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 5,8,9},new Method("Ljava/io/File;","<init>",new String[]{ "Ljava/io/File;","Ljava/lang/String;"},"V"));
                code.visitLabel(L52);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/io/File;","exists",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitJumpStmt(IF_EQZ,8,-1,L6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/io/File;","canWrite",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitJumpStmt(IF_EQZ,8,-1,L6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/io/File;","isDirectory",new String[]{ },"Z"));
                code.visitLabel(L13);
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitJumpStmt(IF_EQZ,8,-1,L6);
                code.visitLabel(L53);
                code.visitStmt2R(MOVE_OBJECT,7,5);
                code.visitJumpStmt(GOTO_16,-1,-1,L6);
                code.visitLabel(L5);
                code.visitStmt1R(MOVE_EXCEPTION,8);
                code.visitStmt2R(MOVE_OBJECT,1,8);
                code.visitLabel(L54);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1},new Method("Lorg/mortbay/log/Log;","ignore",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitJumpStmt(GOTO_16,-1,-1,L6);
                code.visitLabel(L14);
                code.visitTypeStmt(NEW_INSTANCE,8,-1,"Ljava/io/File;");
                code.visitConstStmt(CONST_STRING,9,"java.io.tmpdir");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 9},new Method("Ljava/lang/System;","getProperty",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 8,9,4},new Method("Ljava/io/File;","<init>",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"V"));
                code.visitFieldStmt(IPUT_OBJECT,8,11,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_tmpDir","Ljava/io/File;"));
                code.visitLabel(L55);
                code.visitFieldStmt(IGET_OBJECT,8,11,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_tmpDir","Ljava/io/File;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Ljava/io/File;","exists",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitJumpStmt(IF_EQZ,8,-1,L37);
                code.visitLabel(L56);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/log/Log;","isDebugEnabled",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitJumpStmt(IF_EQZ,8,-1,L57);
                code.visitTypeStmt(NEW_INSTANCE,8,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 8},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,9,"Delete existing temp dir ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,9},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitFieldStmt(IGET_OBJECT,9,11,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_tmpDir","Ljava/io/File;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,9},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitConstStmt(CONST_STRING,9," for ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,9},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,11},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 8},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L57);
                code.visitFieldStmt(IGET_OBJECT,8,11,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_tmpDir","Ljava/io/File;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 8},new Method("Lorg/mortbay/util/IO;","delete",new String[]{ "Ljava/io/File;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitJumpStmt(IF_NEZ,8,-1,L59);
                code.visitLabel(L58);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/log/Log;","isDebugEnabled",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitJumpStmt(IF_EQZ,8,-1,L59);
                code.visitTypeStmt(NEW_INSTANCE,8,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 8},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,9,"Failed to delete temp dir ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,9},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitFieldStmt(IGET_OBJECT,9,11,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_tmpDir","Ljava/io/File;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,9},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 8},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L59);
                code.visitFieldStmt(IGET_OBJECT,8,11,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_tmpDir","Ljava/io/File;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Ljava/io/File;","exists",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitJumpStmt(IF_EQZ,8,-1,L37);
                code.visitLabel(L60);
                code.visitFieldStmt(IGET_OBJECT,8,11,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_tmpDir","Ljava/io/File;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Ljava/io/File;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L61);
                code.visitTypeStmt(NEW_INSTANCE,8,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 8},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitConstStmt(CONST_STRING,9,"_");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,9},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitConstStmt(CONST_STRING,9,"");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 8,9},new Method("Ljava/io/File;","createTempFile",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"Ljava/io/File;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitFieldStmt(IPUT_OBJECT,8,11,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_tmpDir","Ljava/io/File;"));
                code.visitLabel(L62);
                code.visitFieldStmt(IGET_OBJECT,8,11,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_tmpDir","Ljava/io/File;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Ljava/io/File;","exists",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitJumpStmt(IF_EQZ,8,-1,L64);
                code.visitLabel(L63);
                code.visitFieldStmt(IGET_OBJECT,8,11,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_tmpDir","Ljava/io/File;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Ljava/io/File;","delete",new String[]{ },"Z"));
                code.visitLabel(L64);
                code.visitTypeStmt(NEW_INSTANCE,8,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 8},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,9,"Can\'t reuse ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,9},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitConstStmt(CONST_STRING,9,", using ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,9},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitFieldStmt(IGET_OBJECT,9,11,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_tmpDir","Ljava/io/File;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,9},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 8},new Method("Lorg/mortbay/log/Log;","warn",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L15);
                code.visitJumpStmt(GOTO_16,-1,-1,L37);
                code.visitLabel(L8);
                code.visitStmt1R(MOVE_EXCEPTION,8);
                code.visitStmt2R(MOVE_OBJECT,1,8);
                code.visitLabel(L65);
                code.visitConstStmt(CONST_4,8, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_OBJECT,8,11,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_tmpDir","Ljava/io/File;"));
                code.visitLabel(L66);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1},new Method("Lorg/mortbay/log/Log;","ignore",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitJumpStmt(GOTO_16,-1,-1,L7);
                code.visitLabel(L11);
                code.visitStmt1R(MOVE_EXCEPTION,8);
                code.visitStmt2R(MOVE_OBJECT,1,8);
                code.visitLabel(L67);
                code.visitConstStmt(CONST_STRING,8,"tmpdir");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 8,1},new Method("Lorg/mortbay/log/Log;","warn",new String[]{ "Ljava/lang/String;","Ljava/lang/Throwable;"},"V"));
                code.visitConstStmt(CONST_4,8, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 8},new Method("Ljava/lang/System;","exit",new String[]{ "I"},"V"));
                code.visitJumpStmt(GOTO_16,-1,-1,L10);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m028_getUnavailableException(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","getUnavailableException",new String[]{ },"Ljava/lang/Throwable;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(314,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_unavailableException","Ljava/lang/Throwable;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m029_getWar(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","getWar",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(791,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(792,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(793,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_war","Ljava/lang/String;"));
                code.visitJumpStmt(IF_NEZ,0,-1,L2);
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","getResourceBase",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_war","Ljava/lang/String;"));
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_war","Ljava/lang/String;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m030_getWebInf(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","getWebInf",new String[]{ },"Lorg/mortbay/resource/Resource;"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(799,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(802,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(803,L2);
                ddv.visitStartLocal(0,L2,"web_inf","Lorg/mortbay/resource/Resource;",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(804,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(806,L4);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","resolveWebApp",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 3},new Method("Lorg/mortbay/jetty/servlet/Context;","getBaseResource",new String[]{ },"Lorg/mortbay/resource/Resource;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitConstStmt(CONST_STRING,2,"WEB-INF/");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Lorg/mortbay/resource/Resource;","addPath",new String[]{ "Ljava/lang/String;"},"Lorg/mortbay/resource/Resource;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/resource/Resource;","exists",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_EQZ,1,-1,L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/resource/Resource;","isDirectory",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,1);
                DexLabel L5=new DexLabel();
                code.visitJumpStmt(IF_NEZ,1,-1,L5);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L4);
                code.visitStmt1R(RETURN_OBJECT,1);
                code.visitLabel(L5);
                code.visitStmt2R(MOVE_OBJECT,1,0);
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m031_handle(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","handle",new String[]{ "Ljava/lang/String;","Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;","I"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visit(null, new DexType("Ljavax/servlet/ServletException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"target");
                ddv.visitParameterName(1,"request");
                ddv.visitParameterName(2,"response");
                ddv.visitParameterName(3,"dispatch");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(412,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(414,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(418,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(417,L3);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_BOOLEAN,0,1,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_unavailable","Z"));
                code.visitJumpStmt(IF_EQZ,0,-1,L3);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_16,0, Integer.valueOf(503)); // int: 0x000001f7  float:0.000000
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 4,0},new Method("Ljavax/servlet/http/HttpServletResponse;","sendError",new String[]{ "I"},"V"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 1,2,3,4,5},new Method("Lorg/mortbay/jetty/servlet/Context;","handle",new String[]{ "Ljava/lang/String;","Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;","I"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m032_isCopyWebDir(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","isCopyWebDir",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(833,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_BOOLEAN,0,1,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_copyDir","Z"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m033_isDistributable(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","isDistributable",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(815,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_BOOLEAN,0,1,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_distributable","Z"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m034_isExtractWAR(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","isExtractWAR",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(824,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_BOOLEAN,0,1,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_extractWAR","Z"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m035_isLogUrlOnStart(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","isLogUrlOnStart",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1199,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_BOOLEAN,0,1,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_logUrlOnStart","Z"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m036_isParentLoaderPriority(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","isParentLoaderPriority",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(842,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_BOOLEAN,0,1,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_parentLoaderPriority","Z"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m037_isProtectedTarget(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","isProtectedTarget",new String[]{ "Ljava/lang/String;"},"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"target");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(864,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(865,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(867,L2);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_STRING,0,"//");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,0},new Method("Ljava/lang/String;","startsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L2);
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2},new Method("Lorg/mortbay/util/URIUtil;","compactPath",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitJumpStmt(GOTO,-1,-1,L0);
                code.visitLabel(L2);
                code.visitConstStmt(CONST_STRING,0,"/web-inf");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2,0},new Method("Lorg/mortbay/util/StringUtil;","startsWithIgnoreCase",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                DexLabel L3=new DexLabel();
                code.visitJumpStmt(IF_NEZ,0,-1,L3);
                code.visitConstStmt(CONST_STRING,0,"/meta-inf");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2,0},new Method("Lorg/mortbay/util/StringUtil;","startsWithIgnoreCase",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                DexLabel L4=new DexLabel();
                code.visitJumpStmt(IF_EQZ,0,-1,L4);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                DexLabel L5=new DexLabel();
                code.visitLabel(L5);
                code.visitStmt1R(RETURN,0);
                code.visitLabel(L4);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m038_isTempWorkDirectory(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","isTempWorkDirectory",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(775,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(782,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(777,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(778,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(779,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(780,L6);
                ddv.visitStartLocal(0,L6,"t","Ljava/io/File;",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(781,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(782,L8);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitConstStmt(CONST_STRING,4,"work");
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,1,5,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_tmpDir","Ljava/io/File;"));
                code.visitJumpStmt(IF_NEZ,1,-1,L3);
                code.visitStmt2R(MOVE,1,3);
                code.visitLabel(L2);
                code.visitStmt1R(RETURN,1);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,1,5,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_tmpDir","Ljava/io/File;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/io/File;","getName",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitConstStmt(CONST_STRING,2,"work");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,4},new Method("Ljava/lang/String;","equalsIgnoreCase",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_EQZ,1,-1,L5);
                code.visitLabel(L4);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,1,5,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_tmpDir","Ljava/io/File;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/io/File;","getParentFile",new String[]{ },"Ljava/io/File;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L6);
                code.visitJumpStmt(IF_NEZ,0,-1,L8);
                code.visitStmt2R(MOVE,1,3);
                code.visitLabel(L7);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/io/File;","getName",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitConstStmt(CONST_STRING,2,"work");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,4},new Method("Ljava/lang/String;","equalsIgnoreCase",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m039_loadConfigurations(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","loadConfigurations",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/Exception;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(849,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(859,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(851,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(852,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(854,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(855,L5);
                DexLabel L6=new DexLabel();
                ddv.visitStartLocal(0,L6,"i","I",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(857,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(855,L8);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_configurations","[Lorg/mortbay/jetty/webapp/Configuration;"));
                code.visitJumpStmt(IF_EQZ,1,-1,L2);
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_configurationClasses","[Ljava/lang/String;"));
                code.visitJumpStmt(IF_NEZ,1,-1,L4);
                code.visitLabel(L3);
                code.visitFieldStmt(SGET_OBJECT,1,-1,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","__dftConfigurationClasses","[Ljava/lang/String;"));
                code.visitFieldStmt(IPUT_OBJECT,1,4,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_configurationClasses","[Ljava/lang/String;"));
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_configurationClasses","[Ljava/lang/String;"));
                code.visitStmt2R(ARRAY_LENGTH,1,1);
                code.visitTypeStmt(NEW_ARRAY,1,1,"[Lorg/mortbay/jetty/webapp/Configuration;");
                code.visitFieldStmt(IPUT_OBJECT,1,4,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_configurations","[Lorg/mortbay/jetty/webapp/Configuration;"));
                code.visitLabel(L5);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_configurations","[Lorg/mortbay/jetty/webapp/Configuration;"));
                code.visitStmt2R(ARRAY_LENGTH,1,1);
                code.visitJumpStmt(IF_GE,0,1,L1);
                code.visitLabel(L7);
                code.visitFieldStmt(IGET_OBJECT,2,4,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_configurations","[Lorg/mortbay/jetty/webapp/Configuration;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/lang/Object;","getClass",new String[]{ },"Ljava/lang/Class;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitFieldStmt(IGET_OBJECT,3,4,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_configurationClasses","[Ljava/lang/String;"));
                code.visitStmt3R(AGET_OBJECT,3,3,0);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1,3},new Method("Lorg/mortbay/util/Loader;","loadClass",new String[]{ "Ljava/lang/Class;","Ljava/lang/String;"},"Ljava/lang/Class;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/lang/Class;","newInstance",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitTypeStmt(CHECK_CAST,1,-1,"Lorg/mortbay/jetty/webapp/Configuration;");
                code.visitStmt3R(APUT_OBJECT,1,2,0);
                code.visitLabel(L8);
                code.visitStmt2R1N(ADD_INT_LIT8,0,0,1);
                code.visitJumpStmt(GOTO,-1,-1,L6);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m040_removeResourceAlias(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","removeResourceAlias",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"alias");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(358,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(359,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(360,L2);
                ddv.visitEndLocal(1,L2);
                DexLabel L3=new DexLabel();
                ddv.visitRestartLocal(1,L3);
                DexLabel L4=new DexLabel();
                ddv.visitEndLocal(1,L4);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_resourceAliases","Ljava/util/Map;"));
                code.visitJumpStmt(IF_NEZ,0,-1,L3);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L2);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_resourceAliases","Ljava/util/Map;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,2},new Method("Ljava/util/Map;","remove",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L4);
                code.visitTypeStmt(CHECK_CAST,1,-1,"Ljava/lang/String;");
                code.visitStmt2R(MOVE_OBJECT,0,1);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m041_resolveWebApp(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","resolveWebApp",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(11);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(884,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(885,L2);
                ddv.visitStartLocal(2,L2,"web_app","Lorg/mortbay/resource/Resource;",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(887,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(888,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(891,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(894,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(896,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(897,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(900,L9);
                ddv.visitRestartLocal(2,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(901,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(904,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(907,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(908,L13);
                ddv.visitStartLocal(1,L13,"jarWebApp","Lorg/mortbay/resource/Resource;",null);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(910,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(915,L15);
                ddv.visitEndLocal(1,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(926,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(928,L17);
                ddv.visitStartLocal(0,L17,"extractedWebAppDir","Ljava/io/File;",null);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(931,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(932,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(956,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(961,L21);
                ddv.visitEndLocal(0,L21);
                ddv.visitRestartLocal(2,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(963,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(964,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(936,L24);
                ddv.visitRestartLocal(0,L24);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(939,L25);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(940,L26);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(941,L27);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(946,L28);
                DexLabel L29=new DexLabel();
                ddv.visitLineNumber(948,L29);
                DexLabel L30=new DexLabel();
                ddv.visitLineNumber(949,L30);
                DexLabel L31=new DexLabel();
                ddv.visitLineNumber(950,L31);
                DexLabel L32=new DexLabel();
                ddv.visitLineNumber(951,L32);
                DexLabel L33=new DexLabel();
                ddv.visitLineNumber(967,L33);
                ddv.visitEndLocal(0,L33);
                DexLabel L34=new DexLabel();
                ddv.visitLineNumber(968,L34);
                DexLabel L35=new DexLabel();
                ddv.visitLineNumber(971,L35);
                DexLabel L36=new DexLabel();
                ddv.visitLineNumber(973,L36);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,8, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitConstStmt(CONST_STRING,5,"jar:");
                code.visitConstStmt(CONST_STRING,9,"Extract ");
                code.visitConstStmt(CONST_STRING,7," to ");
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 10},new Method("Lorg/mortbay/jetty/servlet/Context;","getBaseResource",new String[]{ },"Lorg/mortbay/resource/Resource;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L2);
                code.visitJumpStmt(IF_NEZ,2,-1,L36);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,3,10,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_war","Ljava/lang/String;"));
                code.visitJumpStmt(IF_EQZ,3,-1,L4);
                code.visitFieldStmt(IGET_OBJECT,3,10,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_war","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_NEZ,3,-1,L5);
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","getResourceBase",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitFieldStmt(IPUT_OBJECT,3,10,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_war","Ljava/lang/String;"));
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,3,10,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_war","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3},new Method("Lorg/mortbay/resource/Resource;","newResource",new String[]{ "Ljava/lang/String;"},"Lorg/mortbay/resource/Resource;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/resource/Resource;","getAlias",new String[]{ },"Ljava/net/URL;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitJumpStmt(IF_EQZ,3,-1,L9);
                code.visitLabel(L7);
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitConstStmt(CONST_STRING,4," anti-aliased to ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/resource/Resource;","getAlias",new String[]{ },"Ljava/net/URL;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/resource/Resource;","getAlias",new String[]{ },"Ljava/net/URL;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3},new Method("Lorg/mortbay/resource/Resource;","newResource",new String[]{ "Ljava/net/URL;"},"Lorg/mortbay/resource/Resource;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/log/Log;","isDebugEnabled",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_EQZ,3,-1,L11);
                code.visitLabel(L10);
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,4,"Try webapp=");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitConstStmt(CONST_STRING,4,", exists=");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/resource/Resource;","exists",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Z"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitConstStmt(CONST_STRING,4,", directory=");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/resource/Resource;","isDirectory",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Z"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L11);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/resource/Resource;","exists",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_EQZ,3,-1,L15);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/resource/Resource;","isDirectory",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_NEZ,3,-1,L15);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/lang/Object;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitConstStmt(CONST_STRING,4,"jar:");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,5},new Method("Ljava/lang/String;","startsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_NEZ,3,-1,L15);
                code.visitLabel(L12);
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,4,"jar:");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitConstStmt(CONST_STRING,4,"!/");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3},new Method("Lorg/mortbay/resource/Resource;","newResource",new String[]{ "Ljava/lang/String;"},"Lorg/mortbay/resource/Resource;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L13);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/resource/Resource;","exists",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_EQZ,3,-1,L15);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/resource/Resource;","isDirectory",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_EQZ,3,-1,L15);
                code.visitLabel(L14);
                code.visitStmt2R(MOVE_OBJECT,2,1);
                code.visitLabel(L15);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/resource/Resource;","exists",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_EQZ,3,-1,L21);
                code.visitFieldStmt(IGET_BOOLEAN,3,10,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_copyDir","Z"));
                DexLabel L37=new DexLabel();
                code.visitJumpStmt(IF_EQZ,3,-1,L37);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/resource/Resource;","getFile",new String[]{ },"Ljava/io/File;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitJumpStmt(IF_EQZ,3,-1,L37);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/resource/Resource;","getFile",new String[]{ },"Ljava/io/File;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/io/File;","isDirectory",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_NEZ,3,-1,L16);
                code.visitLabel(L37);
                code.visitFieldStmt(IGET_BOOLEAN,3,10,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_extractWAR","Z"));
                DexLabel L38=new DexLabel();
                code.visitJumpStmt(IF_EQZ,3,-1,L38);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/resource/Resource;","getFile",new String[]{ },"Ljava/io/File;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitJumpStmt(IF_EQZ,3,-1,L38);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/resource/Resource;","getFile",new String[]{ },"Ljava/io/File;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/io/File;","isDirectory",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_EQZ,3,-1,L16);
                code.visitLabel(L38);
                code.visitFieldStmt(IGET_BOOLEAN,3,10,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_extractWAR","Z"));
                DexLabel L39=new DexLabel();
                code.visitJumpStmt(IF_EQZ,3,-1,L39);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/resource/Resource;","getFile",new String[]{ },"Ljava/io/File;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitJumpStmt(IF_EQZ,3,-1,L16);
                code.visitLabel(L39);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/resource/Resource;","isDirectory",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_NEZ,3,-1,L21);
                code.visitLabel(L16);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/io/File;");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","getTempDirectory",new String[]{ },"Ljava/io/File;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitConstStmt(CONST_STRING,4,"webapp");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,3,4},new Method("Ljava/io/File;","<init>",new String[]{ "Ljava/io/File;","Ljava/lang/String;"},"V"));
                code.visitLabel(L17);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/resource/Resource;","getFile",new String[]{ },"Ljava/io/File;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitJumpStmt(IF_EQZ,3,-1,L24);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/resource/Resource;","getFile",new String[]{ },"Ljava/io/File;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/io/File;","isDirectory",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_EQZ,3,-1,L24);
                code.visitLabel(L18);
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,4,"Copy ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/resource/Resource;","getFile",new String[]{ },"Ljava/io/File;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitConstStmt(CONST_STRING,4," to ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,7},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,0},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3},new Method("Lorg/mortbay/log/Log;","info",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L19);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/resource/Resource;","getFile",new String[]{ },"Ljava/io/File;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3,0},new Method("Lorg/mortbay/util/IO;","copyDir",new String[]{ "Ljava/io/File;","Ljava/io/File;"},"V"));
                code.visitLabel(L20);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/io/File;","getCanonicalPath",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3},new Method("Lorg/mortbay/resource/Resource;","newResource",new String[]{ "Ljava/lang/String;"},"Lorg/mortbay/resource/Resource;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L21);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/resource/Resource;","exists",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_EQZ,3,-1,L22);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/resource/Resource;","isDirectory",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_NEZ,3,-1,L33);
                code.visitLabel(L22);
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,4,"Web application not found ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitFieldStmt(IGET_OBJECT,4,10,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_war","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3},new Method("Lorg/mortbay/log/Log;","warn",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L23);
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Ljava/io/FileNotFoundException;");
                code.visitFieldStmt(IGET_OBJECT,4,10,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_war","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3,4},new Method("Ljava/io/FileNotFoundException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,3);
                code.visitLabel(L24);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/io/File;","exists",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_NEZ,3,-1,L28);
                code.visitLabel(L25);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/io/File;","mkdir",new String[]{ },"Z"));
                code.visitLabel(L26);
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,4,"Extract ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,9},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitFieldStmt(IGET_OBJECT,4,10,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_war","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitConstStmt(CONST_STRING,4," to ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,7},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,0},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3},new Method("Lorg/mortbay/log/Log;","info",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L27);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2,0,8},new Method("Lorg/mortbay/resource/JarResource;","extract",new String[]{ "Lorg/mortbay/resource/Resource;","Ljava/io/File;","Z"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L20);
                code.visitLabel(L28);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/resource/Resource;","lastModified",new String[]{ },"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/io/File;","lastModified",new String[]{ },"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,5);
                code.visitStmt3R(CMP_LONG,3,3,5);
                code.visitJumpStmt(IF_LEZ,3,-1,L20);
                code.visitLabel(L29);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/io/File;","delete",new String[]{ },"Z"));
                code.visitLabel(L30);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/io/File;","mkdir",new String[]{ },"Z"));
                code.visitLabel(L31);
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,4,"Extract ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,9},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitFieldStmt(IGET_OBJECT,4,10,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_war","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitConstStmt(CONST_STRING,4," to ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,7},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,0},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3},new Method("Lorg/mortbay/log/Log;","info",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L32);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2,0,8},new Method("Lorg/mortbay/resource/JarResource;","extract",new String[]{ "Lorg/mortbay/resource/Resource;","Ljava/io/File;","Z"},"V"));
                code.visitJumpStmt(GOTO_16,-1,-1,L20);
                code.visitLabel(L33);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/log/Log;","isDebugEnabled",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_EQZ,3,-1,L35);
                code.visitLabel(L34);
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,4,"webapp=");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L35);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 10,2},new Method("Lorg/mortbay/jetty/servlet/Context;","setBaseResource",new String[]{ "Lorg/mortbay/resource/Resource;"},"V"));
                code.visitLabel(L36);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m042_setClassLoader(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","setClassLoader",new String[]{ "Ljava/lang/ClassLoader;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"classLoader");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(369,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(370,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(371,L2);
                DexLabel L3=new DexLabel();
                ddv.visitEndLocal(2,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(372,L4);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 1,2},new Method("Lorg/mortbay/jetty/servlet/Context;","setClassLoader",new String[]{ "Ljava/lang/ClassLoader;"},"V"));
                code.visitLabel(L1);
                code.visitJumpStmt(IF_EQZ,2,-1,L4);
                code.visitTypeStmt(INSTANCE_OF,0,2,"Lorg/mortbay/jetty/webapp/WebAppClassLoader;");
                code.visitJumpStmt(IF_EQZ,0,-1,L4);
                code.visitLabel(L2);
                code.visitTypeStmt(CHECK_CAST,2,-1,"Lorg/mortbay/jetty/webapp/WebAppClassLoader;");
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","getDisplayName",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,0},new Method("Lorg/mortbay/jetty/webapp/WebAppClassLoader;","setName",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L4);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m043_setConfigurationClasses(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","setConfigurationClasses",new String[]{ "[Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"configurations");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(983,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(984,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(983,L2);
                code.visitLabel(L0);
                code.visitJumpStmt(IF_NEZ,2,-1,L2);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                DexLabel L3=new DexLabel();
                code.visitLabel(L3);
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_configurationClasses","[Ljava/lang/String;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("[Ljava/lang/String;","clone",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitTypeStmt(CHECK_CAST,0,-1,"[Ljava/lang/String;");
                code.visitTypeStmt(CHECK_CAST,0,-1,"[Ljava/lang/String;");
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m044_setConfigurations(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","setConfigurations",new String[]{ "[Lorg/mortbay/jetty/webapp/Configuration;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"configurations");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(992,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(993,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(992,L2);
                code.visitLabel(L0);
                code.visitJumpStmt(IF_NEZ,2,-1,L2);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                DexLabel L3=new DexLabel();
                code.visitLabel(L3);
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_configurations","[Lorg/mortbay/jetty/webapp/Configuration;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("[Lorg/mortbay/jetty/webapp/Configuration;","clone",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitTypeStmt(CHECK_CAST,0,-1,"[Lorg/mortbay/jetty/webapp/Configuration;");
                code.visitTypeStmt(CHECK_CAST,0,-1,"[Lorg/mortbay/jetty/webapp/Configuration;");
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m045_setCopyWebDir(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","setCopyWebDir",new String[]{ "Z"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"copy");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1093,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(1094,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_BOOLEAN,1,0,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_copyDir","Z"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m046_setDefaultsDescriptor(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","setDefaultsDescriptor",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"defaultsDescriptor");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1002,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(1003,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_defaultsDescriptor","Ljava/lang/String;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m047_setDescriptor(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","setDescriptor",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"descriptor");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1030,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(1031,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_descriptor","Ljava/lang/String;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m048_setDistributable(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","setDistributable",new String[]{ "Z"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"distributable");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1039,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(1040,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_BOOLEAN,1,0,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_distributable","Z"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m049_setEventListeners(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","setEventListeners",new String[]{ "[Ljava/util/EventListener;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"eventListeners");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1045,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(1046,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(1048,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(1050,L3);
                DexLabel L4=new DexLabel();
                ddv.visitStartLocal(0,L4,"i","I",null);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(1052,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(1054,L6);
                ddv.visitStartLocal(1,L6,"listener","Ljava/util/EventListener;",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(1059,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(1060,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(1050,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(1064,L10);
                ddv.visitEndLocal(1,L10);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,2,3,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_sessionHandler","Lorg/mortbay/jetty/servlet/SessionHandler;"));
                code.visitJumpStmt(IF_EQZ,2,-1,L2);
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,2,3,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_sessionHandler","Lorg/mortbay/jetty/servlet/SessionHandler;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/servlet/SessionHandler;","clearEventListeners",new String[]{ },"V"));
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 3,4},new Method("Lorg/mortbay/jetty/servlet/Context;","setEventListeners",new String[]{ "[Ljava/util/EventListener;"},"V"));
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L4);
                code.visitJumpStmt(IF_EQZ,4,-1,L10);
                code.visitStmt2R(ARRAY_LENGTH,2,4);
                code.visitJumpStmt(IF_GE,0,2,L10);
                code.visitLabel(L5);
                code.visitStmt3R(AGET_OBJECT,1,4,0);
                code.visitLabel(L6);
                code.visitTypeStmt(INSTANCE_OF,2,1,"Ljavax/servlet/http/HttpSessionActivationListener;");
                code.visitJumpStmt(IF_NEZ,2,-1,L7);
                code.visitTypeStmt(INSTANCE_OF,2,1,"Ljavax/servlet/http/HttpSessionAttributeListener;");
                code.visitJumpStmt(IF_NEZ,2,-1,L7);
                code.visitTypeStmt(INSTANCE_OF,2,1,"Ljavax/servlet/http/HttpSessionBindingListener;");
                code.visitJumpStmt(IF_NEZ,2,-1,L7);
                code.visitTypeStmt(INSTANCE_OF,2,1,"Ljavax/servlet/http/HttpSessionListener;");
                code.visitJumpStmt(IF_EQZ,2,-1,L9);
                code.visitLabel(L7);
                code.visitFieldStmt(IGET_OBJECT,2,3,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_sessionHandler","Lorg/mortbay/jetty/servlet/SessionHandler;"));
                code.visitJumpStmt(IF_EQZ,2,-1,L9);
                code.visitLabel(L8);
                code.visitFieldStmt(IGET_OBJECT,2,3,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_sessionHandler","Lorg/mortbay/jetty/servlet/SessionHandler;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,1},new Method("Lorg/mortbay/jetty/servlet/SessionHandler;","addEventListener",new String[]{ "Ljava/util/EventListener;"},"V"));
                code.visitLabel(L9);
                code.visitStmt2R1N(ADD_INT_LIT8,0,0,1);
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitLabel(L10);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m050_setExtraClasspath(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","setExtraClasspath",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"extraClasspath");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1193,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(1194,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_extraClasspath","Ljava/lang/String;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m051_setExtractWAR(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","setExtractWAR",new String[]{ "Z"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"extractWAR");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1083,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(1084,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_BOOLEAN,1,0,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_extractWAR","Z"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m052_setLogUrlOnStart(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","setLogUrlOnStart",new String[]{ "Z"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"logOnStart");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1210,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(1211,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_BOOLEAN,1,0,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_logUrlOnStart","Z"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m053_setOverrideDescriptor(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","setOverrideDescriptor",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"overrideDescriptor");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1012,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(1013,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_overrideDescriptor","Ljava/lang/String;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m054_setParentLoaderPriority(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","setParentLoaderPriority",new String[]{ "Z"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"java2compliant");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1102,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(1103,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_BOOLEAN,1,0,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_parentLoaderPriority","Z"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m055_setPermissions(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","setPermissions",new String[]{ "Ljava/security/PermissionCollection;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"permissions");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1111,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(1112,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_permissions","Ljava/security/PermissionCollection;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m056_setResourceAlias(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","setResourceAlias",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"alias");
                ddv.visitParameterName(1,"uri");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(328,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(329,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(330,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(331,L3);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_resourceAliases","Ljava/util/Map;"));
                code.visitJumpStmt(IF_NEZ,0,-1,L2);
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/util/HashMap;");
                code.visitConstStmt(CONST_4,1, Integer.valueOf(5)); // int: 0x00000005  float:0.000000
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Ljava/util/HashMap;","<init>",new String[]{ "I"},"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_resourceAliases","Ljava/util/Map;"));
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_resourceAliases","Ljava/util/Map;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,3,4},new Method("Ljava/util/Map;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L3);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m057_setResourceAliases(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","setResourceAliases",new String[]{ "Ljava/util/Map;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"map");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(344,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(345,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_resourceAliases","Ljava/util/Map;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m058_setServerClasses(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","setServerClasses",new String[]{ "[Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"serverClasses");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1120,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(1121,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(1120,L2);
                code.visitLabel(L0);
                code.visitJumpStmt(IF_NEZ,2,-1,L2);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                DexLabel L3=new DexLabel();
                code.visitLabel(L3);
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_serverClasses","[Ljava/lang/String;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("[Ljava/lang/String;","clone",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitTypeStmt(CHECK_CAST,0,-1,"[Ljava/lang/String;");
                code.visitTypeStmt(CHECK_CAST,0,-1,"[Ljava/lang/String;");
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m059_setSystemClasses(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","setSystemClasses",new String[]{ "[Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"systemClasses");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1129,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(1130,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(1129,L2);
                code.visitLabel(L0);
                code.visitJumpStmt(IF_NEZ,2,-1,L2);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                DexLabel L3=new DexLabel();
                code.visitLabel(L3);
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_systemClasses","[Ljava/lang/String;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("[Ljava/lang/String;","clone",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitTypeStmt(CHECK_CAST,0,-1,"[Ljava/lang/String;");
                code.visitTypeStmt(CHECK_CAST,0,-1,"[Ljava/lang/String;");
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m060_setTempDirectory(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","setTempDirectory",new String[]{ "Ljava/io/File;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/io/IOException;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"dir");
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(1140,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(1141,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(1143,L5);
                ddv.visitLineNumber(1145,L0);
                ddv.visitEndLocal(6,L1);
                ddv.visitStartLocal(0,L1,"dir","Ljava/io/File;",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(1149,L6);
                ddv.visitEndLocal(0,L6);
                ddv.visitRestartLocal(6,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(1151,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(1152,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(1157,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(1158,L10);
                ddv.visitLineNumber(1146,L2);
                DexLabel L11=new DexLabel();
                ddv.visitStartLocal(1,L11,"e","Ljava/io/IOException;",null);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(1154,L12);
                ddv.visitEndLocal(1,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(1155,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(1160,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(1161,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(1162,L16);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","isStarted",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_EQZ,2,-1,L5);
                code.visitLabel(L4);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Ljava/lang/IllegalStateException;");
                code.visitConstStmt(CONST_STRING,3,"Started");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2,3},new Method("Ljava/lang/IllegalStateException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,2);
                code.visitLabel(L5);
                code.visitJumpStmt(IF_EQZ,6,-1,L6);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/io/File;");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/io/File;","getCanonicalPath",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,2},new Method("Ljava/io/File;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L1);
                code.visitStmt2R(MOVE_OBJECT,6,0);
                code.visitLabel(L6);
                code.visitJumpStmt(IF_EQZ,6,-1,L12);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/io/File;","exists",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_NEZ,2,-1,L12);
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/io/File;","mkdir",new String[]{ },"Z"));
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/io/File;","deleteOnExit",new String[]{ },"V"));
                code.visitLabel(L9);
                code.visitJumpStmt(IF_EQZ,6,-1,L14);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/io/File;","exists",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_EQZ,2,-1,L10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/io/File;","isDirectory",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_EQZ,2,-1,L10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/io/File;","canWrite",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_NEZ,2,-1,L14);
                code.visitLabel(L10);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Ljava/lang/IllegalArgumentException;");
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,4,"Bad temp directory: ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,6},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2,3},new Method("Ljava/lang/IllegalArgumentException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,2);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,2);
                code.visitStmt2R(MOVE_OBJECT,1,2);
                code.visitLabel(L11);
                code.visitConstStmt(CONST_STRING,2,"EXCEPTION ");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2,1},new Method("Lorg/mortbay/log/Log;","warn",new String[]{ "Ljava/lang/String;","Ljava/lang/Throwable;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L6);
                code.visitLabel(L12);
                code.visitJumpStmt(IF_EQZ,6,-1,L9);
                code.visitLabel(L13);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitFieldStmt(IPUT_BOOLEAN,2,5,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_isExistingTmpDir","Z"));
                code.visitJumpStmt(GOTO,-1,-1,L9);
                code.visitLabel(L14);
                code.visitFieldStmt(IPUT_OBJECT,6,5,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_tmpDir","Ljava/io/File;"));
                code.visitLabel(L15);
                code.visitConstStmt(CONST_STRING,2,"javax.servlet.context.tempdir");
                code.visitFieldStmt(IGET_OBJECT,3,5,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_tmpDir","Ljava/io/File;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,2,3},new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","setAttribute",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L16);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m061_setWar(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","setWar",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"war");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1170,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(1171,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_war","Ljava/lang/String;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m062_startContext(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","startContext",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/Exception;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(1218,L1);
                DexLabel L2=new DexLabel();
                ddv.visitStartLocal(0,L2,"i","I",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(1219,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(1218,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(1222,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(1223,L6);
                ddv.visitStartLocal(1,L6,"web_inf","Lorg/mortbay/resource/Resource;",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(1225,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(1226,L8);
                ddv.visitStartLocal(2,L8,"work","Lorg/mortbay/resource/Resource;",null);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(1231,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(1235,L10);
                ddv.visitEndLocal(2,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(1236,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(1235,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(1239,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(1240,L14);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_STRING,4,"javax.servlet.context.tempdir");
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,3,5,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_configurations","[Lorg/mortbay/jetty/webapp/Configuration;"));
                code.visitStmt2R(ARRAY_LENGTH,3,3);
                code.visitJumpStmt(IF_GE,0,3,L5);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,3,5,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_configurations","[Lorg/mortbay/jetty/webapp/Configuration;"));
                code.visitStmt3R(AGET_OBJECT,3,3,0);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3},new Method("Lorg/mortbay/jetty/webapp/Configuration;","configureDefaults",new String[]{ },"V"));
                code.visitLabel(L4);
                code.visitStmt2R1N(ADD_INT_LIT8,0,0,1);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","getWebInf",new String[]{ },"Lorg/mortbay/resource/Resource;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L6);
                code.visitJumpStmt(IF_EQZ,1,-1,L10);
                code.visitLabel(L7);
                code.visitConstStmt(CONST_STRING,3,"work");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,3},new Method("Lorg/mortbay/resource/Resource;","addPath",new String[]{ "Ljava/lang/String;"},"Lorg/mortbay/resource/Resource;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/resource/Resource;","exists",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_EQZ,3,-1,L10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/resource/Resource;","isDirectory",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_EQZ,3,-1,L10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/resource/Resource;","getFile",new String[]{ },"Ljava/io/File;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitJumpStmt(IF_EQZ,3,-1,L10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/resource/Resource;","getFile",new String[]{ },"Ljava/io/File;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/io/File;","canWrite",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_EQZ,3,-1,L10);
                code.visitConstStmt(CONST_STRING,3,"javax.servlet.context.tempdir");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,4},new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","getAttribute",new String[]{ "Ljava/lang/String;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitJumpStmt(IF_NEZ,3,-1,L10);
                code.visitLabel(L9);
                code.visitConstStmt(CONST_STRING,3,"javax.servlet.context.tempdir");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/resource/Resource;","getFile",new String[]{ },"Ljava/io/File;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,4,3},new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","setAttribute",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L10);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                DexLabel L15=new DexLabel();
                code.visitLabel(L15);
                code.visitFieldStmt(IGET_OBJECT,3,5,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_configurations","[Lorg/mortbay/jetty/webapp/Configuration;"));
                code.visitStmt2R(ARRAY_LENGTH,3,3);
                code.visitJumpStmt(IF_GE,0,3,L13);
                code.visitLabel(L11);
                code.visitFieldStmt(IGET_OBJECT,3,5,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_configurations","[Lorg/mortbay/jetty/webapp/Configuration;"));
                code.visitStmt3R(AGET_OBJECT,3,3,0);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3},new Method("Lorg/mortbay/jetty/webapp/Configuration;","configureWebApp",new String[]{ },"V"));
                code.visitLabel(L12);
                code.visitStmt2R1N(ADD_INT_LIT8,0,0,1);
                code.visitJumpStmt(GOTO,-1,-1,L15);
                code.visitLabel(L13);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 5},new Method("Lorg/mortbay/jetty/servlet/Context;","startContext",new String[]{ },"V"));
                code.visitLabel(L14);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m063_toString(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","toString",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(874,L0);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/lang/Object;","getClass",new String[]{ },"Ljava/lang/Class;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/lang/Class;","getName",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitConstStmt(CONST_STRING,1,"@");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/lang/Object;","hashCode",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1},new Method("Ljava/lang/Integer;","toHexString",new String[]{ "I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitConstStmt(CONST_STRING,1,"{");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","getContextPath",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitConstStmt(CONST_STRING,1,",");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_war","Ljava/lang/String;"));
                DexLabel L1=new DexLabel();
                code.visitJumpStmt(IF_NEZ,1,-1,L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","getResourceBase",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                DexLabel L2=new DexLabel();
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitConstStmt(CONST_STRING,1,"}");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/webapp/WebAppContext;","_war","Ljava/lang/String;"));
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
