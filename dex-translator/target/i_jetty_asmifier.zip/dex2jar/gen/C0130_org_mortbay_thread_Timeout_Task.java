package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0130_org_mortbay_thread_Timeout_Task {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/thread/Timeout$Task;","Ljava/lang/Object;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("Timeout.java");
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/EnclosingClass;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("value", new DexType("Lorg/mortbay/thread/Timeout;"));
                av00.visitEnd();
            }
        }
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/InnerClass;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("accessFlags",  Integer.valueOf(9));
                av00.visit("name", "Task");
                av00.visitEnd();
            }
        }
        f000__delay(cv);
        f001__expired(cv);
        f002__next(cv);
        f003__prev(cv);
        f004__timeout(cv);
        f005__timestamp(cv);
        m000__init_(cv);
        m001_access$000(cv);
        m002_access$100(cv);
        m003_link(cv);
        m004_unlink(cv);
        m005_cancel(cv);
        m006_expire(cv);
        m007_expired(cv);
        m008_getAge(cv);
        m009_getTimestamp(cv);
        m010_isExpired(cv);
        m011_isScheduled(cv);
        m012_reschedule(cv);
        m013_schedule(cv);
        m014_schedule(cv);
    }
    public static void f000__delay(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/thread/Timeout$Task;","_delay","J"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001__expired(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/thread/Timeout$Task;","_expired","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002__next(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/thread/Timeout$Task;","_next","Lorg/mortbay/thread/Timeout$Task;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003__prev(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/thread/Timeout$Task;","_prev","Lorg/mortbay/thread/Timeout$Task;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f004__timeout(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/thread/Timeout$Task;","_timeout","Lorg/mortbay/thread/Timeout;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f005__timestamp(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/thread/Timeout$Task;","_timestamp","J"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/thread/Timeout$Task;","<init>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(277,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(272,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(273,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(278,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(279,L4);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2},new Method("Ljava/lang/Object;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitConstStmt(CONST_WIDE_16,0,Long.valueOf(0L)); // long: 0x0000000000000000  double:0.000000
                code.visitFieldStmt(IPUT_WIDE,0,2,new Field("Lorg/mortbay/thread/Timeout$Task;","_timestamp","J"));
                code.visitLabel(L2);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_BOOLEAN,0,2,new Field("Lorg/mortbay/thread/Timeout$Task;","_expired","Z"));
                code.visitLabel(L3);
                code.visitFieldStmt(IPUT_OBJECT,2,2,new Field("Lorg/mortbay/thread/Timeout$Task;","_prev","Lorg/mortbay/thread/Timeout$Task;"));
                code.visitFieldStmt(IPUT_OBJECT,2,2,new Field("Lorg/mortbay/thread/Timeout$Task;","_next","Lorg/mortbay/thread/Timeout$Task;"));
                code.visitLabel(L4);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001_access$000(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_SYNTHETIC, new Method("Lorg/mortbay/thread/Timeout$Task;","access$000",new String[]{ "Lorg/mortbay/thread/Timeout$Task;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"x0");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(266,L0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Lorg/mortbay/thread/Timeout$Task;","unlink",new String[]{ },"V"));
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_access$100(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_SYNTHETIC, new Method("Lorg/mortbay/thread/Timeout$Task;","access$100",new String[]{ "Lorg/mortbay/thread/Timeout$Task;","Lorg/mortbay/thread/Timeout$Task;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"x0");
                ddv.visitParameterName(1,"x1");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(266,L0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Lorg/mortbay/thread/Timeout$Task;","link",new String[]{ "Lorg/mortbay/thread/Timeout$Task;"},"V"));
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_link(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PRIVATE, new Method("Lorg/mortbay/thread/Timeout$Task;","link",new String[]{ "Lorg/mortbay/thread/Timeout$Task;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"task");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(308,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(309,L1);
                ddv.visitStartLocal(0,L1,"next_next","Lorg/mortbay/thread/Timeout$Task;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(310,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(311,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(312,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(313,L5);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/thread/Timeout$Task;","_next","Lorg/mortbay/thread/Timeout$Task;"));
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/thread/Timeout$Task;","_next","Lorg/mortbay/thread/Timeout$Task;"));
                code.visitFieldStmt(IPUT_OBJECT,3,1,new Field("Lorg/mortbay/thread/Timeout$Task;","_prev","Lorg/mortbay/thread/Timeout$Task;"));
                code.visitLabel(L2);
                code.visitFieldStmt(IPUT_OBJECT,3,2,new Field("Lorg/mortbay/thread/Timeout$Task;","_next","Lorg/mortbay/thread/Timeout$Task;"));
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/thread/Timeout$Task;","_next","Lorg/mortbay/thread/Timeout$Task;"));
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/thread/Timeout$Task;","_next","Lorg/mortbay/thread/Timeout$Task;"));
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/thread/Timeout$Task;","_next","Lorg/mortbay/thread/Timeout$Task;"));
                code.visitFieldStmt(IPUT_OBJECT,2,1,new Field("Lorg/mortbay/thread/Timeout$Task;","_prev","Lorg/mortbay/thread/Timeout$Task;"));
                code.visitLabel(L5);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_unlink(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PRIVATE, new Method("Lorg/mortbay/thread/Timeout$Task;","unlink",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(299,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(300,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(301,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(302,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(303,L4);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/thread/Timeout$Task;","_next","Lorg/mortbay/thread/Timeout$Task;"));
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/thread/Timeout$Task;","_prev","Lorg/mortbay/thread/Timeout$Task;"));
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/thread/Timeout$Task;","_prev","Lorg/mortbay/thread/Timeout$Task;"));
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/thread/Timeout$Task;","_prev","Lorg/mortbay/thread/Timeout$Task;"));
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/thread/Timeout$Task;","_next","Lorg/mortbay/thread/Timeout$Task;"));
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/thread/Timeout$Task;","_next","Lorg/mortbay/thread/Timeout$Task;"));
                code.visitLabel(L2);
                code.visitFieldStmt(IPUT_OBJECT,2,2,new Field("Lorg/mortbay/thread/Timeout$Task;","_prev","Lorg/mortbay/thread/Timeout$Task;"));
                code.visitFieldStmt(IPUT_OBJECT,2,2,new Field("Lorg/mortbay/thread/Timeout$Task;","_next","Lorg/mortbay/thread/Timeout$Task;"));
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_BOOLEAN,0,2,new Field("Lorg/mortbay/thread/Timeout$Task;","_expired","Z"));
                code.visitLabel(L4);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_cancel(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/thread/Timeout$Task;","cancel",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(353,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(354,L4);
                ddv.visitStartLocal(0,L4,"timeout","Lorg/mortbay/thread/Timeout;",null);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(356,L5);
                ddv.visitLineNumber(358,L0);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(359,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(360,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(362,L8);
                ddv.visitLineNumber(360,L2);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/thread/Timeout$Task;","_timeout","Lorg/mortbay/thread/Timeout;"));
                code.visitLabel(L4);
                code.visitJumpStmt(IF_EQZ,0,-1,L8);
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/thread/Timeout;","access$300",new String[]{ "Lorg/mortbay/thread/Timeout;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitStmt1R(MONITOR_ENTER,1);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4},new Method("Lorg/mortbay/thread/Timeout$Task;","unlink",new String[]{ },"V"));
                code.visitLabel(L6);
                code.visitConstStmt(CONST_WIDE_16,2,Long.valueOf(0L)); // long: 0x0000000000000000  double:0.000000
                code.visitFieldStmt(IPUT_WIDE,2,4,new Field("Lorg/mortbay/thread/Timeout$Task;","_timestamp","J"));
                code.visitLabel(L7);
                code.visitStmt1R(MONITOR_EXIT,1);
                code.visitLabel(L8);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,2);
                code.visitStmt1R(MONITOR_EXIT,1);
                code.visitLabel(L1);
                code.visitStmt1R(THROW,2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_expire(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/thread/Timeout$Task;","expire",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(377,L0);
                code.visitLabel(L0);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m007_expired(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/thread/Timeout$Task;","expired",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(385,L0);
                code.visitLabel(L0);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m008_getAge(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/thread/Timeout$Task;","getAge",new String[]{ },"J"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(290,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(291,L2);
                ddv.visitStartLocal(0,L2,"t","Lorg/mortbay/thread/Timeout;",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(292,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(293,L4);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_WIDE_16,3,Long.valueOf(0L)); // long: 0x0000000000000000  double:0.000000
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,5,new Field("Lorg/mortbay/thread/Timeout$Task;","_timeout","Lorg/mortbay/thread/Timeout;"));
                code.visitLabel(L2);
                DexLabel L5=new DexLabel();
                code.visitJumpStmt(IF_EQZ,0,-1,L5);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/thread/Timeout;","access$200",new String[]{ "Lorg/mortbay/thread/Timeout;"},"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,1);
                code.visitStmt3R(CMP_LONG,1,1,3);
                code.visitJumpStmt(IF_EQZ,1,-1,L5);
                code.visitFieldStmt(IGET_WIDE,1,5,new Field("Lorg/mortbay/thread/Timeout$Task;","_timestamp","J"));
                code.visitStmt3R(CMP_LONG,1,1,3);
                code.visitJumpStmt(IF_EQZ,1,-1,L5);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/thread/Timeout;","access$200",new String[]{ "Lorg/mortbay/thread/Timeout;"},"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,1);
                code.visitFieldStmt(IGET_WIDE,3,5,new Field("Lorg/mortbay/thread/Timeout$Task;","_timestamp","J"));
                code.visitStmt2R(SUB_LONG_2ADDR,1,3);
                code.visitLabel(L4);
                code.visitStmt1R(RETURN_WIDE,1);
                code.visitLabel(L5);
                code.visitStmt2R(MOVE_WIDE,1,3);
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m009_getTimestamp(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/thread/Timeout$Task;","getTimestamp",new String[]{ },"J"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(284,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_WIDE,0,2,new Field("Lorg/mortbay/thread/Timeout$Task;","_timestamp","J"));
                code.visitStmt1R(RETURN_WIDE,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m010_isExpired(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/thread/Timeout$Task;","isExpired",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(365,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_BOOLEAN,0,1,new Field("Lorg/mortbay/thread/Timeout$Task;","_expired","Z"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m011_isScheduled(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/thread/Timeout$Task;","isScheduled",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(368,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/thread/Timeout$Task;","_next","Lorg/mortbay/thread/Timeout$Task;"));
                DexLabel L1=new DexLabel();
                code.visitJumpStmt(IF_EQ,0,1,L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                DexLabel L2=new DexLabel();
                code.visitLabel(L2);
                code.visitStmt1R(RETURN,0);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m012_reschedule(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/thread/Timeout$Task;","reschedule",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(342,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(343,L1);
                ddv.visitStartLocal(0,L1,"timeout","Lorg/mortbay/thread/Timeout;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(344,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(345,L3);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/thread/Timeout$Task;","_timeout","Lorg/mortbay/thread/Timeout;"));
                code.visitLabel(L1);
                code.visitJumpStmt(IF_EQZ,0,-1,L3);
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_WIDE,1,3,new Field("Lorg/mortbay/thread/Timeout$Task;","_delay","J"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,3,1,2},new Method("Lorg/mortbay/thread/Timeout;","schedule",new String[]{ "Lorg/mortbay/thread/Timeout$Task;","J"},"V"));
                code.visitLabel(L3);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m013_schedule(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/thread/Timeout$Task;","schedule",new String[]{ "Lorg/mortbay/thread/Timeout;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"timer");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(322,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(323,L1);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,0},new Method("Lorg/mortbay/thread/Timeout;","schedule",new String[]{ "Lorg/mortbay/thread/Timeout$Task;"},"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m014_schedule(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/thread/Timeout$Task;","schedule",new String[]{ "Lorg/mortbay/thread/Timeout;","J"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"timer");
                ddv.visitParameterName(1,"delay");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(332,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(333,L1);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,0,2,3},new Method("Lorg/mortbay/thread/Timeout;","schedule",new String[]{ "Lorg/mortbay/thread/Timeout$Task;","J"},"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
