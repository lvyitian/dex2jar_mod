package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0167_org_mortbay_jetty_HttpHeaders {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/jetty/HttpHeaders;","Lorg/mortbay/io/BufferCache;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("HttpHeaders.java");
        f000_ACCEPT(cv);
        f001_ACCEPT_BUFFER(cv);
        f002_ACCEPT_CHARSET(cv);
        f003_ACCEPT_CHARSET_BUFFER(cv);
        f004_ACCEPT_CHARSET_ORDINAL(cv);
        f005_ACCEPT_ENCODING(cv);
        f006_ACCEPT_ENCODING_BUFFER(cv);
        f007_ACCEPT_ENCODING_ORDINAL(cv);
        f008_ACCEPT_LANGUAGE(cv);
        f009_ACCEPT_LANGUAGE_BUFFER(cv);
        f010_ACCEPT_LANGUAGE_ORDINAL(cv);
        f011_ACCEPT_ORDINAL(cv);
        f012_ACCEPT_RANGES(cv);
        f013_ACCEPT_RANGES_BUFFER(cv);
        f014_ACCEPT_RANGES_ORDINAL(cv);
        f015_AGE(cv);
        f016_AGE_BUFFER(cv);
        f017_AGE_ORDINAL(cv);
        f018_ALLOW(cv);
        f019_ALLOW_BUFFER(cv);
        f020_ALLOW_ORDINAL(cv);
        f021_AUTHORIZATION(cv);
        f022_AUTHORIZATION_BUFFER(cv);
        f023_AUTHORIZATION_ORDINAL(cv);
        f024_CACHE(cv);
        f025_CACHE_CONTROL(cv);
        f026_CACHE_CONTROL_BUFFER(cv);
        f027_CACHE_CONTROL_ORDINAL(cv);
        f028_CONNECTION(cv);
        f029_CONNECTION_BUFFER(cv);
        f030_CONNECTION_ORDINAL(cv);
        f031_CONTENT_ENCODING(cv);
        f032_CONTENT_ENCODING_BUFFER(cv);
        f033_CONTENT_ENCODING_ORDINAL(cv);
        f034_CONTENT_LANGUAGE(cv);
        f035_CONTENT_LANGUAGE_BUFFER(cv);
        f036_CONTENT_LANGUAGE_ORDINAL(cv);
        f037_CONTENT_LENGTH(cv);
        f038_CONTENT_LENGTH_BUFFER(cv);
        f039_CONTENT_LENGTH_ORDINAL(cv);
        f040_CONTENT_LOCATION(cv);
        f041_CONTENT_LOCATION_BUFFER(cv);
        f042_CONTENT_LOCATION_ORDINAL(cv);
        f043_CONTENT_MD5(cv);
        f044_CONTENT_MD5_BUFFER(cv);
        f045_CONTENT_MD5_ORDINAL(cv);
        f046_CONTENT_RANGE(cv);
        f047_CONTENT_RANGE_BUFFER(cv);
        f048_CONTENT_RANGE_ORDINAL(cv);
        f049_CONTENT_TYPE(cv);
        f050_CONTENT_TYPE_BUFFER(cv);
        f051_CONTENT_TYPE_ORDINAL(cv);
        f052_COOKIE(cv);
        f053_COOKIE_BUFFER(cv);
        f054_COOKIE_ORDINAL(cv);
        f055_DATE(cv);
        f056_DATE_BUFFER(cv);
        f057_DATE_ORDINAL(cv);
        f058_ETAG(cv);
        f059_ETAG_BUFFER(cv);
        f060_ETAG_ORDINAL(cv);
        f061_EXPECT(cv);
        f062_EXPECT_BUFFER(cv);
        f063_EXPECT_ORDINAL(cv);
        f064_EXPIRES(cv);
        f065_EXPIRES_BUFFER(cv);
        f066_EXPIRES_ORDINAL(cv);
        f067_FORWARDED(cv);
        f068_FORWARDED_BUFFER(cv);
        f069_FORWARDED_ORDINAL(cv);
        f070_FROM(cv);
        f071_FROM_BUFFER(cv);
        f072_FROM_ORDINAL(cv);
        f073_HOST(cv);
        f074_HOST_BUFFER(cv);
        f075_HOST_ORDINAL(cv);
        f076_IDENTITY(cv);
        f077_IDENTITY_BUFFER(cv);
        f078_IDENTITY_ORDINAL(cv);
        f079_IF_MATCH(cv);
        f080_IF_MATCH_BUFFER(cv);
        f081_IF_MATCH_ORDINAL(cv);
        f082_IF_MODIFIED_SINCE(cv);
        f083_IF_MODIFIED_SINCE_BUFFER(cv);
        f084_IF_MODIFIED_SINCE_ORDINAL(cv);
        f085_IF_NONE_MATCH(cv);
        f086_IF_NONE_MATCH_BUFFER(cv);
        f087_IF_NONE_MATCH_ORDINAL(cv);
        f088_IF_RANGE(cv);
        f089_IF_RANGE_BUFFER(cv);
        f090_IF_RANGE_ORDINAL(cv);
        f091_IF_UNMODIFIED_SINCE(cv);
        f092_IF_UNMODIFIED_SINCE_BUFFER(cv);
        f093_IF_UNMODIFIED_SINCE_ORDINAL(cv);
        f094_KEEP_ALIVE(cv);
        f095_KEEP_ALIVE_BUFFER(cv);
        f096_KEEP_ALIVE_ORDINAL(cv);
        f097_LAST_MODIFIED(cv);
        f098_LAST_MODIFIED_BUFFER(cv);
        f099_LAST_MODIFIED_ORDINAL(cv);
        f100_LOCATION(cv);
        f101_LOCATION_BUFFER(cv);
        f102_LOCATION_ORDINAL(cv);
        f103_MAX_FORWARDS(cv);
        f104_MAX_FORWARDS_BUFFER(cv);
        f105_MAX_FORWARDS_ORDINAL(cv);
        f106_MIME_VERSION(cv);
        f107_MIME_VERSION_BUFFER(cv);
        f108_MIME_VERSION_ORDINAL(cv);
        f109_PRAGMA(cv);
        f110_PRAGMA_BUFFER(cv);
        f111_PRAGMA_ORDINAL(cv);
        f112_PROXY_AUTHENTICATE(cv);
        f113_PROXY_AUTHENTICATE_BUFFER(cv);
        f114_PROXY_AUTHENTICATE_ORDINAL(cv);
        f115_PROXY_AUTHORIZATION(cv);
        f116_PROXY_AUTHORIZATION_BUFFER(cv);
        f117_PROXY_AUTHORIZATION_ORDINAL(cv);
        f118_PROXY_CONNECTION(cv);
        f119_PROXY_CONNECTION_BUFFER(cv);
        f120_PROXY_CONNECTION_ORDINAL(cv);
        f121_RANGE(cv);
        f122_RANGE_BUFFER(cv);
        f123_RANGE_ORDINAL(cv);
        f124_REFERER(cv);
        f125_REFERER_BUFFER(cv);
        f126_REFERER_ORDINAL(cv);
        f127_REQUEST_RANGE(cv);
        f128_REQUEST_RANGE_BUFFER(cv);
        f129_REQUEST_RANGE_ORDINAL(cv);
        f130_RETRY_AFTER(cv);
        f131_RETRY_AFTER_BUFFER(cv);
        f132_RETRY_AFTER_ORDINAL(cv);
        f133_SERVER(cv);
        f134_SERVER_BUFFER(cv);
        f135_SERVER_ORDINAL(cv);
        f136_SERVLET_ENGINE(cv);
        f137_SERVLET_ENGINE_BUFFER(cv);
        f138_SERVLET_ENGINE_ORDINAL(cv);
        f139_SET_COOKIE(cv);
        f140_SET_COOKIE2(cv);
        f141_SET_COOKIE2_BUFFER(cv);
        f142_SET_COOKIE2_ORDINAL(cv);
        f143_SET_COOKIE_BUFFER(cv);
        f144_SET_COOKIE_ORDINAL(cv);
        f145_TE(cv);
        f146_TE_BUFFER(cv);
        f147_TE_ORDINAL(cv);
        f148_TRAILER(cv);
        f149_TRAILER_BUFFER(cv);
        f150_TRAILER_ORDINAL(cv);
        f151_TRANSFER_ENCODING(cv);
        f152_TRANSFER_ENCODING_BUFFER(cv);
        f153_TRANSFER_ENCODING_ORDINAL(cv);
        f154_UPGRADE(cv);
        f155_UPGRADE_BUFFER(cv);
        f156_UPGRADE_ORDINAL(cv);
        f157_USER_AGENT(cv);
        f158_USER_AGENT_BUFFER(cv);
        f159_USER_AGENT_ORDINAL(cv);
        f160_VARY(cv);
        f161_VARY_BUFFER(cv);
        f162_VARY_ORDINAL(cv);
        f163_VIA(cv);
        f164_VIA_BUFFER(cv);
        f165_VIA_ORDINAL(cv);
        f166_WARNING(cv);
        f167_WARNING_BUFFER(cv);
        f168_WARNING_ORDINAL(cv);
        f169_WWW_AUTHENTICATE(cv);
        f170_WWW_AUTHENTICATE_BUFFER(cv);
        f171_WWW_AUTHENTICATE_ORDINAL(cv);
        f172_X_FORWARDED_FOR(cv);
        f173_X_FORWARDED_FOR_BUFFER(cv);
        f174_X_FORWARDED_FOR_ORDINAL(cv);
        m000__clinit_(cv);
        m001__init_(cv);
    }
    public static void f000_ACCEPT(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","ACCEPT","Ljava/lang/String;"), "Accept");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001_ACCEPT_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","ACCEPT_BUFFER","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002_ACCEPT_CHARSET(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","ACCEPT_CHARSET","Ljava/lang/String;"), "Accept-Charset");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003_ACCEPT_CHARSET_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","ACCEPT_CHARSET_BUFFER","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f004_ACCEPT_CHARSET_ORDINAL(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","ACCEPT_CHARSET_ORDINAL","I"),  Integer.valueOf(20));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f005_ACCEPT_ENCODING(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","ACCEPT_ENCODING","Ljava/lang/String;"), "Accept-Encoding");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f006_ACCEPT_ENCODING_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","ACCEPT_ENCODING_BUFFER","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f007_ACCEPT_ENCODING_ORDINAL(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","ACCEPT_ENCODING_ORDINAL","I"),  Integer.valueOf(21));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f008_ACCEPT_LANGUAGE(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","ACCEPT_LANGUAGE","Ljava/lang/String;"), "Accept-Language");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f009_ACCEPT_LANGUAGE_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","ACCEPT_LANGUAGE_BUFFER","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f010_ACCEPT_LANGUAGE_ORDINAL(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","ACCEPT_LANGUAGE_ORDINAL","I"),  Integer.valueOf(22));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f011_ACCEPT_ORDINAL(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","ACCEPT_ORDINAL","I"),  Integer.valueOf(19));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f012_ACCEPT_RANGES(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","ACCEPT_RANGES","Ljava/lang/String;"), "Accept-Ranges");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f013_ACCEPT_RANGES_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","ACCEPT_RANGES_BUFFER","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f014_ACCEPT_RANGES_ORDINAL(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","ACCEPT_RANGES_ORDINAL","I"),  Integer.valueOf(42));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f015_AGE(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","AGE","Ljava/lang/String;"), "Age");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f016_AGE_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","AGE_BUFFER","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f017_AGE_ORDINAL(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","AGE_ORDINAL","I"),  Integer.valueOf(43));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f018_ALLOW(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","ALLOW","Ljava/lang/String;"), "Allow");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f019_ALLOW_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","ALLOW_BUFFER","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f020_ALLOW_ORDINAL(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","ALLOW_ORDINAL","I"),  Integer.valueOf(9));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f021_AUTHORIZATION(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","AUTHORIZATION","Ljava/lang/String;"), "Authorization");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f022_AUTHORIZATION_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","AUTHORIZATION_BUFFER","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f023_AUTHORIZATION_ORDINAL(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","AUTHORIZATION_ORDINAL","I"),  Integer.valueOf(23));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f024_CACHE(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","CACHE","Lorg/mortbay/jetty/HttpHeaders;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f025_CACHE_CONTROL(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","CACHE_CONTROL","Ljava/lang/String;"), "Cache-Control");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f026_CACHE_CONTROL_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","CACHE_CONTROL_BUFFER","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f027_CACHE_CONTROL_ORDINAL(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","CACHE_CONTROL_ORDINAL","I"),  Integer.valueOf(57));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f028_CONNECTION(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","CONNECTION","Ljava/lang/String;"), "Connection");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f029_CONNECTION_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","CONNECTION_BUFFER","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f030_CONNECTION_ORDINAL(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","CONNECTION_ORDINAL","I"),  Integer.valueOf(1));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f031_CONTENT_ENCODING(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","CONTENT_ENCODING","Ljava/lang/String;"), "Content-Encoding");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f032_CONTENT_ENCODING_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","CONTENT_ENCODING_BUFFER","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f033_CONTENT_ENCODING_ORDINAL(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","CONTENT_ENCODING_ORDINAL","I"),  Integer.valueOf(10));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f034_CONTENT_LANGUAGE(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","CONTENT_LANGUAGE","Ljava/lang/String;"), "Content-Language");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f035_CONTENT_LANGUAGE_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","CONTENT_LANGUAGE_BUFFER","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f036_CONTENT_LANGUAGE_ORDINAL(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","CONTENT_LANGUAGE_ORDINAL","I"),  Integer.valueOf(11));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f037_CONTENT_LENGTH(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","CONTENT_LENGTH","Ljava/lang/String;"), "Content-Length");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f038_CONTENT_LENGTH_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","CONTENT_LENGTH_BUFFER","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f039_CONTENT_LENGTH_ORDINAL(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","CONTENT_LENGTH_ORDINAL","I"),  Integer.valueOf(12));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f040_CONTENT_LOCATION(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","CONTENT_LOCATION","Ljava/lang/String;"), "Content-Location");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f041_CONTENT_LOCATION_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","CONTENT_LOCATION_BUFFER","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f042_CONTENT_LOCATION_ORDINAL(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","CONTENT_LOCATION_ORDINAL","I"),  Integer.valueOf(13));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f043_CONTENT_MD5(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","CONTENT_MD5","Ljava/lang/String;"), "Content-MD5");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f044_CONTENT_MD5_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","CONTENT_MD5_BUFFER","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f045_CONTENT_MD5_ORDINAL(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","CONTENT_MD5_ORDINAL","I"),  Integer.valueOf(14));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f046_CONTENT_RANGE(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","CONTENT_RANGE","Ljava/lang/String;"), "Content-Range");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f047_CONTENT_RANGE_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","CONTENT_RANGE_BUFFER","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f048_CONTENT_RANGE_ORDINAL(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","CONTENT_RANGE_ORDINAL","I"),  Integer.valueOf(15));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f049_CONTENT_TYPE(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","CONTENT_TYPE","Ljava/lang/String;"), "Content-Type");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f050_CONTENT_TYPE_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","CONTENT_TYPE_BUFFER","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f051_CONTENT_TYPE_ORDINAL(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","CONTENT_TYPE_ORDINAL","I"),  Integer.valueOf(16));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f052_COOKIE(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","COOKIE","Ljava/lang/String;"), "Cookie");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f053_COOKIE_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","COOKIE_BUFFER","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f054_COOKIE_ORDINAL(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","COOKIE_ORDINAL","I"),  Integer.valueOf(52));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f055_DATE(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","DATE","Ljava/lang/String;"), "Date");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f056_DATE_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","DATE_BUFFER","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f057_DATE_ORDINAL(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","DATE_ORDINAL","I"),  Integer.valueOf(2));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f058_ETAG(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","ETAG","Ljava/lang/String;"), "ETag");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f059_ETAG_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","ETAG_BUFFER","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f060_ETAG_ORDINAL(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","ETAG_ORDINAL","I"),  Integer.valueOf(44));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f061_EXPECT(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","EXPECT","Ljava/lang/String;"), "Expect");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f062_EXPECT_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","EXPECT_BUFFER","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f063_EXPECT_ORDINAL(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","EXPECT_ORDINAL","I"),  Integer.valueOf(24));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f064_EXPIRES(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","EXPIRES","Ljava/lang/String;"), "Expires");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f065_EXPIRES_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","EXPIRES_BUFFER","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f066_EXPIRES_ORDINAL(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","EXPIRES_ORDINAL","I"),  Integer.valueOf(17));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f067_FORWARDED(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","FORWARDED","Ljava/lang/String;"), "Forwarded");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f068_FORWARDED_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","FORWARDED_BUFFER","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f069_FORWARDED_ORDINAL(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","FORWARDED_ORDINAL","I"),  Integer.valueOf(25));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f070_FROM(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","FROM","Ljava/lang/String;"), "From");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f071_FROM_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","FROM_BUFFER","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f072_FROM_ORDINAL(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","FROM_ORDINAL","I"),  Integer.valueOf(26));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f073_HOST(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","HOST","Ljava/lang/String;"), "Host");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f074_HOST_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","HOST_BUFFER","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f075_HOST_ORDINAL(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","HOST_ORDINAL","I"),  Integer.valueOf(27));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f076_IDENTITY(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","IDENTITY","Ljava/lang/String;"), "identity");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f077_IDENTITY_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","IDENTITY_BUFFER","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f078_IDENTITY_ORDINAL(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","IDENTITY_ORDINAL","I"),  Integer.valueOf(56));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f079_IF_MATCH(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","IF_MATCH","Ljava/lang/String;"), "If-Match");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f080_IF_MATCH_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","IF_MATCH_BUFFER","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f081_IF_MATCH_ORDINAL(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","IF_MATCH_ORDINAL","I"),  Integer.valueOf(28));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f082_IF_MODIFIED_SINCE(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","IF_MODIFIED_SINCE","Ljava/lang/String;"), "If-Modified-Since");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f083_IF_MODIFIED_SINCE_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","IF_MODIFIED_SINCE_BUFFER","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f084_IF_MODIFIED_SINCE_ORDINAL(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","IF_MODIFIED_SINCE_ORDINAL","I"),  Integer.valueOf(29));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f085_IF_NONE_MATCH(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","IF_NONE_MATCH","Ljava/lang/String;"), "If-None-Match");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f086_IF_NONE_MATCH_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","IF_NONE_MATCH_BUFFER","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f087_IF_NONE_MATCH_ORDINAL(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","IF_NONE_MATCH_ORDINAL","I"),  Integer.valueOf(30));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f088_IF_RANGE(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","IF_RANGE","Ljava/lang/String;"), "If-Range");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f089_IF_RANGE_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","IF_RANGE_BUFFER","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f090_IF_RANGE_ORDINAL(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","IF_RANGE_ORDINAL","I"),  Integer.valueOf(31));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f091_IF_UNMODIFIED_SINCE(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","IF_UNMODIFIED_SINCE","Ljava/lang/String;"), "If-Unmodified-Since");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f092_IF_UNMODIFIED_SINCE_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","IF_UNMODIFIED_SINCE_BUFFER","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f093_IF_UNMODIFIED_SINCE_ORDINAL(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","IF_UNMODIFIED_SINCE_ORDINAL","I"),  Integer.valueOf(32));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f094_KEEP_ALIVE(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","KEEP_ALIVE","Ljava/lang/String;"), "Keep-Alive");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f095_KEEP_ALIVE_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","KEEP_ALIVE_BUFFER","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f096_KEEP_ALIVE_ORDINAL(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","KEEP_ALIVE_ORDINAL","I"),  Integer.valueOf(33));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f097_LAST_MODIFIED(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","LAST_MODIFIED","Ljava/lang/String;"), "Last-Modified");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f098_LAST_MODIFIED_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","LAST_MODIFIED_BUFFER","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f099_LAST_MODIFIED_ORDINAL(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","LAST_MODIFIED_ORDINAL","I"),  Integer.valueOf(18));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f100_LOCATION(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","LOCATION","Ljava/lang/String;"), "Location");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f101_LOCATION_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","LOCATION_BUFFER","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f102_LOCATION_ORDINAL(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","LOCATION_ORDINAL","I"),  Integer.valueOf(45));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f103_MAX_FORWARDS(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","MAX_FORWARDS","Ljava/lang/String;"), "Max-Forwards");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f104_MAX_FORWARDS_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","MAX_FORWARDS_BUFFER","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f105_MAX_FORWARDS_ORDINAL(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","MAX_FORWARDS_ORDINAL","I"),  Integer.valueOf(34));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f106_MIME_VERSION(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","MIME_VERSION","Ljava/lang/String;"), "MIME-Version");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f107_MIME_VERSION_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","MIME_VERSION_BUFFER","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f108_MIME_VERSION_ORDINAL(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","MIME_VERSION_ORDINAL","I"),  Integer.valueOf(55));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f109_PRAGMA(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","PRAGMA","Ljava/lang/String;"), "Pragma");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f110_PRAGMA_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","PRAGMA_BUFFER","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f111_PRAGMA_ORDINAL(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","PRAGMA_ORDINAL","I"),  Integer.valueOf(3));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f112_PROXY_AUTHENTICATE(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","PROXY_AUTHENTICATE","Ljava/lang/String;"), "Proxy-Authenticate");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f113_PROXY_AUTHENTICATE_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","PROXY_AUTHENTICATE_BUFFER","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f114_PROXY_AUTHENTICATE_ORDINAL(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","PROXY_AUTHENTICATE_ORDINAL","I"),  Integer.valueOf(46));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f115_PROXY_AUTHORIZATION(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","PROXY_AUTHORIZATION","Ljava/lang/String;"), "Proxy-Authorization");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f116_PROXY_AUTHORIZATION_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","PROXY_AUTHORIZATION_BUFFER","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f117_PROXY_AUTHORIZATION_ORDINAL(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","PROXY_AUTHORIZATION_ORDINAL","I"),  Integer.valueOf(35));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f118_PROXY_CONNECTION(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","PROXY_CONNECTION","Ljava/lang/String;"), "Proxy-Connection");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f119_PROXY_CONNECTION_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","PROXY_CONNECTION_BUFFER","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f120_PROXY_CONNECTION_ORDINAL(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","PROXY_CONNECTION_ORDINAL","I"),  Integer.valueOf(58));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f121_RANGE(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","RANGE","Ljava/lang/String;"), "Range");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f122_RANGE_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","RANGE_BUFFER","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f123_RANGE_ORDINAL(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","RANGE_ORDINAL","I"),  Integer.valueOf(36));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f124_REFERER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","REFERER","Ljava/lang/String;"), "Referer");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f125_REFERER_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","REFERER_BUFFER","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f126_REFERER_ORDINAL(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","REFERER_ORDINAL","I"),  Integer.valueOf(38));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f127_REQUEST_RANGE(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","REQUEST_RANGE","Ljava/lang/String;"), "Request-Range");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f128_REQUEST_RANGE_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","REQUEST_RANGE_BUFFER","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f129_REQUEST_RANGE_ORDINAL(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","REQUEST_RANGE_ORDINAL","I"),  Integer.valueOf(37));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f130_RETRY_AFTER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","RETRY_AFTER","Ljava/lang/String;"), "Retry-After");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f131_RETRY_AFTER_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","RETRY_AFTER_BUFFER","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f132_RETRY_AFTER_ORDINAL(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","RETRY_AFTER_ORDINAL","I"),  Integer.valueOf(47));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f133_SERVER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","SERVER","Ljava/lang/String;"), "Server");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f134_SERVER_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","SERVER_BUFFER","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f135_SERVER_ORDINAL(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","SERVER_ORDINAL","I"),  Integer.valueOf(48));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f136_SERVLET_ENGINE(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","SERVLET_ENGINE","Ljava/lang/String;"), "Servlet-Engine");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f137_SERVLET_ENGINE_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","SERVLET_ENGINE_BUFFER","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f138_SERVLET_ENGINE_ORDINAL(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","SERVLET_ENGINE_ORDINAL","I"),  Integer.valueOf(49));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f139_SET_COOKIE(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","SET_COOKIE","Ljava/lang/String;"), "Set-Cookie");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f140_SET_COOKIE2(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","SET_COOKIE2","Ljava/lang/String;"), "Set-Cookie2");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f141_SET_COOKIE2_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","SET_COOKIE2_BUFFER","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f142_SET_COOKIE2_ORDINAL(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","SET_COOKIE2_ORDINAL","I"),  Integer.valueOf(54));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f143_SET_COOKIE_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","SET_COOKIE_BUFFER","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f144_SET_COOKIE_ORDINAL(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","SET_COOKIE_ORDINAL","I"),  Integer.valueOf(53));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f145_TE(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","TE","Ljava/lang/String;"), "TE");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f146_TE_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","TE_BUFFER","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f147_TE_ORDINAL(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","TE_ORDINAL","I"),  Integer.valueOf(39));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f148_TRAILER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","TRAILER","Ljava/lang/String;"), "Trailer");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f149_TRAILER_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","TRAILER_BUFFER","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f150_TRAILER_ORDINAL(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","TRAILER_ORDINAL","I"),  Integer.valueOf(4));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f151_TRANSFER_ENCODING(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","TRANSFER_ENCODING","Ljava/lang/String;"), "Transfer-Encoding");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f152_TRANSFER_ENCODING_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","TRANSFER_ENCODING_BUFFER","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f153_TRANSFER_ENCODING_ORDINAL(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","TRANSFER_ENCODING_ORDINAL","I"),  Integer.valueOf(5));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f154_UPGRADE(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","UPGRADE","Ljava/lang/String;"), "Upgrade");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f155_UPGRADE_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","UPGRADE_BUFFER","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f156_UPGRADE_ORDINAL(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","UPGRADE_ORDINAL","I"),  Integer.valueOf(6));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f157_USER_AGENT(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","USER_AGENT","Ljava/lang/String;"), "User-Agent");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f158_USER_AGENT_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","USER_AGENT_BUFFER","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f159_USER_AGENT_ORDINAL(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","USER_AGENT_ORDINAL","I"),  Integer.valueOf(40));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f160_VARY(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","VARY","Ljava/lang/String;"), "Vary");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f161_VARY_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","VARY_BUFFER","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f162_VARY_ORDINAL(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","VARY_ORDINAL","I"),  Integer.valueOf(50));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f163_VIA(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","VIA","Ljava/lang/String;"), "Via");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f164_VIA_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","VIA_BUFFER","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f165_VIA_ORDINAL(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","VIA_ORDINAL","I"),  Integer.valueOf(7));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f166_WARNING(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","WARNING","Ljava/lang/String;"), "Warning");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f167_WARNING_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","WARNING_BUFFER","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f168_WARNING_ORDINAL(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","WARNING_ORDINAL","I"),  Integer.valueOf(8));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f169_WWW_AUTHENTICATE(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","WWW_AUTHENTICATE","Ljava/lang/String;"), "WWW-Authenticate");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f170_WWW_AUTHENTICATE_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","WWW_AUTHENTICATE_BUFFER","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f171_WWW_AUTHENTICATE_ORDINAL(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","WWW_AUTHENTICATE_ORDINAL","I"),  Integer.valueOf(51));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f172_X_FORWARDED_FOR(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","X_FORWARDED_FOR","Ljava/lang/String;"), "X-Forwarded-For");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f173_X_FORWARDED_FOR_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","X_FORWARDED_FOR_BUFFER","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f174_X_FORWARDED_FOR_ORDINAL(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaders;","X_FORWARDED_FOR_ORDINAL","I"),  Integer.valueOf(41));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__clinit_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/HttpHeaders;","<clinit>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(165,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(168,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(169,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(170,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(171,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(172,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(174,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(175,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(176,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(177,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(178,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(179,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(180,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(181,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(182,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(183,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(184,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(185,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(186,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(187,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(188,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(189,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(190,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(191,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(192,L24);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(193,L25);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(194,L26);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(195,L27);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(196,L28);
                DexLabel L29=new DexLabel();
                ddv.visitLineNumber(197,L29);
                DexLabel L30=new DexLabel();
                ddv.visitLineNumber(198,L30);
                DexLabel L31=new DexLabel();
                ddv.visitLineNumber(199,L31);
                DexLabel L32=new DexLabel();
                ddv.visitLineNumber(200,L32);
                DexLabel L33=new DexLabel();
                ddv.visitLineNumber(201,L33);
                DexLabel L34=new DexLabel();
                ddv.visitLineNumber(202,L34);
                DexLabel L35=new DexLabel();
                ddv.visitLineNumber(203,L35);
                DexLabel L36=new DexLabel();
                ddv.visitLineNumber(204,L36);
                DexLabel L37=new DexLabel();
                ddv.visitLineNumber(205,L37);
                DexLabel L38=new DexLabel();
                ddv.visitLineNumber(206,L38);
                DexLabel L39=new DexLabel();
                ddv.visitLineNumber(207,L39);
                DexLabel L40=new DexLabel();
                ddv.visitLineNumber(208,L40);
                DexLabel L41=new DexLabel();
                ddv.visitLineNumber(209,L41);
                DexLabel L42=new DexLabel();
                ddv.visitLineNumber(210,L42);
                DexLabel L43=new DexLabel();
                ddv.visitLineNumber(211,L43);
                DexLabel L44=new DexLabel();
                ddv.visitLineNumber(212,L44);
                DexLabel L45=new DexLabel();
                ddv.visitLineNumber(213,L45);
                DexLabel L46=new DexLabel();
                ddv.visitLineNumber(214,L46);
                DexLabel L47=new DexLabel();
                ddv.visitLineNumber(215,L47);
                DexLabel L48=new DexLabel();
                ddv.visitLineNumber(216,L48);
                DexLabel L49=new DexLabel();
                ddv.visitLineNumber(217,L49);
                DexLabel L50=new DexLabel();
                ddv.visitLineNumber(218,L50);
                DexLabel L51=new DexLabel();
                ddv.visitLineNumber(219,L51);
                DexLabel L52=new DexLabel();
                ddv.visitLineNumber(220,L52);
                DexLabel L53=new DexLabel();
                ddv.visitLineNumber(221,L53);
                DexLabel L54=new DexLabel();
                ddv.visitLineNumber(222,L54);
                DexLabel L55=new DexLabel();
                ddv.visitLineNumber(223,L55);
                DexLabel L56=new DexLabel();
                ddv.visitLineNumber(224,L56);
                DexLabel L57=new DexLabel();
                ddv.visitLineNumber(225,L57);
                DexLabel L58=new DexLabel();
                ddv.visitLineNumber(226,L58);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/jetty/HttpHeaders;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Lorg/mortbay/jetty/HttpHeaders;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","CACHE","Lorg/mortbay/jetty/HttpHeaders;"));
                code.visitLabel(L1);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","CACHE","Lorg/mortbay/jetty/HttpHeaders;"));
                code.visitConstStmt(CONST_STRING,1,"Host");
                code.visitConstStmt(CONST_16,2, Integer.valueOf(27)); // int: 0x0000001b  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Lorg/mortbay/jetty/HttpHeaders;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","HOST_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L2);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","CACHE","Lorg/mortbay/jetty/HttpHeaders;"));
                code.visitConstStmt(CONST_STRING,1,"Accept");
                code.visitConstStmt(CONST_16,2, Integer.valueOf(19)); // int: 0x00000013  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Lorg/mortbay/jetty/HttpHeaders;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","ACCEPT_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L3);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","CACHE","Lorg/mortbay/jetty/HttpHeaders;"));
                code.visitConstStmt(CONST_STRING,1,"Accept-Charset");
                code.visitConstStmt(CONST_16,2, Integer.valueOf(20)); // int: 0x00000014  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Lorg/mortbay/jetty/HttpHeaders;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","ACCEPT_CHARSET_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L4);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","CACHE","Lorg/mortbay/jetty/HttpHeaders;"));
                code.visitConstStmt(CONST_STRING,1,"Accept-Encoding");
                code.visitConstStmt(CONST_16,2, Integer.valueOf(21)); // int: 0x00000015  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Lorg/mortbay/jetty/HttpHeaders;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","ACCEPT_ENCODING_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L5);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","CACHE","Lorg/mortbay/jetty/HttpHeaders;"));
                code.visitConstStmt(CONST_STRING,1,"Accept-Language");
                code.visitConstStmt(CONST_16,2, Integer.valueOf(22)); // int: 0x00000016  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Lorg/mortbay/jetty/HttpHeaders;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","ACCEPT_LANGUAGE_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L6);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","CACHE","Lorg/mortbay/jetty/HttpHeaders;"));
                code.visitConstStmt(CONST_STRING,1,"Content-Length");
                code.visitConstStmt(CONST_16,2, Integer.valueOf(12)); // int: 0x0000000c  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Lorg/mortbay/jetty/HttpHeaders;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","CONTENT_LENGTH_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L7);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","CACHE","Lorg/mortbay/jetty/HttpHeaders;"));
                code.visitConstStmt(CONST_STRING,1,"Connection");
                code.visitConstStmt(CONST_4,2, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Lorg/mortbay/jetty/HttpHeaders;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","CONNECTION_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L8);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","CACHE","Lorg/mortbay/jetty/HttpHeaders;"));
                code.visitConstStmt(CONST_STRING,1,"Cache-Control");
                code.visitConstStmt(CONST_16,2, Integer.valueOf(57)); // int: 0x00000039  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Lorg/mortbay/jetty/HttpHeaders;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","CACHE_CONTROL_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L9);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","CACHE","Lorg/mortbay/jetty/HttpHeaders;"));
                code.visitConstStmt(CONST_STRING,1,"Date");
                code.visitConstStmt(CONST_4,2, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Lorg/mortbay/jetty/HttpHeaders;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","DATE_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L10);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","CACHE","Lorg/mortbay/jetty/HttpHeaders;"));
                code.visitConstStmt(CONST_STRING,1,"Pragma");
                code.visitConstStmt(CONST_4,2, Integer.valueOf(3)); // int: 0x00000003  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Lorg/mortbay/jetty/HttpHeaders;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","PRAGMA_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L11);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","CACHE","Lorg/mortbay/jetty/HttpHeaders;"));
                code.visitConstStmt(CONST_STRING,1,"Trailer");
                code.visitConstStmt(CONST_4,2, Integer.valueOf(4)); // int: 0x00000004  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Lorg/mortbay/jetty/HttpHeaders;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","TRAILER_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L12);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","CACHE","Lorg/mortbay/jetty/HttpHeaders;"));
                code.visitConstStmt(CONST_STRING,1,"Transfer-Encoding");
                code.visitConstStmt(CONST_4,2, Integer.valueOf(5)); // int: 0x00000005  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Lorg/mortbay/jetty/HttpHeaders;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","TRANSFER_ENCODING_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L13);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","CACHE","Lorg/mortbay/jetty/HttpHeaders;"));
                code.visitConstStmt(CONST_STRING,1,"Upgrade");
                code.visitConstStmt(CONST_4,2, Integer.valueOf(6)); // int: 0x00000006  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Lorg/mortbay/jetty/HttpHeaders;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","UPGRADE_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L14);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","CACHE","Lorg/mortbay/jetty/HttpHeaders;"));
                code.visitConstStmt(CONST_STRING,1,"Via");
                code.visitConstStmt(CONST_4,2, Integer.valueOf(7)); // int: 0x00000007  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Lorg/mortbay/jetty/HttpHeaders;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","VIA_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L15);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","CACHE","Lorg/mortbay/jetty/HttpHeaders;"));
                code.visitConstStmt(CONST_STRING,1,"Warning");
                code.visitConstStmt(CONST_16,2, Integer.valueOf(8)); // int: 0x00000008  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Lorg/mortbay/jetty/HttpHeaders;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","WARNING_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L16);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","CACHE","Lorg/mortbay/jetty/HttpHeaders;"));
                code.visitConstStmt(CONST_STRING,1,"Allow");
                code.visitConstStmt(CONST_16,2, Integer.valueOf(9)); // int: 0x00000009  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Lorg/mortbay/jetty/HttpHeaders;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","ALLOW_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L17);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","CACHE","Lorg/mortbay/jetty/HttpHeaders;"));
                code.visitConstStmt(CONST_STRING,1,"Content-Encoding");
                code.visitConstStmt(CONST_16,2, Integer.valueOf(10)); // int: 0x0000000a  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Lorg/mortbay/jetty/HttpHeaders;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","CONTENT_ENCODING_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L18);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","CACHE","Lorg/mortbay/jetty/HttpHeaders;"));
                code.visitConstStmt(CONST_STRING,1,"Content-Language");
                code.visitConstStmt(CONST_16,2, Integer.valueOf(11)); // int: 0x0000000b  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Lorg/mortbay/jetty/HttpHeaders;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","CONTENT_LANGUAGE_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L19);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","CACHE","Lorg/mortbay/jetty/HttpHeaders;"));
                code.visitConstStmt(CONST_STRING,1,"Content-Location");
                code.visitConstStmt(CONST_16,2, Integer.valueOf(13)); // int: 0x0000000d  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Lorg/mortbay/jetty/HttpHeaders;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","CONTENT_LOCATION_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L20);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","CACHE","Lorg/mortbay/jetty/HttpHeaders;"));
                code.visitConstStmt(CONST_STRING,1,"Content-MD5");
                code.visitConstStmt(CONST_16,2, Integer.valueOf(14)); // int: 0x0000000e  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Lorg/mortbay/jetty/HttpHeaders;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","CONTENT_MD5_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L21);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","CACHE","Lorg/mortbay/jetty/HttpHeaders;"));
                code.visitConstStmt(CONST_STRING,1,"Content-Range");
                code.visitConstStmt(CONST_16,2, Integer.valueOf(15)); // int: 0x0000000f  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Lorg/mortbay/jetty/HttpHeaders;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","CONTENT_RANGE_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L22);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","CACHE","Lorg/mortbay/jetty/HttpHeaders;"));
                code.visitConstStmt(CONST_STRING,1,"Content-Type");
                code.visitConstStmt(CONST_16,2, Integer.valueOf(16)); // int: 0x00000010  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Lorg/mortbay/jetty/HttpHeaders;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","CONTENT_TYPE_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L23);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","CACHE","Lorg/mortbay/jetty/HttpHeaders;"));
                code.visitConstStmt(CONST_STRING,1,"Expires");
                code.visitConstStmt(CONST_16,2, Integer.valueOf(17)); // int: 0x00000011  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Lorg/mortbay/jetty/HttpHeaders;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","EXPIRES_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L24);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","CACHE","Lorg/mortbay/jetty/HttpHeaders;"));
                code.visitConstStmt(CONST_STRING,1,"Last-Modified");
                code.visitConstStmt(CONST_16,2, Integer.valueOf(18)); // int: 0x00000012  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Lorg/mortbay/jetty/HttpHeaders;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","LAST_MODIFIED_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L25);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","CACHE","Lorg/mortbay/jetty/HttpHeaders;"));
                code.visitConstStmt(CONST_STRING,1,"Authorization");
                code.visitConstStmt(CONST_16,2, Integer.valueOf(23)); // int: 0x00000017  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Lorg/mortbay/jetty/HttpHeaders;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","AUTHORIZATION_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L26);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","CACHE","Lorg/mortbay/jetty/HttpHeaders;"));
                code.visitConstStmt(CONST_STRING,1,"Expect");
                code.visitConstStmt(CONST_16,2, Integer.valueOf(24)); // int: 0x00000018  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Lorg/mortbay/jetty/HttpHeaders;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","EXPECT_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L27);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","CACHE","Lorg/mortbay/jetty/HttpHeaders;"));
                code.visitConstStmt(CONST_STRING,1,"Forwarded");
                code.visitConstStmt(CONST_16,2, Integer.valueOf(25)); // int: 0x00000019  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Lorg/mortbay/jetty/HttpHeaders;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","FORWARDED_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L28);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","CACHE","Lorg/mortbay/jetty/HttpHeaders;"));
                code.visitConstStmt(CONST_STRING,1,"From");
                code.visitConstStmt(CONST_16,2, Integer.valueOf(26)); // int: 0x0000001a  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Lorg/mortbay/jetty/HttpHeaders;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","FROM_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L29);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","CACHE","Lorg/mortbay/jetty/HttpHeaders;"));
                code.visitConstStmt(CONST_STRING,1,"If-Match");
                code.visitConstStmt(CONST_16,2, Integer.valueOf(28)); // int: 0x0000001c  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Lorg/mortbay/jetty/HttpHeaders;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","IF_MATCH_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L30);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","CACHE","Lorg/mortbay/jetty/HttpHeaders;"));
                code.visitConstStmt(CONST_STRING,1,"If-Modified-Since");
                code.visitConstStmt(CONST_16,2, Integer.valueOf(29)); // int: 0x0000001d  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Lorg/mortbay/jetty/HttpHeaders;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","IF_MODIFIED_SINCE_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L31);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","CACHE","Lorg/mortbay/jetty/HttpHeaders;"));
                code.visitConstStmt(CONST_STRING,1,"If-None-Match");
                code.visitConstStmt(CONST_16,2, Integer.valueOf(30)); // int: 0x0000001e  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Lorg/mortbay/jetty/HttpHeaders;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","IF_NONE_MATCH_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L32);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","CACHE","Lorg/mortbay/jetty/HttpHeaders;"));
                code.visitConstStmt(CONST_STRING,1,"If-Range");
                code.visitConstStmt(CONST_16,2, Integer.valueOf(31)); // int: 0x0000001f  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Lorg/mortbay/jetty/HttpHeaders;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","IF_RANGE_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L33);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","CACHE","Lorg/mortbay/jetty/HttpHeaders;"));
                code.visitConstStmt(CONST_STRING,1,"If-Unmodified-Since");
                code.visitConstStmt(CONST_16,2, Integer.valueOf(32)); // int: 0x00000020  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Lorg/mortbay/jetty/HttpHeaders;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","IF_UNMODIFIED_SINCE_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L34);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","CACHE","Lorg/mortbay/jetty/HttpHeaders;"));
                code.visitConstStmt(CONST_STRING,1,"Keep-Alive");
                code.visitConstStmt(CONST_16,2, Integer.valueOf(33)); // int: 0x00000021  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Lorg/mortbay/jetty/HttpHeaders;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","KEEP_ALIVE_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L35);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","CACHE","Lorg/mortbay/jetty/HttpHeaders;"));
                code.visitConstStmt(CONST_STRING,1,"Max-Forwards");
                code.visitConstStmt(CONST_16,2, Integer.valueOf(34)); // int: 0x00000022  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Lorg/mortbay/jetty/HttpHeaders;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","MAX_FORWARDS_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L36);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","CACHE","Lorg/mortbay/jetty/HttpHeaders;"));
                code.visitConstStmt(CONST_STRING,1,"Proxy-Authorization");
                code.visitConstStmt(CONST_16,2, Integer.valueOf(35)); // int: 0x00000023  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Lorg/mortbay/jetty/HttpHeaders;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","PROXY_AUTHORIZATION_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L37);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","CACHE","Lorg/mortbay/jetty/HttpHeaders;"));
                code.visitConstStmt(CONST_STRING,1,"Range");
                code.visitConstStmt(CONST_16,2, Integer.valueOf(36)); // int: 0x00000024  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Lorg/mortbay/jetty/HttpHeaders;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","RANGE_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L38);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","CACHE","Lorg/mortbay/jetty/HttpHeaders;"));
                code.visitConstStmt(CONST_STRING,1,"Request-Range");
                code.visitConstStmt(CONST_16,2, Integer.valueOf(37)); // int: 0x00000025  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Lorg/mortbay/jetty/HttpHeaders;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","REQUEST_RANGE_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L39);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","CACHE","Lorg/mortbay/jetty/HttpHeaders;"));
                code.visitConstStmt(CONST_STRING,1,"Referer");
                code.visitConstStmt(CONST_16,2, Integer.valueOf(38)); // int: 0x00000026  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Lorg/mortbay/jetty/HttpHeaders;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","REFERER_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L40);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","CACHE","Lorg/mortbay/jetty/HttpHeaders;"));
                code.visitConstStmt(CONST_STRING,1,"TE");
                code.visitConstStmt(CONST_16,2, Integer.valueOf(39)); // int: 0x00000027  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Lorg/mortbay/jetty/HttpHeaders;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","TE_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L41);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","CACHE","Lorg/mortbay/jetty/HttpHeaders;"));
                code.visitConstStmt(CONST_STRING,1,"User-Agent");
                code.visitConstStmt(CONST_16,2, Integer.valueOf(40)); // int: 0x00000028  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Lorg/mortbay/jetty/HttpHeaders;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","USER_AGENT_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L42);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","CACHE","Lorg/mortbay/jetty/HttpHeaders;"));
                code.visitConstStmt(CONST_STRING,1,"X-Forwarded-For");
                code.visitConstStmt(CONST_16,2, Integer.valueOf(41)); // int: 0x00000029  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Lorg/mortbay/jetty/HttpHeaders;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","X_FORWARDED_FOR_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L43);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","CACHE","Lorg/mortbay/jetty/HttpHeaders;"));
                code.visitConstStmt(CONST_STRING,1,"Accept-Ranges");
                code.visitConstStmt(CONST_16,2, Integer.valueOf(42)); // int: 0x0000002a  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Lorg/mortbay/jetty/HttpHeaders;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","ACCEPT_RANGES_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L44);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","CACHE","Lorg/mortbay/jetty/HttpHeaders;"));
                code.visitConstStmt(CONST_STRING,1,"Age");
                code.visitConstStmt(CONST_16,2, Integer.valueOf(43)); // int: 0x0000002b  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Lorg/mortbay/jetty/HttpHeaders;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","AGE_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L45);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","CACHE","Lorg/mortbay/jetty/HttpHeaders;"));
                code.visitConstStmt(CONST_STRING,1,"ETag");
                code.visitConstStmt(CONST_16,2, Integer.valueOf(44)); // int: 0x0000002c  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Lorg/mortbay/jetty/HttpHeaders;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","ETAG_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L46);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","CACHE","Lorg/mortbay/jetty/HttpHeaders;"));
                code.visitConstStmt(CONST_STRING,1,"Location");
                code.visitConstStmt(CONST_16,2, Integer.valueOf(45)); // int: 0x0000002d  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Lorg/mortbay/jetty/HttpHeaders;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","LOCATION_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L47);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","CACHE","Lorg/mortbay/jetty/HttpHeaders;"));
                code.visitConstStmt(CONST_STRING,1,"Proxy-Authenticate");
                code.visitConstStmt(CONST_16,2, Integer.valueOf(46)); // int: 0x0000002e  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Lorg/mortbay/jetty/HttpHeaders;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","PROXY_AUTHENTICATE_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L48);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","CACHE","Lorg/mortbay/jetty/HttpHeaders;"));
                code.visitConstStmt(CONST_STRING,1,"Retry-After");
                code.visitConstStmt(CONST_16,2, Integer.valueOf(47)); // int: 0x0000002f  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Lorg/mortbay/jetty/HttpHeaders;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","RETRY_AFTER_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L49);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","CACHE","Lorg/mortbay/jetty/HttpHeaders;"));
                code.visitConstStmt(CONST_STRING,1,"Server");
                code.visitConstStmt(CONST_16,2, Integer.valueOf(48)); // int: 0x00000030  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Lorg/mortbay/jetty/HttpHeaders;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","SERVER_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L50);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","CACHE","Lorg/mortbay/jetty/HttpHeaders;"));
                code.visitConstStmt(CONST_STRING,1,"Servlet-Engine");
                code.visitConstStmt(CONST_16,2, Integer.valueOf(49)); // int: 0x00000031  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Lorg/mortbay/jetty/HttpHeaders;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","SERVLET_ENGINE_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L51);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","CACHE","Lorg/mortbay/jetty/HttpHeaders;"));
                code.visitConstStmt(CONST_STRING,1,"Vary");
                code.visitConstStmt(CONST_16,2, Integer.valueOf(50)); // int: 0x00000032  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Lorg/mortbay/jetty/HttpHeaders;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","VARY_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L52);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","CACHE","Lorg/mortbay/jetty/HttpHeaders;"));
                code.visitConstStmt(CONST_STRING,1,"WWW-Authenticate");
                code.visitConstStmt(CONST_16,2, Integer.valueOf(51)); // int: 0x00000033  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Lorg/mortbay/jetty/HttpHeaders;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","WWW_AUTHENTICATE_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L53);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","CACHE","Lorg/mortbay/jetty/HttpHeaders;"));
                code.visitConstStmt(CONST_STRING,1,"Cookie");
                code.visitConstStmt(CONST_16,2, Integer.valueOf(52)); // int: 0x00000034  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Lorg/mortbay/jetty/HttpHeaders;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","COOKIE_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L54);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","CACHE","Lorg/mortbay/jetty/HttpHeaders;"));
                code.visitConstStmt(CONST_STRING,1,"Set-Cookie");
                code.visitConstStmt(CONST_16,2, Integer.valueOf(53)); // int: 0x00000035  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Lorg/mortbay/jetty/HttpHeaders;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","SET_COOKIE_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L55);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","CACHE","Lorg/mortbay/jetty/HttpHeaders;"));
                code.visitConstStmt(CONST_STRING,1,"Set-Cookie2");
                code.visitConstStmt(CONST_16,2, Integer.valueOf(54)); // int: 0x00000036  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Lorg/mortbay/jetty/HttpHeaders;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","SET_COOKIE2_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L56);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","CACHE","Lorg/mortbay/jetty/HttpHeaders;"));
                code.visitConstStmt(CONST_STRING,1,"MIME-Version");
                code.visitConstStmt(CONST_16,2, Integer.valueOf(55)); // int: 0x00000037  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Lorg/mortbay/jetty/HttpHeaders;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","MIME_VERSION_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L57);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","CACHE","Lorg/mortbay/jetty/HttpHeaders;"));
                code.visitConstStmt(CONST_STRING,1,"identity");
                code.visitConstStmt(CONST_16,2, Integer.valueOf(56)); // int: 0x00000038  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Lorg/mortbay/jetty/HttpHeaders;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","IDENTITY_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L58);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","CACHE","Lorg/mortbay/jetty/HttpHeaders;"));
                code.visitConstStmt(CONST_STRING,1,"Proxy-Connection");
                code.visitConstStmt(CONST_16,2, Integer.valueOf(58)); // int: 0x0000003a  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Lorg/mortbay/jetty/HttpHeaders;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","PROXY_CONNECTION_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/HttpHeaders;","<init>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(25,L0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Lorg/mortbay/io/BufferCache;","<init>",new String[]{ },"V"));
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
