package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0326_org_mortbay_jetty_servlet_Dispatcher {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/jetty/servlet/Dispatcher;","Ljava/lang/Object;",new String[]{ "Ljavax/servlet/RequestDispatcher;"});
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("Dispatcher.java");
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/MemberClasses;", Visibility.SYSTEM);
            if(av00 != null) {
                {
                    DexAnnotationVisitor av01 = av00.visitArray("value");
                    if(av01 != null) {
                        av01.visit(null, new DexType("Lorg/mortbay/jetty/servlet/Dispatcher$IncludeAttributes;"));
                        av01.visit(null, new DexType("Lorg/mortbay/jetty/servlet/Dispatcher$ForwardAttributes;"));
                        av01.visitEnd();
                    }
                }
                av00.visitEnd();
            }
        }
        f000___FORWARD_CONTEXT_PATH(cv);
        f001___FORWARD_JETTY(cv);
        f002___FORWARD_PATH_INFO(cv);
        f003___FORWARD_PREFIX(cv);
        f004___FORWARD_QUERY_STRING(cv);
        f005___FORWARD_REQUEST_URI(cv);
        f006___FORWARD_SERVLET_PATH(cv);
        f007___INCLUDE_CONTEXT_PATH(cv);
        f008___INCLUDE_JETTY(cv);
        f009___INCLUDE_PATH_INFO(cv);
        f010___INCLUDE_PREFIX(cv);
        f011___INCLUDE_QUERY_STRING(cv);
        f012___INCLUDE_REQUEST_URI(cv);
        f013___INCLUDE_SERVLET_PATH(cv);
        f014___JSP_FILE(cv);
        f015__contextHandler(cv);
        f016__dQuery(cv);
        f017__named(cv);
        f018__path(cv);
        f019__uri(cv);
        m000__init_(cv);
        m001__init_(cv);
        m002_access$000(cv);
        m003_type(cv);
        m004_error(cv);
        m005_forward(cv);
        m006_forward(cv);
        m007_include(cv);
    }
    public static void f000___FORWARD_CONTEXT_PATH(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/servlet/Dispatcher;","__FORWARD_CONTEXT_PATH","Ljava/lang/String;"), "javax.servlet.forward.context_path");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001___FORWARD_JETTY(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/servlet/Dispatcher;","__FORWARD_JETTY","Ljava/lang/String;"), "org.mortbay.jetty.forwarded");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002___FORWARD_PATH_INFO(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/servlet/Dispatcher;","__FORWARD_PATH_INFO","Ljava/lang/String;"), "javax.servlet.forward.path_info");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003___FORWARD_PREFIX(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/servlet/Dispatcher;","__FORWARD_PREFIX","Ljava/lang/String;"), "javax.servlet.forward.");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f004___FORWARD_QUERY_STRING(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/servlet/Dispatcher;","__FORWARD_QUERY_STRING","Ljava/lang/String;"), "javax.servlet.forward.query_string");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f005___FORWARD_REQUEST_URI(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/servlet/Dispatcher;","__FORWARD_REQUEST_URI","Ljava/lang/String;"), "javax.servlet.forward.request_uri");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f006___FORWARD_SERVLET_PATH(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/servlet/Dispatcher;","__FORWARD_SERVLET_PATH","Ljava/lang/String;"), "javax.servlet.forward.servlet_path");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f007___INCLUDE_CONTEXT_PATH(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/servlet/Dispatcher;","__INCLUDE_CONTEXT_PATH","Ljava/lang/String;"), "javax.servlet.include.context_path");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f008___INCLUDE_JETTY(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/servlet/Dispatcher;","__INCLUDE_JETTY","Ljava/lang/String;"), "org.mortbay.jetty.included");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f009___INCLUDE_PATH_INFO(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/servlet/Dispatcher;","__INCLUDE_PATH_INFO","Ljava/lang/String;"), "javax.servlet.include.path_info");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f010___INCLUDE_PREFIX(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/servlet/Dispatcher;","__INCLUDE_PREFIX","Ljava/lang/String;"), "javax.servlet.include.");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f011___INCLUDE_QUERY_STRING(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/servlet/Dispatcher;","__INCLUDE_QUERY_STRING","Ljava/lang/String;"), "javax.servlet.include.query_string");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f012___INCLUDE_REQUEST_URI(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/servlet/Dispatcher;","__INCLUDE_REQUEST_URI","Ljava/lang/String;"), "javax.servlet.include.request_uri");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f013___INCLUDE_SERVLET_PATH(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/servlet/Dispatcher;","__INCLUDE_SERVLET_PATH","Ljava/lang/String;"), "javax.servlet.include.servlet_path");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f014___JSP_FILE(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/servlet/Dispatcher;","__JSP_FILE","Ljava/lang/String;"), "org.apache.catalina.jsp_file");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f015__contextHandler(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/servlet/Dispatcher;","_contextHandler","Lorg/mortbay/jetty/handler/ContextHandler;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f016__dQuery(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/servlet/Dispatcher;","_dQuery","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f017__named(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/servlet/Dispatcher;","_named","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f018__path(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/servlet/Dispatcher;","_path","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f019__uri(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/servlet/Dispatcher;","_uri","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/servlet/Dispatcher;","<init>",new String[]{ "Lorg/mortbay/jetty/handler/ContextHandler;","Ljava/lang/String;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/IllegalStateException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"contextHandler");
                ddv.visitParameterName(1,"name");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(115,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(116,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(117,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(118,L3);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/Object;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/servlet/Dispatcher;","_contextHandler","Lorg/mortbay/jetty/handler/ContextHandler;"));
                code.visitLabel(L2);
                code.visitFieldStmt(IPUT_OBJECT,2,0,new Field("Lorg/mortbay/jetty/servlet/Dispatcher;","_named","Ljava/lang/String;"));
                code.visitLabel(L3);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/servlet/Dispatcher;","<init>",new String[]{ "Lorg/mortbay/jetty/handler/ContextHandler;","Ljava/lang/String;","Ljava/lang/String;","Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"contextHandler");
                ddv.visitParameterName(1,"uri");
                ddv.visitParameterName(2,"pathInContext");
                ddv.visitParameterName(3,"query");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(100,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(101,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(102,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(103,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(104,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(105,L5);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/Object;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/servlet/Dispatcher;","_contextHandler","Lorg/mortbay/jetty/handler/ContextHandler;"));
                code.visitLabel(L2);
                code.visitFieldStmt(IPUT_OBJECT,2,0,new Field("Lorg/mortbay/jetty/servlet/Dispatcher;","_uri","Ljava/lang/String;"));
                code.visitLabel(L3);
                code.visitFieldStmt(IPUT_OBJECT,3,0,new Field("Lorg/mortbay/jetty/servlet/Dispatcher;","_path","Ljava/lang/String;"));
                code.visitLabel(L4);
                code.visitFieldStmt(IPUT_OBJECT,4,0,new Field("Lorg/mortbay/jetty/servlet/Dispatcher;","_dQuery","Ljava/lang/String;"));
                code.visitLabel(L5);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_access$000(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_SYNTHETIC, new Method("Lorg/mortbay/jetty/servlet/Dispatcher;","access$000",new String[]{ "Lorg/mortbay/jetty/servlet/Dispatcher;"},"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"x0");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(45,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/servlet/Dispatcher;","_named","Ljava/lang/String;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_type(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/jetty/servlet/Dispatcher;","type",new String[]{ "Ljava/lang/String;"},"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"type");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(73,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(74,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(80,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(75,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(76,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(77,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(78,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(79,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(80,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(81,L9);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_STRING,0,"request");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/String;","equalsIgnoreCase",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L3);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L2);
                code.visitStmt1R(RETURN,0);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_STRING,0,"forward");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/String;","equalsIgnoreCase",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L5);
                code.visitLabel(L4);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L5);
                code.visitConstStmt(CONST_STRING,0,"include");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/String;","equalsIgnoreCase",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L7);
                code.visitLabel(L6);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(4)); // int: 0x00000004  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L7);
                code.visitConstStmt(CONST_STRING,0,"error");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/String;","equalsIgnoreCase",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L9);
                code.visitLabel(L8);
                code.visitConstStmt(CONST_16,0, Integer.valueOf(8)); // int: 0x00000008  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L9);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/IllegalArgumentException;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Ljava/lang/IllegalArgumentException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_error(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/Dispatcher;","error",new String[]{ "Ljavax/servlet/ServletRequest;","Ljavax/servlet/ServletResponse;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljavax/servlet/ServletException;"));
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"request");
                ddv.visitParameterName(1,"response");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(135,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(136,L1);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_16,0, Integer.valueOf(8)); // int: 0x00000008  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2,3,0},new Method("Lorg/mortbay/jetty/servlet/Dispatcher;","forward",new String[]{ "Ljavax/servlet/ServletRequest;","Ljavax/servlet/ServletResponse;","I"},"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_forward(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/Dispatcher;","forward",new String[]{ "Ljavax/servlet/ServletRequest;","Ljavax/servlet/ServletResponse;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljavax/servlet/ServletException;"));
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"request");
                ddv.visitParameterName(1,"response");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(126,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(127,L1);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2,3,0},new Method("Lorg/mortbay/jetty/servlet/Dispatcher;","forward",new String[]{ "Ljavax/servlet/ServletRequest;","Ljavax/servlet/ServletResponse;","I"},"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_forward(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/servlet/Dispatcher;","forward",new String[]{ "Ljavax/servlet/ServletRequest;","Ljavax/servlet/ServletResponse;","I"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljavax/servlet/ServletException;"));
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(32);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L2},new String[]{ null});
                DexLabel L5=new DexLabel();
                DexLabel L6=new DexLabel();
                DexLabel L7=new DexLabel();
                code.visitTryCatch(L5,L6,new DexLabel[]{L7,L2},new String[]{ "Ljava/lang/IllegalStateException;",null});
                DexLabel L8=new DexLabel();
                DexLabel L9=new DexLabel();
                code.visitTryCatch(L8,L9,new DexLabel[]{L2},new String[]{ null});
                DexLabel L10=new DexLabel();
                DexLabel L11=new DexLabel();
                code.visitTryCatch(L10,L11,new DexLabel[]{L2},new String[]{ null});
                DexLabel L12=new DexLabel();
                DexLabel L13=new DexLabel();
                DexLabel L14=new DexLabel();
                code.visitTryCatch(L12,L13,new DexLabel[]{L14,L2},new String[]{ "Ljava/lang/IllegalStateException;",null});
                DexLabel L15=new DexLabel();
                DexLabel L16=new DexLabel();
                code.visitTryCatch(L15,L16,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"request");
                ddv.visitParameterName(1,"response");
                ddv.visitParameterName(2,"dispatch");
                DexLabel L17=new DexLabel();
                ddv.visitPrologue(L17);
                ddv.visitLineNumber(210,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(211,L18);
                ddv.visitStartLocal(6,L18,"base_request","Lorg/mortbay/jetty/Request;",null);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(212,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(214,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(215,L21);
                ddv.visitStartLocal(18,L21,"old_uri","Ljava/lang/String;",null);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(216,L22);
                ddv.visitStartLocal(13,L22,"old_context_path","Ljava/lang/String;",null);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(217,L23);
                ddv.visitStartLocal(17,L23,"old_servlet_path","Ljava/lang/String;",null);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(218,L24);
                ddv.visitStartLocal(15,L24,"old_path_info","Ljava/lang/String;",null);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(219,L25);
                ddv.visitStartLocal(16,L25,"old_query","Ljava/lang/String;",null);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(220,L26);
                ddv.visitStartLocal(12,L26,"old_attr","Lorg/mortbay/util/Attributes;",null);
                ddv.visitLineNumber(223,L0);
                ddv.visitStartLocal(14,L0,"old_params","Lorg/mortbay/util/MultiMap;",null);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(224,L27);
                DexLabel L28=new DexLabel();
                ddv.visitEndLocal(29,L28);
                DexLabel L29=new DexLabel();
                ddv.visitEndLocal(30,L29);
                ddv.visitLineNumber(350,L1);
                DexLabel L30=new DexLabel();
                ddv.visitLineNumber(351,L30);
                DexLabel L31=new DexLabel();
                ddv.visitLineNumber(352,L31);
                DexLabel L32=new DexLabel();
                ddv.visitLineNumber(353,L32);
                DexLabel L33=new DexLabel();
                ddv.visitLineNumber(354,L33);
                DexLabel L34=new DexLabel();
                ddv.visitLineNumber(355,L34);
                DexLabel L35=new DexLabel();
                ddv.visitLineNumber(356,L35);
                DexLabel L36=new DexLabel();
                ddv.visitLineNumber(358,L36);
                DexLabel L37=new DexLabel();
                ddv.visitLineNumber(210,L37);
                ddv.visitEndLocal(6,L37);
                ddv.visitEndLocal(18,L37);
                ddv.visitEndLocal(13,L37);
                ddv.visitEndLocal(17,L37);
                ddv.visitEndLocal(15,L37);
                ddv.visitEndLocal(16,L37);
                ddv.visitEndLocal(12,L37);
                ddv.visitEndLocal(14,L37);
                ddv.visitRestartLocal(29,L37);
                ddv.visitRestartLocal(30,L37);
                ddv.visitLineNumber(227,L3);
                ddv.visitRestartLocal(6,L3);
                ddv.visitRestartLocal(12,L3);
                ddv.visitRestartLocal(13,L3);
                ddv.visitRestartLocal(14,L3);
                ddv.visitRestartLocal(15,L3);
                ddv.visitRestartLocal(16,L3);
                ddv.visitRestartLocal(17,L3);
                ddv.visitRestartLocal(18,L3);
                DexLabel L38=new DexLabel();
                ddv.visitLineNumber(229,L38);
                ddv.visitStartLocal(23,L38,"query","Ljava/lang/String;",null);
                DexLabel L39=new DexLabel();
                ddv.visitLineNumber(231,L39);
                DexLabel L40=new DexLabel();
                ddv.visitLineNumber(232,L40);
                ddv.visitStartLocal(22,L40,"parameters","Lorg/mortbay/util/MultiMap;",null);
                DexLabel L41=new DexLabel();
                ddv.visitLineNumber(234,L41);
                DexLabel L42=new DexLabel();
                ddv.visitLineNumber(236,L42);
                ddv.visitStartLocal(24,L42,"rewrite_old_query","Z",null);
                DexLabel L43=new DexLabel();
                ddv.visitLineNumber(238,L43);
                DexLabel L44=new DexLabel();
                ddv.visitLineNumber(239,L44);
                DexLabel L45=new DexLabel();
                ddv.visitLineNumber(242,L45);
                ddv.visitRestartLocal(14,L45);
                DexLabel L46=new DexLabel();
                ddv.visitLineNumber(245,L46);
                DexLabel L47=new DexLabel();
                ddv.visitLineNumber(246,L47);
                ddv.visitStartLocal(10,L47,"iter","Ljava/util/Iterator;",null);
                DexLabel L48=new DexLabel();
                ddv.visitLineNumber(248,L48);
                DexLabel L49=new DexLabel();
                ddv.visitLineNumber(249,L49);
                ddv.visitStartLocal(8,L49,"entry","Ljava/util/Map$Entry;",null);
                DexLabel L50=new DexLabel();
                ddv.visitLineNumber(251,L50);
                ddv.visitStartLocal(11,L50,"name","Ljava/lang/String;",null);
                DexLabel L51=new DexLabel();
                ddv.visitLineNumber(253,L51);
                DexLabel L52=new DexLabel();
                ddv.visitLineNumber(257,L52);
                DexLabel L53=new DexLabel();
                ddv.visitLineNumber(258,L53);
                ddv.visitStartLocal(25,L53,"values","Ljava/lang/Object;",null);
                DexLabel L54=new DexLabel();
                ddv.visitStartLocal(9,L54,"i","I",null);
                DexLabel L55=new DexLabel();
                ddv.visitLineNumber(260,L55);
                DexLabel L56=new DexLabel();
                ddv.visitLineNumber(258,L56);
                DexLabel L57=new DexLabel();
                ddv.visitLineNumber(266,L57);
                ddv.visitEndLocal(10,L57);
                ddv.visitEndLocal(8,L57);
                ddv.visitEndLocal(11,L57);
                ddv.visitEndLocal(25,L57);
                ddv.visitEndLocal(9,L57);
                DexLabel L58=new DexLabel();
                ddv.visitLineNumber(268,L58);
                DexLabel L59=new DexLabel();
                ddv.visitLineNumber(270,L59);
                DexLabel L60=new DexLabel();
                ddv.visitLineNumber(271,L60);
                ddv.visitStartLocal(21,L60,"overridden_query_string","Ljava/lang/StringBuffer;",null);
                DexLabel L61=new DexLabel();
                ddv.visitLineNumber(272,L61);
                ddv.visitStartLocal(20,L61,"overridden_old_query","Lorg/mortbay/util/MultiMap;",null);
                DexLabel L62=new DexLabel();
                ddv.visitLineNumber(274,L62);
                DexLabel L63=new DexLabel();
                ddv.visitLineNumber(275,L63);
                ddv.visitStartLocal(19,L63,"overridden_new_query","Lorg/mortbay/util/MultiMap;",null);
                DexLabel L64=new DexLabel();
                ddv.visitLineNumber(277,L64);
                DexLabel L65=new DexLabel();
                ddv.visitLineNumber(278,L65);
                ddv.visitRestartLocal(10,L65);
                DexLabel L66=new DexLabel();
                ddv.visitLineNumber(280,L66);
                DexLabel L67=new DexLabel();
                ddv.visitLineNumber(281,L67);
                ddv.visitRestartLocal(8,L67);
                DexLabel L68=new DexLabel();
                ddv.visitLineNumber(282,L68);
                ddv.visitRestartLocal(11,L68);
                DexLabel L69=new DexLabel();
                ddv.visitLineNumber(284,L69);
                DexLabel L70=new DexLabel();
                ddv.visitLineNumber(285,L70);
                ddv.visitRestartLocal(25,L70);
                DexLabel L71=new DexLabel();
                ddv.visitRestartLocal(9,L71);
                DexLabel L72=new DexLabel();
                ddv.visitLineNumber(287,L72);
                DexLabel L73=new DexLabel();
                ddv.visitLineNumber(285,L73);
                DexLabel L74=new DexLabel();
                ddv.visitLineNumber(292,L74);
                ddv.visitEndLocal(8,L74);
                ddv.visitEndLocal(11,L74);
                ddv.visitEndLocal(25,L74);
                ddv.visitEndLocal(9,L74);
                DexLabel L75=new DexLabel();
                ddv.visitLineNumber(300,L75);
                ddv.visitEndLocal(21,L75);
                ddv.visitEndLocal(20,L75);
                ddv.visitEndLocal(19,L75);
                ddv.visitEndLocal(10,L75);
                DexLabel L76=new DexLabel();
                ddv.visitLineNumber(301,L76);
                DexLabel L77=new DexLabel();
                ddv.visitLineNumber(304,L77);
                ddv.visitEndLocal(22,L77);
                ddv.visitEndLocal(24,L77);
                DexLabel L78=new DexLabel();
                ddv.visitLineNumber(310,L78);
                ddv.visitStartLocal(5,L78,"attr","Lorg/mortbay/jetty/servlet/Dispatcher$ForwardAttributes;",null);
                DexLabel L79=new DexLabel();
                ddv.visitLineNumber(312,L79);
                DexLabel L80=new DexLabel();
                ddv.visitLineNumber(313,L80);
                DexLabel L81=new DexLabel();
                ddv.visitLineNumber(314,L81);
                DexLabel L82=new DexLabel();
                ddv.visitLineNumber(315,L82);
                DexLabel L83=new DexLabel();
                ddv.visitLineNumber(316,L83);
                DexLabel L84=new DexLabel();
                ddv.visitLineNumber(329,L84);
                DexLabel L85=new DexLabel();
                ddv.visitLineNumber(330,L85);
                DexLabel L86=new DexLabel();
                ddv.visitLineNumber(331,L86);
                DexLabel L87=new DexLabel();
                ddv.visitLineNumber(332,L87);
                DexLabel L88=new DexLabel();
                ddv.visitLineNumber(334,L88);
                DexLabel L89=new DexLabel();
                ddv.visitEndLocal(29,L89);
                DexLabel L90=new DexLabel();
                ddv.visitEndLocal(5,L90);
                DexLabel L91=new DexLabel();
                ddv.visitLineNumber(336,L91);
                ddv.visitLineNumber(338,L5);
                ddv.visitLineNumber(339,L7);
                ddv.visitStartLocal(7,L8,"e","Ljava/lang/IllegalStateException;",null);
                ddv.visitLineNumber(350,L2);
                ddv.visitEndLocal(30,L2);
                ddv.visitEndLocal(23,L2);
                ddv.visitEndLocal(7,L2);
                DexLabel L92=new DexLabel();
                ddv.visitLineNumber(351,L92);
                DexLabel L93=new DexLabel();
                ddv.visitLineNumber(352,L93);
                DexLabel L94=new DexLabel();
                ddv.visitLineNumber(353,L94);
                DexLabel L95=new DexLabel();
                ddv.visitLineNumber(354,L95);
                DexLabel L96=new DexLabel();
                ddv.visitLineNumber(355,L96);
                DexLabel L97=new DexLabel();
                ddv.visitLineNumber(356,L97);
                DexLabel L98=new DexLabel();
                ddv.visitLineNumber(350,L98);
                ddv.visitLineNumber(296,L10);
                ddv.visitRestartLocal(22,L10);
                ddv.visitRestartLocal(23,L10);
                ddv.visitRestartLocal(24,L10);
                ddv.visitRestartLocal(29,L10);
                ddv.visitRestartLocal(30,L10);
                DexLabel L99=new DexLabel();
                ddv.visitRestartLocal(23,L99);
                DexLabel L100=new DexLabel();
                ddv.visitLineNumber(320,L100);
                ddv.visitEndLocal(22,L100);
                ddv.visitEndLocal(24,L100);
                ddv.visitRestartLocal(5,L100);
                DexLabel L101=new DexLabel();
                ddv.visitLineNumber(321,L101);
                DexLabel L102=new DexLabel();
                ddv.visitLineNumber(322,L102);
                DexLabel L103=new DexLabel();
                ddv.visitLineNumber(323,L103);
                DexLabel L104=new DexLabel();
                ddv.visitLineNumber(324,L104);
                ddv.visitLineNumber(343,L12);
                ddv.visitEndLocal(29,L12);
                ddv.visitEndLocal(5,L12);
                ddv.visitLineNumber(344,L14);
                ddv.visitRestartLocal(7,L15);
                code.visitLabel(L17);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,29);
                code.visitTypeStmt(INSTANCE_OF,0,0,"Lorg/mortbay/jetty/Request;");
                code.visitStmt2R(MOVE_FROM16,26,0);
                code.visitJumpStmt(IF_EQZ,26,-1,L37);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,29);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Lorg/mortbay/jetty/Request;");
                code.visitStmt2R(MOVE_OBJECT,5,0);
                code.visitStmt2R(MOVE_OBJECT,6,5);
                code.visitLabel(L18);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 30},new Method("Ljavax/servlet/ServletResponse;","resetBuffer",new String[]{ },"V"));
                code.visitLabel(L19);
                code.visitConstStmt(CONST_STRING,26,"org.apache.catalina.jsp_file");
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,29);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,26);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1},new Method("Ljavax/servlet/ServletRequest;","removeAttribute",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L20);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/Request;","getRequestURI",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,18);
                code.visitLabel(L21);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/Request;","getContextPath",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,13);
                code.visitLabel(L22);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/Request;","getServletPath",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,17);
                code.visitLabel(L23);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/Request;","getPathInfo",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,15);
                code.visitLabel(L24);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/Request;","getQueryString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,16);
                code.visitLabel(L25);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/Request;","getAttributes",new String[]{ },"Lorg/mortbay/util/Attributes;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,12);
                code.visitLabel(L26);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/Request;","getParameters",new String[]{ },"Lorg/mortbay/util/MultiMap;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,14);
                code.visitLabel(L0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,28);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/servlet/Dispatcher;","_named","Ljava/lang/String;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,26,0);
                code.visitJumpStmt(IF_EQZ,26,-1,L3);
                code.visitLabel(L27);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,28);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/servlet/Dispatcher;","_contextHandler","Lorg/mortbay/jetty/handler/ContextHandler;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,26,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,28);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/servlet/Dispatcher;","_named","Ljava/lang/String;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,27,0);
                code.visitTypeStmt(CHECK_CAST,29,-1,"Ljavax/servlet/http/HttpServletRequest;");
                code.visitLabel(L28);
                code.visitTypeStmt(CHECK_CAST,30,-1,"Ljavax/servlet/http/HttpServletResponse;");
                code.visitLabel(L29);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,26);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,27);
                code.visitStmt2R(MOVE_OBJECT_FROM16,2,29);
                code.visitStmt2R(MOVE_OBJECT_FROM16,3,30);
                code.visitStmt2R(MOVE_FROM16,4,31);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2,3,4},new Method("Lorg/mortbay/jetty/handler/ContextHandler;","handle",new String[]{ "Ljava/lang/String;","Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;","I"},"V"));
                code.visitLabel(L1);
                code.visitStmt2R(MOVE_OBJECT,0,6);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,18);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/Request;","setRequestURI",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L30);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,13},new Method("Lorg/mortbay/jetty/Request;","setContextPath",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L31);
                code.visitStmt2R(MOVE_OBJECT,0,6);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,17);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/Request;","setServletPath",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L32);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,15},new Method("Lorg/mortbay/jetty/Request;","setPathInfo",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L33);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,12},new Method("Lorg/mortbay/jetty/Request;","setAttributes",new String[]{ "Lorg/mortbay/util/Attributes;"},"V"));
                code.visitLabel(L34);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,14},new Method("Lorg/mortbay/jetty/Request;","setParameters",new String[]{ "Lorg/mortbay/util/MultiMap;"},"V"));
                code.visitLabel(L35);
                code.visitStmt2R(MOVE_OBJECT,0,6);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,16);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/Request;","setQueryString",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L36);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L37);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/jetty/HttpConnection;","getCurrentConnection",new String[]{ },"Lorg/mortbay/jetty/HttpConnection;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,26);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 26},new Method("Lorg/mortbay/jetty/HttpConnection;","getRequest",new String[]{ },"Lorg/mortbay/jetty/Request;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,26);
                code.visitStmt2R(MOVE_OBJECT_FROM16,6,26);
                code.visitJumpStmt(GOTO,-1,-1,L18);
                code.visitLabel(L3);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,28);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/servlet/Dispatcher;","_dQuery","Ljava/lang/String;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,23,0);
                code.visitLabel(L38);
                code.visitJumpStmt(IF_EQZ,23,-1,L77);
                code.visitLabel(L39);
                code.visitTypeStmt(NEW_INSTANCE,22,-1,"Lorg/mortbay/util/MultiMap;");
                code.visitMethodStmt(INVOKE_DIRECT_RANGE,new int[]{ 22},new Method("Lorg/mortbay/util/MultiMap;","<init>",new String[]{ },"V"));
                code.visitLabel(L40);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 29},new Method("Ljavax/servlet/ServletRequest;","getCharacterEncoding",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,26);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,23);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,2,26);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,1,2},new Method("Lorg/mortbay/util/UrlEncoded;","decodeTo",new String[]{ "Ljava/lang/String;","Lorg/mortbay/util/MultiMap;","Ljava/lang/String;"},"V"));
                code.visitLabel(L41);
                code.visitConstStmt(CONST_16,24, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L42);
                code.visitJumpStmt(IF_NEZ,14,-1,L45);
                code.visitLabel(L43);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/Request;","getParameterNames",new String[]{ },"Ljava/util/Enumeration;"));
                code.visitLabel(L44);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/Request;","getParameters",new String[]{ },"Lorg/mortbay/util/MultiMap;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,14);
                code.visitLabel(L45);
                code.visitJumpStmt(IF_EQZ,14,-1,L57);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 14},new Method("Lorg/mortbay/util/MultiMap;","size",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,26);
                code.visitJumpStmt(IF_LEZ,26,-1,L57);
                code.visitLabel(L46);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 14},new Method("Lorg/mortbay/util/MultiMap;","entrySet",new String[]{ },"Ljava/util/Set;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,26);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 26},new Method("Ljava/util/Set;","iterator",new String[]{ },"Ljava/util/Iterator;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,10);
                code.visitLabel(L47);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 10},new Method("Ljava/util/Iterator;","hasNext",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,26);
                code.visitJumpStmt(IF_EQZ,26,-1,L57);
                code.visitLabel(L48);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 10},new Method("Ljava/util/Iterator;","next",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitTypeStmt(CHECK_CAST,8,-1,"Ljava/util/Map$Entry;");
                code.visitLabel(L49);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 8},new Method("Ljava/util/Map$Entry;","getKey",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,11);
                code.visitTypeStmt(CHECK_CAST,11,-1,"Ljava/lang/String;");
                code.visitLabel(L50);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,22);
                code.visitStmt2R(MOVE_OBJECT,1,11);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/util/MultiMap;","containsKey",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,26);
                code.visitJumpStmt(IF_EQZ,26,-1,L52);
                code.visitLabel(L51);
                code.visitConstStmt(CONST_16,24, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L47);
                code.visitLabel(L52);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 8},new Method("Ljava/util/Map$Entry;","getValue",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,25);
                code.visitLabel(L53);
                code.visitConstStmt(CONST_4,9, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L54);
                code.visitMethodStmt(INVOKE_STATIC_RANGE,new int[]{ 25},new Method("Lorg/mortbay/util/LazyList;","size",new String[]{ "Ljava/lang/Object;"},"I"));
                code.visitStmt1R(MOVE_RESULT,26);
                code.visitStmt2R(MOVE,0,9);
                code.visitStmt2R(MOVE_FROM16,1,26);
                code.visitJumpStmt(IF_GE,0,1,L47);
                code.visitLabel(L55);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,25);
                code.visitStmt2R(MOVE,1,9);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,1},new Method("Lorg/mortbay/util/LazyList;","get",new String[]{ "Ljava/lang/Object;","I"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,26);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,22);
                code.visitStmt2R(MOVE_OBJECT,1,11);
                code.visitStmt2R(MOVE_OBJECT_FROM16,2,26);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Lorg/mortbay/util/MultiMap;","add",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L56);
                code.visitStmt2R1N(ADD_INT_LIT8,9,9,1);
                code.visitJumpStmt(GOTO,-1,-1,L54);
                code.visitLabel(L57);
                code.visitJumpStmt(IF_EQZ,16,-1,L75);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 16},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,26);
                code.visitJumpStmt(IF_LEZ,26,-1,L75);
                code.visitLabel(L58);
                code.visitJumpStmt(IF_EQZ,24,-1,L10);
                code.visitLabel(L59);
                code.visitTypeStmt(NEW_INSTANCE,21,-1,"Ljava/lang/StringBuffer;");
                code.visitMethodStmt(INVOKE_DIRECT_RANGE,new int[]{ 21},new Method("Ljava/lang/StringBuffer;","<init>",new String[]{ },"V"));
                code.visitLabel(L60);
                code.visitTypeStmt(NEW_INSTANCE,20,-1,"Lorg/mortbay/util/MultiMap;");
                code.visitMethodStmt(INVOKE_DIRECT_RANGE,new int[]{ 20},new Method("Lorg/mortbay/util/MultiMap;","<init>",new String[]{ },"V"));
                code.visitLabel(L61);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 29},new Method("Ljavax/servlet/ServletRequest;","getCharacterEncoding",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,26);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,16);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,20);
                code.visitStmt2R(MOVE_OBJECT_FROM16,2,26);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,1,2},new Method("Lorg/mortbay/util/UrlEncoded;","decodeTo",new String[]{ "Ljava/lang/String;","Lorg/mortbay/util/MultiMap;","Ljava/lang/String;"},"V"));
                code.visitLabel(L62);
                code.visitTypeStmt(NEW_INSTANCE,19,-1,"Lorg/mortbay/util/MultiMap;");
                code.visitMethodStmt(INVOKE_DIRECT_RANGE,new int[]{ 19},new Method("Lorg/mortbay/util/MultiMap;","<init>",new String[]{ },"V"));
                code.visitLabel(L63);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 29},new Method("Ljavax/servlet/ServletRequest;","getCharacterEncoding",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,26);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,23);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,19);
                code.visitStmt2R(MOVE_OBJECT_FROM16,2,26);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,1,2},new Method("Lorg/mortbay/util/UrlEncoded;","decodeTo",new String[]{ "Ljava/lang/String;","Lorg/mortbay/util/MultiMap;","Ljava/lang/String;"},"V"));
                code.visitLabel(L64);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 20},new Method("Lorg/mortbay/util/MultiMap;","entrySet",new String[]{ },"Ljava/util/Set;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,26);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 26},new Method("Ljava/util/Set;","iterator",new String[]{ },"Ljava/util/Iterator;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,10);
                code.visitLabel(L65);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 10},new Method("Ljava/util/Iterator;","hasNext",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,26);
                code.visitJumpStmt(IF_EQZ,26,-1,L74);
                code.visitLabel(L66);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 10},new Method("Ljava/util/Iterator;","next",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitTypeStmt(CHECK_CAST,8,-1,"Ljava/util/Map$Entry;");
                code.visitLabel(L67);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 8},new Method("Ljava/util/Map$Entry;","getKey",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,11);
                code.visitTypeStmt(CHECK_CAST,11,-1,"Ljava/lang/String;");
                code.visitLabel(L68);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,19);
                code.visitStmt2R(MOVE_OBJECT,1,11);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/util/MultiMap;","containsKey",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,26);
                code.visitJumpStmt(IF_NEZ,26,-1,L65);
                code.visitLabel(L69);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 8},new Method("Ljava/util/Map$Entry;","getValue",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,25);
                code.visitLabel(L70);
                code.visitConstStmt(CONST_4,9, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L71);
                code.visitMethodStmt(INVOKE_STATIC_RANGE,new int[]{ 25},new Method("Lorg/mortbay/util/LazyList;","size",new String[]{ "Ljava/lang/Object;"},"I"));
                code.visitStmt1R(MOVE_RESULT,26);
                code.visitStmt2R(MOVE,0,9);
                code.visitStmt2R(MOVE_FROM16,1,26);
                code.visitJumpStmt(IF_GE,0,1,L65);
                code.visitLabel(L72);
                code.visitTypeStmt(NEW_INSTANCE,26,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT_RANGE,new int[]{ 26},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,27,"&");
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 26,27},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,26);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,26);
                code.visitStmt2R(MOVE_OBJECT,1,11);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,26);
                code.visitConstStmt(CONST_STRING,27,"=");
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 26,27},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,26);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,25);
                code.visitStmt2R(MOVE,1,9);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,1},new Method("Lorg/mortbay/util/LazyList;","get",new String[]{ "Ljava/lang/Object;","I"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,27);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 26,27},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,26);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 26},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,26);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,26);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L73);
                code.visitStmt2R1N(ADD_INT_LIT8,9,9,1);
                code.visitJumpStmt(GOTO,-1,-1,L71);
                code.visitLabel(L74);
                code.visitTypeStmt(NEW_INSTANCE,26,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT_RANGE,new int[]{ 26},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,26);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,23);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,26);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,26);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,21);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,26);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 26},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,23);
                code.visitLabel(L75);
                code.visitStmt2R(MOVE_OBJECT,0,6);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,22);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/Request;","setParameters",new String[]{ "Lorg/mortbay/util/MultiMap;"},"V"));
                code.visitLabel(L76);
                code.visitStmt2R(MOVE_OBJECT,0,6);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,23);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/Request;","setQueryString",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L77);
                code.visitTypeStmt(NEW_INSTANCE,5,-1,"Lorg/mortbay/jetty/servlet/Dispatcher$ForwardAttributes;");
                code.visitStmt2R(MOVE_OBJECT,0,5);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,28);
                code.visitStmt2R(MOVE_OBJECT,2,12);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1,2},new Method("Lorg/mortbay/jetty/servlet/Dispatcher$ForwardAttributes;","<init>",new String[]{ "Lorg/mortbay/jetty/servlet/Dispatcher;","Lorg/mortbay/util/Attributes;"},"V"));
                code.visitLabel(L78);
                code.visitConstStmt(CONST_STRING,26,"javax.servlet.forward.request_uri");
                code.visitStmt2R(MOVE_OBJECT,0,12);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,26);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1},new Method("Lorg/mortbay/util/Attributes;","getAttribute",new String[]{ "Ljava/lang/String;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitTypeStmt(CHECK_CAST,7,-1,"Ljava/lang/String;");
                code.visitJumpStmt(IF_EQZ,7,-1,L100);
                code.visitLabel(L79);
                code.visitConstStmt(CONST_STRING,26,"javax.servlet.forward.path_info");
                code.visitStmt2R(MOVE_OBJECT,0,12);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,26);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1},new Method("Lorg/mortbay/util/Attributes;","getAttribute",new String[]{ "Ljava/lang/String;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitTypeStmt(CHECK_CAST,7,-1,"Ljava/lang/String;");
                code.visitFieldStmt(IPUT_OBJECT,7,5,new Field("Lorg/mortbay/jetty/servlet/Dispatcher$ForwardAttributes;","_pathInfo","Ljava/lang/String;"));
                code.visitLabel(L80);
                code.visitConstStmt(CONST_STRING,26,"javax.servlet.forward.query_string");
                code.visitStmt2R(MOVE_OBJECT,0,12);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,26);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1},new Method("Lorg/mortbay/util/Attributes;","getAttribute",new String[]{ "Ljava/lang/String;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitTypeStmt(CHECK_CAST,7,-1,"Ljava/lang/String;");
                code.visitFieldStmt(IPUT_OBJECT,7,5,new Field("Lorg/mortbay/jetty/servlet/Dispatcher$ForwardAttributes;","_query","Ljava/lang/String;"));
                code.visitLabel(L81);
                code.visitConstStmt(CONST_STRING,26,"javax.servlet.forward.request_uri");
                code.visitStmt2R(MOVE_OBJECT,0,12);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,26);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1},new Method("Lorg/mortbay/util/Attributes;","getAttribute",new String[]{ "Ljava/lang/String;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitTypeStmt(CHECK_CAST,7,-1,"Ljava/lang/String;");
                code.visitFieldStmt(IPUT_OBJECT,7,5,new Field("Lorg/mortbay/jetty/servlet/Dispatcher$ForwardAttributes;","_requestURI","Ljava/lang/String;"));
                code.visitLabel(L82);
                code.visitConstStmt(CONST_STRING,26,"javax.servlet.forward.context_path");
                code.visitStmt2R(MOVE_OBJECT,0,12);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,26);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1},new Method("Lorg/mortbay/util/Attributes;","getAttribute",new String[]{ "Ljava/lang/String;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitTypeStmt(CHECK_CAST,7,-1,"Ljava/lang/String;");
                code.visitFieldStmt(IPUT_OBJECT,7,5,new Field("Lorg/mortbay/jetty/servlet/Dispatcher$ForwardAttributes;","_contextPath","Ljava/lang/String;"));
                code.visitLabel(L83);
                code.visitConstStmt(CONST_STRING,26,"javax.servlet.forward.servlet_path");
                code.visitStmt2R(MOVE_OBJECT,0,12);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,26);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1},new Method("Lorg/mortbay/util/Attributes;","getAttribute",new String[]{ "Ljava/lang/String;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitTypeStmt(CHECK_CAST,7,-1,"Ljava/lang/String;");
                code.visitFieldStmt(IPUT_OBJECT,7,5,new Field("Lorg/mortbay/jetty/servlet/Dispatcher$ForwardAttributes;","_servletPath","Ljava/lang/String;"));
                code.visitLabel(L84);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,28);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/servlet/Dispatcher;","_uri","Ljava/lang/String;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,26,0);
                code.visitStmt2R(MOVE_OBJECT,0,6);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,26);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/Request;","setRequestURI",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L85);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,28);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/servlet/Dispatcher;","_contextHandler","Lorg/mortbay/jetty/handler/ContextHandler;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,26,0);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 26},new Method("Lorg/mortbay/jetty/handler/ContextHandler;","getContextPath",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,26);
                code.visitStmt2R(MOVE_OBJECT,0,6);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,26);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/Request;","setContextPath",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L86);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,5},new Method("Lorg/mortbay/jetty/Request;","setAttributes",new String[]{ "Lorg/mortbay/util/Attributes;"},"V"));
                code.visitLabel(L87);
                code.visitStmt2R(MOVE_OBJECT,0,6);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,23);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/Request;","setQueryString",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L88);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,28);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/servlet/Dispatcher;","_contextHandler","Lorg/mortbay/jetty/handler/ContextHandler;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,26,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,28);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/servlet/Dispatcher;","_path","Ljava/lang/String;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,27,0);
                code.visitTypeStmt(CHECK_CAST,29,-1,"Ljavax/servlet/http/HttpServletRequest;");
                code.visitLabel(L89);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,30);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Ljavax/servlet/http/HttpServletResponse;");
                code.visitStmt2R(MOVE_OBJECT,5,0);
                code.visitLabel(L90);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,26);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,27);
                code.visitStmt2R(MOVE_OBJECT_FROM16,2,29);
                code.visitStmt2R(MOVE_OBJECT,3,5);
                code.visitStmt2R(MOVE_FROM16,4,31);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2,3,4},new Method("Lorg/mortbay/jetty/handler/ContextHandler;","handle",new String[]{ "Ljava/lang/String;","Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;","I"},"V"));
                code.visitLabel(L91);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/Request;","getConnection",new String[]{ },"Lorg/mortbay/jetty/HttpConnection;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,26);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 26},new Method("Lorg/mortbay/jetty/HttpConnection;","getResponse",new String[]{ },"Lorg/mortbay/jetty/Response;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,26);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 26},new Method("Lorg/mortbay/jetty/Response;","isWriting",new String[]{ },"Z"));
                code.visitLabel(L4);
                code.visitStmt1R(MOVE_RESULT,26);
                code.visitJumpStmt(IF_EQZ,26,-1,L12);
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 30},new Method("Ljavax/servlet/ServletResponse;","getWriter",new String[]{ },"Ljava/io/PrintWriter;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,26);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 26},new Method("Ljava/io/PrintWriter;","close",new String[]{ },"V"));
                code.visitLabel(L6);
                code.visitJumpStmt(GOTO_16,-1,-1,L1);
                code.visitLabel(L7);
                code.visitStmt1R(MOVE_EXCEPTION,26);
                code.visitStmt2R(MOVE_OBJECT_FROM16,7,26);
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 30},new Method("Ljavax/servlet/ServletResponse;","getOutputStream",new String[]{ },"Ljavax/servlet/ServletOutputStream;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,26);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 26},new Method("Ljavax/servlet/ServletOutputStream;","close",new String[]{ },"V"));
                code.visitLabel(L9);
                code.visitJumpStmt(GOTO_16,-1,-1,L1);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,26);
                code.visitStmt2R(MOVE_OBJECT,0,6);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,18);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/Request;","setRequestURI",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L92);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,13},new Method("Lorg/mortbay/jetty/Request;","setContextPath",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L93);
                code.visitStmt2R(MOVE_OBJECT,0,6);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,17);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/Request;","setServletPath",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L94);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,15},new Method("Lorg/mortbay/jetty/Request;","setPathInfo",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L95);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,12},new Method("Lorg/mortbay/jetty/Request;","setAttributes",new String[]{ "Lorg/mortbay/util/Attributes;"},"V"));
                code.visitLabel(L96);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,14},new Method("Lorg/mortbay/jetty/Request;","setParameters",new String[]{ "Lorg/mortbay/util/MultiMap;"},"V"));
                code.visitLabel(L97);
                code.visitStmt2R(MOVE_OBJECT,0,6);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,16);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/Request;","setQueryString",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L98);
                code.visitStmt1R(THROW,26);
                code.visitLabel(L10);
                code.visitTypeStmt(NEW_INSTANCE,26,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT_RANGE,new int[]{ 26},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,26);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,23);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,26);
                code.visitConstStmt(CONST_STRING,27,"&");
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 26,27},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,26);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,26);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,16);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,26);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 26},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,23);
                code.visitLabel(L99);
                code.visitJumpStmt(GOTO_16,-1,-1,L75);
                code.visitLabel(L100);
                code.visitFieldStmt(IPUT_OBJECT,15,5,new Field("Lorg/mortbay/jetty/servlet/Dispatcher$ForwardAttributes;","_pathInfo","Ljava/lang/String;"));
                code.visitLabel(L101);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,16);
                code.visitStmt2R(MOVE_OBJECT,1,5);
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/servlet/Dispatcher$ForwardAttributes;","_query","Ljava/lang/String;"));
                code.visitLabel(L102);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,18);
                code.visitStmt2R(MOVE_OBJECT,1,5);
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/servlet/Dispatcher$ForwardAttributes;","_requestURI","Ljava/lang/String;"));
                code.visitLabel(L103);
                code.visitFieldStmt(IPUT_OBJECT,13,5,new Field("Lorg/mortbay/jetty/servlet/Dispatcher$ForwardAttributes;","_contextPath","Ljava/lang/String;"));
                code.visitLabel(L104);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,17);
                code.visitStmt2R(MOVE_OBJECT,1,5);
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/servlet/Dispatcher$ForwardAttributes;","_servletPath","Ljava/lang/String;"));
                code.visitLabel(L11);
                code.visitJumpStmt(GOTO_16,-1,-1,L84);
                code.visitLabel(L12);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 30},new Method("Ljavax/servlet/ServletResponse;","getOutputStream",new String[]{ },"Ljavax/servlet/ServletOutputStream;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,26);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 26},new Method("Ljavax/servlet/ServletOutputStream;","close",new String[]{ },"V"));
                code.visitLabel(L13);
                code.visitJumpStmt(GOTO_16,-1,-1,L1);
                code.visitLabel(L14);
                code.visitStmt1R(MOVE_EXCEPTION,26);
                code.visitStmt2R(MOVE_OBJECT_FROM16,7,26);
                code.visitLabel(L15);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 30},new Method("Ljavax/servlet/ServletResponse;","getWriter",new String[]{ },"Ljava/io/PrintWriter;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,26);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 26},new Method("Ljava/io/PrintWriter;","close",new String[]{ },"V"));
                code.visitLabel(L16);
                code.visitJumpStmt(GOTO_16,-1,-1,L1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m007_include(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/Dispatcher;","include",new String[]{ "Ljavax/servlet/ServletRequest;","Ljavax/servlet/ServletResponse;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljavax/servlet/ServletException;"));
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(22);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L2},new String[]{ null});
                DexLabel L5=new DexLabel();
                DexLabel L6=new DexLabel();
                code.visitTryCatch(L5,L6,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"request");
                ddv.visitParameterName(1,"response");
                DexLabel L7=new DexLabel();
                ddv.visitPrologue(L7);
                ddv.visitLineNumber(144,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(145,L8);
                ddv.visitStartLocal(6,L8,"base_request","Lorg/mortbay/jetty/Request;",null);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(149,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(150,L10);
                ddv.visitStartLocal(11,L10,"old_attr","Lorg/mortbay/util/Attributes;",null);
                ddv.visitLineNumber(153,L0);
                ddv.visitStartLocal(12,L0,"old_params","Lorg/mortbay/util/MultiMap;",null);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(154,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(155,L12);
                DexLabel L13=new DexLabel();
                ddv.visitEndLocal(20,L13);
                DexLabel L14=new DexLabel();
                ddv.visitEndLocal(21,L14);
                ddv.visitLineNumber(197,L1);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(198,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(199,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(201,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(144,L18);
                ddv.visitEndLocal(6,L18);
                ddv.visitEndLocal(11,L18);
                ddv.visitEndLocal(12,L18);
                ddv.visitRestartLocal(20,L18);
                ddv.visitRestartLocal(21,L18);
                ddv.visitLineNumber(158,L3);
                ddv.visitRestartLocal(6,L3);
                ddv.visitRestartLocal(11,L3);
                ddv.visitRestartLocal(12,L3);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(160,L19);
                ddv.visitStartLocal(14,L19,"query","Ljava/lang/String;",null);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(162,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(163,L21);
                ddv.visitStartLocal(13,L21,"parameters","Lorg/mortbay/util/MultiMap;",null);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(165,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(168,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(169,L24);
                ddv.visitStartLocal(9,L24,"iter","Ljava/util/Iterator;",null);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(171,L25);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(172,L26);
                ddv.visitStartLocal(7,L26,"entry","Ljava/util/Map$Entry;",null);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(173,L27);
                ddv.visitStartLocal(10,L27,"name","Ljava/lang/String;",null);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(174,L28);
                ddv.visitStartLocal(15,L28,"values","Ljava/lang/Object;",null);
                DexLabel L29=new DexLabel();
                ddv.visitStartLocal(8,L29,"i","I",null);
                DexLabel L30=new DexLabel();
                ddv.visitLineNumber(175,L30);
                DexLabel L31=new DexLabel();
                ddv.visitLineNumber(174,L31);
                DexLabel L32=new DexLabel();
                ddv.visitLineNumber(179,L32);
                ddv.visitEndLocal(9,L32);
                ddv.visitEndLocal(7,L32);
                ddv.visitEndLocal(10,L32);
                ddv.visitEndLocal(15,L32);
                ddv.visitEndLocal(8,L32);
                DexLabel L33=new DexLabel();
                ddv.visitLineNumber(182,L33);
                ddv.visitEndLocal(13,L33);
                DexLabel L34=new DexLabel();
                ddv.visitLineNumber(184,L34);
                ddv.visitStartLocal(5,L34,"attr","Lorg/mortbay/jetty/servlet/Dispatcher$IncludeAttributes;",null);
                DexLabel L35=new DexLabel();
                ddv.visitLineNumber(185,L35);
                DexLabel L36=new DexLabel();
                ddv.visitLineNumber(186,L36);
                DexLabel L37=new DexLabel();
                ddv.visitLineNumber(187,L37);
                DexLabel L38=new DexLabel();
                ddv.visitLineNumber(188,L38);
                DexLabel L39=new DexLabel();
                ddv.visitLineNumber(190,L39);
                DexLabel L40=new DexLabel();
                ddv.visitLineNumber(192,L40);
                DexLabel L41=new DexLabel();
                ddv.visitEndLocal(20,L41);
                DexLabel L42=new DexLabel();
                ddv.visitEndLocal(21,L42);
                ddv.visitLineNumber(197,L2);
                ddv.visitEndLocal(14,L2);
                ddv.visitEndLocal(5,L2);
                DexLabel L43=new DexLabel();
                ddv.visitLineNumber(198,L43);
                DexLabel L44=new DexLabel();
                ddv.visitLineNumber(199,L44);
                DexLabel L45=new DexLabel();
                ddv.visitLineNumber(197,L45);
                ddv.visitLineNumber(192,L5);
                ddv.visitRestartLocal(5,L5);
                ddv.visitRestartLocal(14,L5);
                ddv.visitRestartLocal(20,L5);
                ddv.visitRestartLocal(21,L5);
                code.visitLabel(L7);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,20);
                code.visitTypeStmt(INSTANCE_OF,0,0,"Lorg/mortbay/jetty/Request;");
                code.visitStmt2R(MOVE_FROM16,16,0);
                code.visitJumpStmt(IF_EQZ,16,-1,L18);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,20);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Lorg/mortbay/jetty/Request;");
                code.visitStmt2R(MOVE_OBJECT,5,0);
                code.visitStmt2R(MOVE_OBJECT,6,5);
                code.visitLabel(L8);
                code.visitConstStmt(CONST_STRING,16,"org.apache.catalina.jsp_file");
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,20);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,16);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1},new Method("Ljavax/servlet/ServletRequest;","removeAttribute",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/Request;","getAttributes",new String[]{ },"Lorg/mortbay/util/Attributes;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,11);
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/Request;","getParameters",new String[]{ },"Lorg/mortbay/util/MultiMap;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,12);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/Request;","getConnection",new String[]{ },"Lorg/mortbay/jetty/HttpConnection;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,16);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 16},new Method("Lorg/mortbay/jetty/HttpConnection;","include",new String[]{ },"V"));
                code.visitLabel(L11);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,19);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/servlet/Dispatcher;","_named","Ljava/lang/String;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,16,0);
                code.visitJumpStmt(IF_EQZ,16,-1,L3);
                code.visitLabel(L12);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,19);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/servlet/Dispatcher;","_contextHandler","Lorg/mortbay/jetty/handler/ContextHandler;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,16,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,19);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/servlet/Dispatcher;","_named","Ljava/lang/String;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,17,0);
                code.visitTypeStmt(CHECK_CAST,20,-1,"Ljavax/servlet/http/HttpServletRequest;");
                code.visitLabel(L13);
                code.visitTypeStmt(CHECK_CAST,21,-1,"Ljavax/servlet/http/HttpServletResponse;");
                code.visitLabel(L14);
                code.visitConstStmt(CONST_16,18, Integer.valueOf(4)); // int: 0x00000004  float:0.000000
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,16);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,17);
                code.visitStmt2R(MOVE_OBJECT_FROM16,2,20);
                code.visitStmt2R(MOVE_OBJECT_FROM16,3,21);
                code.visitStmt2R(MOVE_FROM16,4,18);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2,3,4},new Method("Lorg/mortbay/jetty/handler/ContextHandler;","handle",new String[]{ "Ljava/lang/String;","Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;","I"},"V"));
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,11},new Method("Lorg/mortbay/jetty/Request;","setAttributes",new String[]{ "Lorg/mortbay/util/Attributes;"},"V"));
                code.visitLabel(L15);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/Request;","getConnection",new String[]{ },"Lorg/mortbay/jetty/HttpConnection;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,16);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 16},new Method("Lorg/mortbay/jetty/HttpConnection;","included",new String[]{ },"V"));
                code.visitLabel(L16);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,12},new Method("Lorg/mortbay/jetty/Request;","setParameters",new String[]{ "Lorg/mortbay/util/MultiMap;"},"V"));
                code.visitLabel(L17);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L18);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/jetty/HttpConnection;","getCurrentConnection",new String[]{ },"Lorg/mortbay/jetty/HttpConnection;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,16);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 16},new Method("Lorg/mortbay/jetty/HttpConnection;","getRequest",new String[]{ },"Lorg/mortbay/jetty/Request;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,16);
                code.visitStmt2R(MOVE_OBJECT_FROM16,6,16);
                code.visitJumpStmt(GOTO,-1,-1,L8);
                code.visitLabel(L3);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,19);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/servlet/Dispatcher;","_dQuery","Ljava/lang/String;"));
                code.visitStmt2R(MOVE_OBJECT,14,0);
                code.visitLabel(L19);
                code.visitJumpStmt(IF_EQZ,14,-1,L33);
                code.visitLabel(L20);
                code.visitTypeStmt(NEW_INSTANCE,13,-1,"Lorg/mortbay/util/MultiMap;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 13},new Method("Lorg/mortbay/util/MultiMap;","<init>",new String[]{ },"V"));
                code.visitLabel(L21);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 20},new Method("Ljavax/servlet/ServletRequest;","getCharacterEncoding",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,16);
                code.visitStmt2R(MOVE_OBJECT,0,14);
                code.visitStmt2R(MOVE_OBJECT,1,13);
                code.visitStmt2R(MOVE_OBJECT_FROM16,2,16);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,1,2},new Method("Lorg/mortbay/util/UrlEncoded;","decodeTo",new String[]{ "Ljava/lang/String;","Lorg/mortbay/util/MultiMap;","Ljava/lang/String;"},"V"));
                code.visitLabel(L22);
                code.visitJumpStmt(IF_EQZ,12,-1,L32);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12},new Method("Lorg/mortbay/util/MultiMap;","size",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,16);
                code.visitJumpStmt(IF_LEZ,16,-1,L32);
                code.visitLabel(L23);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12},new Method("Lorg/mortbay/util/MultiMap;","entrySet",new String[]{ },"Ljava/util/Set;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,16);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 16},new Method("Ljava/util/Set;","iterator",new String[]{ },"Ljava/util/Iterator;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitLabel(L24);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 9},new Method("Ljava/util/Iterator;","hasNext",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,16);
                code.visitJumpStmt(IF_EQZ,16,-1,L32);
                code.visitLabel(L25);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 9},new Method("Ljava/util/Iterator;","next",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitTypeStmt(CHECK_CAST,7,-1,"Ljava/util/Map$Entry;");
                code.visitLabel(L26);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 7},new Method("Ljava/util/Map$Entry;","getKey",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,10);
                code.visitTypeStmt(CHECK_CAST,10,-1,"Ljava/lang/String;");
                code.visitLabel(L27);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 7},new Method("Ljava/util/Map$Entry;","getValue",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,15);
                code.visitLabel(L28);
                code.visitConstStmt(CONST_4,8, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L29);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 15},new Method("Lorg/mortbay/util/LazyList;","size",new String[]{ "Ljava/lang/Object;"},"I"));
                code.visitStmt1R(MOVE_RESULT,16);
                code.visitStmt2R(MOVE,0,8);
                code.visitStmt2R(MOVE_FROM16,1,16);
                code.visitJumpStmt(IF_GE,0,1,L24);
                code.visitLabel(L30);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 15,8},new Method("Lorg/mortbay/util/LazyList;","get",new String[]{ "Ljava/lang/Object;","I"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,16);
                code.visitStmt2R(MOVE_OBJECT,0,13);
                code.visitStmt2R(MOVE_OBJECT,1,10);
                code.visitStmt2R(MOVE_OBJECT_FROM16,2,16);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Lorg/mortbay/util/MultiMap;","add",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L31);
                code.visitStmt2R1N(ADD_INT_LIT8,8,8,1);
                code.visitJumpStmt(GOTO,-1,-1,L29);
                code.visitLabel(L32);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,13},new Method("Lorg/mortbay/jetty/Request;","setParameters",new String[]{ "Lorg/mortbay/util/MultiMap;"},"V"));
                code.visitLabel(L33);
                code.visitTypeStmt(NEW_INSTANCE,5,-1,"Lorg/mortbay/jetty/servlet/Dispatcher$IncludeAttributes;");
                code.visitStmt2R(MOVE_OBJECT,0,5);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,19);
                code.visitStmt2R(MOVE_OBJECT,2,11);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1,2},new Method("Lorg/mortbay/jetty/servlet/Dispatcher$IncludeAttributes;","<init>",new String[]{ "Lorg/mortbay/jetty/servlet/Dispatcher;","Lorg/mortbay/util/Attributes;"},"V"));
                code.visitLabel(L34);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,19);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/servlet/Dispatcher;","_uri","Ljava/lang/String;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,16,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,16);
                code.visitStmt2R(MOVE_OBJECT,1,5);
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/servlet/Dispatcher$IncludeAttributes;","_requestURI","Ljava/lang/String;"));
                code.visitLabel(L35);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,19);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/servlet/Dispatcher;","_contextHandler","Lorg/mortbay/jetty/handler/ContextHandler;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,16,0);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 16},new Method("Lorg/mortbay/jetty/handler/ContextHandler;","getContextPath",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,16);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,16);
                code.visitStmt2R(MOVE_OBJECT,1,5);
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/servlet/Dispatcher$IncludeAttributes;","_contextPath","Ljava/lang/String;"));
                code.visitLabel(L36);
                code.visitConstStmt(CONST_16,16, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,16);
                code.visitStmt2R(MOVE_OBJECT,1,5);
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/servlet/Dispatcher$IncludeAttributes;","_servletPath","Ljava/lang/String;"));
                code.visitLabel(L37);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,19);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/servlet/Dispatcher;","_path","Ljava/lang/String;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,16,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,16);
                code.visitStmt2R(MOVE_OBJECT,1,5);
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/servlet/Dispatcher$IncludeAttributes;","_pathInfo","Ljava/lang/String;"));
                code.visitLabel(L38);
                code.visitFieldStmt(IPUT_OBJECT,14,5,new Field("Lorg/mortbay/jetty/servlet/Dispatcher$IncludeAttributes;","_query","Ljava/lang/String;"));
                code.visitLabel(L39);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,5},new Method("Lorg/mortbay/jetty/Request;","setAttributes",new String[]{ "Lorg/mortbay/util/Attributes;"},"V"));
                code.visitLabel(L40);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,19);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/servlet/Dispatcher;","_contextHandler","Lorg/mortbay/jetty/handler/ContextHandler;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,16,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,19);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/servlet/Dispatcher;","_named","Ljava/lang/String;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,17,0);
                code.visitJumpStmt(IF_NEZ,17,-1,L5);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,19);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/servlet/Dispatcher;","_path","Ljava/lang/String;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,17,0);
                DexLabel L46=new DexLabel();
                code.visitLabel(L46);
                code.visitTypeStmt(CHECK_CAST,20,-1,"Ljavax/servlet/http/HttpServletRequest;");
                code.visitLabel(L41);
                code.visitTypeStmt(CHECK_CAST,21,-1,"Ljavax/servlet/http/HttpServletResponse;");
                code.visitLabel(L42);
                code.visitConstStmt(CONST_16,18, Integer.valueOf(4)); // int: 0x00000004  float:0.000000
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,16);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,17);
                code.visitStmt2R(MOVE_OBJECT_FROM16,2,20);
                code.visitStmt2R(MOVE_OBJECT_FROM16,3,21);
                code.visitStmt2R(MOVE_FROM16,4,18);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2,3,4},new Method("Lorg/mortbay/jetty/handler/ContextHandler;","handle",new String[]{ "Ljava/lang/String;","Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;","I"},"V"));
                code.visitLabel(L4);
                code.visitJumpStmt(GOTO_16,-1,-1,L1);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,16);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,11},new Method("Lorg/mortbay/jetty/Request;","setAttributes",new String[]{ "Lorg/mortbay/util/Attributes;"},"V"));
                code.visitLabel(L43);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/Request;","getConnection",new String[]{ },"Lorg/mortbay/jetty/HttpConnection;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,17);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 17},new Method("Lorg/mortbay/jetty/HttpConnection;","included",new String[]{ },"V"));
                code.visitLabel(L44);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,12},new Method("Lorg/mortbay/jetty/Request;","setParameters",new String[]{ "Lorg/mortbay/util/MultiMap;"},"V"));
                code.visitLabel(L45);
                code.visitStmt1R(THROW,16);
                code.visitLabel(L5);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,19);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/servlet/Dispatcher;","_named","Ljava/lang/String;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,17,0);
                code.visitLabel(L6);
                code.visitJumpStmt(GOTO,-1,-1,L46);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
