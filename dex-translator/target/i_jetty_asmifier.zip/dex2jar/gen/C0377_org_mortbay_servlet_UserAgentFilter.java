package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0377_org_mortbay_servlet_UserAgentFilter {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/servlet/UserAgentFilter;","Ljava/lang/Object;",new String[]{ "Ljavax/servlet/Filter;"});
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("UserAgentFilter.java");
        f000__agentCache(cv);
        f001__agentCacheSize(cv);
        f002__attribute(cv);
        f003__pattern(cv);
        m000__init_(cv);
        m001_destroy(cv);
        m002_doFilter(cv);
        m003_getUserAgent(cv);
        m004_getUserAgent(cv);
        m005_init(cv);
    }
    public static void f000__agentCache(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/servlet/UserAgentFilter;","_agentCache","Ljava/util/Map;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001__agentCacheSize(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/servlet/UserAgentFilter;","_agentCacheSize","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002__attribute(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/servlet/UserAgentFilter;","_attribute","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003__pattern(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/servlet/UserAgentFilter;","_pattern","Ljava/util/regex/Pattern;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/servlet/UserAgentFilter;","<init>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(55,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(58,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(59,L2);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljava/lang/Object;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/util/HashMap;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/util/HashMap;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/servlet/UserAgentFilter;","_agentCache","Ljava/util/Map;"));
                code.visitLabel(L2);
                code.visitConstStmt(CONST_16,0, Integer.valueOf(1024)); // int: 0x00000400  float:0.000000
                code.visitFieldStmt(IPUT,0,1,new Field("Lorg/mortbay/servlet/UserAgentFilter;","_agentCacheSize","I"));
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001_destroy(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/servlet/UserAgentFilter;","destroy",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(68,L0);
                code.visitLabel(L0);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_doFilter(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/servlet/UserAgentFilter;","doFilter",new String[]{ "Ljavax/servlet/ServletRequest;","Ljavax/servlet/ServletResponse;","Ljavax/servlet/FilterChain;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visit(null, new DexType("Ljavax/servlet/ServletException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"request");
                ddv.visitParameterName(1,"response");
                ddv.visitParameterName(2,"chain");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(76,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(78,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(79,L2);
                ddv.visitStartLocal(0,L2,"ua","Ljava/lang/String;",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(81,L3);
                ddv.visitEndLocal(0,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(82,L4);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/servlet/UserAgentFilter;","_attribute","Ljava/lang/String;"));
                code.visitJumpStmt(IF_EQZ,1,-1,L3);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/servlet/UserAgentFilter;","_pattern","Ljava/util/regex/Pattern;"));
                code.visitJumpStmt(IF_EQZ,1,-1,L3);
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Lorg/mortbay/servlet/UserAgentFilter;","getUserAgent",new String[]{ "Ljavax/servlet/ServletRequest;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/servlet/UserAgentFilter;","_attribute","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3,1,0},new Method("Ljavax/servlet/ServletRequest;","setAttribute",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 5,3,4},new Method("Ljavax/servlet/FilterChain;","doFilter",new String[]{ "Ljavax/servlet/ServletRequest;","Ljavax/servlet/ServletResponse;"},"V"));
                code.visitLabel(L4);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_getUserAgent(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/servlet/UserAgentFilter;","getUserAgent",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(9);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L2},new String[]{ null});
                DexLabel L5=new DexLabel();
                DexLabel L6=new DexLabel();
                DexLabel L7=new DexLabel();
                code.visitTryCatch(L5,L6,new DexLabel[]{L7},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"ua");
                DexLabel L8=new DexLabel();
                ddv.visitPrologue(L8);
                ddv.visitLineNumber(118,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(119,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(155,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(122,L11);
                ddv.visitLineNumber(124,L0);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(125,L12);
                ddv.visitStartLocal(3,L12,"tag","Ljava/lang/String;",null);
                ddv.visitLineNumber(127,L1);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(129,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(130,L14);
                ddv.visitStartLocal(2,L14,"matcher","Ljava/util/regex/Matcher;",null);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(132,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(134,L16);
                DexLabel L17=new DexLabel();
                ddv.visitStartLocal(0,L17,"g","I",null);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(136,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(137,L19);
                ddv.visitStartLocal(1,L19,"group","Ljava/lang/String;",null);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(138,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(134,L21);
                ddv.visitLineNumber(125,L2);
                ddv.visitEndLocal(2,L2);
                ddv.visitEndLocal(0,L2);
                ddv.visitEndLocal(1,L2);
                ddv.visitEndLocal(3,L2);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(138,L22);
                ddv.visitRestartLocal(0,L22);
                ddv.visitRestartLocal(1,L22);
                ddv.visitRestartLocal(2,L22);
                ddv.visitRestartLocal(3,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(142,L23);
                ddv.visitEndLocal(0,L23);
                ddv.visitEndLocal(1,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(147,L24);
                ddv.visitRestartLocal(3,L24);
                ddv.visitLineNumber(149,L5);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(150,L25);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(151,L26);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(152,L27);
                DexLabel L28=new DexLabel();
                ddv.visitEndLocal(2,L28);
                DexLabel L29=new DexLabel();
                ddv.visitLineNumber(155,L29);
                DexLabel L30=new DexLabel();
                ddv.visitLineNumber(145,L30);
                ddv.visitRestartLocal(2,L30);
                ddv.visitLineNumber(152,L7);
                code.visitLabel(L8);
                code.visitJumpStmt(IF_NEZ,8,-1,L11);
                code.visitLabel(L9);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L10);
                code.visitStmt1R(RETURN_OBJECT,4);
                code.visitLabel(L11);
                code.visitFieldStmt(IGET_OBJECT,4,7,new Field("Lorg/mortbay/servlet/UserAgentFilter;","_agentCache","Ljava/util/Map;"));
                code.visitStmt1R(MONITOR_ENTER,4);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,5,7,new Field("Lorg/mortbay/servlet/UserAgentFilter;","_agentCache","Ljava/util/Map;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 5,8},new Method("Ljava/util/Map;","get",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitTypeStmt(CHECK_CAST,3,-1,"Ljava/lang/String;");
                code.visitLabel(L12);
                code.visitStmt1R(MONITOR_EXIT,4);
                code.visitLabel(L1);
                code.visitJumpStmt(IF_NEZ,3,-1,L28);
                code.visitLabel(L13);
                code.visitFieldStmt(IGET_OBJECT,4,7,new Field("Lorg/mortbay/servlet/UserAgentFilter;","_pattern","Ljava/util/regex/Pattern;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,8},new Method("Ljava/util/regex/Pattern;","matcher",new String[]{ "Ljava/lang/CharSequence;"},"Ljava/util/regex/Matcher;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L14);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/util/regex/Matcher;","matches",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitJumpStmt(IF_EQZ,4,-1,L30);
                code.visitLabel(L15);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/util/regex/Matcher;","groupCount",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitJumpStmt(IF_LEZ,4,-1,L23);
                code.visitLabel(L16);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L17);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/util/regex/Matcher;","groupCount",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitJumpStmt(IF_GT,0,4,L24);
                code.visitLabel(L18);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,0},new Method("Ljava/util/regex/Matcher;","group",new String[]{ "I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L19);
                code.visitJumpStmt(IF_EQZ,1,-1,L21);
                code.visitLabel(L20);
                code.visitJumpStmt(IF_NEZ,3,-1,L22);
                code.visitStmt2R(MOVE_OBJECT,3,1);
                code.visitLabel(L21);
                code.visitStmt2R1N(ADD_INT_LIT8,0,0,1);
                code.visitJumpStmt(GOTO,-1,-1,L17);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,5);
                code.visitLabel(L3);
                code.visitStmt1R(MONITOR_EXIT,4);
                code.visitLabel(L4);
                code.visitStmt1R(THROW,5);
                code.visitLabel(L22);
                code.visitTypeStmt(NEW_INSTANCE,4,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitStmt2R(MOVE_OBJECT,3,4);
                code.visitJumpStmt(GOTO,-1,-1,L21);
                code.visitLabel(L23);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/util/regex/Matcher;","group",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitLabel(L24);
                code.visitFieldStmt(IGET_OBJECT,4,7,new Field("Lorg/mortbay/servlet/UserAgentFilter;","_agentCache","Ljava/util/Map;"));
                code.visitStmt1R(MONITOR_ENTER,4);
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,5,7,new Field("Lorg/mortbay/servlet/UserAgentFilter;","_agentCache","Ljava/util/Map;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 5},new Method("Ljava/util/Map;","size",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitFieldStmt(IGET,6,7,new Field("Lorg/mortbay/servlet/UserAgentFilter;","_agentCacheSize","I"));
                code.visitJumpStmt(IF_LT,5,6,L26);
                code.visitLabel(L25);
                code.visitFieldStmt(IGET_OBJECT,5,7,new Field("Lorg/mortbay/servlet/UserAgentFilter;","_agentCache","Ljava/util/Map;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 5},new Method("Ljava/util/Map;","clear",new String[]{ },"V"));
                code.visitLabel(L26);
                code.visitFieldStmt(IGET_OBJECT,5,7,new Field("Lorg/mortbay/servlet/UserAgentFilter;","_agentCache","Ljava/util/Map;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 5,8,3},new Method("Ljava/util/Map;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L27);
                code.visitStmt1R(MONITOR_EXIT,4);
                code.visitLabel(L28);
                code.visitStmt2R(MOVE_OBJECT,4,3);
                code.visitLabel(L29);
                code.visitJumpStmt(GOTO,-1,-1,L10);
                code.visitLabel(L30);
                code.visitStmt2R(MOVE_OBJECT,3,8);
                code.visitJumpStmt(GOTO,-1,-1,L24);
                code.visitLabel(L7);
                code.visitStmt1R(MOVE_EXCEPTION,5);
                code.visitStmt1R(MONITOR_EXIT,4);
                code.visitLabel(L6);
                code.visitStmt1R(THROW,5);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_getUserAgent(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/servlet/UserAgentFilter;","getUserAgent",new String[]{ "Ljavax/servlet/ServletRequest;"},"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"request");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(104,L0);
                DexLabel L1=new DexLabel();
                ddv.visitEndLocal(3,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(105,L2);
                ddv.visitStartLocal(0,L2,"ua","Ljava/lang/String;",null);
                code.visitLabel(L0);
                code.visitTypeStmt(CHECK_CAST,3,-1,"Ljavax/servlet/http/HttpServletRequest;");
                code.visitLabel(L1);
                code.visitConstStmt(CONST_STRING,1,"User-Agent");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3,1},new Method("Ljavax/servlet/http/HttpServletRequest;","getHeader",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,0},new Method("Lorg/mortbay/servlet/UserAgentFilter;","getUserAgent",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitStmt1R(RETURN_OBJECT,1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_init(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/servlet/UserAgentFilter;","init",new String[]{ "Ljavax/servlet/FilterConfig;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljavax/servlet/ServletException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"filterConfig");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(90,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(92,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(93,L2);
                ddv.visitStartLocal(0,L2,"p","Ljava/lang/String;",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(94,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(96,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(97,L5);
                ddv.visitStartLocal(1,L5,"size","Ljava/lang/String;",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(98,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(99,L7);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_STRING,2,"attribute");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 4,2},new Method("Ljavax/servlet/FilterConfig;","getInitParameter",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitFieldStmt(IPUT_OBJECT,2,3,new Field("Lorg/mortbay/servlet/UserAgentFilter;","_attribute","Ljava/lang/String;"));
                code.visitLabel(L1);
                code.visitConstStmt(CONST_STRING,2,"userAgent");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 4,2},new Method("Ljavax/servlet/FilterConfig;","getInitParameter",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L2);
                code.visitJumpStmt(IF_EQZ,0,-1,L4);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Ljava/util/regex/Pattern;","compile",new String[]{ "Ljava/lang/String;"},"Ljava/util/regex/Pattern;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitFieldStmt(IPUT_OBJECT,2,3,new Field("Lorg/mortbay/servlet/UserAgentFilter;","_pattern","Ljava/util/regex/Pattern;"));
                code.visitLabel(L4);
                code.visitConstStmt(CONST_STRING,2,"cacheSize");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 4,2},new Method("Ljavax/servlet/FilterConfig;","getInitParameter",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L5);
                code.visitJumpStmt(IF_EQZ,1,-1,L7);
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1},new Method("Ljava/lang/Integer;","parseInt",new String[]{ "Ljava/lang/String;"},"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitFieldStmt(IPUT,2,3,new Field("Lorg/mortbay/servlet/UserAgentFilter;","_agentCacheSize","I"));
                code.visitLabel(L7);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
