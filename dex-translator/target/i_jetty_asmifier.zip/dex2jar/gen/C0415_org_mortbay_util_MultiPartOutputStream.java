package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0415_org_mortbay_util_MultiPartOutputStream {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/util/MultiPartOutputStream;","Ljava/io/FilterOutputStream;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("MultiPartOutputStream.java");
        f000_MULTIPART_MIXED(cv);
        f001_MULTIPART_X_MIXED_REPLACE(cv);
        f002___CRLF(cv);
        f003___DASHDASH(cv);
        f004_boundary(cv);
        f005_boundaryBytes(cv);
        f006_inPart(cv);
        m000__clinit_(cv);
        m001__init_(cv);
        m002_close(cv);
        m003_getBoundary(cv);
        m004_getOut(cv);
        m005_startPart(cv);
        m006_startPart(cv);
    }
    public static void f000_MULTIPART_MIXED(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC, new Field("Lorg/mortbay/util/MultiPartOutputStream;","MULTIPART_MIXED","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001_MULTIPART_X_MIXED_REPLACE(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC, new Field("Lorg/mortbay/util/MultiPartOutputStream;","MULTIPART_X_MIXED_REPLACE","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002___CRLF(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC, new Field("Lorg/mortbay/util/MultiPartOutputStream;","__CRLF","[B"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003___DASHDASH(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC, new Field("Lorg/mortbay/util/MultiPartOutputStream;","__DASHDASH","[B"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f004_boundary(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/util/MultiPartOutputStream;","boundary","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f005_boundaryBytes(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/util/MultiPartOutputStream;","boundaryBytes","[B"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f006_inPart(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/util/MultiPartOutputStream;","inPart","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__clinit_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/util/MultiPartOutputStream;","<clinit>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/lang/Exception;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(34,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(35,L4);
                ddv.visitLineNumber(40,L0);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(41,L5);
                ddv.visitLineNumber(44,L1);
                ddv.visitLineNumber(43,L2);
                DexLabel L6=new DexLabel();
                ddv.visitStartLocal(0,L6,"e","Ljava/lang/Exception;",null);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_STRING,1,"multipart/mixed");
                code.visitFieldStmt(SPUT_OBJECT,1,-1,new Field("Lorg/mortbay/util/MultiPartOutputStream;","MULTIPART_MIXED","Ljava/lang/String;"));
                code.visitLabel(L4);
                code.visitConstStmt(CONST_STRING,1,"multipart/x-mixed-replace");
                code.visitFieldStmt(SPUT_OBJECT,1,-1,new Field("Lorg/mortbay/util/MultiPartOutputStream;","MULTIPART_X_MIXED_REPLACE","Ljava/lang/String;"));
                code.visitLabel(L0);
                code.visitConstStmt(CONST_STRING,1,"\r\n");
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/util/StringUtil;","__ISO_8859_1","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/lang/String;","getBytes",new String[]{ "Ljava/lang/String;"},"[B"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitFieldStmt(SPUT_OBJECT,1,-1,new Field("Lorg/mortbay/util/MultiPartOutputStream;","__CRLF","[B"));
                code.visitLabel(L5);
                code.visitConstStmt(CONST_STRING,1,"--");
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/util/StringUtil;","__ISO_8859_1","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/lang/String;","getBytes",new String[]{ "Ljava/lang/String;"},"[B"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitFieldStmt(SPUT_OBJECT,1,-1,new Field("Lorg/mortbay/util/MultiPartOutputStream;","__DASHDASH","[B"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitStmt2R(MOVE_OBJECT,0,1);
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/Exception;","printStackTrace",new String[]{ },"V"));
                code.visitConstStmt(CONST_4,1, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1},new Method("Ljava/lang/System;","exit",new String[]{ "I"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/util/MultiPartOutputStream;","<init>",new String[]{ "Ljava/io/OutputStream;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"out");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(57,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(51,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(59,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(61,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(63,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(64,L6);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 5,6},new Method("Ljava/io/FilterOutputStream;","<init>",new String[]{ "Ljava/io/OutputStream;"},"V"));
                code.visitLabel(L2);
                code.visitFieldStmt(IPUT_BOOLEAN,4,5,new Field("Lorg/mortbay/util/MultiPartOutputStream;","inPart","Z"));
                code.visitLabel(L3);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,1,"jetty");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 5},new Method("Ljava/lang/System;","identityHashCode",new String[]{ "Ljava/lang/Object;"},"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "I"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Ljava/lang/System;","currentTimeMillis",new String[]{ },"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,1);
                code.visitConstStmt(CONST_16,3, Integer.valueOf(36)); // int: 0x00000024  float:0.000000
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1,2,3},new Method("Ljava/lang/Long;","toString",new String[]{ "J","I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IPUT_OBJECT,0,5,new Field("Lorg/mortbay/util/MultiPartOutputStream;","boundary","Ljava/lang/String;"));
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,0,5,new Field("Lorg/mortbay/util/MultiPartOutputStream;","boundary","Ljava/lang/String;"));
                code.visitFieldStmt(SGET_OBJECT,1,-1,new Field("Lorg/mortbay/util/StringUtil;","__ISO_8859_1","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/String;","getBytes",new String[]{ "Ljava/lang/String;"},"[B"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IPUT_OBJECT,0,5,new Field("Lorg/mortbay/util/MultiPartOutputStream;","boundaryBytes","[B"));
                code.visitLabel(L5);
                code.visitFieldStmt(IPUT_BOOLEAN,4,5,new Field("Lorg/mortbay/util/MultiPartOutputStream;","inPart","Z"));
                code.visitLabel(L6);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_close(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/MultiPartOutputStream;","close",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(75,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(76,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(77,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(78,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(79,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(80,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(81,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(82,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(83,L8);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_BOOLEAN,0,2,new Field("Lorg/mortbay/util/MultiPartOutputStream;","inPart","Z"));
                code.visitJumpStmt(IF_EQZ,0,-1,L2);
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/util/MultiPartOutputStream;","out","Ljava/io/OutputStream;"));
                code.visitFieldStmt(SGET_OBJECT,1,-1,new Field("Lorg/mortbay/util/MultiPartOutputStream;","__CRLF","[B"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/io/OutputStream;","write",new String[]{ "[B"},"V"));
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/util/MultiPartOutputStream;","out","Ljava/io/OutputStream;"));
                code.visitFieldStmt(SGET_OBJECT,1,-1,new Field("Lorg/mortbay/util/MultiPartOutputStream;","__DASHDASH","[B"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/io/OutputStream;","write",new String[]{ "[B"},"V"));
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/util/MultiPartOutputStream;","out","Ljava/io/OutputStream;"));
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/util/MultiPartOutputStream;","boundaryBytes","[B"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/io/OutputStream;","write",new String[]{ "[B"},"V"));
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/util/MultiPartOutputStream;","out","Ljava/io/OutputStream;"));
                code.visitFieldStmt(SGET_OBJECT,1,-1,new Field("Lorg/mortbay/util/MultiPartOutputStream;","__DASHDASH","[B"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/io/OutputStream;","write",new String[]{ "[B"},"V"));
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/util/MultiPartOutputStream;","out","Ljava/io/OutputStream;"));
                code.visitFieldStmt(SGET_OBJECT,1,-1,new Field("Lorg/mortbay/util/MultiPartOutputStream;","__CRLF","[B"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/io/OutputStream;","write",new String[]{ "[B"},"V"));
                code.visitLabel(L6);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_BOOLEAN,0,2,new Field("Lorg/mortbay/util/MultiPartOutputStream;","inPart","Z"));
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 2},new Method("Ljava/io/FilterOutputStream;","close",new String[]{ },"V"));
                code.visitLabel(L8);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_getBoundary(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/MultiPartOutputStream;","getBoundary",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(88,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/util/MultiPartOutputStream;","boundary","Ljava/lang/String;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_getOut(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/MultiPartOutputStream;","getOut",new String[]{ },"Ljava/io/OutputStream;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(91,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/util/MultiPartOutputStream;","out","Ljava/io/OutputStream;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_startPart(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/MultiPartOutputStream;","startPart",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"contentType");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(99,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(100,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(101,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(102,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(103,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(104,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(105,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(106,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(107,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(108,L9);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_BOOLEAN,0,3,new Field("Lorg/mortbay/util/MultiPartOutputStream;","inPart","Z"));
                code.visitJumpStmt(IF_EQZ,0,-1,L2);
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/util/MultiPartOutputStream;","out","Ljava/io/OutputStream;"));
                code.visitFieldStmt(SGET_OBJECT,1,-1,new Field("Lorg/mortbay/util/MultiPartOutputStream;","__CRLF","[B"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/io/OutputStream;","write",new String[]{ "[B"},"V"));
                code.visitLabel(L2);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitFieldStmt(IPUT_BOOLEAN,0,3,new Field("Lorg/mortbay/util/MultiPartOutputStream;","inPart","Z"));
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/util/MultiPartOutputStream;","out","Ljava/io/OutputStream;"));
                code.visitFieldStmt(SGET_OBJECT,1,-1,new Field("Lorg/mortbay/util/MultiPartOutputStream;","__DASHDASH","[B"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/io/OutputStream;","write",new String[]{ "[B"},"V"));
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/util/MultiPartOutputStream;","out","Ljava/io/OutputStream;"));
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/util/MultiPartOutputStream;","boundaryBytes","[B"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/io/OutputStream;","write",new String[]{ "[B"},"V"));
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/util/MultiPartOutputStream;","out","Ljava/io/OutputStream;"));
                code.visitFieldStmt(SGET_OBJECT,1,-1,new Field("Lorg/mortbay/util/MultiPartOutputStream;","__CRLF","[B"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/io/OutputStream;","write",new String[]{ "[B"},"V"));
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/util/MultiPartOutputStream;","out","Ljava/io/OutputStream;"));
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,2,"Content-Type: ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/util/StringUtil;","__ISO_8859_1","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/lang/String;","getBytes",new String[]{ "Ljava/lang/String;"},"[B"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/io/OutputStream;","write",new String[]{ "[B"},"V"));
                code.visitLabel(L7);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/util/MultiPartOutputStream;","out","Ljava/io/OutputStream;"));
                code.visitFieldStmt(SGET_OBJECT,1,-1,new Field("Lorg/mortbay/util/MultiPartOutputStream;","__CRLF","[B"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/io/OutputStream;","write",new String[]{ "[B"},"V"));
                code.visitLabel(L8);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/util/MultiPartOutputStream;","out","Ljava/io/OutputStream;"));
                code.visitFieldStmt(SGET_OBJECT,1,-1,new Field("Lorg/mortbay/util/MultiPartOutputStream;","__CRLF","[B"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/io/OutputStream;","write",new String[]{ "[B"},"V"));
                code.visitLabel(L9);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_startPart(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/MultiPartOutputStream;","startPart",new String[]{ "Ljava/lang/String;","[Ljava/lang/String;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"contentType");
                ddv.visitParameterName(1,"headers");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(116,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(117,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(118,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(119,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(120,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(121,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(122,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(123,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(124,L8);
                DexLabel L9=new DexLabel();
                ddv.visitStartLocal(0,L9,"i","I",null);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(126,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(127,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(124,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(129,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(130,L14);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_BOOLEAN,1,4,new Field("Lorg/mortbay/util/MultiPartOutputStream;","inPart","Z"));
                code.visitJumpStmt(IF_EQZ,1,-1,L2);
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/util/MultiPartOutputStream;","out","Ljava/io/OutputStream;"));
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/util/MultiPartOutputStream;","__CRLF","[B"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/io/OutputStream;","write",new String[]{ "[B"},"V"));
                code.visitLabel(L2);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitFieldStmt(IPUT_BOOLEAN,1,4,new Field("Lorg/mortbay/util/MultiPartOutputStream;","inPart","Z"));
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/util/MultiPartOutputStream;","out","Ljava/io/OutputStream;"));
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/util/MultiPartOutputStream;","__DASHDASH","[B"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/io/OutputStream;","write",new String[]{ "[B"},"V"));
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/util/MultiPartOutputStream;","out","Ljava/io/OutputStream;"));
                code.visitFieldStmt(IGET_OBJECT,2,4,new Field("Lorg/mortbay/util/MultiPartOutputStream;","boundaryBytes","[B"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/io/OutputStream;","write",new String[]{ "[B"},"V"));
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/util/MultiPartOutputStream;","out","Ljava/io/OutputStream;"));
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/util/MultiPartOutputStream;","__CRLF","[B"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/io/OutputStream;","write",new String[]{ "[B"},"V"));
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/util/MultiPartOutputStream;","out","Ljava/io/OutputStream;"));
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,3,"Content-Type: ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitFieldStmt(SGET_OBJECT,3,-1,new Field("Lorg/mortbay/util/StringUtil;","__ISO_8859_1","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/String;","getBytes",new String[]{ "Ljava/lang/String;"},"[B"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/io/OutputStream;","write",new String[]{ "[B"},"V"));
                code.visitLabel(L7);
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/util/MultiPartOutputStream;","out","Ljava/io/OutputStream;"));
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/util/MultiPartOutputStream;","__CRLF","[B"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/io/OutputStream;","write",new String[]{ "[B"},"V"));
                code.visitLabel(L8);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L9);
                code.visitJumpStmt(IF_EQZ,6,-1,L13);
                code.visitStmt2R(ARRAY_LENGTH,1,6);
                code.visitJumpStmt(IF_GE,0,1,L13);
                code.visitLabel(L10);
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/util/MultiPartOutputStream;","out","Ljava/io/OutputStream;"));
                code.visitStmt3R(AGET_OBJECT,2,6,0);
                code.visitFieldStmt(SGET_OBJECT,3,-1,new Field("Lorg/mortbay/util/StringUtil;","__ISO_8859_1","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/String;","getBytes",new String[]{ "Ljava/lang/String;"},"[B"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/io/OutputStream;","write",new String[]{ "[B"},"V"));
                code.visitLabel(L11);
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/util/MultiPartOutputStream;","out","Ljava/io/OutputStream;"));
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/util/MultiPartOutputStream;","__CRLF","[B"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/io/OutputStream;","write",new String[]{ "[B"},"V"));
                code.visitLabel(L12);
                code.visitStmt2R1N(ADD_INT_LIT8,0,0,1);
                code.visitJumpStmt(GOTO,-1,-1,L9);
                code.visitLabel(L13);
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/util/MultiPartOutputStream;","out","Ljava/io/OutputStream;"));
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/util/MultiPartOutputStream;","__CRLF","[B"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/io/OutputStream;","write",new String[]{ "[B"},"V"));
                code.visitLabel(L14);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
