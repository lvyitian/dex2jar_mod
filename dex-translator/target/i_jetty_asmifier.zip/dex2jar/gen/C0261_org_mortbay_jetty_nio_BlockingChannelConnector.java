package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0261_org_mortbay_jetty_nio_BlockingChannelConnector {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/jetty/nio/BlockingChannelConnector;","Lorg/mortbay/jetty/nio/AbstractNIOConnector;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("BlockingChannelConnector.java");
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/MemberClasses;", Visibility.SYSTEM);
            if(av00 != null) {
                {
                    DexAnnotationVisitor av01 = av00.visitArray("value");
                    if(av01 != null) {
                        av01.visit(null, new DexType("Lorg/mortbay/jetty/nio/BlockingChannelConnector$Connection;"));
                        av01.visitEnd();
                    }
                }
                av00.visitEnd();
            }
        }
        f000__acceptChannel(cv);
        m000__init_(cv);
        m001_access$000(cv);
        m002_access$100(cv);
        m003_accept(cv);
        m004_close(cv);
        m005_customize(cv);
        m006_getConnection(cv);
        m007_getLocalPort(cv);
        m008_open(cv);
    }
    public static void f000__acceptChannel(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_TRANSIENT, new Field("Lorg/mortbay/jetty/nio/BlockingChannelConnector;","_acceptChannel","Ljava/nio/channels/ServerSocketChannel;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/nio/BlockingChannelConnector;","<init>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(54,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(55,L1);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Lorg/mortbay/jetty/nio/AbstractNIOConnector;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001_access$000(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_SYNTHETIC, new Method("Lorg/mortbay/jetty/nio/BlockingChannelConnector;","access$000",new String[]{ "Lorg/mortbay/jetty/nio/BlockingChannelConnector;","Lorg/mortbay/jetty/HttpConnection;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"x0");
                ddv.visitParameterName(1,"x1");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(45,L0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/nio/BlockingChannelConnector;","connectionOpened",new String[]{ "Lorg/mortbay/jetty/HttpConnection;"},"V"));
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_access$100(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_SYNTHETIC, new Method("Lorg/mortbay/jetty/nio/BlockingChannelConnector;","access$100",new String[]{ "Lorg/mortbay/jetty/nio/BlockingChannelConnector;","Lorg/mortbay/jetty/HttpConnection;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"x0");
                ddv.visitParameterName(1,"x1");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(45,L0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/nio/BlockingChannelConnector;","connectionClosed",new String[]{ "Lorg/mortbay/jetty/HttpConnection;"},"V"));
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_accept(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/nio/BlockingChannelConnector;","accept",new String[]{ "I"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visit(null, new DexType("Ljava/lang/InterruptedException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"acceptorID");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(87,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(88,L1);
                ddv.visitStartLocal(0,L1,"channel","Ljava/nio/channels/SocketChannel;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(89,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(90,L3);
                ddv.visitStartLocal(2,L3,"socket","Ljava/net/Socket;",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(92,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(93,L5);
                ddv.visitStartLocal(1,L5,"connection","Lorg/mortbay/jetty/nio/BlockingChannelConnector$Connection;",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(94,L6);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,3,4,new Field("Lorg/mortbay/jetty/nio/BlockingChannelConnector;","_acceptChannel","Ljava/nio/channels/ServerSocketChannel;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/nio/channels/ServerSocketChannel;","accept",new String[]{ },"Ljava/nio/channels/SocketChannel;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,3},new Method("Ljava/nio/channels/SocketChannel;","configureBlocking",new String[]{ "Z"},"Ljava/nio/channels/SelectableChannel;"));
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/nio/channels/SocketChannel;","socket",new String[]{ },"Ljava/net/Socket;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,2},new Method("Lorg/mortbay/jetty/nio/BlockingChannelConnector;","configure",new String[]{ "Ljava/net/Socket;"},"V"));
                code.visitLabel(L4);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Lorg/mortbay/jetty/nio/BlockingChannelConnector$Connection;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,4,0},new Method("Lorg/mortbay/jetty/nio/BlockingChannelConnector$Connection;","<init>",new String[]{ "Lorg/mortbay/jetty/nio/BlockingChannelConnector;","Ljava/nio/channels/ByteChannel;"},"V"));
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/jetty/nio/BlockingChannelConnector$Connection;","dispatch",new String[]{ },"V"));
                code.visitLabel(L6);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_close(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/nio/BlockingChannelConnector;","close",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(78,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(79,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(80,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(81,L3);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/nio/BlockingChannelConnector;","_acceptChannel","Ljava/nio/channels/ServerSocketChannel;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L2);
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/nio/BlockingChannelConnector;","_acceptChannel","Ljava/nio/channels/ServerSocketChannel;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/nio/channels/ServerSocketChannel;","close",new String[]{ },"V"));
                code.visitLabel(L2);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/nio/BlockingChannelConnector;","_acceptChannel","Ljava/nio/channels/ServerSocketChannel;"));
                code.visitLabel(L3);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_customize(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/nio/BlockingChannelConnector;","customize",new String[]{ "Lorg/mortbay/io/EndPoint;","Lorg/mortbay/jetty/Request;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"endpoint");
                ddv.visitParameterName(1,"request");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(100,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(101,L1);
                ddv.visitStartLocal(1,L1,"connection","Lorg/mortbay/jetty/nio/BlockingChannelConnector$Connection;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(103,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(104,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(107,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(108,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(109,L6);
                code.visitLabel(L0);
                code.visitStmt2R(MOVE_OBJECT,0,5);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Lorg/mortbay/jetty/nio/BlockingChannelConnector$Connection;");
                code.visitStmt2R(MOVE_OBJECT,1,0);
                code.visitLabel(L1);
                code.visitFieldStmt(IGET,2,1,new Field("Lorg/mortbay/jetty/nio/BlockingChannelConnector$Connection;","_sotimeout","I"));
                code.visitFieldStmt(IGET,3,4,new Field("Lorg/mortbay/jetty/nio/BlockingChannelConnector;","_maxIdleTime","I"));
                code.visitJumpStmt(IF_EQ,2,3,L4);
                code.visitLabel(L2);
                code.visitFieldStmt(IGET,2,4,new Field("Lorg/mortbay/jetty/nio/BlockingChannelConnector;","_maxIdleTime","I"));
                code.visitFieldStmt(IPUT,2,1,new Field("Lorg/mortbay/jetty/nio/BlockingChannelConnector$Connection;","_sotimeout","I"));
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 5},new Method("Lorg/mortbay/io/EndPoint;","getTransport",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitTypeStmt(CHECK_CAST,2,-1,"Ljava/nio/channels/SocketChannel;");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/nio/channels/SocketChannel;","socket",new String[]{ },"Ljava/net/Socket;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitFieldStmt(IGET,3,4,new Field("Lorg/mortbay/jetty/nio/BlockingChannelConnector;","_maxIdleTime","I"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/net/Socket;","setSoTimeout",new String[]{ "I"},"V"));
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 4,5,6},new Method("Lorg/mortbay/jetty/nio/AbstractNIOConnector;","customize",new String[]{ "Lorg/mortbay/io/EndPoint;","Lorg/mortbay/jetty/Request;"},"V"));
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 5},new Method("Lorg/mortbay/io/EndPoint;","getTransport",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitTypeStmt(CHECK_CAST,2,-1,"Ljava/nio/channels/SocketChannel;");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/nio/channels/SocketChannel;","socket",new String[]{ },"Ljava/net/Socket;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,2},new Method("Lorg/mortbay/jetty/nio/BlockingChannelConnector;","configure",new String[]{ "Ljava/net/Socket;"},"V"));
                code.visitLabel(L6);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_getConnection(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/nio/BlockingChannelConnector;","getConnection",new String[]{ },"Ljava/lang/Object;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(60,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/nio/BlockingChannelConnector;","_acceptChannel","Ljava/nio/channels/ServerSocketChannel;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m007_getLocalPort(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/nio/BlockingChannelConnector;","getLocalPort",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(115,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(116,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(117,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/nio/BlockingChannelConnector;","_acceptChannel","Ljava/nio/channels/ServerSocketChannel;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L1);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/nio/BlockingChannelConnector;","_acceptChannel","Ljava/nio/channels/ServerSocketChannel;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/nio/channels/ServerSocketChannel;","isOpen",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                DexLabel L3=new DexLabel();
                code.visitJumpStmt(IF_NEZ,0,-1,L3);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(-1)); // int: 0xffffffff  float:NaN
                code.visitLabel(L2);
                code.visitStmt1R(RETURN,0);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/nio/BlockingChannelConnector;","_acceptChannel","Ljava/nio/channels/ServerSocketChannel;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/nio/channels/ServerSocketChannel;","socket",new String[]{ },"Ljava/net/ServerSocket;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/net/ServerSocket;","getLocalPort",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m008_open(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/nio/BlockingChannelConnector;","open",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(67,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(68,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(71,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(72,L3);
                ddv.visitStartLocal(0,L3,"addr","Ljava/net/InetSocketAddress;",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(73,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(71,L5);
                ddv.visitEndLocal(0,L5);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Ljava/nio/channels/ServerSocketChannel;","open",new String[]{ },"Ljava/nio/channels/ServerSocketChannel;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitFieldStmt(IPUT_OBJECT,1,4,new Field("Lorg/mortbay/jetty/nio/BlockingChannelConnector;","_acceptChannel","Ljava/nio/channels/ServerSocketChannel;"));
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/jetty/nio/BlockingChannelConnector;","_acceptChannel","Ljava/nio/channels/ServerSocketChannel;"));
                code.visitConstStmt(CONST_4,2, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/nio/channels/ServerSocketChannel;","configureBlocking",new String[]{ "Z"},"Ljava/nio/channels/SelectableChannel;"));
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/jetty/nio/BlockingChannelConnector;","getHost",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitJumpStmt(IF_NEZ,1,-1,L5);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/net/InetSocketAddress;");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/jetty/nio/BlockingChannelConnector;","getPort",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,2},new Method("Ljava/net/InetSocketAddress;","<init>",new String[]{ "I"},"V"));
                code.visitStmt2R(MOVE_OBJECT,0,1);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/jetty/nio/BlockingChannelConnector;","_acceptChannel","Ljava/nio/channels/ServerSocketChannel;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/nio/channels/ServerSocketChannel;","socket",new String[]{ },"Ljava/net/ServerSocket;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/jetty/nio/BlockingChannelConnector;","getAcceptQueueSize",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,0,2},new Method("Ljava/net/ServerSocket;","bind",new String[]{ "Ljava/net/SocketAddress;","I"},"V"));
                code.visitLabel(L4);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L5);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/net/InetSocketAddress;");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/jetty/nio/BlockingChannelConnector;","getHost",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/jetty/nio/BlockingChannelConnector;","getPort",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,2,3},new Method("Ljava/net/InetSocketAddress;","<init>",new String[]{ "Ljava/lang/String;","I"},"V"));
                code.visitStmt2R(MOVE_OBJECT,0,1);
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
