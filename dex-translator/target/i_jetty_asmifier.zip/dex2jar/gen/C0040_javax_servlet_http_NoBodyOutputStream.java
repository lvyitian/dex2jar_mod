package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0040_javax_servlet_http_NoBodyOutputStream {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(0,"Ljavax/servlet/http/NoBodyOutputStream;","Ljavax/servlet/ServletOutputStream;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("HttpServlet.java");
        f000_LSTRING_FILE(cv);
        f001_lStrings(cv);
        f002_contentLength(cv);
        m000__clinit_(cv);
        m001__init_(cv);
        m002_getContentLength(cv);
        m003_write(cv);
        m004_write(cv);
    }
    public static void f000_LSTRING_FILE(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC|ACC_FINAL, new Field("Ljavax/servlet/http/NoBodyOutputStream;","LSTRING_FILE","Ljava/lang/String;"), "javax.servlet.http.LocalStrings");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001_lStrings(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC, new Field("Ljavax/servlet/http/NoBodyOutputStream;","lStrings","Ljava/util/ResourceBundle;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002_contentLength(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Ljavax/servlet/http/NoBodyOutputStream;","contentLength","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__clinit_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_CONSTRUCTOR, new Method("Ljavax/servlet/http/NoBodyOutputStream;","<clinit>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1018,L0);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_STRING,0,"javax.servlet.http.LocalStrings");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Ljava/util/ResourceBundle;","getBundle",new String[]{ "Ljava/lang/String;"},"Ljava/util/ResourceBundle;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Ljavax/servlet/http/NoBodyOutputStream;","lStrings","Ljava/util/ResourceBundle;"));
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_CONSTRUCTOR, new Method("Ljavax/servlet/http/NoBodyOutputStream;","<init>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1024,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(1021,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(1024,L2);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljavax/servlet/ServletOutputStream;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT,0,1,new Field("Ljavax/servlet/http/NoBodyOutputStream;","contentLength","I"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_getContentLength(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(0, new Method("Ljavax/servlet/http/NoBodyOutputStream;","getContentLength",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1028,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,1,new Field("Ljavax/servlet/http/NoBodyOutputStream;","contentLength","I"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_write(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Ljavax/servlet/http/NoBodyOutputStream;","write",new String[]{ "I"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"b");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1032,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(1033,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,1,new Field("Ljavax/servlet/http/NoBodyOutputStream;","contentLength","I"));
                code.visitStmt2R1N(ADD_INT_LIT8,0,0,1);
                code.visitFieldStmt(IPUT,0,1,new Field("Ljavax/servlet/http/NoBodyOutputStream;","contentLength","I"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_write(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Ljavax/servlet/http/NoBodyOutputStream;","write",new String[]{ "[B","I","I"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"buf");
                ddv.visitParameterName(1,"offset");
                ddv.visitParameterName(2,"len");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1038,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(1039,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(1047,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(1044,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(1045,L4);
                ddv.visitStartLocal(0,L4,"msg","Ljava/lang/String;",null);
                code.visitLabel(L0);
                code.visitJumpStmt(IF_LTZ,6,-1,L3);
                code.visitLabel(L1);
                code.visitFieldStmt(IGET,1,3,new Field("Ljavax/servlet/http/NoBodyOutputStream;","contentLength","I"));
                code.visitStmt2R(ADD_INT_2ADDR,1,6);
                code.visitFieldStmt(IPUT,1,3,new Field("Ljavax/servlet/http/NoBodyOutputStream;","contentLength","I"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L3);
                code.visitFieldStmt(SGET_OBJECT,1,-1,new Field("Ljavax/servlet/http/NoBodyOutputStream;","lStrings","Ljava/util/ResourceBundle;"));
                code.visitConstStmt(CONST_STRING,2,"err.io.negativelength");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/util/ResourceBundle;","getString",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L4);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/io/IOException;");
                code.visitConstStmt(CONST_STRING,2,"negative length");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,2},new Method("Ljava/io/IOException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
