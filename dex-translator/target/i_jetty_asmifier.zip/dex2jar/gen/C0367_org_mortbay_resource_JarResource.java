package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0367_org_mortbay_resource_JarResource {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/resource/JarResource;","Lorg/mortbay/resource/URLResource;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("JarResource.java");
        f000__jarConnection(cv);
        m000__init_(cv);
        m001__init_(cv);
        m002_extract(cv);
        m003_checkConnection(cv);
        m004_exists(cv);
        m005_extract(cv);
        m006_getFile(cv);
        m007_getInputStream(cv);
        m008_newConnection(cv);
        m009_release(cv);
    }
    public static void f000__jarConnection(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED|ACC_TRANSIENT, new Field("Lorg/mortbay/resource/JarResource;","_jarConnection","Ljava/net/JarURLConnection;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_CONSTRUCTOR, new Method("Lorg/mortbay/resource/JarResource;","<init>",new String[]{ "Ljava/net/URL;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"url");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(40,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(41,L1);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,2,0},new Method("Lorg/mortbay/resource/URLResource;","<init>",new String[]{ "Ljava/net/URL;","Ljava/net/URLConnection;"},"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_CONSTRUCTOR, new Method("Lorg/mortbay/resource/JarResource;","<init>",new String[]{ "Ljava/net/URL;","Z"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"url");
                ddv.visitParameterName(1,"useCaches");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(46,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(47,L1);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,2,0,3},new Method("Lorg/mortbay/resource/URLResource;","<init>",new String[]{ "Ljava/net/URL;","Ljava/net/URLConnection;","Z"},"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_extract(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/resource/JarResource;","extract",new String[]{ "Lorg/mortbay/resource/Resource;","Ljava/io/File;","Z"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(13);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                code.visitTryCatch(L1,L3,new DexLabel[]{L4},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"resource");
                ddv.visitParameterName(1,"directory");
                ddv.visitParameterName(2,"deleteOnExit");
                DexLabel L5=new DexLabel();
                ddv.visitPrologue(L5);
                ddv.visitLineNumber(122,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(125,L6);
                DexLabel L7=new DexLabel();
                ddv.visitEndLocal(10,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(126,L8);
                ddv.visitStartLocal(2,L8,"urlString","Ljava/lang/String;",null);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(127,L9);
                ddv.visitStartLocal(10,L9,"endOfJarUrl","I",null);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(129,L10);
                ddv.visitStartLocal(1,L10,"startOfJarUrl","I",null);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(130,L11);
                DexLabel L12=new DexLabel();
                ddv.visitEndLocal(10,L12);
                DexLabel L13=new DexLabel();
                ddv.visitEndLocal(11,L13);
                DexLabel L14=new DexLabel();
                ddv.visitEndLocal(12,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(127,L15);
                ddv.visitEndLocal(1,L15);
                ddv.visitRestartLocal(10,L15);
                ddv.visitRestartLocal(11,L15);
                ddv.visitRestartLocal(12,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(132,L16);
                ddv.visitRestartLocal(1,L16);
                DexLabel L17=new DexLabel();
                ddv.visitEndLocal(1,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(133,L18);
                ddv.visitStartLocal(0,L18,"jarFileURL","Ljava/net/URL;",null);
                DexLabel L19=new DexLabel();
                ddv.visitEndLocal(10,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(134,L20);
                ddv.visitStartLocal(5,L20,"subEntryName","Ljava/lang/String;",null);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(136,L21);
                ddv.visitStartLocal(4,L21,"subEntryIsDir","Z",null);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(138,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(139,L23);
                ddv.visitStartLocal(10,L23,"is","Ljava/io/InputStream;",null);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(142,L24);
                ddv.visitEndLocal(2,L24);
                ddv.visitEndLocal(0,L24);
                ddv.visitEndLocal(10,L24);
                ddv.visitStartLocal(3,L24,"jin","Ljava/util/jar/JarInputStream;",null);
                DexLabel L25=new DexLabel();
                ddv.visitStartLocal(0,L25,"entry","Ljava/util/jar/JarEntry;",null);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(144,L26);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(145,L27);
                ddv.visitStartLocal(10,L27,"entryName","Ljava/lang/String;",null);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(149,L28);
                DexLabel L29=new DexLabel();
                ddv.visitLineNumber(155,L29);
                DexLabel L30=new DexLabel();
                ddv.visitLineNumber(156,L30);
                DexLabel L31=new DexLabel();
                ddv.visitLineNumber(159,L31);
                DexLabel L32=new DexLabel();
                ddv.visitLineNumber(180,L32);
                ddv.visitStartLocal(1,L32,"shouldExtract","Z",null);
                DexLabel L33=new DexLabel();
                ddv.visitLineNumber(182,L33);
                DexLabel L34=new DexLabel();
                ddv.visitEndLocal(0,L34);
                DexLabel L35=new DexLabel();
                ddv.visitEndLocal(1,L35);
                DexLabel L36=new DexLabel();
                ddv.visitEndLocal(10,L36);
                DexLabel L37=new DexLabel();
                ddv.visitLineNumber(133,L37);
                ddv.visitEndLocal(5,L37);
                ddv.visitEndLocal(4,L37);
                ddv.visitEndLocal(3,L37);
                ddv.visitStartLocal(0,L37,"jarFileURL","Ljava/net/URL;",null);
                ddv.visitRestartLocal(2,L37);
                ddv.visitStartLocal(10,L37,"endOfJarUrl","I",null);
                DexLabel L38=new DexLabel();
                ddv.visitLineNumber(134,L38);
                ddv.visitEndLocal(10,L38);
                ddv.visitRestartLocal(5,L38);
                DexLabel L39=new DexLabel();
                ddv.visitLineNumber(162,L39);
                ddv.visitEndLocal(2,L39);
                ddv.visitStartLocal(0,L39,"entry","Ljava/util/jar/JarEntry;",null);
                ddv.visitRestartLocal(3,L39);
                ddv.visitRestartLocal(4,L39);
                ddv.visitStartLocal(10,L39,"entryName","Ljava/lang/String;",null);
                DexLabel L40=new DexLabel();
                ddv.visitRestartLocal(1,L40);
                DexLabel L41=new DexLabel();
                ddv.visitLineNumber(165,L41);
                ddv.visitEndLocal(1,L41);
                DexLabel L42=new DexLabel();
                ddv.visitRestartLocal(1,L42);
                DexLabel L43=new DexLabel();
                ddv.visitLineNumber(167,L43);
                ddv.visitEndLocal(1,L43);
                DexLabel L44=new DexLabel();
                ddv.visitLineNumber(171,L44);
                DexLabel L45=new DexLabel();
                ddv.visitRestartLocal(1,L45);
                DexLabel L46=new DexLabel();
                ddv.visitLineNumber(176,L46);
                ddv.visitEndLocal(1,L46);
                DexLabel L47=new DexLabel();
                ddv.visitRestartLocal(1,L47);
                DexLabel L48=new DexLabel();
                ddv.visitLineNumber(187,L48);
                DexLabel L49=new DexLabel();
                ddv.visitEndLocal(1,L49);
                DexLabel L50=new DexLabel();
                ddv.visitLineNumber(188,L50);
                ddv.visitStartLocal(1,L50,"file","Ljava/io/File;",null);
                DexLabel L51=new DexLabel();
                ddv.visitEndLocal(10,L51);
                DexLabel L52=new DexLabel();
                ddv.visitLineNumber(191,L52);
                DexLabel L53=new DexLabel();
                ddv.visitLineNumber(192,L53);
                DexLabel L54=new DexLabel();
                ddv.visitLineNumber(217,L54);
                DexLabel L55=new DexLabel();
                ddv.visitLineNumber(218,L55);
                DexLabel L56=new DexLabel();
                ddv.visitLineNumber(197,L56);
                DexLabel L57=new DexLabel();
                ddv.visitLineNumber(198,L57);
                ddv.visitStartLocal(10,L57,"dir","Ljava/io/File;",null);
                DexLabel L58=new DexLabel();
                ddv.visitLineNumber(199,L58);
                DexLabel L59=new DexLabel();
                ddv.visitLineNumber(202,L59);
                ddv.visitLineNumber(205,L0);
                ddv.visitStartLocal(10,L0,"fout","Ljava/io/FileOutputStream;",null);
                ddv.visitLineNumber(206,L1);
                ddv.visitStartLocal(2,L1,"fout","Ljava/io/FileOutputStream;",null);
                ddv.visitLineNumber(210,L3);
                ddv.visitEndLocal(10,L3);
                DexLabel L60=new DexLabel();
                ddv.visitLineNumber(214,L60);
                DexLabel L61=new DexLabel();
                ddv.visitLineNumber(215,L61);
                ddv.visitLineNumber(210,L2);
                ddv.visitEndLocal(2,L2);
                ddv.visitRestartLocal(10,L2);
                DexLabel L62=new DexLabel();
                ddv.visitEndLocal(11,L62);
                DexLabel L63=new DexLabel();
                ddv.visitLineNumber(221,L63);
                ddv.visitEndLocal(1,L63);
                ddv.visitEndLocal(10,L63);
                ddv.visitRestartLocal(11,L63);
                DexLabel L64=new DexLabel();
                ddv.visitLineNumber(223,L64);
                DexLabel L65=new DexLabel();
                ddv.visitLineNumber(224,L65);
                ddv.visitStartLocal(12,L65,"manifest","Ljava/util/jar/Manifest;",null);
                DexLabel L66=new DexLabel();
                ddv.visitLineNumber(226,L66);
                DexLabel L67=new DexLabel();
                ddv.visitEndLocal(0,L67);
                DexLabel L68=new DexLabel();
                ddv.visitLineNumber(227,L68);
                ddv.visitStartLocal(0,L68,"metaInf","Ljava/io/File;",null);
                DexLabel L69=new DexLabel();
                ddv.visitLineNumber(228,L69);
                DexLabel L70=new DexLabel();
                ddv.visitEndLocal(11,L70);
                DexLabel L71=new DexLabel();
                ddv.visitLineNumber(229,L71);
                ddv.visitStartLocal(10,L71,"f","Ljava/io/File;",null);
                DexLabel L72=new DexLabel();
                ddv.visitLineNumber(230,L72);
                ddv.visitStartLocal(11,L72,"fout","Ljava/io/FileOutputStream;",null);
                DexLabel L73=new DexLabel();
                ddv.visitLineNumber(231,L73);
                DexLabel L74=new DexLabel();
                ddv.visitLineNumber(234,L74);
                ddv.visitEndLocal(12,L74);
                ddv.visitEndLocal(0,L74);
                ddv.visitEndLocal(10,L74);
                ddv.visitEndLocal(11,L74);
                DexLabel L75=new DexLabel();
                ddv.visitLineNumber(235,L75);
                ddv.visitLineNumber(210,L4);
                ddv.visitStartLocal(0,L4,"entry","Ljava/util/jar/JarEntry;",null);
                ddv.visitRestartLocal(1,L4);
                ddv.visitRestartLocal(2,L4);
                ddv.visitStartLocal(11,L4,"directory","Ljava/io/File;",null);
                ddv.visitStartLocal(12,L4,"deleteOnExit","Z",null);
                DexLabel L76=new DexLabel();
                ddv.visitStartLocal(10,L76,"fout","Ljava/io/FileOutputStream;",null);
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/log/Log;","isDebugEnabled",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L6);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,1,"Extract ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,10},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitConstStmt(CONST_STRING,1," to ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,11},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Lorg/mortbay/resource/Resource;","getURL",new String[]{ },"Ljava/net/URL;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,10);
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Ljava/net/URL;","toExternalForm",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Ljava/lang/String;","trim",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L8);
                code.visitConstStmt(CONST_STRING,10,"!/");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,10},new Method("Ljava/lang/String;","indexOf",new String[]{ "Ljava/lang/String;"},"I"));
                code.visitStmt1R(MOVE_RESULT,10);
                code.visitLabel(L9);
                code.visitJumpStmt(IF_LTZ,10,-1,L15);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(4)); // int: 0x00000004  float:0.000000
                code.visitStmt2R(MOVE,1,0);
                code.visitLabel(L10);
                code.visitJumpStmt(IF_GEZ,10,-1,L16);
                code.visitLabel(L11);
                code.visitTypeStmt(NEW_INSTANCE,10,-1,"Ljava/io/IOException;");
                code.visitLabel(L12);
                code.visitTypeStmt(NEW_INSTANCE,11,-1,"Ljava/lang/StringBuilder;");
                code.visitLabel(L13);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 11},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,12,"Not a valid jar url: ");
                code.visitLabel(L14);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11,12},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,11);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,11);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,11);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 10,11},new Method("Ljava/io/IOException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,10);
                code.visitLabel(L15);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt2R(MOVE,1,0);
                code.visitJumpStmt(GOTO,-1,-1,L10);
                code.visitLabel(L16);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/net/URL;");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,1,10},new Method("Ljava/lang/String;","substring",new String[]{ "I","I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L17);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Ljava/net/URL;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L18);
                code.visitStmt2R1N(ADD_INT_LIT8,1,10,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_GE,1,3,L37);
                code.visitStmt2R1N(ADD_INT_LIT8,10,10,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,10},new Method("Ljava/lang/String;","substring",new String[]{ "I"},"Ljava/lang/String;"));
                code.visitLabel(L19);
                code.visitStmt1R(MOVE_RESULT_OBJECT,10);
                code.visitStmt2R(MOVE_OBJECT,5,10);
                code.visitLabel(L20);
                code.visitJumpStmt(IF_EQZ,5,-1,L38);
                code.visitConstStmt(CONST_STRING,10,"/");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,10},new Method("Ljava/lang/String;","endsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,10);
                code.visitJumpStmt(IF_EQZ,10,-1,L38);
                code.visitConstStmt(CONST_4,10, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt2R(MOVE,4,10);
                code.visitLabel(L21);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/log/Log;","isDebugEnabled",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,10);
                code.visitJumpStmt(IF_EQZ,10,-1,L22);
                code.visitTypeStmt(NEW_INSTANCE,10,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 10},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,1,"Extracting entry = ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,10);
                code.visitConstStmt(CONST_STRING,1," from jar ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10,0},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,10);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 10},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L22);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/net/URL;","openConnection",new String[]{ },"Ljava/net/URLConnection;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Ljava/net/URLConnection;","getInputStream",new String[]{ },"Ljava/io/InputStream;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,10);
                code.visitLabel(L23);
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Ljava/util/jar/JarInputStream;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3,10},new Method("Ljava/util/jar/JarInputStream;","<init>",new String[]{ "Ljava/io/InputStream;"},"V"));
                code.visitLabel(L24);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/util/jar/JarInputStream;","getNextJarEntry",new String[]{ },"Ljava/util/jar/JarEntry;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L25);
                code.visitJumpStmt(IF_EQZ,0,-1,L63);
                code.visitLabel(L26);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/util/jar/JarEntry;","getName",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,10);
                code.visitLabel(L27);
                code.visitJumpStmt(IF_EQZ,5,-1,L43);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10,5},new Method("Ljava/lang/String;","startsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_EQZ,1,-1,L43);
                code.visitLabel(L28);
                code.visitJumpStmt(IF_EQZ,4,-1,L41);
                code.visitLabel(L29);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10,1},new Method("Ljava/lang/String;","substring",new String[]{ "I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,10);
                code.visitLabel(L30);
                code.visitConstStmt(CONST_STRING,1,"");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10,1},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_NEZ,1,-1,L39);
                code.visitLabel(L31);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L32);
                code.visitJumpStmt(IF_NEZ,1,-1,L48);
                code.visitLabel(L33);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/log/Log;","isDebugEnabled",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitLabel(L34);
                code.visitJumpStmt(IF_EQZ,0,-1,L24);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,1,"Skipping entry: ");
                code.visitLabel(L35);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,10},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,10);
                code.visitLabel(L36);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,10);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 10},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L24);
                code.visitLabel(L37);
                code.visitConstStmt(CONST_4,10, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt2R(MOVE_OBJECT,5,10);
                code.visitJumpStmt(GOTO_16,-1,-1,L20);
                code.visitLabel(L38);
                code.visitConstStmt(CONST_4,10, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt2R(MOVE,4,10);
                code.visitJumpStmt(GOTO,-1,-1,L21);
                code.visitLabel(L39);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L40);
                code.visitJumpStmt(GOTO,-1,-1,L32);
                code.visitLabel(L41);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L42);
                code.visitJumpStmt(GOTO,-1,-1,L32);
                code.visitLabel(L43);
                code.visitJumpStmt(IF_EQZ,5,-1,L46);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10,5},new Method("Ljava/lang/String;","startsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_NEZ,1,-1,L46);
                code.visitLabel(L44);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L45);
                code.visitJumpStmt(GOTO,-1,-1,L32);
                code.visitLabel(L46);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L47);
                code.visitJumpStmt(GOTO,-1,-1,L32);
                code.visitLabel(L48);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/io/File;");
                code.visitLabel(L49);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,11,10},new Method("Ljava/io/File;","<init>",new String[]{ "Ljava/io/File;","Ljava/lang/String;"},"V"));
                code.visitLabel(L50);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/util/jar/JarEntry;","isDirectory",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,10);
                code.visitLabel(L51);
                code.visitJumpStmt(IF_EQZ,10,-1,L56);
                code.visitLabel(L52);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/io/File;","exists",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,10);
                code.visitJumpStmt(IF_NEZ,10,-1,L54);
                code.visitLabel(L53);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/io/File;","mkdirs",new String[]{ },"Z"));
                code.visitLabel(L54);
                code.visitJumpStmt(IF_EQZ,12,-1,L24);
                code.visitLabel(L55);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/io/File;","deleteOnExit",new String[]{ },"V"));
                code.visitJumpStmt(GOTO,-1,-1,L24);
                code.visitLabel(L56);
                code.visitTypeStmt(NEW_INSTANCE,10,-1,"Ljava/io/File;");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/io/File;","getParent",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 10,2},new Method("Ljava/io/File;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L57);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Ljava/io/File;","exists",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_NEZ,2,-1,L59);
                code.visitLabel(L58);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Ljava/io/File;","mkdirs",new String[]{ },"Z"));
                code.visitLabel(L59);
                code.visitConstStmt(CONST_4,10, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Ljava/io/FileOutputStream;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2,1},new Method("Ljava/io/FileOutputStream;","<init>",new String[]{ "Ljava/io/File;"},"V"));
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3,2},new Method("Lorg/mortbay/util/IO;","copy",new String[]{ "Ljava/io/InputStream;","Ljava/io/OutputStream;"},"V"));
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2},new Method("Lorg/mortbay/util/IO;","close",new String[]{ "Ljava/io/OutputStream;"},"V"));
                code.visitLabel(L60);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/util/jar/JarEntry;","getTime",new String[]{ },"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,6);
                code.visitConstStmt(CONST_WIDE_16,8,Long.valueOf(0L)); // long: 0x0000000000000000  double:0.000000
                code.visitStmt3R(CMP_LONG,10,6,8);
                code.visitJumpStmt(IF_LTZ,10,-1,L54);
                code.visitLabel(L61);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/util/jar/JarEntry;","getTime",new String[]{ },"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,6,7},new Method("Ljava/io/File;","setLastModified",new String[]{ "J"},"Z"));
                code.visitJumpStmt(GOTO,-1,-1,L54);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,11);
                code.visitLabel(L62);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 10},new Method("Lorg/mortbay/util/IO;","close",new String[]{ "Ljava/io/OutputStream;"},"V"));
                code.visitStmt1R(THROW,11);
                code.visitLabel(L63);
                code.visitJumpStmt(IF_EQZ,5,-1,L64);
                code.visitJumpStmt(IF_EQZ,5,-1,L74);
                code.visitConstStmt(CONST_STRING,10,"META-INF/MANIFEST.MF");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,10},new Method("Ljava/lang/String;","equalsIgnoreCase",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,10);
                code.visitJumpStmt(IF_EQZ,10,-1,L74);
                code.visitLabel(L64);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/util/jar/JarInputStream;","getManifest",new String[]{ },"Ljava/util/jar/Manifest;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,12);
                code.visitLabel(L65);
                code.visitJumpStmt(IF_EQZ,12,-1,L74);
                code.visitLabel(L66);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/io/File;");
                code.visitLabel(L67);
                code.visitConstStmt(CONST_STRING,10,"META-INF");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,11,10},new Method("Ljava/io/File;","<init>",new String[]{ "Ljava/io/File;","Ljava/lang/String;"},"V"));
                code.visitLabel(L68);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/io/File;","mkdir",new String[]{ },"Z"));
                code.visitLabel(L69);
                code.visitTypeStmt(NEW_INSTANCE,10,-1,"Ljava/io/File;");
                code.visitConstStmt(CONST_STRING,11,"MANIFEST.MF");
                code.visitLabel(L70);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 10,0,11},new Method("Ljava/io/File;","<init>",new String[]{ "Ljava/io/File;","Ljava/lang/String;"},"V"));
                code.visitLabel(L71);
                code.visitTypeStmt(NEW_INSTANCE,11,-1,"Ljava/io/FileOutputStream;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 11,10},new Method("Ljava/io/FileOutputStream;","<init>",new String[]{ "Ljava/io/File;"},"V"));
                code.visitLabel(L72);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12,11},new Method("Ljava/util/jar/Manifest;","write",new String[]{ "Ljava/io/OutputStream;"},"V"));
                code.visitLabel(L73);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11},new Method("Ljava/io/FileOutputStream;","close",new String[]{ },"V"));
                code.visitLabel(L74);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3},new Method("Lorg/mortbay/util/IO;","close",new String[]{ "Ljava/io/InputStream;"},"V"));
                code.visitLabel(L75);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L4);
                code.visitStmt1R(MOVE_EXCEPTION,10);
                code.visitStmt2R(MOVE_OBJECT,11,10);
                code.visitStmt2R(MOVE_OBJECT,10,2);
                code.visitLabel(L76);
                code.visitJumpStmt(GOTO,-1,-1,L62);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_checkConnection(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/resource/JarResource;","checkConnection",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/io/IOException;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(59,L3);
                ddv.visitLineNumber(62,L0);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(63,L4);
                ddv.visitLineNumber(71,L1);
                ddv.visitLineNumber(65,L2);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(67,L5);
                ddv.visitStartLocal(0,L5,"e","Ljava/io/IOException;",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(68,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(71,L7);
                ddv.visitEndLocal(0,L7);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 3},new Method("Lorg/mortbay/resource/URLResource;","checkConnection",new String[]{ },"Z"));
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/resource/JarResource;","_jarConnection","Ljava/net/JarURLConnection;"));
                code.visitFieldStmt(IGET_OBJECT,2,3,new Field("Lorg/mortbay/resource/JarResource;","_connection","Ljava/net/URLConnection;"));
                code.visitJumpStmt(IF_EQ,1,2,L1);
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/resource/JarResource;","newConnection",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/resource/JarResource;","_jarConnection","Ljava/net/JarURLConnection;"));
                code.visitJumpStmt(IF_EQZ,1,-1,L7);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                DexLabel L8=new DexLabel();
                code.visitLabel(L8);
                code.visitStmt1R(RETURN,1);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitStmt2R(MOVE_OBJECT,0,1);
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/log/Log;","ignore",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitLabel(L6);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_OBJECT,1,3,new Field("Lorg/mortbay/resource/JarResource;","_jarConnection","Ljava/net/JarURLConnection;"));
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitLabel(L7);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L8);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_exists(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/resource/JarResource;","exists",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(89,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(90,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(92,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/resource/JarResource;","_urlString","Ljava/lang/String;"));
                code.visitConstStmt(CONST_STRING,1,"!/");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/String;","endsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                DexLabel L3=new DexLabel();
                code.visitJumpStmt(IF_EQZ,0,-1,L3);
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/resource/JarResource;","checkConnection",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitLabel(L2);
                code.visitStmt1R(RETURN,0);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 2},new Method("Lorg/mortbay/resource/URLResource;","exists",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_extract(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/resource/JarResource;","extract",new String[]{ "Ljava/io/File;","Z"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"directory");
                ddv.visitParameterName(1,"deleteOnExit");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(241,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(242,L1);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,1,2},new Method("Lorg/mortbay/resource/JarResource;","extract",new String[]{ "Lorg/mortbay/resource/Resource;","Ljava/io/File;","Z"},"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_getFile(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/resource/JarResource;","getFile",new String[]{ },"Ljava/io/File;"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(99,L0);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m007_getInputStream(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/resource/JarResource;","getInputStream",new String[]{ },"Ljava/io/InputStream;"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(106,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(107,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(108,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(115,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(113,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(114,L5);
                ddv.visitStartLocal(1,L5,"url","Ljava/net/URL;",null);
                DexLabel L6=new DexLabel();
                ddv.visitStartLocal(0,L6,"is","Ljava/io/InputStream;",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(115,L7);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/resource/JarResource;","checkConnection",new String[]{ },"Z"));
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,2,6,new Field("Lorg/mortbay/resource/JarResource;","_urlString","Ljava/lang/String;"));
                code.visitConstStmt(CONST_STRING,3,"!/");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/String;","endsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_NEZ,2,-1,L4);
                code.visitLabel(L2);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Lorg/mortbay/resource/JarResource$1;");
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 6},new Method("Lorg/mortbay/resource/URLResource;","getInputStream",new String[]{ },"Ljava/io/InputStream;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2,6,3},new Method("Lorg/mortbay/resource/JarResource$1;","<init>",new String[]{ "Lorg/mortbay/resource/JarResource;","Ljava/io/InputStream;"},"V"));
                code.visitLabel(L3);
                code.visitStmt1R(RETURN_OBJECT,2);
                code.visitLabel(L4);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/net/URL;");
                code.visitFieldStmt(IGET_OBJECT,2,6,new Field("Lorg/mortbay/resource/JarResource;","_urlString","Ljava/lang/String;"));
                code.visitConstStmt(CONST_4,3, Integer.valueOf(4)); // int: 0x00000004  float:0.000000
                code.visitFieldStmt(IGET_OBJECT,4,6,new Field("Lorg/mortbay/resource/JarResource;","_urlString","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitConstStmt(CONST_4,5, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitStmt2R(SUB_INT_2ADDR,4,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3,4},new Method("Ljava/lang/String;","substring",new String[]{ "I","I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,2},new Method("Ljava/net/URL;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/net/URL;","openStream",new String[]{ },"Ljava/io/InputStream;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L6);
                code.visitStmt2R(MOVE_OBJECT,2,0);
                code.visitLabel(L7);
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m008_newConnection(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/resource/JarResource;","newConnection",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(80,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(81,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/resource/JarResource;","_connection","Ljava/net/URLConnection;"));
                code.visitTypeStmt(CHECK_CAST,0,-1,"Ljava/net/JarURLConnection;");
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/resource/JarResource;","_jarConnection","Ljava/net/JarURLConnection;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m009_release(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/resource/JarResource;","release",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(52,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(53,L4);
                ddv.visitLineNumber(54,L1);
                ddv.visitLineNumber(52,L2);
                code.visitLabel(L3);
                code.visitStmt1R(MONITOR_ENTER,1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/resource/JarResource;","_jarConnection","Ljava/net/JarURLConnection;"));
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 1},new Method("Lorg/mortbay/resource/URLResource;","release",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitStmt1R(MONITOR_EXIT,1);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,0);
                code.visitStmt1R(MONITOR_EXIT,1);
                code.visitStmt1R(THROW,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
