package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0317_org_mortbay_jetty_servlet_AbstractSessionManager {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC|ACC_ABSTRACT,"Lorg/mortbay/jetty/servlet/AbstractSessionManager;","Lorg/mortbay/component/AbstractLifeCycle;",new String[]{ "Lorg/mortbay/jetty/SessionManager;"});
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("AbstractSessionManager.java");
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/MemberClasses;", Visibility.SYSTEM);
            if(av00 != null) {
                {
                    DexAnnotationVisitor av01 = av00.visitArray("value");
                    if(av01 != null) {
                        av01.visit(null, new DexType("Lorg/mortbay/jetty/servlet/AbstractSessionManager$1;"));
                        av01.visit(null, new DexType("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;"));
                        av01.visit(null, new DexType("Lorg/mortbay/jetty/servlet/AbstractSessionManager$SessionIf;"));
                        av01.visit(null, new DexType("Lorg/mortbay/jetty/servlet/AbstractSessionManager$NullSessionContext;"));
                        av01.visitEnd();
                    }
                }
                av00.visitEnd();
            }
        }
        f000___distantFuture(cv);
        f001___nullSessionContext(cv);
        f002__context(cv);
        f003__dftMaxIdleSecs(cv);
        f004__httpOnly(cv);
        f005__loader(cv);
        f006__maxCookieAge(cv);
        f007__maxSessions(cv);
        f008__minSessions(cv);
        f009__nodeIdInSessionId(cv);
        f010__refreshCookieAge(cv);
        f011__secureCookies(cv);
        f012__sessionAttributeListeners(cv);
        f013__sessionCookie(cv);
        f014__sessionDomain(cv);
        f015__sessionHandler(cv);
        f016__sessionIdManager(cv);
        f017__sessionListeners(cv);
        f018__sessionPath(cv);
        f019__sessionURL(cv);
        f020__sessionURLPrefix(cv);
        f021__usingCookies(cv);
        m000__clinit_(cv);
        m001__init_(cv);
        m002_access$100(cv);
        m003_access(cv);
        m004_addEventListener(cv);
        m005_addSession(cv);
        m006_addSession(cv);
        m007_clearEventListeners(cv);
        m008_complete(cv);
        m009_doStart(cv);
        m010_doStop(cv);
        m011_getClusterId(cv);
        m012_getHttpOnly(cv);
        m013_getHttpSession(cv);
        m014_getIdManager(cv);
        m015_getMaxCookieAge(cv);
        m016_getMaxInactiveInterval(cv);
        m017_getMaxSessions(cv);
        m018_getMetaManager(cv);
        m019_getMinSessions(cv);
        m020_getNodeId(cv);
        m021_getRefreshCookieAge(cv);
        m022_getSecureCookies(cv);
        m023_getSession(cv);
        m024_getSessionCookie(cv);
        m025_getSessionCookie(cv);
        m026_getSessionDomain(cv);
        m027_getSessionHandler(cv);
        m028_getSessionMap(cv);
        m029_getSessionPath(cv);
        m030_getSessionURL(cv);
        m031_getSessionURLPrefix(cv);
        m032_getSessions(cv);
        m033_invalidateSessions(cv);
        m034_isNodeIdInSessionId(cv);
        m035_isUsingCookies(cv);
        m036_isValid(cv);
        m037_newHttpSession(cv);
        m038_newSession(cv);
        m039_removeEventListener(cv);
        m040_removeSession(cv);
        m041_removeSession(cv);
        m042_removeSession(cv);
        m043_resetStats(cv);
        m044_setHttpOnly(cv);
        m045_setIdManager(cv);
        m046_setMaxCookieAge(cv);
        m047_setMaxInactiveInterval(cv);
        m048_setMetaManager(cv);
        m049_setNodeIdInSessionId(cv);
        m050_setRefreshCookieAge(cv);
        m051_setSecureCookies(cv);
        m052_setSessionCookie(cv);
        m053_setSessionDomain(cv);
        m054_setSessionHandler(cv);
        m055_setSessionPath(cv);
        m056_setSessionURL(cv);
        m057_setUsingCookies(cv);
    }
    public static void f000___distantFuture(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","__distantFuture","I"),  Integer.valueOf(628992000));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001___nullSessionContext(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","__nullSessionContext","Ljavax/servlet/http/HttpSessionContext;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002__context(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_context","Lorg/mortbay/jetty/handler/ContextHandler$SContext;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003__dftMaxIdleSecs(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_dftMaxIdleSecs","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f004__httpOnly(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_httpOnly","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f005__loader(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_loader","Ljava/lang/ClassLoader;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f006__maxCookieAge(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_maxCookieAge","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f007__maxSessions(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_maxSessions","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f008__minSessions(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_minSessions","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f009__nodeIdInSessionId(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_nodeIdInSessionId","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f010__refreshCookieAge(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_refreshCookieAge","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f011__secureCookies(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_secureCookies","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f012__sessionAttributeListeners(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_sessionAttributeListeners","Ljava/lang/Object;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f013__sessionCookie(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_sessionCookie","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f014__sessionDomain(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_sessionDomain","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f015__sessionHandler(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_sessionHandler","Lorg/mortbay/jetty/servlet/SessionHandler;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f016__sessionIdManager(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_sessionIdManager","Lorg/mortbay/jetty/SessionIdManager;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f017__sessionListeners(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_sessionListeners","Ljava/lang/Object;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f018__sessionPath(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_sessionPath","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f019__sessionURL(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_sessionURL","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f020__sessionURLPrefix(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_sessionURLPrefix","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f021__usingCookies(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_usingCookies","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__clinit_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","<clinit>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(67,L0);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/jetty/servlet/AbstractSessionManager$NullSessionContext;");
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager$NullSessionContext;","<init>",new String[]{ "Lorg/mortbay/jetty/servlet/AbstractSessionManager$1;"},"V"));
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","__nullSessionContext","Ljavax/servlet/http/HttpSessionContext;"));
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","<init>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(98,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(69,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(74,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(76,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(77,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(79,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(81,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(87,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(88,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(89,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(92,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(99,L12);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(-1)); // int: 0xffffffff  float:NaN
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3},new Method("Lorg/mortbay/component/AbstractLifeCycle;","<init>",new String[]{ },"V"));
                code.visitLabel(L2);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitFieldStmt(IPUT_BOOLEAN,0,3,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_usingCookies","Z"));
                code.visitLabel(L3);
                code.visitFieldStmt(IPUT,2,3,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_dftMaxIdleSecs","I"));
                code.visitLabel(L4);
                code.visitFieldStmt(IPUT_BOOLEAN,1,3,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_httpOnly","Z"));
                code.visitLabel(L5);
                code.visitFieldStmt(IPUT,1,3,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_maxSessions","I"));
                code.visitLabel(L6);
                code.visitFieldStmt(IPUT,1,3,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_minSessions","I"));
                code.visitLabel(L7);
                code.visitFieldStmt(IPUT_BOOLEAN,1,3,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_secureCookies","Z"));
                code.visitLabel(L8);
                code.visitConstStmt(CONST_STRING,0,"JSESSIONID");
                code.visitFieldStmt(IPUT_OBJECT,0,3,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_sessionCookie","Ljava/lang/String;"));
                code.visitLabel(L9);
                code.visitConstStmt(CONST_STRING,0,"jsessionid");
                code.visitFieldStmt(IPUT_OBJECT,0,3,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_sessionURL","Ljava/lang/String;"));
                code.visitLabel(L10);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,1,";");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_sessionURL","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitConstStmt(CONST_STRING,1,"=");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IPUT_OBJECT,0,3,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_sessionURLPrefix","Ljava/lang/String;"));
                code.visitLabel(L11);
                code.visitFieldStmt(IPUT,2,3,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_maxCookieAge","I"));
                code.visitLabel(L12);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_access$100(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_SYNTHETIC, new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","access$100",new String[]{ },"Ljavax/servlet/http/HttpSessionContext;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(62,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","__nullSessionContext","Ljavax/servlet/http/HttpSessionContext;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_access(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","access",new String[]{ "Ljavax/servlet/http/HttpSession;","Z"},"Ljavax/servlet/http/Cookie;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(12);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"session");
                ddv.visitParameterName(1,"secure");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(104,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(106,L1);
                ddv.visitStartLocal(2,L1,"now","J",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(107,L2);
                ddv.visitStartLocal(4,L2,"s","Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(110,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(116,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(117,L5);
                ddv.visitStartLocal(1,L5,"cookie","Ljavax/servlet/http/Cookie;",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(118,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(122,L7);
                ddv.visitEndLocal(1,L7);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Ljava/lang/System;","currentTimeMillis",new String[]{ },"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,2);
                code.visitLabel(L1);
                code.visitStmt2R(MOVE_OBJECT,0,10);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Lorg/mortbay/jetty/servlet/AbstractSessionManager$SessionIf;");
                code.visitStmt2R(MOVE_OBJECT,5,0);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 5},new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager$SessionIf;","getSession",new String[]{ },"Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,2,3},new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","access",new String[]{ "J"},"V"));
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9},new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","isUsingCookies",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,5);
                DexLabel L8=new DexLabel();
                code.visitJumpStmt(IF_EQZ,5,-1,L8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","isIdChanged",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitJumpStmt(IF_NEZ,5,-1,L4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9},new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","getMaxCookieAge",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitJumpStmt(IF_LEZ,5,-1,L8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9},new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","getRefreshCookieAge",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitJumpStmt(IF_LEZ,5,-1,L8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","getCookieSetTime",new String[]{ },"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,5);
                code.visitStmt3R(SUB_LONG,5,2,5);
                code.visitConstStmt(CONST_WIDE_16,7,Long.valueOf(1000L)); // long: 0x00000000000003e8  double:0.000000
                code.visitStmt2R(DIV_LONG_2ADDR,5,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9},new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","getRefreshCookieAge",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitStmt2R(INT_TO_LONG,7,7);
                code.visitStmt3R(CMP_LONG,5,5,7);
                code.visitJumpStmt(IF_LEZ,5,-1,L8);
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,5,9,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_context","Lorg/mortbay/jetty/handler/ContextHandler$SContext;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/jetty/handler/ContextHandler$SContext;","getContextPath",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9,10,5,11},new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","getSessionCookie",new String[]{ "Ljavax/servlet/http/HttpSession;","Ljava/lang/String;","Z"},"Ljavax/servlet/http/Cookie;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","cookieSet",new String[]{ },"V"));
                code.visitLabel(L6);
                code.visitConstStmt(CONST_4,5, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","setIdChanged",new String[]{ "Z"},"V"));
                code.visitStmt2R(MOVE_OBJECT,5,1);
                code.visitLabel(L7);
                code.visitStmt1R(RETURN_OBJECT,5);
                code.visitLabel(L8);
                code.visitConstStmt(CONST_4,5, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L7);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_addEventListener(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","addEventListener",new String[]{ "Ljava/util/EventListener;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"listener");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(128,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(129,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(130,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(131,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(132,L4);
                code.visitLabel(L0);
                code.visitTypeStmt(INSTANCE_OF,0,2,"Ljavax/servlet/http/HttpSessionAttributeListener;");
                code.visitJumpStmt(IF_EQZ,0,-1,L2);
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_sessionAttributeListeners","Ljava/lang/Object;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,2},new Method("Lorg/mortbay/util/LazyList;","add",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_sessionAttributeListeners","Ljava/lang/Object;"));
                code.visitLabel(L2);
                code.visitTypeStmt(INSTANCE_OF,0,2,"Ljavax/servlet/http/HttpSessionListener;");
                code.visitJumpStmt(IF_EQZ,0,-1,L4);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_sessionListeners","Ljava/lang/Object;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,2},new Method("Lorg/mortbay/util/LazyList;","add",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_sessionListeners","Ljava/lang/Object;"));
                code.visitLabel(L4);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_addSession(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED|ACC_ABSTRACT, new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","addSession",new String[]{ "Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;"},"V"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m006_addSession(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","addSession",new String[]{ "Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","Z"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(8);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                code.visitTryCatch(L1,L3,new DexLabel[]{L4},new String[]{ null});
                DexLabel L5=new DexLabel();
                code.visitTryCatch(L3,L5,new DexLabel[]{L2},new String[]{ null});
                DexLabel L6=new DexLabel();
                DexLabel L7=new DexLabel();
                code.visitTryCatch(L6,L7,new DexLabel[]{L4},new String[]{ null});
                DexLabel L8=new DexLabel();
                code.visitTryCatch(L7,L8,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"session");
                ddv.visitParameterName(1,"created");
                DexLabel L9=new DexLabel();
                ddv.visitPrologue(L9);
                ddv.visitLineNumber(555,L9);
                ddv.visitLineNumber(557,L0);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(558,L10);
                ddv.visitLineNumber(560,L1);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(561,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(562,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(563,L13);
                ddv.visitLineNumber(564,L3);
                ddv.visitLineNumber(566,L5);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(568,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(576,L15);
                ddv.visitLineNumber(563,L4);
                ddv.visitLineNumber(564,L2);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(570,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(572,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(573,L18);
                ddv.visitStartLocal(0,L18,"event","Ljavax/servlet/http/HttpSessionEvent;",null);
                DexLabel L19=new DexLabel();
                ddv.visitStartLocal(1,L19,"i","I",null);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(574,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(573,L21);
                code.visitLabel(L9);
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_sessionIdManager","Lorg/mortbay/jetty/SessionIdManager;"));
                code.visitStmt1R(MONITOR_ENTER,2);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,3,5,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_sessionIdManager","Lorg/mortbay/jetty/SessionIdManager;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3,6},new Method("Lorg/mortbay/jetty/SessionIdManager;","addSession",new String[]{ "Ljavax/servlet/http/HttpSession;"},"V"));
                code.visitLabel(L10);
                code.visitStmt1R(MONITOR_ENTER,5);
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","addSession",new String[]{ "Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;"},"V"));
                code.visitLabel(L11);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","getSessions",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitFieldStmt(IGET,4,5,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_maxSessions","I"));
                code.visitJumpStmt(IF_LE,3,4,L13);
                code.visitLabel(L12);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","getSessions",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitFieldStmt(IPUT,3,5,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_maxSessions","I"));
                code.visitLabel(L13);
                code.visitStmt1R(MONITOR_EXIT,5);
                code.visitLabel(L3);
                code.visitStmt1R(MONITOR_EXIT,2);
                code.visitLabel(L5);
                code.visitJumpStmt(IF_NEZ,7,-1,L16);
                code.visitLabel(L14);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","didActivate",new String[]{ },"V"));
                code.visitLabel(L15);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L4);
                code.visitStmt1R(MOVE_EXCEPTION,3);
                code.visitLabel(L6);
                code.visitStmt1R(MONITOR_EXIT,5);
                code.visitLabel(L7);
                code.visitStmt1R(THROW,3);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,3);
                code.visitStmt1R(MONITOR_EXIT,2);
                code.visitLabel(L8);
                code.visitStmt1R(THROW,3);
                code.visitLabel(L16);
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_sessionListeners","Ljava/lang/Object;"));
                code.visitJumpStmt(IF_EQZ,2,-1,L15);
                code.visitLabel(L17);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljavax/servlet/http/HttpSessionEvent;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,6},new Method("Ljavax/servlet/http/HttpSessionEvent;","<init>",new String[]{ "Ljavax/servlet/http/HttpSession;"},"V"));
                code.visitLabel(L18);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L19);
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_sessionListeners","Ljava/lang/Object;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2},new Method("Lorg/mortbay/util/LazyList;","size",new String[]{ "Ljava/lang/Object;"},"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_GE,1,2,L15);
                code.visitLabel(L20);
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_sessionListeners","Ljava/lang/Object;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2,1},new Method("Lorg/mortbay/util/LazyList;","get",new String[]{ "Ljava/lang/Object;","I"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitTypeStmt(CHECK_CAST,2,-1,"Ljavax/servlet/http/HttpSessionListener;");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2,0},new Method("Ljavax/servlet/http/HttpSessionListener;","sessionCreated",new String[]{ "Ljavax/servlet/http/HttpSessionEvent;"},"V"));
                code.visitLabel(L21);
                code.visitStmt2R1N(ADD_INT_LIT8,1,1,1);
                code.visitJumpStmt(GOTO,-1,-1,L19);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m007_clearEventListeners(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","clearEventListeners",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(137,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(138,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(139,L3);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_sessionAttributeListeners","Ljava/lang/Object;"));
                code.visitLabel(L2);
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_sessionListeners","Ljava/lang/Object;"));
                code.visitLabel(L3);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m008_complete(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","complete",new String[]{ "Ljavax/servlet/http/HttpSession;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"session");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(144,L0);
                DexLabel L1=new DexLabel();
                ddv.visitEndLocal(2,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(145,L2);
                ddv.visitStartLocal(0,L2,"s","Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(146,L3);
                code.visitLabel(L0);
                code.visitTypeStmt(CHECK_CAST,2,-1,"Lorg/mortbay/jetty/servlet/AbstractSessionManager$SessionIf;");
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2},new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager$SessionIf;","getSession",new String[]{ },"Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","complete",new String[]{ },"V"));
                code.visitLabel(L3);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m009_doStart(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","doStart",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/Exception;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(8);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L5=new DexLabel();
                ddv.visitPrologue(L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(151,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(152,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(154,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(156,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(157,L10);
                ddv.visitStartLocal(0,L10,"server","Lorg/mortbay/jetty/Server;",null);
                ddv.visitLineNumber(159,L0);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(160,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(162,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(163,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(165,L14);
                ddv.visitLineNumber(167,L1);
                ddv.visitEndLocal(0,L1);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(168,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(171,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(172,L17);
                ddv.visitStartLocal(2,L17,"tmp","Ljava/lang/String;",null);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(173,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(175,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(176,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(178,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(179,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(183,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(185,L24);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(187,L25);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(188,L26);
                ddv.visitStartLocal(1,L26,"str","Ljava/lang/String;",null);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(189,L27);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(193,L28);
                ddv.visitEndLocal(1,L28);
                DexLabel L29=new DexLabel();
                ddv.visitLineNumber(196,L29);
                DexLabel L30=new DexLabel();
                ddv.visitLineNumber(197,L30);
                DexLabel L31=new DexLabel();
                ddv.visitLineNumber(201,L31);
                DexLabel L32=new DexLabel();
                ddv.visitLineNumber(204,L32);
                DexLabel L33=new DexLabel();
                ddv.visitLineNumber(205,L33);
                DexLabel L34=new DexLabel();
                ddv.visitLineNumber(208,L34);
                DexLabel L35=new DexLabel();
                ddv.visitLineNumber(209,L35);
                ddv.visitLineNumber(165,L2);
                ddv.visitEndLocal(2,L2);
                ddv.visitRestartLocal(0,L2);
                DexLabel L36=new DexLabel();
                ddv.visitEndLocal(0,L36);
                ddv.visitRestartLocal(2,L36);
                DexLabel L37=new DexLabel();
                ddv.visitLineNumber(178,L37);
                DexLabel L38=new DexLabel();
                ddv.visitLineNumber(179,L38);
                code.visitLabel(L5);
                code.visitConstStmt(CONST_4,5, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitConstStmt(CONST_STRING,6,"none");
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/jetty/handler/ContextHandler;","getCurrentContext",new String[]{ },"Lorg/mortbay/jetty/handler/ContextHandler$SContext;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitFieldStmt(IPUT_OBJECT,3,7,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_context","Lorg/mortbay/jetty/handler/ContextHandler$SContext;"));
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Ljava/lang/Thread;","currentThread",new String[]{ },"Ljava/lang/Thread;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/lang/Thread;","getContextClassLoader",new String[]{ },"Ljava/lang/ClassLoader;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitFieldStmt(IPUT_OBJECT,3,7,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_loader","Ljava/lang/ClassLoader;"));
                code.visitLabel(L8);
                code.visitFieldStmt(IGET_OBJECT,3,7,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_sessionIdManager","Lorg/mortbay/jetty/SessionIdManager;"));
                code.visitJumpStmt(IF_NEZ,3,-1,L1);
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","getSessionHandler",new String[]{ },"Lorg/mortbay/jetty/servlet/SessionHandler;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/jetty/servlet/SessionHandler;","getServer",new String[]{ },"Lorg/mortbay/jetty/Server;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L10);
                code.visitStmt1R(MONITOR_ENTER,0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/Server;","getSessionIdManager",new String[]{ },"Lorg/mortbay/jetty/SessionIdManager;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitFieldStmt(IPUT_OBJECT,3,7,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_sessionIdManager","Lorg/mortbay/jetty/SessionIdManager;"));
                code.visitLabel(L11);
                code.visitFieldStmt(IGET_OBJECT,3,7,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_sessionIdManager","Lorg/mortbay/jetty/SessionIdManager;"));
                code.visitJumpStmt(IF_NEZ,3,-1,L14);
                code.visitLabel(L12);
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Lorg/mortbay/jetty/servlet/HashSessionIdManager;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3},new Method("Lorg/mortbay/jetty/servlet/HashSessionIdManager;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,3,7,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_sessionIdManager","Lorg/mortbay/jetty/SessionIdManager;"));
                code.visitLabel(L13);
                code.visitFieldStmt(IGET_OBJECT,3,7,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_sessionIdManager","Lorg/mortbay/jetty/SessionIdManager;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,3},new Method("Lorg/mortbay/jetty/Server;","setSessionIdManager",new String[]{ "Lorg/mortbay/jetty/SessionIdManager;"},"V"));
                code.visitLabel(L14);
                code.visitStmt1R(MONITOR_EXIT,0);
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,3,7,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_sessionIdManager","Lorg/mortbay/jetty/SessionIdManager;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3},new Method("Lorg/mortbay/jetty/SessionIdManager;","isStarted",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_NEZ,3,-1,L16);
                code.visitLabel(L15);
                code.visitFieldStmt(IGET_OBJECT,3,7,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_sessionIdManager","Lorg/mortbay/jetty/SessionIdManager;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3},new Method("Lorg/mortbay/jetty/SessionIdManager;","start",new String[]{ },"V"));
                code.visitLabel(L16);
                code.visitFieldStmt(IGET_OBJECT,3,7,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_context","Lorg/mortbay/jetty/handler/ContextHandler$SContext;"));
                code.visitConstStmt(CONST_STRING,4,"org.mortbay.jetty.servlet.SessionCookie");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Lorg/mortbay/jetty/handler/ContextHandler$SContext;","getInitParameter",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L17);
                code.visitJumpStmt(IF_EQZ,2,-1,L19);
                code.visitLabel(L18);
                code.visitFieldStmt(IPUT_OBJECT,2,7,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_sessionCookie","Ljava/lang/String;"));
                code.visitLabel(L19);
                code.visitFieldStmt(IGET_OBJECT,3,7,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_context","Lorg/mortbay/jetty/handler/ContextHandler$SContext;"));
                code.visitConstStmt(CONST_STRING,4,"org.mortbay.jetty.servlet.SessionURL");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Lorg/mortbay/jetty/handler/ContextHandler$SContext;","getInitParameter",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L20);
                code.visitJumpStmt(IF_EQZ,2,-1,L23);
                code.visitLabel(L21);
                DexLabel L39=new DexLabel();
                code.visitJumpStmt(IF_EQZ,2,-1,L39);
                code.visitConstStmt(CONST_STRING,3,"none");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,2},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_EQZ,3,-1,L36);
                code.visitLabel(L39);
                code.visitStmt2R(MOVE_OBJECT,3,5);
                DexLabel L40=new DexLabel();
                code.visitLabel(L40);
                code.visitFieldStmt(IPUT_OBJECT,3,7,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_sessionURL","Ljava/lang/String;"));
                code.visitLabel(L22);
                DexLabel L41=new DexLabel();
                code.visitJumpStmt(IF_EQZ,2,-1,L41);
                code.visitConstStmt(CONST_STRING,3,"none");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,2},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_EQZ,3,-1,L38);
                code.visitLabel(L41);
                code.visitStmt2R(MOVE_OBJECT,3,5);
                DexLabel L42=new DexLabel();
                code.visitLabel(L42);
                code.visitFieldStmt(IPUT_OBJECT,3,7,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_sessionURLPrefix","Ljava/lang/String;"));
                code.visitLabel(L23);
                code.visitFieldStmt(IGET,3,7,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_maxCookieAge","I"));
                code.visitConstStmt(CONST_4,4, Integer.valueOf(-1)); // int: 0xffffffff  float:NaN
                code.visitJumpStmt(IF_NE,3,4,L28);
                code.visitLabel(L24);
                code.visitFieldStmt(IGET_OBJECT,3,7,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_context","Lorg/mortbay/jetty/handler/ContextHandler$SContext;"));
                code.visitJumpStmt(IF_EQZ,3,-1,L28);
                code.visitLabel(L25);
                code.visitFieldStmt(IGET_OBJECT,3,7,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_context","Lorg/mortbay/jetty/handler/ContextHandler$SContext;"));
                code.visitConstStmt(CONST_STRING,4,"org.mortbay.jetty.servlet.MaxAge");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Lorg/mortbay/jetty/handler/ContextHandler$SContext;","getInitParameter",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L26);
                code.visitJumpStmt(IF_EQZ,1,-1,L28);
                code.visitLabel(L27);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/lang/String;","trim",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3},new Method("Ljava/lang/Integer;","parseInt",new String[]{ "Ljava/lang/String;"},"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitFieldStmt(IPUT,3,7,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_maxCookieAge","I"));
                code.visitLabel(L28);
                code.visitFieldStmt(IGET_OBJECT,3,7,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_sessionDomain","Ljava/lang/String;"));
                code.visitJumpStmt(IF_NEZ,3,-1,L31);
                code.visitLabel(L29);
                code.visitFieldStmt(IGET_OBJECT,3,7,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_context","Lorg/mortbay/jetty/handler/ContextHandler$SContext;"));
                code.visitJumpStmt(IF_EQZ,3,-1,L31);
                code.visitLabel(L30);
                code.visitFieldStmt(IGET_OBJECT,3,7,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_context","Lorg/mortbay/jetty/handler/ContextHandler$SContext;"));
                code.visitConstStmt(CONST_STRING,4,"org.mortbay.jetty.servlet.SessionDomain");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Lorg/mortbay/jetty/handler/ContextHandler$SContext;","getInitParameter",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitFieldStmt(IPUT_OBJECT,3,7,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_sessionDomain","Ljava/lang/String;"));
                code.visitLabel(L31);
                code.visitFieldStmt(IGET_OBJECT,3,7,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_sessionPath","Ljava/lang/String;"));
                code.visitJumpStmt(IF_NEZ,3,-1,L34);
                code.visitLabel(L32);
                code.visitFieldStmt(IGET_OBJECT,3,7,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_context","Lorg/mortbay/jetty/handler/ContextHandler$SContext;"));
                code.visitJumpStmt(IF_EQZ,3,-1,L34);
                code.visitLabel(L33);
                code.visitFieldStmt(IGET_OBJECT,3,7,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_context","Lorg/mortbay/jetty/handler/ContextHandler$SContext;"));
                code.visitConstStmt(CONST_STRING,4,"org.mortbay.jetty.servlet.SessionPath");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Lorg/mortbay/jetty/handler/ContextHandler$SContext;","getInitParameter",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitFieldStmt(IPUT_OBJECT,3,7,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_sessionPath","Ljava/lang/String;"));
                code.visitLabel(L34);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 7},new Method("Lorg/mortbay/component/AbstractLifeCycle;","doStart",new String[]{ },"V"));
                code.visitLabel(L35);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,3);
                code.visitLabel(L3);
                code.visitStmt1R(MONITOR_EXIT,0);
                code.visitLabel(L4);
                code.visitStmt1R(THROW,3);
                code.visitLabel(L36);
                code.visitStmt2R(MOVE_OBJECT,3,2);
                code.visitLabel(L37);
                code.visitJumpStmt(GOTO,-1,-1,L40);
                code.visitLabel(L38);
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,4,";");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitFieldStmt(IGET_OBJECT,4,7,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_sessionURL","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitConstStmt(CONST_STRING,4,"=");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitJumpStmt(GOTO,-1,-1,L42);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m010_doStop(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","doStop",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/Exception;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(214,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(216,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(218,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(219,L3);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 1},new Method("Lorg/mortbay/component/AbstractLifeCycle;","doStop",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","invalidateSessions",new String[]{ },"V"));
                code.visitLabel(L2);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_loader","Ljava/lang/ClassLoader;"));
                code.visitLabel(L3);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m011_getClusterId(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","getClusterId",new String[]{ "Ljavax/servlet/http/HttpSession;"},"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"session");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(396,L0);
                DexLabel L1=new DexLabel();
                ddv.visitEndLocal(3,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(397,L2);
                ddv.visitStartLocal(0,L2,"s","Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;",null);
                code.visitLabel(L0);
                code.visitTypeStmt(CHECK_CAST,3,-1,"Lorg/mortbay/jetty/servlet/AbstractSessionManager$SessionIf;");
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3},new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager$SessionIf;","getSession",new String[]{ },"Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","getClusterId",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitStmt1R(RETURN_OBJECT,1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m012_getHttpOnly(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","getHttpOnly",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(227,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_BOOLEAN,0,1,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_httpOnly","Z"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m013_getHttpSession(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","getHttpSession",new String[]{ "Ljava/lang/String;"},"Ljavax/servlet/http/HttpSession;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"nodeId");
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(233,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(235,L4);
                ddv.visitStartLocal(0,L4,"cluster_id","Ljava/lang/String;",null);
                ddv.visitLineNumber(237,L0);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(239,L5);
                ddv.visitStartLocal(1,L5,"session","Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(240,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(241,L7);
                ddv.visitLineNumber(242,L2);
                ddv.visitEndLocal(1,L2);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","getIdManager",new String[]{ },"Lorg/mortbay/jetty/SessionIdManager;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2,4},new Method("Lorg/mortbay/jetty/SessionIdManager;","getClusterId",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L4);
                code.visitStmt1R(MONITOR_ENTER,3);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,0},new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","getSession",new String[]{ "Ljava/lang/String;"},"Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L5);
                code.visitJumpStmt(IF_EQZ,1,-1,L7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","getNodeId",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,4},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_NEZ,2,-1,L7);
                code.visitLabel(L6);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","setIdChanged",new String[]{ "Z"},"V"));
                code.visitLabel(L7);
                code.visitStmt1R(MONITOR_EXIT,3);
                code.visitStmt1R(RETURN_OBJECT,1);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,2);
                code.visitStmt1R(MONITOR_EXIT,3);
                code.visitLabel(L1);
                code.visitStmt1R(THROW,2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m014_getIdManager(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","getIdManager",new String[]{ },"Lorg/mortbay/jetty/SessionIdManager;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(252,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_sessionIdManager","Lorg/mortbay/jetty/SessionIdManager;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m015_getMaxCookieAge(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","getMaxCookieAge",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(258,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,1,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_maxCookieAge","I"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m016_getMaxInactiveInterval(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","getMaxInactiveInterval",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(267,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,1,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_dftMaxIdleSecs","I"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m017_getMaxSessions(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","getMaxSessions",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(273,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,1,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_maxSessions","I"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m018_getMetaManager(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","getMetaManager",new String[]{ },"Lorg/mortbay/jetty/SessionIdManager;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(282,L0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","getIdManager",new String[]{ },"Lorg/mortbay/jetty/SessionIdManager;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m019_getMinSessions(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","getMinSessions",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(288,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,1,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_minSessions","I"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m020_getNodeId(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","getNodeId",new String[]{ "Ljavax/servlet/http/HttpSession;"},"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"session");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(403,L0);
                DexLabel L1=new DexLabel();
                ddv.visitEndLocal(3,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(404,L2);
                ddv.visitStartLocal(0,L2,"s","Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;",null);
                code.visitLabel(L0);
                code.visitTypeStmt(CHECK_CAST,3,-1,"Lorg/mortbay/jetty/servlet/AbstractSessionManager$SessionIf;");
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3},new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager$SessionIf;","getSession",new String[]{ },"Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","getNodeId",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitStmt1R(RETURN_OBJECT,1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m021_getRefreshCookieAge(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","getRefreshCookieAge",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(294,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,1,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_refreshCookieAge","I"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m022_getSecureCookies(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","getSecureCookies",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(304,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_BOOLEAN,0,1,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_secureCookies","Z"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m023_getSession(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","getSession",new String[]{ "Ljava/lang/String;"},"Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m024_getSessionCookie(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","getSessionCookie",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(310,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_sessionCookie","Ljava/lang/String;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m025_getSessionCookie(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","getSessionCookie",new String[]{ "Ljavax/servlet/http/HttpSession;","Ljava/lang/String;","Z"},"Ljavax/servlet/http/Cookie;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(8);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"session");
                ddv.visitParameterName(1,"contextPath");
                ddv.visitParameterName(2,"requestIsSecure");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(316,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(318,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(319,L2);
                ddv.visitStartLocal(1,L2,"id","Ljava/lang/String;",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(321,L3);
                ddv.visitStartLocal(0,L3,"cookie","Ljavax/servlet/http/Cookie;",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(322,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(323,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(326,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(327,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(328,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(329,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(333,L10);
                ddv.visitEndLocal(1,L10);
                ddv.visitEndLocal(0,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(319,L11);
                ddv.visitRestartLocal(1,L11);
                DexLabel L12=new DexLabel();
                ddv.visitRestartLocal(0,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(321,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(323,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(333,L15);
                ddv.visitEndLocal(1,L15);
                ddv.visitEndLocal(0,L15);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","isUsingCookies",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_EQZ,2,-1,L15);
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","getNodeId",new String[]{ "Ljavax/servlet/http/HttpSession;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","getHttpOnly",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_EQZ,2,-1,L11);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Lorg/mortbay/jetty/HttpOnlyCookie;");
                code.visitFieldStmt(IGET_OBJECT,3,4,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_sessionCookie","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2,3,1},new Method("Lorg/mortbay/jetty/HttpOnlyCookie;","<init>",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"V"));
                code.visitStmt2R(MOVE_OBJECT,0,2);
                code.visitLabel(L3);
                DexLabel L16=new DexLabel();
                code.visitJumpStmt(IF_EQZ,6,-1,L16);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_NEZ,2,-1,L12);
                code.visitLabel(L16);
                code.visitConstStmt(CONST_STRING,2,"/");
                DexLabel L17=new DexLabel();
                code.visitLabel(L17);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,2},new Method("Ljavax/servlet/http/Cookie;","setPath",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","getMaxCookieAge",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,2},new Method("Ljavax/servlet/http/Cookie;","setMaxAge",new String[]{ "I"},"V"));
                code.visitLabel(L5);
                code.visitJumpStmt(IF_EQZ,7,-1,L14);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","getSecureCookies",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_EQZ,2,-1,L14);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                DexLabel L18=new DexLabel();
                code.visitLabel(L18);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,2},new Method("Ljavax/servlet/http/Cookie;","setSecure",new String[]{ "Z"},"V"));
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,2,4,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_sessionDomain","Ljava/lang/String;"));
                code.visitJumpStmt(IF_EQZ,2,-1,L8);
                code.visitLabel(L7);
                code.visitFieldStmt(IGET_OBJECT,2,4,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_sessionDomain","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,2},new Method("Ljavax/servlet/http/Cookie;","setDomain",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L8);
                code.visitFieldStmt(IGET_OBJECT,2,4,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_sessionPath","Ljava/lang/String;"));
                DexLabel L19=new DexLabel();
                code.visitJumpStmt(IF_EQZ,2,-1,L19);
                code.visitLabel(L9);
                code.visitFieldStmt(IGET_OBJECT,2,4,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_sessionPath","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,2},new Method("Ljavax/servlet/http/Cookie;","setPath",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L19);
                code.visitStmt2R(MOVE_OBJECT,2,0);
                code.visitLabel(L10);
                code.visitStmt1R(RETURN_OBJECT,2);
                code.visitLabel(L11);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Ljavax/servlet/http/Cookie;");
                code.visitFieldStmt(IGET_OBJECT,3,4,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_sessionCookie","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2,3,1},new Method("Ljavax/servlet/http/Cookie;","<init>",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"V"));
                code.visitStmt2R(MOVE_OBJECT,0,2);
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitLabel(L12);
                code.visitStmt2R(MOVE_OBJECT,2,6);
                code.visitLabel(L13);
                code.visitJumpStmt(GOTO,-1,-1,L17);
                code.visitLabel(L14);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L18);
                code.visitLabel(L15);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L10);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m026_getSessionDomain(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","getSessionDomain",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(338,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_sessionDomain","Ljava/lang/String;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m027_getSessionHandler(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","getSessionHandler",new String[]{ },"Lorg/mortbay/jetty/servlet/SessionHandler;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(347,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_sessionHandler","Lorg/mortbay/jetty/servlet/SessionHandler;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m028_getSessionMap(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","getSessionMap",new String[]{ },"Ljava/util/Map;"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m029_getSessionPath(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","getSessionPath",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(359,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_sessionPath","Ljava/lang/String;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m030_getSessionURL(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","getSessionURL",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(368,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_sessionURL","Ljava/lang/String;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m031_getSessionURLPrefix(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","getSessionURLPrefix",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(374,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_sessionURLPrefix","Ljava/lang/String;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m032_getSessions(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","getSessions",new String[]{ },"I"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m033_invalidateSessions(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED|ACC_ABSTRACT, new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","invalidateSessions",new String[]{ },"V"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m034_isNodeIdInSessionId(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","isNodeIdInSessionId",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(605,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_BOOLEAN,0,1,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_nodeIdInSessionId","Z"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m035_isUsingCookies(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","isUsingCookies",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(383,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_BOOLEAN,0,1,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_usingCookies","Z"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m036_isValid(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","isValid",new String[]{ "Ljavax/servlet/http/HttpSession;"},"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"session");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(389,L0);
                DexLabel L1=new DexLabel();
                ddv.visitEndLocal(3,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(390,L2);
                ddv.visitStartLocal(0,L2,"s","Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;",null);
                code.visitLabel(L0);
                code.visitTypeStmt(CHECK_CAST,3,-1,"Lorg/mortbay/jetty/servlet/AbstractSessionManager$SessionIf;");
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3},new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager$SessionIf;","getSession",new String[]{ },"Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","isValid",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitStmt1R(RETURN,1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m037_newHttpSession(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","newHttpSession",new String[]{ "Ljavax/servlet/http/HttpServletRequest;"},"Ljavax/servlet/http/HttpSession;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"request");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(413,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(414,L1);
                ddv.visitStartLocal(0,L1,"session","Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(415,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(416,L3);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","newSession",new String[]{ "Ljavax/servlet/http/HttpServletRequest;"},"Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L1);
                code.visitFieldStmt(IGET,1,2,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_dftMaxIdleSecs","I"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","setMaxInactiveInterval",new String[]{ "I"},"V"));
                code.visitLabel(L2);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,0,1},new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","addSession",new String[]{ "Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","Z"},"V"));
                code.visitLabel(L3);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m038_newSession(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED|ACC_ABSTRACT, new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","newSession",new String[]{ "Ljavax/servlet/http/HttpServletRequest;"},"Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m039_removeEventListener(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","removeEventListener",new String[]{ "Ljava/util/EventListener;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"listener");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(422,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(423,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(424,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(425,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(426,L4);
                code.visitLabel(L0);
                code.visitTypeStmt(INSTANCE_OF,0,2,"Ljavax/servlet/http/HttpSessionAttributeListener;");
                code.visitJumpStmt(IF_EQZ,0,-1,L2);
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_sessionAttributeListeners","Ljava/lang/Object;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,2},new Method("Lorg/mortbay/util/LazyList;","remove",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_sessionAttributeListeners","Ljava/lang/Object;"));
                code.visitLabel(L2);
                code.visitTypeStmt(INSTANCE_OF,0,2,"Ljavax/servlet/http/HttpSessionListener;");
                code.visitJumpStmt(IF_EQZ,0,-1,L4);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_sessionListeners","Ljava/lang/Object;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,2},new Method("Lorg/mortbay/util/LazyList;","remove",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_sessionListeners","Ljava/lang/Object;"));
                code.visitLabel(L4);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m040_removeSession(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED|ACC_ABSTRACT, new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","removeSession",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m041_removeSession(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","removeSession",new String[]{ "Ljavax/servlet/http/HttpSession;","Z"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"session");
                ddv.visitParameterName(1,"invalidate");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(625,L0);
                DexLabel L1=new DexLabel();
                ddv.visitEndLocal(2,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(626,L2);
                ddv.visitStartLocal(0,L2,"s","Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(627,L3);
                code.visitLabel(L0);
                code.visitTypeStmt(CHECK_CAST,2,-1,"Lorg/mortbay/jetty/servlet/AbstractSessionManager$SessionIf;");
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2},new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager$SessionIf;","getSession",new String[]{ },"Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,0,3},new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","removeSession",new String[]{ "Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","Z"},"V"));
                code.visitLabel(L3);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m042_removeSession(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","removeSession",new String[]{ "Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","Z"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(10);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                code.visitTryCatch(L1,L3,new DexLabel[]{L4},new String[]{ null});
                DexLabel L5=new DexLabel();
                DexLabel L6=new DexLabel();
                code.visitTryCatch(L5,L6,new DexLabel[]{L2},new String[]{ null});
                DexLabel L7=new DexLabel();
                DexLabel L8=new DexLabel();
                code.visitTryCatch(L7,L8,new DexLabel[]{L4},new String[]{ null});
                DexLabel L9=new DexLabel();
                code.visitTryCatch(L8,L9,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"session");
                ddv.visitParameterName(1,"invalidate");
                DexLabel L10=new DexLabel();
                ddv.visitPrologue(L10);
                ddv.visitLineNumber(638,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(640,L11);
                ddv.visitLineNumber(642,L0);
                ddv.visitStartLocal(3,L0,"removed","Z",null);
                ddv.visitLineNumber(645,L1);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(647,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(648,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(650,L14);
                ddv.visitLineNumber(652,L3);
                ddv.visitLineNumber(655,L5);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(656,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(657,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(659,L17);
                ddv.visitLineNumber(661,L6);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(663,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(664,L19);
                ddv.visitStartLocal(0,L19,"event","Ljavax/servlet/http/HttpSessionEvent;",null);
                DexLabel L20=new DexLabel();
                ddv.visitStartLocal(1,L20,"i","I",null);
                DexLabel L21=new DexLabel();
                ddv.visitEndLocal(1,L21);
                ddv.visitStartLocal(2,L21,"i","I",null);
                DexLabel L22=new DexLabel();
                ddv.visitRestartLocal(1,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(665,L23);
                ddv.visitEndLocal(2,L23);
                DexLabel L24=new DexLabel();
                ddv.visitRestartLocal(2,L24);
                ddv.visitLineNumber(650,L4);
                ddv.visitEndLocal(0,L4);
                ddv.visitEndLocal(1,L4);
                ddv.visitEndLocal(2,L4);
                ddv.visitLineNumber(659,L2);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(667,L25);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(669,L26);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(671,L27);
                code.visitLabel(L10);
                code.visitFieldStmt(IGET_OBJECT,4,7,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_sessionIdManager","Lorg/mortbay/jetty/SessionIdManager;"));
                code.visitStmt1R(MONITOR_ENTER,4);
                code.visitLabel(L11);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L0);
                code.visitStmt1R(MONITOR_ENTER,7);
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","getClusterId",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,5},new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","getSession",new String[]{ "Ljava/lang/String;"},"Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitJumpStmt(IF_EQZ,5,-1,L14);
                code.visitLabel(L12);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L13);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","getClusterId",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,5},new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","removeSession",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L14);
                code.visitStmt1R(MONITOR_EXIT,7);
                code.visitLabel(L3);
                code.visitJumpStmt(IF_EQZ,3,-1,L17);
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,5,7,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_sessionIdManager","Lorg/mortbay/jetty/SessionIdManager;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 5,8},new Method("Lorg/mortbay/jetty/SessionIdManager;","removeSession",new String[]{ "Ljavax/servlet/http/HttpSession;"},"V"));
                code.visitLabel(L15);
                code.visitJumpStmt(IF_EQZ,9,-1,L17);
                code.visitLabel(L16);
                code.visitFieldStmt(IGET_OBJECT,5,7,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_sessionIdManager","Lorg/mortbay/jetty/SessionIdManager;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","getClusterId",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 5,6},new Method("Lorg/mortbay/jetty/SessionIdManager;","invalidateAll",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L17);
                code.visitStmt1R(MONITOR_EXIT,4);
                code.visitLabel(L6);
                code.visitJumpStmt(IF_EQZ,9,-1,L25);
                code.visitFieldStmt(IGET_OBJECT,4,7,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_sessionListeners","Ljava/lang/Object;"));
                code.visitJumpStmt(IF_EQZ,4,-1,L25);
                code.visitLabel(L18);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljavax/servlet/http/HttpSessionEvent;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,8},new Method("Ljavax/servlet/http/HttpSessionEvent;","<init>",new String[]{ "Ljavax/servlet/http/HttpSession;"},"V"));
                code.visitLabel(L19);
                code.visitFieldStmt(IGET_OBJECT,4,7,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_sessionListeners","Ljava/lang/Object;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 4},new Method("Lorg/mortbay/util/LazyList;","size",new String[]{ "Ljava/lang/Object;"},"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitLabel(L20);
                code.visitStmt2R(MOVE,2,1);
                code.visitLabel(L21);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt3R(SUB_INT,1,2,4);
                code.visitLabel(L22);
                code.visitJumpStmt(IF_LEZ,2,-1,L25);
                code.visitLabel(L23);
                code.visitFieldStmt(IGET_OBJECT,4,7,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_sessionListeners","Ljava/lang/Object;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 4,1},new Method("Lorg/mortbay/util/LazyList;","get",new String[]{ "Ljava/lang/Object;","I"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitTypeStmt(CHECK_CAST,4,-1,"Ljavax/servlet/http/HttpSessionListener;");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 4,0},new Method("Ljavax/servlet/http/HttpSessionListener;","sessionDestroyed",new String[]{ "Ljavax/servlet/http/HttpSessionEvent;"},"V"));
                code.visitStmt2R(MOVE,2,1);
                code.visitLabel(L24);
                code.visitJumpStmt(GOTO,-1,-1,L21);
                code.visitLabel(L4);
                code.visitStmt1R(MOVE_EXCEPTION,5);
                code.visitLabel(L7);
                code.visitStmt1R(MONITOR_EXIT,7);
                code.visitLabel(L8);
                code.visitStmt1R(THROW,5);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,5);
                code.visitStmt1R(MONITOR_EXIT,4);
                code.visitLabel(L9);
                code.visitStmt1R(THROW,5);
                code.visitLabel(L25);
                code.visitJumpStmt(IF_NEZ,9,-1,L27);
                code.visitLabel(L26);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","willPassivate",new String[]{ },"V"));
                code.visitLabel(L27);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m043_resetStats(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","resetStats",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(431,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(432,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(433,L2);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","getSessions",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitFieldStmt(IPUT,0,1,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_minSessions","I"));
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","getSessions",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitFieldStmt(IPUT,0,1,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_maxSessions","I"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m044_setHttpOnly(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","setHttpOnly",new String[]{ "Z"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"httpOnly");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(442,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(443,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_BOOLEAN,1,0,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_httpOnly","Z"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m045_setIdManager(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","setIdManager",new String[]{ "Lorg/mortbay/jetty/SessionIdManager;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"metaManager");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(452,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(453,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_sessionIdManager","Lorg/mortbay/jetty/SessionIdManager;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m046_setMaxCookieAge(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","setMaxCookieAge",new String[]{ "I"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"maxCookieAgeInSeconds");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(458,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(460,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(461,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(463,L3);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT,2,1,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_maxCookieAge","I"));
                code.visitLabel(L1);
                code.visitFieldStmt(IGET,0,1,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_maxCookieAge","I"));
                code.visitJumpStmt(IF_LEZ,0,-1,L3);
                code.visitFieldStmt(IGET,0,1,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_refreshCookieAge","I"));
                code.visitJumpStmt(IF_NEZ,0,-1,L3);
                code.visitLabel(L2);
                code.visitFieldStmt(IGET,0,1,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_maxCookieAge","I"));
                code.visitStmt2R1N(DIV_INT_LIT8,0,0,3);
                code.visitFieldStmt(IPUT,0,1,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_refreshCookieAge","I"));
                code.visitLabel(L3);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m047_setMaxInactiveInterval(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","setMaxInactiveInterval",new String[]{ "I"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"seconds");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(471,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(472,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT,1,0,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_dftMaxIdleSecs","I"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m048_setMetaManager(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","setMetaManager",new String[]{ "Lorg/mortbay/jetty/SessionIdManager;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"metaManager");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(480,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(481,L1);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","setIdManager",new String[]{ "Lorg/mortbay/jetty/SessionIdManager;"},"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m049_setNodeIdInSessionId(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","setNodeIdInSessionId",new String[]{ "Z"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"nodeIdInSessionId");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(614,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(615,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_BOOLEAN,1,0,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_nodeIdInSessionId","Z"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m050_setRefreshCookieAge(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","setRefreshCookieAge",new String[]{ "I"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"ageInSeconds");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(486,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(487,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT,1,0,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_refreshCookieAge","I"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m051_setSecureCookies(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","setSecureCookies",new String[]{ "Z"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"secureCookies");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(497,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(498,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_BOOLEAN,1,0,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_secureCookies","Z"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m052_setSessionCookie(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","setSessionCookie",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"cookieName");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(502,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(503,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_sessionCookie","Ljava/lang/String;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m053_setSessionDomain(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","setSessionDomain",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"domain");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(507,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(508,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_sessionDomain","Ljava/lang/String;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m054_setSessionHandler(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","setSessionHandler",new String[]{ "Lorg/mortbay/jetty/servlet/SessionHandler;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"sessionHandler");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(517,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(518,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_sessionHandler","Lorg/mortbay/jetty/servlet/SessionHandler;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m055_setSessionPath(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","setSessionPath",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"path");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(523,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(524,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_sessionPath","Ljava/lang/String;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m056_setSessionURL(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","setSessionURL",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"param");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(532,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(533,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(534,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(532,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(533,L5);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitConstStmt(CONST_STRING,2,"none");
                code.visitLabel(L1);
                DexLabel L6=new DexLabel();
                code.visitJumpStmt(IF_EQZ,4,-1,L6);
                code.visitConstStmt(CONST_STRING,0,"none");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,4},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                DexLabel L7=new DexLabel();
                code.visitJumpStmt(IF_EQZ,0,-1,L7);
                code.visitLabel(L6);
                code.visitStmt2R(MOVE_OBJECT,0,1);
                DexLabel L8=new DexLabel();
                code.visitLabel(L8);
                code.visitFieldStmt(IPUT_OBJECT,0,3,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_sessionURL","Ljava/lang/String;"));
                code.visitLabel(L2);
                DexLabel L9=new DexLabel();
                code.visitJumpStmt(IF_EQZ,4,-1,L9);
                code.visitConstStmt(CONST_STRING,0,"none");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,4},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L5);
                code.visitLabel(L9);
                code.visitStmt2R(MOVE_OBJECT,0,1);
                DexLabel L10=new DexLabel();
                code.visitLabel(L10);
                code.visitFieldStmt(IPUT_OBJECT,0,3,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_sessionURLPrefix","Ljava/lang/String;"));
                code.visitLabel(L3);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L7);
                code.visitStmt2R(MOVE_OBJECT,0,4);
                code.visitLabel(L4);
                code.visitJumpStmt(GOTO,-1,-1,L8);
                code.visitLabel(L5);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,1,";");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_sessionURL","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitConstStmt(CONST_STRING,1,"=");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitJumpStmt(GOTO,-1,-1,L10);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m057_setUsingCookies(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","setUsingCookies",new String[]{ "Z"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"usingCookies");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(542,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(543,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_BOOLEAN,1,0,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_usingCookies","Z"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
