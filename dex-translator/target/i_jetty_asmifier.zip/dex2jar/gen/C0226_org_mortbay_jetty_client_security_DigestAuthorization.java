package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0226_org_mortbay_jetty_client_security_DigestAuthorization {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/jetty/client/security/DigestAuthorization;","Ljava/lang/Object;",new String[]{ "Lorg/mortbay/jetty/client/security/Authorization;"});
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("DigestAuthorization.java");
        f000_NC(cv);
        f001_details(cv);
        f002_securityRealm(cv);
        m000__init_(cv);
        m001_encode(cv);
        m002_newCnonce(cv);
        m003_newResponse(cv);
        m004_setCredentials(cv);
    }
    public static void f000_NC(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/client/security/DigestAuthorization;","NC","Ljava/lang/String;"), "00000001");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001_details(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/jetty/client/security/DigestAuthorization;","details","Ljava/util/Map;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002_securityRealm(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/jetty/client/security/DigestAuthorization;","securityRealm","Lorg/mortbay/jetty/client/security/Realm;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/client/security/DigestAuthorization;","<init>",new String[]{ "Lorg/mortbay/jetty/client/security/Realm;","Ljava/util/Map;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"realm");
                ddv.visitParameterName(1,"details");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(34,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(35,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(36,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(37,L3);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/Object;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/client/security/DigestAuthorization;","securityRealm","Lorg/mortbay/jetty/client/security/Realm;"));
                code.visitLabel(L2);
                code.visitFieldStmt(IPUT_OBJECT,2,0,new Field("Lorg/mortbay/jetty/client/security/DigestAuthorization;","details","Ljava/util/Map;"));
                code.visitLabel(L3);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001_encode(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PRIVATE|ACC_STATIC, new Method("Lorg/mortbay/jetty/client/security/DigestAuthorization;","encode",new String[]{ "[B"},"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"data");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(130,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(131,L1);
                ddv.visitStartLocal(0,L1,"buffer","Ljava/lang/StringBuilder;",null);
                DexLabel L2=new DexLabel();
                ddv.visitStartLocal(1,L2,"i","I",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(133,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(134,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(131,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(136,L6);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L2);
                code.visitStmt2R(ARRAY_LENGTH,2,3);
                code.visitJumpStmt(IF_GE,1,2,L6);
                code.visitLabel(L3);
                code.visitStmt3R(AGET_BYTE,2,3,1);
                code.visitStmt2R1N(AND_INT_LIT16,2,2,240);
                code.visitStmt2R1N(USHR_INT_LIT8,2,2,4);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2},new Method("Ljava/lang/Integer;","toHexString",new String[]{ "I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitLabel(L4);
                code.visitStmt3R(AGET_BYTE,2,3,1);
                code.visitStmt2R1N(AND_INT_LIT8,2,2,15);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2},new Method("Ljava/lang/Integer;","toHexString",new String[]{ "I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitLabel(L5);
                code.visitStmt2R1N(ADD_INT_LIT8,1,1,1);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitStmt1R(RETURN_OBJECT,2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_newCnonce(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/client/security/DigestAuthorization;","newCnonce",new String[]{ "Lorg/mortbay/jetty/client/HttpExchange;","Lorg/mortbay/jetty/client/security/Realm;","Ljava/util/Map;"},"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(9);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/lang/Exception;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"exchange");
                ddv.visitParameterName(1,"securityRealm");
                ddv.visitParameterName(2,"details");
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(117,L0);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(118,L3);
                ddv.visitStartLocal(2,L3,"md","Ljava/security/MessageDigest;",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(119,L4);
                ddv.visitStartLocal(0,L4,"b","[B",null);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(124,L5);
                ddv.visitEndLocal(2,L5);
                ddv.visitEndLocal(0,L5);
                ddv.visitLineNumber(121,L2);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(123,L6);
                ddv.visitStartLocal(1,L6,"e","Ljava/lang/Exception;",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(124,L7);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_STRING,3,"MD5");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3},new Method("Ljava/security/MessageDigest;","getInstance",new String[]{ "Ljava/lang/String;"},"Ljava/security/MessageDigest;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Ljava/lang/System;","currentTimeMillis",new String[]{ },"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,3);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3,4},new Method("Ljava/lang/String;","valueOf",new String[]{ "J"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitFieldStmt(SGET_OBJECT,4,-1,new Field("Lorg/mortbay/util/StringUtil;","__ISO_8859_1","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/String;","getBytes",new String[]{ "Ljava/lang/String;"},"[B"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/security/MessageDigest;","digest",new String[]{ "[B"},"[B"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/jetty/client/security/DigestAuthorization;","encode",new String[]{ "[B"},"Ljava/lang/String;"));
                code.visitLabel(L1);
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitLabel(L5);
                code.visitStmt1R(RETURN_OBJECT,3);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,3);
                code.visitStmt2R(MOVE_OBJECT,1,3);
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/lang/Exception;","printStackTrace",new String[]{ },"V"));
                code.visitLabel(L7);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_newResponse(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/client/security/DigestAuthorization;","newResponse",new String[]{ "Ljava/lang/String;","Lorg/mortbay/jetty/client/HttpExchange;","Lorg/mortbay/jetty/client/security/Realm;","Ljava/util/Map;"},"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(12);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/lang/Exception;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"cnonce");
                ddv.visitParameterName(1,"exchange");
                ddv.visitParameterName(2,"securityRealm");
                ddv.visitParameterName(3,"details");
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(74,L0);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(77,L3);
                ddv.visitStartLocal(4,L3,"md","Ljava/security/MessageDigest;",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(78,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(79,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(80,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(81,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(82,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(84,L9);
                ddv.visitStartLocal(2,L9,"ha1","[B",null);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(85,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(86,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(87,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(88,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(90,L14);
                ddv.visitStartLocal(3,L14,"ha2","[B",null);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(91,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(92,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(93,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(94,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(95,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(96,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(97,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(98,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(99,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(100,L24);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(101,L25);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(104,L26);
                ddv.visitStartLocal(0,L26,"digest","[B",null);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(109,L27);
                ddv.visitEndLocal(4,L27);
                ddv.visitEndLocal(2,L27);
                ddv.visitEndLocal(3,L27);
                ddv.visitEndLocal(0,L27);
                ddv.visitLineNumber(106,L2);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(108,L28);
                ddv.visitStartLocal(1,L28,"e","Ljava/lang/Exception;",null);
                DexLabel L29=new DexLabel();
                ddv.visitLineNumber(109,L29);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_STRING,5,"MD5");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 5},new Method("Ljava/security/MessageDigest;","getInstance",new String[]{ "Ljava/lang/String;"},"Ljava/security/MessageDigest;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 10},new Method("Lorg/mortbay/jetty/client/security/Realm;","getPrincipal",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitFieldStmt(SGET_OBJECT,6,-1,new Field("Lorg/mortbay/util/StringUtil;","__ISO_8859_1","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Ljava/lang/String;","getBytes",new String[]{ "Ljava/lang/String;"},"[B"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Ljava/security/MessageDigest;","update",new String[]{ "[B"},"V"));
                code.visitLabel(L4);
                code.visitConstStmt(CONST_16,5, Integer.valueOf(58)); // int: 0x0000003a  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Ljava/security/MessageDigest;","update",new String[]{ "B"},"V"));
                code.visitLabel(L5);
                code.visitConstStmt(CONST_STRING,5,"realm");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 11,5},new Method("Ljava/util/Map;","get",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 5},new Method("Ljava/lang/String;","valueOf",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitFieldStmt(SGET_OBJECT,6,-1,new Field("Lorg/mortbay/util/StringUtil;","__ISO_8859_1","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Ljava/lang/String;","getBytes",new String[]{ "Ljava/lang/String;"},"[B"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Ljava/security/MessageDigest;","update",new String[]{ "[B"},"V"));
                code.visitLabel(L6);
                code.visitConstStmt(CONST_16,5, Integer.valueOf(58)); // int: 0x0000003a  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Ljava/security/MessageDigest;","update",new String[]{ "B"},"V"));
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 10},new Method("Lorg/mortbay/jetty/client/security/Realm;","getCredentials",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitFieldStmt(SGET_OBJECT,6,-1,new Field("Lorg/mortbay/util/StringUtil;","__ISO_8859_1","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Ljava/lang/String;","getBytes",new String[]{ "Ljava/lang/String;"},"[B"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Ljava/security/MessageDigest;","update",new String[]{ "[B"},"V"));
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/security/MessageDigest;","digest",new String[]{ },"[B"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/security/MessageDigest;","reset",new String[]{ },"V"));
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9},new Method("Lorg/mortbay/jetty/client/HttpExchange;","getMethod",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitFieldStmt(SGET_OBJECT,6,-1,new Field("Lorg/mortbay/util/StringUtil;","__ISO_8859_1","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Ljava/lang/String;","getBytes",new String[]{ "Ljava/lang/String;"},"[B"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Ljava/security/MessageDigest;","update",new String[]{ "[B"},"V"));
                code.visitLabel(L11);
                code.visitConstStmt(CONST_16,5, Integer.valueOf(58)); // int: 0x0000003a  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Ljava/security/MessageDigest;","update",new String[]{ "B"},"V"));
                code.visitLabel(L12);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9},new Method("Lorg/mortbay/jetty/client/HttpExchange;","getURI",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitFieldStmt(SGET_OBJECT,6,-1,new Field("Lorg/mortbay/util/StringUtil;","__ISO_8859_1","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Ljava/lang/String;","getBytes",new String[]{ "Ljava/lang/String;"},"[B"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Ljava/security/MessageDigest;","update",new String[]{ "[B"},"V"));
                code.visitLabel(L13);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/security/MessageDigest;","digest",new String[]{ },"[B"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitLabel(L14);
                code.visitConstStmt(CONST_16,5, Integer.valueOf(16)); // int: 0x00000010  float:0.000000
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2,5},new Method("Lorg/mortbay/util/TypeUtil;","toString",new String[]{ "[B","I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitFieldStmt(SGET_OBJECT,6,-1,new Field("Lorg/mortbay/util/StringUtil;","__ISO_8859_1","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Ljava/lang/String;","getBytes",new String[]{ "Ljava/lang/String;"},"[B"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Ljava/security/MessageDigest;","update",new String[]{ "[B"},"V"));
                code.visitLabel(L15);
                code.visitConstStmt(CONST_16,5, Integer.valueOf(58)); // int: 0x0000003a  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Ljava/security/MessageDigest;","update",new String[]{ "B"},"V"));
                code.visitLabel(L16);
                code.visitConstStmt(CONST_STRING,5,"nonce");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 11,5},new Method("Ljava/util/Map;","get",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 5},new Method("Ljava/lang/String;","valueOf",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitFieldStmt(SGET_OBJECT,6,-1,new Field("Lorg/mortbay/util/StringUtil;","__ISO_8859_1","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Ljava/lang/String;","getBytes",new String[]{ "Ljava/lang/String;"},"[B"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Ljava/security/MessageDigest;","update",new String[]{ "[B"},"V"));
                code.visitLabel(L17);
                code.visitConstStmt(CONST_16,5, Integer.valueOf(58)); // int: 0x0000003a  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Ljava/security/MessageDigest;","update",new String[]{ "B"},"V"));
                code.visitLabel(L18);
                code.visitConstStmt(CONST_STRING,5,"00000001");
                code.visitFieldStmt(SGET_OBJECT,6,-1,new Field("Lorg/mortbay/util/StringUtil;","__ISO_8859_1","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Ljava/lang/String;","getBytes",new String[]{ "Ljava/lang/String;"},"[B"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Ljava/security/MessageDigest;","update",new String[]{ "[B"},"V"));
                code.visitLabel(L19);
                code.visitConstStmt(CONST_16,5, Integer.valueOf(58)); // int: 0x0000003a  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Ljava/security/MessageDigest;","update",new String[]{ "B"},"V"));
                code.visitLabel(L20);
                code.visitFieldStmt(SGET_OBJECT,5,-1,new Field("Lorg/mortbay/util/StringUtil;","__ISO_8859_1","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,5},new Method("Ljava/lang/String;","getBytes",new String[]{ "Ljava/lang/String;"},"[B"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Ljava/security/MessageDigest;","update",new String[]{ "[B"},"V"));
                code.visitLabel(L21);
                code.visitConstStmt(CONST_16,5, Integer.valueOf(58)); // int: 0x0000003a  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Ljava/security/MessageDigest;","update",new String[]{ "B"},"V"));
                code.visitLabel(L22);
                code.visitConstStmt(CONST_STRING,5,"qop");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 11,5},new Method("Ljava/util/Map;","get",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 5},new Method("Ljava/lang/String;","valueOf",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitFieldStmt(SGET_OBJECT,6,-1,new Field("Lorg/mortbay/util/StringUtil;","__ISO_8859_1","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Ljava/lang/String;","getBytes",new String[]{ "Ljava/lang/String;"},"[B"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Ljava/security/MessageDigest;","update",new String[]{ "[B"},"V"));
                code.visitLabel(L23);
                code.visitConstStmt(CONST_16,5, Integer.valueOf(58)); // int: 0x0000003a  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Ljava/security/MessageDigest;","update",new String[]{ "B"},"V"));
                code.visitLabel(L24);
                code.visitConstStmt(CONST_16,5, Integer.valueOf(16)); // int: 0x00000010  float:0.000000
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3,5},new Method("Lorg/mortbay/util/TypeUtil;","toString",new String[]{ "[B","I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitFieldStmt(SGET_OBJECT,6,-1,new Field("Lorg/mortbay/util/StringUtil;","__ISO_8859_1","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Ljava/lang/String;","getBytes",new String[]{ "Ljava/lang/String;"},"[B"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Ljava/security/MessageDigest;","update",new String[]{ "[B"},"V"));
                code.visitLabel(L25);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/security/MessageDigest;","digest",new String[]{ },"[B"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L26);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/jetty/client/security/DigestAuthorization;","encode",new String[]{ "[B"},"Ljava/lang/String;"));
                code.visitLabel(L1);
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitLabel(L27);
                code.visitStmt1R(RETURN_OBJECT,5);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,5);
                code.visitStmt2R(MOVE_OBJECT,1,5);
                code.visitLabel(L28);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/lang/Exception;","printStackTrace",new String[]{ },"V"));
                code.visitLabel(L29);
                code.visitConstStmt(CONST_4,5, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L27);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_setCredentials(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/client/security/DigestAuthorization;","setCredentials",new String[]{ "Lorg/mortbay/jetty/client/HttpExchange;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(12);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"exchange");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(43,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(45,L2);
                ddv.visitStartLocal(0,L2,"buffer","Ljava/lang/StringBuilder;",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(47,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(49,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(51,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(53,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(55,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(57,L8);
                ddv.visitStartLocal(1,L8,"cnonce","Ljava/lang/String;",null);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(60,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(63,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(65,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(67,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(69,L13);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_16,6, Integer.valueOf(61)); // int: 0x0000003d  float:0.000000
                code.visitConstStmt(CONST_16,5, Integer.valueOf(34)); // int: 0x00000022  float:0.000000
                code.visitConstStmt(CONST_STRING,9,"nonce");
                code.visitConstStmt(CONST_STRING,8,"algorithm");
                code.visitConstStmt(CONST_STRING,7,", ");
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,3,"Digest");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L2);
                code.visitConstStmt(CONST_STRING,2," ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitConstStmt(CONST_STRING,3,"username");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,6},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "C"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "C"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitFieldStmt(IGET_OBJECT,3,10,new Field("Lorg/mortbay/jetty/client/security/DigestAuthorization;","securityRealm","Lorg/mortbay/jetty/client/security/Realm;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3},new Method("Lorg/mortbay/jetty/client/security/Realm;","getPrincipal",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "C"},"Ljava/lang/StringBuilder;"));
                code.visitLabel(L3);
                code.visitConstStmt(CONST_STRING,2,", ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,7},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitConstStmt(CONST_STRING,3,"realm");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,6},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "C"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "C"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitFieldStmt(IGET_OBJECT,3,10,new Field("Lorg/mortbay/jetty/client/security/DigestAuthorization;","details","Ljava/util/Map;"));
                code.visitConstStmt(CONST_STRING,4,"realm");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3,4},new Method("Ljava/util/Map;","get",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3},new Method("Ljava/lang/String;","valueOf",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "C"},"Ljava/lang/StringBuilder;"));
                code.visitLabel(L4);
                code.visitConstStmt(CONST_STRING,2,", ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,7},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitConstStmt(CONST_STRING,3,"nonce");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,9},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,6},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "C"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "C"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitFieldStmt(IGET_OBJECT,3,10,new Field("Lorg/mortbay/jetty/client/security/DigestAuthorization;","details","Ljava/util/Map;"));
                code.visitConstStmt(CONST_STRING,4,"nonce");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3,9},new Method("Ljava/util/Map;","get",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3},new Method("Ljava/lang/String;","valueOf",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "C"},"Ljava/lang/StringBuilder;"));
                code.visitLabel(L5);
                code.visitConstStmt(CONST_STRING,2,", ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,7},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitConstStmt(CONST_STRING,3,"uri");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,6},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "C"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "C"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11},new Method("Lorg/mortbay/jetty/client/HttpExchange;","getURI",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "C"},"Ljava/lang/StringBuilder;"));
                code.visitLabel(L6);
                code.visitConstStmt(CONST_STRING,2,", ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,7},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitConstStmt(CONST_STRING,3,"algorithm");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,8},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,6},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "C"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitFieldStmt(IGET_OBJECT,3,10,new Field("Lorg/mortbay/jetty/client/security/DigestAuthorization;","details","Ljava/util/Map;"));
                code.visitConstStmt(CONST_STRING,4,"algorithm");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3,8},new Method("Ljava/util/Map;","get",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3},new Method("Ljava/lang/String;","valueOf",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitLabel(L7);
                code.visitFieldStmt(IGET_OBJECT,2,10,new Field("Lorg/mortbay/jetty/client/security/DigestAuthorization;","securityRealm","Lorg/mortbay/jetty/client/security/Realm;"));
                code.visitFieldStmt(IGET_OBJECT,3,10,new Field("Lorg/mortbay/jetty/client/security/DigestAuthorization;","details","Ljava/util/Map;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10,11,2,3},new Method("Lorg/mortbay/jetty/client/security/DigestAuthorization;","newCnonce",new String[]{ "Lorg/mortbay/jetty/client/HttpExchange;","Lorg/mortbay/jetty/client/security/Realm;","Ljava/util/Map;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L8);
                code.visitConstStmt(CONST_STRING,2,", ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,7},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitConstStmt(CONST_STRING,3,"response");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,6},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "C"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "C"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitFieldStmt(IGET_OBJECT,3,10,new Field("Lorg/mortbay/jetty/client/security/DigestAuthorization;","securityRealm","Lorg/mortbay/jetty/client/security/Realm;"));
                code.visitFieldStmt(IGET_OBJECT,4,10,new Field("Lorg/mortbay/jetty/client/security/DigestAuthorization;","details","Ljava/util/Map;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10,1,11,3,4},new Method("Lorg/mortbay/jetty/client/security/DigestAuthorization;","newResponse",new String[]{ "Ljava/lang/String;","Lorg/mortbay/jetty/client/HttpExchange;","Lorg/mortbay/jetty/client/security/Realm;","Ljava/util/Map;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "C"},"Ljava/lang/StringBuilder;"));
                code.visitLabel(L9);
                code.visitConstStmt(CONST_STRING,2,", ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,7},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitConstStmt(CONST_STRING,3,"qop");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,6},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "C"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitFieldStmt(IGET_OBJECT,3,10,new Field("Lorg/mortbay/jetty/client/security/DigestAuthorization;","details","Ljava/util/Map;"));
                code.visitConstStmt(CONST_STRING,4,"qop");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3,4},new Method("Ljava/util/Map;","get",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3},new Method("Ljava/lang/String;","valueOf",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitLabel(L10);
                code.visitConstStmt(CONST_STRING,2,", ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,7},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitConstStmt(CONST_STRING,3,"nc");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,6},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "C"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitConstStmt(CONST_STRING,3,"00000001");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitLabel(L11);
                code.visitConstStmt(CONST_STRING,2,", ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,7},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitConstStmt(CONST_STRING,3,"cnonce");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,6},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "C"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "C"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "C"},"Ljava/lang/StringBuilder;"));
                code.visitLabel(L12);
                code.visitConstStmt(CONST_STRING,2,"Authorization");
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Ljava/lang/String;");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitFieldStmt(SGET_OBJECT,5,-1,new Field("Lorg/mortbay/util/StringUtil;","__ISO_8859_1","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Ljava/lang/String;","getBytes",new String[]{ "Ljava/lang/String;"},"[B"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3,4},new Method("Ljava/lang/String;","<init>",new String[]{ "[B"},"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11,2,3},new Method("Lorg/mortbay/jetty/client/HttpExchange;","setRequestHeader",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"V"));
                code.visitLabel(L13);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
