package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0458_org_mortbay_util_ajax_JSONPojoConvertor_Setter {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/util/ajax/JSONPojoConvertor$Setter;","Ljava/lang/Object;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("JSONPojoConvertor.java");
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/EnclosingClass;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("value", new DexType("Lorg/mortbay/util/ajax/JSONPojoConvertor;"));
                av00.visitEnd();
            }
        }
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/InnerClass;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("accessFlags",  Integer.valueOf(9));
                av00.visit("name", "Setter");
                av00.visitEnd();
            }
        }
        f000__componentType(cv);
        f001__method(cv);
        f002__numberType(cv);
        f003__propertyName(cv);
        f004__type(cv);
        m000__init_(cv);
        m001_getComponentType(cv);
        m002_getMethod(cv);
        m003_getNumberType(cv);
        m004_getPropertyName(cv);
        m005_getType(cv);
        m006_invoke(cv);
        m007_invokeObject(cv);
        m008_isPropertyNumber(cv);
    }
    public static void f000__componentType(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/util/ajax/JSONPojoConvertor$Setter;","_componentType","Ljava/lang/Class;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001__method(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/util/ajax/JSONPojoConvertor$Setter;","_method","Ljava/lang/reflect/Method;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002__numberType(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/util/ajax/JSONPojoConvertor$Setter;","_numberType","Lorg/mortbay/util/ajax/JSONPojoConvertor$NumberType;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003__propertyName(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/util/ajax/JSONPojoConvertor$Setter;","_propertyName","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f004__type(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/util/ajax/JSONPojoConvertor$Setter;","_type","Ljava/lang/Class;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/util/ajax/JSONPojoConvertor$Setter;","<init>",new String[]{ "Ljava/lang/String;","Ljava/lang/reflect/Method;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"propertyName");
                ddv.visitParameterName(1,"method");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(237,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(238,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(239,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(240,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(241,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(242,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(244,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(245,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(247,L8);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2},new Method("Ljava/lang/Object;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitFieldStmt(IPUT_OBJECT,3,2,new Field("Lorg/mortbay/util/ajax/JSONPojoConvertor$Setter;","_propertyName","Ljava/lang/String;"));
                code.visitLabel(L2);
                code.visitFieldStmt(IPUT_OBJECT,4,2,new Field("Lorg/mortbay/util/ajax/JSONPojoConvertor$Setter;","_method","Ljava/lang/reflect/Method;"));
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/lang/reflect/Method;","getParameterTypes",new String[]{ },"[Ljava/lang/Class;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt3R(AGET_OBJECT,0,0,1);
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/util/ajax/JSONPojoConvertor$Setter;","_type","Ljava/lang/Class;"));
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/util/ajax/JSONPojoConvertor;","access$000",new String[]{ },"Ljava/util/Map;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/util/ajax/JSONPojoConvertor$Setter;","_type","Ljava/lang/Class;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1},new Method("Ljava/util/Map;","get",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Lorg/mortbay/util/ajax/JSONPojoConvertor$NumberType;");
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/util/ajax/JSONPojoConvertor$Setter;","_numberType","Lorg/mortbay/util/ajax/JSONPojoConvertor$NumberType;"));
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/util/ajax/JSONPojoConvertor$Setter;","_numberType","Lorg/mortbay/util/ajax/JSONPojoConvertor$NumberType;"));
                code.visitJumpStmt(IF_NEZ,0,-1,L8);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/util/ajax/JSONPojoConvertor$Setter;","_type","Ljava/lang/Class;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/Class;","isArray",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L8);
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/util/ajax/JSONPojoConvertor$Setter;","_type","Ljava/lang/Class;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/Class;","getComponentType",new String[]{ },"Ljava/lang/Class;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/util/ajax/JSONPojoConvertor$Setter;","_componentType","Ljava/lang/Class;"));
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/util/ajax/JSONPojoConvertor;","access$000",new String[]{ },"Ljava/util/Map;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/util/ajax/JSONPojoConvertor$Setter;","_componentType","Ljava/lang/Class;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1},new Method("Ljava/util/Map;","get",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Lorg/mortbay/util/ajax/JSONPojoConvertor$NumberType;");
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/util/ajax/JSONPojoConvertor$Setter;","_numberType","Lorg/mortbay/util/ajax/JSONPojoConvertor$NumberType;"));
                code.visitLabel(L8);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001_getComponentType(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/ajax/JSONPojoConvertor$Setter;","getComponentType",new String[]{ },"Ljava/lang/Class;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(271,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/util/ajax/JSONPojoConvertor$Setter;","_componentType","Ljava/lang/Class;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_getMethod(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/ajax/JSONPojoConvertor$Setter;","getMethod",new String[]{ },"Ljava/lang/reflect/Method;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(256,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/util/ajax/JSONPojoConvertor$Setter;","_method","Ljava/lang/reflect/Method;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_getNumberType(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/ajax/JSONPojoConvertor$Setter;","getNumberType",new String[]{ },"Lorg/mortbay/util/ajax/JSONPojoConvertor$NumberType;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(261,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/util/ajax/JSONPojoConvertor$Setter;","_numberType","Lorg/mortbay/util/ajax/JSONPojoConvertor$NumberType;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_getPropertyName(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/ajax/JSONPojoConvertor$Setter;","getPropertyName",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(251,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/util/ajax/JSONPojoConvertor$Setter;","_propertyName","Ljava/lang/String;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_getType(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/ajax/JSONPojoConvertor$Setter;","getType",new String[]{ },"Ljava/lang/Class;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(266,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/util/ajax/JSONPojoConvertor$Setter;","_type","Ljava/lang/Class;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_invoke(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/ajax/JSONPojoConvertor$Setter;","invoke",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/IllegalArgumentException;"));
                            av01.visit(null, new DexType("Ljava/lang/IllegalAccessException;"));
                            av01.visit(null, new DexType("Ljava/lang/reflect/InvocationTargetException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"obj");
                ddv.visitParameterName(1,"value");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(282,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(283,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(286,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(285,L3);
                code.visitLabel(L0);
                code.visitJumpStmt(IF_NEZ,4,-1,L3);
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/util/ajax/JSONPojoConvertor$Setter;","_method","Ljava/lang/reflect/Method;"));
                code.visitFieldStmt(SGET_OBJECT,1,-1,new Field("Lorg/mortbay/util/ajax/JSONPojoConvertor;","NULL_ARG","[Ljava/lang/Object;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,3,1},new Method("Ljava/lang/reflect/Method;","invoke",new String[]{ "Ljava/lang/Object;","[Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3,4},new Method("Lorg/mortbay/util/ajax/JSONPojoConvertor$Setter;","invokeObject",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m007_invokeObject(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/util/ajax/JSONPojoConvertor$Setter;","invokeObject",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/IllegalArgumentException;"));
                            av01.visit(null, new DexType("Ljava/lang/IllegalAccessException;"));
                            av01.visit(null, new DexType("Ljava/lang/reflect/InvocationTargetException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(13);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/lang/Exception;"});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                DexLabel L5=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L5},new String[]{ "Ljava/lang/Exception;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"obj");
                ddv.visitParameterName(1,"value");
                DexLabel L6=new DexLabel();
                ddv.visitPrologue(L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(291,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(292,L8);
                DexLabel L9=new DexLabel();
                ddv.visitEndLocal(12,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(333,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(293,L11);
                ddv.visitRestartLocal(12,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(295,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(297,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(298,L14);
                ddv.visitStartLocal(4,L14,"len","I",null);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(301,L15);
                ddv.visitStartLocal(1,L15,"array","Ljava/lang/Object;",null);
                ddv.visitLineNumber(310,L1);
                ddv.visitLineNumber(303,L2);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(306,L16);
                ddv.visitStartLocal(2,L16,"e","Ljava/lang/Exception;",null);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(307,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(314,L18);
                ddv.visitEndLocal(4,L18);
                ddv.visitEndLocal(1,L18);
                ddv.visitEndLocal(2,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(315,L19);
                ddv.visitStartLocal(5,L19,"old","[Ljava/lang/Object;",null);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(318,L20);
                ddv.visitRestartLocal(1,L20);
                ddv.visitStartLocal(3,L3,"i","I",null);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(319,L21);
                ddv.visitLineNumber(318,L4);
                ddv.visitLineNumber(321,L5);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(324,L22);
                ddv.visitRestartLocal(2,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(325,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(328,L24);
                ddv.visitEndLocal(2,L24);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(332,L25);
                ddv.visitEndLocal(5,L25);
                ddv.visitEndLocal(1,L25);
                ddv.visitEndLocal(3,L25);
                code.visitLabel(L6);
                code.visitConstStmt(CONST_4,8, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitConstStmt(CONST_4,9, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L7);
                code.visitFieldStmt(IGET_OBJECT,6,10,new Field("Lorg/mortbay/util/ajax/JSONPojoConvertor$Setter;","_numberType","Lorg/mortbay/util/ajax/JSONPojoConvertor$NumberType;"));
                code.visitJumpStmt(IF_EQZ,6,-1,L11);
                code.visitTypeStmt(INSTANCE_OF,6,12,"Ljava/lang/Number;");
                code.visitJumpStmt(IF_EQZ,6,-1,L11);
                code.visitLabel(L8);
                code.visitFieldStmt(IGET_OBJECT,6,10,new Field("Lorg/mortbay/util/ajax/JSONPojoConvertor$Setter;","_method","Ljava/lang/reflect/Method;"));
                code.visitTypeStmt(NEW_ARRAY,7,8,"[Ljava/lang/Object;");
                code.visitFieldStmt(IGET_OBJECT,8,10,new Field("Lorg/mortbay/util/ajax/JSONPojoConvertor$Setter;","_numberType","Lorg/mortbay/util/ajax/JSONPojoConvertor$NumberType;"));
                code.visitTypeStmt(CHECK_CAST,12,-1,"Ljava/lang/Number;");
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 8,12},new Method("Lorg/mortbay/util/ajax/JSONPojoConvertor$NumberType;","getActualValue",new String[]{ "Ljava/lang/Number;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitStmt3R(APUT_OBJECT,8,7,9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,11,7},new Method("Ljava/lang/reflect/Method;","invoke",new String[]{ "Ljava/lang/Object;","[Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L10);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L11);
                code.visitFieldStmt(IGET_OBJECT,6,10,new Field("Lorg/mortbay/util/ajax/JSONPojoConvertor$Setter;","_componentType","Ljava/lang/Class;"));
                code.visitJumpStmt(IF_EQZ,6,-1,L25);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12},new Method("Ljava/lang/Object;","getClass",new String[]{ },"Ljava/lang/Class;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/lang/Class;","isArray",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitJumpStmt(IF_EQZ,6,-1,L25);
                code.visitLabel(L12);
                code.visitFieldStmt(IGET_OBJECT,6,10,new Field("Lorg/mortbay/util/ajax/JSONPojoConvertor$Setter;","_numberType","Lorg/mortbay/util/ajax/JSONPojoConvertor$NumberType;"));
                code.visitJumpStmt(IF_NEZ,6,-1,L18);
                code.visitLabel(L13);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 12},new Method("Ljava/lang/reflect/Array;","getLength",new String[]{ "Ljava/lang/Object;"},"I"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitLabel(L14);
                code.visitFieldStmt(IGET_OBJECT,6,10,new Field("Lorg/mortbay/util/ajax/JSONPojoConvertor$Setter;","_componentType","Ljava/lang/Class;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 6,4},new Method("Ljava/lang/reflect/Array;","newInstance",new String[]{ "Ljava/lang/Class;","I"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L15);
                code.visitConstStmt(CONST_4,6, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitConstStmt(CONST_4,7, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 12,6,1,7,4},new Method("Ljava/lang/System;","arraycopy",new String[]{ "Ljava/lang/Object;","I","Ljava/lang/Object;","I","I"},"V"));
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,6,10,new Field("Lorg/mortbay/util/ajax/JSONPojoConvertor$Setter;","_method","Ljava/lang/reflect/Method;"));
                code.visitTypeStmt(NEW_ARRAY,7,8,"[Ljava/lang/Object;");
                code.visitStmt3R(APUT_OBJECT,1,7,9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,11,7},new Method("Ljava/lang/reflect/Method;","invoke",new String[]{ "Ljava/lang/Object;","[Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitJumpStmt(GOTO,-1,-1,L10);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,2);
                code.visitLabel(L16);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2},new Method("Lorg/mortbay/log/Log;","ignore",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitLabel(L17);
                code.visitFieldStmt(IGET_OBJECT,6,10,new Field("Lorg/mortbay/util/ajax/JSONPojoConvertor$Setter;","_method","Ljava/lang/reflect/Method;"));
                code.visitTypeStmt(NEW_ARRAY,7,8,"[Ljava/lang/Object;");
                code.visitStmt3R(APUT_OBJECT,12,7,9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,11,7},new Method("Ljava/lang/reflect/Method;","invoke",new String[]{ "Ljava/lang/Object;","[Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitJumpStmt(GOTO,-1,-1,L10);
                code.visitLabel(L18);
                code.visitStmt2R(MOVE_OBJECT,0,12);
                code.visitTypeStmt(CHECK_CAST,0,-1,"[Ljava/lang/Object;");
                code.visitStmt2R(MOVE_OBJECT,6,0);
                code.visitStmt2R(MOVE_OBJECT,0,6);
                code.visitTypeStmt(CHECK_CAST,0,-1,"[Ljava/lang/Object;");
                code.visitStmt2R(MOVE_OBJECT,5,0);
                code.visitLabel(L19);
                code.visitFieldStmt(IGET_OBJECT,6,10,new Field("Lorg/mortbay/util/ajax/JSONPojoConvertor$Setter;","_componentType","Ljava/lang/Class;"));
                code.visitStmt2R(ARRAY_LENGTH,7,5);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 6,7},new Method("Ljava/lang/reflect/Array;","newInstance",new String[]{ "Ljava/lang/Class;","I"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L20);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L3);
                code.visitStmt2R(ARRAY_LENGTH,6,5);
                code.visitJumpStmt(IF_GE,3,6,L24);
                code.visitLabel(L21);
                code.visitFieldStmt(IGET_OBJECT,7,10,new Field("Lorg/mortbay/util/ajax/JSONPojoConvertor$Setter;","_numberType","Lorg/mortbay/util/ajax/JSONPojoConvertor$NumberType;"));
                code.visitStmt3R(AGET_OBJECT,6,5,3);
                code.visitTypeStmt(CHECK_CAST,6,-1,"Ljava/lang/Number;");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 7,6},new Method("Lorg/mortbay/util/ajax/JSONPojoConvertor$NumberType;","getActualValue",new String[]{ "Ljava/lang/Number;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1,3,6},new Method("Ljava/lang/reflect/Array;","set",new String[]{ "Ljava/lang/Object;","I","Ljava/lang/Object;"},"V"));
                code.visitLabel(L4);
                code.visitStmt2R1N(ADD_INT_LIT8,3,3,1);
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitLabel(L5);
                code.visitStmt1R(MOVE_EXCEPTION,6);
                code.visitStmt2R(MOVE_OBJECT,2,6);
                code.visitLabel(L22);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2},new Method("Lorg/mortbay/log/Log;","ignore",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitLabel(L23);
                code.visitFieldStmt(IGET_OBJECT,6,10,new Field("Lorg/mortbay/util/ajax/JSONPojoConvertor$Setter;","_method","Ljava/lang/reflect/Method;"));
                code.visitTypeStmt(NEW_ARRAY,7,8,"[Ljava/lang/Object;");
                code.visitStmt3R(APUT_OBJECT,12,7,9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,11,7},new Method("Ljava/lang/reflect/Method;","invoke",new String[]{ "Ljava/lang/Object;","[Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitJumpStmt(GOTO,-1,-1,L10);
                code.visitLabel(L24);
                code.visitFieldStmt(IGET_OBJECT,6,10,new Field("Lorg/mortbay/util/ajax/JSONPojoConvertor$Setter;","_method","Ljava/lang/reflect/Method;"));
                code.visitTypeStmt(NEW_ARRAY,7,8,"[Ljava/lang/Object;");
                code.visitStmt3R(APUT_OBJECT,1,7,9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,11,7},new Method("Ljava/lang/reflect/Method;","invoke",new String[]{ "Ljava/lang/Object;","[Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitJumpStmt(GOTO,-1,-1,L10);
                code.visitLabel(L25);
                code.visitFieldStmt(IGET_OBJECT,6,10,new Field("Lorg/mortbay/util/ajax/JSONPojoConvertor$Setter;","_method","Ljava/lang/reflect/Method;"));
                code.visitTypeStmt(NEW_ARRAY,7,8,"[Ljava/lang/Object;");
                code.visitStmt3R(APUT_OBJECT,12,7,9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,11,7},new Method("Ljava/lang/reflect/Method;","invoke",new String[]{ "Ljava/lang/Object;","[Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitJumpStmt(GOTO,-1,-1,L10);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m008_isPropertyNumber(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/ajax/JSONPojoConvertor$Setter;","isPropertyNumber",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(276,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/util/ajax/JSONPojoConvertor$Setter;","_numberType","Lorg/mortbay/util/ajax/JSONPojoConvertor$NumberType;"));
                DexLabel L1=new DexLabel();
                code.visitJumpStmt(IF_EQZ,0,-1,L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                DexLabel L2=new DexLabel();
                code.visitLabel(L2);
                code.visitStmt1R(RETURN,0);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
