package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0179_org_mortbay_jetty_Main {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/jetty/Main;","Ljava/lang/Object;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("Main.java");
        m000__init_(cv);
        m001_main(cv);
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/Main;","<init>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(25,L0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/Object;","<init>",new String[]{ },"V"));
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001_main(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/jetty/Main;","main",new String[]{ "[Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(14);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/lang/Exception;"});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L2},new String[]{ "Ljava/lang/Exception;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"args");
                DexLabel L5=new DexLabel();
                ddv.visitPrologue(L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(35,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(37,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(38,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(39,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(40,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(41,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(42,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(43,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(44,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(45,L15);
                ddv.visitLineNumber(51,L0);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(52,L16);
                ddv.visitStartLocal(6,L16,"server","Lorg/mortbay/jetty/Server;",null);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(53,L17);
                ddv.visitStartLocal(4,L17,"contexts","Lorg/mortbay/jetty/handler/ContextHandlerCollection;",null);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(55,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(56,L19);
                ddv.visitStartLocal(2,L19,"connector","Lorg/mortbay/jetty/bio/SocketConnector;",null);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(57,L20);
                ddv.visitStartLocal(0,L20,"address","Ljava/lang/String;",null);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(58,L21);
                ddv.visitStartLocal(1,L21,"colon","I",null);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(59,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(65,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(67,L24);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(69,L25);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(70,L26);
                ddv.visitStartLocal(3,L26,"context","Lorg/mortbay/jetty/handler/ContextHandler;",null);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(71,L27);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(72,L28);
                DexLabel L29=new DexLabel();
                ddv.visitLineNumber(73,L29);
                ddv.visitStartLocal(7,L29,"servlet","Lorg/mortbay/jetty/servlet/ServletHandler;",null);
                DexLabel L30=new DexLabel();
                ddv.visitLineNumber(74,L30);
                DexLabel L31=new DexLabel();
                ddv.visitLineNumber(75,L31);
                DexLabel L32=new DexLabel();
                ddv.visitLineNumber(90,L32);
                ddv.visitEndLocal(3,L32);
                ddv.visitEndLocal(7,L32);
                DexLabel L33=new DexLabel();
                ddv.visitLineNumber(97,L33);
                ddv.visitEndLocal(6,L33);
                ddv.visitEndLocal(4,L33);
                ddv.visitEndLocal(2,L33);
                ddv.visitEndLocal(0,L33);
                ddv.visitEndLocal(1,L33);
                DexLabel L34=new DexLabel();
                ddv.visitLineNumber(62,L34);
                ddv.visitRestartLocal(0,L34);
                ddv.visitRestartLocal(1,L34);
                ddv.visitRestartLocal(2,L34);
                ddv.visitRestartLocal(4,L34);
                ddv.visitRestartLocal(6,L34);
                DexLabel L35=new DexLabel();
                ddv.visitLineNumber(63,L35);
                ddv.visitLineNumber(93,L2);
                ddv.visitEndLocal(0,L2);
                ddv.visitEndLocal(1,L2);
                ddv.visitEndLocal(2,L2);
                ddv.visitEndLocal(4,L2);
                ddv.visitEndLocal(6,L2);
                DexLabel L36=new DexLabel();
                ddv.visitLineNumber(95,L36);
                ddv.visitStartLocal(5,L36,"e","Ljava/lang/Exception;",null);
                DexLabel L37=new DexLabel();
                ddv.visitLineNumber(71,L37);
                ddv.visitEndLocal(5,L37);
                ddv.visitRestartLocal(0,L37);
                ddv.visitRestartLocal(1,L37);
                ddv.visitRestartLocal(2,L37);
                ddv.visitRestartLocal(3,L37);
                ddv.visitRestartLocal(4,L37);
                ddv.visitRestartLocal(6,L37);
                DexLabel L38=new DexLabel();
                ddv.visitLineNumber(77,L38);
                ddv.visitEndLocal(3,L38);
                DexLabel L39=new DexLabel();
                ddv.visitLineNumber(79,L39);
                DexLabel L40=new DexLabel();
                ddv.visitLineNumber(81,L40);
                DexLabel L41=new DexLabel();
                ddv.visitLineNumber(83,L41);
                DexLabel L42=new DexLabel();
                ddv.visitLineNumber(84,L42);
                ddv.visitStartLocal(8,L42,"webapp","Lorg/mortbay/jetty/webapp/WebAppContext;",null);
                DexLabel L43=new DexLabel();
                ddv.visitLineNumber(85,L43);
                DexLabel L44=new DexLabel();
                ddv.visitLineNumber(86,L44);
                code.visitLabel(L5);
                code.visitConstStmt(CONST_4,12, Integer.valueOf(3)); // int: 0x00000003  float:0.000000
                code.visitConstStmt(CONST_4,11, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitConstStmt(CONST_STRING,9,"/");
                code.visitLabel(L6);
                code.visitStmt2R(ARRAY_LENGTH,9,13);
                code.visitJumpStmt(IF_LT,9,11,L7);
                code.visitStmt2R(ARRAY_LENGTH,9,13);
                code.visitJumpStmt(IF_LE,9,12,L0);
                code.visitLabel(L7);
                code.visitFieldStmt(SGET_OBJECT,9,-1,new Field("Ljava/lang/System;","err","Ljava/io/PrintStream;"));
                code.visitConstStmt(CONST_STRING,10,"Usage - java org.mortbay.jetty.Main [<addr>:]<port>");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9,10},new Method("Ljava/io/PrintStream;","println",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L8);
                code.visitFieldStmt(SGET_OBJECT,9,-1,new Field("Ljava/lang/System;","err","Ljava/io/PrintStream;"));
                code.visitConstStmt(CONST_STRING,10,"Usage - java org.mortbay.jetty.Main [<addr>:]<port> docroot");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9,10},new Method("Ljava/io/PrintStream;","println",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L9);
                code.visitFieldStmt(SGET_OBJECT,9,-1,new Field("Ljava/lang/System;","err","Ljava/io/PrintStream;"));
                code.visitConstStmt(CONST_STRING,10,"Usage - java org.mortbay.jetty.Main [<addr>:]<port> -webapp myapp.war");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9,10},new Method("Ljava/io/PrintStream;","println",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L10);
                code.visitFieldStmt(SGET_OBJECT,9,-1,new Field("Ljava/lang/System;","err","Ljava/io/PrintStream;"));
                code.visitConstStmt(CONST_STRING,10,"Usage - java org.mortbay.jetty.Main [<addr>:]<port> -webapps webapps");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9,10},new Method("Ljava/io/PrintStream;","println",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L11);
                code.visitFieldStmt(SGET_OBJECT,9,-1,new Field("Ljava/lang/System;","err","Ljava/io/PrintStream;"));
                code.visitConstStmt(CONST_STRING,10,"Usage - java -jar jetty-x.x.x-standalone.jar [<addr>:]<port>");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9,10},new Method("Ljava/io/PrintStream;","println",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L12);
                code.visitFieldStmt(SGET_OBJECT,9,-1,new Field("Ljava/lang/System;","err","Ljava/io/PrintStream;"));
                code.visitConstStmt(CONST_STRING,10,"Usage - java -jar jetty-x.x.x-standalone.jar [<addr>:]<port> docroot");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9,10},new Method("Ljava/io/PrintStream;","println",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L13);
                code.visitFieldStmt(SGET_OBJECT,9,-1,new Field("Ljava/lang/System;","err","Ljava/io/PrintStream;"));
                code.visitConstStmt(CONST_STRING,10,"Usage - java -jar jetty-x.x.x-standalone.jar [<addr>:]<port> -webapp myapp.war");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9,10},new Method("Ljava/io/PrintStream;","println",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L14);
                code.visitFieldStmt(SGET_OBJECT,9,-1,new Field("Ljava/lang/System;","err","Ljava/io/PrintStream;"));
                code.visitConstStmt(CONST_STRING,10,"Usage - java -jar jetty-x.x.x-standalone.jar [<addr>:]<port> -webapps webapps");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9,10},new Method("Ljava/io/PrintStream;","println",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L15);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 11},new Method("Ljava/lang/System;","exit",new String[]{ "I"},"V"));
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,6,-1,"Lorg/mortbay/jetty/Server;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 6},new Method("Lorg/mortbay/jetty/Server;","<init>",new String[]{ },"V"));
                code.visitLabel(L16);
                code.visitTypeStmt(NEW_INSTANCE,4,-1,"Lorg/mortbay/jetty/handler/ContextHandlerCollection;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4},new Method("Lorg/mortbay/jetty/handler/ContextHandlerCollection;","<init>",new String[]{ },"V"));
                code.visitLabel(L17);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,4},new Method("Lorg/mortbay/jetty/Server;","setHandler",new String[]{ "Lorg/mortbay/jetty/Handler;"},"V"));
                code.visitLabel(L18);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Lorg/mortbay/jetty/bio/SocketConnector;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2},new Method("Lorg/mortbay/jetty/bio/SocketConnector;","<init>",new String[]{ },"V"));
                code.visitLabel(L19);
                code.visitConstStmt(CONST_4,9, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt3R(AGET_OBJECT,0,13,9);
                code.visitLabel(L20);
                code.visitConstStmt(CONST_16,9, Integer.valueOf(58)); // int: 0x0000003a  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,9},new Method("Ljava/lang/String;","lastIndexOf",new String[]{ "I"},"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitLabel(L21);
                code.visitJumpStmt(IF_GEZ,1,-1,L34);
                code.visitLabel(L22);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Ljava/lang/Integer;","parseInt",new String[]{ "Ljava/lang/String;"},"I"));
                code.visitStmt1R(MOVE_RESULT,9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,9},new Method("Lorg/mortbay/jetty/bio/SocketConnector;","setPort",new String[]{ "I"},"V"));
                code.visitLabel(L23);
                code.visitConstStmt(CONST_4,9, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitTypeStmt(NEW_ARRAY,9,9,"[Lorg/mortbay/jetty/Connector;");
                code.visitConstStmt(CONST_4,10, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt3R(APUT_OBJECT,2,9,10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,9},new Method("Lorg/mortbay/jetty/Server;","setConnectors",new String[]{ "[Lorg/mortbay/jetty/Connector;"},"V"));
                code.visitLabel(L24);
                code.visitStmt2R(ARRAY_LENGTH,9,13);
                code.visitJumpStmt(IF_GE,9,12,L38);
                code.visitLabel(L25);
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Lorg/mortbay/jetty/handler/ContextHandler;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3},new Method("Lorg/mortbay/jetty/handler/ContextHandler;","<init>",new String[]{ },"V"));
                code.visitLabel(L26);
                code.visitConstStmt(CONST_STRING,9,"/");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,9},new Method("Lorg/mortbay/jetty/handler/ContextHandler;","setContextPath",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L27);
                code.visitStmt2R(ARRAY_LENGTH,9,13);
                code.visitJumpStmt(IF_NE,9,11,L37);
                code.visitConstStmt(CONST_STRING,9,".");
                DexLabel L45=new DexLabel();
                code.visitLabel(L45);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,9},new Method("Lorg/mortbay/jetty/handler/ContextHandler;","setResourceBase",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L28);
                code.visitTypeStmt(NEW_INSTANCE,7,-1,"Lorg/mortbay/jetty/servlet/ServletHandler;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 7},new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","<init>",new String[]{ },"V"));
                code.visitLabel(L29);
                code.visitConstStmt(CONST_STRING,9,"org.mortbay.jetty.servlet.DefaultServlet");
                code.visitConstStmt(CONST_STRING,10,"/");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,9,10},new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","addServletWithMapping",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"Lorg/mortbay/jetty/servlet/ServletHolder;"));
                code.visitLabel(L30);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,7},new Method("Lorg/mortbay/jetty/handler/ContextHandler;","setHandler",new String[]{ "Lorg/mortbay/jetty/Handler;"},"V"));
                code.visitLabel(L31);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,3},new Method("Lorg/mortbay/jetty/handler/ContextHandlerCollection;","addHandler",new String[]{ "Lorg/mortbay/jetty/Handler;"},"V"));
                code.visitLabel(L32);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/Server;","start",new String[]{ },"V"));
                code.visitLabel(L33);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L34);
                code.visitConstStmt(CONST_4,9, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,9,1},new Method("Ljava/lang/String;","substring",new String[]{ "I","I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,9},new Method("Lorg/mortbay/jetty/bio/SocketConnector;","setHost",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L35);
                code.visitStmt2R1N(ADD_INT_LIT8,9,1,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,9},new Method("Ljava/lang/String;","substring",new String[]{ "I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 9},new Method("Ljava/lang/Integer;","parseInt",new String[]{ "Ljava/lang/String;"},"I"));
                code.visitStmt1R(MOVE_RESULT,9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,9},new Method("Lorg/mortbay/jetty/bio/SocketConnector;","setPort",new String[]{ "I"},"V"));
                code.visitLabel(L1);
                code.visitJumpStmt(GOTO,-1,-1,L23);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,9);
                code.visitStmt2R(MOVE_OBJECT,5,9);
                code.visitLabel(L36);
                code.visitConstStmt(CONST_STRING,9,"EXCEPTION ");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 9,5},new Method("Lorg/mortbay/log/Log;","warn",new String[]{ "Ljava/lang/String;","Ljava/lang/Throwable;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L33);
                code.visitLabel(L37);
                code.visitConstStmt(CONST_4,9, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L3);
                code.visitStmt3R(AGET_OBJECT,9,13,9);
                code.visitJumpStmt(GOTO,-1,-1,L45);
                code.visitLabel(L38);
                code.visitConstStmt(CONST_STRING,9,"-webapps");
                code.visitConstStmt(CONST_4,10, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt3R(AGET_OBJECT,10,13,10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9,10},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,9);
                code.visitJumpStmt(IF_EQZ,9,-1,L40);
                code.visitLabel(L39);
                code.visitConstStmt(CONST_4,9, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitStmt3R(AGET_OBJECT,9,13,9);
                code.visitConstStmt(CONST_STRING,10,"org/mortbay/jetty/webapp/webdefault.xml");
                code.visitConstStmt(CONST_4,11, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitConstStmt(CONST_4,12, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 6,9,10,11,12},new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","addWebApplications",new String[]{ "Lorg/mortbay/jetty/Server;","Ljava/lang/String;","Ljava/lang/String;","Z","Z"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L32);
                code.visitLabel(L40);
                code.visitConstStmt(CONST_STRING,9,"-webapp");
                code.visitConstStmt(CONST_4,10, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt3R(AGET_OBJECT,10,13,10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9,10},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,9);
                code.visitJumpStmt(IF_EQZ,9,-1,L32);
                code.visitLabel(L41);
                code.visitTypeStmt(NEW_INSTANCE,8,-1,"Lorg/mortbay/jetty/webapp/WebAppContext;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 8},new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","<init>",new String[]{ },"V"));
                code.visitLabel(L42);
                code.visitConstStmt(CONST_4,9, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitStmt3R(AGET_OBJECT,9,13,9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,9},new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","setResourceBase",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L43);
                code.visitConstStmt(CONST_STRING,9,"/");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,9},new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","setContextPath",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L44);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,8},new Method("Lorg/mortbay/jetty/handler/ContextHandlerCollection;","addHandler",new String[]{ "Lorg/mortbay/jetty/Handler;"},"V"));
                code.visitLabel(L4);
                code.visitJumpStmt(GOTO,-1,-1,L32);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
