package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0037_javax_servlet_http_HttpSessionContext {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC|ACC_INTERFACE|ACC_ABSTRACT,"Ljavax/servlet/http/HttpSessionContext;","Ljava/lang/Object;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("HttpSessionContext.java");
        m000_getIds(cv);
        m001_getSession(cv);
    }
    public static void m000_getIds(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Ljavax/servlet/http/HttpSessionContext;","getIds",new String[]{ },"Ljava/util/Enumeration;"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m001_getSession(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Ljavax/servlet/http/HttpSessionContext;","getSession",new String[]{ "Ljava/lang/String;"},"Ljavax/servlet/http/HttpSession;"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
}
