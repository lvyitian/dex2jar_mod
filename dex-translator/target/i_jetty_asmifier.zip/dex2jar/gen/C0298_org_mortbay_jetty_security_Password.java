package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0298_org_mortbay_jetty_security_Password {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/jetty/security/Password;","Lorg/mortbay/jetty/security/Credential;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("Password.java");
        f000___OBFUSCATE(cv);
        f001__pw(cv);
        m000__init_(cv);
        m001_deobfuscate(cv);
        m002_getPassword(cv);
        m003_main(cv);
        m004_obfuscate(cv);
        m005_check(cv);
        m006_equals(cv);
        m007_hashCode(cv);
        m008_toStarString(cv);
        m009_toString(cv);
    }
    public static void f000___OBFUSCATE(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/security/Password;","__OBFUSCATE","Ljava/lang/String;"), "OBF:");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001__pw(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/security/Password;","_pw","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/security/Password;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"password");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(57,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(58,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(61,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(62,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(63,L4);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2},new Method("Lorg/mortbay/jetty/security/Credential;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitFieldStmt(IPUT_OBJECT,3,2,new Field("Lorg/mortbay/jetty/security/Password;","_pw","Ljava/lang/String;"));
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/security/Password;","_pw","Ljava/lang/String;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L4);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/security/Password;","_pw","Ljava/lang/String;"));
                code.visitConstStmt(CONST_STRING,1,"OBF:");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/String;","startsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L4);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/security/Password;","_pw","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/jetty/security/Password;","deobfuscate",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/jetty/security/Password;","_pw","Ljava/lang/String;"));
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L4);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001_deobfuscate(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/jetty/security/Password;","deobfuscate",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(11);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"s");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(155,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(156,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(158,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(159,L3);
                ddv.visitStartLocal(0,L3,"b","[B",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(160,L4);
                ddv.visitStartLocal(5,L4,"l","I",null);
                DexLabel L5=new DexLabel();
                ddv.visitStartLocal(1,L5,"i","I",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(162,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(163,L7);
                ddv.visitStartLocal(7,L7,"x","Ljava/lang/String;",null);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(164,L8);
                ddv.visitStartLocal(2,L8,"i0","I",null);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(165,L9);
                ddv.visitStartLocal(3,L9,"i1","I",null);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(166,L10);
                ddv.visitStartLocal(4,L10,"i2","I",null);
                DexLabel L11=new DexLabel();
                ddv.visitStartLocal(6,L11,"l","I",null);
                DexLabel L12=new DexLabel();
                ddv.visitEndLocal(5,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(160,L13);
                DexLabel L14=new DexLabel();
                ddv.visitRestartLocal(5,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(169,L15);
                ddv.visitEndLocal(7,L15);
                ddv.visitEndLocal(2,L15);
                ddv.visitEndLocal(3,L15);
                ddv.visitEndLocal(4,L15);
                ddv.visitEndLocal(6,L15);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_STRING,8,"OBF:");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10,8},new Method("Ljava/lang/String;","startsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitJumpStmt(IF_EQZ,8,-1,L2);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,8, Integer.valueOf(4)); // int: 0x00000004  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10,8},new Method("Ljava/lang/String;","substring",new String[]{ "I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,10);
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitStmt2R1N(DIV_INT_LIT8,8,8,2);
                code.visitTypeStmt(NEW_ARRAY,0,8,"[B");
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,5, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L4);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitJumpStmt(IF_GE,1,8,L15);
                code.visitLabel(L6);
                code.visitStmt2R1N(ADD_INT_LIT8,8,1,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10,1,8},new Method("Ljava/lang/String;","substring",new String[]{ "I","I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitLabel(L7);
                code.visitConstStmt(CONST_16,8, Integer.valueOf(36)); // int: 0x00000024  float:0.000000
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 7,8},new Method("Ljava/lang/Integer;","parseInt",new String[]{ "Ljava/lang/String;","I"},"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitLabel(L8);
                code.visitStmt2R1N(DIV_INT_LIT16,3,2,256);
                code.visitLabel(L9);
                code.visitStmt2R1N(REM_INT_LIT16,4,2,256);
                code.visitLabel(L10);
                code.visitStmt2R1N(ADD_INT_LIT8,6,5,1);
                code.visitLabel(L11);
                code.visitStmt3R(ADD_INT,8,3,4);
                code.visitConstStmt(CONST_16,9, Integer.valueOf(254)); // int: 0x000000fe  float:0.000000
                code.visitStmt2R(SUB_INT_2ADDR,8,9);
                code.visitStmt2R1N(DIV_INT_LIT8,8,8,2);
                code.visitLabel(L12);
                code.visitStmt2R(INT_TO_BYTE,8,8);
                code.visitStmt3R(APUT_BYTE,8,0,5);
                code.visitLabel(L13);
                code.visitStmt2R1N(ADD_INT_LIT8,1,1,4);
                code.visitStmt2R(MOVE,5,6);
                code.visitLabel(L14);
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitLabel(L15);
                code.visitTypeStmt(NEW_INSTANCE,8,-1,"Ljava/lang/String;");
                code.visitConstStmt(CONST_4,9, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 8,0,9,5},new Method("Ljava/lang/String;","<init>",new String[]{ "[B","I","I"},"V"));
                code.visitStmt1R(RETURN_OBJECT,8);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_getPassword(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/jetty/security/Password;","getPassword",new String[]{ "Ljava/lang/String;","Ljava/lang/String;","Ljava/lang/String;"},"Lorg/mortbay/jetty/security/Password;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(10);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/io/IOException;"});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L2},new String[]{ "Ljava/io/IOException;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"realm");
                ddv.visitParameterName(1,"dft");
                ddv.visitParameterName(2,"promptDft");
                DexLabel L5=new DexLabel();
                ddv.visitPrologue(L5);
                ddv.visitLineNumber(186,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(187,L6);
                ddv.visitStartLocal(3,L6,"passwd","Ljava/lang/String;",null);
                ddv.visitLineNumber(191,L0);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(194,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(195,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(196,L9);
                ddv.visitStartLocal(0,L9,"buf","[B",null);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(197,L10);
                ddv.visitStartLocal(2,L10,"len","I",null);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(198,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(204,L12);
                ddv.visitEndLocal(0,L12);
                ddv.visitEndLocal(2,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(205,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(207,L14);
                ddv.visitLineNumber(191,L3);
                ddv.visitLineNumber(200,L2);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(202,L15);
                ddv.visitStartLocal(1,L15,"e","Ljava/io/IOException;",null);
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 7,8},new Method("Ljava/lang/System;","getProperty",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitLabel(L6);
                code.visitJumpStmt(IF_EQZ,3,-1,L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitJumpStmt(IF_NEZ,4,-1,L14);
                code.visitLabel(L0);
                code.visitFieldStmt(SGET_OBJECT,4,-1,new Field("Ljava/lang/System;","out","Ljava/io/PrintStream;"));
                code.visitTypeStmt(NEW_INSTANCE,5,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 5},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,7},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitJumpStmt(IF_EQZ,9,-1,L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitJumpStmt(IF_LEZ,6,-1,L3);
                code.visitConstStmt(CONST_STRING,6," [dft]");
                DexLabel L16=new DexLabel();
                code.visitLabel(L16);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitConstStmt(CONST_STRING,6," : ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Ljava/io/PrintStream;","print",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L7);
                code.visitFieldStmt(SGET_OBJECT,4,-1,new Field("Ljava/lang/System;","out","Ljava/io/PrintStream;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/io/PrintStream;","flush",new String[]{ },"V"));
                code.visitLabel(L8);
                code.visitConstStmt(CONST_16,4, Integer.valueOf(512)); // int: 0x00000200  float:0.000000
                code.visitTypeStmt(NEW_ARRAY,0,4,"[B");
                code.visitLabel(L9);
                code.visitFieldStmt(SGET_OBJECT,4,-1,new Field("Ljava/lang/System;","in","Ljava/io/InputStream;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,0},new Method("Ljava/io/InputStream;","read",new String[]{ "[B"},"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitLabel(L10);
                code.visitJumpStmt(IF_LEZ,2,-1,L12);
                code.visitLabel(L11);
                code.visitTypeStmt(NEW_INSTANCE,4,-1,"Ljava/lang/String;");
                code.visitConstStmt(CONST_4,5, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4,0,5,2},new Method("Ljava/lang/String;","<init>",new String[]{ "[B","I","I"},"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/lang/String;","trim",new String[]{ },"Ljava/lang/String;"));
                code.visitLabel(L1);
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitLabel(L12);
                code.visitJumpStmt(IF_EQZ,3,-1,L13);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitJumpStmt(IF_NEZ,4,-1,L14);
                code.visitLabel(L13);
                code.visitStmt2R(MOVE_OBJECT,3,9);
                code.visitLabel(L14);
                code.visitTypeStmt(NEW_INSTANCE,4,-1,"Lorg/mortbay/jetty/security/Password;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4,3},new Method("Lorg/mortbay/jetty/security/Password;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(RETURN_OBJECT,4);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_STRING,6,"");
                code.visitLabel(L4);
                code.visitJumpStmt(GOTO,-1,-1,L16);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,4);
                code.visitStmt2R(MOVE_OBJECT,1,4);
                code.visitLabel(L15);
                code.visitConstStmt(CONST_STRING,4,"EXCEPTION ");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 4,1},new Method("Lorg/mortbay/log/Log;","warn",new String[]{ "Ljava/lang/String;","Ljava/lang/Throwable;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L12);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_main(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/jetty/security/Password;","main",new String[]{ "[Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(8);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"arg");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(217,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(219,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(220,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(221,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(223,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(224,L6);
                ddv.visitStartLocal(0,L6,"p","Ljava/lang/String;",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(225,L7);
                ddv.visitStartLocal(1,L7,"pw","Lorg/mortbay/jetty/security/Password;",null);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(226,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(227,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(228,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(229,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(230,L12);
                DexLabel L13=new DexLabel();
                ddv.visitEndLocal(0,L13);
                ddv.visitEndLocal(1,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(223,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(224,L15);
                ddv.visitRestartLocal(0,L15);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,6, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitConstStmt(CONST_4,5, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitConstStmt(CONST_4,4, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L1);
                code.visitStmt2R(ARRAY_LENGTH,2,7);
                code.visitJumpStmt(IF_EQ,2,4,L5);
                code.visitStmt2R(ARRAY_LENGTH,2,7);
                code.visitJumpStmt(IF_EQ,2,6,L5);
                code.visitLabel(L2);
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Ljava/lang/System;","err","Ljava/io/PrintStream;"));
                code.visitConstStmt(CONST_STRING,3,"Usage - java org.mortbay.jetty.security.Password [<user>] <password>");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/io/PrintStream;","println",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L3);
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Ljava/lang/System;","err","Ljava/io/PrintStream;"));
                code.visitConstStmt(CONST_STRING,3,"If the password is ?, the user will be prompted for the password");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/io/PrintStream;","println",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 4},new Method("Ljava/lang/System;","exit",new String[]{ "I"},"V"));
                code.visitLabel(L5);
                code.visitStmt2R(ARRAY_LENGTH,2,7);
                code.visitJumpStmt(IF_NE,2,4,L13);
                code.visitStmt2R(MOVE,2,5);
                DexLabel L16=new DexLabel();
                code.visitLabel(L16);
                code.visitStmt3R(AGET_OBJECT,0,7,2);
                code.visitLabel(L6);
                code.visitConstStmt(CONST_STRING,2,"?");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,0},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_EQZ,2,-1,L15);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Lorg/mortbay/jetty/security/Password;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2,0},new Method("Lorg/mortbay/jetty/security/Password;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt2R(MOVE_OBJECT,1,2);
                code.visitLabel(L7);
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Ljava/lang/System;","err","Ljava/io/PrintStream;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/jetty/security/Password;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/io/PrintStream;","println",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L8);
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Ljava/lang/System;","err","Ljava/io/PrintStream;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/jetty/security/Password;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3},new Method("Lorg/mortbay/jetty/security/Password;","obfuscate",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/io/PrintStream;","println",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L9);
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Ljava/lang/System;","err","Ljava/io/PrintStream;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/jetty/security/Credential$MD5;","digest",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/io/PrintStream;","println",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L10);
                code.visitStmt2R(ARRAY_LENGTH,2,7);
                code.visitJumpStmt(IF_NE,2,6,L12);
                code.visitLabel(L11);
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Ljava/lang/System;","err","Ljava/io/PrintStream;"));
                code.visitStmt3R(AGET_OBJECT,3,7,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/jetty/security/Password;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3,4},new Method("Lorg/mortbay/jetty/security/Credential$Crypt;","crypt",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/io/PrintStream;","println",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L12);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L13);
                code.visitStmt2R(MOVE,2,4);
                code.visitLabel(L14);
                code.visitJumpStmt(GOTO,-1,-1,L16);
                code.visitLabel(L15);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Lorg/mortbay/jetty/security/Password;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2,0},new Method("Lorg/mortbay/jetty/security/Password;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt2R(MOVE_OBJECT,1,2);
                code.visitJumpStmt(GOTO,-1,-1,L7);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_obfuscate(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/jetty/security/Password;","obfuscate",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(12);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"s");
                DexLabel L5=new DexLabel();
                ddv.visitPrologue(L5);
                ddv.visitLineNumber(125,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(126,L6);
                ddv.visitStartLocal(3,L6,"buf","Ljava/lang/StringBuffer;",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(128,L7);
                ddv.visitStartLocal(0,L7,"b","[B",null);
                ddv.visitLineNumber(130,L0);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(131,L8);
                DexLabel L9=new DexLabel();
                ddv.visitStartLocal(4,L9,"i","I",null);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(133,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(134,L11);
                ddv.visitStartLocal(1,L11,"b1","B",null);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(135,L12);
                ddv.visitStartLocal(2,L12,"b2","B",null);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(136,L13);
                ddv.visitStartLocal(6,L13,"i1","I",null);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(137,L14);
                ddv.visitStartLocal(7,L14,"i2","I",null);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(138,L15);
                ddv.visitStartLocal(5,L15,"i0","I",null);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(140,L16);
                ddv.visitStartLocal(8,L16,"x","Ljava/lang/String;",null);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(145,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(131,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(142,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(143,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(144,L21);
                ddv.visitLineNumber(149,L2);
                ddv.visitEndLocal(4,L2);
                ddv.visitEndLocal(1,L2);
                ddv.visitEndLocal(2,L2);
                ddv.visitEndLocal(6,L2);
                ddv.visitEndLocal(7,L2);
                ddv.visitEndLocal(5,L2);
                ddv.visitEndLocal(8,L2);
                ddv.visitLineNumber(148,L3);
                ddv.visitRestartLocal(4,L3);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(140,L22);
                code.visitLabel(L5);
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Ljava/lang/StringBuffer;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3},new Method("Ljava/lang/StringBuffer;","<init>",new String[]{ },"V"));
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11},new Method("Ljava/lang/String;","getBytes",new String[]{ },"[B"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L7);
                code.visitStmt1R(MONITOR_ENTER,3);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_STRING,9,"OBF:");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,9},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L8);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L9);
                code.visitStmt2R(ARRAY_LENGTH,9,0);
                code.visitJumpStmt(IF_GE,4,9,L3);
                code.visitLabel(L10);
                code.visitStmt3R(AGET_BYTE,1,0,4);
                code.visitLabel(L11);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,9);
                code.visitStmt2R1N(ADD_INT_LIT8,10,4,1);
                code.visitStmt2R(SUB_INT_2ADDR,9,10);
                code.visitStmt3R(AGET_BYTE,2,0,9);
                code.visitLabel(L12);
                code.visitStmt2R1N(ADD_INT_LIT8,9,1,127);
                code.visitStmt3R(ADD_INT,6,9,2);
                code.visitLabel(L13);
                code.visitStmt2R1N(ADD_INT_LIT8,9,1,127);
                code.visitStmt3R(SUB_INT,7,9,2);
                code.visitLabel(L14);
                code.visitStmt2R1N(MUL_INT_LIT16,9,6,256);
                code.visitStmt3R(ADD_INT,5,9,7);
                code.visitLabel(L15);
                code.visitConstStmt(CONST_16,9, Integer.valueOf(36)); // int: 0x00000024  float:0.000000
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 5,9},new Method("Ljava/lang/Integer;","toString",new String[]{ "I","I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitLabel(L16);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,9);
                code.visitSparseSwitchStmt(PACKED_SWITCH,9,1,new DexLabel[]{L19,L20,L21});
                code.visitLabel(L17);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,8},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L18);
                code.visitStmt2R1N(ADD_INT_LIT8,4,4,1);
                code.visitJumpStmt(GOTO,-1,-1,L9);
                code.visitLabel(L19);
                code.visitConstStmt(CONST_16,9, Integer.valueOf(48)); // int: 0x00000030  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,9},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "C"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L20);
                code.visitConstStmt(CONST_16,9, Integer.valueOf(48)); // int: 0x00000030  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,9},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "C"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L21);
                code.visitConstStmt(CONST_16,9, Integer.valueOf(48)); // int: 0x00000030  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,9},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "C"},"Ljava/lang/StringBuffer;"));
                code.visitJumpStmt(GOTO,-1,-1,L17);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,9);
                code.visitStmt1R(MONITOR_EXIT,3);
                code.visitLabel(L1);
                code.visitStmt1R(THROW,9);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/lang/StringBuffer;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitStmt1R(MONITOR_EXIT,3);
                code.visitLabel(L4);
                code.visitStmt1R(RETURN_OBJECT,9);
                code.visitLabel(L22);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_check(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/Password;","check",new String[]{ "Ljava/lang/Object;"},"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"credentials");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(81,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(82,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(93,L2);
                ddv.visitEndLocal(2,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(84,L3);
                ddv.visitRestartLocal(2,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(85,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(87,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(88,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(90,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(91,L8);
                DexLabel L9=new DexLabel();
                ddv.visitEndLocal(2,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(93,L10);
                ddv.visitRestartLocal(2,L10);
                code.visitLabel(L0);
                code.visitJumpStmt(IF_NE,1,2,L3);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L2);
                code.visitStmt1R(RETURN,0);
                code.visitLabel(L3);
                code.visitTypeStmt(INSTANCE_OF,0,2,"Lorg/mortbay/jetty/security/Password;");
                code.visitJumpStmt(IF_EQZ,0,-1,L5);
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/security/Password;","_pw","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,0},new Method("Ljava/lang/Object;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L5);
                code.visitTypeStmt(INSTANCE_OF,0,2,"Ljava/lang/String;");
                code.visitJumpStmt(IF_EQZ,0,-1,L7);
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/security/Password;","_pw","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,0},new Method("Ljava/lang/Object;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L7);
                code.visitTypeStmt(INSTANCE_OF,0,2,"Lorg/mortbay/jetty/security/Credential;");
                code.visitJumpStmt(IF_EQZ,0,-1,L10);
                code.visitLabel(L8);
                code.visitTypeStmt(CHECK_CAST,2,-1,"Lorg/mortbay/jetty/security/Credential;");
                code.visitLabel(L9);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/security/Password;","_pw","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,0},new Method("Lorg/mortbay/jetty/security/Credential;","check",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L10);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_equals(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/Password;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(8);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"o");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(99,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(114,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(102,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(103,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(105,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(107,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(108,L7);
                ddv.visitStartLocal(1,L7,"p","Lorg/mortbay/jetty/security/Password;",null);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(111,L8);
                ddv.visitEndLocal(1,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(112,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(114,L10);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,5, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitConstStmt(CONST_4,4, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitJumpStmt(IF_NE,6,7,L3);
                code.visitStmt2R(MOVE,2,5);
                code.visitLabel(L2);
                code.visitStmt1R(RETURN,2);
                code.visitLabel(L3);
                code.visitJumpStmt(IF_NEZ,7,-1,L5);
                code.visitStmt2R(MOVE,2,4);
                code.visitLabel(L4);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L5);
                code.visitTypeStmt(INSTANCE_OF,2,7,"Lorg/mortbay/jetty/security/Password;");
                code.visitJumpStmt(IF_EQZ,2,-1,L8);
                code.visitLabel(L6);
                code.visitStmt2R(MOVE_OBJECT,0,7);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Lorg/mortbay/jetty/security/Password;");
                code.visitStmt2R(MOVE_OBJECT,1,0);
                code.visitLabel(L7);
                code.visitFieldStmt(IGET_OBJECT,2,1,new Field("Lorg/mortbay/jetty/security/Password;","_pw","Ljava/lang/String;"));
                code.visitFieldStmt(IGET_OBJECT,3,6,new Field("Lorg/mortbay/jetty/security/Password;","_pw","Ljava/lang/String;"));
                DexLabel L11=new DexLabel();
                code.visitJumpStmt(IF_EQ,2,3,L11);
                code.visitFieldStmt(IGET_OBJECT,2,6,new Field("Lorg/mortbay/jetty/security/Password;","_pw","Ljava/lang/String;"));
                DexLabel L12=new DexLabel();
                code.visitJumpStmt(IF_EQZ,2,-1,L12);
                code.visitFieldStmt(IGET_OBJECT,2,6,new Field("Lorg/mortbay/jetty/security/Password;","_pw","Ljava/lang/String;"));
                code.visitFieldStmt(IGET_OBJECT,3,1,new Field("Lorg/mortbay/jetty/security/Password;","_pw","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_EQZ,2,-1,L12);
                code.visitLabel(L11);
                code.visitStmt2R(MOVE,2,5);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L12);
                code.visitStmt2R(MOVE,2,4);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L8);
                code.visitTypeStmt(INSTANCE_OF,2,7,"Ljava/lang/String;");
                DexLabel L13=new DexLabel();
                code.visitJumpStmt(IF_EQZ,2,-1,L13);
                code.visitLabel(L9);
                code.visitFieldStmt(IGET_OBJECT,2,6,new Field("Lorg/mortbay/jetty/security/Password;","_pw","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,2},new Method("Ljava/lang/Object;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L13);
                code.visitStmt2R(MOVE,2,4);
                code.visitLabel(L10);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m007_hashCode(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/Password;","hashCode",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(119,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/security/Password;","_pw","Ljava/lang/String;"));
                DexLabel L1=new DexLabel();
                code.visitJumpStmt(IF_NEZ,0,-1,L1);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 1},new Method("Ljava/lang/Object;","hashCode",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                DexLabel L2=new DexLabel();
                code.visitLabel(L2);
                code.visitStmt1R(RETURN,0);
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/security/Password;","_pw","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/String;","hashCode",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m008_toStarString(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/Password;","toStarString",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(74,L0);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_STRING,0,"*****************************************************");
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IGET_OBJECT,2,3,new Field("Lorg/mortbay/jetty/security/Password;","_pw","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Ljava/lang/String;","substring",new String[]{ "I","I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m009_toString(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/Password;","toString",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(68,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/security/Password;","_pw","Ljava/lang/String;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
