package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0349_org_mortbay_jetty_servlet_ServletHolder {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/jetty/servlet/ServletHolder;","Lorg/mortbay/jetty/servlet/Holder;",new String[]{ "Ljava/lang/Comparable;"});
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("ServletHolder.java");
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/MemberClasses;", Visibility.SYSTEM);
            if(av00 != null) {
                {
                    DexAnnotationVisitor av01 = av00.visitArray("value");
                    if(av01 != null) {
                        av01.visit(null, new DexType("Lorg/mortbay/jetty/servlet/ServletHolder$1;"));
                        av01.visit(null, new DexType("Lorg/mortbay/jetty/servlet/ServletHolder$SingleThreadedWrapper;"));
                        av01.visit(null, new DexType("Lorg/mortbay/jetty/servlet/ServletHolder$Config;"));
                        av01.visitEnd();
                    }
                }
                av00.visitEnd();
            }
        }
        f000__config(cv);
        f001__forcedPath(cv);
        f002__initOnStartup(cv);
        f003__initOrder(cv);
        f004__realm(cv);
        f005__roleMap(cv);
        f006__runAs(cv);
        f007__servlet(cv);
        f008__unavailable(cv);
        f009__unavailableEx(cv);
        m000__init_(cv);
        m001__init_(cv);
        m002__init_(cv);
        m003_access$100(cv);
        m004_initServlet(cv);
        m005_makeUnavailable(cv);
        m006_makeUnavailable(cv);
        m007_checkServletType(cv);
        m008_compareTo(cv);
        m009_destroyInstance(cv);
        m010_doStart(cv);
        m011_doStop(cv);
        m012_equals(cv);
        m013_getForcedPath(cv);
        m014_getInitOrder(cv);
        m015_getRoleMap(cv);
        m016_getRunAs(cv);
        m017_getServlet(cv);
        m018_getUnavailableException(cv);
        m019_getUserRoleLink(cv);
        m020_handle(cv);
        m021_hashCode(cv);
        m022_isAvailable(cv);
        m023_setForcedPath(cv);
        m024_setInitOrder(cv);
        m025_setRunAs(cv);
        m026_setServlet(cv);
        m027_setUserRoleLink(cv);
    }
    public static void f000__config(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_TRANSIENT, new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_config","Lorg/mortbay/jetty/servlet/ServletHolder$Config;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001__forcedPath(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_forcedPath","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002__initOnStartup(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_initOnStartup","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003__initOrder(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_initOrder","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f004__realm(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_realm","Lorg/mortbay/jetty/security/UserRealm;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f005__roleMap(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_roleMap","Ljava/util/Map;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f006__runAs(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_runAs","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f007__servlet(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_TRANSIENT, new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_servlet","Ljavax/servlet/Servlet;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f008__unavailable(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_TRANSIENT, new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_unavailable","J"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f009__unavailableEx(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_TRANSIENT, new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_unavailableEx","Ljavax/servlet/UnavailableException;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/servlet/ServletHolder;","<init>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(72,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(56,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(72,L2);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Lorg/mortbay/jetty/servlet/Holder;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_BOOLEAN,0,1,new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_initOnStartup","Z"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/servlet/ServletHolder;","<init>",new String[]{ "Ljava/lang/Class;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"servlet");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(87,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(56,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(88,L2);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,2},new Method("Lorg/mortbay/jetty/servlet/Holder;","<init>",new String[]{ "Ljava/lang/Class;"},"V"));
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_BOOLEAN,0,1,new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_initOnStartup","Z"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/servlet/ServletHolder;","<init>",new String[]{ "Ljavax/servlet/Servlet;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"servlet");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(78,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(56,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(79,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(80,L3);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Lorg/mortbay/jetty/servlet/Holder;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_BOOLEAN,0,1,new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_initOnStartup","Z"));
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Lorg/mortbay/jetty/servlet/ServletHolder;","setServlet",new String[]{ "Ljavax/servlet/Servlet;"},"V"));
                code.visitLabel(L3);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_access$100(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_SYNTHETIC, new Method("Lorg/mortbay/jetty/servlet/ServletHolder;","access$100",new String[]{ "Lorg/mortbay/jetty/servlet/ServletHolder;"},"Lorg/mortbay/jetty/servlet/ServletHolder$Config;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"x0");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(51,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_config","Lorg/mortbay/jetty/servlet/ServletHolder$Config;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_initServlet(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PRIVATE, new Method("Lorg/mortbay/jetty/servlet/ServletHolder;","initServlet",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljavax/servlet/ServletException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                DexLabel L5=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2,L3,L4,L5},new String[]{ "Ljavax/servlet/UnavailableException;","Ljavax/servlet/ServletException;","Ljava/lang/Exception;",null});
                DexLabel L6=new DexLabel();
                code.visitTryCatch(L6,L5,new DexLabel[]{L5},new String[]{ null});
                DexLabel L7=new DexLabel();
                DexLabel L8=new DexLabel();
                code.visitTryCatch(L7,L8,new DexLabel[]{L5},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L9=new DexLabel();
                ddv.visitPrologue(L9);
                ddv.visitLineNumber(415,L9);
                ddv.visitLineNumber(418,L0);
                ddv.visitStartLocal(1,L0,"user","Ljava/security/Principal;",null);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(419,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(420,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(421,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(424,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(425,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(428,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(429,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(431,L17);
                ddv.visitLineNumber(457,L1);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(458,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(460,L19);
                ddv.visitLineNumber(433,L2);
                ddv.visitLineNumber(435,L6);
                ddv.visitStartLocal(0,L6,"e","Ljavax/servlet/UnavailableException;",null);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(436,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(437,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(438,L22);
                ddv.visitLineNumber(457,L5);
                ddv.visitEndLocal(0,L5);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(458,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(457,L24);
                ddv.visitLineNumber(440,L3);
                ddv.visitLineNumber(442,L7);
                ddv.visitStartLocal(0,L7,"e","Ljavax/servlet/ServletException;",null);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(443,L25);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(444,L26);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(445,L27);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(442,L28);
                ddv.visitLineNumber(447,L4);
                ddv.visitEndLocal(0,L4);
                DexLabel L29=new DexLabel();
                ddv.visitLineNumber(449,L29);
                ddv.visitStartLocal(0,L29,"e","Ljava/lang/Exception;",null);
                DexLabel L30=new DexLabel();
                ddv.visitLineNumber(450,L30);
                DexLabel L31=new DexLabel();
                ddv.visitLineNumber(451,L31);
                DexLabel L32=new DexLabel();
                ddv.visitLineNumber(452,L32);
                code.visitLabel(L9);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_servlet","Ljavax/servlet/Servlet;"));
                code.visitJumpStmt(IF_NEZ,2,-1,L11);
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/jetty/servlet/ServletHolder;","newInstance",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitTypeStmt(CHECK_CAST,2,-1,"Ljavax/servlet/Servlet;");
                code.visitFieldStmt(IPUT_OBJECT,2,5,new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_servlet","Ljavax/servlet/Servlet;"));
                code.visitLabel(L11);
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_config","Lorg/mortbay/jetty/servlet/ServletHolder$Config;"));
                code.visitJumpStmt(IF_NEZ,2,-1,L13);
                code.visitLabel(L12);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Lorg/mortbay/jetty/servlet/ServletHolder$Config;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2,5},new Method("Lorg/mortbay/jetty/servlet/ServletHolder$Config;","<init>",new String[]{ "Lorg/mortbay/jetty/servlet/ServletHolder;"},"V"));
                code.visitFieldStmt(IPUT_OBJECT,2,5,new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_config","Lorg/mortbay/jetty/servlet/ServletHolder$Config;"));
                code.visitLabel(L13);
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_servlet","Ljavax/servlet/Servlet;"));
                code.visitTypeStmt(INSTANCE_OF,2,2,"Lorg/mortbay/jetty/servlet/ServletHolder$SingleThreadedWrapper;");
                code.visitJumpStmt(IF_NEZ,2,-1,L15);
                code.visitLabel(L14);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/jetty/servlet/ServletHolder;","getServletHandler",new String[]{ },"Lorg/mortbay/jetty/servlet/ServletHandler;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitFieldStmt(IGET_OBJECT,3,5,new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_servlet","Ljavax/servlet/Servlet;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","customizeServlet",new String[]{ "Ljavax/servlet/Servlet;"},"Ljavax/servlet/Servlet;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitFieldStmt(IPUT_OBJECT,2,5,new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_servlet","Ljavax/servlet/Servlet;"));
                code.visitLabel(L15);
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_runAs","Ljava/lang/String;"));
                code.visitJumpStmt(IF_EQZ,2,-1,L17);
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_realm","Lorg/mortbay/jetty/security/UserRealm;"));
                code.visitJumpStmt(IF_EQZ,2,-1,L17);
                code.visitLabel(L16);
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_realm","Lorg/mortbay/jetty/security/UserRealm;"));
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IGET_OBJECT,4,5,new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_runAs","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2,3,4},new Method("Lorg/mortbay/jetty/security/UserRealm;","pushRole",new String[]{ "Ljava/security/Principal;","Ljava/lang/String;"},"Ljava/security/Principal;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L17);
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_servlet","Ljavax/servlet/Servlet;"));
                code.visitFieldStmt(IGET_OBJECT,3,5,new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_config","Lorg/mortbay/jetty/servlet/ServletHolder$Config;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2,3},new Method("Ljavax/servlet/Servlet;","init",new String[]{ "Ljavax/servlet/ServletConfig;"},"V"));
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_runAs","Ljava/lang/String;"));
                code.visitJumpStmt(IF_EQZ,2,-1,L19);
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_realm","Lorg/mortbay/jetty/security/UserRealm;"));
                code.visitJumpStmt(IF_EQZ,2,-1,L19);
                code.visitJumpStmt(IF_EQZ,1,-1,L19);
                code.visitLabel(L18);
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_realm","Lorg/mortbay/jetty/security/UserRealm;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2,1},new Method("Lorg/mortbay/jetty/security/UserRealm;","popRole",new String[]{ "Ljava/security/Principal;"},"Ljava/security/Principal;"));
                code.visitLabel(L19);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,2);
                code.visitStmt2R(MOVE_OBJECT,0,2);
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 5,0},new Method("Lorg/mortbay/jetty/servlet/ServletHolder;","makeUnavailable",new String[]{ "Ljavax/servlet/UnavailableException;"},"V"));
                code.visitLabel(L20);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_OBJECT,2,5,new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_servlet","Ljavax/servlet/Servlet;"));
                code.visitLabel(L21);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_OBJECT,2,5,new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_config","Lorg/mortbay/jetty/servlet/ServletHolder$Config;"));
                code.visitLabel(L22);
                code.visitStmt1R(THROW,0);
                code.visitLabel(L5);
                code.visitStmt1R(MOVE_EXCEPTION,2);
                code.visitFieldStmt(IGET_OBJECT,3,5,new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_runAs","Ljava/lang/String;"));
                code.visitJumpStmt(IF_EQZ,3,-1,L24);
                code.visitFieldStmt(IGET_OBJECT,3,5,new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_realm","Lorg/mortbay/jetty/security/UserRealm;"));
                code.visitJumpStmt(IF_EQZ,3,-1,L24);
                code.visitJumpStmt(IF_EQZ,1,-1,L24);
                code.visitLabel(L23);
                code.visitFieldStmt(IGET_OBJECT,3,5,new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_realm","Lorg/mortbay/jetty/security/UserRealm;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3,1},new Method("Lorg/mortbay/jetty/security/UserRealm;","popRole",new String[]{ "Ljava/security/Principal;"},"Ljava/security/Principal;"));
                code.visitLabel(L24);
                code.visitStmt1R(THROW,2);
                code.visitLabel(L3);
                code.visitStmt1R(MOVE_EXCEPTION,2);
                code.visitStmt2R(MOVE_OBJECT,0,2);
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljavax/servlet/ServletException;","getCause",new String[]{ },"Ljava/lang/Throwable;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitJumpStmt(IF_NEZ,2,-1,L28);
                code.visitStmt2R(MOVE_OBJECT,2,0);
                DexLabel L33=new DexLabel();
                code.visitLabel(L33);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 5,2},new Method("Lorg/mortbay/jetty/servlet/ServletHolder;","makeUnavailable",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitLabel(L25);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_OBJECT,2,5,new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_servlet","Ljavax/servlet/Servlet;"));
                code.visitLabel(L26);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_OBJECT,2,5,new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_config","Lorg/mortbay/jetty/servlet/ServletHolder$Config;"));
                code.visitLabel(L27);
                code.visitStmt1R(THROW,0);
                code.visitLabel(L28);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljavax/servlet/ServletException;","getCause",new String[]{ },"Ljava/lang/Throwable;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitJumpStmt(GOTO,-1,-1,L33);
                code.visitLabel(L4);
                code.visitStmt1R(MOVE_EXCEPTION,2);
                code.visitStmt2R(MOVE_OBJECT,0,2);
                code.visitLabel(L29);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 5,0},new Method("Lorg/mortbay/jetty/servlet/ServletHolder;","makeUnavailable",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitLabel(L30);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_OBJECT,2,5,new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_servlet","Ljavax/servlet/Servlet;"));
                code.visitLabel(L31);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_OBJECT,2,5,new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_config","Lorg/mortbay/jetty/servlet/ServletHolder$Config;"));
                code.visitLabel(L32);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Ljavax/servlet/ServletException;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2,0},new Method("Ljavax/servlet/ServletException;","<init>",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitStmt1R(THROW,2);
                code.visitLabel(L8);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_makeUnavailable(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PRIVATE, new Method("Lorg/mortbay/jetty/servlet/ServletHolder;","makeUnavailable",new String[]{ "Ljava/lang/Throwable;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"e");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(401,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(402,L1);
                DexLabel L2=new DexLabel();
                ddv.visitEndLocal(4,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(409,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(405,L4);
                ddv.visitRestartLocal(4,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(406,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(407,L6);
                code.visitLabel(L0);
                code.visitTypeStmt(INSTANCE_OF,0,4,"Ljavax/servlet/UnavailableException;");
                code.visitJumpStmt(IF_EQZ,0,-1,L4);
                code.visitLabel(L1);
                code.visitTypeStmt(CHECK_CAST,4,-1,"Ljavax/servlet/UnavailableException;");
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3,4},new Method("Lorg/mortbay/jetty/servlet/ServletHolder;","makeUnavailable",new String[]{ "Ljavax/servlet/UnavailableException;"},"V"));
                code.visitLabel(L3);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_servletHandler","Lorg/mortbay/jetty/servlet/ServletHandler;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","getServletContext",new String[]{ },"Ljavax/servlet/ServletContext;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitConstStmt(CONST_STRING,1,"unavailable");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1,4},new Method("Ljavax/servlet/ServletContext;","log",new String[]{ "Ljava/lang/String;","Ljava/lang/Throwable;"},"V"));
                code.visitLabel(L5);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljavax/servlet/UnavailableException;");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/lang/Throwable;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(-1)); // int: 0xffffffff  float:NaN
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1,2},new Method("Ljavax/servlet/UnavailableException;","<init>",new String[]{ "Ljava/lang/String;","I"},"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,3,new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_unavailableEx","Ljavax/servlet/UnavailableException;"));
                code.visitLabel(L6);
                code.visitConstStmt(CONST_WIDE_16,0,Long.valueOf(-1L)); // long: 0xffffffffffffffff  double:NaN
                code.visitFieldStmt(IPUT_WIDE,0,3,new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_unavailable","J"));
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_makeUnavailable(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PRIVATE, new Method("Lorg/mortbay/jetty/servlet/ServletHolder;","makeUnavailable",new String[]{ "Ljavax/servlet/UnavailableException;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(8);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"e");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(380,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(396,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(383,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(385,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(386,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(387,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(388,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(391,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(392,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(394,L10);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_WIDE_16,4,Long.valueOf(-1L)); // long: 0xffffffffffffffff  double:NaN
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,6,new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_unavailableEx","Ljavax/servlet/UnavailableException;"));
                code.visitJumpStmt(IF_NE,0,7,L3);
                code.visitFieldStmt(IGET_WIDE,0,6,new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_unavailable","J"));
                code.visitConstStmt(CONST_WIDE_16,2,Long.valueOf(0L)); // long: 0x0000000000000000  double:0.000000
                code.visitStmt3R(CMP_LONG,0,0,2);
                code.visitJumpStmt(IF_EQZ,0,-1,L3);
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,6,new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_servletHandler","Lorg/mortbay/jetty/servlet/ServletHandler;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","getServletContext",new String[]{ },"Ljavax/servlet/ServletContext;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitConstStmt(CONST_STRING,1,"unavailable");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1,7},new Method("Ljavax/servlet/ServletContext;","log",new String[]{ "Ljava/lang/String;","Ljava/lang/Throwable;"},"V"));
                code.visitLabel(L4);
                code.visitFieldStmt(IPUT_OBJECT,7,6,new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_unavailableEx","Ljavax/servlet/UnavailableException;"));
                code.visitLabel(L5);
                code.visitFieldStmt(IPUT_WIDE,4,6,new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_unavailable","J"));
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Ljavax/servlet/UnavailableException;","isPermanent",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L8);
                code.visitLabel(L7);
                code.visitFieldStmt(IPUT_WIDE,4,6,new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_unavailable","J"));
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L8);
                code.visitFieldStmt(IGET_OBJECT,0,6,new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_unavailableEx","Ljavax/servlet/UnavailableException;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljavax/servlet/UnavailableException;","getUnavailableSeconds",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_LEZ,0,-1,L10);
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Ljava/lang/System;","currentTimeMillis",new String[]{ },"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,0);
                code.visitFieldStmt(IGET_OBJECT,2,6,new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_unavailableEx","Ljavax/servlet/UnavailableException;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljavax/servlet/UnavailableException;","getUnavailableSeconds",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitStmt2R1N(MUL_INT_LIT16,2,2,1000);
                code.visitStmt2R(INT_TO_LONG,2,2);
                code.visitStmt2R(ADD_LONG_2ADDR,0,2);
                code.visitFieldStmt(IPUT_WIDE,0,6,new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_unavailable","J"));
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Ljava/lang/System;","currentTimeMillis",new String[]{ },"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,0);
                code.visitConstStmt(CONST_WIDE_16,2,Long.valueOf(5000L)); // long: 0x0000000000001388  double:0.000000
                code.visitStmt2R(ADD_LONG_2ADDR,0,2);
                code.visitFieldStmt(IPUT_WIDE,0,6,new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_unavailable","J"));
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m007_checkServletType(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/ServletHolder;","checkServletType",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljavax/servlet/UnavailableException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(351,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(353,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(355,L2);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_CLASS,0,new DexType("Ljavax/servlet/Servlet;"));
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_class","Ljava/lang/Class;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/Class;","isAssignableFrom",new String[]{ "Ljava/lang/Class;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_NEZ,0,-1,L2);
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljavax/servlet/UnavailableException;");
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,2,"Servlet ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitFieldStmt(IGET_OBJECT,2,3,new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_class","Ljava/lang/Class;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitConstStmt(CONST_STRING,2," is not a javax.servlet.Servlet");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Ljavax/servlet/UnavailableException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,0);
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m008_compareTo(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/ServletHolder;","compareTo",new String[]{ "Ljava/lang/Object;"},"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(10);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"o");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(135,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(137,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(138,L3);
                ddv.visitStartLocal(2,L3,"sh","Lorg/mortbay/jetty/servlet/ServletHolder;",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(152,L4);
                ddv.visitEndLocal(2,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(140,L5);
                ddv.visitRestartLocal(2,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(141,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(142,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(143,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(145,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(146,L10);
                ddv.visitStartLocal(1,L10,"c","I",null);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(147,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(148,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(149,L13);
                DexLabel L14=new DexLabel();
                ddv.visitRestartLocal(1,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(150,L15);
                DexLabel L16=new DexLabel();
                ddv.visitEndLocal(1,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(145,L17);
                DexLabel L18=new DexLabel();
                ddv.visitRestartLocal(1,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(149,L19);
                DexLabel L20=new DexLabel();
                ddv.visitEndLocal(2,L20);
                ddv.visitEndLocal(1,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(152,L21);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,7, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitConstStmt(CONST_4,6, Integer.valueOf(-1)); // int: 0xffffffff  float:NaN
                code.visitConstStmt(CONST_4,5, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L1);
                code.visitTypeStmt(INSTANCE_OF,3,9,"Lorg/mortbay/jetty/servlet/ServletHolder;");
                code.visitJumpStmt(IF_EQZ,3,-1,L20);
                code.visitLabel(L2);
                code.visitStmt2R(MOVE_OBJECT,0,9);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Lorg/mortbay/jetty/servlet/ServletHolder;");
                code.visitStmt2R(MOVE_OBJECT,2,0);
                code.visitLabel(L3);
                code.visitJumpStmt(IF_NE,2,8,L5);
                code.visitStmt2R(MOVE,3,7);
                code.visitLabel(L4);
                code.visitStmt1R(RETURN,3);
                code.visitLabel(L5);
                code.visitFieldStmt(IGET,3,2,new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_initOrder","I"));
                code.visitFieldStmt(IGET,4,8,new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_initOrder","I"));
                code.visitJumpStmt(IF_GE,3,4,L7);
                code.visitStmt2R(MOVE,3,5);
                code.visitLabel(L6);
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitLabel(L7);
                code.visitFieldStmt(IGET,3,2,new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_initOrder","I"));
                code.visitFieldStmt(IGET,4,8,new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_initOrder","I"));
                code.visitJumpStmt(IF_LE,3,4,L9);
                code.visitStmt2R(MOVE,3,6);
                code.visitLabel(L8);
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitLabel(L9);
                code.visitFieldStmt(IGET_OBJECT,3,8,new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_className","Ljava/lang/String;"));
                code.visitJumpStmt(IF_EQZ,3,-1,L16);
                code.visitFieldStmt(IGET_OBJECT,3,2,new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_className","Ljava/lang/String;"));
                code.visitJumpStmt(IF_EQZ,3,-1,L16);
                code.visitFieldStmt(IGET_OBJECT,3,8,new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_className","Ljava/lang/String;"));
                code.visitFieldStmt(IGET_OBJECT,4,2,new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_className","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/String;","compareTo",new String[]{ "Ljava/lang/String;"},"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitStmt2R(MOVE,1,3);
                code.visitLabel(L10);
                code.visitJumpStmt(IF_NEZ,1,-1,L12);
                code.visitLabel(L11);
                code.visitFieldStmt(IGET_OBJECT,3,8,new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_name","Ljava/lang/String;"));
                code.visitFieldStmt(IGET_OBJECT,4,2,new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_name","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/String;","compareTo",new String[]{ "Ljava/lang/String;"},"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitLabel(L12);
                code.visitJumpStmt(IF_NEZ,1,-1,L14);
                code.visitLabel(L13);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Lorg/mortbay/jetty/servlet/ServletHolder;","hashCode",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9},new Method("Ljava/lang/Object;","hashCode",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitJumpStmt(IF_LE,3,4,L18);
                code.visitStmt2R(MOVE,1,5);
                code.visitLabel(L14);
                code.visitStmt2R(MOVE,3,1);
                code.visitLabel(L15);
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitLabel(L16);
                code.visitStmt2R(MOVE,1,7);
                code.visitLabel(L17);
                code.visitJumpStmt(GOTO,-1,-1,L10);
                code.visitLabel(L18);
                code.visitStmt2R(MOVE,1,6);
                code.visitLabel(L19);
                code.visitJumpStmt(GOTO,-1,-1,L14);
                code.visitLabel(L20);
                code.visitStmt2R(MOVE,3,5);
                code.visitLabel(L21);
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m009_destroyInstance(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/ServletHolder;","destroyInstance",new String[]{ "Ljava/lang/Object;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/Exception;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"o");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(315,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(320,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(317,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(318,L3);
                ddv.visitStartLocal(1,L3,"servlet","Ljavax/servlet/Servlet;",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(319,L4);
                code.visitLabel(L0);
                code.visitJumpStmt(IF_NEZ,4,-1,L2);
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitStmt2R(MOVE_OBJECT,0,4);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Ljavax/servlet/Servlet;");
                code.visitStmt2R(MOVE_OBJECT,1,0);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Ljavax/servlet/Servlet;","destroy",new String[]{ },"V"));
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/jetty/servlet/ServletHolder;","getServletHandler",new String[]{ },"Lorg/mortbay/jetty/servlet/ServletHandler;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,1},new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","customizeServletDestroy",new String[]{ "Ljavax/servlet/Servlet;"},"Ljavax/servlet/Servlet;"));
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m010_doStart(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/ServletHolder;","doStart",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/Exception;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljavax/servlet/UnavailableException;"});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                DexLabel L5=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L5},new String[]{ "Ljava/lang/Exception;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L6=new DexLabel();
                ddv.visitPrologue(L6);
                ddv.visitLineNumber(239,L6);
                ddv.visitLineNumber(242,L0);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(243,L7);
                ddv.visitLineNumber(250,L1);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(252,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(253,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(256,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(257,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(259,L12);
                ddv.visitLineNumber(263,L3);
                ddv.visitLineNumber(273,L4);
                ddv.visitLineNumber(245,L2);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(247,L13);
                ddv.visitStartLocal(1,L13,"ue","Ljavax/servlet/UnavailableException;",null);
                ddv.visitLineNumber(265,L5);
                ddv.visitEndLocal(1,L5);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(267,L14);
                ddv.visitStartLocal(0,L14,"e","Ljava/lang/Exception;",null);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(268,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(270,L16);
                code.visitLabel(L6);
                code.visitConstStmt(CONST_WIDE_16,2,Long.valueOf(0L)); // long: 0x0000000000000000  double:0.000000
                code.visitFieldStmt(IPUT_WIDE,2,4,new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_unavailable","J"));
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 4},new Method("Lorg/mortbay/jetty/servlet/Holder;","doStart",new String[]{ },"V"));
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/jetty/servlet/ServletHolder;","checkServletType",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Lorg/mortbay/jetty/servlet/ServletHolder$Config;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2,4},new Method("Lorg/mortbay/jetty/servlet/ServletHolder$Config;","<init>",new String[]{ "Lorg/mortbay/jetty/servlet/ServletHolder;"},"V"));
                code.visitFieldStmt(IPUT_OBJECT,2,4,new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_config","Lorg/mortbay/jetty/servlet/ServletHolder$Config;"));
                code.visitLabel(L8);
                code.visitFieldStmt(IGET_OBJECT,2,4,new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_runAs","Ljava/lang/String;"));
                code.visitJumpStmt(IF_EQZ,2,-1,L10);
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/jetty/handler/ContextHandler;","getCurrentContext",new String[]{ },"Lorg/mortbay/jetty/handler/ContextHandler$SContext;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/handler/ContextHandler$SContext;","getContextHandler",new String[]{ },"Lorg/mortbay/jetty/handler/ContextHandler;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitConstStmt(CONST_CLASS,3,new DexType("Lorg/mortbay/jetty/security/SecurityHandler;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Lorg/mortbay/jetty/handler/ContextHandler;","getChildHandlerByClass",new String[]{ "Ljava/lang/Class;"},"Lorg/mortbay/jetty/Handler;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitTypeStmt(CHECK_CAST,2,-1,"Lorg/mortbay/jetty/security/SecurityHandler;");
                code.visitTypeStmt(CHECK_CAST,2,-1,"Lorg/mortbay/jetty/security/SecurityHandler;");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/security/SecurityHandler;","getUserRealm",new String[]{ },"Lorg/mortbay/jetty/security/UserRealm;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitFieldStmt(IPUT_OBJECT,2,4,new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_realm","Lorg/mortbay/jetty/security/UserRealm;"));
                code.visitLabel(L10);
                code.visitConstStmt(CONST_CLASS,2,new DexType("Ljavax/servlet/SingleThreadModel;"));
                code.visitFieldStmt(IGET_OBJECT,3,4,new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_class","Ljava/lang/Class;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/Class;","isAssignableFrom",new String[]{ "Ljava/lang/Class;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_EQZ,2,-1,L12);
                code.visitLabel(L11);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Lorg/mortbay/jetty/servlet/ServletHolder$SingleThreadedWrapper;");
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2,4,3},new Method("Lorg/mortbay/jetty/servlet/ServletHolder$SingleThreadedWrapper;","<init>",new String[]{ "Lorg/mortbay/jetty/servlet/ServletHolder;","Lorg/mortbay/jetty/servlet/ServletHolder$1;"},"V"));
                code.visitFieldStmt(IPUT_OBJECT,2,4,new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_servlet","Ljavax/servlet/Servlet;"));
                code.visitLabel(L12);
                code.visitFieldStmt(IGET_BOOLEAN,2,4,new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_extInstance","Z"));
                code.visitJumpStmt(IF_NEZ,2,-1,L3);
                code.visitFieldStmt(IGET_BOOLEAN,2,4,new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_initOnStartup","Z"));
                code.visitJumpStmt(IF_EQZ,2,-1,L4);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4},new Method("Lorg/mortbay/jetty/servlet/ServletHolder;","initServlet",new String[]{ },"V"));
                code.visitLabel(L4);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,2);
                code.visitStmt2R(MOVE_OBJECT,1,2);
                code.visitLabel(L13);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4,1},new Method("Lorg/mortbay/jetty/servlet/ServletHolder;","makeUnavailable",new String[]{ "Ljavax/servlet/UnavailableException;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitLabel(L5);
                code.visitStmt1R(MOVE_EXCEPTION,0);
                code.visitLabel(L14);
                code.visitFieldStmt(IGET_OBJECT,2,4,new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_servletHandler","Lorg/mortbay/jetty/servlet/ServletHandler;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","isStartWithUnavailable",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_EQZ,2,-1,L16);
                code.visitLabel(L15);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/log/Log;","ignore",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitLabel(L16);
                code.visitStmt1R(THROW,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m011_doStop(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/ServletHolder;","doStop",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                DexLabel L5=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L5,L2},new String[]{ "Ljava/lang/Exception;",null});
                DexLabel L6=new DexLabel();
                code.visitTryCatch(L4,L6,new DexLabel[]{L2},new String[]{ null});
                DexLabel L7=new DexLabel();
                DexLabel L8=new DexLabel();
                code.visitTryCatch(L7,L8,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L9=new DexLabel();
                ddv.visitPrologue(L9);
                ddv.visitLineNumber(278,L9);
                ddv.visitLineNumber(282,L0);
                ddv.visitStartLocal(1,L0,"user","Ljava/security/Principal;",null);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(283,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(285,L11);
                ddv.visitLineNumber(289,L3);
                ddv.visitLineNumber(297,L4);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(298,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(300,L13);
                ddv.visitLineNumber(304,L6);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(306,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(307,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(309,L16);
                ddv.visitLineNumber(291,L5);
                ddv.visitLineNumber(293,L7);
                ddv.visitStartLocal(0,L7,"e","Ljava/lang/Exception;",null);
                ddv.visitLineNumber(304,L2);
                ddv.visitEndLocal(0,L2);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(306,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(307,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(304,L19);
                code.visitLabel(L9);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_runAs","Ljava/lang/String;"));
                code.visitJumpStmt(IF_EQZ,2,-1,L11);
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_realm","Lorg/mortbay/jetty/security/UserRealm;"));
                code.visitJumpStmt(IF_EQZ,2,-1,L11);
                code.visitLabel(L10);
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_realm","Lorg/mortbay/jetty/security/UserRealm;"));
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IGET_OBJECT,4,5,new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_runAs","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2,3,4},new Method("Lorg/mortbay/jetty/security/UserRealm;","pushRole",new String[]{ "Ljava/security/Principal;","Ljava/lang/String;"},"Ljava/security/Principal;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L11);
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_servlet","Ljavax/servlet/Servlet;"));
                code.visitLabel(L1);
                code.visitJumpStmt(IF_EQZ,2,-1,L4);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_servlet","Ljavax/servlet/Servlet;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,2},new Method("Lorg/mortbay/jetty/servlet/ServletHolder;","destroyInstance",new String[]{ "Ljava/lang/Object;"},"V"));
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_BOOLEAN,2,5,new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_extInstance","Z"));
                code.visitJumpStmt(IF_NEZ,2,-1,L13);
                code.visitLabel(L12);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_OBJECT,2,5,new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_servlet","Ljavax/servlet/Servlet;"));
                code.visitLabel(L13);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_OBJECT,2,5,new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_config","Lorg/mortbay/jetty/servlet/ServletHolder$Config;"));
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 5},new Method("Lorg/mortbay/jetty/servlet/Holder;","doStop",new String[]{ },"V"));
                code.visitLabel(L14);
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_runAs","Ljava/lang/String;"));
                code.visitJumpStmt(IF_EQZ,2,-1,L16);
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_realm","Lorg/mortbay/jetty/security/UserRealm;"));
                code.visitJumpStmt(IF_EQZ,2,-1,L16);
                code.visitJumpStmt(IF_EQZ,1,-1,L16);
                code.visitLabel(L15);
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_realm","Lorg/mortbay/jetty/security/UserRealm;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2,1},new Method("Lorg/mortbay/jetty/security/UserRealm;","popRole",new String[]{ "Ljava/security/Principal;"},"Ljava/security/Principal;"));
                code.visitLabel(L16);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L5);
                code.visitStmt1R(MOVE_EXCEPTION,2);
                code.visitStmt2R(MOVE_OBJECT,0,2);
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/log/Log;","warn",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitLabel(L8);
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,2);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 5},new Method("Lorg/mortbay/jetty/servlet/Holder;","doStop",new String[]{ },"V"));
                code.visitLabel(L17);
                code.visitFieldStmt(IGET_OBJECT,3,5,new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_runAs","Ljava/lang/String;"));
                code.visitJumpStmt(IF_EQZ,3,-1,L19);
                code.visitFieldStmt(IGET_OBJECT,3,5,new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_realm","Lorg/mortbay/jetty/security/UserRealm;"));
                code.visitJumpStmt(IF_EQZ,3,-1,L19);
                code.visitJumpStmt(IF_EQZ,1,-1,L19);
                code.visitLabel(L18);
                code.visitFieldStmt(IGET_OBJECT,3,5,new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_realm","Lorg/mortbay/jetty/security/UserRealm;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3,1},new Method("Lorg/mortbay/jetty/security/UserRealm;","popRole",new String[]{ "Ljava/security/Principal;"},"Ljava/security/Principal;"));
                code.visitLabel(L19);
                code.visitStmt1R(THROW,2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m012_equals(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/ServletHolder;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"o");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(158,L0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Lorg/mortbay/jetty/servlet/ServletHolder;","compareTo",new String[]{ "Ljava/lang/Object;"},"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                DexLabel L1=new DexLabel();
                code.visitJumpStmt(IF_NEZ,0,-1,L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                DexLabel L2=new DexLabel();
                code.visitLabel(L2);
                code.visitStmt1R(RETURN,0);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m013_getForcedPath(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/ServletHolder;","getForcedPath",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(223,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_forcedPath","Ljava/lang/String;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m014_getInitOrder(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/ServletHolder;","getInitOrder",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(115,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,1,new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_initOrder","I"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m015_getRoleMap(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/ServletHolder;","getRoleMap",new String[]{ },"Ljava/util/Map;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(198,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_roleMap","Ljava/util/Map;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m016_getRunAs(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/ServletHolder;","getRunAs",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(214,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_runAs","Ljava/lang/String;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m017_getServlet(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/ServletHolder;","getServlet",new String[]{ },"Ljavax/servlet/Servlet;"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljavax/servlet/ServletException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L1},new String[]{ null});
                DexLabel L2=new DexLabel();
                DexLabel L3=new DexLabel();
                code.visitTryCatch(L2,L3,new DexLabel[]{L1},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L4=new DexLabel();
                ddv.visitPrologue(L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(330,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(332,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(333,L7);
                ddv.visitLineNumber(330,L1);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(334,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(335,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(338,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(339,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(340,L12);
                code.visitLabel(L4);
                code.visitConstStmt(CONST_WIDE_16,2,Long.valueOf(0L)); // long: 0x0000000000000000  double:0.000000
                code.visitLabel(L5);
                code.visitStmt1R(MONITOR_ENTER,4);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_WIDE,0,4,new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_unavailable","J"));
                code.visitStmt3R(CMP_LONG,0,0,2);
                code.visitJumpStmt(IF_EQZ,0,-1,L10);
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_WIDE,0,4,new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_unavailable","J"));
                code.visitStmt3R(CMP_LONG,0,0,2);
                code.visitJumpStmt(IF_LTZ,0,-1,L7);
                code.visitFieldStmt(IGET_WIDE,0,4,new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_unavailable","J"));
                code.visitStmt3R(CMP_LONG,0,0,2);
                code.visitJumpStmt(IF_LEZ,0,-1,L8);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Ljava/lang/System;","currentTimeMillis",new String[]{ },"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,0);
                code.visitFieldStmt(IGET_WIDE,2,4,new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_unavailable","J"));
                code.visitStmt3R(CMP_LONG,0,0,2);
                code.visitJumpStmt(IF_GEZ,0,-1,L8);
                code.visitLabel(L7);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_unavailableEx","Ljavax/servlet/UnavailableException;"));
                code.visitStmt1R(THROW,0);
                code.visitLabel(L1);
                code.visitStmt1R(MOVE_EXCEPTION,0);
                code.visitStmt1R(MONITOR_EXIT,4);
                code.visitStmt1R(THROW,0);
                code.visitLabel(L8);
                code.visitConstStmt(CONST_WIDE_16,0,Long.valueOf(0L)); // long: 0x0000000000000000  double:0.000000
                code.visitLabel(L2);
                code.visitFieldStmt(IPUT_WIDE,0,4,new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_unavailable","J"));
                code.visitLabel(L9);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_OBJECT,0,4,new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_unavailableEx","Ljavax/servlet/UnavailableException;"));
                code.visitLabel(L10);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_servlet","Ljavax/servlet/Servlet;"));
                code.visitJumpStmt(IF_NEZ,0,-1,L12);
                code.visitLabel(L11);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4},new Method("Lorg/mortbay/jetty/servlet/ServletHolder;","initServlet",new String[]{ },"V"));
                code.visitLabel(L12);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_servlet","Ljavax/servlet/Servlet;"));
                code.visitLabel(L3);
                code.visitStmt1R(MONITOR_EXIT,4);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m018_getUnavailableException(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/ServletHolder;","getUnavailableException",new String[]{ },"Ljavax/servlet/UnavailableException;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(96,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_unavailableEx","Ljavax/servlet/UnavailableException;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m019_getUserRoleLink(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/ServletHolder;","getUserRoleLink",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(189,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(192,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(191,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(192,L3);
                ddv.visitStartLocal(0,L3,"link","Ljava/lang/String;",null);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_roleMap","Ljava/util/Map;"));
                code.visitJumpStmt(IF_NEZ,1,-1,L2);
                code.visitStmt2R(MOVE_OBJECT,1,3);
                code.visitLabel(L1);
                code.visitStmt1R(RETURN_OBJECT,1);
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_roleMap","Ljava/util/Map;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1,3},new Method("Ljava/util/Map;","get",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Ljava/lang/String;");
                code.visitLabel(L3);
                DexLabel L4=new DexLabel();
                code.visitJumpStmt(IF_NEZ,0,-1,L4);
                code.visitStmt2R(MOVE_OBJECT,1,3);
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitLabel(L4);
                code.visitStmt2R(MOVE_OBJECT,1,0);
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m020_handle(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/ServletHolder;","handle",new String[]{ "Ljavax/servlet/ServletRequest;","Ljavax/servlet/ServletResponse;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljavax/servlet/ServletException;"));
                            av01.visit(null, new DexType("Ljavax/servlet/UnavailableException;"));
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(13);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L2},new String[]{ null});
                DexLabel L5=new DexLabel();
                DexLabel L6=new DexLabel();
                DexLabel L7=new DexLabel();
                DexLabel L8=new DexLabel();
                code.visitTryCatch(L5,L6,new DexLabel[]{L7,L8},new String[]{ "Ljavax/servlet/UnavailableException;",null});
                DexLabel L9=new DexLabel();
                code.visitTryCatch(L9,L8,new DexLabel[]{L8},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"request");
                ddv.visitParameterName(1,"response");
                DexLabel L10=new DexLabel();
                ddv.visitPrologue(L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(471,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(472,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(474,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(475,L14);
                ddv.visitStartLocal(2,L14,"servlet","Ljavax/servlet/Servlet;",null);
                ddv.visitLineNumber(477,L0);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(478,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(479,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(480,L17);
                ddv.visitLineNumber(481,L2);
                ddv.visitLineNumber(484,L4);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(485,L18);
                ddv.visitStartLocal(3,L18,"servlet_error","Z",null);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(486,L19);
                ddv.visitStartLocal(4,L19,"user","Ljava/security/Principal;",null);
                ddv.visitLineNumber(490,L5);
                ddv.visitStartLocal(0,L5,"base_request","Lorg/mortbay/jetty/Request;",null);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(492,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(495,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(497,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(498,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(499,L24);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(502,L25);
                ddv.visitLineNumber(503,L6);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(513,L26);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(515,L27);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(516,L28);
                ddv.visitRestartLocal(4,L28);
                DexLabel L29=new DexLabel();
                ddv.visitLineNumber(520,L29);
                DexLabel L30=new DexLabel();
                ddv.visitLineNumber(521,L30);
                DexLabel L31=new DexLabel();
                ddv.visitLineNumber(523,L31);
                ddv.visitLineNumber(505,L7);
                ddv.visitLineNumber(507,L9);
                ddv.visitStartLocal(1,L9,"e","Ljavax/servlet/UnavailableException;",null);
                DexLabel L32=new DexLabel();
                ddv.visitLineNumber(508,L32);
                ddv.visitLineNumber(513,L8);
                ddv.visitEndLocal(1,L8);
                DexLabel L33=new DexLabel();
                ddv.visitLineNumber(515,L33);
                DexLabel L34=new DexLabel();
                ddv.visitLineNumber(516,L34);
                ddv.visitRestartLocal(4,L34);
                DexLabel L35=new DexLabel();
                ddv.visitLineNumber(520,L35);
                DexLabel L36=new DexLabel();
                ddv.visitLineNumber(521,L36);
                DexLabel L37=new DexLabel();
                ddv.visitLineNumber(513,L37);
                code.visitLabel(L10);
                code.visitConstStmt(CONST_STRING,9,"javax.servlet.error.servlet_name");
                code.visitLabel(L11);
                code.visitFieldStmt(IGET_OBJECT,5,10,new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_class","Ljava/lang/Class;"));
                code.visitJumpStmt(IF_NEZ,5,-1,L13);
                code.visitLabel(L12);
                code.visitTypeStmt(NEW_INSTANCE,5,-1,"Ljavax/servlet/UnavailableException;");
                code.visitConstStmt(CONST_STRING,6,"Servlet Not Initialized");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 5,6},new Method("Ljavax/servlet/UnavailableException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,5);
                code.visitLabel(L13);
                code.visitFieldStmt(IGET_OBJECT,2,10,new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_servlet","Ljavax/servlet/Servlet;"));
                code.visitLabel(L14);
                code.visitStmt1R(MONITOR_ENTER,10);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_WIDE,5,10,new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_unavailable","J"));
                code.visitConstStmt(CONST_WIDE_16,7,Long.valueOf(0L)); // long: 0x0000000000000000  double:0.000000
                code.visitStmt3R(CMP_LONG,5,5,7);
                code.visitJumpStmt(IF_NEZ,5,-1,L15);
                code.visitFieldStmt(IGET_BOOLEAN,5,10,new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_initOnStartup","Z"));
                code.visitJumpStmt(IF_NEZ,5,-1,L16);
                code.visitLabel(L15);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Lorg/mortbay/jetty/servlet/ServletHolder;","getServlet",new String[]{ },"Ljavax/servlet/Servlet;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L16);
                code.visitJumpStmt(IF_NEZ,2,-1,L3);
                code.visitLabel(L17);
                code.visitTypeStmt(NEW_INSTANCE,5,-1,"Ljavax/servlet/UnavailableException;");
                code.visitTypeStmt(NEW_INSTANCE,6,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 6},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,7,"Could not instantiate ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,7},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitFieldStmt(IGET_OBJECT,7,10,new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_class","Ljava/lang/Class;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,7},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 5,6},new Method("Ljavax/servlet/UnavailableException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,5);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,5);
                code.visitStmt1R(MONITOR_EXIT,10);
                code.visitLabel(L1);
                code.visitStmt1R(THROW,5);
                code.visitLabel(L3);
                code.visitStmt1R(MONITOR_EXIT,10);
                code.visitLabel(L4);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L18);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L19);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,5,10,new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_forcedPath","Ljava/lang/String;"));
                code.visitJumpStmt(IF_EQZ,5,-1,L21);
                code.visitLabel(L20);
                code.visitConstStmt(CONST_STRING,5,"org.apache.catalina.jsp_file");
                code.visitFieldStmt(IGET_OBJECT,6,10,new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_forcedPath","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 11,5,6},new Method("Ljavax/servlet/ServletRequest;","setAttribute",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L21);
                code.visitFieldStmt(IGET_OBJECT,5,10,new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_runAs","Ljava/lang/String;"));
                code.visitJumpStmt(IF_EQZ,5,-1,L25);
                code.visitFieldStmt(IGET_OBJECT,5,10,new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_realm","Lorg/mortbay/jetty/security/UserRealm;"));
                code.visitJumpStmt(IF_EQZ,5,-1,L25);
                code.visitLabel(L22);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/jetty/HttpConnection;","getCurrentConnection",new String[]{ },"Lorg/mortbay/jetty/HttpConnection;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/jetty/HttpConnection;","getRequest",new String[]{ },"Lorg/mortbay/jetty/Request;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L23);
                code.visitFieldStmt(IGET_OBJECT,5,10,new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_realm","Lorg/mortbay/jetty/security/UserRealm;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/Request;","getUserPrincipal",new String[]{ },"Ljava/security/Principal;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitFieldStmt(IGET_OBJECT,7,10,new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_runAs","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 5,6,7},new Method("Lorg/mortbay/jetty/security/UserRealm;","pushRole",new String[]{ "Ljava/security/Principal;","Ljava/lang/String;"},"Ljava/security/Principal;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitLabel(L24);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,4},new Method("Lorg/mortbay/jetty/Request;","setUserPrincipal",new String[]{ "Ljava/security/Principal;"},"V"));
                code.visitLabel(L25);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2,11,12},new Method("Ljavax/servlet/Servlet;","service",new String[]{ "Ljavax/servlet/ServletRequest;","Ljavax/servlet/ServletResponse;"},"V"));
                code.visitLabel(L6);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L26);
                code.visitFieldStmt(IGET_OBJECT,5,10,new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_runAs","Ljava/lang/String;"));
                code.visitJumpStmt(IF_EQZ,5,-1,L29);
                code.visitFieldStmt(IGET_OBJECT,5,10,new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_realm","Lorg/mortbay/jetty/security/UserRealm;"));
                code.visitJumpStmt(IF_EQZ,5,-1,L29);
                code.visitJumpStmt(IF_EQZ,4,-1,L29);
                code.visitJumpStmt(IF_EQZ,0,-1,L29);
                code.visitLabel(L27);
                code.visitFieldStmt(IGET_OBJECT,5,10,new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_realm","Lorg/mortbay/jetty/security/UserRealm;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 5,4},new Method("Lorg/mortbay/jetty/security/UserRealm;","popRole",new String[]{ "Ljava/security/Principal;"},"Ljava/security/Principal;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitLabel(L28);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,4},new Method("Lorg/mortbay/jetty/Request;","setUserPrincipal",new String[]{ "Ljava/security/Principal;"},"V"));
                code.visitLabel(L29);
                code.visitJumpStmt(IF_EQZ,3,-1,L31);
                code.visitLabel(L30);
                code.visitConstStmt(CONST_STRING,5,"javax.servlet.error.servlet_name");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Lorg/mortbay/jetty/servlet/ServletHolder;","getName",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 11,9,5},new Method("Ljavax/servlet/ServletRequest;","setAttribute",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L31);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L7);
                code.visitStmt1R(MOVE_EXCEPTION,5);
                code.visitStmt2R(MOVE_OBJECT,1,5);
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 10,1},new Method("Lorg/mortbay/jetty/servlet/ServletHolder;","makeUnavailable",new String[]{ "Ljavax/servlet/UnavailableException;"},"V"));
                code.visitLabel(L32);
                code.visitFieldStmt(IGET_OBJECT,5,10,new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_unavailableEx","Ljavax/servlet/UnavailableException;"));
                code.visitStmt1R(THROW,5);
                code.visitLabel(L8);
                code.visitStmt1R(MOVE_EXCEPTION,5);
                code.visitFieldStmt(IGET_OBJECT,6,10,new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_runAs","Ljava/lang/String;"));
                code.visitJumpStmt(IF_EQZ,6,-1,L35);
                code.visitFieldStmt(IGET_OBJECT,6,10,new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_realm","Lorg/mortbay/jetty/security/UserRealm;"));
                code.visitJumpStmt(IF_EQZ,6,-1,L35);
                code.visitJumpStmt(IF_EQZ,4,-1,L35);
                code.visitJumpStmt(IF_EQZ,0,-1,L35);
                code.visitLabel(L33);
                code.visitFieldStmt(IGET_OBJECT,6,10,new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_realm","Lorg/mortbay/jetty/security/UserRealm;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 6,4},new Method("Lorg/mortbay/jetty/security/UserRealm;","popRole",new String[]{ "Ljava/security/Principal;"},"Ljava/security/Principal;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitLabel(L34);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,4},new Method("Lorg/mortbay/jetty/Request;","setUserPrincipal",new String[]{ "Ljava/security/Principal;"},"V"));
                code.visitLabel(L35);
                code.visitJumpStmt(IF_EQZ,3,-1,L37);
                code.visitLabel(L36);
                code.visitConstStmt(CONST_STRING,6,"javax.servlet.error.servlet_name");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Lorg/mortbay/jetty/servlet/ServletHolder;","getName",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 11,9,6},new Method("Ljavax/servlet/ServletRequest;","setAttribute",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L37);
                code.visitStmt1R(THROW,5);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m021_hashCode(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/ServletHolder;","hashCode",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(164,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_name","Ljava/lang/String;"));
                DexLabel L1=new DexLabel();
                code.visitJumpStmt(IF_NEZ,0,-1,L1);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1},new Method("Ljava/lang/System;","identityHashCode",new String[]{ "Ljava/lang/Object;"},"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                DexLabel L2=new DexLabel();
                code.visitLabel(L2);
                code.visitStmt1R(RETURN,0);
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_name","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/String;","hashCode",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m022_isAvailable(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/ServletHolder;","isAvailable",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/lang/Exception;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(363,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(374,L5);
                ddv.visitLineNumber(367,L0);
                ddv.visitLineNumber(374,L1);
                ddv.visitLineNumber(369,L2);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(371,L6);
                ddv.visitStartLocal(0,L6,"e","Ljava/lang/Exception;",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(374,L7);
                ddv.visitEndLocal(0,L7);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_WIDE_16,4,Long.valueOf(0L)); // long: 0x0000000000000000  double:0.000000
                code.visitConstStmt(CONST_4,3, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/servlet/ServletHolder;","isStarted",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_EQZ,1,-1,L0);
                code.visitFieldStmt(IGET_WIDE,1,6,new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_unavailable","J"));
                code.visitStmt3R(CMP_LONG,1,1,4);
                code.visitJumpStmt(IF_NEZ,1,-1,L0);
                code.visitStmt2R(MOVE,1,3);
                code.visitLabel(L5);
                code.visitStmt1R(RETURN,1);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/servlet/ServletHolder;","getServlet",new String[]{ },"Ljavax/servlet/Servlet;"));
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/servlet/ServletHolder;","isStarted",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_EQZ,1,-1,L7);
                code.visitFieldStmt(IGET_WIDE,1,6,new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_unavailable","J"));
                code.visitStmt3R(CMP_LONG,1,1,4);
                code.visitJumpStmt(IF_NEZ,1,-1,L7);
                code.visitStmt2R(MOVE,1,3);
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,0);
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/log/Log;","ignore",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitLabel(L7);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m023_setForcedPath(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/ServletHolder;","setForcedPath",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"forcedPath");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(232,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(233,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_forcedPath","Ljava/lang/String;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m024_setInitOrder(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/ServletHolder;","setInitOrder",new String[]{ "I"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"order");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(126,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(127,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(128,L2);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitFieldStmt(IPUT_BOOLEAN,0,1,new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_initOnStartup","Z"));
                code.visitLabel(L1);
                code.visitFieldStmt(IPUT,2,1,new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_initOrder","I"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m025_setRunAs(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/ServletHolder;","setRunAs",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"role");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(208,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(209,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_runAs","Ljava/lang/String;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m026_setServlet(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/ServletHolder;","setServlet",new String[]{ "Ljavax/servlet/Servlet;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L1},new String[]{ null});
                DexLabel L2=new DexLabel();
                DexLabel L3=new DexLabel();
                code.visitTryCatch(L2,L3,new DexLabel[]{L1},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"servlet");
                DexLabel L4=new DexLabel();
                ddv.visitPrologue(L4);
                ddv.visitLineNumber(102,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(103,L5);
                ddv.visitLineNumber(102,L1);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(105,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(106,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(107,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(108,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(109,L10);
                ddv.visitLineNumber(110,L3);
                code.visitLabel(L4);
                code.visitStmt1R(MONITOR_ENTER,2);
                code.visitJumpStmt(IF_EQZ,3,-1,L5);
                code.visitLabel(L0);
                code.visitTypeStmt(INSTANCE_OF,0,3,"Ljavax/servlet/SingleThreadModel;");
                code.visitJumpStmt(IF_EQZ,0,-1,L6);
                code.visitLabel(L5);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/IllegalArgumentException;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/IllegalArgumentException;","<init>",new String[]{ },"V"));
                code.visitStmt1R(THROW,0);
                code.visitLabel(L1);
                code.visitStmt1R(MOVE_EXCEPTION,0);
                code.visitStmt1R(MONITOR_EXIT,2);
                code.visitStmt1R(THROW,0);
                code.visitLabel(L6);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L2);
                code.visitFieldStmt(IPUT_BOOLEAN,0,2,new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_extInstance","Z"));
                code.visitLabel(L7);
                code.visitFieldStmt(IPUT_OBJECT,3,2,new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_servlet","Ljavax/servlet/Servlet;"));
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/lang/Object;","getClass",new String[]{ },"Ljava/lang/Class;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,0},new Method("Lorg/mortbay/jetty/servlet/ServletHolder;","setHeldClass",new String[]{ "Ljava/lang/Class;"},"V"));
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/servlet/ServletHolder;","getName",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitJumpStmt(IF_NEZ,0,-1,L3);
                code.visitLabel(L10);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/lang/Object;","getClass",new String[]{ },"Ljava/lang/Class;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/lang/Class;","getName",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitConstStmt(CONST_STRING,1,"-");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 2},new Method("Ljava/lang/Object;","hashCode",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "I"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,0},new Method("Lorg/mortbay/jetty/servlet/ServletHolder;","setName",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L3);
                code.visitStmt1R(MONITOR_EXIT,2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m027_setUserRoleLink(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/ServletHolder;","setUserRoleLink",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                ddv.visitParameterName(1,"link");
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(176,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(177,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(178,L5);
                ddv.visitLineNumber(179,L1);
                ddv.visitLineNumber(176,L2);
                code.visitLabel(L3);
                code.visitStmt1R(MONITOR_ENTER,1);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_roleMap","Ljava/util/Map;"));
                code.visitJumpStmt(IF_NEZ,0,-1,L5);
                code.visitLabel(L4);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/util/HashMap;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/util/HashMap;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_roleMap","Ljava/util/Map;"));
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/servlet/ServletHolder;","_roleMap","Ljava/util/Map;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,2,3},new Method("Ljava/util/Map;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L1);
                code.visitStmt1R(MONITOR_EXIT,1);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,0);
                code.visitStmt1R(MONITOR_EXIT,1);
                code.visitStmt1R(THROW,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
