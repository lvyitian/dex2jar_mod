package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0151_org_mortbay_jetty_HttpConnection_Output {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/jetty/HttpConnection$Output;","Lorg/mortbay/jetty/AbstractGenerator$Output;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("HttpConnection.java");
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/EnclosingClass;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("value", new DexType("Lorg/mortbay/jetty/HttpConnection;"));
                av00.visitEnd();
            }
        }
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/InnerClass;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("accessFlags",  Integer.valueOf(1));
                av00.visit("name", "Output");
                av00.visitEnd();
            }
        }
        f000_this$0(cv);
        m000__init_(cv);
        m001_close(cv);
        m002_flush(cv);
        m003_print(cv);
        m004_sendContent(cv);
        m005_sendResponse(cv);
    }
    public static void f000_this$0(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_FINAL|ACC_SYNTHETIC, new Field("Lorg/mortbay/jetty/HttpConnection$Output;","this$0","Lorg/mortbay/jetty/HttpConnection;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/HttpConnection$Output;","<init>",new String[]{ "Lorg/mortbay/jetty/HttpConnection;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(918,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(919,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(920,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,4,3,new Field("Lorg/mortbay/jetty/HttpConnection$Output;","this$0","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/jetty/HttpConnection;","_generator","Lorg/mortbay/jetty/Generator;"));
                code.visitTypeStmt(CHECK_CAST,0,-1,"Lorg/mortbay/jetty/AbstractGenerator;");
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/jetty/HttpConnection;","_connector","Lorg/mortbay/jetty/Connector;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Lorg/mortbay/jetty/Connector;","getMaxIdleTime",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitStmt2R(INT_TO_LONG,1,1);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3,0,1,2},new Method("Lorg/mortbay/jetty/AbstractGenerator$Output;","<init>",new String[]{ "Lorg/mortbay/jetty/AbstractGenerator;","J"},"V"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001_close(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpConnection$Output;","close",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(928,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(937,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(931,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(932,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(936,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(934,L5);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_BOOLEAN,0,2,new Field("Lorg/mortbay/jetty/HttpConnection$Output;","_closed","Z"));
                code.visitJumpStmt(IF_EQZ,0,-1,L2);
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/HttpConnection$Output;","this$0","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/HttpConnection;","isIncluding",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_NEZ,0,-1,L5);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/HttpConnection$Output;","_generator","Lorg/mortbay/jetty/AbstractGenerator;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/AbstractGenerator;","isCommitted",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_NEZ,0,-1,L5);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/HttpConnection$Output;","this$0","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitConstStmt(CONST_4,1, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/HttpConnection;","commitResponse",new String[]{ "Z"},"V"));
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 2},new Method("Lorg/mortbay/jetty/AbstractGenerator$Output;","close",new String[]{ },"V"));
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/HttpConnection$Output;","this$0","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/HttpConnection;","flushResponse",new String[]{ },"V"));
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_flush(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpConnection$Output;","flush",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(945,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(946,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(947,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(948,L3);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/HttpConnection$Output;","_generator","Lorg/mortbay/jetty/AbstractGenerator;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/AbstractGenerator;","isCommitted",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_NEZ,0,-1,L2);
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/HttpConnection$Output;","this$0","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/HttpConnection;","commitResponse",new String[]{ "Z"},"V"));
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 2},new Method("Lorg/mortbay/jetty/AbstractGenerator$Output;","flush",new String[]{ },"V"));
                code.visitLabel(L3);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_print(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpConnection$Output;","print",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"s");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(956,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(957,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(958,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(959,L3);
                ddv.visitStartLocal(0,L3,"writer","Ljava/io/PrintWriter;",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(960,L4);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_BOOLEAN,1,3,new Field("Lorg/mortbay/jetty/HttpConnection$Output;","_closed","Z"));
                code.visitJumpStmt(IF_EQZ,1,-1,L2);
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/io/IOException;");
                code.visitConstStmt(CONST_STRING,2,"Closed");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,2},new Method("Ljava/io/IOException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,1);
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/jetty/HttpConnection$Output;","this$0","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Lorg/mortbay/jetty/HttpConnection;","getPrintWriter",new String[]{ "Ljava/lang/String;"},"Ljava/io/PrintWriter;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,4},new Method("Ljava/io/PrintWriter;","print",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L4);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_sendContent(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpConnection$Output;","sendContent",new String[]{ "Ljava/lang/Object;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(23);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"content");
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(971,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(973,L4);
                ddv.visitStartLocal(16,L4,"resource","Lorg/mortbay/resource/Resource;",null);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(974,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(976,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(977,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(979,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(981,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(982,L10);
                ddv.visitStartLocal(6,L10,"c","Lorg/mortbay/jetty/HttpContent;",null);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(983,L11);
                ddv.visitStartLocal(7,L11,"contentType","Lorg/mortbay/io/Buffer;",null);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(985,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(986,L13);
                ddv.visitStartLocal(9,L13,"enc","Ljava/lang/String;",null);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(987,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(1008,L15);
                ddv.visitEndLocal(9,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(1009,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(1010,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(1011,L18);
                ddv.visitStartLocal(12,L18,"lm","Lorg/mortbay/io/Buffer;",null);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(1012,L19);
                ddv.visitStartLocal(13,L19,"lml","J",null);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(1013,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(1020,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(1021,L22);
                ddv.visitStartLocal(22,L22,"content","Lorg/mortbay/io/Buffer;",null);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(1022,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(1031,L24);
                ddv.visitEndLocal(6,L24);
                ddv.visitEndLocal(7,L24);
                ddv.visitEndLocal(12,L24);
                ddv.visitEndLocal(13,L24);
                ddv.visitEndLocal(22,L24);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(1033,L25);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(1034,L26);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(1071,L27);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(990,L28);
                ddv.visitRestartLocal(6,L28);
                ddv.visitRestartLocal(7,L28);
                ddv.visitRestartLocal(9,L28);
                ddv.visitStartLocal(22,L28,"content","Ljava/lang/Object;",null);
                DexLabel L29=new DexLabel();
                ddv.visitLineNumber(992,L29);
                DexLabel L30=new DexLabel();
                ddv.visitLineNumber(993,L30);
                ddv.visitStartLocal(8,L30,"content_type","Lorg/mortbay/io/BufferCache$CachedBuffer;",null);
                DexLabel L31=new DexLabel();
                ddv.visitLineNumber(994,L31);
                DexLabel L32=new DexLabel();
                ddv.visitLineNumber(997,L32);
                DexLabel L33=new DexLabel();
                ddv.visitLineNumber(1003,L33);
                ddv.visitEndLocal(8,L33);
                DexLabel L34=new DexLabel();
                ddv.visitLineNumber(1014,L34);
                ddv.visitEndLocal(9,L34);
                ddv.visitRestartLocal(12,L34);
                ddv.visitRestartLocal(13,L34);
                DexLabel L35=new DexLabel();
                ddv.visitLineNumber(1016,L35);
                DexLabel L36=new DexLabel();
                ddv.visitLineNumber(1017,L36);
                DexLabel L37=new DexLabel();
                ddv.visitLineNumber(1024,L37);
                ddv.visitEndLocal(6,L37);
                ddv.visitEndLocal(7,L37);
                ddv.visitEndLocal(12,L37);
                ddv.visitEndLocal(13,L37);
                DexLabel L38=new DexLabel();
                ddv.visitLineNumber(1026,L38);
                DexLabel L39=new DexLabel();
                ddv.visitLineNumber(1027,L39);
                DexLabel L40=new DexLabel();
                ddv.visitLineNumber(1028,L40);
                DexLabel L41=new DexLabel();
                ddv.visitStartLocal(22,L41,"content","Ljava/io/InputStream;",null);
                DexLabel L42=new DexLabel();
                ddv.visitLineNumber(1036,L42);
                ddv.visitEndLocal(22,L42);
                DexLabel L43=new DexLabel();
                ddv.visitLineNumber(1038,L43);
                ddv.visitLineNumber(1042,L0);
                ddv.visitStartLocal(10,L0,"in","Ljava/io/InputStream;",null);
                DexLabel L44=new DexLabel();
                ddv.visitLineNumber(1043,L44);
                ddv.visitStartLocal(15,L44,"max","I",null);
                DexLabel L45=new DexLabel();
                ddv.visitLineNumber(1045,L45);
                ddv.visitStartLocal(5,L45,"buffer","Lorg/mortbay/io/Buffer;",null);
                DexLabel L46=new DexLabel();
                ddv.visitLineNumber(1047,L46);
                ddv.visitStartLocal(11,L46,"len","I",null);
                DexLabel L47=new DexLabel();
                ddv.visitLineNumber(1049,L47);
                DexLabel L48=new DexLabel();
                ddv.visitLineNumber(1050,L48);
                DexLabel L49=new DexLabel();
                ddv.visitLineNumber(1052,L49);
                DexLabel L50=new DexLabel();
                ddv.visitLineNumber(1053,L50);
                DexLabel L51=new DexLabel();
                ddv.visitLineNumber(1054,L51);
                DexLabel L52=new DexLabel();
                ddv.visitLineNumber(1056,L52);
                DexLabel L53=new DexLabel();
                ddv.visitLineNumber(1057,L53);
                ddv.visitLineNumber(1061,L1);
                DexLabel L54=new DexLabel();
                ddv.visitLineNumber(1062,L54);
                DexLabel L55=new DexLabel();
                ddv.visitLineNumber(1064,L55);
                ddv.visitLineNumber(1061,L2);
                ddv.visitEndLocal(15,L2);
                ddv.visitEndLocal(5,L2);
                ddv.visitEndLocal(11,L2);
                DexLabel L56=new DexLabel();
                ddv.visitLineNumber(1062,L56);
                DexLabel L57=new DexLabel();
                ddv.visitLineNumber(1064,L57);
                DexLabel L58=new DexLabel();
                ddv.visitLineNumber(1069,L58);
                ddv.visitEndLocal(10,L58);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_16,16, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L4);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitFieldStmt(IGET_BOOLEAN,0,0,new Field("Lorg/mortbay/jetty/HttpConnection$Output;","_closed","Z"));
                code.visitStmt2R(MOVE_FROM16,17,0);
                code.visitJumpStmt(IF_EQZ,17,-1,L6);
                code.visitLabel(L5);
                code.visitTypeStmt(NEW_INSTANCE,17,-1,"Ljava/io/IOException;");
                code.visitConstStmt(CONST_STRING,18,"Closed");
                code.visitMethodStmt(INVOKE_DIRECT_RANGE,new int[]{ 17,18},new Method("Ljava/io/IOException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,17);
                code.visitLabel(L6);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpConnection$Output;","_generator","Lorg/mortbay/jetty/AbstractGenerator;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,17,0);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 17},new Method("Lorg/mortbay/jetty/AbstractGenerator;","getContentWritten",new String[]{ },"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,17);
                code.visitConstStmt(CONST_WIDE_16,19,Long.valueOf(0L)); // long: 0x0000000000000000  double:0.000000
                code.visitStmt3R(CMP_LONG,17,17,19);
                code.visitJumpStmt(IF_LEZ,17,-1,L8);
                code.visitLabel(L7);
                code.visitTypeStmt(NEW_INSTANCE,17,-1,"Ljava/lang/IllegalStateException;");
                code.visitConstStmt(CONST_STRING,18,"!empty");
                code.visitMethodStmt(INVOKE_DIRECT_RANGE,new int[]{ 17,18},new Method("Ljava/lang/IllegalStateException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,17);
                code.visitLabel(L8);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,22);
                code.visitTypeStmt(INSTANCE_OF,0,0,"Lorg/mortbay/jetty/HttpContent;");
                code.visitStmt2R(MOVE_FROM16,17,0);
                code.visitJumpStmt(IF_EQZ,17,-1,L37);
                code.visitLabel(L9);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,22);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Lorg/mortbay/jetty/HttpContent;");
                code.visitStmt2R(MOVE_OBJECT,6,0);
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 6},new Method("Lorg/mortbay/jetty/HttpContent;","getContentType",new String[]{ },"Lorg/mortbay/io/Buffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitLabel(L11);
                code.visitJumpStmt(IF_EQZ,7,-1,L15);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpConnection$Output;","this$0","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,17,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,17);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpConnection;","_responseFields","Lorg/mortbay/jetty/HttpFields;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,17,0);
                code.visitFieldStmt(SGET_OBJECT,18,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","CONTENT_TYPE_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 17,18},new Method("Lorg/mortbay/jetty/HttpFields;","containsKey",new String[]{ "Lorg/mortbay/io/Buffer;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,17);
                code.visitJumpStmt(IF_NEZ,17,-1,L15);
                code.visitLabel(L12);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpConnection$Output;","this$0","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,17,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,17);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpConnection;","_response","Lorg/mortbay/jetty/Response;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,17,0);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 17},new Method("Lorg/mortbay/jetty/Response;","getSetCharacterEncoding",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitLabel(L13);
                code.visitJumpStmt(IF_NEZ,9,-1,L28);
                code.visitLabel(L14);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpConnection$Output;","this$0","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,17,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,17);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpConnection;","_responseFields","Lorg/mortbay/jetty/HttpFields;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,17,0);
                code.visitFieldStmt(SGET_OBJECT,18,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","CONTENT_TYPE_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,17);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,18);
                code.visitStmt2R(MOVE_OBJECT,2,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Lorg/mortbay/jetty/HttpFields;","add",new String[]{ "Lorg/mortbay/io/Buffer;","Lorg/mortbay/io/Buffer;"},"V"));
                code.visitLabel(L15);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 6},new Method("Lorg/mortbay/jetty/HttpContent;","getContentLength",new String[]{ },"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,17);
                code.visitConstStmt(CONST_WIDE_16,19,Long.valueOf(0L)); // long: 0x0000000000000000  double:0.000000
                code.visitStmt3R(CMP_LONG,17,17,19);
                code.visitJumpStmt(IF_LEZ,17,-1,L17);
                code.visitLabel(L16);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpConnection$Output;","this$0","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,17,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,17);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpConnection;","_responseFields","Lorg/mortbay/jetty/HttpFields;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,17,0);
                code.visitFieldStmt(SGET_OBJECT,18,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","CONTENT_LENGTH_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 6},new Method("Lorg/mortbay/jetty/HttpContent;","getContentLength",new String[]{ },"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,19);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 17,18,19,20},new Method("Lorg/mortbay/jetty/HttpFields;","putLongField",new String[]{ "Lorg/mortbay/io/Buffer;","J"},"V"));
                code.visitLabel(L17);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 6},new Method("Lorg/mortbay/jetty/HttpContent;","getLastModified",new String[]{ },"Lorg/mortbay/io/Buffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,12);
                code.visitLabel(L18);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 6},new Method("Lorg/mortbay/jetty/HttpContent;","getResource",new String[]{ },"Lorg/mortbay/resource/Resource;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,17);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 17},new Method("Lorg/mortbay/resource/Resource;","lastModified",new String[]{ },"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,13);
                code.visitLabel(L19);
                code.visitJumpStmt(IF_EQZ,12,-1,L34);
                code.visitLabel(L20);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpConnection$Output;","this$0","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,17,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,17);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpConnection;","_responseFields","Lorg/mortbay/jetty/HttpFields;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,17,0);
                code.visitFieldStmt(SGET_OBJECT,18,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","LAST_MODIFIED_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,17);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,18);
                code.visitStmt2R(MOVE_OBJECT,2,12);
                code.visitStmt2R(MOVE_WIDE,3,13);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2,3,4},new Method("Lorg/mortbay/jetty/HttpFields;","put",new String[]{ "Lorg/mortbay/io/Buffer;","Lorg/mortbay/io/Buffer;","J"},"V"));
                code.visitLabel(L21);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 6},new Method("Lorg/mortbay/jetty/HttpContent;","getBuffer",new String[]{ },"Lorg/mortbay/io/Buffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,22);
                code.visitLabel(L22);
                code.visitJumpStmt(IF_NEZ,22,-1,L24);
                code.visitLabel(L23);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 6},new Method("Lorg/mortbay/jetty/HttpContent;","getInputStream",new String[]{ },"Ljava/io/InputStream;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,22);
                code.visitLabel(L24);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,22);
                code.visitTypeStmt(INSTANCE_OF,0,0,"Lorg/mortbay/io/Buffer;");
                code.visitStmt2R(MOVE_FROM16,17,0);
                code.visitJumpStmt(IF_EQZ,17,-1,L42);
                code.visitLabel(L25);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpConnection$Output;","_generator","Lorg/mortbay/jetty/AbstractGenerator;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,17,0);
                code.visitTypeStmt(CHECK_CAST,22,-1,"Lorg/mortbay/io/Buffer;");
                code.visitConstStmt(CONST_16,18, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,17);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,22);
                code.visitStmt2R(MOVE_FROM16,2,18);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Lorg/mortbay/jetty/AbstractGenerator;","addContent",new String[]{ "Lorg/mortbay/io/Buffer;","Z"},"V"));
                code.visitLabel(L26);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpConnection$Output;","this$0","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,17,0);
                code.visitConstStmt(CONST_16,18, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 17,18},new Method("Lorg/mortbay/jetty/HttpConnection;","commitResponse",new String[]{ "Z"},"V"));
                code.visitLabel(L27);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L28);
                code.visitStmt2R(MOVE_OBJECT,0,7);
                code.visitTypeStmt(INSTANCE_OF,0,0,"Lorg/mortbay/io/BufferCache$CachedBuffer;");
                code.visitStmt2R(MOVE_FROM16,17,0);
                code.visitJumpStmt(IF_EQZ,17,-1,L33);
                code.visitLabel(L29);
                code.visitStmt2R(MOVE_OBJECT,0,7);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Lorg/mortbay/io/BufferCache$CachedBuffer;");
                code.visitStmt2R(MOVE_OBJECT,8,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,9},new Method("Lorg/mortbay/io/BufferCache$CachedBuffer;","getAssociate",new String[]{ "Ljava/lang/Object;"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitLabel(L30);
                code.visitJumpStmt(IF_EQZ,8,-1,L32);
                code.visitLabel(L31);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpConnection$Output;","this$0","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,17,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,17);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpConnection;","_responseFields","Lorg/mortbay/jetty/HttpFields;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,17,0);
                code.visitFieldStmt(SGET_OBJECT,18,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","CONTENT_TYPE_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,17);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,18);
                code.visitStmt2R(MOVE_OBJECT,2,8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Lorg/mortbay/jetty/HttpFields;","put",new String[]{ "Lorg/mortbay/io/Buffer;","Lorg/mortbay/io/Buffer;"},"V"));
                code.visitJumpStmt(GOTO_16,-1,-1,L15);
                code.visitLabel(L32);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpConnection$Output;","this$0","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,17,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,17);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpConnection;","_responseFields","Lorg/mortbay/jetty/HttpFields;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,17,0);
                code.visitFieldStmt(SGET_OBJECT,18,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","CONTENT_TYPE_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitTypeStmt(NEW_INSTANCE,19,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT_RANGE,new int[]{ 19},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,19);
                code.visitStmt2R(MOVE_OBJECT,1,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,19);
                code.visitConstStmt(CONST_STRING,20,";charset=");
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 19,20},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,19);
                code.visitConstStmt(CONST_STRING,20,";= ");
                code.visitStmt2R(MOVE_OBJECT,0,9);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,20);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,1},new Method("Lorg/mortbay/util/QuotedStringTokenizer;","quote",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,20);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 19,20},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,19);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 19},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,19);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 17,18,19},new Method("Lorg/mortbay/jetty/HttpFields;","put",new String[]{ "Lorg/mortbay/io/Buffer;","Ljava/lang/String;"},"V"));
                code.visitJumpStmt(GOTO_16,-1,-1,L15);
                code.visitLabel(L33);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpConnection$Output;","this$0","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,17,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,17);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpConnection;","_responseFields","Lorg/mortbay/jetty/HttpFields;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,17,0);
                code.visitFieldStmt(SGET_OBJECT,18,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","CONTENT_TYPE_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitTypeStmt(NEW_INSTANCE,19,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT_RANGE,new int[]{ 19},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,19);
                code.visitStmt2R(MOVE_OBJECT,1,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,19);
                code.visitConstStmt(CONST_STRING,20,";charset=");
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 19,20},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,19);
                code.visitConstStmt(CONST_STRING,20,";= ");
                code.visitStmt2R(MOVE_OBJECT,0,9);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,20);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,1},new Method("Lorg/mortbay/util/QuotedStringTokenizer;","quote",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,20);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 19,20},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,19);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 19},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,19);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 17,18,19},new Method("Lorg/mortbay/jetty/HttpFields;","put",new String[]{ "Lorg/mortbay/io/Buffer;","Ljava/lang/String;"},"V"));
                code.visitJumpStmt(GOTO_16,-1,-1,L15);
                code.visitLabel(L34);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 6},new Method("Lorg/mortbay/jetty/HttpContent;","getResource",new String[]{ },"Lorg/mortbay/resource/Resource;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,17);
                code.visitJumpStmt(IF_EQZ,17,-1,L21);
                code.visitLabel(L35);
                code.visitConstStmt(CONST_WIDE_16,17,Long.valueOf(-1L)); // long: 0xffffffffffffffff  double:NaN
                code.visitStmt3R(CMP_LONG,17,13,17);
                code.visitJumpStmt(IF_EQZ,17,-1,L21);
                code.visitLabel(L36);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpConnection$Output;","this$0","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,17,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,17);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpConnection;","_responseFields","Lorg/mortbay/jetty/HttpFields;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,17,0);
                code.visitFieldStmt(SGET_OBJECT,18,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","LAST_MODIFIED_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,17);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,18);
                code.visitStmt2R(MOVE_WIDE,2,13);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2,3},new Method("Lorg/mortbay/jetty/HttpFields;","putDateField",new String[]{ "Lorg/mortbay/io/Buffer;","J"},"V"));
                code.visitJumpStmt(GOTO_16,-1,-1,L21);
                code.visitLabel(L37);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,22);
                code.visitTypeStmt(INSTANCE_OF,0,0,"Lorg/mortbay/resource/Resource;");
                code.visitStmt2R(MOVE_FROM16,17,0);
                code.visitJumpStmt(IF_EQZ,17,-1,L24);
                code.visitLabel(L38);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,22);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Lorg/mortbay/resource/Resource;");
                code.visitStmt2R(MOVE_OBJECT_FROM16,16,0);
                code.visitLabel(L39);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpConnection$Output;","this$0","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,17,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,17);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpConnection;","_responseFields","Lorg/mortbay/jetty/HttpFields;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,17,0);
                code.visitFieldStmt(SGET_OBJECT,18,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","LAST_MODIFIED_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 16},new Method("Lorg/mortbay/resource/Resource;","lastModified",new String[]{ },"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,19);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 17,18,19,20},new Method("Lorg/mortbay/jetty/HttpFields;","putDateField",new String[]{ "Lorg/mortbay/io/Buffer;","J"},"V"));
                code.visitLabel(L40);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 16},new Method("Lorg/mortbay/resource/Resource;","getInputStream",new String[]{ },"Ljava/io/InputStream;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,22);
                code.visitLabel(L41);
                code.visitJumpStmt(GOTO_16,-1,-1,L24);
                code.visitLabel(L42);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,22);
                code.visitTypeStmt(INSTANCE_OF,0,0,"Ljava/io/InputStream;");
                code.visitStmt2R(MOVE_FROM16,17,0);
                code.visitJumpStmt(IF_EQZ,17,-1,L58);
                code.visitLabel(L43);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,22);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Ljava/io/InputStream;");
                code.visitStmt2R(MOVE_OBJECT,10,0);
                code.visitLabel(L0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpConnection$Output;","_generator","Lorg/mortbay/jetty/AbstractGenerator;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,17,0);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 17},new Method("Lorg/mortbay/jetty/AbstractGenerator;","prepareUncheckedAddContent",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,15);
                code.visitLabel(L44);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpConnection$Output;","_generator","Lorg/mortbay/jetty/AbstractGenerator;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,17,0);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 17},new Method("Lorg/mortbay/jetty/AbstractGenerator;","getUncheckedBuffer",new String[]{ },"Lorg/mortbay/io/Buffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitLabel(L45);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 5,10,15},new Method("Lorg/mortbay/io/Buffer;","readFrom",new String[]{ "Ljava/io/InputStream;","I"},"I"));
                code.visitStmt1R(MOVE_RESULT,11);
                code.visitLabel(L46);
                code.visitJumpStmt(IF_LTZ,11,-1,L52);
                code.visitLabel(L47);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpConnection$Output;","_generator","Lorg/mortbay/jetty/AbstractGenerator;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,17,0);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 17},new Method("Lorg/mortbay/jetty/AbstractGenerator;","completeUncheckedAddContent",new String[]{ },"V"));
                code.visitLabel(L48);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpConnection$Output;","this$0","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,17,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,17);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpConnection;","_out","Lorg/mortbay/jetty/HttpConnection$Output;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,17,0);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 17},new Method("Lorg/mortbay/jetty/HttpConnection$Output;","flush",new String[]{ },"V"));
                code.visitLabel(L49);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpConnection$Output;","_generator","Lorg/mortbay/jetty/AbstractGenerator;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,17,0);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 17},new Method("Lorg/mortbay/jetty/AbstractGenerator;","prepareUncheckedAddContent",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,15);
                code.visitLabel(L50);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpConnection$Output;","_generator","Lorg/mortbay/jetty/AbstractGenerator;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,17,0);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 17},new Method("Lorg/mortbay/jetty/AbstractGenerator;","getUncheckedBuffer",new String[]{ },"Lorg/mortbay/io/Buffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitLabel(L51);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 5,10,15},new Method("Lorg/mortbay/io/Buffer;","readFrom",new String[]{ "Ljava/io/InputStream;","I"},"I"));
                code.visitStmt1R(MOVE_RESULT,11);
                code.visitJumpStmt(GOTO,-1,-1,L46);
                code.visitLabel(L52);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpConnection$Output;","_generator","Lorg/mortbay/jetty/AbstractGenerator;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,17,0);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 17},new Method("Lorg/mortbay/jetty/AbstractGenerator;","completeUncheckedAddContent",new String[]{ },"V"));
                code.visitLabel(L53);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpConnection$Output;","this$0","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,17,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,17);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpConnection;","_out","Lorg/mortbay/jetty/HttpConnection$Output;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,17,0);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 17},new Method("Lorg/mortbay/jetty/HttpConnection$Output;","flush",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitJumpStmt(IF_EQZ,16,-1,L55);
                code.visitLabel(L54);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 16},new Method("Lorg/mortbay/resource/Resource;","release",new String[]{ },"V"));
                code.visitJumpStmt(GOTO_16,-1,-1,L27);
                code.visitLabel(L55);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Ljava/io/InputStream;","close",new String[]{ },"V"));
                code.visitJumpStmt(GOTO_16,-1,-1,L27);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,17);
                DexLabel L59=new DexLabel();
                code.visitJumpStmt(IF_EQZ,16,-1,L59);
                code.visitLabel(L56);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 16},new Method("Lorg/mortbay/resource/Resource;","release",new String[]{ },"V"));
                code.visitLabel(L57);
                code.visitStmt1R(THROW,17);
                code.visitLabel(L59);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Ljava/io/InputStream;","close",new String[]{ },"V"));
                code.visitJumpStmt(GOTO,-1,-1,L57);
                code.visitLabel(L58);
                code.visitTypeStmt(NEW_INSTANCE,17,-1,"Ljava/lang/IllegalArgumentException;");
                code.visitConstStmt(CONST_STRING,18,"unknown content type?");
                code.visitMethodStmt(INVOKE_DIRECT_RANGE,new int[]{ 17,18},new Method("Ljava/lang/IllegalArgumentException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,17);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_sendResponse(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpConnection$Output;","sendResponse",new String[]{ "Lorg/mortbay/io/Buffer;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"response");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(965,L0);
                DexLabel L1=new DexLabel();
                ddv.visitEndLocal(0,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(966,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpConnection$Output;","_generator","Lorg/mortbay/jetty/AbstractGenerator;"));
                code.visitLabel(L1);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Lorg/mortbay/jetty/HttpGenerator;");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/HttpGenerator;","sendResponse",new String[]{ "Lorg/mortbay/io/Buffer;"},"V"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
