package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0286_org_mortbay_jetty_security_SSORealm {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC|ACC_INTERFACE|ACC_ABSTRACT,"Lorg/mortbay/jetty/security/SSORealm;","Ljava/lang/Object;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("SSORealm.java");
        m000_clearSingleSignOn(cv);
        m001_getSingleSignOn(cv);
        m002_setSingleSignOn(cv);
    }
    public static void m000_clearSingleSignOn(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/jetty/security/SSORealm;","clearSingleSignOn",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m001_getSingleSignOn(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/jetty/security/SSORealm;","getSingleSignOn",new String[]{ "Lorg/mortbay/jetty/Request;","Lorg/mortbay/jetty/Response;"},"Lorg/mortbay/jetty/security/Credential;"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m002_setSingleSignOn(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/jetty/security/SSORealm;","setSingleSignOn",new String[]{ "Lorg/mortbay/jetty/Request;","Lorg/mortbay/jetty/Response;","Ljava/security/Principal;","Lorg/mortbay/jetty/security/Credential;"},"V"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
}
