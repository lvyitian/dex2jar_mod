package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0132_org_mortbay_io_nio_SelectChannelEndPoint {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/io/nio/SelectChannelEndPoint;","Lorg/mortbay/io/nio/ChannelEndPoint;",new String[]{ "Ljava/lang/Runnable;"});
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("SelectChannelEndPoint.java");
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/MemberClasses;", Visibility.SYSTEM);
            if(av00 != null) {
                {
                    DexAnnotationVisitor av01 = av00.visitArray("value");
                    if(av01 != null) {
                        av01.visit(null, new DexType("Lorg/mortbay/io/nio/SelectChannelEndPoint$IdleTask;"));
                        av01.visitEnd();
                    }
                }
                av00.visitEnd();
            }
        }
        f000__connection(cv);
        f001__dispatched(cv);
        f002__interestOps(cv);
        f003__key(cv);
        f004__manager(cv);
        f005__readBlocked(cv);
        f006__selectSet(cv);
        f007__timeoutTask(cv);
        f008__writable(cv);
        f009__writeBlocked(cv);
        m000__init_(cv);
        m001_updateKey(cv);
        m002_blockReadable(cv);
        m003_blockWritable(cv);
        m004_cancelIdle(cv);
        m005_close(cv);
        m006_dispatch(cv);
        m007_dispatch(cv);
        m008_doUpdateKey(cv);
        m009_flush(cv);
        m010_flush(cv);
        m011_getConnection(cv);
        m012_getSelectSet(cv);
        m013_getTimeoutTask(cv);
        m014_idleExpired(cv);
        m015_run(cv);
        m016_scheduleIdle(cv);
        m017_scheduleWrite(cv);
        m018_setWritable(cv);
        m019_toString(cv);
        m020_undispatch(cv);
    }
    public static void f000__connection(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/io/nio/SelectChannelEndPoint;","_connection","Lorg/mortbay/io/Connection;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001__dispatched(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/io/nio/SelectChannelEndPoint;","_dispatched","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002__interestOps(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/io/nio/SelectChannelEndPoint;","_interestOps","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003__key(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/io/nio/SelectChannelEndPoint;","_key","Ljava/nio/channels/SelectionKey;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f004__manager(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/io/nio/SelectChannelEndPoint;","_manager","Lorg/mortbay/io/nio/SelectorManager;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f005__readBlocked(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/io/nio/SelectChannelEndPoint;","_readBlocked","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f006__selectSet(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/io/nio/SelectChannelEndPoint;","_selectSet","Lorg/mortbay/io/nio/SelectorManager$SelectSet;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f007__timeoutTask(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/io/nio/SelectChannelEndPoint;","_timeoutTask","Lorg/mortbay/thread/Timeout$Task;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f008__writable(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/io/nio/SelectChannelEndPoint;","_writable","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f009__writeBlocked(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/io/nio/SelectChannelEndPoint;","_writeBlocked","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/io/nio/SelectChannelEndPoint;","<init>",new String[]{ "Ljava/nio/channels/SocketChannel;","Lorg/mortbay/io/nio/SelectorManager$SelectSet;","Ljava/nio/channels/SelectionKey;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"channel");
                ddv.visitParameterName(1,"selectSet");
                ddv.visitParameterName(2,"key");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(61,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(42,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(43,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(50,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(63,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(64,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(65,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(67,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(69,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(70,L9);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,2},new Method("Lorg/mortbay/io/nio/ChannelEndPoint;","<init>",new String[]{ "Ljava/nio/channels/ByteChannel;"},"V"));
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_BOOLEAN,0,1,new Field("Lorg/mortbay/io/nio/SelectChannelEndPoint;","_dispatched","Z"));
                code.visitLabel(L2);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitFieldStmt(IPUT_BOOLEAN,0,1,new Field("Lorg/mortbay/io/nio/SelectChannelEndPoint;","_writable","Z"));
                code.visitLabel(L3);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/io/nio/SelectChannelEndPoint$IdleTask;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Lorg/mortbay/io/nio/SelectChannelEndPoint$IdleTask;","<init>",new String[]{ "Lorg/mortbay/io/nio/SelectChannelEndPoint;"},"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/io/nio/SelectChannelEndPoint;","_timeoutTask","Lorg/mortbay/thread/Timeout$Task;"));
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/io/nio/SelectorManager$SelectSet;","getManager",new String[]{ },"Lorg/mortbay/io/nio/SelectorManager;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/io/nio/SelectChannelEndPoint;","_manager","Lorg/mortbay/io/nio/SelectorManager;"));
                code.visitLabel(L5);
                code.visitFieldStmt(IPUT_OBJECT,3,1,new Field("Lorg/mortbay/io/nio/SelectChannelEndPoint;","_selectSet","Lorg/mortbay/io/nio/SelectorManager$SelectSet;"));
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/io/nio/SelectChannelEndPoint;","_manager","Lorg/mortbay/io/nio/SelectorManager;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,2,1},new Method("Lorg/mortbay/io/nio/SelectorManager;","newConnection",new String[]{ "Ljava/nio/channels/SocketChannel;","Lorg/mortbay/io/nio/SelectChannelEndPoint;"},"Lorg/mortbay/io/Connection;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/io/nio/SelectChannelEndPoint;","_connection","Lorg/mortbay/io/Connection;"));
                code.visitLabel(L7);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/io/nio/SelectChannelEndPoint;","_manager","Lorg/mortbay/io/nio/SelectorManager;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/io/nio/SelectorManager;","endPointOpened",new String[]{ "Lorg/mortbay/io/nio/SelectChannelEndPoint;"},"V"));
                code.visitLabel(L8);
                code.visitFieldStmt(IPUT_OBJECT,4,1,new Field("Lorg/mortbay/io/nio/SelectChannelEndPoint;","_key","Ljava/nio/channels/SelectionKey;"));
                code.visitLabel(L9);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001_updateKey(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PRIVATE, new Method("Lorg/mortbay/io/nio/SelectChannelEndPoint;","updateKey",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L5=new DexLabel();
                ddv.visitPrologue(L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(319,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(321,L7);
                ddv.visitLineNumber(322,L0);
                ddv.visitStartLocal(0,L0,"ops","I",null);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(324,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(325,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(329,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(330,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(335,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(324,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(325,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(332,L15);
                ddv.visitLineNumber(333,L1);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(334,L16);
                ddv.visitLineNumber(332,L2);
                code.visitLabel(L5);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L6);
                code.visitStmt1R(MONITOR_ENTER,4);
                code.visitLabel(L7);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(-1)); // int: 0xffffffff  float:NaN
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/io/nio/SelectChannelEndPoint;","getChannel",new String[]{ },"Ljava/nio/channels/ByteChannel;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Ljava/nio/channels/ByteChannel;","isOpen",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_EQZ,1,-1,L10);
                code.visitLabel(L8);
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/io/nio/SelectChannelEndPoint;","_key","Ljava/nio/channels/SelectionKey;"));
                code.visitJumpStmt(IF_EQZ,1,-1,L13);
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/io/nio/SelectChannelEndPoint;","_key","Ljava/nio/channels/SelectionKey;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/nio/channels/SelectionKey;","isValid",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_EQZ,1,-1,L13);
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/io/nio/SelectChannelEndPoint;","_key","Ljava/nio/channels/SelectionKey;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/nio/channels/SelectionKey;","interestOps",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitStmt2R(MOVE,0,1);
                code.visitLabel(L9);
                code.visitFieldStmt(IGET_BOOLEAN,1,4,new Field("Lorg/mortbay/io/nio/SelectChannelEndPoint;","_dispatched","Z"));
                DexLabel L17=new DexLabel();
                code.visitJumpStmt(IF_EQZ,1,-1,L17);
                code.visitFieldStmt(IGET_BOOLEAN,1,4,new Field("Lorg/mortbay/io/nio/SelectChannelEndPoint;","_readBlocked","Z"));
                DexLabel L18=new DexLabel();
                code.visitJumpStmt(IF_EQZ,1,-1,L18);
                code.visitLabel(L17);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                DexLabel L19=new DexLabel();
                code.visitLabel(L19);
                code.visitFieldStmt(IGET_BOOLEAN,2,4,new Field("Lorg/mortbay/io/nio/SelectChannelEndPoint;","_writable","Z"));
                DexLabel L20=new DexLabel();
                code.visitJumpStmt(IF_EQZ,2,-1,L20);
                code.visitFieldStmt(IGET_BOOLEAN,2,4,new Field("Lorg/mortbay/io/nio/SelectChannelEndPoint;","_writeBlocked","Z"));
                DexLabel L21=new DexLabel();
                code.visitJumpStmt(IF_EQZ,2,-1,L21);
                code.visitLabel(L20);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(4)); // int: 0x00000004  float:0.000000
                DexLabel L22=new DexLabel();
                code.visitLabel(L22);
                code.visitStmt2R(OR_INT_2ADDR,1,2);
                code.visitFieldStmt(IPUT,1,4,new Field("Lorg/mortbay/io/nio/SelectChannelEndPoint;","_interestOps","I"));
                code.visitLabel(L10);
                code.visitFieldStmt(IGET,1,4,new Field("Lorg/mortbay/io/nio/SelectChannelEndPoint;","_interestOps","I"));
                code.visitJumpStmt(IF_NE,1,0,L15);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/io/nio/SelectChannelEndPoint;","getChannel",new String[]{ },"Ljava/nio/channels/ByteChannel;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Ljava/nio/channels/ByteChannel;","isOpen",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_EQZ,1,-1,L15);
                code.visitLabel(L11);
                code.visitStmt1R(MONITOR_EXIT,4);
                code.visitLabel(L12);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L13);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(-1)); // int: 0xffffffff  float:NaN
                code.visitStmt2R(MOVE,0,1);
                code.visitJumpStmt(GOTO,-1,-1,L9);
                code.visitLabel(L18);
                code.visitStmt2R(MOVE,1,3);
                code.visitLabel(L14);
                code.visitJumpStmt(GOTO,-1,-1,L19);
                code.visitLabel(L21);
                code.visitStmt2R(MOVE,2,3);
                code.visitJumpStmt(GOTO,-1,-1,L22);
                code.visitLabel(L15);
                code.visitStmt1R(MONITOR_EXIT,4);
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/io/nio/SelectChannelEndPoint;","_selectSet","Lorg/mortbay/io/nio/SelectorManager$SelectSet;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,4},new Method("Lorg/mortbay/io/nio/SelectorManager$SelectSet;","addChange",new String[]{ "Ljava/lang/Object;"},"V"));
                code.visitLabel(L16);
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/io/nio/SelectChannelEndPoint;","_selectSet","Lorg/mortbay/io/nio/SelectorManager$SelectSet;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/io/nio/SelectorManager$SelectSet;","wakeup",new String[]{ },"V"));
                code.visitJumpStmt(GOTO,-1,-1,L12);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitLabel(L3);
                code.visitStmt1R(MONITOR_EXIT,4);
                code.visitLabel(L4);
                code.visitStmt1R(THROW,1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_blockReadable(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/nio/SelectChannelEndPoint;","blockReadable",new String[]{ "J"},"Z"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(10);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                DexLabel L5=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L5},new String[]{ null});
                DexLabel L6=new DexLabel();
                DexLabel L7=new DexLabel();
                DexLabel L8=new DexLabel();
                code.visitTryCatch(L6,L7,new DexLabel[]{L8,L5},new String[]{ "Ljava/lang/InterruptedException;",null});
                DexLabel L9=new DexLabel();
                DexLabel L10=new DexLabel();
                code.visitTryCatch(L9,L10,new DexLabel[]{L2},new String[]{ null});
                DexLabel L11=new DexLabel();
                DexLabel L12=new DexLabel();
                code.visitTryCatch(L11,L12,new DexLabel[]{L5},new String[]{ null});
                DexLabel L13=new DexLabel();
                DexLabel L14=new DexLabel();
                code.visitTryCatch(L13,L14,new DexLabel[]{L2},new String[]{ null});
                DexLabel L15=new DexLabel();
                DexLabel L16=new DexLabel();
                code.visitTryCatch(L15,L16,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"timeoutMs");
                DexLabel L17=new DexLabel();
                ddv.visitPrologue(L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(232,L18);
                ddv.visitLineNumber(234,L0);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(237,L19);
                ddv.visitStartLocal(1,L19,"start","J",null);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(238,L20);
                ddv.visitLineNumber(242,L6);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(243,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(245,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(256,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(246,L24);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(259,L25);
                ddv.visitLineNumber(248,L8);
                ddv.visitLineNumber(250,L11);
                ddv.visitStartLocal(0,L11,"e","Ljava/lang/InterruptedException;",null);
                ddv.visitLineNumber(256,L5);
                ddv.visitEndLocal(0,L5);
                ddv.visitLineNumber(258,L2);
                ddv.visitEndLocal(1,L2);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(256,L26);
                ddv.visitRestartLocal(1,L26);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(258,L27);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(259,L28);
                code.visitLabel(L17);
                code.visitConstStmt(CONST_4,6, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitConstStmt(CONST_4,5, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L18);
                code.visitStmt1R(MONITOR_ENTER,7);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,3,7,new Field("Lorg/mortbay/io/nio/SelectChannelEndPoint;","_selectSet","Lorg/mortbay/io/nio/SelectorManager$SelectSet;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/io/nio/SelectorManager$SelectSet;","getNow",new String[]{ },"J"));
                code.visitLabel(L1);
                code.visitStmt1R(MOVE_RESULT_WIDE,1);
                code.visitLabel(L19);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L3);
                code.visitFieldStmt(IPUT_BOOLEAN,3,7,new Field("Lorg/mortbay/io/nio/SelectChannelEndPoint;","_readBlocked","Z"));
                code.visitLabel(L20);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Lorg/mortbay/io/nio/SelectChannelEndPoint;","isOpen",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_EQZ,3,-1,L26);
                code.visitFieldStmt(IGET_BOOLEAN,3,7,new Field("Lorg/mortbay/io/nio/SelectChannelEndPoint;","_readBlocked","Z"));
                code.visitLabel(L4);
                code.visitJumpStmt(IF_EQZ,3,-1,L26);
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 7},new Method("Lorg/mortbay/io/nio/SelectChannelEndPoint;","updateKey",new String[]{ },"V"));
                code.visitLabel(L21);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,8,9},new Method("Ljava/lang/Object;","wait",new String[]{ "J"},"V"));
                code.visitLabel(L22);
                code.visitFieldStmt(IGET_BOOLEAN,3,7,new Field("Lorg/mortbay/io/nio/SelectChannelEndPoint;","_readBlocked","Z"));
                code.visitJumpStmt(IF_EQZ,3,-1,L20);
                code.visitFieldStmt(IGET_OBJECT,3,7,new Field("Lorg/mortbay/io/nio/SelectChannelEndPoint;","_selectSet","Lorg/mortbay/io/nio/SelectorManager$SelectSet;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/io/nio/SelectorManager$SelectSet;","getNow",new String[]{ },"J"));
                code.visitLabel(L7);
                code.visitStmt1R(MOVE_RESULT_WIDE,3);
                code.visitStmt2R(SUB_LONG_2ADDR,3,1);
                code.visitStmt3R(CMP_LONG,3,8,3);
                code.visitJumpStmt(IF_GEZ,3,-1,L20);
                code.visitLabel(L23);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L9);
                code.visitFieldStmt(IPUT_BOOLEAN,3,7,new Field("Lorg/mortbay/io/nio/SelectChannelEndPoint;","_readBlocked","Z"));
                code.visitLabel(L24);
                code.visitStmt1R(MONITOR_EXIT,7);
                code.visitLabel(L10);
                code.visitStmt2R(MOVE,3,5);
                code.visitLabel(L25);
                code.visitStmt1R(RETURN,3);
                code.visitLabel(L8);
                code.visitStmt1R(MOVE_EXCEPTION,3);
                code.visitStmt2R(MOVE_OBJECT,0,3);
                code.visitLabel(L11);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/log/Log;","warn",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitLabel(L12);
                code.visitJumpStmt(GOTO,-1,-1,L20);
                code.visitLabel(L5);
                code.visitStmt1R(MOVE_EXCEPTION,3);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L13);
                code.visitFieldStmt(IPUT_BOOLEAN,4,7,new Field("Lorg/mortbay/io/nio/SelectChannelEndPoint;","_readBlocked","Z"));
                code.visitStmt1R(THROW,3);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,3);
                code.visitStmt1R(MONITOR_EXIT,7);
                code.visitLabel(L14);
                code.visitStmt1R(THROW,3);
                code.visitLabel(L26);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L15);
                code.visitFieldStmt(IPUT_BOOLEAN,3,7,new Field("Lorg/mortbay/io/nio/SelectChannelEndPoint;","_readBlocked","Z"));
                code.visitLabel(L27);
                code.visitStmt1R(MONITOR_EXIT,7);
                code.visitLabel(L16);
                code.visitStmt2R(MOVE,3,6);
                code.visitLabel(L28);
                code.visitJumpStmt(GOTO,-1,-1,L25);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_blockWritable(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/nio/SelectChannelEndPoint;","blockWritable",new String[]{ "J"},"Z"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(10);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                DexLabel L5=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L5},new String[]{ null});
                DexLabel L6=new DexLabel();
                DexLabel L7=new DexLabel();
                DexLabel L8=new DexLabel();
                code.visitTryCatch(L6,L7,new DexLabel[]{L8,L5},new String[]{ "Ljava/lang/InterruptedException;",null});
                DexLabel L9=new DexLabel();
                DexLabel L10=new DexLabel();
                code.visitTryCatch(L9,L10,new DexLabel[]{L2},new String[]{ null});
                DexLabel L11=new DexLabel();
                DexLabel L12=new DexLabel();
                code.visitTryCatch(L11,L12,new DexLabel[]{L5},new String[]{ null});
                DexLabel L13=new DexLabel();
                DexLabel L14=new DexLabel();
                code.visitTryCatch(L13,L14,new DexLabel[]{L2},new String[]{ null});
                DexLabel L15=new DexLabel();
                DexLabel L16=new DexLabel();
                code.visitTryCatch(L15,L16,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"timeoutMs");
                DexLabel L17=new DexLabel();
                ddv.visitPrologue(L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(268,L18);
                ddv.visitLineNumber(270,L0);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(273,L19);
                ddv.visitStartLocal(1,L19,"start","J",null);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(274,L20);
                ddv.visitLineNumber(278,L6);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(279,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(281,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(292,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(282,L24);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(295,L25);
                ddv.visitLineNumber(284,L8);
                ddv.visitLineNumber(286,L11);
                ddv.visitStartLocal(0,L11,"e","Ljava/lang/InterruptedException;",null);
                ddv.visitLineNumber(292,L5);
                ddv.visitEndLocal(0,L5);
                ddv.visitLineNumber(294,L2);
                ddv.visitEndLocal(1,L2);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(292,L26);
                ddv.visitRestartLocal(1,L26);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(294,L27);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(295,L28);
                code.visitLabel(L17);
                code.visitConstStmt(CONST_4,6, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitConstStmt(CONST_4,5, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L18);
                code.visitStmt1R(MONITOR_ENTER,7);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,3,7,new Field("Lorg/mortbay/io/nio/SelectChannelEndPoint;","_selectSet","Lorg/mortbay/io/nio/SelectorManager$SelectSet;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/io/nio/SelectorManager$SelectSet;","getNow",new String[]{ },"J"));
                code.visitLabel(L1);
                code.visitStmt1R(MOVE_RESULT_WIDE,1);
                code.visitLabel(L19);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L3);
                code.visitFieldStmt(IPUT_BOOLEAN,3,7,new Field("Lorg/mortbay/io/nio/SelectChannelEndPoint;","_writeBlocked","Z"));
                code.visitLabel(L20);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Lorg/mortbay/io/nio/SelectChannelEndPoint;","isOpen",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_EQZ,3,-1,L26);
                code.visitFieldStmt(IGET_BOOLEAN,3,7,new Field("Lorg/mortbay/io/nio/SelectChannelEndPoint;","_writeBlocked","Z"));
                code.visitLabel(L4);
                code.visitJumpStmt(IF_EQZ,3,-1,L26);
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 7},new Method("Lorg/mortbay/io/nio/SelectChannelEndPoint;","updateKey",new String[]{ },"V"));
                code.visitLabel(L21);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,8,9},new Method("Ljava/lang/Object;","wait",new String[]{ "J"},"V"));
                code.visitLabel(L22);
                code.visitFieldStmt(IGET_BOOLEAN,3,7,new Field("Lorg/mortbay/io/nio/SelectChannelEndPoint;","_writeBlocked","Z"));
                code.visitJumpStmt(IF_EQZ,3,-1,L20);
                code.visitFieldStmt(IGET_OBJECT,3,7,new Field("Lorg/mortbay/io/nio/SelectChannelEndPoint;","_selectSet","Lorg/mortbay/io/nio/SelectorManager$SelectSet;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/io/nio/SelectorManager$SelectSet;","getNow",new String[]{ },"J"));
                code.visitLabel(L7);
                code.visitStmt1R(MOVE_RESULT_WIDE,3);
                code.visitStmt2R(SUB_LONG_2ADDR,3,1);
                code.visitStmt3R(CMP_LONG,3,8,3);
                code.visitJumpStmt(IF_GEZ,3,-1,L20);
                code.visitLabel(L23);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L9);
                code.visitFieldStmt(IPUT_BOOLEAN,3,7,new Field("Lorg/mortbay/io/nio/SelectChannelEndPoint;","_writeBlocked","Z"));
                code.visitLabel(L24);
                code.visitStmt1R(MONITOR_EXIT,7);
                code.visitLabel(L10);
                code.visitStmt2R(MOVE,3,5);
                code.visitLabel(L25);
                code.visitStmt1R(RETURN,3);
                code.visitLabel(L8);
                code.visitStmt1R(MOVE_EXCEPTION,3);
                code.visitStmt2R(MOVE_OBJECT,0,3);
                code.visitLabel(L11);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/log/Log;","warn",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitLabel(L12);
                code.visitJumpStmt(GOTO,-1,-1,L20);
                code.visitLabel(L5);
                code.visitStmt1R(MOVE_EXCEPTION,3);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L13);
                code.visitFieldStmt(IPUT_BOOLEAN,4,7,new Field("Lorg/mortbay/io/nio/SelectChannelEndPoint;","_writeBlocked","Z"));
                code.visitStmt1R(THROW,3);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,3);
                code.visitStmt1R(MONITOR_EXIT,7);
                code.visitLabel(L14);
                code.visitStmt1R(THROW,3);
                code.visitLabel(L26);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L15);
                code.visitFieldStmt(IPUT_BOOLEAN,3,7,new Field("Lorg/mortbay/io/nio/SelectChannelEndPoint;","_writeBlocked","Z"));
                code.visitLabel(L27);
                code.visitStmt1R(MONITOR_EXIT,7);
                code.visitLabel(L16);
                code.visitStmt2R(MOVE,3,6);
                code.visitLabel(L28);
                code.visitJumpStmt(GOTO,-1,-1,L25);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_cancelIdle(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/nio/SelectChannelEndPoint;","cancelIdle",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(165,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(166,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/io/nio/SelectChannelEndPoint;","_selectSet","Lorg/mortbay/io/nio/SelectorManager$SelectSet;"));
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/io/nio/SelectChannelEndPoint;","_timeoutTask","Lorg/mortbay/thread/Timeout$Task;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/io/nio/SelectorManager$SelectSet;","cancelIdle",new String[]{ "Lorg/mortbay/thread/Timeout$Task;"},"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_close(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/nio/SelectChannelEndPoint;","close",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                DexLabel L3=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2,L3},new String[]{ "Ljava/io/IOException;",null});
                DexLabel L4=new DexLabel();
                DexLabel L5=new DexLabel();
                code.visitTryCatch(L4,L5,new DexLabel[]{L3},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(447,L0);
                ddv.visitLineNumber(455,L1);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(457,L6);
                ddv.visitLineNumber(449,L2);
                ddv.visitLineNumber(451,L4);
                ddv.visitStartLocal(0,L4,"e","Ljava/io/IOException;",null);
                ddv.visitLineNumber(455,L3);
                ddv.visitEndLocal(0,L3);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 2},new Method("Lorg/mortbay/io/nio/ChannelEndPoint;","close",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2},new Method("Lorg/mortbay/io/nio/SelectChannelEndPoint;","updateKey",new String[]{ },"V"));
                code.visitLabel(L6);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,0);
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/log/Log;","ignore",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitLabel(L5);
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitLabel(L3);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2},new Method("Lorg/mortbay/io/nio/SelectChannelEndPoint;","updateKey",new String[]{ },"V"));
                code.visitStmt1R(THROW,1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_dispatch(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(0, new Method("Lorg/mortbay/io/nio/SelectChannelEndPoint;","dispatch",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(75,L4);
                ddv.visitLineNumber(78,L0);
                ddv.visitStartLocal(0,L0,"dispatch_done","Z",null);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(80,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(81,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(86,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(88,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(89,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(92,L10);
                ddv.visitLineNumber(86,L2);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(88,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(89,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(86,L13);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_STRING,3,"dispatch failed!");
                code.visitLabel(L4);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/io/nio/SelectChannelEndPoint;","_manager","Lorg/mortbay/io/nio/SelectorManager;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/io/nio/SelectorManager;","isDelaySelectKeyUpdate",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,1},new Method("Lorg/mortbay/io/nio/SelectChannelEndPoint;","dispatch",new String[]{ "Z"},"Z"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_EQZ,1,-1,L7);
                code.visitLabel(L5);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/io/nio/SelectChannelEndPoint;","_manager","Lorg/mortbay/io/nio/SelectorManager;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,4},new Method("Lorg/mortbay/io/nio/SelectorManager;","dispatch",new String[]{ "Ljava/lang/Runnable;"},"Z"));
                code.visitLabel(L1);
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitLabel(L7);
                code.visitJumpStmt(IF_NEZ,0,-1,L10);
                code.visitLabel(L8);
                code.visitConstStmt(CONST_STRING,1,"dispatch failed!");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3},new Method("Lorg/mortbay/log/Log;","warn",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/io/nio/SelectChannelEndPoint;","undispatch",new String[]{ },"V"));
                code.visitLabel(L10);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitJumpStmt(IF_NEZ,0,-1,L13);
                code.visitLabel(L11);
                code.visitConstStmt(CONST_STRING,2,"dispatch failed!");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3},new Method("Lorg/mortbay/log/Log;","warn",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L12);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/io/nio/SelectChannelEndPoint;","undispatch",new String[]{ },"V"));
                code.visitLabel(L13);
                code.visitStmt1R(THROW,1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m007_dispatch(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/nio/SelectChannelEndPoint;","dispatch",new String[]{ "Z"},"Z"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"assumeShortDispatch");
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(106,L4);
                ddv.visitLineNumber(108,L0);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(110,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(111,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(112,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(113,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(153,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(116,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(118,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(119,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(120,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(121,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(124,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(127,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(128,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(131,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(132,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(135,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(138,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(139,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(143,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(146,L24);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(147,L25);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(148,L26);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(151,L27);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(152,L28);
                DexLabel L29=new DexLabel();
                ddv.visitLineNumber(153,L29);
                ddv.visitLineNumber(152,L2);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(4)); // int: 0x00000004  float:0.000000
                code.visitConstStmt(CONST_4,3, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L4);
                code.visitStmt1R(MONITOR_ENTER,5);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,5,new Field("Lorg/mortbay/io/nio/SelectChannelEndPoint;","_key","Ljava/nio/channels/SelectionKey;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L5);
                code.visitFieldStmt(IGET_OBJECT,0,5,new Field("Lorg/mortbay/io/nio/SelectChannelEndPoint;","_key","Ljava/nio/channels/SelectionKey;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/nio/channels/SelectionKey;","isValid",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_NEZ,0,-1,L10);
                code.visitLabel(L5);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_BOOLEAN,0,5,new Field("Lorg/mortbay/io/nio/SelectChannelEndPoint;","_readBlocked","Z"));
                code.visitLabel(L6);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_BOOLEAN,0,5,new Field("Lorg/mortbay/io/nio/SelectChannelEndPoint;","_writeBlocked","Z"));
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/lang/Object;","notifyAll",new String[]{ },"V"));
                code.visitLabel(L8);
                code.visitStmt1R(MONITOR_EXIT,5);
                code.visitStmt2R(MOVE,0,2);
                code.visitLabel(L9);
                code.visitStmt1R(RETURN,0);
                code.visitLabel(L10);
                code.visitFieldStmt(IGET_BOOLEAN,0,5,new Field("Lorg/mortbay/io/nio/SelectChannelEndPoint;","_readBlocked","Z"));
                code.visitJumpStmt(IF_NEZ,0,-1,L11);
                code.visitFieldStmt(IGET_BOOLEAN,0,5,new Field("Lorg/mortbay/io/nio/SelectChannelEndPoint;","_writeBlocked","Z"));
                code.visitJumpStmt(IF_EQZ,0,-1,L18);
                code.visitLabel(L11);
                code.visitFieldStmt(IGET_BOOLEAN,0,5,new Field("Lorg/mortbay/io/nio/SelectChannelEndPoint;","_readBlocked","Z"));
                code.visitJumpStmt(IF_EQZ,0,-1,L13);
                code.visitFieldStmt(IGET_OBJECT,0,5,new Field("Lorg/mortbay/io/nio/SelectChannelEndPoint;","_key","Ljava/nio/channels/SelectionKey;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/nio/channels/SelectionKey;","isReadable",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L13);
                code.visitLabel(L12);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_BOOLEAN,0,5,new Field("Lorg/mortbay/io/nio/SelectChannelEndPoint;","_readBlocked","Z"));
                code.visitLabel(L13);
                code.visitFieldStmt(IGET_BOOLEAN,0,5,new Field("Lorg/mortbay/io/nio/SelectChannelEndPoint;","_writeBlocked","Z"));
                code.visitJumpStmt(IF_EQZ,0,-1,L15);
                code.visitFieldStmt(IGET_OBJECT,0,5,new Field("Lorg/mortbay/io/nio/SelectChannelEndPoint;","_key","Ljava/nio/channels/SelectionKey;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/nio/channels/SelectionKey;","isWritable",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L15);
                code.visitLabel(L14);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_BOOLEAN,0,5,new Field("Lorg/mortbay/io/nio/SelectChannelEndPoint;","_writeBlocked","Z"));
                code.visitLabel(L15);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/lang/Object;","notifyAll",new String[]{ },"V"));
                code.visitLabel(L16);
                code.visitFieldStmt(IGET_OBJECT,0,5,new Field("Lorg/mortbay/io/nio/SelectChannelEndPoint;","_key","Ljava/nio/channels/SelectionKey;"));
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/nio/channels/SelectionKey;","interestOps",new String[]{ "I"},"Ljava/nio/channels/SelectionKey;"));
                code.visitLabel(L17);
                code.visitStmt1R(MONITOR_EXIT,5);
                code.visitStmt2R(MOVE,0,2);
                code.visitJumpStmt(GOTO,-1,-1,L9);
                code.visitLabel(L18);
                code.visitJumpStmt(IF_NEZ,6,-1,L20);
                code.visitLabel(L19);
                code.visitFieldStmt(IGET_OBJECT,0,5,new Field("Lorg/mortbay/io/nio/SelectChannelEndPoint;","_key","Ljava/nio/channels/SelectionKey;"));
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/nio/channels/SelectionKey;","interestOps",new String[]{ "I"},"Ljava/nio/channels/SelectionKey;"));
                code.visitLabel(L20);
                code.visitFieldStmt(IGET_BOOLEAN,0,5,new Field("Lorg/mortbay/io/nio/SelectChannelEndPoint;","_dispatched","Z"));
                code.visitJumpStmt(IF_EQZ,0,-1,L23);
                code.visitLabel(L21);
                code.visitFieldStmt(IGET_OBJECT,0,5,new Field("Lorg/mortbay/io/nio/SelectChannelEndPoint;","_key","Ljava/nio/channels/SelectionKey;"));
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/nio/channels/SelectionKey;","interestOps",new String[]{ "I"},"Ljava/nio/channels/SelectionKey;"));
                code.visitLabel(L22);
                code.visitStmt1R(MONITOR_EXIT,5);
                code.visitStmt2R(MOVE,0,2);
                code.visitJumpStmt(GOTO,-1,-1,L9);
                code.visitLabel(L23);
                code.visitFieldStmt(IGET_OBJECT,0,5,new Field("Lorg/mortbay/io/nio/SelectChannelEndPoint;","_key","Ljava/nio/channels/SelectionKey;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/nio/channels/SelectionKey;","readyOps",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitStmt2R1N(AND_INT_LIT8,0,0,4);
                code.visitJumpStmt(IF_NE,0,4,L27);
                code.visitFieldStmt(IGET_OBJECT,0,5,new Field("Lorg/mortbay/io/nio/SelectChannelEndPoint;","_key","Ljava/nio/channels/SelectionKey;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/nio/channels/SelectionKey;","interestOps",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitStmt2R1N(AND_INT_LIT8,0,0,4);
                code.visitJumpStmt(IF_NE,0,4,L27);
                code.visitLabel(L24);
                code.visitFieldStmt(IGET_OBJECT,0,5,new Field("Lorg/mortbay/io/nio/SelectChannelEndPoint;","_key","Ljava/nio/channels/SelectionKey;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/nio/channels/SelectionKey;","interestOps",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitStmt2R1N(AND_INT_LIT8,0,0,-5);
                code.visitFieldStmt(IPUT,0,5,new Field("Lorg/mortbay/io/nio/SelectChannelEndPoint;","_interestOps","I"));
                code.visitLabel(L25);
                code.visitFieldStmt(IGET_OBJECT,0,5,new Field("Lorg/mortbay/io/nio/SelectChannelEndPoint;","_key","Ljava/nio/channels/SelectionKey;"));
                code.visitFieldStmt(IGET,1,5,new Field("Lorg/mortbay/io/nio/SelectChannelEndPoint;","_interestOps","I"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/nio/channels/SelectionKey;","interestOps",new String[]{ "I"},"Ljava/nio/channels/SelectionKey;"));
                code.visitLabel(L26);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitFieldStmt(IPUT_BOOLEAN,0,5,new Field("Lorg/mortbay/io/nio/SelectChannelEndPoint;","_writable","Z"));
                code.visitLabel(L27);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitFieldStmt(IPUT_BOOLEAN,0,5,new Field("Lorg/mortbay/io/nio/SelectChannelEndPoint;","_dispatched","Z"));
                code.visitLabel(L28);
                code.visitStmt1R(MONITOR_EXIT,5);
                code.visitStmt2R(MOVE,0,3);
                code.visitLabel(L29);
                code.visitJumpStmt(GOTO,-1,-1,L9);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,0);
                code.visitStmt1R(MONITOR_EXIT,5);
                code.visitLabel(L1);
                code.visitStmt1R(THROW,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m008_doUpdateKey(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(0, new Method("Lorg/mortbay/io/nio/SelectChannelEndPoint;","doUpdateKey",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                DexLabel L5=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L5,L2},new String[]{ "Ljava/lang/Exception;",null});
                DexLabel L6=new DexLabel();
                DexLabel L7=new DexLabel();
                code.visitTryCatch(L6,L7,new DexLabel[]{L2},new String[]{ null});
                DexLabel L8=new DexLabel();
                DexLabel L9=new DexLabel();
                code.visitTryCatch(L8,L9,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L10=new DexLabel();
                ddv.visitPrologue(L10);
                ddv.visitLineNumber(343,L10);
                ddv.visitLineNumber(345,L0);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(347,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(349,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(351,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(352,L14);
                ddv.visitStartLocal(1,L14,"sc","Ljava/nio/channels/SelectableChannel;",null);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(354,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(399,L16);
                ddv.visitEndLocal(1,L16);
                ddv.visitLineNumber(400,L1);
                ddv.visitLineNumber(360,L3);
                ddv.visitRestartLocal(1,L3);
                ddv.visitLineNumber(362,L5);
                ddv.visitLineNumber(364,L6);
                ddv.visitStartLocal(0,L6,"e","Ljava/lang/Exception;",null);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(365,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(367,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(369,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(370,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(371,L21);
                ddv.visitLineNumber(399,L2);
                ddv.visitEndLocal(1,L2);
                ddv.visitEndLocal(0,L2);
                ddv.visitLineNumber(377,L8);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(382,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(383,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(385,L24);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(390,L25);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(392,L26);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(393,L27);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(395,L28);
                DexLabel L29=new DexLabel();
                ddv.visitLineNumber(396,L29);
                DexLabel L30=new DexLabel();
                ddv.visitLineNumber(397,L30);
                code.visitLabel(L10);
                code.visitStmt1R(MONITOR_ENTER,5);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/io/nio/SelectChannelEndPoint;","getChannel",new String[]{ },"Ljava/nio/channels/ByteChannel;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2},new Method("Ljava/nio/channels/ByteChannel;","isOpen",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_EQZ,2,-1,L25);
                code.visitLabel(L11);
                code.visitFieldStmt(IGET,2,5,new Field("Lorg/mortbay/io/nio/SelectChannelEndPoint;","_interestOps","I"));
                code.visitJumpStmt(IF_LEZ,2,-1,L22);
                code.visitLabel(L12);
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/io/nio/SelectChannelEndPoint;","_key","Ljava/nio/channels/SelectionKey;"));
                code.visitJumpStmt(IF_EQZ,2,-1,L13);
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/io/nio/SelectChannelEndPoint;","_key","Ljava/nio/channels/SelectionKey;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/nio/channels/SelectionKey;","isValid",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_NEZ,2,-1,L8);
                code.visitLabel(L13);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/io/nio/SelectChannelEndPoint;","getChannel",new String[]{ },"Ljava/nio/channels/ByteChannel;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitTypeStmt(CHECK_CAST,1,-1,"Ljava/nio/channels/SelectableChannel;");
                code.visitLabel(L14);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/nio/channels/SelectableChannel;","isRegistered",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_EQZ,2,-1,L3);
                code.visitLabel(L15);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 5},new Method("Lorg/mortbay/io/nio/SelectChannelEndPoint;","updateKey",new String[]{ },"V"));
                code.visitLabel(L16);
                code.visitStmt1R(MONITOR_EXIT,5);
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/io/nio/SelectChannelEndPoint;","getChannel",new String[]{ },"Ljava/nio/channels/ByteChannel;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitTypeStmt(CHECK_CAST,2,-1,"Ljava/nio/channels/SelectableChannel;");
                code.visitFieldStmt(IGET_OBJECT,3,5,new Field("Lorg/mortbay/io/nio/SelectChannelEndPoint;","_selectSet","Lorg/mortbay/io/nio/SelectorManager$SelectSet;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/io/nio/SelectorManager$SelectSet;","getSelector",new String[]{ },"Ljava/nio/channels/Selector;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitFieldStmt(IGET,4,5,new Field("Lorg/mortbay/io/nio/SelectChannelEndPoint;","_interestOps","I"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3,4,5},new Method("Ljava/nio/channels/SelectableChannel;","register",new String[]{ "Ljava/nio/channels/Selector;","I","Ljava/lang/Object;"},"Ljava/nio/channels/SelectionKey;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitFieldStmt(IPUT_OBJECT,2,5,new Field("Lorg/mortbay/io/nio/SelectChannelEndPoint;","_key","Ljava/nio/channels/SelectionKey;"));
                code.visitLabel(L4);
                code.visitJumpStmt(GOTO,-1,-1,L16);
                code.visitLabel(L5);
                code.visitStmt1R(MOVE_EXCEPTION,2);
                code.visitStmt2R(MOVE_OBJECT,0,2);
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/log/Log;","ignore",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitLabel(L17);
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/io/nio/SelectChannelEndPoint;","_key","Ljava/nio/channels/SelectionKey;"));
                code.visitJumpStmt(IF_EQZ,2,-1,L19);
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/io/nio/SelectChannelEndPoint;","_key","Ljava/nio/channels/SelectionKey;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/nio/channels/SelectionKey;","isValid",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_EQZ,2,-1,L19);
                code.visitLabel(L18);
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/io/nio/SelectChannelEndPoint;","_key","Ljava/nio/channels/SelectionKey;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/nio/channels/SelectionKey;","cancel",new String[]{ },"V"));
                code.visitLabel(L19);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/io/nio/SelectChannelEndPoint;","cancelIdle",new String[]{ },"V"));
                code.visitLabel(L20);
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/io/nio/SelectChannelEndPoint;","_manager","Lorg/mortbay/io/nio/SelectorManager;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,5},new Method("Lorg/mortbay/io/nio/SelectorManager;","endPointClosed",new String[]{ "Lorg/mortbay/io/nio/SelectChannelEndPoint;"},"V"));
                code.visitLabel(L21);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_OBJECT,2,5,new Field("Lorg/mortbay/io/nio/SelectChannelEndPoint;","_key","Ljava/nio/channels/SelectionKey;"));
                code.visitJumpStmt(GOTO,-1,-1,L16);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,2);
                code.visitStmt1R(MONITOR_EXIT,5);
                code.visitLabel(L7);
                code.visitStmt1R(THROW,2);
                code.visitLabel(L8);
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/io/nio/SelectChannelEndPoint;","_key","Ljava/nio/channels/SelectionKey;"));
                code.visitFieldStmt(IGET,3,5,new Field("Lorg/mortbay/io/nio/SelectChannelEndPoint;","_interestOps","I"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/nio/channels/SelectionKey;","interestOps",new String[]{ "I"},"Ljava/nio/channels/SelectionKey;"));
                code.visitJumpStmt(GOTO,-1,-1,L16);
                code.visitLabel(L22);
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/io/nio/SelectChannelEndPoint;","_key","Ljava/nio/channels/SelectionKey;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/nio/channels/SelectionKey;","isValid",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_EQZ,2,-1,L24);
                code.visitLabel(L23);
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/io/nio/SelectChannelEndPoint;","_key","Ljava/nio/channels/SelectionKey;"));
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/nio/channels/SelectionKey;","interestOps",new String[]{ "I"},"Ljava/nio/channels/SelectionKey;"));
                code.visitJumpStmt(GOTO,-1,-1,L16);
                code.visitLabel(L24);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_OBJECT,2,5,new Field("Lorg/mortbay/io/nio/SelectChannelEndPoint;","_key","Ljava/nio/channels/SelectionKey;"));
                code.visitJumpStmt(GOTO,-1,-1,L16);
                code.visitLabel(L25);
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/io/nio/SelectChannelEndPoint;","_key","Ljava/nio/channels/SelectionKey;"));
                code.visitJumpStmt(IF_EQZ,2,-1,L28);
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/io/nio/SelectChannelEndPoint;","_key","Ljava/nio/channels/SelectionKey;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/nio/channels/SelectionKey;","isValid",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_EQZ,2,-1,L28);
                code.visitLabel(L26);
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/io/nio/SelectChannelEndPoint;","_key","Ljava/nio/channels/SelectionKey;"));
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/nio/channels/SelectionKey;","interestOps",new String[]{ "I"},"Ljava/nio/channels/SelectionKey;"));
                code.visitLabel(L27);
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/io/nio/SelectChannelEndPoint;","_key","Ljava/nio/channels/SelectionKey;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/nio/channels/SelectionKey;","cancel",new String[]{ },"V"));
                code.visitLabel(L28);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/io/nio/SelectChannelEndPoint;","cancelIdle",new String[]{ },"V"));
                code.visitLabel(L29);
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/io/nio/SelectChannelEndPoint;","_manager","Lorg/mortbay/io/nio/SelectorManager;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,5},new Method("Lorg/mortbay/io/nio/SelectorManager;","endPointClosed",new String[]{ "Lorg/mortbay/io/nio/SelectChannelEndPoint;"},"V"));
                code.visitLabel(L30);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_OBJECT,2,5,new Field("Lorg/mortbay/io/nio/SelectChannelEndPoint;","_key","Ljava/nio/channels/SelectionKey;"));
                code.visitLabel(L9);
                code.visitJumpStmt(GOTO,-1,-1,L16);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m009_flush(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/nio/SelectChannelEndPoint;","flush",new String[]{ "Lorg/mortbay/io/Buffer;"},"I"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"buffer");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(221,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(222,L1);
                ddv.visitStartLocal(0,L1,"l","I",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(223,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(222,L3);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 2,3},new Method("Lorg/mortbay/io/nio/ChannelEndPoint;","flush",new String[]{ "Lorg/mortbay/io/Buffer;"},"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitLabel(L1);
                code.visitJumpStmt(IF_LEZ,0,-1,L3);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                DexLabel L4=new DexLabel();
                code.visitLabel(L4);
                code.visitFieldStmt(IPUT_BOOLEAN,1,2,new Field("Lorg/mortbay/io/nio/SelectChannelEndPoint;","_writable","Z"));
                code.visitLabel(L2);
                code.visitStmt1R(RETURN,0);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m010_flush(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/nio/SelectChannelEndPoint;","flush",new String[]{ "Lorg/mortbay/io/Buffer;","Lorg/mortbay/io/Buffer;","Lorg/mortbay/io/Buffer;"},"I"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"header");
                ddv.visitParameterName(1,"buffer");
                ddv.visitParameterName(2,"trailer");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(211,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(212,L1);
                ddv.visitStartLocal(0,L1,"l","I",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(213,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(212,L3);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 2,3,4,5},new Method("Lorg/mortbay/io/nio/ChannelEndPoint;","flush",new String[]{ "Lorg/mortbay/io/Buffer;","Lorg/mortbay/io/Buffer;","Lorg/mortbay/io/Buffer;"},"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitLabel(L1);
                code.visitJumpStmt(IF_LEZ,0,-1,L3);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                DexLabel L4=new DexLabel();
                code.visitLabel(L4);
                code.visitFieldStmt(IPUT_BOOLEAN,1,2,new Field("Lorg/mortbay/io/nio/SelectChannelEndPoint;","_writable","Z"));
                code.visitLabel(L2);
                code.visitStmt1R(RETURN,0);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m011_getConnection(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/nio/SelectChannelEndPoint;","getConnection",new String[]{ },"Lorg/mortbay/io/Connection;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(55,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/io/nio/SelectChannelEndPoint;","_connection","Lorg/mortbay/io/Connection;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m012_getSelectSet(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/nio/SelectChannelEndPoint;","getSelectSet",new String[]{ },"Lorg/mortbay/io/nio/SelectorManager$SelectSet;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(474,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/io/nio/SelectChannelEndPoint;","_selectSet","Lorg/mortbay/io/nio/SelectorManager$SelectSet;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m013_getTimeoutTask(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/nio/SelectChannelEndPoint;","getTimeoutTask",new String[]{ },"Lorg/mortbay/thread/Timeout$Task;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(468,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/io/nio/SelectChannelEndPoint;","_timeoutTask","Lorg/mortbay/thread/Timeout$Task;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m014_idleExpired(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/io/nio/SelectChannelEndPoint;","idleExpired",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/io/IOException;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(174,L0);
                ddv.visitLineNumber(180,L1);
                ddv.visitLineNumber(176,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(178,L3);
                ddv.visitStartLocal(0,L3,"e","Ljava/io/IOException;",null);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/io/nio/SelectChannelEndPoint;","close",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,0);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/log/Log;","ignore",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m015_run(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/nio/SelectChannelEndPoint;","run",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                DexLabel L5=new DexLabel();
                DexLabel L6=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2,L3,L4,L5,L6},new String[]{ "Ljava/nio/channels/ClosedChannelException;","Lorg/mortbay/jetty/EofException;","Lorg/mortbay/jetty/HttpException;","Ljava/lang/Throwable;",null});
                DexLabel L7=new DexLabel();
                DexLabel L8=new DexLabel();
                code.visitTryCatch(L7,L8,new DexLabel[]{L6},new String[]{ null});
                DexLabel L9=new DexLabel();
                DexLabel L10=new DexLabel();
                code.visitTryCatch(L9,L10,new DexLabel[]{L6},new String[]{ null});
                DexLabel L11=new DexLabel();
                DexLabel L12=new DexLabel();
                code.visitTryCatch(L10,L11,new DexLabel[]{L12,L6},new String[]{ "Ljava/io/IOException;",null});
                DexLabel L13=new DexLabel();
                DexLabel L14=new DexLabel();
                code.visitTryCatch(L13,L14,new DexLabel[]{L6},new String[]{ null});
                DexLabel L15=new DexLabel();
                DexLabel L16=new DexLabel();
                code.visitTryCatch(L14,L15,new DexLabel[]{L16,L6},new String[]{ "Ljava/io/IOException;",null});
                DexLabel L17=new DexLabel();
                DexLabel L18=new DexLabel();
                code.visitTryCatch(L17,L18,new DexLabel[]{L6},new String[]{ null});
                DexLabel L19=new DexLabel();
                DexLabel L20=new DexLabel();
                code.visitTryCatch(L18,L19,new DexLabel[]{L20,L6},new String[]{ "Ljava/io/IOException;",null});
                DexLabel L21=new DexLabel();
                DexLabel L22=new DexLabel();
                code.visitTryCatch(L21,L22,new DexLabel[]{L6},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(409,L0);
                ddv.visitLineNumber(435,L1);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(437,L23);
                ddv.visitLineNumber(411,L2);
                ddv.visitLineNumber(413,L7);
                ddv.visitStartLocal(0,L7,"e","Ljava/nio/channels/ClosedChannelException;",null);
                ddv.visitLineNumber(435,L6);
                ddv.visitEndLocal(0,L6);
                ddv.visitLineNumber(415,L3);
                ddv.visitLineNumber(417,L9);
                ddv.visitStartLocal(0,L9,"e","Lorg/mortbay/jetty/EofException;",null);
                ddv.visitLineNumber(418,L10);
                ddv.visitLineNumber(419,L12);
                ddv.visitStartLocal(1,L13,"e2","Ljava/io/IOException;",null);
                ddv.visitLineNumber(421,L4);
                ddv.visitEndLocal(0,L4);
                ddv.visitEndLocal(1,L4);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(423,L24);
                ddv.visitStartLocal(0,L24,"e","Lorg/mortbay/jetty/HttpException;",null);
                ddv.visitLineNumber(424,L14);
                ddv.visitLineNumber(425,L16);
                ddv.visitRestartLocal(1,L17);
                ddv.visitLineNumber(427,L5);
                ddv.visitEndLocal(0,L5);
                ddv.visitEndLocal(1,L5);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(429,L25);
                ddv.visitStartLocal(0,L25,"e","Ljava/lang/Throwable;",null);
                ddv.visitLineNumber(430,L18);
                ddv.visitLineNumber(431,L20);
                ddv.visitRestartLocal(1,L21);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,2,3,new Field("Lorg/mortbay/io/nio/SelectChannelEndPoint;","_connection","Lorg/mortbay/io/Connection;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2},new Method("Lorg/mortbay/io/Connection;","handle",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/io/nio/SelectChannelEndPoint;","undispatch",new String[]{ },"V"));
                code.visitLabel(L23);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,2);
                code.visitStmt2R(MOVE_OBJECT,0,2);
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/log/Log;","ignore",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitLabel(L8);
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitLabel(L6);
                code.visitStmt1R(MOVE_EXCEPTION,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/io/nio/SelectChannelEndPoint;","undispatch",new String[]{ },"V"));
                code.visitStmt1R(THROW,2);
                code.visitLabel(L3);
                code.visitStmt1R(MOVE_EXCEPTION,2);
                code.visitStmt2R(MOVE_OBJECT,0,2);
                code.visitLabel(L9);
                code.visitConstStmt(CONST_STRING,2,"EOF");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2,0},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/io/nio/SelectChannelEndPoint;","close",new String[]{ },"V"));
                code.visitLabel(L11);
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitLabel(L12);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitLabel(L13);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1},new Method("Lorg/mortbay/log/Log;","ignore",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitLabel(L4);
                code.visitStmt1R(MOVE_EXCEPTION,2);
                code.visitStmt2R(MOVE_OBJECT,0,2);
                code.visitLabel(L24);
                code.visitConstStmt(CONST_STRING,2,"BAD");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2,0},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L14);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/io/nio/SelectChannelEndPoint;","close",new String[]{ },"V"));
                code.visitLabel(L15);
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitLabel(L16);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitLabel(L17);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1},new Method("Lorg/mortbay/log/Log;","ignore",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitLabel(L5);
                code.visitStmt1R(MOVE_EXCEPTION,2);
                code.visitStmt2R(MOVE_OBJECT,0,2);
                code.visitLabel(L25);
                code.visitConstStmt(CONST_STRING,2,"handle failed");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2,0},new Method("Lorg/mortbay/log/Log;","warn",new String[]{ "Ljava/lang/String;","Ljava/lang/Throwable;"},"V"));
                code.visitLabel(L18);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/io/nio/SelectChannelEndPoint;","close",new String[]{ },"V"));
                code.visitLabel(L19);
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitLabel(L20);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitLabel(L21);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1},new Method("Lorg/mortbay/log/Log;","ignore",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitLabel(L22);
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m016_scheduleIdle(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/nio/SelectChannelEndPoint;","scheduleIdle",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(159,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(160,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/io/nio/SelectChannelEndPoint;","_selectSet","Lorg/mortbay/io/nio/SelectorManager$SelectSet;"));
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/io/nio/SelectChannelEndPoint;","_timeoutTask","Lorg/mortbay/thread/Timeout$Task;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/io/nio/SelectorManager$SelectSet;","scheduleIdle",new String[]{ "Lorg/mortbay/thread/Timeout$Task;"},"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m017_scheduleWrite(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/nio/SelectChannelEndPoint;","scheduleWrite",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(307,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(308,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(309,L2);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_BOOLEAN,0,1,new Field("Lorg/mortbay/io/nio/SelectChannelEndPoint;","_writable","Z"));
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Lorg/mortbay/io/nio/SelectChannelEndPoint;","updateKey",new String[]{ },"V"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m018_setWritable(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/nio/SelectChannelEndPoint;","setWritable",new String[]{ "Z"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"writable");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(301,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(302,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_BOOLEAN,1,0,new Field("Lorg/mortbay/io/nio/SelectChannelEndPoint;","_writable","Z"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m019_toString(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/nio/SelectChannelEndPoint;","toString",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(462,L0);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,1,"SCEP@");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/lang/Object;","hashCode",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "I"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitConstStmt(CONST_STRING,1,"[d=");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IGET_BOOLEAN,1,2,new Field("Lorg/mortbay/io/nio/SelectChannelEndPoint;","_dispatched","Z"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Z"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitConstStmt(CONST_STRING,1,",io=");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IGET,1,2,new Field("Lorg/mortbay/io/nio/SelectChannelEndPoint;","_interestOps","I"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "I"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitConstStmt(CONST_STRING,1,",w=");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IGET_BOOLEAN,1,2,new Field("Lorg/mortbay/io/nio/SelectChannelEndPoint;","_writable","Z"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Z"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitConstStmt(CONST_STRING,1,",b=");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IGET_BOOLEAN,1,2,new Field("Lorg/mortbay/io/nio/SelectChannelEndPoint;","_readBlocked","Z"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Z"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitConstStmt(CONST_STRING,1,"|");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IGET_BOOLEAN,1,2,new Field("Lorg/mortbay/io/nio/SelectChannelEndPoint;","_writeBlocked","Z"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Z"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitConstStmt(CONST_STRING,1,"]");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m020_undispatch(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/nio/SelectChannelEndPoint;","undispatch",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                DexLabel L3=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2,L3},new String[]{ "Ljava/lang/Exception;",null});
                DexLabel L4=new DexLabel();
                code.visitTryCatch(L1,L4,new DexLabel[]{L3},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L5=new DexLabel();
                ddv.visitPrologue(L5);
                ddv.visitLineNumber(189,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(193,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(194,L7);
                ddv.visitLineNumber(203,L1);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(204,L8);
                ddv.visitLineNumber(196,L2);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(199,L9);
                ddv.visitStartLocal(0,L9,"e","Ljava/lang/Exception;",null);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(200,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(201,L11);
                ddv.visitLineNumber(203,L3);
                ddv.visitEndLocal(0,L3);
                code.visitLabel(L5);
                code.visitStmt1R(MONITOR_ENTER,2);
                code.visitLabel(L6);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_BOOLEAN,1,2,new Field("Lorg/mortbay/io/nio/SelectChannelEndPoint;","_dispatched","Z"));
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2},new Method("Lorg/mortbay/io/nio/SelectChannelEndPoint;","updateKey",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitStmt1R(MONITOR_EXIT,2);
                code.visitLabel(L8);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitStmt2R(MOVE_OBJECT,0,1);
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/log/Log;","ignore",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitLabel(L10);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(-1)); // int: 0xffffffff  float:NaN
                code.visitFieldStmt(IPUT,1,2,new Field("Lorg/mortbay/io/nio/SelectChannelEndPoint;","_interestOps","I"));
                code.visitLabel(L11);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/io/nio/SelectChannelEndPoint;","_selectSet","Lorg/mortbay/io/nio/SelectorManager$SelectSet;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Lorg/mortbay/io/nio/SelectorManager$SelectSet;","addChange",new String[]{ "Ljava/lang/Object;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitLabel(L3);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitStmt1R(MONITOR_EXIT,2);
                code.visitLabel(L4);
                code.visitStmt1R(THROW,1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
