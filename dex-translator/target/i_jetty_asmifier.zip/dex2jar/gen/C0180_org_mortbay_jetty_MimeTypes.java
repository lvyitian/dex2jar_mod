package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0180_org_mortbay_jetty_MimeTypes {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/jetty/MimeTypes;","Ljava/lang/Object;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("MimeTypes.java");
        f000_CACHE(cv);
        f001_FORM_ENCODED(cv);
        f002_FORM_ENCODED_BUFFER(cv);
        f003_FORM_ENCODED_ORDINAL(cv);
        f004_MESSAGE_HTTP(cv);
        f005_MESSAGE_HTTP_BUFFER(cv);
        f006_MESSAGE_HTTP_ORDINAL(cv);
        f007_MULTIPART_BYTERANGES(cv);
        f008_MULTIPART_BYTERANGES_BUFFER(cv);
        f009_MULTIPART_BYTERANGES_ORDINAL(cv);
        f010_TEXT_HTML(cv);
        f011_TEXT_HTML_8859_1(cv);
        f012_TEXT_HTML_8859_1_BUFFER(cv);
        f013_TEXT_HTML_8859_1_ORDINAL(cv);
        f014_TEXT_HTML_BUFFER(cv);
        f015_TEXT_HTML_ORDINAL(cv);
        f016_TEXT_HTML_UTF_8(cv);
        f017_TEXT_HTML_UTF_8_BUFFER(cv);
        f018_TEXT_HTML_UTF_8_ORDINAL(cv);
        f019_TEXT_JSON(cv);
        f020_TEXT_JSON_BUFFER(cv);
        f021_TEXT_JSON_ORDINAL(cv);
        f022_TEXT_JSON_UTF_8(cv);
        f023_TEXT_JSON_UTF_8_BUFFER(cv);
        f024_TEXT_JSON_UTF_8_ORDINAL(cv);
        f025_TEXT_PLAIN(cv);
        f026_TEXT_PLAIN_8859_1(cv);
        f027_TEXT_PLAIN_8859_1_BUFFER(cv);
        f028_TEXT_PLAIN_8859_1_ORDINAL(cv);
        f029_TEXT_PLAIN_BUFFER(cv);
        f030_TEXT_PLAIN_ORDINAL(cv);
        f031_TEXT_PLAIN_UTF_8(cv);
        f032_TEXT_PLAIN_UTF_8_BUFFER(cv);
        f033_TEXT_PLAIN_UTF_8_ORDINAL(cv);
        f034_TEXT_XML(cv);
        f035_TEXT_XML_8859_1(cv);
        f036_TEXT_XML_8859_1_BUFFER(cv);
        f037_TEXT_XML_8859_1_ORDINAL(cv);
        f038_TEXT_XML_BUFFER(cv);
        f039_TEXT_XML_ORDINAL(cv);
        f040_TEXT_XML_UTF_8(cv);
        f041_TEXT_XML_UTF_8_BUFFER(cv);
        f042_TEXT_XML_UTF_8_ORDINAL(cv);
        f043___dftMimeMap(cv);
        f044___encodings(cv);
        f045___index(cv);
        f046__mimeMap(cv);
        m000__clinit_(cv);
        m001__init_(cv);
        m002_getCharsetFromContentType(cv);
        m003_normalizeMimeType(cv);
        m004_addMimeMapping(cv);
        m005_getMimeByExtension(cv);
        m006_getMimeMap(cv);
        m007_setMimeMap(cv);
    }
    public static void f000_CACHE(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/MimeTypes;","CACHE","Lorg/mortbay/io/BufferCache;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001_FORM_ENCODED(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/MimeTypes;","FORM_ENCODED","Ljava/lang/String;"), "application/x-www-form-urlencoded");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002_FORM_ENCODED_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/MimeTypes;","FORM_ENCODED_BUFFER","Lorg/mortbay/io/BufferCache$CachedBuffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003_FORM_ENCODED_ORDINAL(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/MimeTypes;","FORM_ENCODED_ORDINAL","I"),  Integer.valueOf(1));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f004_MESSAGE_HTTP(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/MimeTypes;","MESSAGE_HTTP","Ljava/lang/String;"), "message/http");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f005_MESSAGE_HTTP_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/MimeTypes;","MESSAGE_HTTP_BUFFER","Lorg/mortbay/io/BufferCache$CachedBuffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f006_MESSAGE_HTTP_ORDINAL(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/MimeTypes;","MESSAGE_HTTP_ORDINAL","I"),  Integer.valueOf(2));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f007_MULTIPART_BYTERANGES(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/MimeTypes;","MULTIPART_BYTERANGES","Ljava/lang/String;"), "multipart/byteranges");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f008_MULTIPART_BYTERANGES_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/MimeTypes;","MULTIPART_BYTERANGES_BUFFER","Lorg/mortbay/io/BufferCache$CachedBuffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f009_MULTIPART_BYTERANGES_ORDINAL(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/MimeTypes;","MULTIPART_BYTERANGES_ORDINAL","I"),  Integer.valueOf(3));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f010_TEXT_HTML(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/MimeTypes;","TEXT_HTML","Ljava/lang/String;"), "text/html");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f011_TEXT_HTML_8859_1(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/MimeTypes;","TEXT_HTML_8859_1","Ljava/lang/String;"), "text/html; charset=iso-8859-1");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f012_TEXT_HTML_8859_1_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/MimeTypes;","TEXT_HTML_8859_1_BUFFER","Lorg/mortbay/io/BufferCache$CachedBuffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f013_TEXT_HTML_8859_1_ORDINAL(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/MimeTypes;","TEXT_HTML_8859_1_ORDINAL","I"),  Integer.valueOf(7));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f014_TEXT_HTML_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/MimeTypes;","TEXT_HTML_BUFFER","Lorg/mortbay/io/BufferCache$CachedBuffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f015_TEXT_HTML_ORDINAL(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/MimeTypes;","TEXT_HTML_ORDINAL","I"),  Integer.valueOf(4));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f016_TEXT_HTML_UTF_8(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/MimeTypes;","TEXT_HTML_UTF_8","Ljava/lang/String;"), "text/html; charset=utf-8");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f017_TEXT_HTML_UTF_8_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/MimeTypes;","TEXT_HTML_UTF_8_BUFFER","Lorg/mortbay/io/BufferCache$CachedBuffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f018_TEXT_HTML_UTF_8_ORDINAL(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/MimeTypes;","TEXT_HTML_UTF_8_ORDINAL","I"),  Integer.valueOf(10));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f019_TEXT_JSON(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/MimeTypes;","TEXT_JSON","Ljava/lang/String;"), "text/json");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f020_TEXT_JSON_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/MimeTypes;","TEXT_JSON_BUFFER","Lorg/mortbay/io/BufferCache$CachedBuffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f021_TEXT_JSON_ORDINAL(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/MimeTypes;","TEXT_JSON_ORDINAL","I"),  Integer.valueOf(13));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f022_TEXT_JSON_UTF_8(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/MimeTypes;","TEXT_JSON_UTF_8","Ljava/lang/String;"), "text/json;charset=UTF-8");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f023_TEXT_JSON_UTF_8_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/MimeTypes;","TEXT_JSON_UTF_8_BUFFER","Lorg/mortbay/io/BufferCache$CachedBuffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f024_TEXT_JSON_UTF_8_ORDINAL(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/MimeTypes;","TEXT_JSON_UTF_8_ORDINAL","I"),  Integer.valueOf(14));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f025_TEXT_PLAIN(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/MimeTypes;","TEXT_PLAIN","Ljava/lang/String;"), "text/plain");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f026_TEXT_PLAIN_8859_1(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/MimeTypes;","TEXT_PLAIN_8859_1","Ljava/lang/String;"), "text/plain; charset=iso-8859-1");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f027_TEXT_PLAIN_8859_1_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/MimeTypes;","TEXT_PLAIN_8859_1_BUFFER","Lorg/mortbay/io/BufferCache$CachedBuffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f028_TEXT_PLAIN_8859_1_ORDINAL(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/MimeTypes;","TEXT_PLAIN_8859_1_ORDINAL","I"),  Integer.valueOf(8));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f029_TEXT_PLAIN_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/MimeTypes;","TEXT_PLAIN_BUFFER","Lorg/mortbay/io/BufferCache$CachedBuffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f030_TEXT_PLAIN_ORDINAL(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/MimeTypes;","TEXT_PLAIN_ORDINAL","I"),  Integer.valueOf(5));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f031_TEXT_PLAIN_UTF_8(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/MimeTypes;","TEXT_PLAIN_UTF_8","Ljava/lang/String;"), "text/plain; charset=utf-8");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f032_TEXT_PLAIN_UTF_8_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/MimeTypes;","TEXT_PLAIN_UTF_8_BUFFER","Lorg/mortbay/io/BufferCache$CachedBuffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f033_TEXT_PLAIN_UTF_8_ORDINAL(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/MimeTypes;","TEXT_PLAIN_UTF_8_ORDINAL","I"),  Integer.valueOf(11));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f034_TEXT_XML(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/MimeTypes;","TEXT_XML","Ljava/lang/String;"), "text/xml");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f035_TEXT_XML_8859_1(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/MimeTypes;","TEXT_XML_8859_1","Ljava/lang/String;"), "text/xml; charset=iso-8859-1");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f036_TEXT_XML_8859_1_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/MimeTypes;","TEXT_XML_8859_1_BUFFER","Lorg/mortbay/io/BufferCache$CachedBuffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f037_TEXT_XML_8859_1_ORDINAL(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/MimeTypes;","TEXT_XML_8859_1_ORDINAL","I"),  Integer.valueOf(9));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f038_TEXT_XML_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/MimeTypes;","TEXT_XML_BUFFER","Lorg/mortbay/io/BufferCache$CachedBuffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f039_TEXT_XML_ORDINAL(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/MimeTypes;","TEXT_XML_ORDINAL","I"),  Integer.valueOf(6));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f040_TEXT_XML_UTF_8(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/MimeTypes;","TEXT_XML_UTF_8","Ljava/lang/String;"), "text/xml; charset=utf-8");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f041_TEXT_XML_UTF_8_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/MimeTypes;","TEXT_XML_UTF_8_BUFFER","Lorg/mortbay/io/BufferCache$CachedBuffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f042_TEXT_XML_UTF_8_ORDINAL(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/MimeTypes;","TEXT_XML_UTF_8_ORDINAL","I"),  Integer.valueOf(12));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f043___dftMimeMap(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/MimeTypes;","__dftMimeMap","Ljava/util/Map;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f044___encodings(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/MimeTypes;","__encodings","Ljava/util/Map;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f045___index(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC, new Field("Lorg/mortbay/jetty/MimeTypes;","__index","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f046__mimeMap(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/MimeTypes;","_mimeMap","Ljava/util/Map;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__clinit_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/MimeTypes;","<clinit>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(16);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/lang/Exception;"});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                DexLabel L5=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L5},new String[]{ "Ljava/lang/Exception;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L6=new DexLabel();
                ddv.visitPrologue(L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(76,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(78,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(81,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(82,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(83,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(85,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(86,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(87,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(89,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(90,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(91,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(92,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(93,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(94,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(96,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(97,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(102,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(103,L24);
                ddv.visitLineNumber(108,L0);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(109,L25);
                ddv.visitStartLocal(4,L25,"is","Ljava/io/InputStream;",null);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(110,L26);
                ddv.visitStartLocal(6,L26,"mime","Ljava/util/ResourceBundle;",null);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(111,L27);
                ddv.visitStartLocal(3,L27,"i","Ljava/util/Enumeration;",null);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(113,L28);
                DexLabel L29=new DexLabel();
                ddv.visitLineNumber(114,L29);
                ddv.visitStartLocal(2,L29,"ext","Ljava/lang/String;",null);
                DexLabel L30=new DexLabel();
                ddv.visitLineNumber(115,L30);
                ddv.visitStartLocal(5,L30,"m","Ljava/lang/String;",null);
                ddv.visitLineNumber(118,L2);
                ddv.visitEndLocal(4,L2);
                ddv.visitEndLocal(6,L2);
                ddv.visitEndLocal(3,L2);
                ddv.visitEndLocal(2,L2);
                ddv.visitEndLocal(5,L2);
                DexLabel L31=new DexLabel();
                ddv.visitLineNumber(120,L31);
                ddv.visitStartLocal(0,L31,"e","Ljava/lang/Exception;",null);
                DexLabel L32=new DexLabel();
                ddv.visitLineNumber(121,L32);
                ddv.visitLineNumber(126,L3);
                ddv.visitEndLocal(0,L3);
                DexLabel L33=new DexLabel();
                ddv.visitLineNumber(127,L33);
                ddv.visitRestartLocal(4,L33);
                DexLabel L34=new DexLabel();
                ddv.visitLineNumber(128,L34);
                ddv.visitStartLocal(1,L34,"encoding","Ljava/util/ResourceBundle;",null);
                DexLabel L35=new DexLabel();
                ddv.visitLineNumber(129,L35);
                ddv.visitRestartLocal(3,L35);
                DexLabel L36=new DexLabel();
                ddv.visitLineNumber(131,L36);
                DexLabel L37=new DexLabel();
                ddv.visitLineNumber(132,L37);
                ddv.visitStartLocal(7,L37,"type","Lorg/mortbay/io/Buffer;",null);
                ddv.visitLineNumber(135,L5);
                ddv.visitEndLocal(4,L5);
                ddv.visitEndLocal(1,L5);
                ddv.visitEndLocal(3,L5);
                ddv.visitEndLocal(7,L5);
                DexLabel L38=new DexLabel();
                ddv.visitLineNumber(137,L38);
                ddv.visitRestartLocal(0,L38);
                DexLabel L39=new DexLabel();
                ddv.visitLineNumber(138,L39);
                DexLabel L40=new DexLabel();
                ddv.visitLineNumber(142,L40);
                ddv.visitEndLocal(0,L40);
                DexLabel L41=new DexLabel();
                ddv.visitLineNumber(143,L41);
                DexLabel L42=new DexLabel();
                ddv.visitLineNumber(144,L42);
                DexLabel L43=new DexLabel();
                ddv.visitLineNumber(145,L43);
                DexLabel L44=new DexLabel();
                ddv.visitLineNumber(146,L44);
                DexLabel L45=new DexLabel();
                ddv.visitLineNumber(147,L45);
                DexLabel L46=new DexLabel();
                ddv.visitLineNumber(148,L46);
                DexLabel L47=new DexLabel();
                ddv.visitLineNumber(149,L47);
                DexLabel L48=new DexLabel();
                ddv.visitLineNumber(150,L48);
                DexLabel L49=new DexLabel();
                ddv.visitLineNumber(152,L49);
                DexLabel L50=new DexLabel();
                ddv.visitLineNumber(153,L50);
                DexLabel L51=new DexLabel();
                ddv.visitLineNumber(154,L51);
                DexLabel L52=new DexLabel();
                ddv.visitLineNumber(155,L52);
                DexLabel L53=new DexLabel();
                ddv.visitLineNumber(156,L53);
                DexLabel L54=new DexLabel();
                ddv.visitLineNumber(157,L54);
                DexLabel L55=new DexLabel();
                ddv.visitLineNumber(158,L55);
                DexLabel L56=new DexLabel();
                ddv.visitLineNumber(159,L56);
                DexLabel L57=new DexLabel();
                ddv.visitLineNumber(160,L57);
                DexLabel L58=new DexLabel();
                ddv.visitLineNumber(161,L58);
                DexLabel L59=new DexLabel();
                ddv.visitLineNumber(162,L59);
                DexLabel L60=new DexLabel();
                ddv.visitLineNumber(164,L60);
                DexLabel L61=new DexLabel();
                ddv.visitLineNumber(165,L61);
                DexLabel L62=new DexLabel();
                ddv.visitLineNumber(166,L62);
                DexLabel L63=new DexLabel();
                ddv.visitLineNumber(167,L63);
                DexLabel L64=new DexLabel();
                ddv.visitLineNumber(168,L64);
                code.visitLabel(L6);
                code.visitConstStmt(CONST_STRING,15,"ISO_8859_1");
                code.visitConstStmt(CONST_STRING,14,"ISO-8859-1");
                code.visitConstStmt(CONST_STRING,13,"utf-8");
                code.visitConstStmt(CONST_STRING,12,"UTF8");
                code.visitConstStmt(CONST_STRING,11,"UTF-8");
                code.visitLabel(L7);
                code.visitConstStmt(CONST_16,8, Integer.valueOf(15)); // int: 0x0000000f  float:0.000000
                code.visitFieldStmt(SPUT,8,-1,new Field("Lorg/mortbay/jetty/MimeTypes;","__index","I"));
                code.visitLabel(L8);
                code.visitTypeStmt(NEW_INSTANCE,8,-1,"Lorg/mortbay/io/BufferCache;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 8},new Method("Lorg/mortbay/io/BufferCache;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(SPUT_OBJECT,8,-1,new Field("Lorg/mortbay/jetty/MimeTypes;","CACHE","Lorg/mortbay/io/BufferCache;"));
                code.visitLabel(L9);
                code.visitFieldStmt(SGET_OBJECT,8,-1,new Field("Lorg/mortbay/jetty/MimeTypes;","CACHE","Lorg/mortbay/io/BufferCache;"));
                code.visitConstStmt(CONST_STRING,9,"application/x-www-form-urlencoded");
                code.visitConstStmt(CONST_4,10, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,9,10},new Method("Lorg/mortbay/io/BufferCache;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitFieldStmt(SPUT_OBJECT,8,-1,new Field("Lorg/mortbay/jetty/MimeTypes;","FORM_ENCODED_BUFFER","Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitLabel(L10);
                code.visitFieldStmt(SGET_OBJECT,8,-1,new Field("Lorg/mortbay/jetty/MimeTypes;","CACHE","Lorg/mortbay/io/BufferCache;"));
                code.visitConstStmt(CONST_STRING,9,"message/http");
                code.visitConstStmt(CONST_4,10, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,9,10},new Method("Lorg/mortbay/io/BufferCache;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitFieldStmt(SPUT_OBJECT,8,-1,new Field("Lorg/mortbay/jetty/MimeTypes;","MESSAGE_HTTP_BUFFER","Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitLabel(L11);
                code.visitFieldStmt(SGET_OBJECT,8,-1,new Field("Lorg/mortbay/jetty/MimeTypes;","CACHE","Lorg/mortbay/io/BufferCache;"));
                code.visitConstStmt(CONST_STRING,9,"multipart/byteranges");
                code.visitConstStmt(CONST_4,10, Integer.valueOf(3)); // int: 0x00000003  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,9,10},new Method("Lorg/mortbay/io/BufferCache;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitFieldStmt(SPUT_OBJECT,8,-1,new Field("Lorg/mortbay/jetty/MimeTypes;","MULTIPART_BYTERANGES_BUFFER","Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitLabel(L12);
                code.visitFieldStmt(SGET_OBJECT,8,-1,new Field("Lorg/mortbay/jetty/MimeTypes;","CACHE","Lorg/mortbay/io/BufferCache;"));
                code.visitConstStmt(CONST_STRING,9,"text/html");
                code.visitConstStmt(CONST_4,10, Integer.valueOf(4)); // int: 0x00000004  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,9,10},new Method("Lorg/mortbay/io/BufferCache;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitFieldStmt(SPUT_OBJECT,8,-1,new Field("Lorg/mortbay/jetty/MimeTypes;","TEXT_HTML_BUFFER","Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitLabel(L13);
                code.visitFieldStmt(SGET_OBJECT,8,-1,new Field("Lorg/mortbay/jetty/MimeTypes;","CACHE","Lorg/mortbay/io/BufferCache;"));
                code.visitConstStmt(CONST_STRING,9,"text/plain");
                code.visitConstStmt(CONST_4,10, Integer.valueOf(5)); // int: 0x00000005  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,9,10},new Method("Lorg/mortbay/io/BufferCache;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitFieldStmt(SPUT_OBJECT,8,-1,new Field("Lorg/mortbay/jetty/MimeTypes;","TEXT_PLAIN_BUFFER","Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitLabel(L14);
                code.visitFieldStmt(SGET_OBJECT,8,-1,new Field("Lorg/mortbay/jetty/MimeTypes;","CACHE","Lorg/mortbay/io/BufferCache;"));
                code.visitConstStmt(CONST_STRING,9,"text/xml");
                code.visitConstStmt(CONST_4,10, Integer.valueOf(6)); // int: 0x00000006  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,9,10},new Method("Lorg/mortbay/io/BufferCache;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitFieldStmt(SPUT_OBJECT,8,-1,new Field("Lorg/mortbay/jetty/MimeTypes;","TEXT_XML_BUFFER","Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitLabel(L15);
                code.visitTypeStmt(NEW_INSTANCE,8,-1,"Lorg/mortbay/io/BufferCache$CachedBuffer;");
                code.visitConstStmt(CONST_STRING,9,"text/html; charset=iso-8859-1");
                code.visitConstStmt(CONST_4,10, Integer.valueOf(7)); // int: 0x00000007  float:0.000000
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 8,9,10},new Method("Lorg/mortbay/io/BufferCache$CachedBuffer;","<init>",new String[]{ "Ljava/lang/String;","I"},"V"));
                code.visitFieldStmt(SPUT_OBJECT,8,-1,new Field("Lorg/mortbay/jetty/MimeTypes;","TEXT_HTML_8859_1_BUFFER","Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitLabel(L16);
                code.visitTypeStmt(NEW_INSTANCE,8,-1,"Lorg/mortbay/io/BufferCache$CachedBuffer;");
                code.visitConstStmt(CONST_STRING,9,"text/plain; charset=iso-8859-1");
                code.visitConstStmt(CONST_16,10, Integer.valueOf(8)); // int: 0x00000008  float:0.000000
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 8,9,10},new Method("Lorg/mortbay/io/BufferCache$CachedBuffer;","<init>",new String[]{ "Ljava/lang/String;","I"},"V"));
                code.visitFieldStmt(SPUT_OBJECT,8,-1,new Field("Lorg/mortbay/jetty/MimeTypes;","TEXT_PLAIN_8859_1_BUFFER","Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitLabel(L17);
                code.visitTypeStmt(NEW_INSTANCE,8,-1,"Lorg/mortbay/io/BufferCache$CachedBuffer;");
                code.visitConstStmt(CONST_STRING,9,"text/xml; charset=iso-8859-1");
                code.visitConstStmt(CONST_16,10, Integer.valueOf(9)); // int: 0x00000009  float:0.000000
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 8,9,10},new Method("Lorg/mortbay/io/BufferCache$CachedBuffer;","<init>",new String[]{ "Ljava/lang/String;","I"},"V"));
                code.visitFieldStmt(SPUT_OBJECT,8,-1,new Field("Lorg/mortbay/jetty/MimeTypes;","TEXT_XML_8859_1_BUFFER","Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitLabel(L18);
                code.visitTypeStmt(NEW_INSTANCE,8,-1,"Lorg/mortbay/io/BufferCache$CachedBuffer;");
                code.visitConstStmt(CONST_STRING,9,"text/html; charset=utf-8");
                code.visitConstStmt(CONST_16,10, Integer.valueOf(10)); // int: 0x0000000a  float:0.000000
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 8,9,10},new Method("Lorg/mortbay/io/BufferCache$CachedBuffer;","<init>",new String[]{ "Ljava/lang/String;","I"},"V"));
                code.visitFieldStmt(SPUT_OBJECT,8,-1,new Field("Lorg/mortbay/jetty/MimeTypes;","TEXT_HTML_UTF_8_BUFFER","Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitLabel(L19);
                code.visitTypeStmt(NEW_INSTANCE,8,-1,"Lorg/mortbay/io/BufferCache$CachedBuffer;");
                code.visitConstStmt(CONST_STRING,9,"text/plain; charset=utf-8");
                code.visitConstStmt(CONST_16,10, Integer.valueOf(11)); // int: 0x0000000b  float:0.000000
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 8,9,10},new Method("Lorg/mortbay/io/BufferCache$CachedBuffer;","<init>",new String[]{ "Ljava/lang/String;","I"},"V"));
                code.visitFieldStmt(SPUT_OBJECT,8,-1,new Field("Lorg/mortbay/jetty/MimeTypes;","TEXT_PLAIN_UTF_8_BUFFER","Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitLabel(L20);
                code.visitTypeStmt(NEW_INSTANCE,8,-1,"Lorg/mortbay/io/BufferCache$CachedBuffer;");
                code.visitConstStmt(CONST_STRING,9,"text/xml; charset=utf-8");
                code.visitConstStmt(CONST_16,10, Integer.valueOf(12)); // int: 0x0000000c  float:0.000000
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 8,9,10},new Method("Lorg/mortbay/io/BufferCache$CachedBuffer;","<init>",new String[]{ "Ljava/lang/String;","I"},"V"));
                code.visitFieldStmt(SPUT_OBJECT,8,-1,new Field("Lorg/mortbay/jetty/MimeTypes;","TEXT_XML_UTF_8_BUFFER","Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitLabel(L21);
                code.visitFieldStmt(SGET_OBJECT,8,-1,new Field("Lorg/mortbay/jetty/MimeTypes;","CACHE","Lorg/mortbay/io/BufferCache;"));
                code.visitConstStmt(CONST_STRING,9,"text/json");
                code.visitConstStmt(CONST_16,10, Integer.valueOf(13)); // int: 0x0000000d  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,9,10},new Method("Lorg/mortbay/io/BufferCache;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitFieldStmt(SPUT_OBJECT,8,-1,new Field("Lorg/mortbay/jetty/MimeTypes;","TEXT_JSON_BUFFER","Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitLabel(L22);
                code.visitFieldStmt(SGET_OBJECT,8,-1,new Field("Lorg/mortbay/jetty/MimeTypes;","CACHE","Lorg/mortbay/io/BufferCache;"));
                code.visitConstStmt(CONST_STRING,9,"text/json;charset=UTF-8");
                code.visitConstStmt(CONST_16,10, Integer.valueOf(14)); // int: 0x0000000e  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,9,10},new Method("Lorg/mortbay/io/BufferCache;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitFieldStmt(SPUT_OBJECT,8,-1,new Field("Lorg/mortbay/jetty/MimeTypes;","TEXT_JSON_UTF_8_BUFFER","Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitLabel(L23);
                code.visitTypeStmt(NEW_INSTANCE,8,-1,"Ljava/util/HashMap;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 8},new Method("Ljava/util/HashMap;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(SPUT_OBJECT,8,-1,new Field("Lorg/mortbay/jetty/MimeTypes;","__dftMimeMap","Ljava/util/Map;"));
                code.visitLabel(L24);
                code.visitTypeStmt(NEW_INSTANCE,8,-1,"Ljava/util/HashMap;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 8},new Method("Ljava/util/HashMap;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(SPUT_OBJECT,8,-1,new Field("Lorg/mortbay/jetty/MimeTypes;","__encodings","Ljava/util/Map;"));
                code.visitLabel(L0);
                code.visitConstStmt(CONST_CLASS,8,new DexType("Lorg/mortbay/jetty/MimeTypes;"));
                code.visitConstStmt(CONST_STRING,9,"/org/mortbay/jetty/mime.properties");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,9},new Method("Ljava/lang/Class;","getResourceAsStream",new String[]{ "Ljava/lang/String;"},"Ljava/io/InputStream;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitLabel(L25);
                code.visitTypeStmt(NEW_INSTANCE,6,-1,"Ljava/util/PropertyResourceBundle;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 6,4},new Method("Ljava/util/PropertyResourceBundle;","<init>",new String[]{ "Ljava/io/InputStream;"},"V"));
                code.visitLabel(L26);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/util/ResourceBundle;","getKeys",new String[]{ },"Ljava/util/Enumeration;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitLabel(L27);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3},new Method("Ljava/util/Enumeration;","hasMoreElements",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitJumpStmt(IF_EQZ,8,-1,L3);
                code.visitLabel(L28);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3},new Method("Ljava/util/Enumeration;","nextElement",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitTypeStmt(CHECK_CAST,2,-1,"Ljava/lang/String;");
                code.visitLabel(L29);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,2},new Method("Ljava/util/ResourceBundle;","getString",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitLabel(L30);
                code.visitFieldStmt(SGET_OBJECT,8,-1,new Field("Lorg/mortbay/jetty/MimeTypes;","__dftMimeMap","Ljava/util/Map;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2},new Method("Lorg/mortbay/util/StringUtil;","asciiToLowerCase",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 5},new Method("Lorg/mortbay/jetty/MimeTypes;","normalizeMimeType",new String[]{ "Ljava/lang/String;"},"Lorg/mortbay/io/Buffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,10);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 8,9,10},new Method("Ljava/util/Map;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L1);
                code.visitJumpStmt(GOTO,-1,-1,L27);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,8);
                code.visitStmt2R(MOVE_OBJECT,0,8);
                code.visitLabel(L31);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/Exception;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 8},new Method("Lorg/mortbay/log/Log;","warn",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L32);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitLabel(L3);
                code.visitConstStmt(CONST_CLASS,8,new DexType("Lorg/mortbay/jetty/MimeTypes;"));
                code.visitConstStmt(CONST_STRING,9,"/org/mortbay/jetty/encoding.properties");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,9},new Method("Ljava/lang/Class;","getResourceAsStream",new String[]{ "Ljava/lang/String;"},"Ljava/io/InputStream;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitLabel(L33);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/util/PropertyResourceBundle;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,4},new Method("Ljava/util/PropertyResourceBundle;","<init>",new String[]{ "Ljava/io/InputStream;"},"V"));
                code.visitLabel(L34);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/util/ResourceBundle;","getKeys",new String[]{ },"Ljava/util/Enumeration;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitLabel(L35);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3},new Method("Ljava/util/Enumeration;","hasMoreElements",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitJumpStmt(IF_EQZ,8,-1,L40);
                code.visitLabel(L36);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3},new Method("Ljava/util/Enumeration;","nextElement",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Ljava/lang/String;");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/jetty/MimeTypes;","normalizeMimeType",new String[]{ "Ljava/lang/String;"},"Lorg/mortbay/io/Buffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitLabel(L37);
                code.visitFieldStmt(SGET_OBJECT,8,-1,new Field("Lorg/mortbay/jetty/MimeTypes;","__encodings","Ljava/util/Map;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Ljava/lang/Object;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,9},new Method("Ljava/util/ResourceBundle;","getString",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 8,7,9},new Method("Ljava/util/Map;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L4);
                code.visitJumpStmt(GOTO,-1,-1,L35);
                code.visitLabel(L5);
                code.visitStmt1R(MOVE_EXCEPTION,8);
                code.visitStmt2R(MOVE_OBJECT,0,8);
                code.visitLabel(L38);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/Exception;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 8},new Method("Lorg/mortbay/log/Log;","warn",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L39);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitLabel(L40);
                code.visitFieldStmt(SGET_OBJECT,8,-1,new Field("Lorg/mortbay/jetty/MimeTypes;","TEXT_HTML_BUFFER","Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitConstStmt(CONST_STRING,9,"ISO-8859-1");
                code.visitFieldStmt(SGET_OBJECT,9,-1,new Field("Lorg/mortbay/jetty/MimeTypes;","TEXT_HTML_8859_1_BUFFER","Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,14,9},new Method("Lorg/mortbay/io/BufferCache$CachedBuffer;","setAssociate",new String[]{ "Ljava/lang/Object;","Lorg/mortbay/io/BufferCache$CachedBuffer;"},"V"));
                code.visitLabel(L41);
                code.visitFieldStmt(SGET_OBJECT,8,-1,new Field("Lorg/mortbay/jetty/MimeTypes;","TEXT_HTML_BUFFER","Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitConstStmt(CONST_STRING,9,"ISO_8859_1");
                code.visitFieldStmt(SGET_OBJECT,9,-1,new Field("Lorg/mortbay/jetty/MimeTypes;","TEXT_HTML_8859_1_BUFFER","Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,15,9},new Method("Lorg/mortbay/io/BufferCache$CachedBuffer;","setAssociate",new String[]{ "Ljava/lang/Object;","Lorg/mortbay/io/BufferCache$CachedBuffer;"},"V"));
                code.visitLabel(L42);
                code.visitFieldStmt(SGET_OBJECT,8,-1,new Field("Lorg/mortbay/jetty/MimeTypes;","TEXT_HTML_BUFFER","Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitConstStmt(CONST_STRING,9,"iso-8859-1");
                code.visitFieldStmt(SGET_OBJECT,10,-1,new Field("Lorg/mortbay/jetty/MimeTypes;","TEXT_HTML_8859_1_BUFFER","Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,9,10},new Method("Lorg/mortbay/io/BufferCache$CachedBuffer;","setAssociate",new String[]{ "Ljava/lang/Object;","Lorg/mortbay/io/BufferCache$CachedBuffer;"},"V"));
                code.visitLabel(L43);
                code.visitFieldStmt(SGET_OBJECT,8,-1,new Field("Lorg/mortbay/jetty/MimeTypes;","TEXT_PLAIN_BUFFER","Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitConstStmt(CONST_STRING,9,"ISO-8859-1");
                code.visitFieldStmt(SGET_OBJECT,9,-1,new Field("Lorg/mortbay/jetty/MimeTypes;","TEXT_PLAIN_8859_1_BUFFER","Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,14,9},new Method("Lorg/mortbay/io/BufferCache$CachedBuffer;","setAssociate",new String[]{ "Ljava/lang/Object;","Lorg/mortbay/io/BufferCache$CachedBuffer;"},"V"));
                code.visitLabel(L44);
                code.visitFieldStmt(SGET_OBJECT,8,-1,new Field("Lorg/mortbay/jetty/MimeTypes;","TEXT_PLAIN_BUFFER","Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitConstStmt(CONST_STRING,9,"ISO_8859_1");
                code.visitFieldStmt(SGET_OBJECT,9,-1,new Field("Lorg/mortbay/jetty/MimeTypes;","TEXT_PLAIN_8859_1_BUFFER","Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,15,9},new Method("Lorg/mortbay/io/BufferCache$CachedBuffer;","setAssociate",new String[]{ "Ljava/lang/Object;","Lorg/mortbay/io/BufferCache$CachedBuffer;"},"V"));
                code.visitLabel(L45);
                code.visitFieldStmt(SGET_OBJECT,8,-1,new Field("Lorg/mortbay/jetty/MimeTypes;","TEXT_PLAIN_BUFFER","Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitConstStmt(CONST_STRING,9,"iso-8859-1");
                code.visitFieldStmt(SGET_OBJECT,10,-1,new Field("Lorg/mortbay/jetty/MimeTypes;","TEXT_PLAIN_8859_1_BUFFER","Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,9,10},new Method("Lorg/mortbay/io/BufferCache$CachedBuffer;","setAssociate",new String[]{ "Ljava/lang/Object;","Lorg/mortbay/io/BufferCache$CachedBuffer;"},"V"));
                code.visitLabel(L46);
                code.visitFieldStmt(SGET_OBJECT,8,-1,new Field("Lorg/mortbay/jetty/MimeTypes;","TEXT_XML_BUFFER","Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitConstStmt(CONST_STRING,9,"ISO-8859-1");
                code.visitFieldStmt(SGET_OBJECT,9,-1,new Field("Lorg/mortbay/jetty/MimeTypes;","TEXT_XML_8859_1_BUFFER","Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,14,9},new Method("Lorg/mortbay/io/BufferCache$CachedBuffer;","setAssociate",new String[]{ "Ljava/lang/Object;","Lorg/mortbay/io/BufferCache$CachedBuffer;"},"V"));
                code.visitLabel(L47);
                code.visitFieldStmt(SGET_OBJECT,8,-1,new Field("Lorg/mortbay/jetty/MimeTypes;","TEXT_XML_BUFFER","Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitConstStmt(CONST_STRING,9,"ISO_8859_1");
                code.visitFieldStmt(SGET_OBJECT,9,-1,new Field("Lorg/mortbay/jetty/MimeTypes;","TEXT_XML_8859_1_BUFFER","Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,15,9},new Method("Lorg/mortbay/io/BufferCache$CachedBuffer;","setAssociate",new String[]{ "Ljava/lang/Object;","Lorg/mortbay/io/BufferCache$CachedBuffer;"},"V"));
                code.visitLabel(L48);
                code.visitFieldStmt(SGET_OBJECT,8,-1,new Field("Lorg/mortbay/jetty/MimeTypes;","TEXT_XML_BUFFER","Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitConstStmt(CONST_STRING,9,"iso-8859-1");
                code.visitFieldStmt(SGET_OBJECT,10,-1,new Field("Lorg/mortbay/jetty/MimeTypes;","TEXT_XML_8859_1_BUFFER","Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,9,10},new Method("Lorg/mortbay/io/BufferCache$CachedBuffer;","setAssociate",new String[]{ "Ljava/lang/Object;","Lorg/mortbay/io/BufferCache$CachedBuffer;"},"V"));
                code.visitLabel(L49);
                code.visitFieldStmt(SGET_OBJECT,8,-1,new Field("Lorg/mortbay/jetty/MimeTypes;","TEXT_HTML_BUFFER","Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitConstStmt(CONST_STRING,9,"UTF-8");
                code.visitFieldStmt(SGET_OBJECT,9,-1,new Field("Lorg/mortbay/jetty/MimeTypes;","TEXT_HTML_UTF_8_BUFFER","Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,11,9},new Method("Lorg/mortbay/io/BufferCache$CachedBuffer;","setAssociate",new String[]{ "Ljava/lang/Object;","Lorg/mortbay/io/BufferCache$CachedBuffer;"},"V"));
                code.visitLabel(L50);
                code.visitFieldStmt(SGET_OBJECT,8,-1,new Field("Lorg/mortbay/jetty/MimeTypes;","TEXT_HTML_BUFFER","Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitConstStmt(CONST_STRING,9,"UTF8");
                code.visitFieldStmt(SGET_OBJECT,9,-1,new Field("Lorg/mortbay/jetty/MimeTypes;","TEXT_HTML_UTF_8_BUFFER","Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,12,9},new Method("Lorg/mortbay/io/BufferCache$CachedBuffer;","setAssociate",new String[]{ "Ljava/lang/Object;","Lorg/mortbay/io/BufferCache$CachedBuffer;"},"V"));
                code.visitLabel(L51);
                code.visitFieldStmt(SGET_OBJECT,8,-1,new Field("Lorg/mortbay/jetty/MimeTypes;","TEXT_HTML_BUFFER","Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitConstStmt(CONST_STRING,9,"utf8");
                code.visitFieldStmt(SGET_OBJECT,10,-1,new Field("Lorg/mortbay/jetty/MimeTypes;","TEXT_HTML_UTF_8_BUFFER","Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,9,10},new Method("Lorg/mortbay/io/BufferCache$CachedBuffer;","setAssociate",new String[]{ "Ljava/lang/Object;","Lorg/mortbay/io/BufferCache$CachedBuffer;"},"V"));
                code.visitLabel(L52);
                code.visitFieldStmt(SGET_OBJECT,8,-1,new Field("Lorg/mortbay/jetty/MimeTypes;","TEXT_HTML_BUFFER","Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitConstStmt(CONST_STRING,9,"utf-8");
                code.visitFieldStmt(SGET_OBJECT,9,-1,new Field("Lorg/mortbay/jetty/MimeTypes;","TEXT_HTML_UTF_8_BUFFER","Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,13,9},new Method("Lorg/mortbay/io/BufferCache$CachedBuffer;","setAssociate",new String[]{ "Ljava/lang/Object;","Lorg/mortbay/io/BufferCache$CachedBuffer;"},"V"));
                code.visitLabel(L53);
                code.visitFieldStmt(SGET_OBJECT,8,-1,new Field("Lorg/mortbay/jetty/MimeTypes;","TEXT_PLAIN_BUFFER","Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitConstStmt(CONST_STRING,9,"UTF-8");
                code.visitFieldStmt(SGET_OBJECT,9,-1,new Field("Lorg/mortbay/jetty/MimeTypes;","TEXT_PLAIN_UTF_8_BUFFER","Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,11,9},new Method("Lorg/mortbay/io/BufferCache$CachedBuffer;","setAssociate",new String[]{ "Ljava/lang/Object;","Lorg/mortbay/io/BufferCache$CachedBuffer;"},"V"));
                code.visitLabel(L54);
                code.visitFieldStmt(SGET_OBJECT,8,-1,new Field("Lorg/mortbay/jetty/MimeTypes;","TEXT_PLAIN_BUFFER","Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitConstStmt(CONST_STRING,9,"UTF8");
                code.visitFieldStmt(SGET_OBJECT,9,-1,new Field("Lorg/mortbay/jetty/MimeTypes;","TEXT_PLAIN_UTF_8_BUFFER","Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,12,9},new Method("Lorg/mortbay/io/BufferCache$CachedBuffer;","setAssociate",new String[]{ "Ljava/lang/Object;","Lorg/mortbay/io/BufferCache$CachedBuffer;"},"V"));
                code.visitLabel(L55);
                code.visitFieldStmt(SGET_OBJECT,8,-1,new Field("Lorg/mortbay/jetty/MimeTypes;","TEXT_PLAIN_BUFFER","Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitConstStmt(CONST_STRING,9,"utf-8");
                code.visitFieldStmt(SGET_OBJECT,9,-1,new Field("Lorg/mortbay/jetty/MimeTypes;","TEXT_PLAIN_UTF_8_BUFFER","Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,13,9},new Method("Lorg/mortbay/io/BufferCache$CachedBuffer;","setAssociate",new String[]{ "Ljava/lang/Object;","Lorg/mortbay/io/BufferCache$CachedBuffer;"},"V"));
                code.visitLabel(L56);
                code.visitFieldStmt(SGET_OBJECT,8,-1,new Field("Lorg/mortbay/jetty/MimeTypes;","TEXT_XML_BUFFER","Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitConstStmt(CONST_STRING,9,"UTF-8");
                code.visitFieldStmt(SGET_OBJECT,9,-1,new Field("Lorg/mortbay/jetty/MimeTypes;","TEXT_XML_UTF_8_BUFFER","Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,11,9},new Method("Lorg/mortbay/io/BufferCache$CachedBuffer;","setAssociate",new String[]{ "Ljava/lang/Object;","Lorg/mortbay/io/BufferCache$CachedBuffer;"},"V"));
                code.visitLabel(L57);
                code.visitFieldStmt(SGET_OBJECT,8,-1,new Field("Lorg/mortbay/jetty/MimeTypes;","TEXT_XML_BUFFER","Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitConstStmt(CONST_STRING,9,"utf8");
                code.visitFieldStmt(SGET_OBJECT,10,-1,new Field("Lorg/mortbay/jetty/MimeTypes;","TEXT_XML_UTF_8_BUFFER","Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,9,10},new Method("Lorg/mortbay/io/BufferCache$CachedBuffer;","setAssociate",new String[]{ "Ljava/lang/Object;","Lorg/mortbay/io/BufferCache$CachedBuffer;"},"V"));
                code.visitLabel(L58);
                code.visitFieldStmt(SGET_OBJECT,8,-1,new Field("Lorg/mortbay/jetty/MimeTypes;","TEXT_XML_BUFFER","Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitConstStmt(CONST_STRING,9,"UTF8");
                code.visitFieldStmt(SGET_OBJECT,9,-1,new Field("Lorg/mortbay/jetty/MimeTypes;","TEXT_XML_UTF_8_BUFFER","Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,12,9},new Method("Lorg/mortbay/io/BufferCache$CachedBuffer;","setAssociate",new String[]{ "Ljava/lang/Object;","Lorg/mortbay/io/BufferCache$CachedBuffer;"},"V"));
                code.visitLabel(L59);
                code.visitFieldStmt(SGET_OBJECT,8,-1,new Field("Lorg/mortbay/jetty/MimeTypes;","TEXT_XML_BUFFER","Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitConstStmt(CONST_STRING,9,"utf-8");
                code.visitFieldStmt(SGET_OBJECT,9,-1,new Field("Lorg/mortbay/jetty/MimeTypes;","TEXT_XML_UTF_8_BUFFER","Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,13,9},new Method("Lorg/mortbay/io/BufferCache$CachedBuffer;","setAssociate",new String[]{ "Ljava/lang/Object;","Lorg/mortbay/io/BufferCache$CachedBuffer;"},"V"));
                code.visitLabel(L60);
                code.visitFieldStmt(SGET_OBJECT,8,-1,new Field("Lorg/mortbay/jetty/MimeTypes;","TEXT_JSON_BUFFER","Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitConstStmt(CONST_STRING,9,"UTF-8");
                code.visitFieldStmt(SGET_OBJECT,9,-1,new Field("Lorg/mortbay/jetty/MimeTypes;","TEXT_JSON_UTF_8_BUFFER","Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,11,9},new Method("Lorg/mortbay/io/BufferCache$CachedBuffer;","setAssociate",new String[]{ "Ljava/lang/Object;","Lorg/mortbay/io/BufferCache$CachedBuffer;"},"V"));
                code.visitLabel(L61);
                code.visitFieldStmt(SGET_OBJECT,8,-1,new Field("Lorg/mortbay/jetty/MimeTypes;","TEXT_JSON_BUFFER","Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitConstStmt(CONST_STRING,9,"utf8");
                code.visitFieldStmt(SGET_OBJECT,10,-1,new Field("Lorg/mortbay/jetty/MimeTypes;","TEXT_JSON_UTF_8_BUFFER","Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,9,10},new Method("Lorg/mortbay/io/BufferCache$CachedBuffer;","setAssociate",new String[]{ "Ljava/lang/Object;","Lorg/mortbay/io/BufferCache$CachedBuffer;"},"V"));
                code.visitLabel(L62);
                code.visitFieldStmt(SGET_OBJECT,8,-1,new Field("Lorg/mortbay/jetty/MimeTypes;","TEXT_JSON_BUFFER","Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitConstStmt(CONST_STRING,9,"UTF8");
                code.visitFieldStmt(SGET_OBJECT,9,-1,new Field("Lorg/mortbay/jetty/MimeTypes;","TEXT_JSON_UTF_8_BUFFER","Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,12,9},new Method("Lorg/mortbay/io/BufferCache$CachedBuffer;","setAssociate",new String[]{ "Ljava/lang/Object;","Lorg/mortbay/io/BufferCache$CachedBuffer;"},"V"));
                code.visitLabel(L63);
                code.visitFieldStmt(SGET_OBJECT,8,-1,new Field("Lorg/mortbay/jetty/MimeTypes;","TEXT_JSON_BUFFER","Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitConstStmt(CONST_STRING,9,"utf-8");
                code.visitFieldStmt(SGET_OBJECT,9,-1,new Field("Lorg/mortbay/jetty/MimeTypes;","TEXT_JSON_UTF_8_BUFFER","Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,13,9},new Method("Lorg/mortbay/io/BufferCache$CachedBuffer;","setAssociate",new String[]{ "Ljava/lang/Object;","Lorg/mortbay/io/BufferCache$CachedBuffer;"},"V"));
                code.visitLabel(L64);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/MimeTypes;","<init>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(178,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(179,L1);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/Object;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_getCharsetFromContentType(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/jetty/MimeTypes;","getCharsetFromContentType",new String[]{ "Lorg/mortbay/io/Buffer;"},"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(13);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"value");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(273,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(275,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(291,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(292,L4);
                ddv.visitStartLocal(3,L4,"i","I",null);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(293,L5);
                ddv.visitStartLocal(2,L5,"end","I",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(294,L6);
                ddv.visitStartLocal(6,L6,"state","I",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(295,L7);
                ddv.visitStartLocal(5,L7,"start","I",null);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(296,L8);
                ddv.visitStartLocal(4,L8,"quote","Z",null);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(298,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(300,L10);
                ddv.visitStartLocal(1,L10,"b","B",null);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(302,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(303,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(296,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(280,L14);
                ddv.visitEndLocal(3,L14);
                ddv.visitEndLocal(2,L14);
                ddv.visitEndLocal(6,L14);
                ddv.visitEndLocal(5,L14);
                ddv.visitEndLocal(4,L14);
                ddv.visitEndLocal(1,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(352,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(287,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(307,L17);
                ddv.visitRestartLocal(1,L17);
                ddv.visitRestartLocal(2,L17);
                ddv.visitRestartLocal(3,L17);
                ddv.visitRestartLocal(4,L17);
                ddv.visitRestartLocal(5,L17);
                ddv.visitRestartLocal(6,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(310,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(312,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(313,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(315,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(316,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(319,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(320,L24);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(321,L25);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(322,L26);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(323,L27);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(324,L28);
                DexLabel L29=new DexLabel();
                ddv.visitLineNumber(325,L29);
                DexLabel L30=new DexLabel();
                ddv.visitLineNumber(327,L30);
                DexLabel L31=new DexLabel();
                ddv.visitLineNumber(330,L31);
                DexLabel L32=new DexLabel();
                ddv.visitLineNumber(332,L32);
                DexLabel L33=new DexLabel();
                ddv.visitLineNumber(334,L33);
                DexLabel L34=new DexLabel();
                ddv.visitLineNumber(335,L34);
                DexLabel L35=new DexLabel();
                ddv.visitLineNumber(336,L35);
                DexLabel L36=new DexLabel();
                ddv.visitLineNumber(337,L36);
                DexLabel L37=new DexLabel();
                ddv.visitLineNumber(339,L37);
                DexLabel L38=new DexLabel();
                ddv.visitLineNumber(340,L38);
                DexLabel L39=new DexLabel();
                ddv.visitLineNumber(341,L39);
                DexLabel L40=new DexLabel();
                ddv.visitLineNumber(344,L40);
                DexLabel L41=new DexLabel();
                ddv.visitLineNumber(346,L41);
                DexLabel L42=new DexLabel();
                ddv.visitLineNumber(350,L42);
                ddv.visitEndLocal(1,L42);
                DexLabel L43=new DexLabel();
                ddv.visitLineNumber(351,L43);
                DexLabel L44=new DexLabel();
                ddv.visitLineNumber(352,L44);
                DexLabel L45=new DexLabel();
                ddv.visitLineNumber(275,L45);
                DexLabel L46=new DexLabel();
                ddv.visitLineNumber(307,L46);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_16,11, Integer.valueOf(59)); // int: 0x0000003b  float:0.000000
                code.visitConstStmt(CONST_16,10, Integer.valueOf(10)); // int: 0x0000000a  float:0.000000
                code.visitConstStmt(CONST_16,9, Integer.valueOf(34)); // int: 0x00000022  float:0.000000
                code.visitConstStmt(CONST_16,8, Integer.valueOf(32)); // int: 0x00000020  float:0.000000
                code.visitLabel(L1);
                code.visitTypeStmt(INSTANCE_OF,7,12,"Lorg/mortbay/io/BufferCache$CachedBuffer;");
                code.visitJumpStmt(IF_EQZ,7,-1,L3);
                code.visitLabel(L2);
                code.visitStmt2R(MOVE_OBJECT,0,12);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Lorg/mortbay/io/BufferCache$CachedBuffer;");
                code.visitStmt2R(MOVE_OBJECT,7,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Lorg/mortbay/io/BufferCache$CachedBuffer;","getOrdinal",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitSparseSwitchStmt(PACKED_SWITCH,7,7,new DexLabel[]{L14,L14,L14,L16,L16,L16,L16,L16});
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 12},new Method("Lorg/mortbay/io/Buffer;","getIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 12},new Method("Lorg/mortbay/io/Buffer;","putIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitLabel(L5);
                code.visitConstStmt(CONST_4,6, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L6);
                code.visitConstStmt(CONST_4,5, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L7);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L8);
                code.visitJumpStmt(IF_GE,3,2,L42);
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 12,3},new Method("Lorg/mortbay/io/Buffer;","peek",new String[]{ "I"},"B"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitLabel(L10);
                code.visitJumpStmt(IF_EQZ,4,-1,L17);
                code.visitJumpStmt(IF_EQ,6,10,L17);
                code.visitLabel(L11);
                code.visitJumpStmt(IF_NE,9,1,L13);
                code.visitLabel(L12);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L13);
                code.visitStmt2R1N(ADD_INT_LIT8,3,3,1);
                code.visitJumpStmt(GOTO,-1,-1,L8);
                code.visitLabel(L14);
                code.visitFieldStmt(SGET_OBJECT,7,-1,new Field("Lorg/mortbay/util/StringUtil;","__ISO_8859_1","Ljava/lang/String;"));
                code.visitLabel(L15);
                code.visitStmt1R(RETURN_OBJECT,7);
                code.visitLabel(L16);
                code.visitConstStmt(CONST_STRING,7,"UTF-8");
                code.visitJumpStmt(GOTO,-1,-1,L15);
                code.visitLabel(L17);
                code.visitSparseSwitchStmt(PACKED_SWITCH,6,0,new DexLabel[]{L18,L23,L24,L25,L26,L27,L28,L29,L30,L31,L40});
                DexLabel L47=new DexLabel();
                code.visitLabel(L47);
                code.visitJumpStmt(GOTO,-1,-1,L13);
                code.visitLabel(L18);
                code.visitJumpStmt(IF_NE,9,1,L21);
                code.visitLabel(L19);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L20);
                code.visitJumpStmt(GOTO,-1,-1,L13);
                code.visitLabel(L21);
                code.visitJumpStmt(IF_NE,11,1,L13);
                code.visitLabel(L22);
                code.visitConstStmt(CONST_4,6, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L13);
                code.visitLabel(L23);
                code.visitConstStmt(CONST_16,7, Integer.valueOf(99)); // int: 0x00000063  float:0.000000
                DexLabel L48=new DexLabel();
                code.visitJumpStmt(IF_NE,7,1,L48);
                code.visitConstStmt(CONST_4,6, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L13);
                code.visitLabel(L48);
                code.visitJumpStmt(IF_EQ,8,1,L13);
                code.visitConstStmt(CONST_4,6, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L13);
                code.visitLabel(L24);
                code.visitConstStmt(CONST_16,7, Integer.valueOf(104)); // int: 0x00000068  float:0.000000
                DexLabel L49=new DexLabel();
                code.visitJumpStmt(IF_NE,7,1,L49);
                code.visitConstStmt(CONST_4,6, Integer.valueOf(3)); // int: 0x00000003  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L13);
                code.visitLabel(L49);
                code.visitConstStmt(CONST_4,6, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L13);
                code.visitLabel(L25);
                code.visitConstStmt(CONST_16,7, Integer.valueOf(97)); // int: 0x00000061  float:0.000000
                DexLabel L50=new DexLabel();
                code.visitJumpStmt(IF_NE,7,1,L50);
                code.visitConstStmt(CONST_4,6, Integer.valueOf(4)); // int: 0x00000004  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L13);
                code.visitLabel(L50);
                code.visitConstStmt(CONST_4,6, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L13);
                code.visitLabel(L26);
                code.visitConstStmt(CONST_16,7, Integer.valueOf(114)); // int: 0x00000072  float:0.000000
                DexLabel L51=new DexLabel();
                code.visitJumpStmt(IF_NE,7,1,L51);
                code.visitConstStmt(CONST_4,6, Integer.valueOf(5)); // int: 0x00000005  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L13);
                code.visitLabel(L51);
                code.visitConstStmt(CONST_4,6, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L13);
                code.visitLabel(L27);
                code.visitConstStmt(CONST_16,7, Integer.valueOf(115)); // int: 0x00000073  float:0.000000
                DexLabel L52=new DexLabel();
                code.visitJumpStmt(IF_NE,7,1,L52);
                code.visitConstStmt(CONST_4,6, Integer.valueOf(6)); // int: 0x00000006  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L13);
                code.visitLabel(L52);
                code.visitConstStmt(CONST_4,6, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L13);
                code.visitLabel(L28);
                code.visitConstStmt(CONST_16,7, Integer.valueOf(101)); // int: 0x00000065  float:0.000000
                DexLabel L53=new DexLabel();
                code.visitJumpStmt(IF_NE,7,1,L53);
                code.visitConstStmt(CONST_4,6, Integer.valueOf(7)); // int: 0x00000007  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L13);
                code.visitLabel(L53);
                code.visitConstStmt(CONST_4,6, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L13);
                code.visitLabel(L29);
                code.visitConstStmt(CONST_16,7, Integer.valueOf(116)); // int: 0x00000074  float:0.000000
                DexLabel L54=new DexLabel();
                code.visitJumpStmt(IF_NE,7,1,L54);
                code.visitConstStmt(CONST_16,6, Integer.valueOf(8)); // int: 0x00000008  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L13);
                code.visitLabel(L54);
                code.visitConstStmt(CONST_4,6, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L13);
                code.visitLabel(L30);
                code.visitConstStmt(CONST_16,7, Integer.valueOf(61)); // int: 0x0000003d  float:0.000000
                DexLabel L55=new DexLabel();
                code.visitJumpStmt(IF_NE,7,1,L55);
                code.visitConstStmt(CONST_16,6, Integer.valueOf(9)); // int: 0x00000009  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L13);
                code.visitLabel(L55);
                code.visitJumpStmt(IF_EQ,8,1,L13);
                code.visitConstStmt(CONST_4,6, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L13);
                code.visitLabel(L31);
                code.visitJumpStmt(IF_EQ,8,1,L13);
                code.visitLabel(L32);
                code.visitJumpStmt(IF_NE,9,1,L37);
                code.visitLabel(L33);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L34);
                code.visitStmt2R1N(ADD_INT_LIT8,5,3,1);
                code.visitLabel(L35);
                code.visitConstStmt(CONST_16,6, Integer.valueOf(10)); // int: 0x0000000a  float:0.000000
                code.visitLabel(L36);
                code.visitJumpStmt(GOTO,-1,-1,L13);
                code.visitLabel(L37);
                code.visitStmt2R(MOVE,5,3);
                code.visitLabel(L38);
                code.visitConstStmt(CONST_16,6, Integer.valueOf(10)); // int: 0x0000000a  float:0.000000
                code.visitLabel(L39);
                code.visitJumpStmt(GOTO,-1,-1,L13);
                code.visitLabel(L40);
                DexLabel L56=new DexLabel();
                code.visitJumpStmt(IF_NEZ,4,-1,L56);
                code.visitJumpStmt(IF_EQ,11,1,L41);
                code.visitJumpStmt(IF_EQ,8,1,L41);
                code.visitLabel(L56);
                code.visitJumpStmt(IF_EQZ,4,-1,L13);
                code.visitJumpStmt(IF_NE,9,1,L13);
                code.visitLabel(L41);
                code.visitFieldStmt(SGET_OBJECT,7,-1,new Field("Lorg/mortbay/jetty/MimeTypes;","CACHE","Lorg/mortbay/io/BufferCache;"));
                code.visitStmt3R(SUB_INT,8,3,5);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 12,5,8},new Method("Lorg/mortbay/io/Buffer;","peek",new String[]{ "I","I"},"Lorg/mortbay/io/Buffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,8},new Method("Lorg/mortbay/io/BufferCache;","lookup",new String[]{ "Lorg/mortbay/io/Buffer;"},"Lorg/mortbay/io/Buffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Ljava/lang/Object;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitJumpStmt(GOTO,-1,-1,L15);
                code.visitLabel(L42);
                code.visitJumpStmt(IF_NE,6,10,L44);
                code.visitLabel(L43);
                code.visitFieldStmt(SGET_OBJECT,7,-1,new Field("Lorg/mortbay/jetty/MimeTypes;","CACHE","Lorg/mortbay/io/BufferCache;"));
                code.visitStmt3R(SUB_INT,8,3,5);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 12,5,8},new Method("Lorg/mortbay/io/Buffer;","peek",new String[]{ "I","I"},"Lorg/mortbay/io/Buffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,8},new Method("Lorg/mortbay/io/BufferCache;","lookup",new String[]{ "Lorg/mortbay/io/Buffer;"},"Lorg/mortbay/io/Buffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Ljava/lang/Object;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitJumpStmt(GOTO_16,-1,-1,L15);
                code.visitLabel(L44);
                code.visitConstStmt(CONST_4,7, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO_16,-1,-1,L15);
                code.visitLabel(L45);
                code.visitLabel(L46);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_normalizeMimeType(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PRIVATE|ACC_STATIC, new Method("Lorg/mortbay/jetty/MimeTypes;","normalizeMimeType",new String[]{ "Ljava/lang/String;"},"Lorg/mortbay/io/Buffer;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"type");
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(264,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(265,L4);
                ddv.visitStartLocal(0,L4,"b","Lorg/mortbay/io/Buffer;",null);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(266,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(267,L6);
                ddv.visitLineNumber(264,L2);
                ddv.visitEndLocal(0,L2);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_CLASS,1,new DexType("Lorg/mortbay/jetty/MimeTypes;"));
                code.visitStmt1R(MONITOR_ENTER,1);
                code.visitLabel(L0);
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/jetty/MimeTypes;","CACHE","Lorg/mortbay/io/BufferCache;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,5},new Method("Lorg/mortbay/io/BufferCache;","get",new String[]{ "Ljava/lang/String;"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L4);
                code.visitJumpStmt(IF_NEZ,0,-1,L6);
                code.visitLabel(L5);
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/jetty/MimeTypes;","CACHE","Lorg/mortbay/io/BufferCache;"));
                code.visitFieldStmt(SGET,3,-1,new Field("Lorg/mortbay/jetty/MimeTypes;","__index","I"));
                code.visitStmt2R1N(ADD_INT_LIT8,4,3,1);
                code.visitFieldStmt(SPUT,4,-1,new Field("Lorg/mortbay/jetty/MimeTypes;","__index","I"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,5,3},new Method("Lorg/mortbay/io/BufferCache;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitLabel(L1);
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L6);
                code.visitStmt1R(MONITOR_EXIT,1);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,2);
                code.visitStmt1R(MONITOR_EXIT,1);
                code.visitStmt1R(THROW,2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_addMimeMapping(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/MimeTypes;","addMimeMapping",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"extension");
                ddv.visitParameterName(1,"type");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(255,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(256,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(258,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(259,L3);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/jetty/MimeTypes;","_mimeMap","Ljava/util/Map;"));
                code.visitJumpStmt(IF_NEZ,0,-1,L2);
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/util/HashMap;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/util/HashMap;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,3,new Field("Lorg/mortbay/jetty/MimeTypes;","_mimeMap","Ljava/util/Map;"));
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/jetty/MimeTypes;","_mimeMap","Ljava/util/Map;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 4},new Method("Lorg/mortbay/util/StringUtil;","asciiToLowerCase",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 5},new Method("Lorg/mortbay/jetty/MimeTypes;","normalizeMimeType",new String[]{ "Ljava/lang/String;"},"Lorg/mortbay/io/Buffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1,2},new Method("Ljava/util/Map;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L3);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_getMimeByExtension(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/MimeTypes;","getMimeByExtension",new String[]{ "Ljava/lang/String;"},"Lorg/mortbay/io/Buffer;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(8);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"filename");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(217,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(219,L2);
                ddv.visitStartLocal(2,L2,"type","Lorg/mortbay/io/Buffer;",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(221,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(222,L4);
                ddv.visitStartLocal(1,L4,"i","I",null);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(224,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(226,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(237,L7);
                ddv.visitEndLocal(1,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(239,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(240,L9);
                DexLabel L10=new DexLabel();
                ddv.visitEndLocal(2,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(241,L11);
                ddv.visitRestartLocal(2,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(242,L12);
                DexLabel L13=new DexLabel();
                ddv.visitEndLocal(2,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(245,L14);
                ddv.visitRestartLocal(2,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(229,L15);
                ddv.visitRestartLocal(1,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(230,L16);
                ddv.visitStartLocal(0,L16,"ext","Ljava/lang/String;",null);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(231,L17);
                DexLabel L18=new DexLabel();
                ddv.visitEndLocal(2,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(232,L19);
                ddv.visitRestartLocal(2,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(233,L20);
                DexLabel L21=new DexLabel();
                ddv.visitEndLocal(2,L21);
                DexLabel L22=new DexLabel();
                ddv.visitRestartLocal(2,L22);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_STRING,5,"*");
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L2);
                code.visitJumpStmt(IF_EQZ,7,-1,L7);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(-1)); // int: 0xffffffff  float:NaN
                code.visitLabel(L4);
                code.visitJumpStmt(IF_NEZ,2,-1,L7);
                code.visitLabel(L5);
                code.visitConstStmt(CONST_STRING,3,".");
                code.visitStmt2R1N(ADD_INT_LIT8,4,1,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,3,4},new Method("Ljava/lang/String;","indexOf",new String[]{ "Ljava/lang/String;","I"},"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitLabel(L6);
                code.visitJumpStmt(IF_LTZ,1,-1,L7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_LT,1,3,L15);
                code.visitLabel(L7);
                code.visitJumpStmt(IF_NEZ,2,-1,L14);
                code.visitLabel(L8);
                code.visitFieldStmt(IGET_OBJECT,3,6,new Field("Lorg/mortbay/jetty/MimeTypes;","_mimeMap","Ljava/util/Map;"));
                code.visitJumpStmt(IF_EQZ,3,-1,L11);
                code.visitLabel(L9);
                code.visitFieldStmt(IGET_OBJECT,3,6,new Field("Lorg/mortbay/jetty/MimeTypes;","_mimeMap","Ljava/util/Map;"));
                code.visitConstStmt(CONST_STRING,4,"*");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3,5},new Method("Ljava/util/Map;","get",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L10);
                code.visitTypeStmt(CHECK_CAST,2,-1,"Lorg/mortbay/io/Buffer;");
                code.visitLabel(L11);
                code.visitJumpStmt(IF_NEZ,2,-1,L14);
                code.visitLabel(L12);
                code.visitFieldStmt(SGET_OBJECT,3,-1,new Field("Lorg/mortbay/jetty/MimeTypes;","__dftMimeMap","Ljava/util/Map;"));
                code.visitConstStmt(CONST_STRING,4,"*");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3,5},new Method("Ljava/util/Map;","get",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L13);
                code.visitTypeStmt(CHECK_CAST,2,-1,"Lorg/mortbay/io/Buffer;");
                code.visitLabel(L14);
                code.visitStmt1R(RETURN_OBJECT,2);
                code.visitLabel(L15);
                code.visitStmt2R1N(ADD_INT_LIT8,3,1,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,3},new Method("Ljava/lang/String;","substring",new String[]{ "I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3},new Method("Lorg/mortbay/util/StringUtil;","asciiToLowerCase",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L16);
                code.visitFieldStmt(IGET_OBJECT,3,6,new Field("Lorg/mortbay/jetty/MimeTypes;","_mimeMap","Ljava/util/Map;"));
                code.visitJumpStmt(IF_EQZ,3,-1,L19);
                code.visitLabel(L17);
                code.visitFieldStmt(IGET_OBJECT,3,6,new Field("Lorg/mortbay/jetty/MimeTypes;","_mimeMap","Ljava/util/Map;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3,0},new Method("Ljava/util/Map;","get",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L18);
                code.visitTypeStmt(CHECK_CAST,2,-1,"Lorg/mortbay/io/Buffer;");
                code.visitLabel(L19);
                code.visitJumpStmt(IF_NEZ,2,-1,L4);
                code.visitLabel(L20);
                code.visitFieldStmt(SGET_OBJECT,3,-1,new Field("Lorg/mortbay/jetty/MimeTypes;","__dftMimeMap","Ljava/util/Map;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3,0},new Method("Ljava/util/Map;","get",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L21);
                code.visitTypeStmt(CHECK_CAST,2,-1,"Lorg/mortbay/io/Buffer;");
                code.visitLabel(L22);
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_getMimeMap(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/MimeTypes;","getMimeMap",new String[]{ },"Ljava/util/Map;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(184,L3);
                code.visitLabel(L3);
                code.visitStmt1R(MONITOR_ENTER,1);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/MimeTypes;","_mimeMap","Ljava/util/Map;"));
                code.visitLabel(L1);
                code.visitStmt1R(MONITOR_EXIT,1);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,0);
                code.visitStmt1R(MONITOR_EXIT,1);
                code.visitStmt1R(THROW,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m007_setMimeMap(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/MimeTypes;","setMimeMap",new String[]{ "Ljava/util/Map;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"mimeMap");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(193,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(195,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(207,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(199,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(200,L4);
                ddv.visitStartLocal(2,L4,"m","Ljava/util/Map;",null);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(201,L5);
                ddv.visitStartLocal(1,L5,"i","Ljava/util/Iterator;",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(203,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(204,L7);
                ddv.visitStartLocal(0,L7,"entry","Ljava/util/Map$Entry;",null);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(206,L8);
                ddv.visitEndLocal(0,L8);
                code.visitLabel(L0);
                code.visitJumpStmt(IF_NEZ,6,-1,L3);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_OBJECT,3,5,new Field("Lorg/mortbay/jetty/MimeTypes;","_mimeMap","Ljava/util/Map;"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L3);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Ljava/util/HashMap;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2},new Method("Ljava/util/HashMap;","<init>",new String[]{ },"V"));
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 6},new Method("Ljava/util/Map;","entrySet",new String[]{ },"Ljava/util/Set;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3},new Method("Ljava/util/Set;","iterator",new String[]{ },"Ljava/util/Iterator;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Ljava/util/Iterator;","hasNext",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_EQZ,3,-1,L8);
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Ljava/util/Iterator;","next",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Ljava/util/Map$Entry;");
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Ljava/util/Map$Entry;","getKey",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Ljava/util/Map$Entry;","getValue",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/lang/Object;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 4},new Method("Lorg/mortbay/jetty/MimeTypes;","normalizeMimeType",new String[]{ "Ljava/lang/String;"},"Lorg/mortbay/io/Buffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2,3,4},new Method("Ljava/util/Map;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitLabel(L8);
                code.visitFieldStmt(IPUT_OBJECT,2,5,new Field("Lorg/mortbay/jetty/MimeTypes;","_mimeMap","Ljava/util/Map;"));
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
