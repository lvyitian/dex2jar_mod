package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0049_org_mortbay_ijetty_AndroidClassLoader {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/ijetty/AndroidClassLoader;","Ljava/lang/ClassLoader;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("AndroidClassLoader.java");
        f000__context(cv);
        f001__delegate(cv);
        f002__parent(cv);
        m000__init_(cv);
        m001_getResource(cv);
        m002_isServerPath(cv);
        m003_isSystemPath(cv);
        m004_loadClass(cv);
        m005_loadClass(cv);
        m006_toString(cv);
    }
    public static void f000__context(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/ijetty/AndroidClassLoader;","_context","Lorg/mortbay/jetty/webapp/WebAppContext;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001__delegate(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/ijetty/AndroidClassLoader;","_delegate","Ljava/lang/ClassLoader;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002__parent(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/ijetty/AndroidClassLoader;","_parent","Ljava/lang/ClassLoader;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/ijetty/AndroidClassLoader;","<init>",new String[]{ "Ljava/lang/String;","Ljava/lang/ClassLoader;","Lorg/mortbay/jetty/webapp/WebAppContext;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"path");
                ddv.visitParameterName(1,"parent");
                ddv.visitParameterName(2,"context");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(39,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(41,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(43,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(44,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(46,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(47,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(51,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(52,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(49,L9);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_STRING,2,"");
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3},new Method("Ljava/lang/ClassLoader;","<init>",new String[]{ },"V"));
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/lang/Object;","getClass",new String[]{ },"Ljava/lang/Class;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/Class;","getClassLoader",new String[]{ },"Ljava/lang/ClassLoader;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IPUT_OBJECT,0,3,new Field("Lorg/mortbay/ijetty/AndroidClassLoader;","_parent","Ljava/lang/ClassLoader;"));
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/ijetty/AndroidClassLoader;","_parent","Ljava/lang/ClassLoader;"));
                code.visitJumpStmt(IF_NEZ,0,-1,L5);
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Ljava/lang/ClassLoader;","getSystemClassLoader",new String[]{ },"Ljava/lang/ClassLoader;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IPUT_OBJECT,0,3,new Field("Lorg/mortbay/ijetty/AndroidClassLoader;","_parent","Ljava/lang/ClassLoader;"));
                code.visitLabel(L5);
                code.visitJumpStmt(IF_EQZ,4,-1,L6);
                code.visitConstStmt(CONST_STRING,0,"");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/lang/String;","trim",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,0},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L9);
                code.visitLabel(L6);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ldalvik/system/PathClassLoader;");
                code.visitConstStmt(CONST_STRING,1,"");
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/ijetty/AndroidClassLoader;","_parent","Ljava/lang/ClassLoader;"));
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,2,1},new Method("Ldalvik/system/PathClassLoader;","<init>",new String[]{ "Ljava/lang/String;","Ljava/lang/ClassLoader;"},"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,3,new Field("Lorg/mortbay/ijetty/AndroidClassLoader;","_delegate","Ljava/lang/ClassLoader;"));
                code.visitLabel(L7);
                code.visitFieldStmt(IPUT_OBJECT,6,3,new Field("Lorg/mortbay/ijetty/AndroidClassLoader;","_context","Lorg/mortbay/jetty/webapp/WebAppContext;"));
                code.visitLabel(L8);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L9);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ldalvik/system/PathClassLoader;");
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/ijetty/AndroidClassLoader;","_parent","Ljava/lang/ClassLoader;"));
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,4,1},new Method("Ldalvik/system/PathClassLoader;","<init>",new String[]{ "Ljava/lang/String;","Ljava/lang/ClassLoader;"},"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,3,new Field("Lorg/mortbay/ijetty/AndroidClassLoader;","_delegate","Ljava/lang/ClassLoader;"));
                code.visitJumpStmt(GOTO,-1,-1,L7);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001_getResource(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/ijetty/AndroidClassLoader;","getResource",new String[]{ "Ljava/lang/String;"},"Ljava/net/URL;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(59,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(60,L4);
                ddv.visitStartLocal(1,L4,"url","Ljava/net/URL;",null);
                ddv.visitLineNumber(61,L0);
                ddv.visitStartLocal(0,L0,"tried_parent","Z",null);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(63,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(65,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(66,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(69,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(71,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(73,L10);
                ddv.visitRestartLocal(1,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(75,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(76,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(80,L13);
                ddv.visitRestartLocal(1,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(82,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(83,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(86,L16);
                ddv.visitRestartLocal(1,L16);
                ddv.visitLineNumber(88,L1);
                ddv.visitLineNumber(59,L2);
                code.visitLabel(L3);
                code.visitStmt1R(MONITOR_ENTER,4);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L4);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,2,4,new Field("Lorg/mortbay/ijetty/AndroidClassLoader;","_context","Lorg/mortbay/jetty/webapp/WebAppContext;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","isParentLoaderPriority",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_NEZ,2,-1,L5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Lorg/mortbay/ijetty/AndroidClassLoader;","isSystemPath",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_EQZ,2,-1,L8);
                code.visitLabel(L5);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,2,4,new Field("Lorg/mortbay/ijetty/AndroidClassLoader;","_parent","Ljava/lang/ClassLoader;"));
                code.visitJumpStmt(IF_EQZ,2,-1,L8);
                code.visitLabel(L7);
                code.visitFieldStmt(IGET_OBJECT,2,4,new Field("Lorg/mortbay/ijetty/AndroidClassLoader;","_parent","Ljava/lang/ClassLoader;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,5},new Method("Ljava/lang/ClassLoader;","getResource",new String[]{ "Ljava/lang/String;"},"Ljava/net/URL;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L8);
                code.visitJumpStmt(IF_NEZ,1,-1,L13);
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Lorg/mortbay/ijetty/AndroidClassLoader;","findResource",new String[]{ "Ljava/lang/String;"},"Ljava/net/URL;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L10);
                code.visitJumpStmt(IF_NEZ,1,-1,L13);
                code.visitConstStmt(CONST_STRING,2,"/");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,2},new Method("Ljava/lang/String;","startsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_EQZ,2,-1,L13);
                code.visitLabel(L11);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/log/Log;","isDebugEnabled",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_EQZ,2,-1,L12);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,3,"HACK leading / off ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L12);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,2},new Method("Ljava/lang/String;","substring",new String[]{ "I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,2},new Method("Lorg/mortbay/ijetty/AndroidClassLoader;","findResource",new String[]{ "Ljava/lang/String;"},"Ljava/net/URL;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L13);
                code.visitJumpStmt(IF_NEZ,1,-1,L16);
                code.visitJumpStmt(IF_NEZ,0,-1,L16);
                code.visitLabel(L14);
                code.visitFieldStmt(IGET_OBJECT,2,4,new Field("Lorg/mortbay/ijetty/AndroidClassLoader;","_parent","Ljava/lang/ClassLoader;"));
                code.visitJumpStmt(IF_EQZ,2,-1,L16);
                code.visitLabel(L15);
                code.visitFieldStmt(IGET_OBJECT,2,4,new Field("Lorg/mortbay/ijetty/AndroidClassLoader;","_parent","Ljava/lang/ClassLoader;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,5},new Method("Ljava/lang/ClassLoader;","getResource",new String[]{ "Ljava/lang/String;"},"Ljava/net/URL;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L16);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/log/Log;","isDebugEnabled",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_EQZ,2,-1,L1);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,3,"getResource(");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitConstStmt(CONST_STRING,3,")=");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L1);
                code.visitStmt1R(MONITOR_EXIT,4);
                code.visitStmt1R(RETURN_OBJECT,1);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,2);
                code.visitStmt1R(MONITOR_EXIT,4);
                code.visitStmt1R(THROW,2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_isServerPath(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/ijetty/AndroidClassLoader;","isServerPath",new String[]{ "Ljava/lang/String;"},"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(10);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(94,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(95,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(96,L3);
                DexLabel L4=new DexLabel();
                ddv.visitRestartLocal(9,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(98,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(99,L6);
                ddv.visitStartLocal(3,L6,"server_classes","[Ljava/lang/String;",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(101,L7);
                DexLabel L8=new DexLabel();
                ddv.visitStartLocal(1,L8,"i","I",null);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(103,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(104,L10);
                ddv.visitStartLocal(2,L10,"result","Z",null);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(105,L11);
                ddv.visitStartLocal(0,L11,"c","Ljava/lang/String;",null);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(107,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(108,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(111,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(113,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(120,L16);
                ddv.visitEndLocal(1,L16);
                ddv.visitEndLocal(2,L16);
                ddv.visitEndLocal(0,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(116,L17);
                ddv.visitRestartLocal(0,L17);
                ddv.visitRestartLocal(1,L17);
                ddv.visitRestartLocal(2,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(117,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(101,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(120,L20);
                ddv.visitEndLocal(0,L20);
                ddv.visitEndLocal(1,L20);
                ddv.visitEndLocal(2,L20);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,6, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitConstStmt(CONST_STRING,7,".");
                code.visitLabel(L1);
                code.visitConstStmt(CONST_16,4, Integer.valueOf(47)); // int: 0x0000002f  float:0.000000
                code.visitConstStmt(CONST_16,5, Integer.valueOf(46)); // int: 0x0000002e  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9,4,5},new Method("Ljava/lang/String;","replace",new String[]{ "C","C"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitLabel(L2);
                code.visitConstStmt(CONST_STRING,4,".");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9,7},new Method("Ljava/lang/String;","startsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitJumpStmt(IF_EQZ,4,-1,L5);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9,6},new Method("Ljava/lang/String;","substring",new String[]{ "I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitLabel(L4);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,4,8,new Field("Lorg/mortbay/ijetty/AndroidClassLoader;","_context","Lorg/mortbay/jetty/webapp/WebAppContext;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","getServerClasses",new String[]{ },"[Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitLabel(L6);
                code.visitJumpStmt(IF_EQZ,3,-1,L20);
                code.visitLabel(L7);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L8);
                code.visitStmt2R(ARRAY_LENGTH,4,3);
                code.visitJumpStmt(IF_GE,1,4,L20);
                code.visitLabel(L9);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L10);
                code.visitStmt3R(AGET_OBJECT,0,3,1);
                code.visitLabel(L11);
                code.visitConstStmt(CONST_STRING,4,"-");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,4},new Method("Ljava/lang/String;","startsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitJumpStmt(IF_EQZ,4,-1,L14);
                code.visitLabel(L12);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,6},new Method("Ljava/lang/String;","substring",new String[]{ "I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L13);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L14);
                code.visitConstStmt(CONST_STRING,4,".");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,7},new Method("Ljava/lang/String;","endsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitJumpStmt(IF_EQZ,4,-1,L17);
                code.visitLabel(L15);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9,0},new Method("Ljava/lang/String;","startsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitJumpStmt(IF_EQZ,4,-1,L19);
                code.visitStmt2R(MOVE,4,2);
                code.visitLabel(L16);
                code.visitStmt1R(RETURN,4);
                code.visitLabel(L17);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9,0},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitJumpStmt(IF_EQZ,4,-1,L19);
                code.visitStmt2R(MOVE,4,2);
                code.visitLabel(L18);
                code.visitJumpStmt(GOTO,-1,-1,L16);
                code.visitLabel(L19);
                code.visitStmt2R1N(ADD_INT_LIT8,1,1,1);
                code.visitJumpStmt(GOTO,-1,-1,L8);
                code.visitLabel(L20);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L16);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_isSystemPath(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/ijetty/AndroidClassLoader;","isSystemPath",new String[]{ "Ljava/lang/String;"},"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(10);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(125,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(126,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(127,L3);
                DexLabel L4=new DexLabel();
                ddv.visitRestartLocal(9,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(128,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(129,L6);
                ddv.visitStartLocal(3,L6,"system_classes","[Ljava/lang/String;",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(131,L7);
                DexLabel L8=new DexLabel();
                ddv.visitStartLocal(1,L8,"i","I",null);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(133,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(134,L10);
                ddv.visitStartLocal(2,L10,"result","Z",null);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(136,L11);
                ddv.visitStartLocal(0,L11,"c","Ljava/lang/String;",null);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(138,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(139,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(142,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(144,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(152,L16);
                ddv.visitEndLocal(1,L16);
                ddv.visitEndLocal(2,L16);
                ddv.visitEndLocal(0,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(147,L17);
                ddv.visitRestartLocal(0,L17);
                ddv.visitRestartLocal(1,L17);
                ddv.visitRestartLocal(2,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(148,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(131,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(152,L20);
                ddv.visitEndLocal(0,L20);
                ddv.visitEndLocal(1,L20);
                ddv.visitEndLocal(2,L20);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,6, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitConstStmt(CONST_STRING,7,".");
                code.visitLabel(L1);
                code.visitConstStmt(CONST_16,4, Integer.valueOf(47)); // int: 0x0000002f  float:0.000000
                code.visitConstStmt(CONST_16,5, Integer.valueOf(46)); // int: 0x0000002e  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9,4,5},new Method("Ljava/lang/String;","replace",new String[]{ "C","C"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitLabel(L2);
                code.visitConstStmt(CONST_STRING,4,".");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9,7},new Method("Ljava/lang/String;","startsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitJumpStmt(IF_EQZ,4,-1,L5);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9,6},new Method("Ljava/lang/String;","substring",new String[]{ "I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitLabel(L4);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,4,8,new Field("Lorg/mortbay/ijetty/AndroidClassLoader;","_context","Lorg/mortbay/jetty/webapp/WebAppContext;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","getSystemClasses",new String[]{ },"[Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitLabel(L6);
                code.visitJumpStmt(IF_EQZ,3,-1,L20);
                code.visitLabel(L7);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L8);
                code.visitStmt2R(ARRAY_LENGTH,4,3);
                code.visitJumpStmt(IF_GE,1,4,L20);
                code.visitLabel(L9);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L10);
                code.visitStmt3R(AGET_OBJECT,0,3,1);
                code.visitLabel(L11);
                code.visitConstStmt(CONST_STRING,4,"-");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,4},new Method("Ljava/lang/String;","startsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitJumpStmt(IF_EQZ,4,-1,L14);
                code.visitLabel(L12);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,6},new Method("Ljava/lang/String;","substring",new String[]{ "I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L13);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L14);
                code.visitConstStmt(CONST_STRING,4,".");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,7},new Method("Ljava/lang/String;","endsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitJumpStmt(IF_EQZ,4,-1,L17);
                code.visitLabel(L15);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9,0},new Method("Ljava/lang/String;","startsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitJumpStmt(IF_EQZ,4,-1,L19);
                code.visitStmt2R(MOVE,4,2);
                code.visitLabel(L16);
                code.visitStmt1R(RETURN,4);
                code.visitLabel(L17);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9,0},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitJumpStmt(IF_EQZ,4,-1,L19);
                code.visitStmt2R(MOVE,4,2);
                code.visitLabel(L18);
                code.visitJumpStmt(GOTO,-1,-1,L16);
                code.visitLabel(L19);
                code.visitStmt2R1N(ADD_INT_LIT8,1,1,1);
                code.visitJumpStmt(GOTO,-1,-1,L8);
                code.visitLabel(L20);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L16);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_loadClass(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/ijetty/AndroidClassLoader;","loadClass",new String[]{ "Ljava/lang/String;"},"Ljava/lang/Class;"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/ClassNotFoundException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(158,L3);
                code.visitLabel(L3);
                code.visitStmt1R(MONITOR_ENTER,1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2,0},new Method("Lorg/mortbay/ijetty/AndroidClassLoader;","loadClass",new String[]{ "Ljava/lang/String;","Z"},"Ljava/lang/Class;"));
                code.visitLabel(L1);
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt1R(MONITOR_EXIT,1);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,0);
                code.visitStmt1R(MONITOR_EXIT,1);
                code.visitStmt1R(THROW,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_loadClass(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/ijetty/AndroidClassLoader;","loadClass",new String[]{ "Ljava/lang/String;","Z"},"Ljava/lang/Class;"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/ClassNotFoundException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(9);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                DexLabel L5=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L5,L2},new String[]{ "Ljava/lang/ClassNotFoundException;",null});
                DexLabel L6=new DexLabel();
                DexLabel L7=new DexLabel();
                DexLabel L8=new DexLabel();
                code.visitTryCatch(L6,L7,new DexLabel[]{L8,L2},new String[]{ "Ljava/lang/ClassNotFoundException;",null});
                DexLabel L9=new DexLabel();
                code.visitTryCatch(L9,L2,new DexLabel[]{L2},new String[]{ null});
                DexLabel L10=new DexLabel();
                DexLabel L11=new DexLabel();
                code.visitTryCatch(L10,L11,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                ddv.visitParameterName(1,"resolve");
                DexLabel L12=new DexLabel();
                ddv.visitPrologue(L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(163,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(164,L14);
                ddv.visitStartLocal(0,L14,"c","Ljava/lang/Class;",null);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(165,L15);
                ddv.visitStartLocal(2,L15,"ex","Ljava/lang/ClassNotFoundException;",null);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(166,L16);
                ddv.visitStartLocal(3,L16,"tried_parent","Z",null);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(168,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(170,L18);
                ddv.visitLineNumber(173,L3);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(174,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(175,L20);
                ddv.visitLineNumber(183,L4);
                ddv.visitLineNumber(187,L6);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(188,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(189,L22);
                ddv.visitRestartLocal(0,L22);
                ddv.visitLineNumber(197,L7);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(198,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(200,L24);
                ddv.visitRestartLocal(0,L24);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(201,L25);
                ddv.visitLineNumber(163,L2);
                ddv.visitEndLocal(2,L2);
                ddv.visitEndLocal(3,L2);
                ddv.visitEndLocal(0,L2);
                ddv.visitLineNumber(177,L5);
                ddv.visitRestartLocal(0,L5);
                ddv.visitRestartLocal(2,L5);
                ddv.visitRestartLocal(3,L5);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(179,L26);
                ddv.visitStartLocal(1,L26,"e","Ljava/lang/ClassNotFoundException;",null);
                ddv.visitLineNumber(191,L8);
                ddv.visitEndLocal(1,L8);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(193,L27);
                ddv.visitRestartLocal(1,L27);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(203,L28);
                ddv.visitEndLocal(1,L28);
                ddv.visitLineNumber(204,L10);
                DexLabel L29=new DexLabel();
                ddv.visitLineNumber(206,L29);
                ddv.visitLineNumber(208,L11);
                code.visitLabel(L12);
                code.visitConstStmt(CONST_STRING,4,"loading class ");
                code.visitLabel(L13);
                code.visitStmt1R(MONITOR_ENTER,6);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,7},new Method("Lorg/mortbay/ijetty/AndroidClassLoader;","findLoadedClass",new String[]{ "Ljava/lang/String;"},"Ljava/lang/Class;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L14);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L15);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L16);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/log/Log;","isDebugEnabled",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitJumpStmt(IF_EQZ,4,-1,L17);
                code.visitTypeStmt(NEW_INSTANCE,4,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IGET_OBJECT,5,6,new Field("Lorg/mortbay/ijetty/AndroidClassLoader;","_context","Lorg/mortbay/jetty/webapp/WebAppContext;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","getContextPath",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitConstStmt(CONST_STRING,5," parent priority = ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitFieldStmt(IGET_OBJECT,5,6,new Field("Lorg/mortbay/ijetty/AndroidClassLoader;","_context","Lorg/mortbay/jetty/webapp/WebAppContext;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","isParentLoaderPriority",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Z"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 4},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L17);
                code.visitJumpStmt(IF_NEZ,0,-1,L4);
                code.visitFieldStmt(IGET_OBJECT,4,6,new Field("Lorg/mortbay/ijetty/AndroidClassLoader;","_parent","Ljava/lang/ClassLoader;"));
                code.visitJumpStmt(IF_EQZ,4,-1,L4);
                code.visitFieldStmt(IGET_OBJECT,4,6,new Field("Lorg/mortbay/ijetty/AndroidClassLoader;","_context","Lorg/mortbay/jetty/webapp/WebAppContext;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","isParentLoaderPriority",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitJumpStmt(IF_NEZ,4,-1,L18);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,7},new Method("Lorg/mortbay/ijetty/AndroidClassLoader;","isSystemPath",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitLabel(L1);
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitJumpStmt(IF_EQZ,4,-1,L4);
                code.visitLabel(L18);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/log/Log;","isDebugEnabled",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitJumpStmt(IF_EQZ,4,-1,L19);
                code.visitTypeStmt(NEW_INSTANCE,4,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,5,"loading class ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,7},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitConstStmt(CONST_STRING,5," trying parent loader first");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitFieldStmt(IGET_OBJECT,5,6,new Field("Lorg/mortbay/ijetty/AndroidClassLoader;","_parent","Ljava/lang/ClassLoader;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 4},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L19);
                code.visitFieldStmt(IGET_OBJECT,4,6,new Field("Lorg/mortbay/ijetty/AndroidClassLoader;","_parent","Ljava/lang/ClassLoader;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,7},new Method("Ljava/lang/ClassLoader;","loadClass",new String[]{ "Ljava/lang/String;"},"Ljava/lang/Class;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L20);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/log/Log;","isDebugEnabled",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitJumpStmt(IF_EQZ,4,-1,L4);
                code.visitTypeStmt(NEW_INSTANCE,4,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,5,"parent loaded ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,0},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 4},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L4);
                code.visitJumpStmt(IF_NEZ,0,-1,L7);
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/log/Log;","isDebugEnabled",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitJumpStmt(IF_EQZ,4,-1,L21);
                code.visitTypeStmt(NEW_INSTANCE,4,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,5,"loading class ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,7},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitConstStmt(CONST_STRING,5," trying delegate loader");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitFieldStmt(IGET_OBJECT,5,6,new Field("Lorg/mortbay/ijetty/AndroidClassLoader;","_delegate","Ljava/lang/ClassLoader;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 4},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L21);
                code.visitFieldStmt(IGET_OBJECT,4,6,new Field("Lorg/mortbay/ijetty/AndroidClassLoader;","_delegate","Ljava/lang/ClassLoader;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,7},new Method("Ljava/lang/ClassLoader;","loadClass",new String[]{ "Ljava/lang/String;"},"Ljava/lang/Class;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L22);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/log/Log;","isDebugEnabled",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitJumpStmt(IF_EQZ,4,-1,L7);
                code.visitTypeStmt(NEW_INSTANCE,4,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,5,"delegate loaded ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,0},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 4},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L7);
                code.visitJumpStmt(IF_NEZ,0,-1,L24);
                code.visitLabel(L9);
                code.visitFieldStmt(IGET_OBJECT,4,6,new Field("Lorg/mortbay/ijetty/AndroidClassLoader;","_parent","Ljava/lang/ClassLoader;"));
                code.visitJumpStmt(IF_EQZ,4,-1,L24);
                code.visitJumpStmt(IF_NEZ,3,-1,L24);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,7},new Method("Lorg/mortbay/ijetty/AndroidClassLoader;","isServerPath",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitJumpStmt(IF_NEZ,4,-1,L24);
                code.visitLabel(L23);
                code.visitFieldStmt(IGET_OBJECT,4,6,new Field("Lorg/mortbay/ijetty/AndroidClassLoader;","_parent","Ljava/lang/ClassLoader;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,7},new Method("Ljava/lang/ClassLoader;","loadClass",new String[]{ "Ljava/lang/String;"},"Ljava/lang/Class;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L24);
                code.visitJumpStmt(IF_NEZ,0,-1,L28);
                code.visitLabel(L25);
                code.visitStmt1R(THROW,2);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,4);
                code.visitStmt1R(MONITOR_EXIT,6);
                code.visitStmt1R(THROW,4);
                code.visitLabel(L5);
                code.visitStmt1R(MOVE_EXCEPTION,4);
                code.visitStmt2R(MOVE_OBJECT,1,4);
                code.visitLabel(L26);
                code.visitStmt2R(MOVE_OBJECT,2,1);
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitLabel(L8);
                code.visitStmt1R(MOVE_EXCEPTION,4);
                code.visitStmt2R(MOVE_OBJECT,1,4);
                code.visitLabel(L27);
                code.visitStmt2R(MOVE_OBJECT,2,1);
                code.visitJumpStmt(GOTO,-1,-1,L7);
                code.visitLabel(L28);
                code.visitJumpStmt(IF_EQZ,8,-1,L29);
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,0},new Method("Lorg/mortbay/ijetty/AndroidClassLoader;","resolveClass",new String[]{ "Ljava/lang/Class;"},"V"));
                code.visitLabel(L29);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/log/Log;","isDebugEnabled",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitJumpStmt(IF_EQZ,4,-1,L11);
                code.visitTypeStmt(NEW_INSTANCE,4,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,5,"loaded ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,0},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitConstStmt(CONST_STRING,5," from ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/Class;","getClassLoader",new String[]{ },"Ljava/lang/ClassLoader;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 4},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L11);
                code.visitStmt1R(MONITOR_EXIT,6);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_toString(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/ijetty/AndroidClassLoader;","toString",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(215,L0);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,1,"(AndroidClassLoader, delegate=");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/ijetty/AndroidClassLoader;","_delegate","Ljava/lang/ClassLoader;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitConstStmt(CONST_STRING,1,")");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
