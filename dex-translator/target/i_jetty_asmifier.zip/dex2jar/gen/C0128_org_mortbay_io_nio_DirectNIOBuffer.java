package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0128_org_mortbay_io_nio_DirectNIOBuffer {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/io/nio/DirectNIOBuffer;","Lorg/mortbay/io/AbstractBuffer;",new String[]{ "Lorg/mortbay/io/nio/NIOBuffer;"});
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("DirectNIOBuffer.java");
        f000__buf(cv);
        f001__in(cv);
        f002__inStream(cv);
        f003__out(cv);
        f004__outStream(cv);
        m000__init_(cv);
        m001__init_(cv);
        m002__init_(cv);
        m003_array(cv);
        m004_capacity(cv);
        m005_getByteBuffer(cv);
        m006_isDirect(cv);
        m007_peek(cv);
        m008_peek(cv);
        m009_poke(cv);
        m010_poke(cv);
        m011_poke(cv);
        m012_readFrom(cv);
        m013_writeTo(cv);
    }
    public static void f000__buf(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/io/nio/DirectNIOBuffer;","_buf","Ljava/nio/ByteBuffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001__in(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/io/nio/DirectNIOBuffer;","_in","Ljava/nio/channels/ReadableByteChannel;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002__inStream(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/io/nio/DirectNIOBuffer;","_inStream","Ljava/io/InputStream;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003__out(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/io/nio/DirectNIOBuffer;","_out","Ljava/nio/channels/WritableByteChannel;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f004__outStream(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/io/nio/DirectNIOBuffer;","_outStream","Ljava/io/OutputStream;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/io/nio/DirectNIOBuffer;","<init>",new String[]{ "I"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"size");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(46,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(47,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(48,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(49,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(50,L5);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2,0,1},new Method("Lorg/mortbay/io/AbstractBuffer;","<init>",new String[]{ "I","Z"},"V"));
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3},new Method("Ljava/nio/ByteBuffer;","allocateDirect",new String[]{ "I"},"Ljava/nio/ByteBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/io/nio/DirectNIOBuffer;","_buf","Ljava/nio/ByteBuffer;"));
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/io/nio/DirectNIOBuffer;","_buf","Ljava/nio/ByteBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/nio/ByteBuffer;","position",new String[]{ "I"},"Ljava/nio/Buffer;"));
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/io/nio/DirectNIOBuffer;","_buf","Ljava/nio/ByteBuffer;"));
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/io/nio/DirectNIOBuffer;","_buf","Ljava/nio/ByteBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/nio/ByteBuffer;","capacity",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/nio/ByteBuffer;","limit",new String[]{ "I"},"Ljava/nio/Buffer;"));
                code.visitLabel(L5);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/io/nio/DirectNIOBuffer;","<init>",new String[]{ "Ljava/io/File;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(10);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"file");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(67,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(68,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(69,L3);
                ddv.visitStartLocal(6,L3,"fis","Ljava/io/FileInputStream;",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(70,L4);
                ddv.visitStartLocal(0,L4,"fc","Ljava/nio/channels/FileChannel;",null);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(71,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(72,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(73,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(74,L8);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,7, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 8,1,7},new Method("Lorg/mortbay/io/AbstractBuffer;","<init>",new String[]{ "I","Z"},"V"));
                code.visitLabel(L2);
                code.visitTypeStmt(NEW_INSTANCE,6,-1,"Ljava/io/FileInputStream;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 6,9},new Method("Ljava/io/FileInputStream;","<init>",new String[]{ "Ljava/io/File;"},"V"));
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/io/FileInputStream;","getChannel",new String[]{ },"Ljava/nio/channels/FileChannel;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L4);
                code.visitFieldStmt(SGET_OBJECT,1,-1,new Field("Ljava/nio/channels/FileChannel$MapMode;","READ_ONLY","Ljava/nio/channels/FileChannel$MapMode;"));
                code.visitConstStmt(CONST_WIDE_16,2,Long.valueOf(0L)); // long: 0x0000000000000000  double:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9},new Method("Ljava/io/File;","length",new String[]{ },"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,4);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 0,1,2,3,4,5},new Method("Ljava/nio/channels/FileChannel;","map",new String[]{ "Ljava/nio/channels/FileChannel$MapMode;","J","J"},"Ljava/nio/MappedByteBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitFieldStmt(IPUT_OBJECT,1,8,new Field("Lorg/mortbay/io/nio/DirectNIOBuffer;","_buf","Ljava/nio/ByteBuffer;"));
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,7},new Method("Lorg/mortbay/io/nio/DirectNIOBuffer;","setGetIndex",new String[]{ "I"},"V"));
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9},new Method("Ljava/io/File;","length",new String[]{ },"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,1);
                code.visitStmt2R(LONG_TO_INT,1,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,1},new Method("Lorg/mortbay/io/nio/DirectNIOBuffer;","setPutIndex",new String[]{ "I"},"V"));
                code.visitLabel(L7);
                code.visitFieldStmt(IPUT,7,8,new Field("Lorg/mortbay/io/nio/DirectNIOBuffer;","_access","I"));
                code.visitLabel(L8);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/io/nio/DirectNIOBuffer;","<init>",new String[]{ "Ljava/nio/ByteBuffer;","Z"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"buffer");
                ddv.visitParameterName(1,"immutable");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(54,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(55,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(56,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(54,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(57,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(58,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(59,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(60,L8);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitJumpStmt(IF_EQZ,4,-1,L4);
                code.visitStmt2R(MOVE,0,1);
                DexLabel L9=new DexLabel();
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2,0,1},new Method("Lorg/mortbay/io/AbstractBuffer;","<init>",new String[]{ "I","Z"},"V"));
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/nio/ByteBuffer;","isDirect",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_NEZ,0,-1,L5);
                code.visitLabel(L3);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/IllegalArgumentException;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/IllegalArgumentException;","<init>",new String[]{ },"V"));
                code.visitStmt1R(THROW,0);
                code.visitLabel(L4);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L9);
                code.visitLabel(L5);
                code.visitFieldStmt(IPUT_OBJECT,3,2,new Field("Lorg/mortbay/io/nio/DirectNIOBuffer;","_buf","Ljava/nio/ByteBuffer;"));
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/nio/ByteBuffer;","position",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,0},new Method("Lorg/mortbay/io/nio/DirectNIOBuffer;","setGetIndex",new String[]{ "I"},"V"));
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/nio/ByteBuffer;","limit",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,0},new Method("Lorg/mortbay/io/nio/DirectNIOBuffer;","setPutIndex",new String[]{ "I"},"V"));
                code.visitLabel(L8);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_array(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/nio/DirectNIOBuffer;","array",new String[]{ },"[B"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(85,L0);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_capacity(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/nio/DirectNIOBuffer;","capacity",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(91,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/io/nio/DirectNIOBuffer;","_buf","Ljava/nio/ByteBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/nio/ByteBuffer;","capacity",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_getByteBuffer(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/nio/DirectNIOBuffer;","getByteBuffer",new String[]{ },"Ljava/nio/ByteBuffer;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(213,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/io/nio/DirectNIOBuffer;","_buf","Ljava/nio/ByteBuffer;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_isDirect(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/nio/DirectNIOBuffer;","isDirect",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(79,L0);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m007_peek(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/nio/DirectNIOBuffer;","peek",new String[]{ "I"},"B"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"position");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(97,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/io/nio/DirectNIOBuffer;","_buf","Ljava/nio/ByteBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,2},new Method("Ljava/nio/ByteBuffer;","get",new String[]{ "I"},"B"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m008_peek(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/nio/DirectNIOBuffer;","peek",new String[]{ "I","[B","I","I"},"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(10);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"index");
                ddv.visitParameterName(1,"b");
                ddv.visitParameterName(2,"offset");
                ddv.visitParameterName(3,"length");
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(102,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(103,L5);
                ddv.visitStartLocal(0,L5,"l","I",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(105,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(106,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(122,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(110,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(111,L10);
                ddv.visitLineNumber(114,L0);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(115,L11);
                ddv.visitLineNumber(119,L1);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(122,L12);
                ddv.visitLineNumber(119,L2);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitConstStmt(CONST_4,3, Integer.valueOf(-1)); // int: 0xffffffff  float:NaN
                code.visitLabel(L4);
                code.visitStmt2R(MOVE,0,9);
                code.visitLabel(L5);
                code.visitStmt3R(ADD_INT,1,6,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/io/nio/DirectNIOBuffer;","capacity",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_LE,1,2,L9);
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/io/nio/DirectNIOBuffer;","capacity",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitStmt3R(SUB_INT,0,1,6);
                code.visitLabel(L7);
                code.visitJumpStmt(IF_NEZ,0,-1,L9);
                code.visitStmt2R(MOVE,1,3);
                code.visitLabel(L8);
                code.visitStmt1R(RETURN,1);
                code.visitLabel(L9);
                code.visitJumpStmt(IF_GEZ,0,-1,L0);
                code.visitStmt2R(MOVE,1,3);
                code.visitLabel(L10);
                code.visitJumpStmt(GOTO,-1,-1,L8);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,1,5,new Field("Lorg/mortbay/io/nio/DirectNIOBuffer;","_buf","Ljava/nio/ByteBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,6},new Method("Ljava/nio/ByteBuffer;","position",new String[]{ "I"},"Ljava/nio/Buffer;"));
                code.visitLabel(L11);
                code.visitFieldStmt(IGET_OBJECT,1,5,new Field("Lorg/mortbay/io/nio/DirectNIOBuffer;","_buf","Ljava/nio/ByteBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,7,8,0},new Method("Ljava/nio/ByteBuffer;","get",new String[]{ "[B","I","I"},"Ljava/nio/ByteBuffer;"));
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,1,5,new Field("Lorg/mortbay/io/nio/DirectNIOBuffer;","_buf","Ljava/nio/ByteBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,4},new Method("Ljava/nio/ByteBuffer;","position",new String[]{ "I"},"Ljava/nio/Buffer;"));
                code.visitStmt2R(MOVE,1,0);
                code.visitLabel(L12);
                code.visitJumpStmt(GOTO,-1,-1,L8);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/io/nio/DirectNIOBuffer;","_buf","Ljava/nio/ByteBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,4},new Method("Ljava/nio/ByteBuffer;","position",new String[]{ "I"},"Ljava/nio/Buffer;"));
                code.visitStmt1R(THROW,1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m009_poke(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/nio/DirectNIOBuffer;","poke",new String[]{ "I","Lorg/mortbay/io/Buffer;"},"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(11);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"index");
                ddv.visitParameterName(1,"src");
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(136,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(138,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(139,L6);
                ddv.visitStartLocal(0,L6,"array","[B",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(141,L7);
                DexLabel L8=new DexLabel();
                ddv.visitStartLocal(1,L8,"length","I",null);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(175,L9);
                ddv.visitEndLocal(1,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(146,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(147,L11);
                ddv.visitStartLocal(3,L11,"src_buf","Lorg/mortbay/io/Buffer;",null);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(149,L12);
                DexLabel L13=new DexLabel();
                ddv.visitEndLocal(3,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(150,L14);
                ddv.visitStartLocal(4,L14,"src_bytebuf","Ljava/nio/ByteBuffer;",null);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(151,L15);
                ddv.visitLineNumber(154,L0);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(155,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(157,L17);
                ddv.visitStartLocal(2,L17,"space","I",null);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(158,L18);
                ddv.visitRestartLocal(1,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(159,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(161,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(162,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(164,L22);
                ddv.visitLineNumber(169,L1);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(170,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(171,L24);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(165,L25);
                ddv.visitLineNumber(169,L2);
                ddv.visitEndLocal(2,L2);
                ddv.visitEndLocal(1,L2);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(170,L26);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(171,L27);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(169,L28);
                DexLabel L29=new DexLabel();
                ddv.visitLineNumber(175,L29);
                ddv.visitEndLocal(4,L29);
                ddv.visitRestartLocal(3,L29);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,7, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Lorg/mortbay/io/nio/DirectNIOBuffer;","isReadOnly",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitJumpStmt(IF_EQZ,5,-1,L5);
                code.visitTypeStmt(NEW_INSTANCE,5,-1,"Ljava/lang/IllegalStateException;");
                code.visitConstStmt(CONST_STRING,6,"READONLY");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 5,6},new Method("Ljava/lang/IllegalStateException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,5);
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 10},new Method("Lorg/mortbay/io/Buffer;","array",new String[]{ },"[B"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L6);
                code.visitJumpStmt(IF_EQZ,0,-1,L10);
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 10},new Method("Lorg/mortbay/io/Buffer;","getIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 10},new Method("Lorg/mortbay/io/Buffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,9,0,5,6},new Method("Lorg/mortbay/io/nio/DirectNIOBuffer;","poke",new String[]{ "I","[B","I","I"},"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitLabel(L8);
                code.visitStmt2R(MOVE,5,1);
                code.visitLabel(L9);
                code.visitStmt1R(RETURN,5);
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 10},new Method("Lorg/mortbay/io/Buffer;","buffer",new String[]{ },"Lorg/mortbay/io/Buffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitLabel(L11);
                code.visitTypeStmt(INSTANCE_OF,5,3,"Lorg/mortbay/io/nio/DirectNIOBuffer;");
                code.visitJumpStmt(IF_EQZ,5,-1,L29);
                code.visitLabel(L12);
                code.visitTypeStmt(CHECK_CAST,3,-1,"Lorg/mortbay/io/nio/DirectNIOBuffer;");
                code.visitLabel(L13);
                code.visitFieldStmt(IGET_OBJECT,4,3,new Field("Lorg/mortbay/io/nio/DirectNIOBuffer;","_buf","Ljava/nio/ByteBuffer;"));
                code.visitLabel(L14);
                code.visitFieldStmt(IGET_OBJECT,5,8,new Field("Lorg/mortbay/io/nio/DirectNIOBuffer;","_buf","Ljava/nio/ByteBuffer;"));
                code.visitJumpStmt(IF_NE,4,5,L0);
                code.visitLabel(L15);
                code.visitFieldStmt(IGET_OBJECT,5,8,new Field("Lorg/mortbay/io/nio/DirectNIOBuffer;","_buf","Ljava/nio/ByteBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/nio/ByteBuffer;","duplicate",new String[]{ },"Ljava/nio/ByteBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,5,8,new Field("Lorg/mortbay/io/nio/DirectNIOBuffer;","_buf","Ljava/nio/ByteBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,9},new Method("Ljava/nio/ByteBuffer;","position",new String[]{ "I"},"Ljava/nio/Buffer;"));
                code.visitLabel(L16);
                code.visitFieldStmt(IGET_OBJECT,5,8,new Field("Lorg/mortbay/io/nio/DirectNIOBuffer;","_buf","Ljava/nio/ByteBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/nio/ByteBuffer;","remaining",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitLabel(L17);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 10},new Method("Lorg/mortbay/io/Buffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitLabel(L18);
                code.visitJumpStmt(IF_LE,1,2,L20);
                code.visitLabel(L19);
                code.visitStmt2R(MOVE,1,2);
                code.visitLabel(L20);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 10},new Method("Lorg/mortbay/io/Buffer;","getIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Ljava/nio/ByteBuffer;","position",new String[]{ "I"},"Ljava/nio/Buffer;"));
                code.visitLabel(L21);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 10},new Method("Lorg/mortbay/io/Buffer;","getIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitStmt2R(ADD_INT_2ADDR,5,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Ljava/nio/ByteBuffer;","limit",new String[]{ "I"},"Ljava/nio/Buffer;"));
                code.visitLabel(L22);
                code.visitFieldStmt(IGET_OBJECT,5,8,new Field("Lorg/mortbay/io/nio/DirectNIOBuffer;","_buf","Ljava/nio/ByteBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,4},new Method("Ljava/nio/ByteBuffer;","put",new String[]{ "Ljava/nio/ByteBuffer;"},"Ljava/nio/ByteBuffer;"));
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,5,8,new Field("Lorg/mortbay/io/nio/DirectNIOBuffer;","_buf","Ljava/nio/ByteBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,7},new Method("Ljava/nio/ByteBuffer;","position",new String[]{ "I"},"Ljava/nio/Buffer;"));
                code.visitLabel(L23);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/nio/ByteBuffer;","capacity",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Ljava/nio/ByteBuffer;","limit",new String[]{ "I"},"Ljava/nio/Buffer;"));
                code.visitLabel(L24);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,7},new Method("Ljava/nio/ByteBuffer;","position",new String[]{ "I"},"Ljava/nio/Buffer;"));
                code.visitStmt2R(MOVE,5,1);
                code.visitLabel(L25);
                code.visitJumpStmt(GOTO,-1,-1,L9);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,5);
                code.visitFieldStmt(IGET_OBJECT,6,8,new Field("Lorg/mortbay/io/nio/DirectNIOBuffer;","_buf","Ljava/nio/ByteBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,7},new Method("Ljava/nio/ByteBuffer;","position",new String[]{ "I"},"Ljava/nio/Buffer;"));
                code.visitLabel(L26);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/nio/ByteBuffer;","capacity",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,6},new Method("Ljava/nio/ByteBuffer;","limit",new String[]{ "I"},"Ljava/nio/Buffer;"));
                code.visitLabel(L27);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,7},new Method("Ljava/nio/ByteBuffer;","position",new String[]{ "I"},"Ljava/nio/Buffer;"));
                code.visitLabel(L28);
                code.visitStmt1R(THROW,5);
                code.visitLabel(L29);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 8,9,10},new Method("Lorg/mortbay/io/AbstractBuffer;","poke",new String[]{ "I","Lorg/mortbay/io/Buffer;"},"I"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitJumpStmt(GOTO,-1,-1,L9);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m010_poke(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/nio/DirectNIOBuffer;","poke",new String[]{ "I","[B","I","I"},"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(9);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"index");
                ddv.visitParameterName(1,"b");
                ddv.visitParameterName(2,"offset");
                ddv.visitParameterName(3,"length");
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(181,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(183,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(185,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(187,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(188,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(189,L9);
                ddv.visitLineNumber(194,L0);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(196,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(198,L11);
                ddv.visitStartLocal(0,L11,"space","I",null);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(199,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(200,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(201,L14);
                ddv.visitLineNumber(206,L1);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(202,L15);
                ddv.visitLineNumber(206,L2);
                ddv.visitEndLocal(0,L2);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/io/nio/DirectNIOBuffer;","isReadOnly",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_EQZ,1,-1,L5);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/lang/IllegalStateException;");
                code.visitConstStmt(CONST_STRING,2,"READONLY");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,2},new Method("Ljava/lang/IllegalStateException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,1);
                code.visitLabel(L5);
                code.visitJumpStmt(IF_GEZ,5,-1,L6);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/lang/IllegalArgumentException;");
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,3,"index<0: ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "I"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitConstStmt(CONST_STRING,3,"<0");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,2},new Method("Ljava/lang/IllegalArgumentException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,1);
                code.visitLabel(L6);
                code.visitStmt3R(ADD_INT,1,5,8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/io/nio/DirectNIOBuffer;","capacity",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_LE,1,2,L0);
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/io/nio/DirectNIOBuffer;","capacity",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitStmt3R(SUB_INT,8,1,5);
                code.visitLabel(L8);
                code.visitJumpStmt(IF_GEZ,8,-1,L0);
                code.visitLabel(L9);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/lang/IllegalArgumentException;");
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,3,"index>capacity(): ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "I"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitConstStmt(CONST_STRING,3,">");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/io/nio/DirectNIOBuffer;","capacity",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "I"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,2},new Method("Ljava/lang/IllegalArgumentException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,1);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/io/nio/DirectNIOBuffer;","_buf","Ljava/nio/ByteBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,5},new Method("Ljava/nio/ByteBuffer;","position",new String[]{ "I"},"Ljava/nio/Buffer;"));
                code.visitLabel(L10);
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/io/nio/DirectNIOBuffer;","_buf","Ljava/nio/ByteBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/nio/ByteBuffer;","remaining",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitLabel(L11);
                code.visitJumpStmt(IF_LE,8,0,L13);
                code.visitLabel(L12);
                code.visitStmt2R(MOVE,8,0);
                code.visitLabel(L13);
                code.visitJumpStmt(IF_LEZ,8,-1,L1);
                code.visitLabel(L14);
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/io/nio/DirectNIOBuffer;","_buf","Ljava/nio/ByteBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,6,7,8},new Method("Ljava/nio/ByteBuffer;","put",new String[]{ "[B","I","I"},"Ljava/nio/ByteBuffer;"));
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/io/nio/DirectNIOBuffer;","_buf","Ljava/nio/ByteBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,3},new Method("Ljava/nio/ByteBuffer;","position",new String[]{ "I"},"Ljava/nio/Buffer;"));
                code.visitLabel(L15);
                code.visitStmt1R(RETURN,8);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitFieldStmt(IGET_OBJECT,2,4,new Field("Lorg/mortbay/io/nio/DirectNIOBuffer;","_buf","Ljava/nio/ByteBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/nio/ByteBuffer;","position",new String[]{ "I"},"Ljava/nio/Buffer;"));
                code.visitStmt1R(THROW,1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m011_poke(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/nio/DirectNIOBuffer;","poke",new String[]{ "I","B"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"index");
                ddv.visitParameterName(1,"b");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(127,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(128,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(129,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(130,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(131,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(132,L5);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/io/nio/DirectNIOBuffer;","isReadOnly",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L1);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/IllegalStateException;");
                code.visitConstStmt(CONST_STRING,1,"READONLY");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Ljava/lang/IllegalStateException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,0);
                code.visitLabel(L1);
                code.visitJumpStmt(IF_GEZ,4,-1,L2);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/IllegalArgumentException;");
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,2,"index<0: ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "I"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitConstStmt(CONST_STRING,2,"<0");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Ljava/lang/IllegalArgumentException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,0);
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/io/nio/DirectNIOBuffer;","capacity",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_LE,4,0,L4);
                code.visitLabel(L3);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/IllegalArgumentException;");
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,2,"index>capacity(): ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "I"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitConstStmt(CONST_STRING,2,">");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/io/nio/DirectNIOBuffer;","capacity",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "I"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Ljava/lang/IllegalArgumentException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,0);
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/io/nio/DirectNIOBuffer;","_buf","Ljava/nio/ByteBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,4,5},new Method("Ljava/nio/ByteBuffer;","put",new String[]{ "I","B"},"Ljava/nio/ByteBuffer;"));
                code.visitLabel(L5);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m012_readFrom(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/nio/DirectNIOBuffer;","readFrom",new String[]{ "Ljava/io/InputStream;","I"},"I"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(14);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                DexLabel L3=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2,L3},new String[]{ "Ljava/io/IOException;",null});
                DexLabel L4=new DexLabel();
                DexLabel L5=new DexLabel();
                code.visitTryCatch(L4,L5,new DexLabel[]{L2,L3},new String[]{ "Ljava/io/IOException;",null});
                DexLabel L6=new DexLabel();
                DexLabel L7=new DexLabel();
                DexLabel L8=new DexLabel();
                DexLabel L9=new DexLabel();
                code.visitTryCatch(L6,L7,new DexLabel[]{L8,L9},new String[]{ "Ljava/io/IOException;",null});
                DexLabel L10=new DexLabel();
                code.visitTryCatch(L10,L9,new DexLabel[]{L9},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"in");
                ddv.visitParameterName(1,"max");
                DexLabel L11=new DexLabel();
                ddv.visitPrologue(L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(219,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(221,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(222,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(225,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(226,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(227,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(231,L18);
                ddv.visitStartLocal(5,L18,"p","I",null);
                DexLabel L19=new DexLabel();
                ddv.visitStartLocal(2,L19,"len","I",null);
                DexLabel L20=new DexLabel();
                ddv.visitStartLocal(6,L20,"total","I",null);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(232,L21);
                ddv.visitStartLocal(0,L21,"available","I",null);
                DexLabel L22=new DexLabel();
                ddv.visitStartLocal(3,L22,"loop","I",null);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(233,L23);
                ddv.visitEndLocal(3,L23);
                ddv.visitStartLocal(4,L23,"loop","I",null);
                ddv.visitLineNumber(235,L0);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(236,L24);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(237,L25);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(238,L26);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(240,L27);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(241,L28);
                DexLabel L29=new DexLabel();
                ddv.visitLineNumber(257,L29);
                ddv.visitEndLocal(4,L29);
                ddv.visitRestartLocal(3,L29);
                DexLabel L30=new DexLabel();
                ddv.visitLineNumber(258,L30);
                DexLabel L31=new DexLabel();
                ddv.visitLineNumber(270,L31);
                DexLabel L32=new DexLabel();
                ddv.visitLineNumber(272,L32);
                DexLabel L33=new DexLabel();
                ddv.visitLineNumber(273,L33);
                DexLabel L34=new DexLabel();
                ddv.visitLineNumber(275,L34);
                DexLabel L35=new DexLabel();
                ddv.visitLineNumber(276,L35);
                DexLabel L36=new DexLabel();
                ddv.visitLineNumber(259,L36);
                DexLabel L37=new DexLabel();
                ddv.visitLineNumber(244,L37);
                ddv.visitEndLocal(3,L37);
                ddv.visitRestartLocal(4,L37);
                DexLabel L38=new DexLabel();
                ddv.visitLineNumber(246,L38);
                DexLabel L39=new DexLabel();
                ddv.visitLineNumber(247,L39);
                DexLabel L40=new DexLabel();
                ddv.visitLineNumber(248,L40);
                ddv.visitLineNumber(249,L4);
                ddv.visitLineNumber(250,L5);
                ddv.visitLineNumber(254,L6);
                ddv.visitEndLocal(4,L6);
                ddv.visitRestartLocal(3,L6);
                DexLabel L41=new DexLabel();
                ddv.visitRestartLocal(4,L41);
                DexLabel L42=new DexLabel();
                ddv.visitLineNumber(252,L42);
                ddv.visitEndLocal(3,L42);
                DexLabel L43=new DexLabel();
                ddv.visitRestartLocal(3,L43);
                DexLabel L44=new DexLabel();
                ddv.visitLineNumber(270,L44);
                ddv.visitEndLocal(4,L44);
                DexLabel L45=new DexLabel();
                ddv.visitLineNumber(272,L45);
                DexLabel L46=new DexLabel();
                ddv.visitLineNumber(273,L46);
                DexLabel L47=new DexLabel();
                ddv.visitLineNumber(275,L47);
                DexLabel L48=new DexLabel();
                ddv.visitLineNumber(276,L48);
                DexLabel L49=new DexLabel();
                ddv.visitLineNumber(259,L49);
                ddv.visitLineNumber(262,L2);
                ddv.visitEndLocal(3,L2);
                ddv.visitRestartLocal(4,L2);
                DexLabel L50=new DexLabel();
                ddv.visitLineNumber(264,L50);
                ddv.visitEndLocal(4,L50);
                ddv.visitRestartLocal(3,L50);
                ddv.visitStartLocal(1,L50,"e","Ljava/io/IOException;",null);
                DexLabel L51=new DexLabel();
                ddv.visitLineNumber(265,L51);
                DexLabel L52=new DexLabel();
                ddv.visitLineNumber(266,L52);
                ddv.visitLineNumber(270,L9);
                ddv.visitEndLocal(1,L9);
                DexLabel L53=new DexLabel();
                ddv.visitLineNumber(272,L53);
                DexLabel L54=new DexLabel();
                ddv.visitLineNumber(273,L54);
                DexLabel L55=new DexLabel();
                ddv.visitLineNumber(275,L55);
                DexLabel L56=new DexLabel();
                ddv.visitLineNumber(276,L56);
                DexLabel L57=new DexLabel();
                ddv.visitLineNumber(270,L57);
                ddv.visitEndLocal(3,L3);
                ddv.visitRestartLocal(4,L3);
                DexLabel L58=new DexLabel();
                ddv.visitRestartLocal(3,L58);
                ddv.visitLineNumber(262,L8);
                ddv.visitEndLocal(4,L8);
                DexLabel L59=new DexLabel();
                ddv.visitEndLocal(3,L59);
                ddv.visitRestartLocal(4,L59);
                DexLabel L60=new DexLabel();
                ddv.visitRestartLocal(3,L60);
                code.visitLabel(L11);
                code.visitConstStmt(CONST_4,10, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitConstStmt(CONST_4,9, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L12);
                code.visitFieldStmt(IGET_OBJECT,7,11,new Field("Lorg/mortbay/io/nio/DirectNIOBuffer;","_in","Ljava/nio/channels/ReadableByteChannel;"));
                code.visitJumpStmt(IF_EQZ,7,-1,L13);
                code.visitFieldStmt(IGET_OBJECT,7,11,new Field("Lorg/mortbay/io/nio/DirectNIOBuffer;","_in","Ljava/nio/channels/ReadableByteChannel;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 7},new Method("Ljava/nio/channels/ReadableByteChannel;","isOpen",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitJumpStmt(IF_EQZ,7,-1,L13);
                code.visitFieldStmt(IGET_OBJECT,7,11,new Field("Lorg/mortbay/io/nio/DirectNIOBuffer;","_inStream","Ljava/io/InputStream;"));
                code.visitJumpStmt(IF_EQ,12,7,L15);
                code.visitLabel(L13);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 12},new Method("Ljava/nio/channels/Channels;","newChannel",new String[]{ "Ljava/io/InputStream;"},"Ljava/nio/channels/ReadableByteChannel;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitFieldStmt(IPUT_OBJECT,7,11,new Field("Lorg/mortbay/io/nio/DirectNIOBuffer;","_in","Ljava/nio/channels/ReadableByteChannel;"));
                code.visitLabel(L14);
                code.visitFieldStmt(IPUT_OBJECT,12,11,new Field("Lorg/mortbay/io/nio/DirectNIOBuffer;","_inStream","Ljava/io/InputStream;"));
                code.visitLabel(L15);
                code.visitJumpStmt(IF_LTZ,13,-1,L16);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11},new Method("Lorg/mortbay/io/nio/DirectNIOBuffer;","space",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitJumpStmt(IF_LE,13,7,L17);
                code.visitLabel(L16);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11},new Method("Lorg/mortbay/io/nio/DirectNIOBuffer;","space",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,13);
                code.visitLabel(L17);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11},new Method("Lorg/mortbay/io/nio/DirectNIOBuffer;","putIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitLabel(L18);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L19);
                code.visitConstStmt(CONST_4,6, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L20);
                code.visitStmt2R(MOVE,0,13);
                code.visitLabel(L21);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L22);
                code.visitStmt2R(MOVE,4,3);
                code.visitLabel(L23);
                code.visitJumpStmt(IF_GE,6,13,L59);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,7,11,new Field("Lorg/mortbay/io/nio/DirectNIOBuffer;","_buf","Ljava/nio/ByteBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,5},new Method("Ljava/nio/ByteBuffer;","position",new String[]{ "I"},"Ljava/nio/Buffer;"));
                code.visitLabel(L24);
                code.visitFieldStmt(IGET_OBJECT,7,11,new Field("Lorg/mortbay/io/nio/DirectNIOBuffer;","_buf","Ljava/nio/ByteBuffer;"));
                code.visitStmt3R(ADD_INT,8,5,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,8},new Method("Ljava/nio/ByteBuffer;","limit",new String[]{ "I"},"Ljava/nio/Buffer;"));
                code.visitLabel(L25);
                code.visitFieldStmt(IGET_OBJECT,7,11,new Field("Lorg/mortbay/io/nio/DirectNIOBuffer;","_in","Ljava/nio/channels/ReadableByteChannel;"));
                code.visitFieldStmt(IGET_OBJECT,8,11,new Field("Lorg/mortbay/io/nio/DirectNIOBuffer;","_buf","Ljava/nio/ByteBuffer;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 7,8},new Method("Ljava/nio/channels/ReadableByteChannel;","read",new String[]{ "Ljava/nio/ByteBuffer;"},"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitLabel(L26);
                code.visitJumpStmt(IF_GEZ,2,-1,L37);
                code.visitLabel(L27);
                code.visitConstStmt(CONST_4,7, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_OBJECT,7,11,new Field("Lorg/mortbay/io/nio/DirectNIOBuffer;","_in","Ljava/nio/channels/ReadableByteChannel;"));
                code.visitLabel(L28);
                code.visitFieldStmt(IPUT_OBJECT,12,11,new Field("Lorg/mortbay/io/nio/DirectNIOBuffer;","_inStream","Ljava/io/InputStream;"));
                code.visitLabel(L1);
                code.visitStmt2R(MOVE,3,4);
                code.visitLabel(L29);
                code.visitJumpStmt(IF_GEZ,2,-1,L44);
                code.visitJumpStmt(IF_NEZ,6,-1,L44);
                code.visitLabel(L30);
                code.visitConstStmt(CONST_4,7, Integer.valueOf(-1)); // int: 0xffffffff  float:NaN
                code.visitLabel(L31);
                code.visitFieldStmt(IGET_OBJECT,8,11,new Field("Lorg/mortbay/io/nio/DirectNIOBuffer;","_in","Ljava/nio/channels/ReadableByteChannel;"));
                code.visitJumpStmt(IF_EQZ,8,-1,L34);
                code.visitFieldStmt(IGET_OBJECT,8,11,new Field("Lorg/mortbay/io/nio/DirectNIOBuffer;","_in","Ljava/nio/channels/ReadableByteChannel;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 8},new Method("Ljava/nio/channels/ReadableByteChannel;","isOpen",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitJumpStmt(IF_NEZ,8,-1,L34);
                code.visitLabel(L32);
                code.visitFieldStmt(IPUT_OBJECT,9,11,new Field("Lorg/mortbay/io/nio/DirectNIOBuffer;","_in","Ljava/nio/channels/ReadableByteChannel;"));
                code.visitLabel(L33);
                code.visitFieldStmt(IPUT_OBJECT,12,11,new Field("Lorg/mortbay/io/nio/DirectNIOBuffer;","_inStream","Ljava/io/InputStream;"));
                code.visitLabel(L34);
                code.visitFieldStmt(IGET_OBJECT,8,11,new Field("Lorg/mortbay/io/nio/DirectNIOBuffer;","_buf","Ljava/nio/ByteBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,10},new Method("Ljava/nio/ByteBuffer;","position",new String[]{ "I"},"Ljava/nio/Buffer;"));
                code.visitLabel(L35);
                code.visitFieldStmt(IGET_OBJECT,8,11,new Field("Lorg/mortbay/io/nio/DirectNIOBuffer;","_buf","Ljava/nio/ByteBuffer;"));
                code.visitFieldStmt(IGET_OBJECT,9,11,new Field("Lorg/mortbay/io/nio/DirectNIOBuffer;","_buf","Ljava/nio/ByteBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9},new Method("Ljava/nio/ByteBuffer;","capacity",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,9},new Method("Ljava/nio/ByteBuffer;","limit",new String[]{ "I"},"Ljava/nio/Buffer;"));
                code.visitLabel(L36);
                code.visitStmt1R(RETURN,7);
                code.visitLabel(L37);
                code.visitJumpStmt(IF_LEZ,2,-1,L42);
                code.visitLabel(L38);
                code.visitStmt2R(ADD_INT_2ADDR,5,2);
                code.visitLabel(L39);
                code.visitStmt2R(ADD_INT_2ADDR,6,2);
                code.visitLabel(L40);
                code.visitStmt2R(SUB_INT_2ADDR,0,2);
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11,5},new Method("Lorg/mortbay/io/nio/DirectNIOBuffer;","setPutIndex",new String[]{ "I"},"V"));
                code.visitLabel(L5);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12},new Method("Ljava/io/InputStream;","available",new String[]{ },"I"));
                code.visitLabel(L7);
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitJumpStmt(IF_LEZ,7,-1,L29);
                code.visitStmt2R(MOVE,4,3);
                code.visitLabel(L41);
                code.visitJumpStmt(GOTO,-1,-1,L23);
                code.visitLabel(L42);
                code.visitStmt2R1N(ADD_INT_LIT8,3,4,1);
                code.visitLabel(L43);
                code.visitConstStmt(CONST_4,7, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitJumpStmt(IF_LE,4,7,L6);
                code.visitJumpStmt(GOTO,-1,-1,L29);
                code.visitLabel(L44);
                code.visitFieldStmt(IGET_OBJECT,7,11,new Field("Lorg/mortbay/io/nio/DirectNIOBuffer;","_in","Ljava/nio/channels/ReadableByteChannel;"));
                code.visitJumpStmt(IF_EQZ,7,-1,L47);
                code.visitFieldStmt(IGET_OBJECT,7,11,new Field("Lorg/mortbay/io/nio/DirectNIOBuffer;","_in","Ljava/nio/channels/ReadableByteChannel;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 7},new Method("Ljava/nio/channels/ReadableByteChannel;","isOpen",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitJumpStmt(IF_NEZ,7,-1,L47);
                code.visitLabel(L45);
                code.visitFieldStmt(IPUT_OBJECT,9,11,new Field("Lorg/mortbay/io/nio/DirectNIOBuffer;","_in","Ljava/nio/channels/ReadableByteChannel;"));
                code.visitLabel(L46);
                code.visitFieldStmt(IPUT_OBJECT,12,11,new Field("Lorg/mortbay/io/nio/DirectNIOBuffer;","_inStream","Ljava/io/InputStream;"));
                code.visitLabel(L47);
                code.visitFieldStmt(IGET_OBJECT,7,11,new Field("Lorg/mortbay/io/nio/DirectNIOBuffer;","_buf","Ljava/nio/ByteBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,10},new Method("Ljava/nio/ByteBuffer;","position",new String[]{ "I"},"Ljava/nio/Buffer;"));
                code.visitLabel(L48);
                code.visitFieldStmt(IGET_OBJECT,7,11,new Field("Lorg/mortbay/io/nio/DirectNIOBuffer;","_buf","Ljava/nio/ByteBuffer;"));
                code.visitFieldStmt(IGET_OBJECT,8,11,new Field("Lorg/mortbay/io/nio/DirectNIOBuffer;","_buf","Ljava/nio/ByteBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Ljava/nio/ByteBuffer;","capacity",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,8},new Method("Ljava/nio/ByteBuffer;","limit",new String[]{ "I"},"Ljava/nio/Buffer;"));
                code.visitStmt2R(MOVE,7,6);
                code.visitLabel(L49);
                code.visitJumpStmt(GOTO,-1,-1,L36);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,7);
                code.visitStmt2R(MOVE_OBJECT,1,7);
                code.visitStmt2R(MOVE,3,4);
                code.visitLabel(L50);
                code.visitConstStmt(CONST_4,7, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L10);
                code.visitFieldStmt(IPUT_OBJECT,7,11,new Field("Lorg/mortbay/io/nio/DirectNIOBuffer;","_in","Ljava/nio/channels/ReadableByteChannel;"));
                code.visitLabel(L51);
                code.visitFieldStmt(IPUT_OBJECT,12,11,new Field("Lorg/mortbay/io/nio/DirectNIOBuffer;","_inStream","Ljava/io/InputStream;"));
                code.visitLabel(L52);
                code.visitStmt1R(THROW,1);
                code.visitLabel(L9);
                code.visitStmt1R(MOVE_EXCEPTION,7);
                DexLabel L61=new DexLabel();
                code.visitLabel(L61);
                code.visitFieldStmt(IGET_OBJECT,8,11,new Field("Lorg/mortbay/io/nio/DirectNIOBuffer;","_in","Ljava/nio/channels/ReadableByteChannel;"));
                code.visitJumpStmt(IF_EQZ,8,-1,L55);
                code.visitFieldStmt(IGET_OBJECT,8,11,new Field("Lorg/mortbay/io/nio/DirectNIOBuffer;","_in","Ljava/nio/channels/ReadableByteChannel;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 8},new Method("Ljava/nio/channels/ReadableByteChannel;","isOpen",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitJumpStmt(IF_NEZ,8,-1,L55);
                code.visitLabel(L53);
                code.visitFieldStmt(IPUT_OBJECT,9,11,new Field("Lorg/mortbay/io/nio/DirectNIOBuffer;","_in","Ljava/nio/channels/ReadableByteChannel;"));
                code.visitLabel(L54);
                code.visitFieldStmt(IPUT_OBJECT,12,11,new Field("Lorg/mortbay/io/nio/DirectNIOBuffer;","_inStream","Ljava/io/InputStream;"));
                code.visitLabel(L55);
                code.visitFieldStmt(IGET_OBJECT,8,11,new Field("Lorg/mortbay/io/nio/DirectNIOBuffer;","_buf","Ljava/nio/ByteBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,10},new Method("Ljava/nio/ByteBuffer;","position",new String[]{ "I"},"Ljava/nio/Buffer;"));
                code.visitLabel(L56);
                code.visitFieldStmt(IGET_OBJECT,8,11,new Field("Lorg/mortbay/io/nio/DirectNIOBuffer;","_buf","Ljava/nio/ByteBuffer;"));
                code.visitFieldStmt(IGET_OBJECT,9,11,new Field("Lorg/mortbay/io/nio/DirectNIOBuffer;","_buf","Ljava/nio/ByteBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9},new Method("Ljava/nio/ByteBuffer;","capacity",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,9},new Method("Ljava/nio/ByteBuffer;","limit",new String[]{ "I"},"Ljava/nio/Buffer;"));
                code.visitLabel(L57);
                code.visitStmt1R(THROW,7);
                code.visitLabel(L3);
                code.visitStmt1R(MOVE_EXCEPTION,7);
                code.visitStmt2R(MOVE,3,4);
                code.visitLabel(L58);
                code.visitJumpStmt(GOTO,-1,-1,L61);
                code.visitLabel(L8);
                code.visitStmt1R(MOVE_EXCEPTION,7);
                code.visitStmt2R(MOVE_OBJECT,1,7);
                code.visitJumpStmt(GOTO,-1,-1,L50);
                code.visitLabel(L59);
                code.visitStmt2R(MOVE,3,4);
                code.visitLabel(L60);
                code.visitJumpStmt(GOTO_16,-1,-1,L29);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m013_writeTo(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/nio/DirectNIOBuffer;","writeTo",new String[]{ "Ljava/io/OutputStream;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(10);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                DexLabel L3=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2,L3},new String[]{ "Ljava/io/IOException;",null});
                DexLabel L4=new DexLabel();
                DexLabel L5=new DexLabel();
                DexLabel L6=new DexLabel();
                code.visitTryCatch(L4,L5,new DexLabel[]{L6},new String[]{ null});
                DexLabel L7=new DexLabel();
                DexLabel L8=new DexLabel();
                code.visitTryCatch(L7,L8,new DexLabel[]{L2,L3},new String[]{ "Ljava/io/IOException;",null});
                DexLabel L9=new DexLabel();
                code.visitTryCatch(L9,L3,new DexLabel[]{L3},new String[]{ null});
                DexLabel L10=new DexLabel();
                DexLabel L11=new DexLabel();
                code.visitTryCatch(L10,L11,new DexLabel[]{L6},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"out");
                DexLabel L12=new DexLabel();
                ddv.visitPrologue(L12);
                ddv.visitLineNumber(283,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(285,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(286,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(289,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(293,L16);
                DexLabel L17=new DexLabel();
                ddv.visitStartLocal(2,L17,"loop","I",null);
                ddv.visitLineNumber(294,L0);
                ddv.visitEndLocal(2,L0);
                ddv.visitStartLocal(3,L0,"loop","I",null);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(296,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(297,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(298,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(299,L21);
                ddv.visitStartLocal(1,L21,"len","I",null);
                ddv.visitLineNumber(319,L4);
                ddv.visitEndLocal(3,L4);
                ddv.visitEndLocal(1,L4);
                ddv.visitRestartLocal(2,L4);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(321,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(322,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(324,L24);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(325,L25);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(327,L26);
                ddv.visitLineNumber(328,L5);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(301,L27);
                ddv.visitEndLocal(2,L27);
                ddv.visitRestartLocal(1,L27);
                ddv.visitRestartLocal(3,L27);
                ddv.visitLineNumber(303,L7);
                ddv.visitLineNumber(304,L8);
                DexLabel L28=new DexLabel();
                ddv.visitEndLocal(3,L28);
                ddv.visitRestartLocal(2,L28);
                DexLabel L29=new DexLabel();
                ddv.visitLineNumber(308,L29);
                ddv.visitRestartLocal(3,L29);
                DexLabel L30=new DexLabel();
                ddv.visitLineNumber(306,L30);
                ddv.visitEndLocal(2,L30);
                DexLabel L31=new DexLabel();
                ddv.visitRestartLocal(2,L31);
                ddv.visitLineNumber(311,L2);
                ddv.visitEndLocal(1,L2);
                ddv.visitEndLocal(2,L2);
                DexLabel L32=new DexLabel();
                ddv.visitLineNumber(313,L32);
                ddv.visitStartLocal(0,L32,"e","Ljava/io/IOException;",null);
                DexLabel L33=new DexLabel();
                ddv.visitLineNumber(314,L33);
                DexLabel L34=new DexLabel();
                ddv.visitLineNumber(315,L34);
                ddv.visitLineNumber(319,L3);
                ddv.visitEndLocal(0,L3);
                DexLabel L35=new DexLabel();
                ddv.visitLineNumber(321,L35);
                DexLabel L36=new DexLabel();
                ddv.visitLineNumber(322,L36);
                DexLabel L37=new DexLabel();
                ddv.visitLineNumber(324,L37);
                DexLabel L38=new DexLabel();
                ddv.visitLineNumber(325,L38);
                DexLabel L39=new DexLabel();
                ddv.visitLineNumber(319,L39);
                ddv.visitLineNumber(327,L6);
                ddv.visitEndLocal(3,L6);
                DexLabel L40=new DexLabel();
                ddv.visitRestartLocal(3,L40);
                DexLabel L41=new DexLabel();
                ddv.visitRestartLocal(2,L41);
                code.visitLabel(L12);
                code.visitFieldStmt(IGET_OBJECT,4,8,new Field("Lorg/mortbay/io/nio/DirectNIOBuffer;","_out","Ljava/nio/channels/WritableByteChannel;"));
                code.visitJumpStmt(IF_EQZ,4,-1,L13);
                code.visitFieldStmt(IGET_OBJECT,4,8,new Field("Lorg/mortbay/io/nio/DirectNIOBuffer;","_out","Ljava/nio/channels/WritableByteChannel;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 4},new Method("Ljava/nio/channels/WritableByteChannel;","isOpen",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitJumpStmt(IF_EQZ,4,-1,L13);
                code.visitFieldStmt(IGET_OBJECT,4,8,new Field("Lorg/mortbay/io/nio/DirectNIOBuffer;","_out","Ljava/nio/channels/WritableByteChannel;"));
                code.visitFieldStmt(IGET_OBJECT,5,8,new Field("Lorg/mortbay/io/nio/DirectNIOBuffer;","_outStream","Ljava/io/OutputStream;"));
                code.visitJumpStmt(IF_EQ,4,5,L15);
                code.visitLabel(L13);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 9},new Method("Ljava/nio/channels/Channels;","newChannel",new String[]{ "Ljava/io/OutputStream;"},"Ljava/nio/channels/WritableByteChannel;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitFieldStmt(IPUT_OBJECT,4,8,new Field("Lorg/mortbay/io/nio/DirectNIOBuffer;","_out","Ljava/nio/channels/WritableByteChannel;"));
                code.visitLabel(L14);
                code.visitFieldStmt(IPUT_OBJECT,9,8,new Field("Lorg/mortbay/io/nio/DirectNIOBuffer;","_outStream","Ljava/io/OutputStream;"));
                code.visitLabel(L15);
                code.visitFieldStmt(IGET_OBJECT,4,8,new Field("Lorg/mortbay/io/nio/DirectNIOBuffer;","_buf","Ljava/nio/ByteBuffer;"));
                code.visitStmt1R(MONITOR_ENTER,4);
                code.visitLabel(L16);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L17);
                code.visitStmt2R(MOVE,3,2);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Lorg/mortbay/io/nio/DirectNIOBuffer;","hasContent",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitJumpStmt(IF_EQZ,5,-1,L40);
                code.visitFieldStmt(IGET_OBJECT,5,8,new Field("Lorg/mortbay/io/nio/DirectNIOBuffer;","_out","Ljava/nio/channels/WritableByteChannel;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 5},new Method("Ljava/nio/channels/WritableByteChannel;","isOpen",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitJumpStmt(IF_EQZ,5,-1,L40);
                code.visitLabel(L18);
                code.visitFieldStmt(IGET_OBJECT,5,8,new Field("Lorg/mortbay/io/nio/DirectNIOBuffer;","_buf","Ljava/nio/ByteBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Lorg/mortbay/io/nio/DirectNIOBuffer;","getIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Ljava/nio/ByteBuffer;","position",new String[]{ "I"},"Ljava/nio/Buffer;"));
                code.visitLabel(L19);
                code.visitFieldStmt(IGET_OBJECT,5,8,new Field("Lorg/mortbay/io/nio/DirectNIOBuffer;","_buf","Ljava/nio/ByteBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Lorg/mortbay/io/nio/DirectNIOBuffer;","putIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Ljava/nio/ByteBuffer;","limit",new String[]{ "I"},"Ljava/nio/Buffer;"));
                code.visitLabel(L20);
                code.visitFieldStmt(IGET_OBJECT,5,8,new Field("Lorg/mortbay/io/nio/DirectNIOBuffer;","_out","Ljava/nio/channels/WritableByteChannel;"));
                code.visitFieldStmt(IGET_OBJECT,6,8,new Field("Lorg/mortbay/io/nio/DirectNIOBuffer;","_buf","Ljava/nio/ByteBuffer;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 5,6},new Method("Ljava/nio/channels/WritableByteChannel;","write",new String[]{ "Ljava/nio/ByteBuffer;"},"I"));
                code.visitLabel(L1);
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitLabel(L21);
                code.visitJumpStmt(IF_GEZ,1,-1,L27);
                code.visitStmt2R(MOVE,2,3);
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,5,8,new Field("Lorg/mortbay/io/nio/DirectNIOBuffer;","_out","Ljava/nio/channels/WritableByteChannel;"));
                code.visitJumpStmt(IF_EQZ,5,-1,L24);
                code.visitFieldStmt(IGET_OBJECT,5,8,new Field("Lorg/mortbay/io/nio/DirectNIOBuffer;","_out","Ljava/nio/channels/WritableByteChannel;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 5},new Method("Ljava/nio/channels/WritableByteChannel;","isOpen",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitJumpStmt(IF_NEZ,5,-1,L24);
                code.visitLabel(L22);
                code.visitConstStmt(CONST_4,5, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_OBJECT,5,8,new Field("Lorg/mortbay/io/nio/DirectNIOBuffer;","_out","Ljava/nio/channels/WritableByteChannel;"));
                code.visitLabel(L23);
                code.visitConstStmt(CONST_4,5, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_OBJECT,5,8,new Field("Lorg/mortbay/io/nio/DirectNIOBuffer;","_outStream","Ljava/io/OutputStream;"));
                code.visitLabel(L24);
                code.visitFieldStmt(IGET_OBJECT,5,8,new Field("Lorg/mortbay/io/nio/DirectNIOBuffer;","_buf","Ljava/nio/ByteBuffer;"));
                code.visitConstStmt(CONST_4,6, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Ljava/nio/ByteBuffer;","position",new String[]{ "I"},"Ljava/nio/Buffer;"));
                code.visitLabel(L25);
                code.visitFieldStmt(IGET_OBJECT,5,8,new Field("Lorg/mortbay/io/nio/DirectNIOBuffer;","_buf","Ljava/nio/ByteBuffer;"));
                code.visitFieldStmt(IGET_OBJECT,6,8,new Field("Lorg/mortbay/io/nio/DirectNIOBuffer;","_buf","Ljava/nio/ByteBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/nio/ByteBuffer;","capacity",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Ljava/nio/ByteBuffer;","limit",new String[]{ "I"},"Ljava/nio/Buffer;"));
                code.visitLabel(L26);
                code.visitStmt1R(MONITOR_EXIT,4);
                code.visitLabel(L5);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L27);
                code.visitJumpStmt(IF_LEZ,1,-1,L30);
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,1},new Method("Lorg/mortbay/io/nio/DirectNIOBuffer;","skip",new String[]{ "I"},"I"));
                code.visitLabel(L8);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L28);
                code.visitStmt2R(MOVE,3,2);
                code.visitLabel(L29);
                code.visitJumpStmt(GOTO,-1,-1,L0);
                code.visitLabel(L30);
                code.visitStmt2R1N(ADD_INT_LIT8,2,3,1);
                code.visitLabel(L31);
                code.visitConstStmt(CONST_4,5, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitJumpStmt(IF_LE,3,5,L28);
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,5);
                code.visitStmt2R(MOVE_OBJECT,0,5);
                code.visitLabel(L32);
                code.visitConstStmt(CONST_4,5, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L9);
                code.visitFieldStmt(IPUT_OBJECT,5,8,new Field("Lorg/mortbay/io/nio/DirectNIOBuffer;","_out","Ljava/nio/channels/WritableByteChannel;"));
                code.visitLabel(L33);
                code.visitConstStmt(CONST_4,5, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_OBJECT,5,8,new Field("Lorg/mortbay/io/nio/DirectNIOBuffer;","_outStream","Ljava/io/OutputStream;"));
                code.visitLabel(L34);
                code.visitStmt1R(THROW,0);
                code.visitLabel(L3);
                code.visitStmt1R(MOVE_EXCEPTION,5);
                code.visitLabel(L10);
                code.visitFieldStmt(IGET_OBJECT,6,8,new Field("Lorg/mortbay/io/nio/DirectNIOBuffer;","_out","Ljava/nio/channels/WritableByteChannel;"));
                code.visitJumpStmt(IF_EQZ,6,-1,L37);
                code.visitFieldStmt(IGET_OBJECT,6,8,new Field("Lorg/mortbay/io/nio/DirectNIOBuffer;","_out","Ljava/nio/channels/WritableByteChannel;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 6},new Method("Ljava/nio/channels/WritableByteChannel;","isOpen",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitJumpStmt(IF_NEZ,6,-1,L37);
                code.visitLabel(L35);
                code.visitConstStmt(CONST_4,6, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_OBJECT,6,8,new Field("Lorg/mortbay/io/nio/DirectNIOBuffer;","_out","Ljava/nio/channels/WritableByteChannel;"));
                code.visitLabel(L36);
                code.visitConstStmt(CONST_4,6, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_OBJECT,6,8,new Field("Lorg/mortbay/io/nio/DirectNIOBuffer;","_outStream","Ljava/io/OutputStream;"));
                code.visitLabel(L37);
                code.visitFieldStmt(IGET_OBJECT,6,8,new Field("Lorg/mortbay/io/nio/DirectNIOBuffer;","_buf","Ljava/nio/ByteBuffer;"));
                code.visitConstStmt(CONST_4,7, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,7},new Method("Ljava/nio/ByteBuffer;","position",new String[]{ "I"},"Ljava/nio/Buffer;"));
                code.visitLabel(L38);
                code.visitFieldStmt(IGET_OBJECT,6,8,new Field("Lorg/mortbay/io/nio/DirectNIOBuffer;","_buf","Ljava/nio/ByteBuffer;"));
                code.visitFieldStmt(IGET_OBJECT,7,8,new Field("Lorg/mortbay/io/nio/DirectNIOBuffer;","_buf","Ljava/nio/ByteBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Ljava/nio/ByteBuffer;","capacity",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,7},new Method("Ljava/nio/ByteBuffer;","limit",new String[]{ "I"},"Ljava/nio/Buffer;"));
                code.visitLabel(L39);
                code.visitStmt1R(THROW,5);
                code.visitLabel(L6);
                code.visitStmt1R(MOVE_EXCEPTION,5);
                code.visitStmt1R(MONITOR_EXIT,4);
                code.visitLabel(L11);
                code.visitStmt1R(THROW,5);
                code.visitLabel(L40);
                code.visitStmt2R(MOVE,2,3);
                code.visitLabel(L41);
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
