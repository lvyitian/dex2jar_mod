package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0158_org_mortbay_jetty_HttpFields_1 {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(0,"Lorg/mortbay/jetty/HttpFields$1;","Ljava/lang/Object;",new String[]{ "Ljava/util/Enumeration;"});
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("HttpFields.java");
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/EnclosingMethod;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("value", new Method("Lorg/mortbay/jetty/HttpFields;","getFieldNames",new String[]{ },"Ljava/util/Enumeration;"));
                av00.visitEnd();
            }
        }
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/InnerClass;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("accessFlags",  Integer.valueOf(0));
                av00.visit("name", null);
                av00.visitEnd();
            }
        }
        f000_field(cv);
        f001_i(cv);
        f002_this$0(cv);
        f003_val$revision(cv);
        m000__init_(cv);
        m001_hasMoreElements(cv);
        m002_nextElement(cv);
    }
    public static void f000_field(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/jetty/HttpFields$1;","field","Lorg/mortbay/jetty/HttpFields$Field;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001_i(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/jetty/HttpFields$1;","i","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002_this$0(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_FINAL|ACC_SYNTHETIC, new Field("Lorg/mortbay/jetty/HttpFields$1;","this$0","Lorg/mortbay/jetty/HttpFields;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003_val$revision(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_FINAL|ACC_SYNTHETIC, new Field("Lorg/mortbay/jetty/HttpFields$1;","val$revision","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/HttpFields$1;","<init>",new String[]{ "Lorg/mortbay/jetty/HttpFields;","I"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(240,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(222,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(223,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,2,1,new Field("Lorg/mortbay/jetty/HttpFields$1;","this$0","Lorg/mortbay/jetty/HttpFields;"));
                code.visitFieldStmt(IPUT,3,1,new Field("Lorg/mortbay/jetty/HttpFields$1;","val$revision","I"));
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljava/lang/Object;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT,0,1,new Field("Lorg/mortbay/jetty/HttpFields$1;","i","I"));
                code.visitLabel(L2);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/HttpFields$1;","field","Lorg/mortbay/jetty/HttpFields$Field;"));
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001_hasMoreElements(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpFields$1;","hasMoreElements",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(227,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(237,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(228,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(230,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(231,L5);
                ddv.visitStartLocal(0,L5,"f","Lorg/mortbay/jetty/HttpFields$Field;",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(233,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(234,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(237,L8);
                ddv.visitEndLocal(0,L8);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,1,5,new Field("Lorg/mortbay/jetty/HttpFields$1;","field","Lorg/mortbay/jetty/HttpFields$Field;"));
                code.visitJumpStmt(IF_EQZ,1,-1,L3);
                code.visitStmt2R(MOVE,1,4);
                code.visitLabel(L2);
                code.visitStmt1R(RETURN,1);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET,1,5,new Field("Lorg/mortbay/jetty/HttpFields$1;","i","I"));
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/jetty/HttpFields$1;","this$0","Lorg/mortbay/jetty/HttpFields;"));
                code.visitFieldStmt(IGET_OBJECT,2,2,new Field("Lorg/mortbay/jetty/HttpFields;","_fields","Ljava/util/ArrayList;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/util/ArrayList;","size",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_GE,1,2,L8);
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,1,5,new Field("Lorg/mortbay/jetty/HttpFields$1;","this$0","Lorg/mortbay/jetty/HttpFields;"));
                code.visitFieldStmt(IGET_OBJECT,1,1,new Field("Lorg/mortbay/jetty/HttpFields;","_fields","Ljava/util/ArrayList;"));
                code.visitFieldStmt(IGET,2,5,new Field("Lorg/mortbay/jetty/HttpFields$1;","i","I"));
                code.visitStmt2R1N(ADD_INT_LIT8,3,2,1);
                code.visitFieldStmt(IPUT,3,5,new Field("Lorg/mortbay/jetty/HttpFields$1;","i","I"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/util/ArrayList;","get",new String[]{ "I"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Lorg/mortbay/jetty/HttpFields$Field;");
                code.visitLabel(L5);
                code.visitJumpStmt(IF_EQZ,0,-1,L3);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/jetty/HttpFields$Field;","access$000",new String[]{ "Lorg/mortbay/jetty/HttpFields$Field;"},"Lorg/mortbay/jetty/HttpFields$Field;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitJumpStmt(IF_NEZ,1,-1,L3);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/jetty/HttpFields$Field;","access$100",new String[]{ "Lorg/mortbay/jetty/HttpFields$Field;"},"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitFieldStmt(IGET,2,5,new Field("Lorg/mortbay/jetty/HttpFields$1;","val$revision","I"));
                code.visitJumpStmt(IF_NE,1,2,L3);
                code.visitLabel(L6);
                code.visitFieldStmt(IPUT_OBJECT,0,5,new Field("Lorg/mortbay/jetty/HttpFields$1;","field","Lorg/mortbay/jetty/HttpFields$Field;"));
                code.visitStmt2R(MOVE,1,4);
                code.visitLabel(L7);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L8);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_nextElement(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpFields$1;","nextElement",new String[]{ },"Ljava/lang/Object;"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/util/NoSuchElementException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(242,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(244,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(245,L2);
                ddv.visitStartLocal(0,L2,"n","Ljava/lang/String;",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(246,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(248,L4);
                ddv.visitEndLocal(0,L4);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/HttpFields$1;","field","Lorg/mortbay/jetty/HttpFields$Field;"));
                code.visitJumpStmt(IF_NEZ,1,-1,L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/HttpFields$1;","hasMoreElements",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_EQZ,1,-1,L4);
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/HttpFields$1;","field","Lorg/mortbay/jetty/HttpFields$Field;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1},new Method("Lorg/mortbay/jetty/HttpFields$Field;","access$200",new String[]{ "Lorg/mortbay/jetty/HttpFields$Field;"},"Lorg/mortbay/io/Buffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1},new Method("Lorg/mortbay/io/BufferUtil;","to8859_1_String",new String[]{ "Lorg/mortbay/io/Buffer;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L2);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_OBJECT,1,2,new Field("Lorg/mortbay/jetty/HttpFields$1;","field","Lorg/mortbay/jetty/HttpFields$Field;"));
                code.visitLabel(L3);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L4);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/util/NoSuchElementException;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljava/util/NoSuchElementException;","<init>",new String[]{ },"V"));
                code.visitStmt1R(THROW,1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
