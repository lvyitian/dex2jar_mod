package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0168_org_mortbay_jetty_HttpMethods {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/jetty/HttpMethods;","Ljava/lang/Object;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("HttpMethods.java");
        f000_CACHE(cv);
        f001_CONNECT(cv);
        f002_CONNECT_BUFFER(cv);
        f003_CONNECT_ORDINAL(cv);
        f004_DELETE(cv);
        f005_DELETE_BUFFER(cv);
        f006_DELETE_ORDINAL(cv);
        f007_GET(cv);
        f008_GET_BUFFER(cv);
        f009_GET_ORDINAL(cv);
        f010_HEAD(cv);
        f011_HEAD_BUFFER(cv);
        f012_HEAD_ORDINAL(cv);
        f013_MOVE(cv);
        f014_MOVE_BUFFER(cv);
        f015_MOVE_ORDINAL(cv);
        f016_OPTIONS(cv);
        f017_OPTIONS_BUFFER(cv);
        f018_OPTIONS_ORDINAL(cv);
        f019_POST(cv);
        f020_POST_BUFFER(cv);
        f021_POST_ORDINAL(cv);
        f022_PUT(cv);
        f023_PUT_BUFFER(cv);
        f024_PUT_ORDINAL(cv);
        f025_TRACE(cv);
        f026_TRACE_BUFFER(cv);
        f027_TRACE_ORDINAL(cv);
        m000__clinit_(cv);
        m001__init_(cv);
    }
    public static void f000_CACHE(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpMethods;","CACHE","Lorg/mortbay/io/BufferCache;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001_CONNECT(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpMethods;","CONNECT","Ljava/lang/String;"), "CONNECT");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002_CONNECT_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpMethods;","CONNECT_BUFFER","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003_CONNECT_ORDINAL(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpMethods;","CONNECT_ORDINAL","I"),  Integer.valueOf(8));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f004_DELETE(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpMethods;","DELETE","Ljava/lang/String;"), "DELETE");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f005_DELETE_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpMethods;","DELETE_BUFFER","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f006_DELETE_ORDINAL(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpMethods;","DELETE_ORDINAL","I"),  Integer.valueOf(6));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f007_GET(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpMethods;","GET","Ljava/lang/String;"), "GET");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f008_GET_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpMethods;","GET_BUFFER","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f009_GET_ORDINAL(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpMethods;","GET_ORDINAL","I"),  Integer.valueOf(1));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f010_HEAD(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpMethods;","HEAD","Ljava/lang/String;"), "HEAD");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f011_HEAD_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpMethods;","HEAD_BUFFER","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f012_HEAD_ORDINAL(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpMethods;","HEAD_ORDINAL","I"),  Integer.valueOf(3));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f013_MOVE(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpMethods;","MOVE","Ljava/lang/String;"), "MOVE");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f014_MOVE_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpMethods;","MOVE_BUFFER","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f015_MOVE_ORDINAL(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpMethods;","MOVE_ORDINAL","I"),  Integer.valueOf(9));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f016_OPTIONS(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpMethods;","OPTIONS","Ljava/lang/String;"), "OPTIONS");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f017_OPTIONS_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpMethods;","OPTIONS_BUFFER","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f018_OPTIONS_ORDINAL(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpMethods;","OPTIONS_ORDINAL","I"),  Integer.valueOf(5));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f019_POST(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpMethods;","POST","Ljava/lang/String;"), "POST");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f020_POST_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpMethods;","POST_BUFFER","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f021_POST_ORDINAL(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpMethods;","POST_ORDINAL","I"),  Integer.valueOf(2));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f022_PUT(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpMethods;","PUT","Ljava/lang/String;"), "PUT");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f023_PUT_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpMethods;","PUT_BUFFER","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f024_PUT_ORDINAL(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpMethods;","PUT_ORDINAL","I"),  Integer.valueOf(4));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f025_TRACE(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpMethods;","TRACE","Ljava/lang/String;"), "TRACE");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f026_TRACE_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpMethods;","TRACE_BUFFER","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f027_TRACE_ORDINAL(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpMethods;","TRACE_ORDINAL","I"),  Integer.valueOf(7));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__clinit_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/HttpMethods;","<clinit>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(47,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(50,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(51,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(52,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(53,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(54,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(55,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(56,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(57,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(58,L9);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/io/BufferCache;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Lorg/mortbay/io/BufferCache;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpMethods;","CACHE","Lorg/mortbay/io/BufferCache;"));
                code.visitLabel(L1);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpMethods;","CACHE","Lorg/mortbay/io/BufferCache;"));
                code.visitConstStmt(CONST_STRING,1,"GET");
                code.visitConstStmt(CONST_4,2, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Lorg/mortbay/io/BufferCache;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpMethods;","GET_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L2);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpMethods;","CACHE","Lorg/mortbay/io/BufferCache;"));
                code.visitConstStmt(CONST_STRING,1,"POST");
                code.visitConstStmt(CONST_4,2, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Lorg/mortbay/io/BufferCache;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpMethods;","POST_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L3);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpMethods;","CACHE","Lorg/mortbay/io/BufferCache;"));
                code.visitConstStmt(CONST_STRING,1,"HEAD");
                code.visitConstStmt(CONST_4,2, Integer.valueOf(3)); // int: 0x00000003  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Lorg/mortbay/io/BufferCache;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpMethods;","HEAD_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L4);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpMethods;","CACHE","Lorg/mortbay/io/BufferCache;"));
                code.visitConstStmt(CONST_STRING,1,"PUT");
                code.visitConstStmt(CONST_4,2, Integer.valueOf(4)); // int: 0x00000004  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Lorg/mortbay/io/BufferCache;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpMethods;","PUT_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L5);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpMethods;","CACHE","Lorg/mortbay/io/BufferCache;"));
                code.visitConstStmt(CONST_STRING,1,"OPTIONS");
                code.visitConstStmt(CONST_4,2, Integer.valueOf(5)); // int: 0x00000005  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Lorg/mortbay/io/BufferCache;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpMethods;","OPTIONS_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L6);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpMethods;","CACHE","Lorg/mortbay/io/BufferCache;"));
                code.visitConstStmt(CONST_STRING,1,"DELETE");
                code.visitConstStmt(CONST_4,2, Integer.valueOf(6)); // int: 0x00000006  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Lorg/mortbay/io/BufferCache;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpMethods;","DELETE_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L7);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpMethods;","CACHE","Lorg/mortbay/io/BufferCache;"));
                code.visitConstStmt(CONST_STRING,1,"TRACE");
                code.visitConstStmt(CONST_4,2, Integer.valueOf(7)); // int: 0x00000007  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Lorg/mortbay/io/BufferCache;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpMethods;","TRACE_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L8);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpMethods;","CACHE","Lorg/mortbay/io/BufferCache;"));
                code.visitConstStmt(CONST_STRING,1,"CONNECT");
                code.visitConstStmt(CONST_16,2, Integer.valueOf(8)); // int: 0x00000008  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Lorg/mortbay/io/BufferCache;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpMethods;","CONNECT_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L9);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpMethods;","CACHE","Lorg/mortbay/io/BufferCache;"));
                code.visitConstStmt(CONST_STRING,1,"MOVE");
                code.visitConstStmt(CONST_16,2, Integer.valueOf(9)); // int: 0x00000009  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Lorg/mortbay/io/BufferCache;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpMethods;","MOVE_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/HttpMethods;","<init>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(25,L0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/Object;","<init>",new String[]{ },"V"));
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
