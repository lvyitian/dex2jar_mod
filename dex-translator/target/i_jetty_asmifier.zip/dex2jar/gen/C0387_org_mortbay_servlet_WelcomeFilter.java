package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0387_org_mortbay_servlet_WelcomeFilter {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/servlet/WelcomeFilter;","Ljava/lang/Object;",new String[]{ "Ljavax/servlet/Filter;"});
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("WelcomeFilter.java");
        f000_welcome(cv);
        m000__init_(cv);
        m001_destroy(cv);
        m002_doFilter(cv);
        m003_init(cv);
    }
    public static void f000_welcome(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/servlet/WelcomeFilter;","welcome","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/servlet/WelcomeFilter;","<init>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(40,L0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/Object;","<init>",new String[]{ },"V"));
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001_destroy(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/servlet/WelcomeFilter;","destroy",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(64,L0);
                code.visitLabel(L0);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_doFilter(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/servlet/WelcomeFilter;","doFilter",new String[]{ "Ljavax/servlet/ServletRequest;","Ljavax/servlet/ServletResponse;","Ljavax/servlet/FilterChain;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visit(null, new DexType("Ljavax/servlet/ServletException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(8);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"request");
                ddv.visitParameterName(1,"response");
                ddv.visitParameterName(2,"chain");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(57,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(58,L1);
                ddv.visitStartLocal(1,L1,"path","Ljava/lang/String;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(59,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(62,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(61,L4);
                code.visitLabel(L0);
                code.visitStmt2R(MOVE_OBJECT,0,5);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Ljavax/servlet/http/HttpServletRequest;");
                code.visitStmt2R(MOVE_OBJECT,2,0);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2},new Method("Ljavax/servlet/http/HttpServletRequest;","getServletPath",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,2,4,new Field("Lorg/mortbay/servlet/WelcomeFilter;","welcome","Ljava/lang/String;"));
                code.visitJumpStmt(IF_EQZ,2,-1,L4);
                code.visitConstStmt(CONST_STRING,2,"/");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/lang/String;","endsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_EQZ,2,-1,L4);
                code.visitLabel(L2);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitFieldStmt(IGET_OBJECT,3,4,new Field("Lorg/mortbay/servlet/WelcomeFilter;","welcome","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 5,2},new Method("Ljavax/servlet/ServletRequest;","getRequestDispatcher",new String[]{ "Ljava/lang/String;"},"Ljavax/servlet/RequestDispatcher;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2,5,6},new Method("Ljavax/servlet/RequestDispatcher;","forward",new String[]{ "Ljavax/servlet/ServletRequest;","Ljavax/servlet/ServletResponse;"},"V"));
                code.visitLabel(L3);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 7,5,6},new Method("Ljavax/servlet/FilterChain;","doFilter",new String[]{ "Ljavax/servlet/ServletRequest;","Ljavax/servlet/ServletResponse;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_init(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/servlet/WelcomeFilter;","init",new String[]{ "Ljavax/servlet/FilterConfig;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"filterConfig");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(46,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(47,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(48,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(49,L3);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_STRING,0,"welcome");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2,0},new Method("Ljavax/servlet/FilterConfig;","getInitParameter",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/servlet/WelcomeFilter;","welcome","Ljava/lang/String;"));
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/servlet/WelcomeFilter;","welcome","Ljava/lang/String;"));
                code.visitJumpStmt(IF_NEZ,0,-1,L3);
                code.visitLabel(L2);
                code.visitConstStmt(CONST_STRING,0,"index.html");
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/servlet/WelcomeFilter;","welcome","Ljava/lang/String;"));
                code.visitLabel(L3);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
