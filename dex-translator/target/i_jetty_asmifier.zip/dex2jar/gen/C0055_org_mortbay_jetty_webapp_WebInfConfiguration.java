package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0055_org_mortbay_jetty_webapp_WebInfConfiguration {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/jetty/webapp/WebInfConfiguration;","Ljava/lang/Object;",new String[]{ "Lorg/mortbay/jetty/webapp/Configuration;"});
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("WebInfConfiguration.java");
        f000__context(cv);
        m000__init_(cv);
        m001_configureClassLoader(cv);
        m002_configureDefaults(cv);
        m003_configureWebApp(cv);
        m004_deconfigureWebApp(cv);
        m005_getWebAppContext(cv);
        m006_setWebAppContext(cv);
    }
    public static void f000__context(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/jetty/webapp/WebInfConfiguration;","_context","Lorg/mortbay/jetty/webapp/WebAppContext;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/webapp/WebInfConfiguration;","<init>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(29,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(30,L1);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/Object;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001_configureClassLoader(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/webapp/WebInfConfiguration;","configureClassLoader",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/Exception;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(56,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(58,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(78,L2);
                ddv.visitEndLocal(5,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(62,L3);
                ddv.visitRestartLocal(5,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(65,L4);
                ddv.visitStartLocal(2,L4,"web_inf","Lorg/mortbay/resource/Resource;",null);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(68,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(69,L6);
                ddv.visitStartLocal(0,L6,"classes","Lorg/mortbay/resource/Resource;",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(70,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(73,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(74,L9);
                ddv.visitStartLocal(1,L9,"lib","Lorg/mortbay/resource/Resource;",null);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(75,L10);
                DexLabel L11=new DexLabel();
                ddv.visitEndLocal(5,L11);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,3,5,new Field("Lorg/mortbay/jetty/webapp/WebInfConfiguration;","_context","Lorg/mortbay/jetty/webapp/WebAppContext;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","isStarted",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_EQZ,3,-1,L3);
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/log/Log;","isDebugEnabled",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_EQZ,3,-1,L2);
                code.visitConstStmt(CONST_STRING,3,"Cannot configure webapp after it is started");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,3,5,new Field("Lorg/mortbay/jetty/webapp/WebInfConfiguration;","_context","Lorg/mortbay/jetty/webapp/WebAppContext;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","getWebInf",new String[]{ },"Lorg/mortbay/resource/Resource;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L4);
                code.visitJumpStmt(IF_EQZ,2,-1,L2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/resource/Resource;","isDirectory",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_EQZ,3,-1,L2);
                code.visitFieldStmt(IGET_OBJECT,3,5,new Field("Lorg/mortbay/jetty/webapp/WebInfConfiguration;","_context","Lorg/mortbay/jetty/webapp/WebAppContext;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","getClassLoader",new String[]{ },"Ljava/lang/ClassLoader;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitTypeStmt(INSTANCE_OF,3,3,"Lorg/mortbay/jetty/webapp/WebAppClassLoader;");
                code.visitJumpStmt(IF_EQZ,3,-1,L2);
                code.visitLabel(L5);
                code.visitConstStmt(CONST_STRING,3,"classes/");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Lorg/mortbay/resource/Resource;","addPath",new String[]{ "Ljava/lang/String;"},"Lorg/mortbay/resource/Resource;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/resource/Resource;","exists",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_EQZ,3,-1,L8);
                code.visitLabel(L7);
                code.visitFieldStmt(IGET_OBJECT,3,5,new Field("Lorg/mortbay/jetty/webapp/WebInfConfiguration;","_context","Lorg/mortbay/jetty/webapp/WebAppContext;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","getClassLoader",new String[]{ },"Ljava/lang/ClassLoader;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitTypeStmt(CHECK_CAST,3,-1,"Lorg/mortbay/jetty/webapp/WebAppClassLoader;");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/Object;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Lorg/mortbay/jetty/webapp/WebAppClassLoader;","addClassPath",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L8);
                code.visitConstStmt(CONST_STRING,3,"lib/");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Lorg/mortbay/resource/Resource;","addPath",new String[]{ "Ljava/lang/String;"},"Lorg/mortbay/resource/Resource;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/resource/Resource;","exists",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_NEZ,3,-1,L10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/resource/Resource;","isDirectory",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_EQZ,3,-1,L2);
                code.visitLabel(L10);
                code.visitFieldStmt(IGET_OBJECT,3,5,new Field("Lorg/mortbay/jetty/webapp/WebInfConfiguration;","_context","Lorg/mortbay/jetty/webapp/WebAppContext;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","getClassLoader",new String[]{ },"Ljava/lang/ClassLoader;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitLabel(L11);
                code.visitTypeStmt(CHECK_CAST,5,-1,"Lorg/mortbay/jetty/webapp/WebAppClassLoader;");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,1},new Method("Lorg/mortbay/jetty/webapp/WebAppClassLoader;","addJars",new String[]{ "Lorg/mortbay/resource/Resource;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_configureDefaults(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/webapp/WebInfConfiguration;","configureDefaults",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/Exception;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(83,L0);
                code.visitLabel(L0);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_configureWebApp(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/webapp/WebInfConfiguration;","configureWebApp",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/Exception;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(88,L0);
                code.visitLabel(L0);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_deconfigureWebApp(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/webapp/WebInfConfiguration;","deconfigureWebApp",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/Exception;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(93,L0);
                code.visitLabel(L0);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_getWebAppContext(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/webapp/WebInfConfiguration;","getWebAppContext",new String[]{ },"Lorg/mortbay/jetty/webapp/WebAppContext;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(41,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/webapp/WebInfConfiguration;","_context","Lorg/mortbay/jetty/webapp/WebAppContext;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_setWebAppContext(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/webapp/WebInfConfiguration;","setWebAppContext",new String[]{ "Lorg/mortbay/jetty/webapp/WebAppContext;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"context");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(35,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(36,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/webapp/WebInfConfiguration;","_context","Lorg/mortbay/jetty/webapp/WebAppContext;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
