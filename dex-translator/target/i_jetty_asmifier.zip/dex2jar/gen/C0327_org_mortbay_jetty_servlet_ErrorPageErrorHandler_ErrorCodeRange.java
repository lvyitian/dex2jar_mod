package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0327_org_mortbay_jetty_servlet_ErrorPageErrorHandler_ErrorCodeRange {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(0,"Lorg/mortbay/jetty/servlet/ErrorPageErrorHandler$ErrorCodeRange;","Ljava/lang/Object;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("ErrorPageErrorHandler.java");
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/EnclosingClass;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("value", new DexType("Lorg/mortbay/jetty/servlet/ErrorPageErrorHandler;"));
                av00.visitEnd();
            }
        }
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/InnerClass;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("accessFlags",  Integer.valueOf(2));
                av00.visit("name", "ErrorCodeRange");
                av00.visitEnd();
            }
        }
        f000__from(cv);
        f001__to(cv);
        f002__uri(cv);
        f003_this$0(cv);
        m000__init_(cv);
        m001_getUri(cv);
        m002_isInRange(cv);
        m003_toString(cv);
    }
    public static void f000__from(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/servlet/ErrorPageErrorHandler$ErrorCodeRange;","_from","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001__to(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/servlet/ErrorPageErrorHandler$ErrorCodeRange;","_to","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002__uri(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/servlet/ErrorPageErrorHandler$ErrorCodeRange;","_uri","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003_this$0(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_FINAL|ACC_SYNTHETIC, new Field("Lorg/mortbay/jetty/servlet/ErrorPageErrorHandler$ErrorCodeRange;","this$0","Lorg/mortbay/jetty/servlet/ErrorPageErrorHandler;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/servlet/ErrorPageErrorHandler$ErrorCodeRange;","<init>",new String[]{ "Lorg/mortbay/jetty/servlet/ErrorPageErrorHandler;","I","I","Ljava/lang/String;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/IllegalArgumentException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(1,"from");
                ddv.visitParameterName(2,"to");
                ddv.visitParameterName(3,"uri");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(236,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(237,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(238,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(240,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(241,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(242,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(243,L6);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,3,2,new Field("Lorg/mortbay/jetty/servlet/ErrorPageErrorHandler$ErrorCodeRange;","this$0","Lorg/mortbay/jetty/servlet/ErrorPageErrorHandler;"));
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2},new Method("Ljava/lang/Object;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitJumpStmt(IF_LE,4,5,L3);
                code.visitLabel(L2);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/IllegalArgumentException;");
                code.visitConstStmt(CONST_STRING,1,"from>to");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Ljava/lang/IllegalArgumentException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,0);
                code.visitLabel(L3);
                code.visitFieldStmt(IPUT,4,2,new Field("Lorg/mortbay/jetty/servlet/ErrorPageErrorHandler$ErrorCodeRange;","_from","I"));
                code.visitLabel(L4);
                code.visitFieldStmt(IPUT,5,2,new Field("Lorg/mortbay/jetty/servlet/ErrorPageErrorHandler$ErrorCodeRange;","_to","I"));
                code.visitLabel(L5);
                code.visitFieldStmt(IPUT_OBJECT,6,2,new Field("Lorg/mortbay/jetty/servlet/ErrorPageErrorHandler$ErrorCodeRange;","_uri","Ljava/lang/String;"));
                code.visitLabel(L6);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001_getUri(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(0, new Method("Lorg/mortbay/jetty/servlet/ErrorPageErrorHandler$ErrorCodeRange;","getUri",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(257,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/servlet/ErrorPageErrorHandler$ErrorCodeRange;","_uri","Ljava/lang/String;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_isInRange(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(0, new Method("Lorg/mortbay/jetty/servlet/ErrorPageErrorHandler$ErrorCodeRange;","isInRange",new String[]{ "I"},"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"value");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(247,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(249,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(252,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,1,new Field("Lorg/mortbay/jetty/servlet/ErrorPageErrorHandler$ErrorCodeRange;","_from","I"));
                DexLabel L3=new DexLabel();
                code.visitJumpStmt(IF_LT,2,0,L3);
                code.visitFieldStmt(IGET,0,1,new Field("Lorg/mortbay/jetty/servlet/ErrorPageErrorHandler$ErrorCodeRange;","_to","I"));
                code.visitJumpStmt(IF_GT,2,0,L3);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L2);
                code.visitStmt1R(RETURN,0);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_toString(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/ErrorPageErrorHandler$ErrorCodeRange;","toString",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(262,L0);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,1,"from: ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IGET,1,2,new Field("Lorg/mortbay/jetty/servlet/ErrorPageErrorHandler$ErrorCodeRange;","_from","I"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "I"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitConstStmt(CONST_STRING,1,",to: ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IGET,1,2,new Field("Lorg/mortbay/jetty/servlet/ErrorPageErrorHandler$ErrorCodeRange;","_to","I"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "I"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitConstStmt(CONST_STRING,1,",uri: ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/servlet/ErrorPageErrorHandler$ErrorCodeRange;","_uri","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
