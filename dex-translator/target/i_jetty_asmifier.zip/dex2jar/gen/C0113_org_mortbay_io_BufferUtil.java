package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0113_org_mortbay_io_BufferUtil {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/io/BufferUtil;","Ljava/lang/Object;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("BufferUtil.java");
        f000_DIGIT(cv);
        f001_MINUS(cv);
        f002_SPACE(cv);
        f003_decDivisors(cv);
        f004_hexDivisors(cv);
        m000__clinit_(cv);
        m001__init_(cv);
        m002_isPrefix(cv);
        m003_prependHexInt(cv);
        m004_putCRLF(cv);
        m005_putDecInt(cv);
        m006_putDecLong(cv);
        m007_putHexInt(cv);
        m008_to8859_1_String(cv);
        m009_toBuffer(cv);
        m010_toInt(cv);
        m011_toLong(cv);
    }
    public static void f000_DIGIT(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/io/BufferUtil;","DIGIT","[B"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001_MINUS(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/io/BufferUtil;","MINUS","B"), Byte.valueOf((byte)45));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002_SPACE(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/io/BufferUtil;","SPACE","B"), Byte.valueOf((byte)32));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003_decDivisors(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC, new Field("Lorg/mortbay/io/BufferUtil;","decDivisors","[I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f004_hexDivisors(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC, new Field("Lorg/mortbay/io/BufferUtil;","hexDivisors","[I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__clinit_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/io/BufferUtil;","<clinit>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(30,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(283,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(286,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(30,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(283,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(286,L5);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_16,0, Integer.valueOf(16)); // int: 0x00000010  float:0.000000
                code.visitTypeStmt(NEW_ARRAY,0,0,"[B");
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/io/BufferUtil;","DIGIT","[B"));
                code.visitLabel(L1);
                code.visitConstStmt(CONST_16,0, Integer.valueOf(10)); // int: 0x0000000a  float:0.000000
                code.visitTypeStmt(NEW_ARRAY,0,0,"[I");
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/io/BufferUtil;","decDivisors","[I"));
                code.visitLabel(L2);
                code.visitConstStmt(CONST_16,0, Integer.valueOf(8)); // int: 0x00000008  float:0.000000
                code.visitTypeStmt(NEW_ARRAY,0,0,"[I");
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/io/BufferUtil;","hexDivisors","[I"));
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L3);
                code.visitLabel(L4);
                code.visitLabel(L5);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/io/BufferUtil;","<init>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(26,L0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/Object;","<init>",new String[]{ },"V"));
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_isPrefix(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/io/BufferUtil;","isPrefix",new String[]{ "Lorg/mortbay/io/Buffer;","Lorg/mortbay/io/Buffer;"},"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(8);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"prefix");
                ddv.visitParameterName(1,"buffer");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(298,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(304,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(300,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(301,L4);
                ddv.visitStartLocal(0,L4,"bi","I",null);
                DexLabel L5=new DexLabel();
                ddv.visitStartLocal(2,L5,"i","I",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(302,L6);
                DexLabel L7=new DexLabel();
                ddv.visitStartLocal(1,L7,"bi","I",null);
                DexLabel L8=new DexLabel();
                ddv.visitEndLocal(0,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(303,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(301,L10);
                DexLabel L11=new DexLabel();
                ddv.visitRestartLocal(0,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(304,L12);
                ddv.visitEndLocal(1,L12);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,5, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 6},new Method("Lorg/mortbay/io/Buffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 7},new Method("Lorg/mortbay/io/Buffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitJumpStmt(IF_LE,3,4,L3);
                code.visitStmt2R(MOVE,3,5);
                code.visitLabel(L2);
                code.visitStmt1R(RETURN,3);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 7},new Method("Lorg/mortbay/io/Buffer;","getIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 6},new Method("Lorg/mortbay/io/Buffer;","getIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 6},new Method("Lorg/mortbay/io/Buffer;","putIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_GE,2,3,L12);
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 6,2},new Method("Lorg/mortbay/io/Buffer;","peek",new String[]{ "I"},"B"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitStmt2R1N(ADD_INT_LIT8,1,0,1);
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 7,0},new Method("Lorg/mortbay/io/Buffer;","peek",new String[]{ "I"},"B"));
                code.visitLabel(L8);
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitJumpStmt(IF_EQ,3,4,L10);
                code.visitStmt2R(MOVE,3,5);
                code.visitLabel(L9);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L10);
                code.visitStmt2R1N(ADD_INT_LIT8,2,2,1);
                code.visitStmt2R(MOVE,0,1);
                code.visitLabel(L11);
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitLabel(L12);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_prependHexInt(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/io/BufferUtil;","prependHexInt",new String[]{ "Lorg/mortbay/io/Buffer;","I"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"buffer");
                ddv.visitParameterName(1,"n");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(165,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(167,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(168,L2);
                ddv.visitStartLocal(1,L2,"gi","I",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(169,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(192,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(173,L5);
                ddv.visitEndLocal(1,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(174,L6);
                ddv.visitStartLocal(2,L6,"minus","Z",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(176,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(177,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(180,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(181,L10);
                ddv.visitRestartLocal(1,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(183,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(184,L12);
                ddv.visitStartLocal(0,L12,"d","I",null);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(185,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(188,L14);
                ddv.visitEndLocal(0,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(189,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(190,L16);
                code.visitLabel(L0);
                code.visitJumpStmt(IF_NEZ,5,-1,L5);
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 4},new Method("Lorg/mortbay/io/Buffer;","getIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitLabel(L2);
                code.visitStmt2R1N(ADD_INT_LIT8,1,1,-1);
                code.visitConstStmt(CONST_16,3, Integer.valueOf(48)); // int: 0x00000030  float:0.000000
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 4,1,3},new Method("Lorg/mortbay/io/Buffer;","poke",new String[]{ "I","B"},"V"));
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 4,1},new Method("Lorg/mortbay/io/Buffer;","setGetIndex",new String[]{ "I"},"V"));
                code.visitLabel(L4);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L5);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L6);
                code.visitJumpStmt(IF_GEZ,5,-1,L9);
                code.visitLabel(L7);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L8);
                code.visitStmt2R(NEG_INT,5,5);
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 4},new Method("Lorg/mortbay/io/Buffer;","getIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitLabel(L10);
                code.visitJumpStmt(IF_LEZ,5,-1,L14);
                code.visitLabel(L11);
                code.visitStmt2R1N(AND_INT_LIT8,0,5,15);
                code.visitLabel(L12);
                code.visitStmt2R1N(SHR_INT_LIT8,5,5,4);
                code.visitLabel(L13);
                code.visitStmt2R1N(ADD_INT_LIT8,1,1,-1);
                code.visitFieldStmt(SGET_OBJECT,3,-1,new Field("Lorg/mortbay/io/BufferUtil;","DIGIT","[B"));
                code.visitStmt3R(AGET_BYTE,3,3,0);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 4,1,3},new Method("Lorg/mortbay/io/Buffer;","poke",new String[]{ "I","B"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L10);
                code.visitLabel(L14);
                code.visitJumpStmt(IF_EQZ,2,-1,L16);
                code.visitLabel(L15);
                code.visitStmt2R1N(ADD_INT_LIT8,1,1,-1);
                code.visitConstStmt(CONST_16,3, Integer.valueOf(45)); // int: 0x0000002d  float:0.000000
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 4,1,3},new Method("Lorg/mortbay/io/Buffer;","poke",new String[]{ "I","B"},"V"));
                code.visitLabel(L16);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 4,1},new Method("Lorg/mortbay/io/Buffer;","setGetIndex",new String[]{ "I"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_putCRLF(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/io/BufferUtil;","putCRLF",new String[]{ "Lorg/mortbay/io/Buffer;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"buffer");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(292,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(293,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(294,L2);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_16,0, Integer.valueOf(13)); // int: 0x0000000d  float:0.000000
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1,0},new Method("Lorg/mortbay/io/Buffer;","put",new String[]{ "B"},"V"));
                code.visitLabel(L1);
                code.visitConstStmt(CONST_16,0, Integer.valueOf(10)); // int: 0x0000000a  float:0.000000
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1,0},new Method("Lorg/mortbay/io/Buffer;","put",new String[]{ "B"},"V"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_putDecInt(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/io/BufferUtil;","putDecInt",new String[]{ "Lorg/mortbay/io/Buffer;","I"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"buffer");
                ddv.visitParameterName(1,"n");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(198,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(200,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(202,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(204,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(205,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(211,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(213,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(234,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(208,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(217,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(219,L10);
                ddv.visitStartLocal(2,L10,"started","Z",null);
                DexLabel L11=new DexLabel();
                ddv.visitStartLocal(1,L11,"i","I",null);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(221,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(223,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(224,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(219,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(228,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(229,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(230,L18);
                ddv.visitStartLocal(0,L18,"d","I",null);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(231,L19);
                code.visitLabel(L0);
                code.visitJumpStmt(IF_GEZ,5,-1,L5);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_16,3, Integer.valueOf(45)); // int: 0x0000002d  float:0.000000
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 4,3},new Method("Lorg/mortbay/io/Buffer;","put",new String[]{ "B"},"V"));
                code.visitLabel(L2);
                code.visitConstStmt(CONST_HIGH16,3, Integer.valueOf(-2147483648)); // int: 0x80000000  float:-0.000000
                code.visitJumpStmt(IF_NE,5,3,L8);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_16,3, Integer.valueOf(50)); // int: 0x00000032  float:0.000000
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 4,3},new Method("Lorg/mortbay/io/Buffer;","put",new String[]{ "B"},"V"));
                code.visitLabel(L4);
                code.visitConstStmt(CONST,5, Integer.valueOf(147483648)); // int: 0x08ca6c00  float:0.000000
                code.visitLabel(L5);
                code.visitConstStmt(CONST_16,3, Integer.valueOf(10)); // int: 0x0000000a  float:0.000000
                code.visitJumpStmt(IF_GE,5,3,L9);
                code.visitLabel(L6);
                code.visitFieldStmt(SGET_OBJECT,3,-1,new Field("Lorg/mortbay/io/BufferUtil;","DIGIT","[B"));
                code.visitStmt3R(AGET_BYTE,3,3,5);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 4,3},new Method("Lorg/mortbay/io/Buffer;","put",new String[]{ "B"},"V"));
                code.visitLabel(L7);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L8);
                code.visitStmt2R(NEG_INT,5,5);
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitLabel(L9);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L10);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L11);
                code.visitFieldStmt(SGET_OBJECT,3,-1,new Field("Lorg/mortbay/io/BufferUtil;","decDivisors","[I"));
                code.visitStmt2R(ARRAY_LENGTH,3,3);
                code.visitJumpStmt(IF_GE,1,3,L7);
                code.visitLabel(L12);
                code.visitFieldStmt(SGET_OBJECT,3,-1,new Field("Lorg/mortbay/io/BufferUtil;","decDivisors","[I"));
                code.visitStmt3R(AGET,3,3,1);
                code.visitJumpStmt(IF_GE,5,3,L16);
                code.visitLabel(L13);
                code.visitJumpStmt(IF_EQZ,2,-1,L15);
                code.visitLabel(L14);
                code.visitConstStmt(CONST_16,3, Integer.valueOf(48)); // int: 0x00000030  float:0.000000
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 4,3},new Method("Lorg/mortbay/io/Buffer;","put",new String[]{ "B"},"V"));
                code.visitLabel(L15);
                code.visitStmt2R1N(ADD_INT_LIT8,1,1,1);
                code.visitJumpStmt(GOTO,-1,-1,L11);
                code.visitLabel(L16);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L17);
                code.visitFieldStmt(SGET_OBJECT,3,-1,new Field("Lorg/mortbay/io/BufferUtil;","decDivisors","[I"));
                code.visitStmt3R(AGET,3,3,1);
                code.visitStmt3R(DIV_INT,0,5,3);
                code.visitLabel(L18);
                code.visitFieldStmt(SGET_OBJECT,3,-1,new Field("Lorg/mortbay/io/BufferUtil;","DIGIT","[B"));
                code.visitStmt3R(AGET_BYTE,3,3,0);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 4,3},new Method("Lorg/mortbay/io/Buffer;","put",new String[]{ "B"},"V"));
                code.visitLabel(L19);
                code.visitFieldStmt(SGET_OBJECT,3,-1,new Field("Lorg/mortbay/io/BufferUtil;","decDivisors","[I"));
                code.visitStmt3R(AGET,3,3,1);
                code.visitStmt2R(MUL_INT_2ADDR,3,0);
                code.visitStmt2R(SUB_INT_2ADDR,5,3);
                code.visitJumpStmt(GOTO,-1,-1,L15);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_putDecLong(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/io/BufferUtil;","putDecLong",new String[]{ "Lorg/mortbay/io/Buffer;","J"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(9);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"buffer");
                ddv.visitParameterName(1,"n");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(238,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(240,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(242,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(244,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(245,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(251,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(253,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(274,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(248,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(257,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(259,L10);
                ddv.visitStartLocal(3,L10,"started","Z",null);
                DexLabel L11=new DexLabel();
                ddv.visitStartLocal(2,L11,"i","I",null);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(261,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(263,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(264,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(259,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(268,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(269,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(270,L18);
                ddv.visitStartLocal(0,L18,"d","J",null);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(271,L19);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_WIDE_16,4,Long.valueOf(0L)); // long: 0x0000000000000000  double:0.000000
                code.visitStmt3R(CMP_LONG,4,7,4);
                code.visitJumpStmt(IF_GEZ,4,-1,L5);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_16,4, Integer.valueOf(45)); // int: 0x0000002d  float:0.000000
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 6,4},new Method("Lorg/mortbay/io/Buffer;","put",new String[]{ "B"},"V"));
                code.visitLabel(L2);
                code.visitConstStmt(CONST_WIDE_HIGH16,4,Long.valueOf(-9223372036854775808L)); // long: 0x8000000000000000  double:-0.000000
                code.visitStmt3R(CMP_LONG,4,7,4);
                code.visitJumpStmt(IF_NEZ,4,-1,L8);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_16,4, Integer.valueOf(57)); // int: 0x00000039  float:0.000000
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 6,4},new Method("Lorg/mortbay/io/Buffer;","put",new String[]{ "B"},"V"));
                code.visitLabel(L4);
                code.visitConstStmt(CONST_WIDE,7,Long.valueOf(223372036854775808L)); // long: 0x031993af1d7c0000  double:0.000000
                code.visitLabel(L5);
                code.visitConstStmt(CONST_WIDE_16,4,Long.valueOf(10L)); // long: 0x000000000000000a  double:0.000000
                code.visitStmt3R(CMP_LONG,4,7,4);
                code.visitJumpStmt(IF_GEZ,4,-1,L9);
                code.visitLabel(L6);
                code.visitFieldStmt(SGET_OBJECT,4,-1,new Field("Lorg/mortbay/io/BufferUtil;","DIGIT","[B"));
                code.visitStmt2R(LONG_TO_INT,5,7);
                code.visitStmt3R(AGET_BYTE,4,4,5);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 6,4},new Method("Lorg/mortbay/io/Buffer;","put",new String[]{ "B"},"V"));
                code.visitLabel(L7);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L8);
                code.visitStmt2R(NEG_LONG,7,7);
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitLabel(L9);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L10);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L11);
                code.visitFieldStmt(SGET_OBJECT,4,-1,new Field("Lorg/mortbay/io/BufferUtil;","decDivisors","[I"));
                code.visitStmt2R(ARRAY_LENGTH,4,4);
                code.visitJumpStmt(IF_GE,2,4,L7);
                code.visitLabel(L12);
                code.visitFieldStmt(SGET_OBJECT,4,-1,new Field("Lorg/mortbay/io/BufferUtil;","decDivisors","[I"));
                code.visitStmt3R(AGET,4,4,2);
                code.visitStmt2R(INT_TO_LONG,4,4);
                code.visitStmt3R(CMP_LONG,4,7,4);
                code.visitJumpStmt(IF_GEZ,4,-1,L16);
                code.visitLabel(L13);
                code.visitJumpStmt(IF_EQZ,3,-1,L15);
                code.visitLabel(L14);
                code.visitConstStmt(CONST_16,4, Integer.valueOf(48)); // int: 0x00000030  float:0.000000
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 6,4},new Method("Lorg/mortbay/io/Buffer;","put",new String[]{ "B"},"V"));
                code.visitLabel(L15);
                code.visitStmt2R1N(ADD_INT_LIT8,2,2,1);
                code.visitJumpStmt(GOTO,-1,-1,L11);
                code.visitLabel(L16);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L17);
                code.visitFieldStmt(SGET_OBJECT,4,-1,new Field("Lorg/mortbay/io/BufferUtil;","decDivisors","[I"));
                code.visitStmt3R(AGET,4,4,2);
                code.visitStmt2R(INT_TO_LONG,4,4);
                code.visitStmt3R(DIV_LONG,0,7,4);
                code.visitLabel(L18);
                code.visitFieldStmt(SGET_OBJECT,4,-1,new Field("Lorg/mortbay/io/BufferUtil;","DIGIT","[B"));
                code.visitStmt2R(LONG_TO_INT,5,0);
                code.visitStmt3R(AGET_BYTE,4,4,5);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 6,4},new Method("Lorg/mortbay/io/Buffer;","put",new String[]{ "B"},"V"));
                code.visitLabel(L19);
                code.visitFieldStmt(SGET_OBJECT,4,-1,new Field("Lorg/mortbay/io/BufferUtil;","decDivisors","[I"));
                code.visitStmt3R(AGET,4,4,2);
                code.visitStmt2R(INT_TO_LONG,4,4);
                code.visitStmt2R(MUL_LONG_2ADDR,4,0);
                code.visitStmt2R(SUB_LONG_2ADDR,7,4);
                code.visitJumpStmt(GOTO,-1,-1,L15);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m007_putHexInt(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/io/BufferUtil;","putHexInt",new String[]{ "Lorg/mortbay/io/Buffer;","I"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"buffer");
                ddv.visitParameterName(1,"n");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(112,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(114,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(116,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(118,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(119,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(120,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(121,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(122,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(123,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(124,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(125,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(155,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(129,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(132,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(134,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(138,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(140,L17);
                ddv.visitStartLocal(2,L17,"started","Z",null);
                DexLabel L18=new DexLabel();
                ddv.visitStartLocal(1,L18,"i","I",null);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(142,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(144,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(145,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(140,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(149,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(150,L24);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(151,L25);
                ddv.visitStartLocal(0,L25,"d","I",null);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(152,L26);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_16,4, Integer.valueOf(48)); // int: 0x00000030  float:0.000000
                code.visitLabel(L1);
                code.visitJumpStmt(IF_GEZ,6,-1,L14);
                code.visitLabel(L2);
                code.visitConstStmt(CONST_16,3, Integer.valueOf(45)); // int: 0x0000002d  float:0.000000
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 5,3},new Method("Lorg/mortbay/io/Buffer;","put",new String[]{ "B"},"V"));
                code.visitLabel(L3);
                code.visitConstStmt(CONST_HIGH16,3, Integer.valueOf(-2147483648)); // int: 0x80000000  float:-0.000000
                code.visitJumpStmt(IF_NE,6,3,L13);
                code.visitLabel(L4);
                code.visitConstStmt(CONST_16,3, Integer.valueOf(56)); // int: 0x00000038  float:0.000000
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 5,3},new Method("Lorg/mortbay/io/Buffer;","put",new String[]{ "B"},"V"));
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 5,4},new Method("Lorg/mortbay/io/Buffer;","put",new String[]{ "B"},"V"));
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 5,4},new Method("Lorg/mortbay/io/Buffer;","put",new String[]{ "B"},"V"));
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 5,4},new Method("Lorg/mortbay/io/Buffer;","put",new String[]{ "B"},"V"));
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 5,4},new Method("Lorg/mortbay/io/Buffer;","put",new String[]{ "B"},"V"));
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 5,4},new Method("Lorg/mortbay/io/Buffer;","put",new String[]{ "B"},"V"));
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 5,4},new Method("Lorg/mortbay/io/Buffer;","put",new String[]{ "B"},"V"));
                code.visitLabel(L11);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 5,4},new Method("Lorg/mortbay/io/Buffer;","put",new String[]{ "B"},"V"));
                code.visitLabel(L12);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L13);
                code.visitStmt2R(NEG_INT,6,6);
                code.visitLabel(L14);
                code.visitConstStmt(CONST_16,3, Integer.valueOf(16)); // int: 0x00000010  float:0.000000
                code.visitJumpStmt(IF_GE,6,3,L16);
                code.visitLabel(L15);
                code.visitFieldStmt(SGET_OBJECT,3,-1,new Field("Lorg/mortbay/io/BufferUtil;","DIGIT","[B"));
                code.visitStmt3R(AGET_BYTE,3,3,6);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 5,3},new Method("Lorg/mortbay/io/Buffer;","put",new String[]{ "B"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L12);
                code.visitLabel(L16);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L17);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L18);
                code.visitFieldStmt(SGET_OBJECT,3,-1,new Field("Lorg/mortbay/io/BufferUtil;","hexDivisors","[I"));
                code.visitStmt2R(ARRAY_LENGTH,3,3);
                code.visitJumpStmt(IF_GE,1,3,L12);
                code.visitLabel(L19);
                code.visitFieldStmt(SGET_OBJECT,3,-1,new Field("Lorg/mortbay/io/BufferUtil;","hexDivisors","[I"));
                code.visitStmt3R(AGET,3,3,1);
                code.visitJumpStmt(IF_GE,6,3,L23);
                code.visitLabel(L20);
                code.visitJumpStmt(IF_EQZ,2,-1,L22);
                code.visitLabel(L21);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 5,4},new Method("Lorg/mortbay/io/Buffer;","put",new String[]{ "B"},"V"));
                code.visitLabel(L22);
                code.visitStmt2R1N(ADD_INT_LIT8,1,1,1);
                code.visitJumpStmt(GOTO,-1,-1,L18);
                code.visitLabel(L23);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L24);
                code.visitFieldStmt(SGET_OBJECT,3,-1,new Field("Lorg/mortbay/io/BufferUtil;","hexDivisors","[I"));
                code.visitStmt3R(AGET,3,3,1);
                code.visitStmt3R(DIV_INT,0,6,3);
                code.visitLabel(L25);
                code.visitFieldStmt(SGET_OBJECT,3,-1,new Field("Lorg/mortbay/io/BufferUtil;","DIGIT","[B"));
                code.visitStmt3R(AGET_BYTE,3,3,0);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 5,3},new Method("Lorg/mortbay/io/Buffer;","put",new String[]{ "B"},"V"));
                code.visitLabel(L26);
                code.visitFieldStmt(SGET_OBJECT,3,-1,new Field("Lorg/mortbay/io/BufferUtil;","hexDivisors","[I"));
                code.visitStmt3R(AGET,3,3,1);
                code.visitStmt2R(MUL_INT_2ADDR,3,0);
                code.visitStmt2R(SUB_INT_2ADDR,6,3);
                code.visitJumpStmt(GOTO,-1,-1,L22);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m008_to8859_1_String(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/io/BufferUtil;","to8859_1_String",new String[]{ "Lorg/mortbay/io/Buffer;"},"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(10);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/io/UnsupportedEncodingException;"});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L2},new String[]{ "Ljava/io/UnsupportedEncodingException;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"buffer");
                DexLabel L5=new DexLabel();
                ddv.visitPrologue(L5);
                ddv.visitLineNumber(309,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(310,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(326,L7);
                ddv.visitLineNumber(314,L0);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(315,L8);
                ddv.visitStartLocal(1,L8,"bytes","[B",null);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(316,L9);
                ddv.visitLineNumber(323,L2);
                ddv.visitEndLocal(1,L2);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(325,L10);
                ddv.visitStartLocal(3,L10,"e","Ljava/io/UnsupportedEncodingException;",null);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(326,L11);
                ddv.visitLineNumber(318,L3);
                ddv.visitEndLocal(3,L3);
                ddv.visitRestartLocal(1,L3);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(319,L12);
                ddv.visitStartLocal(0,L12,"b","Ljava/lang/StringBuffer;",null);
                DexLabel L13=new DexLabel();
                ddv.visitStartLocal(4,L13,"i","I",null);
                DexLabel L14=new DexLabel();
                ddv.visitStartLocal(2,L14,"c","I",null);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(320,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(319,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(321,L17);
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 9},new Method("Lorg/mortbay/io/Buffer;","isImmutable",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitJumpStmt(IF_EQZ,5,-1,L0);
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9},new Method("Ljava/lang/Object;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitLabel(L7);
                code.visitStmt1R(RETURN_OBJECT,5);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 9},new Method("Lorg/mortbay/io/Buffer;","array",new String[]{ },"[B"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L8);
                code.visitJumpStmt(IF_EQZ,1,-1,L3);
                code.visitLabel(L9);
                code.visitTypeStmt(NEW_INSTANCE,5,-1,"Ljava/lang/String;");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 9},new Method("Lorg/mortbay/io/Buffer;","getIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 9},new Method("Lorg/mortbay/io/Buffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitFieldStmt(SGET_OBJECT,8,-1,new Field("Lorg/mortbay/util/StringUtil;","__ISO_8859_1","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 5,1,6,7,8},new Method("Ljava/lang/String;","<init>",new String[]{ "[B","I","I","Ljava/lang/String;"},"V"));
                code.visitLabel(L1);
                code.visitJumpStmt(GOTO,-1,-1,L7);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,5);
                code.visitStmt2R(MOVE_OBJECT,3,5);
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/io/UnsupportedEncodingException;","printStackTrace",new String[]{ },"V"));
                code.visitLabel(L11);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9},new Method("Ljava/lang/Object;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitJumpStmt(GOTO,-1,-1,L7);
                code.visitLabel(L3);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/StringBuffer;");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 9},new Method("Lorg/mortbay/io/Buffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,5},new Method("Ljava/lang/StringBuffer;","<init>",new String[]{ "I"},"V"));
                code.visitLabel(L12);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 9},new Method("Lorg/mortbay/io/Buffer;","getIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitLabel(L13);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L14);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 9},new Method("Lorg/mortbay/io/Buffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitJumpStmt(IF_GE,2,5,L17);
                code.visitLabel(L15);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 9,4},new Method("Lorg/mortbay/io/Buffer;","peek",new String[]{ "I"},"B"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitStmt2R1N(AND_INT_LIT8,5,5,127);
                code.visitStmt2R(INT_TO_CHAR,5,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,5},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "C"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L16);
                code.visitStmt2R1N(ADD_INT_LIT8,4,4,1);
                code.visitStmt2R1N(ADD_INT_LIT8,2,2,1);
                code.visitJumpStmt(GOTO,-1,-1,L14);
                code.visitLabel(L17);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/StringBuffer;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitLabel(L4);
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitJumpStmt(GOTO,-1,-1,L7);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m009_toBuffer(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/io/BufferUtil;","toBuffer",new String[]{ "J"},"Lorg/mortbay/io/Buffer;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"value");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(278,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(279,L1);
                ddv.visitStartLocal(0,L1,"buf","Lorg/mortbay/io/ByteArrayBuffer;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(280,L2);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/io/ByteArrayBuffer;");
                code.visitConstStmt(CONST_16,1, Integer.valueOf(16)); // int: 0x00000010  float:0.000000
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Lorg/mortbay/io/ByteArrayBuffer;","<init>",new String[]{ "I"},"V"));
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,2,3},new Method("Lorg/mortbay/io/BufferUtil;","putDecLong",new String[]{ "Lorg/mortbay/io/Buffer;","J"},"V"));
                code.visitLabel(L2);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m010_toInt(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/io/BufferUtil;","toInt",new String[]{ "Lorg/mortbay/io/Buffer;"},"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(9);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"buffer");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(42,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(43,L2);
                ddv.visitStartLocal(4,L2,"val","I",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(44,L3);
                ddv.visitStartLocal(3,L3,"started","Z",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(45,L4);
                ddv.visitStartLocal(2,L4,"minus","Z",null);
                DexLabel L5=new DexLabel();
                ddv.visitStartLocal(1,L5,"i","I",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(47,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(48,L7);
                ddv.visitStartLocal(0,L7,"b","B",null);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(50,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(66,L9);
                ddv.visitEndLocal(0,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(67,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(53,L11);
                ddv.visitRestartLocal(0,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(55,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(56,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(45,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(58,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(60,L16);
                DexLabel L17=new DexLabel();
                ddv.visitEndLocal(0,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(67,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(68,L19);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_16,7, Integer.valueOf(48)); // int: 0x00000030  float:0.000000
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L2);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 8},new Method("Lorg/mortbay/io/Buffer;","getIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 8},new Method("Lorg/mortbay/io/Buffer;","putIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitJumpStmt(IF_GE,1,5,L9);
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 8,1},new Method("Lorg/mortbay/io/Buffer;","peek",new String[]{ "I"},"B"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitLabel(L7);
                code.visitConstStmt(CONST_16,5, Integer.valueOf(32)); // int: 0x00000020  float:0.000000
                code.visitJumpStmt(IF_GT,0,5,L11);
                code.visitLabel(L8);
                code.visitJumpStmt(IF_EQZ,3,-1,L14);
                code.visitLabel(L9);
                code.visitJumpStmt(IF_EQZ,3,-1,L19);
                code.visitLabel(L10);
                code.visitJumpStmt(IF_EQZ,2,-1,L17);
                code.visitStmt2R(NEG_INT,5,4);
                DexLabel L20=new DexLabel();
                code.visitLabel(L20);
                code.visitStmt1R(RETURN,5);
                code.visitLabel(L11);
                code.visitJumpStmt(IF_LT,0,7,L15);
                code.visitConstStmt(CONST_16,5, Integer.valueOf(57)); // int: 0x00000039  float:0.000000
                code.visitJumpStmt(IF_GT,0,5,L15);
                code.visitLabel(L12);
                code.visitStmt2R1N(MUL_INT_LIT8,5,4,10);
                code.visitStmt3R(SUB_INT,6,0,7);
                code.visitStmt3R(ADD_INT,4,5,6);
                code.visitLabel(L13);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L14);
                code.visitStmt2R1N(ADD_INT_LIT8,1,1,1);
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitLabel(L15);
                code.visitConstStmt(CONST_16,5, Integer.valueOf(45)); // int: 0x0000002d  float:0.000000
                code.visitJumpStmt(IF_NE,0,5,L9);
                code.visitJumpStmt(IF_NEZ,3,-1,L9);
                code.visitLabel(L16);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L14);
                code.visitLabel(L17);
                code.visitStmt2R(MOVE,5,4);
                code.visitLabel(L18);
                code.visitJumpStmt(GOTO,-1,-1,L20);
                code.visitLabel(L19);
                code.visitTypeStmt(NEW_INSTANCE,5,-1,"Ljava/lang/NumberFormatException;");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Ljava/lang/Object;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 5,6},new Method("Ljava/lang/NumberFormatException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,5);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m011_toLong(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/io/BufferUtil;","toLong",new String[]{ "Lorg/mortbay/io/Buffer;"},"J"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(12);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"buffer");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(80,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(81,L2);
                ddv.visitStartLocal(4,L2,"val","J",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(82,L3);
                ddv.visitStartLocal(3,L3,"started","Z",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(83,L4);
                ddv.visitStartLocal(2,L4,"minus","Z",null);
                DexLabel L5=new DexLabel();
                ddv.visitStartLocal(1,L5,"i","I",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(85,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(86,L7);
                ddv.visitStartLocal(0,L7,"b","B",null);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(88,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(104,L9);
                ddv.visitEndLocal(0,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(105,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(91,L11);
                ddv.visitRestartLocal(0,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(93,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(94,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(83,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(96,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(98,L16);
                DexLabel L17=new DexLabel();
                ddv.visitEndLocal(0,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(105,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(106,L19);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_16,10, Integer.valueOf(48)); // int: 0x00000030  float:0.000000
                code.visitLabel(L1);
                code.visitConstStmt(CONST_WIDE_16,4,Long.valueOf(0L)); // long: 0x0000000000000000  double:0.000000
                code.visitLabel(L2);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 11},new Method("Lorg/mortbay/io/Buffer;","getIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 11},new Method("Lorg/mortbay/io/Buffer;","putIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitJumpStmt(IF_GE,1,6,L9);
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 11,1},new Method("Lorg/mortbay/io/Buffer;","peek",new String[]{ "I"},"B"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitLabel(L7);
                code.visitConstStmt(CONST_16,6, Integer.valueOf(32)); // int: 0x00000020  float:0.000000
                code.visitJumpStmt(IF_GT,0,6,L11);
                code.visitLabel(L8);
                code.visitJumpStmt(IF_EQZ,3,-1,L14);
                code.visitLabel(L9);
                code.visitJumpStmt(IF_EQZ,3,-1,L19);
                code.visitLabel(L10);
                code.visitJumpStmt(IF_EQZ,2,-1,L17);
                code.visitStmt2R(NEG_LONG,6,4);
                DexLabel L20=new DexLabel();
                code.visitLabel(L20);
                code.visitStmt1R(RETURN_WIDE,6);
                code.visitLabel(L11);
                code.visitJumpStmt(IF_LT,0,10,L15);
                code.visitConstStmt(CONST_16,6, Integer.valueOf(57)); // int: 0x00000039  float:0.000000
                code.visitJumpStmt(IF_GT,0,6,L15);
                code.visitLabel(L12);
                code.visitConstStmt(CONST_WIDE_16,6,Long.valueOf(10L)); // long: 0x000000000000000a  double:0.000000
                code.visitStmt2R(MUL_LONG_2ADDR,6,4);
                code.visitStmt3R(SUB_INT,8,0,10);
                code.visitStmt2R(INT_TO_LONG,8,8);
                code.visitStmt3R(ADD_LONG,4,6,8);
                code.visitLabel(L13);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L14);
                code.visitStmt2R1N(ADD_INT_LIT8,1,1,1);
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitLabel(L15);
                code.visitConstStmt(CONST_16,6, Integer.valueOf(45)); // int: 0x0000002d  float:0.000000
                code.visitJumpStmt(IF_NE,0,6,L9);
                code.visitJumpStmt(IF_NEZ,3,-1,L9);
                code.visitLabel(L16);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L14);
                code.visitLabel(L17);
                code.visitStmt2R(MOVE_WIDE,6,4);
                code.visitLabel(L18);
                code.visitJumpStmt(GOTO,-1,-1,L20);
                code.visitLabel(L19);
                code.visitTypeStmt(NEW_INSTANCE,6,-1,"Ljava/lang/NumberFormatException;");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11},new Method("Ljava/lang/Object;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 6,7},new Method("Ljava/lang/NumberFormatException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,6);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
