package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0271_org_mortbay_jetty_security_ClientCertAuthenticator {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/jetty/security/ClientCertAuthenticator;","Ljava/lang/Object;",new String[]{ "Lorg/mortbay/jetty/security/Authenticator;"});
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("ClientCertAuthenticator.java");
        f000__maxHandShakeSeconds(cv);
        m000__init_(cv);
        m001_authenticate(cv);
        m002_getAuthMethod(cv);
        m003_getMaxHandShakeSeconds(cv);
        m004_setMaxHandShakeSeconds(cv);
    }
    public static void f000__maxHandShakeSeconds(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/security/ClientCertAuthenticator;","_maxHandShakeSeconds","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/security/ClientCertAuthenticator;","<init>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(39,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(35,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(40,L2);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljava/lang/Object;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitConstStmt(CONST_16,0, Integer.valueOf(60)); // int: 0x0000003c  float:0.000000
                code.visitFieldStmt(IPUT,0,1,new Field("Lorg/mortbay/jetty/security/ClientCertAuthenticator;","_maxHandShakeSeconds","I"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001_authenticate(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/ClientCertAuthenticator;","authenticate",new String[]{ "Lorg/mortbay/jetty/security/UserRealm;","Ljava/lang/String;","Lorg/mortbay/jetty/Request;","Lorg/mortbay/jetty/Response;"},"Ljava/security/Principal;"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(14);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"realm");
                ddv.visitParameterName(1,"pathInContext");
                ddv.visitParameterName(2,"request");
                ddv.visitParameterName(3,"response");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(71,L1);
                DexLabel L2=new DexLabel();
                ddv.visitEndLocal(9,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(76,L3);
                ddv.visitStartLocal(1,L3,"certs","[Ljava/security/cert/X509Certificate;",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(78,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(79,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(98,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(83,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(84,L8);
                ddv.visitStartLocal(2,L8,"principal","Ljava/security/Principal;",null);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(85,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(86,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(88,L11);
                ddv.visitStartLocal(4,L11,"username","Ljava/lang/String;",null);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(89,L12);
                ddv.visitStartLocal(3,L12,"user","Ljava/security/Principal;",null);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(91,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(92,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(93,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(86,L16);
                ddv.visitEndLocal(4,L16);
                ddv.visitEndLocal(3,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(96,L17);
                ddv.visitRestartLocal(3,L17);
                ddv.visitRestartLocal(4,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(97,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(98,L19);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,8, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitConstStmt(CONST_16,7, Integer.valueOf(403)); // int: 0x00000193  float:0.000000
                code.visitConstStmt(CONST_4,6, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitConstStmt(CONST_STRING,5,"javax.servlet.request.X509Certificate");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12,5},new Method("Lorg/mortbay/jetty/Request;","getAttribute",new String[]{ "Ljava/lang/String;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitLabel(L2);
                code.visitTypeStmt(CHECK_CAST,9,-1,"[Ljava/security/cert/X509Certificate;");
                code.visitStmt2R(MOVE_OBJECT,0,9);
                code.visitTypeStmt(CHECK_CAST,0,-1,"[Ljava/security/cert/X509Certificate;");
                code.visitStmt2R(MOVE_OBJECT,1,0);
                code.visitLabel(L3);
                code.visitJumpStmt(IF_EQZ,1,-1,L4);
                code.visitStmt2R(ARRAY_LENGTH,5,1);
                code.visitJumpStmt(IF_EQZ,5,-1,L4);
                code.visitStmt3R(AGET_OBJECT,5,1,6);
                code.visitJumpStmt(IF_NEZ,5,-1,L7);
                code.visitLabel(L4);
                DexLabel L20=new DexLabel();
                code.visitJumpStmt(IF_EQZ,13,-1,L20);
                code.visitLabel(L5);
                code.visitConstStmt(CONST_STRING,5,"A client certificate is required for accessing this web application but the server\'s listener is not configured for mutual authentication (or the client did not provide a certificate).");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13,7,5},new Method("Lorg/mortbay/jetty/Response;","sendError",new String[]{ "I","Ljava/lang/String;"},"V"));
                code.visitLabel(L20);
                code.visitStmt2R(MOVE_OBJECT,5,8);
                code.visitLabel(L6);
                code.visitStmt1R(RETURN_OBJECT,5);
                code.visitLabel(L7);
                code.visitStmt3R(AGET_OBJECT,5,1,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/security/cert/X509Certificate;","getSubjectDN",new String[]{ },"Ljava/security/Principal;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L8);
                code.visitJumpStmt(IF_NEZ,2,-1,L10);
                code.visitLabel(L9);
                code.visitStmt3R(AGET_OBJECT,5,1,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/security/cert/X509Certificate;","getIssuerDN",new String[]{ },"Ljava/security/Principal;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L10);
                code.visitJumpStmt(IF_NEZ,2,-1,L16);
                code.visitConstStmt(CONST_STRING,5,"clientcert");
                code.visitStmt2R(MOVE_OBJECT,4,5);
                code.visitLabel(L11);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 10,4,1,12},new Method("Lorg/mortbay/jetty/security/UserRealm;","authenticate",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;","Lorg/mortbay/jetty/Request;"},"Ljava/security/Principal;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitLabel(L12);
                code.visitJumpStmt(IF_NEZ,3,-1,L17);
                code.visitLabel(L13);
                DexLabel L21=new DexLabel();
                code.visitJumpStmt(IF_EQZ,13,-1,L21);
                code.visitLabel(L14);
                code.visitConstStmt(CONST_STRING,5,"The provided client certificate does not correspond to a trusted user.");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13,7,5},new Method("Lorg/mortbay/jetty/Response;","sendError",new String[]{ "I","Ljava/lang/String;"},"V"));
                code.visitLabel(L21);
                code.visitStmt2R(MOVE_OBJECT,5,8);
                code.visitLabel(L15);
                code.visitJumpStmt(GOTO,-1,-1,L6);
                code.visitLabel(L16);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2},new Method("Ljava/security/Principal;","getName",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitStmt2R(MOVE_OBJECT,4,5);
                code.visitJumpStmt(GOTO,-1,-1,L11);
                code.visitLabel(L17);
                code.visitConstStmt(CONST_STRING,5,"CLIENT_CERT");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12,5},new Method("Lorg/mortbay/jetty/Request;","setAuthType",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L18);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12,3},new Method("Lorg/mortbay/jetty/Request;","setUserPrincipal",new String[]{ "Ljava/security/Principal;"},"V"));
                code.visitStmt2R(MOVE_OBJECT,5,3);
                code.visitLabel(L19);
                code.visitJumpStmt(GOTO,-1,-1,L6);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_getAuthMethod(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/ClientCertAuthenticator;","getAuthMethod",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(104,L0);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_STRING,0,"CLIENT_CERT");
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_getMaxHandShakeSeconds(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/ClientCertAuthenticator;","getMaxHandShakeSeconds",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(45,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,1,new Field("Lorg/mortbay/jetty/security/ClientCertAuthenticator;","_maxHandShakeSeconds","I"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_setMaxHandShakeSeconds(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/ClientCertAuthenticator;","setMaxHandShakeSeconds",new String[]{ "I"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"maxHandShakeSeconds");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(55,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(56,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT,1,0,new Field("Lorg/mortbay/jetty/security/ClientCertAuthenticator;","_maxHandShakeSeconds","I"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
