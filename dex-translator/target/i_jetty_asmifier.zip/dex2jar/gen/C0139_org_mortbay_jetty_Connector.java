package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0139_org_mortbay_jetty_Connector {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC|ACC_INTERFACE|ACC_ABSTRACT,"Lorg/mortbay/jetty/Connector;","Ljava/lang/Object;",new String[]{ "Lorg/mortbay/component/LifeCycle;","Lorg/mortbay/io/Buffers;"});
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("Connector.java");
        m000_close(cv);
        m001_customize(cv);
        m002_getConfidentialPort(cv);
        m003_getConfidentialScheme(cv);
        m004_getConnection(cv);
        m005_getConnections(cv);
        m006_getConnectionsDurationAve(cv);
        m007_getConnectionsDurationMax(cv);
        m008_getConnectionsDurationMin(cv);
        m009_getConnectionsDurationTotal(cv);
        m010_getConnectionsOpen(cv);
        m011_getConnectionsOpenMax(cv);
        m012_getConnectionsOpenMin(cv);
        m013_getConnectionsRequestsAve(cv);
        m014_getConnectionsRequestsMax(cv);
        m015_getConnectionsRequestsMin(cv);
        m016_getHeaderBufferSize(cv);
        m017_getHost(cv);
        m018_getIntegralPort(cv);
        m019_getIntegralScheme(cv);
        m020_getLocalPort(cv);
        m021_getLowResourceMaxIdleTime(cv);
        m022_getMaxIdleTime(cv);
        m023_getName(cv);
        m024_getPort(cv);
        m025_getRequestBufferSize(cv);
        m026_getRequests(cv);
        m027_getResolveNames(cv);
        m028_getResponseBufferSize(cv);
        m029_getServer(cv);
        m030_getStatsOn(cv);
        m031_getStatsOnMs(cv);
        m032_isConfidential(cv);
        m033_isIntegral(cv);
        m034_newContinuation(cv);
        m035_open(cv);
        m036_persist(cv);
        m037_setHeaderBufferSize(cv);
        m038_setHost(cv);
        m039_setLowResourceMaxIdleTime(cv);
        m040_setMaxIdleTime(cv);
        m041_setPort(cv);
        m042_setRequestBufferSize(cv);
        m043_setResponseBufferSize(cv);
        m044_setServer(cv);
        m045_setStatsOn(cv);
        m046_statsReset(cv);
    }
    public static void m000_close(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/jetty/Connector;","close",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            mv.visitEnd();
        }
    }
    public static void m001_customize(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/jetty/Connector;","customize",new String[]{ "Lorg/mortbay/io/EndPoint;","Lorg/mortbay/jetty/Request;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            mv.visitEnd();
        }
    }
    public static void m002_getConfidentialPort(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/jetty/Connector;","getConfidentialPort",new String[]{ },"I"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m003_getConfidentialScheme(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/jetty/Connector;","getConfidentialScheme",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m004_getConnection(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/jetty/Connector;","getConnection",new String[]{ },"Ljava/lang/Object;"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m005_getConnections(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/jetty/Connector;","getConnections",new String[]{ },"I"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m006_getConnectionsDurationAve(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/jetty/Connector;","getConnectionsDurationAve",new String[]{ },"J"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m007_getConnectionsDurationMax(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/jetty/Connector;","getConnectionsDurationMax",new String[]{ },"J"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m008_getConnectionsDurationMin(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/jetty/Connector;","getConnectionsDurationMin",new String[]{ },"J"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m009_getConnectionsDurationTotal(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/jetty/Connector;","getConnectionsDurationTotal",new String[]{ },"J"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m010_getConnectionsOpen(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/jetty/Connector;","getConnectionsOpen",new String[]{ },"I"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m011_getConnectionsOpenMax(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/jetty/Connector;","getConnectionsOpenMax",new String[]{ },"I"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m012_getConnectionsOpenMin(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/jetty/Connector;","getConnectionsOpenMin",new String[]{ },"I"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m013_getConnectionsRequestsAve(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/jetty/Connector;","getConnectionsRequestsAve",new String[]{ },"I"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m014_getConnectionsRequestsMax(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/jetty/Connector;","getConnectionsRequestsMax",new String[]{ },"I"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m015_getConnectionsRequestsMin(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/jetty/Connector;","getConnectionsRequestsMin",new String[]{ },"I"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m016_getHeaderBufferSize(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/jetty/Connector;","getHeaderBufferSize",new String[]{ },"I"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m017_getHost(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/jetty/Connector;","getHost",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m018_getIntegralPort(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/jetty/Connector;","getIntegralPort",new String[]{ },"I"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m019_getIntegralScheme(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/jetty/Connector;","getIntegralScheme",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m020_getLocalPort(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/jetty/Connector;","getLocalPort",new String[]{ },"I"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m021_getLowResourceMaxIdleTime(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/jetty/Connector;","getLowResourceMaxIdleTime",new String[]{ },"I"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m022_getMaxIdleTime(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/jetty/Connector;","getMaxIdleTime",new String[]{ },"I"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m023_getName(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/jetty/Connector;","getName",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m024_getPort(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/jetty/Connector;","getPort",new String[]{ },"I"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m025_getRequestBufferSize(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/jetty/Connector;","getRequestBufferSize",new String[]{ },"I"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m026_getRequests(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/jetty/Connector;","getRequests",new String[]{ },"I"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m027_getResolveNames(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/jetty/Connector;","getResolveNames",new String[]{ },"Z"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m028_getResponseBufferSize(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/jetty/Connector;","getResponseBufferSize",new String[]{ },"I"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m029_getServer(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/jetty/Connector;","getServer",new String[]{ },"Lorg/mortbay/jetty/Server;"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m030_getStatsOn(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/jetty/Connector;","getStatsOn",new String[]{ },"Z"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m031_getStatsOnMs(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/jetty/Connector;","getStatsOnMs",new String[]{ },"J"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m032_isConfidential(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/jetty/Connector;","isConfidential",new String[]{ "Lorg/mortbay/jetty/Request;"},"Z"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m033_isIntegral(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/jetty/Connector;","isIntegral",new String[]{ "Lorg/mortbay/jetty/Request;"},"Z"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m034_newContinuation(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/jetty/Connector;","newContinuation",new String[]{ },"Lorg/mortbay/util/ajax/Continuation;"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m035_open(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/jetty/Connector;","open",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            mv.visitEnd();
        }
    }
    public static void m036_persist(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/jetty/Connector;","persist",new String[]{ "Lorg/mortbay/io/EndPoint;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            mv.visitEnd();
        }
    }
    public static void m037_setHeaderBufferSize(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/jetty/Connector;","setHeaderBufferSize",new String[]{ "I"},"V"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m038_setHost(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/jetty/Connector;","setHost",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m039_setLowResourceMaxIdleTime(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/jetty/Connector;","setLowResourceMaxIdleTime",new String[]{ "I"},"V"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m040_setMaxIdleTime(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/jetty/Connector;","setMaxIdleTime",new String[]{ "I"},"V"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m041_setPort(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/jetty/Connector;","setPort",new String[]{ "I"},"V"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m042_setRequestBufferSize(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/jetty/Connector;","setRequestBufferSize",new String[]{ "I"},"V"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m043_setResponseBufferSize(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/jetty/Connector;","setResponseBufferSize",new String[]{ "I"},"V"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m044_setServer(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/jetty/Connector;","setServer",new String[]{ "Lorg/mortbay/jetty/Server;"},"V"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m045_setStatsOn(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/jetty/Connector;","setStatsOn",new String[]{ "Z"},"V"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m046_statsReset(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/jetty/Connector;","statsReset",new String[]{ },"V"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
}
