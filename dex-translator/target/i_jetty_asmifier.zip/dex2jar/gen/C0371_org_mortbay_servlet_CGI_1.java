package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0371_org_mortbay_servlet_CGI_1 {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(0,"Lorg/mortbay/servlet/CGI$1;","Ljava/lang/Object;",new String[]{ "Ljava/lang/Runnable;"});
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("CGI.java");
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/EnclosingMethod;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("value", new Method("Lorg/mortbay/servlet/CGI;","exec",new String[]{ "Ljava/io/File;","Ljava/lang/String;","Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;"},"V"));
                av00.visitEnd();
            }
        }
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/InnerClass;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("accessFlags",  Integer.valueOf(0));
                av00.visit("name", null);
                av00.visitEnd();
            }
        }
        f000_this$0(cv);
        f001_val$inFromReq(cv);
        f002_val$inLength(cv);
        f003_val$outToCgi(cv);
        m000__init_(cv);
        m001_run(cv);
    }
    public static void f000_this$0(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_FINAL|ACC_SYNTHETIC, new Field("Lorg/mortbay/servlet/CGI$1;","this$0","Lorg/mortbay/servlet/CGI;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001_val$inFromReq(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_FINAL|ACC_SYNTHETIC, new Field("Lorg/mortbay/servlet/CGI$1;","val$inFromReq","Ljava/io/InputStream;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002_val$inLength(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_FINAL|ACC_SYNTHETIC, new Field("Lorg/mortbay/servlet/CGI$1;","val$inLength","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003_val$outToCgi(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_FINAL|ACC_SYNTHETIC, new Field("Lorg/mortbay/servlet/CGI$1;","val$outToCgi","Ljava/io/OutputStream;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_CONSTRUCTOR, new Method("Lorg/mortbay/servlet/CGI$1;","<init>",new String[]{ "Lorg/mortbay/servlet/CGI;","I","Ljava/io/InputStream;","Ljava/io/OutputStream;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(279,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/servlet/CGI$1;","this$0","Lorg/mortbay/servlet/CGI;"));
                code.visitFieldStmt(IPUT,2,0,new Field("Lorg/mortbay/servlet/CGI$1;","val$inLength","I"));
                code.visitFieldStmt(IPUT_OBJECT,3,0,new Field("Lorg/mortbay/servlet/CGI$1;","val$inFromReq","Ljava/io/InputStream;"));
                code.visitFieldStmt(IPUT_OBJECT,4,0,new Field("Lorg/mortbay/servlet/CGI$1;","val$outToCgi","Ljava/io/OutputStream;"));
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/Object;","<init>",new String[]{ },"V"));
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001_run(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/servlet/CGI$1;","run",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/io/IOException;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(283,L0);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(284,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(285,L4);
                ddv.visitLineNumber(291,L1);
                ddv.visitLineNumber(287,L2);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(289,L5);
                ddv.visitStartLocal(0,L5,"e","Ljava/io/IOException;",null);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,1,5,new Field("Lorg/mortbay/servlet/CGI$1;","val$inLength","I"));
                code.visitJumpStmt(IF_LEZ,1,-1,L4);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,1,5,new Field("Lorg/mortbay/servlet/CGI$1;","val$inFromReq","Ljava/io/InputStream;"));
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/servlet/CGI$1;","val$outToCgi","Ljava/io/OutputStream;"));
                code.visitFieldStmt(IGET,3,5,new Field("Lorg/mortbay/servlet/CGI$1;","val$inLength","I"));
                code.visitStmt2R(INT_TO_LONG,3,3);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1,2,3,4},new Method("Lorg/mortbay/util/IO;","copy",new String[]{ "Ljava/io/InputStream;","Ljava/io/OutputStream;","J"},"V"));
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,1,5,new Field("Lorg/mortbay/servlet/CGI$1;","val$outToCgi","Ljava/io/OutputStream;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/io/OutputStream;","close",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitStmt2R(MOVE_OBJECT,0,1);
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/log/Log;","ignore",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
