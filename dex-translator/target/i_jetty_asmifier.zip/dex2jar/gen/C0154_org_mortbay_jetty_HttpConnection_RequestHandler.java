package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0154_org_mortbay_jetty_HttpConnection_RequestHandler {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(0,"Lorg/mortbay/jetty/HttpConnection$RequestHandler;","Lorg/mortbay/jetty/HttpParser$EventHandler;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("HttpConnection.java");
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/EnclosingClass;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("value", new DexType("Lorg/mortbay/jetty/HttpConnection;"));
                av00.visitEnd();
            }
        }
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/InnerClass;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("accessFlags",  Integer.valueOf(2));
                av00.visit("name", "RequestHandler");
                av00.visitEnd();
            }
        }
        f000__charset(cv);
        f001_this$0(cv);
        m000__init_(cv);
        m001__init_(cv);
        m002_content(cv);
        m003_headerComplete(cv);
        m004_messageComplete(cv);
        m005_parsedHeader(cv);
        m006_startRequest(cv);
        m007_startResponse(cv);
    }
    public static void f000__charset(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/HttpConnection$RequestHandler;","_charset","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001_this$0(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_FINAL|ACC_SYNTHETIC, new Field("Lorg/mortbay/jetty/HttpConnection$RequestHandler;","this$0","Lorg/mortbay/jetty/HttpConnection;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PRIVATE|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/HttpConnection$RequestHandler;","<init>",new String[]{ "Lorg/mortbay/jetty/HttpConnection;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(678,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/HttpConnection$RequestHandler;","this$0","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Lorg/mortbay/jetty/HttpParser$EventHandler;","<init>",new String[]{ },"V"));
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_SYNTHETIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/HttpConnection$RequestHandler;","<init>",new String[]{ "Lorg/mortbay/jetty/HttpConnection;","Lorg/mortbay/jetty/HttpConnection$1;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"x0");
                ddv.visitParameterName(1,"x1");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(678,L0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/HttpConnection$RequestHandler;","<init>",new String[]{ "Lorg/mortbay/jetty/HttpConnection;"},"V"));
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_content(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpConnection$RequestHandler;","content",new String[]{ "Lorg/mortbay/io/Buffer;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"ref");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(877,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(879,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(880,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(882,L3);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/HttpConnection$RequestHandler;","this$0","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/jetty/HttpConnection;","access$400",new String[]{ "Lorg/mortbay/jetty/HttpConnection;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L3);
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/HttpConnection$RequestHandler;","this$0","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/HttpConnection;","access$402",new String[]{ "Lorg/mortbay/jetty/HttpConnection;","Z"},"Z"));
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/HttpConnection$RequestHandler;","this$0","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/HttpConnection;","handleRequest",new String[]{ },"V"));
                code.visitLabel(L3);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_headerComplete(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpConnection$RequestHandler;","headerComplete",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(8);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(808,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(809,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(810,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(860,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(861,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(864,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(865,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(868,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(815,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(818,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(820,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(821,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(823,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(825,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(826,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(827,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(828,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(832,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(834,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(838,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(840,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(841,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(842,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(843,L24);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(846,L25);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(851,L26);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(867,L27);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(810,L28);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,6, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitConstStmt(CONST_4,5, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,7,new Field("Lorg/mortbay/jetty/HttpConnection$RequestHandler;","this$0","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/jetty/HttpConnection;","access$708",new String[]{ "Lorg/mortbay/jetty/HttpConnection;"},"I"));
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,0,7,new Field("Lorg/mortbay/jetty/HttpConnection$RequestHandler;","this$0","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpConnection;","_generator","Lorg/mortbay/jetty/Generator;"));
                code.visitFieldStmt(IGET_OBJECT,1,7,new Field("Lorg/mortbay/jetty/HttpConnection$RequestHandler;","this$0","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1},new Method("Lorg/mortbay/jetty/HttpConnection;","access$500",new String[]{ "Lorg/mortbay/jetty/HttpConnection;"},"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/Generator;","setVersion",new String[]{ "I"},"V"));
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,7,new Field("Lorg/mortbay/jetty/HttpConnection$RequestHandler;","this$0","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/jetty/HttpConnection;","access$500",new String[]{ "Lorg/mortbay/jetty/HttpConnection;"},"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitSparseSwitchStmt(PACKED_SWITCH,0,9,new DexLabel[]{L4,L9,L10});
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,0,7,new Field("Lorg/mortbay/jetty/HttpConnection$RequestHandler;","_charset","Ljava/lang/String;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L6);
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,0,7,new Field("Lorg/mortbay/jetty/HttpConnection$RequestHandler;","this$0","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpConnection;","_request","Lorg/mortbay/jetty/Request;"));
                code.visitFieldStmt(IGET_OBJECT,1,7,new Field("Lorg/mortbay/jetty/HttpConnection$RequestHandler;","_charset","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/Request;","setCharacterEncodingUnchecked",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,0,7,new Field("Lorg/mortbay/jetty/HttpConnection$RequestHandler;","this$0","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpConnection;","_parser","Lorg/mortbay/jetty/Parser;"));
                code.visitTypeStmt(CHECK_CAST,0,-1,"Lorg/mortbay/jetty/HttpParser;");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/HttpParser;","getContentLength",new String[]{ },"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,0);
                code.visitConstStmt(CONST_WIDE_16,2,Long.valueOf(0L)); // long: 0x0000000000000000  double:0.000000
                code.visitStmt3R(CMP_LONG,0,0,2);
                code.visitJumpStmt(IF_GTZ,0,-1,L27);
                code.visitFieldStmt(IGET_OBJECT,0,7,new Field("Lorg/mortbay/jetty/HttpConnection$RequestHandler;","this$0","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpConnection;","_parser","Lorg/mortbay/jetty/Parser;"));
                code.visitTypeStmt(CHECK_CAST,0,-1,"Lorg/mortbay/jetty/HttpParser;");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/HttpParser;","isChunking",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_NEZ,0,-1,L27);
                code.visitLabel(L7);
                code.visitFieldStmt(IGET_OBJECT,0,7,new Field("Lorg/mortbay/jetty/HttpConnection$RequestHandler;","this$0","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/HttpConnection;","handleRequest",new String[]{ },"V"));
                code.visitLabel(L8);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L9);
                code.visitFieldStmt(IGET_OBJECT,0,7,new Field("Lorg/mortbay/jetty/HttpConnection$RequestHandler;","this$0","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpConnection;","_generator","Lorg/mortbay/jetty/Generator;"));
                code.visitFieldStmt(IGET_OBJECT,1,7,new Field("Lorg/mortbay/jetty/HttpConnection$RequestHandler;","this$0","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1},new Method("Lorg/mortbay/jetty/HttpConnection;","access$600",new String[]{ "Lorg/mortbay/jetty/HttpConnection;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/Generator;","setHead",new String[]{ "Z"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitLabel(L10);
                code.visitFieldStmt(IGET_OBJECT,0,7,new Field("Lorg/mortbay/jetty/HttpConnection$RequestHandler;","this$0","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpConnection;","_generator","Lorg/mortbay/jetty/Generator;"));
                code.visitFieldStmt(IGET_OBJECT,1,7,new Field("Lorg/mortbay/jetty/HttpConnection$RequestHandler;","this$0","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1},new Method("Lorg/mortbay/jetty/HttpConnection;","access$600",new String[]{ "Lorg/mortbay/jetty/HttpConnection;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/Generator;","setHead",new String[]{ "Z"},"V"));
                code.visitLabel(L11);
                code.visitFieldStmt(IGET_OBJECT,0,7,new Field("Lorg/mortbay/jetty/HttpConnection$RequestHandler;","this$0","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpConnection;","_server","Lorg/mortbay/jetty/Server;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/Server;","getSendDateHeader",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L13);
                code.visitLabel(L12);
                code.visitFieldStmt(IGET_OBJECT,0,7,new Field("Lorg/mortbay/jetty/HttpConnection$RequestHandler;","this$0","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpConnection;","_responseFields","Lorg/mortbay/jetty/HttpFields;"));
                code.visitFieldStmt(SGET_OBJECT,1,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","DATE_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitFieldStmt(IGET_OBJECT,2,7,new Field("Lorg/mortbay/jetty/HttpConnection$RequestHandler;","this$0","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitFieldStmt(IGET_OBJECT,2,2,new Field("Lorg/mortbay/jetty/HttpConnection;","_request","Lorg/mortbay/jetty/Request;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/Request;","getTimeStampBuffer",new String[]{ },"Lorg/mortbay/io/Buffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitFieldStmt(IGET_OBJECT,3,7,new Field("Lorg/mortbay/jetty/HttpConnection$RequestHandler;","this$0","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitFieldStmt(IGET_OBJECT,3,3,new Field("Lorg/mortbay/jetty/HttpConnection;","_request","Lorg/mortbay/jetty/Request;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/jetty/Request;","getTimeStamp",new String[]{ },"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2,3,4},new Method("Lorg/mortbay/jetty/HttpFields;","put",new String[]{ "Lorg/mortbay/io/Buffer;","Lorg/mortbay/io/Buffer;","J"},"V"));
                code.visitLabel(L13);
                code.visitFieldStmt(IGET_OBJECT,0,7,new Field("Lorg/mortbay/jetty/HttpConnection$RequestHandler;","this$0","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/jetty/HttpConnection;","access$100",new String[]{ "Lorg/mortbay/jetty/HttpConnection;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_NEZ,0,-1,L18);
                code.visitLabel(L14);
                code.visitFieldStmt(IGET_OBJECT,0,7,new Field("Lorg/mortbay/jetty/HttpConnection$RequestHandler;","this$0","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpConnection;","_generator","Lorg/mortbay/jetty/Generator;"));
                code.visitConstStmt(CONST_16,1, Integer.valueOf(400)); // int: 0x00000190  float:0.000000
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1,5},new Method("Lorg/mortbay/jetty/Generator;","setResponse",new String[]{ "I","Ljava/lang/String;"},"V"));
                code.visitLabel(L15);
                code.visitFieldStmt(IGET_OBJECT,0,7,new Field("Lorg/mortbay/jetty/HttpConnection$RequestHandler;","this$0","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpConnection;","_responseFields","Lorg/mortbay/jetty/HttpFields;"));
                code.visitFieldStmt(SGET_OBJECT,1,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","CONNECTION_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/jetty/HttpHeaderValues;","CLOSE_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Lorg/mortbay/jetty/HttpFields;","put",new String[]{ "Lorg/mortbay/io/Buffer;","Lorg/mortbay/io/Buffer;"},"V"));
                code.visitLabel(L16);
                code.visitFieldStmt(IGET_OBJECT,0,7,new Field("Lorg/mortbay/jetty/HttpConnection$RequestHandler;","this$0","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpConnection;","_generator","Lorg/mortbay/jetty/Generator;"));
                code.visitFieldStmt(IGET_OBJECT,1,7,new Field("Lorg/mortbay/jetty/HttpConnection$RequestHandler;","this$0","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitFieldStmt(IGET_OBJECT,1,1,new Field("Lorg/mortbay/jetty/HttpConnection;","_responseFields","Lorg/mortbay/jetty/HttpFields;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1,6},new Method("Lorg/mortbay/jetty/Generator;","completeHeader",new String[]{ "Lorg/mortbay/jetty/HttpFields;","Z"},"V"));
                code.visitLabel(L17);
                code.visitFieldStmt(IGET_OBJECT,0,7,new Field("Lorg/mortbay/jetty/HttpConnection$RequestHandler;","this$0","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpConnection;","_generator","Lorg/mortbay/jetty/Generator;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Lorg/mortbay/jetty/Generator;","complete",new String[]{ },"V"));
                code.visitJumpStmt(GOTO,-1,-1,L8);
                code.visitLabel(L18);
                code.visitFieldStmt(IGET_OBJECT,0,7,new Field("Lorg/mortbay/jetty/HttpConnection$RequestHandler;","this$0","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/jetty/HttpConnection;","access$200",new String[]{ "Lorg/mortbay/jetty/HttpConnection;"},"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/jetty/HttpConnection;","access$300",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_EQ,0,1,L4);
                code.visitLabel(L19);
                code.visitFieldStmt(IGET_OBJECT,0,7,new Field("Lorg/mortbay/jetty/HttpConnection$RequestHandler;","this$0","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/jetty/HttpConnection;","access$200",new String[]{ "Lorg/mortbay/jetty/HttpConnection;"},"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(6)); // int: 0x00000006  float:0.000000
                code.visitJumpStmt(IF_NE,0,1,L25);
                code.visitLabel(L20);
                code.visitFieldStmt(IGET_OBJECT,0,7,new Field("Lorg/mortbay/jetty/HttpConnection$RequestHandler;","this$0","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpConnection;","_parser","Lorg/mortbay/jetty/Parser;"));
                code.visitTypeStmt(CHECK_CAST,0,-1,"Lorg/mortbay/jetty/HttpParser;");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/HttpParser;","getHeaderBuffer",new String[]{ },"Lorg/mortbay/io/Buffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L21);
                code.visitFieldStmt(IGET_OBJECT,0,7,new Field("Lorg/mortbay/jetty/HttpConnection$RequestHandler;","this$0","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpConnection;","_parser","Lorg/mortbay/jetty/Parser;"));
                code.visitTypeStmt(CHECK_CAST,0,-1,"Lorg/mortbay/jetty/HttpParser;");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/HttpParser;","getHeaderBuffer",new String[]{ },"Lorg/mortbay/io/Buffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Lorg/mortbay/io/Buffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitJumpStmt(IF_GE,0,1,L4);
                code.visitLabel(L21);
                code.visitFieldStmt(IGET_OBJECT,0,7,new Field("Lorg/mortbay/jetty/HttpConnection$RequestHandler;","this$0","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpConnection;","_generator","Lorg/mortbay/jetty/Generator;"));
                code.visitConstStmt(CONST_16,1, Integer.valueOf(100)); // int: 0x00000064  float:0.000000
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1,5},new Method("Lorg/mortbay/jetty/Generator;","setResponse",new String[]{ "I","Ljava/lang/String;"},"V"));
                code.visitLabel(L22);
                code.visitFieldStmt(IGET_OBJECT,0,7,new Field("Lorg/mortbay/jetty/HttpConnection$RequestHandler;","this$0","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpConnection;","_generator","Lorg/mortbay/jetty/Generator;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,5,6},new Method("Lorg/mortbay/jetty/Generator;","completeHeader",new String[]{ "Lorg/mortbay/jetty/HttpFields;","Z"},"V"));
                code.visitLabel(L23);
                code.visitFieldStmt(IGET_OBJECT,0,7,new Field("Lorg/mortbay/jetty/HttpConnection$RequestHandler;","this$0","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpConnection;","_generator","Lorg/mortbay/jetty/Generator;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Lorg/mortbay/jetty/Generator;","complete",new String[]{ },"V"));
                code.visitLabel(L24);
                code.visitFieldStmt(IGET_OBJECT,0,7,new Field("Lorg/mortbay/jetty/HttpConnection$RequestHandler;","this$0","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpConnection;","_generator","Lorg/mortbay/jetty/Generator;"));
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/Generator;","reset",new String[]{ "Z"},"V"));
                code.visitJumpStmt(GOTO_16,-1,-1,L4);
                code.visitLabel(L25);
                code.visitFieldStmt(IGET_OBJECT,0,7,new Field("Lorg/mortbay/jetty/HttpConnection$RequestHandler;","this$0","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/jetty/HttpConnection;","access$200",new String[]{ "Lorg/mortbay/jetty/HttpConnection;"},"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(7)); // int: 0x00000007  float:0.000000
                code.visitJumpStmt(IF_EQ,0,1,L4);
                code.visitLabel(L26);
                code.visitFieldStmt(IGET_OBJECT,0,7,new Field("Lorg/mortbay/jetty/HttpConnection$RequestHandler;","this$0","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpConnection;","_generator","Lorg/mortbay/jetty/Generator;"));
                code.visitConstStmt(CONST_16,1, Integer.valueOf(417)); // int: 0x000001a1  float:0.000000
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1,5,5,6},new Method("Lorg/mortbay/jetty/Generator;","sendError",new String[]{ "I","Ljava/lang/String;","Ljava/lang/String;","Z"},"V"));
                code.visitJumpStmt(GOTO_16,-1,-1,L8);
                code.visitLabel(L27);
                code.visitFieldStmt(IGET_OBJECT,0,7,new Field("Lorg/mortbay/jetty/HttpConnection$RequestHandler;","this$0","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,6},new Method("Lorg/mortbay/jetty/HttpConnection;","access$402",new String[]{ "Lorg/mortbay/jetty/HttpConnection;","Z"},"Z"));
                code.visitJumpStmt(GOTO_16,-1,-1,L8);
                code.visitLabel(L28);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_messageComplete(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpConnection$RequestHandler;","messageComplete",new String[]{ "J"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"contentLength");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(891,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(893,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(894,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(896,L3);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/HttpConnection$RequestHandler;","this$0","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/jetty/HttpConnection;","access$400",new String[]{ "Lorg/mortbay/jetty/HttpConnection;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L3);
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/HttpConnection$RequestHandler;","this$0","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/HttpConnection;","access$402",new String[]{ "Lorg/mortbay/jetty/HttpConnection;","Z"},"Z"));
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/HttpConnection$RequestHandler;","this$0","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/HttpConnection;","handleRequest",new String[]{ },"V"));
                code.visitLabel(L3);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_parsedHeader(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpConnection$RequestHandler;","parsedHeader",new String[]{ "Lorg/mortbay/io/Buffer;","Lorg/mortbay/io/Buffer;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(13);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                ddv.visitParameterName(1,"value");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(734,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(735,L2);
                ddv.visitStartLocal(1,L2,"ho","I",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(800,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(801,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(739,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(743,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(744,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(749,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(750,L9);
                ddv.visitRestartLocal(12,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(753,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(754,L11);
                ddv.visitRestartLocal(12,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(760,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(761,L13);
                ddv.visitStartLocal(3,L13,"ordinal","I",null);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(765,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(766,L15);
                ddv.visitStartLocal(4,L15,"values","[Ljava/lang/String;",null);
                DexLabel L16=new DexLabel();
                ddv.visitStartLocal(2,L16,"i","I",null);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(768,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(770,L18);
                ddv.visitStartLocal(0,L18,"cb","Lorg/mortbay/io/BufferCache$CachedBuffer;",null);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(772,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(766,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(775,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(776,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(780,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(781,L24);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(789,L25);
                ddv.visitEndLocal(4,L25);
                ddv.visitEndLocal(2,L25);
                ddv.visitEndLocal(0,L25);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(790,L26);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(794,L27);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(795,L28);
                DexLabel L29=new DexLabel();
                ddv.visitLineNumber(735,L29);
                DexLabel L30=new DexLabel();
                ddv.visitLineNumber(761,L30);
                DexLabel L31=new DexLabel();
                ddv.visitLineNumber(772,L31);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_16,9, Integer.valueOf(10)); // int: 0x0000000a  float:0.000000
                code.visitConstStmt(CONST_4,8, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitFieldStmt(SGET_OBJECT,5,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","CACHE","Lorg/mortbay/jetty/HttpHeaders;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,11},new Method("Lorg/mortbay/jetty/HttpHeaders;","getOrdinal",new String[]{ "Lorg/mortbay/io/Buffer;"},"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitLabel(L2);
                code.visitSparseSwitchStmt(SPARSE_SWITCH,1,new int[]{ 1,16,21,24,27,40},new DexLabel[]{L12,L10,L8,L6,L5,L8});
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,5,10,new Field("Lorg/mortbay/jetty/HttpConnection$RequestHandler;","this$0","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitFieldStmt(IGET_OBJECT,5,5,new Field("Lorg/mortbay/jetty/HttpConnection;","_requestFields","Lorg/mortbay/jetty/HttpFields;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,11,12},new Method("Lorg/mortbay/jetty/HttpFields;","add",new String[]{ "Lorg/mortbay/io/Buffer;","Lorg/mortbay/io/Buffer;"},"V"));
                code.visitLabel(L4);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,5,10,new Field("Lorg/mortbay/jetty/HttpConnection$RequestHandler;","this$0","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitConstStmt(CONST_4,6, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 5,6},new Method("Lorg/mortbay/jetty/HttpConnection;","access$102",new String[]{ "Lorg/mortbay/jetty/HttpConnection;","Z"},"Z"));
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitLabel(L6);
                code.visitFieldStmt(SGET_OBJECT,5,-1,new Field("Lorg/mortbay/jetty/HttpHeaderValues;","CACHE","Lorg/mortbay/jetty/HttpHeaderValues;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,12},new Method("Lorg/mortbay/jetty/HttpHeaderValues;","lookup",new String[]{ "Lorg/mortbay/io/Buffer;"},"Lorg/mortbay/io/Buffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,12);
                code.visitLabel(L7);
                code.visitFieldStmt(IGET_OBJECT,5,10,new Field("Lorg/mortbay/jetty/HttpConnection$RequestHandler;","this$0","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitFieldStmt(SGET_OBJECT,6,-1,new Field("Lorg/mortbay/jetty/HttpHeaderValues;","CACHE","Lorg/mortbay/jetty/HttpHeaderValues;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,12},new Method("Lorg/mortbay/jetty/HttpHeaderValues;","getOrdinal",new String[]{ "Lorg/mortbay/io/Buffer;"},"I"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 5,6},new Method("Lorg/mortbay/jetty/HttpConnection;","access$202",new String[]{ "Lorg/mortbay/jetty/HttpConnection;","I"},"I"));
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitLabel(L8);
                code.visitFieldStmt(SGET_OBJECT,5,-1,new Field("Lorg/mortbay/jetty/HttpHeaderValues;","CACHE","Lorg/mortbay/jetty/HttpHeaderValues;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,12},new Method("Lorg/mortbay/jetty/HttpHeaderValues;","lookup",new String[]{ "Lorg/mortbay/io/Buffer;"},"Lorg/mortbay/io/Buffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,12);
                code.visitLabel(L9);
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitLabel(L10);
                code.visitFieldStmt(SGET_OBJECT,5,-1,new Field("Lorg/mortbay/jetty/MimeTypes;","CACHE","Lorg/mortbay/io/BufferCache;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,12},new Method("Lorg/mortbay/io/BufferCache;","lookup",new String[]{ "Lorg/mortbay/io/Buffer;"},"Lorg/mortbay/io/Buffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,12);
                code.visitLabel(L11);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 12},new Method("Lorg/mortbay/jetty/MimeTypes;","getCharsetFromContentType",new String[]{ "Lorg/mortbay/io/Buffer;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitFieldStmt(IPUT_OBJECT,5,10,new Field("Lorg/mortbay/jetty/HttpConnection$RequestHandler;","_charset","Ljava/lang/String;"));
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitLabel(L12);
                code.visitFieldStmt(SGET_OBJECT,5,-1,new Field("Lorg/mortbay/jetty/HttpHeaderValues;","CACHE","Lorg/mortbay/jetty/HttpHeaderValues;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,12},new Method("Lorg/mortbay/jetty/HttpHeaderValues;","getOrdinal",new String[]{ "Lorg/mortbay/io/Buffer;"},"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitLabel(L13);
                code.visitSparseSwitchStmt(SPARSE_SWITCH,3,new int[]{ -1,1,5},new DexLabel[]{L14,L25,L27});
                DexLabel L32=new DexLabel();
                code.visitLabel(L32);
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitLabel(L14);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12},new Method("Ljava/lang/Object;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitConstStmt(CONST_STRING,6,",");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Ljava/lang/String;","split",new String[]{ "Ljava/lang/String;"},"[Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitLabel(L15);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L16);
                code.visitJumpStmt(IF_EQZ,4,-1,L3);
                code.visitStmt2R(ARRAY_LENGTH,5,4);
                code.visitJumpStmt(IF_GE,2,5,L3);
                code.visitLabel(L17);
                code.visitFieldStmt(SGET_OBJECT,5,-1,new Field("Lorg/mortbay/jetty/HttpHeaderValues;","CACHE","Lorg/mortbay/jetty/HttpHeaderValues;"));
                code.visitStmt3R(AGET_OBJECT,6,4,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/lang/String;","trim",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Lorg/mortbay/jetty/HttpHeaderValues;","get",new String[]{ "Ljava/lang/String;"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L18);
                code.visitJumpStmt(IF_EQZ,0,-1,L20);
                code.visitLabel(L19);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/io/BufferCache$CachedBuffer;","getOrdinal",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitSparseSwitchStmt(SPARSE_SWITCH,5,new int[]{ 1,5},new DexLabel[]{L21,L23});
                code.visitLabel(L20);
                code.visitStmt2R1N(ADD_INT_LIT8,2,2,1);
                code.visitJumpStmt(GOTO,-1,-1,L16);
                code.visitLabel(L21);
                code.visitFieldStmt(IGET_OBJECT,5,10,new Field("Lorg/mortbay/jetty/HttpConnection$RequestHandler;","this$0","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitFieldStmt(IGET_OBJECT,5,5,new Field("Lorg/mortbay/jetty/HttpConnection;","_responseFields","Lorg/mortbay/jetty/HttpFields;"));
                code.visitFieldStmt(SGET_OBJECT,6,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","CONNECTION_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitFieldStmt(SGET_OBJECT,7,-1,new Field("Lorg/mortbay/jetty/HttpHeaderValues;","CLOSE_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6,7},new Method("Lorg/mortbay/jetty/HttpFields;","add",new String[]{ "Lorg/mortbay/io/Buffer;","Lorg/mortbay/io/Buffer;"},"V"));
                code.visitLabel(L22);
                code.visitFieldStmt(IGET_OBJECT,5,10,new Field("Lorg/mortbay/jetty/HttpConnection$RequestHandler;","this$0","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitFieldStmt(IGET_OBJECT,5,5,new Field("Lorg/mortbay/jetty/HttpConnection;","_generator","Lorg/mortbay/jetty/Generator;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 5,8},new Method("Lorg/mortbay/jetty/Generator;","setPersistent",new String[]{ "Z"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L20);
                code.visitLabel(L23);
                code.visitFieldStmt(IGET_OBJECT,5,10,new Field("Lorg/mortbay/jetty/HttpConnection$RequestHandler;","this$0","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 5},new Method("Lorg/mortbay/jetty/HttpConnection;","access$500",new String[]{ "Lorg/mortbay/jetty/HttpConnection;"},"I"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitJumpStmt(IF_NE,5,9,L20);
                code.visitLabel(L24);
                code.visitFieldStmt(IGET_OBJECT,5,10,new Field("Lorg/mortbay/jetty/HttpConnection$RequestHandler;","this$0","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitFieldStmt(IGET_OBJECT,5,5,new Field("Lorg/mortbay/jetty/HttpConnection;","_responseFields","Lorg/mortbay/jetty/HttpFields;"));
                code.visitFieldStmt(SGET_OBJECT,6,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","CONNECTION_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitFieldStmt(SGET_OBJECT,7,-1,new Field("Lorg/mortbay/jetty/HttpHeaderValues;","KEEP_ALIVE_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6,7},new Method("Lorg/mortbay/jetty/HttpFields;","add",new String[]{ "Lorg/mortbay/io/Buffer;","Lorg/mortbay/io/Buffer;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L20);
                code.visitLabel(L25);
                code.visitFieldStmt(IGET_OBJECT,5,10,new Field("Lorg/mortbay/jetty/HttpConnection$RequestHandler;","this$0","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitFieldStmt(IGET_OBJECT,5,5,new Field("Lorg/mortbay/jetty/HttpConnection;","_responseFields","Lorg/mortbay/jetty/HttpFields;"));
                code.visitFieldStmt(SGET_OBJECT,6,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","CONNECTION_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitFieldStmt(SGET_OBJECT,7,-1,new Field("Lorg/mortbay/jetty/HttpHeaderValues;","CLOSE_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6,7},new Method("Lorg/mortbay/jetty/HttpFields;","put",new String[]{ "Lorg/mortbay/io/Buffer;","Lorg/mortbay/io/Buffer;"},"V"));
                code.visitLabel(L26);
                code.visitFieldStmt(IGET_OBJECT,5,10,new Field("Lorg/mortbay/jetty/HttpConnection$RequestHandler;","this$0","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitFieldStmt(IGET_OBJECT,5,5,new Field("Lorg/mortbay/jetty/HttpConnection;","_generator","Lorg/mortbay/jetty/Generator;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 5,8},new Method("Lorg/mortbay/jetty/Generator;","setPersistent",new String[]{ "Z"},"V"));
                code.visitJumpStmt(GOTO_16,-1,-1,L3);
                code.visitLabel(L27);
                code.visitFieldStmt(IGET_OBJECT,5,10,new Field("Lorg/mortbay/jetty/HttpConnection$RequestHandler;","this$0","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 5},new Method("Lorg/mortbay/jetty/HttpConnection;","access$500",new String[]{ "Lorg/mortbay/jetty/HttpConnection;"},"I"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitJumpStmt(IF_NE,5,9,L3);
                code.visitLabel(L28);
                code.visitFieldStmt(IGET_OBJECT,5,10,new Field("Lorg/mortbay/jetty/HttpConnection$RequestHandler;","this$0","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitFieldStmt(IGET_OBJECT,5,5,new Field("Lorg/mortbay/jetty/HttpConnection;","_responseFields","Lorg/mortbay/jetty/HttpFields;"));
                code.visitFieldStmt(SGET_OBJECT,6,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","CONNECTION_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitFieldStmt(SGET_OBJECT,7,-1,new Field("Lorg/mortbay/jetty/HttpHeaderValues;","KEEP_ALIVE_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6,7},new Method("Lorg/mortbay/jetty/HttpFields;","put",new String[]{ "Lorg/mortbay/io/Buffer;","Lorg/mortbay/io/Buffer;"},"V"));
                code.visitJumpStmt(GOTO_16,-1,-1,L3);
                code.visitLabel(L29);
                code.visitLabel(L30);
                code.visitLabel(L31);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_startRequest(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpConnection$RequestHandler;","startRequest",new String[]{ "Lorg/mortbay/io/Buffer;","Lorg/mortbay/io/Buffer;","Lorg/mortbay/io/Buffer;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(11);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/lang/Exception;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"method");
                ddv.visitParameterName(1,"uri");
                ddv.visitParameterName(2,"version");
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(690,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(691,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(692,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(693,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(695,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(696,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(697,L10);
                ddv.visitLineNumber(701,L0);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(702,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(704,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(706,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(707,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(718,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(725,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(711,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(712,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(713,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(714,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(715,L21);
                ddv.visitLineNumber(721,L2);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(723,L22);
                ddv.visitStartLocal(0,L22,"e","Ljava/lang/Exception;",null);
                DexLabel L23=new DexLabel();
                ddv.visitEndLocal(0,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(718,L24);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,6, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitConstStmt(CONST_4,5, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,1,7,new Field("Lorg/mortbay/jetty/HttpConnection$RequestHandler;","this$0","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1,5},new Method("Lorg/mortbay/jetty/HttpConnection;","access$102",new String[]{ "Lorg/mortbay/jetty/HttpConnection;","Z"},"Z"));
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,1,7,new Field("Lorg/mortbay/jetty/HttpConnection$RequestHandler;","this$0","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/jetty/HttpConnection;","access$300",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1,2},new Method("Lorg/mortbay/jetty/HttpConnection;","access$202",new String[]{ "Lorg/mortbay/jetty/HttpConnection;","I"},"I"));
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,1,7,new Field("Lorg/mortbay/jetty/HttpConnection$RequestHandler;","this$0","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1,5},new Method("Lorg/mortbay/jetty/HttpConnection;","access$402",new String[]{ "Lorg/mortbay/jetty/HttpConnection;","Z"},"Z"));
                code.visitLabel(L7);
                code.visitFieldStmt(IPUT_OBJECT,6,7,new Field("Lorg/mortbay/jetty/HttpConnection$RequestHandler;","_charset","Ljava/lang/String;"));
                code.visitLabel(L8);
                code.visitFieldStmt(IGET_OBJECT,1,7,new Field("Lorg/mortbay/jetty/HttpConnection$RequestHandler;","this$0","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitFieldStmt(IGET_OBJECT,1,1,new Field("Lorg/mortbay/jetty/HttpConnection;","_request","Lorg/mortbay/jetty/Request;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/jetty/Request;","getTimeStamp",new String[]{ },"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,1);
                code.visitConstStmt(CONST_WIDE_16,3,Long.valueOf(0L)); // long: 0x0000000000000000  double:0.000000
                code.visitStmt3R(CMP_LONG,1,1,3);
                code.visitJumpStmt(IF_NEZ,1,-1,L10);
                code.visitLabel(L9);
                code.visitFieldStmt(IGET_OBJECT,1,7,new Field("Lorg/mortbay/jetty/HttpConnection$RequestHandler;","this$0","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitFieldStmt(IGET_OBJECT,1,1,new Field("Lorg/mortbay/jetty/HttpConnection;","_request","Lorg/mortbay/jetty/Request;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Ljava/lang/System;","currentTimeMillis",new String[]{ },"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2,3},new Method("Lorg/mortbay/jetty/Request;","setTimeStamp",new String[]{ "J"},"V"));
                code.visitLabel(L10);
                code.visitFieldStmt(IGET_OBJECT,1,7,new Field("Lorg/mortbay/jetty/HttpConnection$RequestHandler;","this$0","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitFieldStmt(IGET_OBJECT,1,1,new Field("Lorg/mortbay/jetty/HttpConnection;","_request","Lorg/mortbay/jetty/Request;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Ljava/lang/Object;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Lorg/mortbay/jetty/Request;","setMethod",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,1,7,new Field("Lorg/mortbay/jetty/HttpConnection$RequestHandler;","this$0","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitFieldStmt(IGET_OBJECT,1,1,new Field("Lorg/mortbay/jetty/HttpConnection;","_uri","Lorg/mortbay/jetty/HttpURI;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 9},new Method("Lorg/mortbay/io/Buffer;","array",new String[]{ },"[B"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 9},new Method("Lorg/mortbay/io/Buffer;","getIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 9},new Method("Lorg/mortbay/io/Buffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2,3,4},new Method("Lorg/mortbay/jetty/HttpURI;","parse",new String[]{ "[B","I","I"},"V"));
                code.visitLabel(L11);
                code.visitFieldStmt(IGET_OBJECT,1,7,new Field("Lorg/mortbay/jetty/HttpConnection$RequestHandler;","this$0","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitFieldStmt(IGET_OBJECT,1,1,new Field("Lorg/mortbay/jetty/HttpConnection;","_request","Lorg/mortbay/jetty/Request;"));
                code.visitFieldStmt(IGET_OBJECT,2,7,new Field("Lorg/mortbay/jetty/HttpConnection$RequestHandler;","this$0","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitFieldStmt(IGET_OBJECT,2,2,new Field("Lorg/mortbay/jetty/HttpConnection;","_uri","Lorg/mortbay/jetty/HttpURI;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Lorg/mortbay/jetty/Request;","setUri",new String[]{ "Lorg/mortbay/jetty/HttpURI;"},"V"));
                code.visitLabel(L12);
                code.visitJumpStmt(IF_NEZ,10,-1,L17);
                code.visitLabel(L13);
                code.visitFieldStmt(IGET_OBJECT,1,7,new Field("Lorg/mortbay/jetty/HttpConnection$RequestHandler;","this$0","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitFieldStmt(IGET_OBJECT,1,1,new Field("Lorg/mortbay/jetty/HttpConnection;","_request","Lorg/mortbay/jetty/Request;"));
                code.visitConstStmt(CONST_STRING,2,"");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Lorg/mortbay/jetty/Request;","setProtocol",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L14);
                code.visitFieldStmt(IGET_OBJECT,1,7,new Field("Lorg/mortbay/jetty/HttpConnection$RequestHandler;","this$0","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitConstStmt(CONST_16,2, Integer.valueOf(9)); // int: 0x00000009  float:0.000000
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1,2},new Method("Lorg/mortbay/jetty/HttpConnection;","access$502",new String[]{ "Lorg/mortbay/jetty/HttpConnection;","I"},"I"));
                code.visitLabel(L15);
                code.visitFieldStmt(IGET_OBJECT,1,7,new Field("Lorg/mortbay/jetty/HttpConnection$RequestHandler;","this$0","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/jetty/HttpMethods;","HEAD_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitJumpStmt(IF_NE,8,2,L23);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                DexLabel L25=new DexLabel();
                code.visitLabel(L25);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1,2},new Method("Lorg/mortbay/jetty/HttpConnection;","access$602",new String[]{ "Lorg/mortbay/jetty/HttpConnection;","Z"},"Z"));
                code.visitLabel(L16);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L17);
                code.visitFieldStmt(SGET_OBJECT,1,-1,new Field("Lorg/mortbay/jetty/HttpVersions;","CACHE","Lorg/mortbay/io/BufferCache;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,10},new Method("Lorg/mortbay/io/BufferCache;","get",new String[]{ "Lorg/mortbay/io/Buffer;"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,10);
                code.visitLabel(L18);
                code.visitFieldStmt(IGET_OBJECT,1,7,new Field("Lorg/mortbay/jetty/HttpConnection$RequestHandler;","this$0","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/jetty/HttpVersions;","CACHE","Lorg/mortbay/io/BufferCache;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,10},new Method("Lorg/mortbay/io/BufferCache;","getOrdinal",new String[]{ "Lorg/mortbay/io/Buffer;"},"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1,2},new Method("Lorg/mortbay/jetty/HttpConnection;","access$502",new String[]{ "Lorg/mortbay/jetty/HttpConnection;","I"},"I"));
                code.visitLabel(L19);
                code.visitFieldStmt(IGET_OBJECT,1,7,new Field("Lorg/mortbay/jetty/HttpConnection$RequestHandler;","this$0","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1},new Method("Lorg/mortbay/jetty/HttpConnection;","access$500",new String[]{ "Lorg/mortbay/jetty/HttpConnection;"},"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_GTZ,1,-1,L21);
                code.visitLabel(L20);
                code.visitFieldStmt(IGET_OBJECT,1,7,new Field("Lorg/mortbay/jetty/HttpConnection$RequestHandler;","this$0","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitConstStmt(CONST_16,2, Integer.valueOf(10)); // int: 0x0000000a  float:0.000000
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1,2},new Method("Lorg/mortbay/jetty/HttpConnection;","access$502",new String[]{ "Lorg/mortbay/jetty/HttpConnection;","I"},"I"));
                code.visitLabel(L21);
                code.visitFieldStmt(IGET_OBJECT,1,7,new Field("Lorg/mortbay/jetty/HttpConnection$RequestHandler;","this$0","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitFieldStmt(IGET_OBJECT,1,1,new Field("Lorg/mortbay/jetty/HttpConnection;","_request","Lorg/mortbay/jetty/Request;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Ljava/lang/Object;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Lorg/mortbay/jetty/Request;","setProtocol",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L1);
                code.visitJumpStmt(GOTO,-1,-1,L15);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitStmt2R(MOVE_OBJECT,0,1);
                code.visitLabel(L22);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Lorg/mortbay/jetty/HttpException;");
                code.visitConstStmt(CONST_16,2, Integer.valueOf(400)); // int: 0x00000190  float:0.000000
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,2,6,0},new Method("Lorg/mortbay/jetty/HttpException;","<init>",new String[]{ "I","Ljava/lang/String;","Ljava/lang/Throwable;"},"V"));
                code.visitStmt1R(THROW,1);
                code.visitLabel(L23);
                code.visitStmt2R(MOVE,2,5);
                code.visitLabel(L24);
                code.visitJumpStmt(GOTO,-1,-1,L25);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m007_startResponse(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpConnection$RequestHandler;","startResponse",new String[]{ "Lorg/mortbay/io/Buffer;","I","Lorg/mortbay/io/Buffer;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"version");
                ddv.visitParameterName(1,"status");
                ddv.visitParameterName(2,"reason");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(907,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(908,L2);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_STRING,2," ");
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,1,"Bad request!: ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitConstStmt(CONST_STRING,1," ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "I"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitConstStmt(CONST_STRING,1," ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,6},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
