package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0348_org_mortbay_jetty_servlet_ServletHolder_SingleThreadedWrapper {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(0,"Lorg/mortbay/jetty/servlet/ServletHolder$SingleThreadedWrapper;","Ljava/lang/Object;",new String[]{ "Ljavax/servlet/Servlet;"});
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("ServletHolder.java");
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/EnclosingClass;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("value", new DexType("Lorg/mortbay/jetty/servlet/ServletHolder;"));
                av00.visitEnd();
            }
        }
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/InnerClass;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("accessFlags",  Integer.valueOf(2));
                av00.visit("name", "SingleThreadedWrapper");
                av00.visitEnd();
            }
        }
        f000__stack(cv);
        f001_this$0(cv);
        m000__init_(cv);
        m001__init_(cv);
        m002_destroy(cv);
        m003_getServletConfig(cv);
        m004_getServletInfo(cv);
        m005_init(cv);
        m006_service(cv);
    }
    public static void f000__stack(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/jetty/servlet/ServletHolder$SingleThreadedWrapper;","_stack","Ljava/util/Stack;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001_this$0(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_FINAL|ACC_SYNTHETIC, new Field("Lorg/mortbay/jetty/servlet/ServletHolder$SingleThreadedWrapper;","this$0","Lorg/mortbay/jetty/servlet/ServletHolder;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PRIVATE|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/servlet/ServletHolder$SingleThreadedWrapper;","<init>",new String[]{ "Lorg/mortbay/jetty/servlet/ServletHolder;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(559,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(561,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,2,1,new Field("Lorg/mortbay/jetty/servlet/ServletHolder$SingleThreadedWrapper;","this$0","Lorg/mortbay/jetty/servlet/ServletHolder;"));
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljava/lang/Object;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/util/Stack;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/util/Stack;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/servlet/ServletHolder$SingleThreadedWrapper;","_stack","Ljava/util/Stack;"));
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_SYNTHETIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/servlet/ServletHolder$SingleThreadedWrapper;","<init>",new String[]{ "Lorg/mortbay/jetty/servlet/ServletHolder;","Lorg/mortbay/jetty/servlet/ServletHolder$1;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"x0");
                ddv.visitParameterName(1,"x1");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(559,L0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/servlet/ServletHolder$SingleThreadedWrapper;","<init>",new String[]{ "Lorg/mortbay/jetty/servlet/ServletHolder;"},"V"));
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_destroy(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/ServletHolder$SingleThreadedWrapper;","destroy",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                DexLabel L5=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L5,L2},new String[]{ "Ljava/lang/Exception;",null});
                DexLabel L6=new DexLabel();
                DexLabel L7=new DexLabel();
                code.visitTryCatch(L6,L7,new DexLabel[]{L2},new String[]{ null});
                DexLabel L8=new DexLabel();
                DexLabel L9=new DexLabel();
                code.visitTryCatch(L8,L9,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L10=new DexLabel();
                ddv.visitPrologue(L10);
                ddv.visitLineNumber(565,L10);
                ddv.visitLineNumber(567,L0);
                ddv.visitLineNumber(568,L3);
                ddv.visitStartLocal(0,L6,"e","Ljava/lang/Exception;",null);
                ddv.visitLineNumber(569,L2);
                ddv.visitEndLocal(0,L2);
                ddv.visitLineNumber(570,L9);
                code.visitLabel(L10);
                code.visitStmt1R(MONITOR_ENTER,2);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/servlet/ServletHolder$SingleThreadedWrapper;","_stack","Ljava/util/Stack;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/util/Stack;","size",new String[]{ },"I"));
                code.visitLabel(L1);
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_LEZ,1,-1,L8);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/servlet/ServletHolder$SingleThreadedWrapper;","_stack","Ljava/util/Stack;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/util/Stack;","pop",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitTypeStmt(CHECK_CAST,1,-1,"Ljavax/servlet/Servlet;");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Ljavax/servlet/Servlet;","destroy",new String[]{ },"V"));
                code.visitLabel(L4);
                code.visitJumpStmt(GOTO,-1,-1,L0);
                code.visitLabel(L5);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitStmt2R(MOVE_OBJECT,0,1);
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/log/Log;","warn",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L0);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitStmt1R(MONITOR_EXIT,2);
                code.visitLabel(L7);
                code.visitStmt1R(THROW,1);
                code.visitLabel(L8);
                code.visitStmt1R(MONITOR_EXIT,2);
                code.visitLabel(L9);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_getServletConfig(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/ServletHolder$SingleThreadedWrapper;","getServletConfig",new String[]{ },"Ljavax/servlet/ServletConfig;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(574,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/servlet/ServletHolder$SingleThreadedWrapper;","this$0","Lorg/mortbay/jetty/servlet/ServletHolder;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/jetty/servlet/ServletHolder;","access$100",new String[]{ "Lorg/mortbay/jetty/servlet/ServletHolder;"},"Lorg/mortbay/jetty/servlet/ServletHolder$Config;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_getServletInfo(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/ServletHolder$SingleThreadedWrapper;","getServletInfo",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(579,L0);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_init(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/ServletHolder$SingleThreadedWrapper;","init",new String[]{ "Ljavax/servlet/ServletConfig;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljavax/servlet/ServletException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                DexLabel L5=new DexLabel();
                DexLabel L6=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L5,L6,L2},new String[]{ "Ljavax/servlet/ServletException;","Ljava/lang/Exception;",null});
                DexLabel L7=new DexLabel();
                code.visitTryCatch(L4,L7,new DexLabel[]{L2},new String[]{ null});
                DexLabel L8=new DexLabel();
                DexLabel L9=new DexLabel();
                code.visitTryCatch(L8,L9,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"config");
                DexLabel L10=new DexLabel();
                ddv.visitPrologue(L10);
                ddv.visitLineNumber(584,L10);
                ddv.visitLineNumber(586,L0);
                ddv.visitLineNumber(590,L3);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(591,L11);
                ddv.visitStartLocal(1,L11,"s","Ljavax/servlet/Servlet;",null);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(592,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(593,L13);
                ddv.visitLineNumber(604,L4);
                ddv.visitEndLocal(1,L4);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(605,L14);
                ddv.visitLineNumber(595,L5);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(597,L15);
                ddv.visitStartLocal(0,L15,"e","Ljavax/servlet/ServletException;",null);
                ddv.visitLineNumber(604,L2);
                ddv.visitEndLocal(0,L2);
                ddv.visitLineNumber(599,L6);
                ddv.visitLineNumber(601,L8);
                ddv.visitStartLocal(0,L8,"e","Ljava/lang/Exception;",null);
                code.visitLabel(L10);
                code.visitStmt1R(MONITOR_ENTER,3);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,2,3,new Field("Lorg/mortbay/jetty/servlet/ServletHolder$SingleThreadedWrapper;","_stack","Ljava/util/Stack;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/util/Stack;","size",new String[]{ },"I"));
                code.visitLabel(L1);
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_NEZ,2,-1,L4);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,2,3,new Field("Lorg/mortbay/jetty/servlet/ServletHolder$SingleThreadedWrapper;","this$0","Lorg/mortbay/jetty/servlet/ServletHolder;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/servlet/ServletHolder;","newInstance",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitTypeStmt(CHECK_CAST,1,-1,"Ljavax/servlet/Servlet;");
                code.visitLabel(L11);
                code.visitFieldStmt(IGET_OBJECT,2,3,new Field("Lorg/mortbay/jetty/servlet/ServletHolder$SingleThreadedWrapper;","this$0","Lorg/mortbay/jetty/servlet/ServletHolder;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/servlet/ServletHolder;","getServletHandler",new String[]{ },"Lorg/mortbay/jetty/servlet/ServletHandler;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,1},new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","customizeServlet",new String[]{ "Ljavax/servlet/Servlet;"},"Ljavax/servlet/Servlet;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L12);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1,4},new Method("Ljavax/servlet/Servlet;","init",new String[]{ "Ljavax/servlet/ServletConfig;"},"V"));
                code.visitLabel(L13);
                code.visitFieldStmt(IGET_OBJECT,2,3,new Field("Lorg/mortbay/jetty/servlet/ServletHolder$SingleThreadedWrapper;","_stack","Ljava/util/Stack;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,1},new Method("Ljava/util/Stack;","push",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L4);
                code.visitStmt1R(MONITOR_EXIT,3);
                code.visitLabel(L14);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L5);
                code.visitStmt1R(MOVE_EXCEPTION,2);
                code.visitStmt2R(MOVE_OBJECT,0,2);
                code.visitLabel(L15);
                code.visitStmt1R(THROW,0);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,2);
                code.visitStmt1R(MONITOR_EXIT,3);
                code.visitLabel(L7);
                code.visitStmt1R(THROW,2);
                code.visitLabel(L6);
                code.visitStmt1R(MOVE_EXCEPTION,2);
                code.visitStmt2R(MOVE_OBJECT,0,2);
                code.visitLabel(L8);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Ljavax/servlet/ServletException;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2,0},new Method("Ljavax/servlet/ServletException;","<init>",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitStmt1R(THROW,2);
                code.visitLabel(L9);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_service(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/ServletHolder$SingleThreadedWrapper;","service",new String[]{ "Ljavax/servlet/ServletRequest;","Ljavax/servlet/ServletResponse;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljavax/servlet/ServletException;"));
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                code.visitTryCatch(L1,L3,new DexLabel[]{L4},new String[]{ null});
                DexLabel L5=new DexLabel();
                DexLabel L6=new DexLabel();
                DexLabel L7=new DexLabel();
                code.visitTryCatch(L5,L6,new DexLabel[]{L7},new String[]{ null});
                DexLabel L8=new DexLabel();
                DexLabel L9=new DexLabel();
                DexLabel L10=new DexLabel();
                DexLabel L11=new DexLabel();
                DexLabel L12=new DexLabel();
                code.visitTryCatch(L8,L9,new DexLabel[]{L10,L11,L12,L2},new String[]{ "Ljavax/servlet/ServletException;","Ljava/io/IOException;","Ljava/lang/Exception;",null});
                DexLabel L13=new DexLabel();
                DexLabel L14=new DexLabel();
                code.visitTryCatch(L13,L14,new DexLabel[]{L2},new String[]{ null});
                DexLabel L15=new DexLabel();
                code.visitTryCatch(L15,L4,new DexLabel[]{L2},new String[]{ null});
                DexLabel L16=new DexLabel();
                DexLabel L17=new DexLabel();
                DexLabel L18=new DexLabel();
                code.visitTryCatch(L16,L17,new DexLabel[]{L18},new String[]{ null});
                DexLabel L19=new DexLabel();
                DexLabel L20=new DexLabel();
                code.visitTryCatch(L19,L20,new DexLabel[]{L18},new String[]{ null});
                DexLabel L21=new DexLabel();
                DexLabel L22=new DexLabel();
                code.visitTryCatch(L21,L22,new DexLabel[]{L7},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"req");
                ddv.visitParameterName(1,"res");
                DexLabel L23=new DexLabel();
                ddv.visitPrologue(L23);
                ddv.visitLineNumber(610,L23);
                ddv.visitLineNumber(612,L0);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(613,L24);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(635,L25);
                ddv.visitStartLocal(1,L25,"s","Ljavax/servlet/Servlet;",null);
                ddv.visitLineNumber(639,L1);
                ddv.visitLineNumber(643,L3);
                ddv.visitLineNumber(645,L5);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(646,L26);
                ddv.visitLineNumber(648,L6);
                ddv.visitLineNumber(618,L8);
                ddv.visitEndLocal(1,L8);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(619,L27);
                ddv.visitRestartLocal(1,L27);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(620,L28);
                ddv.visitRestartLocal(1,L28);
                ddv.visitLineNumber(622,L10);
                ddv.visitEndLocal(1,L10);
                ddv.visitLineNumber(624,L13);
                ddv.visitStartLocal(0,L13,"e","Ljavax/servlet/ServletException;",null);
                ddv.visitLineNumber(635,L2);
                ddv.visitEndLocal(0,L2);
                ddv.visitLineNumber(626,L11);
                ddv.visitLineNumber(628,L15);
                ddv.visitStartLocal(0,L15,"e","Ljava/io/IOException;",null);
                ddv.visitLineNumber(630,L12);
                ddv.visitEndLocal(0,L12);
                DexLabel L29=new DexLabel();
                ddv.visitLineNumber(632,L29);
                ddv.visitStartLocal(0,L29,"e","Ljava/lang/Exception;",null);
                ddv.visitLineNumber(643,L4);
                ddv.visitEndLocal(0,L4);
                ddv.visitRestartLocal(1,L4);
                ddv.visitLineNumber(645,L16);
                DexLabel L30=new DexLabel();
                ddv.visitLineNumber(646,L30);
                ddv.visitLineNumber(643,L17);
                ddv.visitLineNumber(646,L18);
                code.visitLabel(L23);
                code.visitStmt1R(MONITOR_ENTER,4);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,2,4,new Field("Lorg/mortbay/jetty/servlet/ServletHolder$SingleThreadedWrapper;","_stack","Ljava/util/Stack;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/util/Stack;","size",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_LEZ,2,-1,L8);
                code.visitLabel(L24);
                code.visitFieldStmt(IGET_OBJECT,2,4,new Field("Lorg/mortbay/jetty/servlet/ServletHolder$SingleThreadedWrapper;","_stack","Ljava/util/Stack;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/util/Stack;","pop",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitTypeStmt(CHECK_CAST,1,-1,"Ljavax/servlet/Servlet;");
                code.visitLabel(L25);
                code.visitStmt1R(MONITOR_EXIT,4);
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1,5,6},new Method("Ljavax/servlet/Servlet;","service",new String[]{ "Ljavax/servlet/ServletRequest;","Ljavax/servlet/ServletResponse;"},"V"));
                code.visitLabel(L3);
                code.visitStmt1R(MONITOR_ENTER,4);
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,2,4,new Field("Lorg/mortbay/jetty/servlet/ServletHolder$SingleThreadedWrapper;","_stack","Ljava/util/Stack;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,1},new Method("Ljava/util/Stack;","push",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L26);
                code.visitStmt1R(MONITOR_EXIT,4);
                code.visitLabel(L6);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L8);
                code.visitFieldStmt(IGET_OBJECT,2,4,new Field("Lorg/mortbay/jetty/servlet/ServletHolder$SingleThreadedWrapper;","this$0","Lorg/mortbay/jetty/servlet/ServletHolder;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/servlet/ServletHolder;","newInstance",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitTypeStmt(CHECK_CAST,1,-1,"Ljavax/servlet/Servlet;");
                code.visitLabel(L27);
                code.visitFieldStmt(IGET_OBJECT,2,4,new Field("Lorg/mortbay/jetty/servlet/ServletHolder$SingleThreadedWrapper;","this$0","Lorg/mortbay/jetty/servlet/ServletHolder;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/servlet/ServletHolder;","getServletHandler",new String[]{ },"Lorg/mortbay/jetty/servlet/ServletHandler;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,1},new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","customizeServlet",new String[]{ "Ljavax/servlet/Servlet;"},"Ljavax/servlet/Servlet;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L28);
                code.visitFieldStmt(IGET_OBJECT,2,4,new Field("Lorg/mortbay/jetty/servlet/ServletHolder$SingleThreadedWrapper;","this$0","Lorg/mortbay/jetty/servlet/ServletHolder;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2},new Method("Lorg/mortbay/jetty/servlet/ServletHolder;","access$100",new String[]{ "Lorg/mortbay/jetty/servlet/ServletHolder;"},"Lorg/mortbay/jetty/servlet/ServletHolder$Config;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1,2},new Method("Ljavax/servlet/Servlet;","init",new String[]{ "Ljavax/servlet/ServletConfig;"},"V"));
                code.visitLabel(L9);
                code.visitJumpStmt(GOTO,-1,-1,L25);
                code.visitLabel(L10);
                code.visitStmt1R(MOVE_EXCEPTION,2);
                code.visitStmt2R(MOVE_OBJECT,0,2);
                code.visitLabel(L13);
                code.visitStmt1R(THROW,0);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,2);
                code.visitStmt1R(MONITOR_EXIT,4);
                code.visitLabel(L14);
                code.visitStmt1R(THROW,2);
                code.visitLabel(L11);
                code.visitStmt1R(MOVE_EXCEPTION,2);
                code.visitStmt2R(MOVE_OBJECT,0,2);
                code.visitLabel(L15);
                code.visitStmt1R(THROW,0);
                code.visitLabel(L12);
                code.visitStmt1R(MOVE_EXCEPTION,2);
                code.visitStmt2R(MOVE_OBJECT,0,2);
                code.visitLabel(L29);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Ljavax/servlet/ServletException;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2,0},new Method("Ljavax/servlet/ServletException;","<init>",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitStmt1R(THROW,2);
                code.visitLabel(L4);
                code.visitStmt1R(MOVE_EXCEPTION,2);
                code.visitStmt1R(MONITOR_ENTER,4);
                code.visitLabel(L16);
                code.visitFieldStmt(IGET_OBJECT,3,4,new Field("Lorg/mortbay/jetty/servlet/ServletHolder$SingleThreadedWrapper;","_stack","Ljava/util/Stack;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,1},new Method("Ljava/util/Stack;","push",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L30);
                code.visitStmt1R(MONITOR_EXIT,4);
                code.visitLabel(L17);
                code.visitStmt1R(THROW,2);
                code.visitLabel(L18);
                code.visitStmt1R(MOVE_EXCEPTION,2);
                code.visitLabel(L19);
                code.visitStmt1R(MONITOR_EXIT,4);
                code.visitLabel(L20);
                code.visitStmt1R(THROW,2);
                code.visitLabel(L7);
                code.visitStmt1R(MOVE_EXCEPTION,2);
                code.visitLabel(L21);
                code.visitStmt1R(MONITOR_EXIT,4);
                code.visitLabel(L22);
                code.visitStmt1R(THROW,2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
