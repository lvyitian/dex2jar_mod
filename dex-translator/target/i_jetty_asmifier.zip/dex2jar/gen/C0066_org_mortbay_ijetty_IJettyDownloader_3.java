package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0066_org_mortbay_ijetty_IJettyDownloader_3 {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(0,"Lorg/mortbay/ijetty/IJettyDownloader$3;","Ljava/lang/Object;",new String[]{ "Landroid/content/DialogInterface$OnClickListener;"});
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("IJettyDownloader.java");
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/EnclosingMethod;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("value", new Method("Lorg/mortbay/ijetty/IJettyDownloader;","startDownload",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"V"));
                av00.visitEnd();
            }
        }
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/InnerClass;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("accessFlags",  Integer.valueOf(0));
                av00.visit("name", null);
                av00.visitEnd();
            }
        }
        f000_this$0(cv);
        f001_val$path(cv);
        f002_val$url(cv);
        f003_val$warFile(cv);
        m000__init_(cv);
        m001_onClick(cv);
    }
    public static void f000_this$0(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_FINAL|ACC_SYNTHETIC, new Field("Lorg/mortbay/ijetty/IJettyDownloader$3;","this$0","Lorg/mortbay/ijetty/IJettyDownloader;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001_val$path(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_FINAL|ACC_SYNTHETIC, new Field("Lorg/mortbay/ijetty/IJettyDownloader$3;","val$path","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002_val$url(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_FINAL|ACC_SYNTHETIC, new Field("Lorg/mortbay/ijetty/IJettyDownloader$3;","val$url","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003_val$warFile(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_FINAL|ACC_SYNTHETIC, new Field("Lorg/mortbay/ijetty/IJettyDownloader$3;","val$warFile","Ljava/io/File;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_CONSTRUCTOR, new Method("Lorg/mortbay/ijetty/IJettyDownloader$3;","<init>",new String[]{ "Lorg/mortbay/ijetty/IJettyDownloader;","Ljava/io/File;","Ljava/lang/String;","Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(241,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/ijetty/IJettyDownloader$3;","this$0","Lorg/mortbay/ijetty/IJettyDownloader;"));
                code.visitFieldStmt(IPUT_OBJECT,2,0,new Field("Lorg/mortbay/ijetty/IJettyDownloader$3;","val$warFile","Ljava/io/File;"));
                code.visitFieldStmt(IPUT_OBJECT,3,0,new Field("Lorg/mortbay/ijetty/IJettyDownloader$3;","val$url","Ljava/lang/String;"));
                code.visitFieldStmt(IPUT_OBJECT,4,0,new Field("Lorg/mortbay/ijetty/IJettyDownloader$3;","val$path","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/Object;","<init>",new String[]{ },"V"));
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001_onClick(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/ijetty/IJettyDownloader$3;","onClick",new String[]{ "Landroid/content/DialogInterface;","I"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"arg0");
                ddv.visitParameterName(1,"arg1");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(243,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(244,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(245,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/ijetty/IJettyDownloader$3;","val$warFile","Ljava/io/File;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/ijetty/Installer;","clean",new String[]{ "Ljava/io/File;"},"V"));
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/ijetty/IJettyDownloader$3;","this$0","Lorg/mortbay/ijetty/IJettyDownloader;"));
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/ijetty/IJettyDownloader$3;","val$url","Ljava/lang/String;"));
                code.visitFieldStmt(IGET_OBJECT,2,4,new Field("Lorg/mortbay/ijetty/IJettyDownloader$3;","val$warFile","Ljava/io/File;"));
                code.visitFieldStmt(IGET_OBJECT,3,4,new Field("Lorg/mortbay/ijetty/IJettyDownloader$3;","val$path","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2,3},new Method("Lorg/mortbay/ijetty/IJettyDownloader;","doDownload",new String[]{ "Ljava/lang/String;","Ljava/io/File;","Ljava/lang/String;"},"V"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
