package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0141_org_mortbay_jetty_AbstractGenerator_Output {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/jetty/AbstractGenerator$Output;","Ljavax/servlet/ServletOutputStream;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("AbstractGenerator.java");
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/EnclosingClass;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("value", new DexType("Lorg/mortbay/jetty/AbstractGenerator;"));
                av00.visitEnd();
            }
        }
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/InnerClass;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("accessFlags",  Integer.valueOf(9));
                av00.visit("name", "Output");
                av00.visitEnd();
            }
        }
        f000__buf(cv);
        f001__bytes(cv);
        f002__characterEncoding(cv);
        f003__chars(cv);
        f004__closed(cv);
        f005__converter(cv);
        f006__generator(cv);
        f007__maxIdleTime(cv);
        m000__init_(cv);
        m001_write(cv);
        m002_blockForOutput(cv);
        m003_close(cv);
        m004_flush(cv);
        m005_print(cv);
        m006_reopen(cv);
        m007_write(cv);
        m008_write(cv);
        m009_write(cv);
    }
    public static void f000__buf(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/jetty/AbstractGenerator$Output;","_buf","Lorg/mortbay/io/ByteArrayBuffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001__bytes(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/jetty/AbstractGenerator$Output;","_bytes","Lorg/mortbay/util/ByteArrayOutputStream2;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002__characterEncoding(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/jetty/AbstractGenerator$Output;","_characterEncoding","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003__chars(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/jetty/AbstractGenerator$Output;","_chars","[C"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f004__closed(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/jetty/AbstractGenerator$Output;","_closed","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f005__converter(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/jetty/AbstractGenerator$Output;","_converter","Ljava/io/Writer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f006__generator(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/jetty/AbstractGenerator$Output;","_generator","Lorg/mortbay/jetty/AbstractGenerator;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f007__maxIdleTime(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/jetty/AbstractGenerator$Output;","_maxIdleTime","J"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/AbstractGenerator$Output;","<init>",new String[]{ "Lorg/mortbay/jetty/AbstractGenerator;","J"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"generator");
                ddv.visitParameterName(1,"maxIdleTime");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(513,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(501,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(514,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(515,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(516,L4);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2},new Method("Ljavax/servlet/ServletOutputStream;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/io/ByteArrayBuffer;");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/jetty/AbstractGenerator;","access$000",new String[]{ },"[B"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Lorg/mortbay/io/ByteArrayBuffer;","<init>",new String[]{ "[B"},"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/jetty/AbstractGenerator$Output;","_buf","Lorg/mortbay/io/ByteArrayBuffer;"));
                code.visitLabel(L2);
                code.visitFieldStmt(IPUT_OBJECT,3,2,new Field("Lorg/mortbay/jetty/AbstractGenerator$Output;","_generator","Lorg/mortbay/jetty/AbstractGenerator;"));
                code.visitLabel(L3);
                code.visitFieldStmt(IPUT_WIDE,4,2,new Field("Lorg/mortbay/jetty/AbstractGenerator$Output;","_maxIdleTime","J"));
                code.visitLabel(L4);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001_write(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PRIVATE, new Method("Lorg/mortbay/jetty/AbstractGenerator$Output;","write",new String[]{ "Lorg/mortbay/io/Buffer;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"buffer");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(628,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(629,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(630,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(631,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(634,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(636,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(637,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(638,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(639,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(640,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(644,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(647,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(648,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(650,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(652,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(653,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(657,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(658,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(659,L19);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_STRING,2,"Closed");
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_BOOLEAN,0,3,new Field("Lorg/mortbay/jetty/AbstractGenerator$Output;","_closed","Z"));
                code.visitJumpStmt(IF_EQZ,0,-1,L3);
                code.visitLabel(L2);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/io/IOException;");
                code.visitConstStmt(CONST_STRING,1,"Closed");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,2},new Method("Ljava/io/IOException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,0);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/jetty/AbstractGenerator$Output;","_generator","Lorg/mortbay/jetty/AbstractGenerator;"));
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/AbstractGenerator;","_endp","Lorg/mortbay/io/EndPoint;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Lorg/mortbay/io/EndPoint;","isOpen",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_NEZ,0,-1,L5);
                code.visitLabel(L4);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/jetty/EofException;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Lorg/mortbay/jetty/EofException;","<init>",new String[]{ },"V"));
                code.visitStmt1R(THROW,0);
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/jetty/AbstractGenerator$Output;","_generator","Lorg/mortbay/jetty/AbstractGenerator;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/AbstractGenerator;","isBufferFull",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L11);
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/jetty/AbstractGenerator$Output;","blockForOutput",new String[]{ },"V"));
                code.visitLabel(L7);
                code.visitFieldStmt(IGET_BOOLEAN,0,3,new Field("Lorg/mortbay/jetty/AbstractGenerator$Output;","_closed","Z"));
                code.visitJumpStmt(IF_EQZ,0,-1,L9);
                code.visitLabel(L8);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/io/IOException;");
                code.visitConstStmt(CONST_STRING,1,"Closed");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,2},new Method("Ljava/io/IOException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,0);
                code.visitLabel(L9);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/jetty/AbstractGenerator$Output;","_generator","Lorg/mortbay/jetty/AbstractGenerator;"));
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/AbstractGenerator;","_endp","Lorg/mortbay/io/EndPoint;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Lorg/mortbay/io/EndPoint;","isOpen",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_NEZ,0,-1,L5);
                code.visitLabel(L10);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/jetty/EofException;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Lorg/mortbay/jetty/EofException;","<init>",new String[]{ },"V"));
                code.visitStmt1R(THROW,0);
                code.visitLabel(L11);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/jetty/AbstractGenerator$Output;","_generator","Lorg/mortbay/jetty/AbstractGenerator;"));
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,4,1},new Method("Lorg/mortbay/jetty/AbstractGenerator;","addContent",new String[]{ "Lorg/mortbay/io/Buffer;","Z"},"V"));
                code.visitLabel(L12);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/jetty/AbstractGenerator$Output;","_generator","Lorg/mortbay/jetty/AbstractGenerator;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/AbstractGenerator;","isBufferFull",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L14);
                code.visitLabel(L13);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/jetty/AbstractGenerator$Output;","flush",new String[]{ },"V"));
                code.visitLabel(L14);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/jetty/AbstractGenerator$Output;","_generator","Lorg/mortbay/jetty/AbstractGenerator;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/AbstractGenerator;","isContentWritten",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L17);
                code.visitLabel(L15);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/jetty/AbstractGenerator$Output;","flush",new String[]{ },"V"));
                code.visitLabel(L16);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/jetty/AbstractGenerator$Output;","close",new String[]{ },"V"));
                code.visitLabel(L17);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 4},new Method("Lorg/mortbay/io/Buffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_LEZ,0,-1,L19);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/jetty/AbstractGenerator$Output;","_generator","Lorg/mortbay/jetty/AbstractGenerator;"));
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/AbstractGenerator;","_endp","Lorg/mortbay/io/EndPoint;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Lorg/mortbay/io/EndPoint;","isOpen",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L19);
                code.visitLabel(L18);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/jetty/AbstractGenerator$Output;","blockForOutput",new String[]{ },"V"));
                code.visitJumpStmt(GOTO,-1,-1,L17);
                code.visitLabel(L19);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_blockForOutput(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(0, new Method("Lorg/mortbay/jetty/AbstractGenerator$Output;","blockForOutput",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/io/IOException;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(530,L3);
                ddv.visitLineNumber(534,L0);
                ddv.visitLineNumber(552,L1);
                ddv.visitLineNumber(536,L2);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(538,L4);
                ddv.visitStartLocal(0,L4,"e","Ljava/io/IOException;",null);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(539,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(544,L6);
                ddv.visitEndLocal(0,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(546,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(547,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(550,L9);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/jetty/AbstractGenerator$Output;","_generator","Lorg/mortbay/jetty/AbstractGenerator;"));
                code.visitFieldStmt(IGET_OBJECT,1,1,new Field("Lorg/mortbay/jetty/AbstractGenerator;","_endp","Lorg/mortbay/io/EndPoint;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Lorg/mortbay/io/EndPoint;","isBlocking",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_EQZ,1,-1,L6);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/jetty/AbstractGenerator$Output;","flush",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,0);
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/jetty/AbstractGenerator$Output;","_generator","Lorg/mortbay/jetty/AbstractGenerator;"));
                code.visitFieldStmt(IGET_OBJECT,1,1,new Field("Lorg/mortbay/jetty/AbstractGenerator;","_endp","Lorg/mortbay/io/EndPoint;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Lorg/mortbay/io/EndPoint;","close",new String[]{ },"V"));
                code.visitLabel(L5);
                code.visitStmt1R(THROW,0);
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/jetty/AbstractGenerator$Output;","_generator","Lorg/mortbay/jetty/AbstractGenerator;"));
                code.visitFieldStmt(IGET_OBJECT,1,1,new Field("Lorg/mortbay/jetty/AbstractGenerator;","_endp","Lorg/mortbay/io/EndPoint;"));
                code.visitFieldStmt(IGET_WIDE,2,4,new Field("Lorg/mortbay/jetty/AbstractGenerator$Output;","_maxIdleTime","J"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1,2,3},new Method("Lorg/mortbay/io/EndPoint;","blockWritable",new String[]{ "J"},"Z"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_NEZ,1,-1,L9);
                code.visitLabel(L7);
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/jetty/AbstractGenerator$Output;","_generator","Lorg/mortbay/jetty/AbstractGenerator;"));
                code.visitFieldStmt(IGET_OBJECT,1,1,new Field("Lorg/mortbay/jetty/AbstractGenerator;","_endp","Lorg/mortbay/io/EndPoint;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Lorg/mortbay/io/EndPoint;","close",new String[]{ },"V"));
                code.visitLabel(L8);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Lorg/mortbay/jetty/EofException;");
                code.visitConstStmt(CONST_STRING,2,"timeout");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,2},new Method("Lorg/mortbay/jetty/EofException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,1);
                code.visitLabel(L9);
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/jetty/AbstractGenerator$Output;","_generator","Lorg/mortbay/jetty/AbstractGenerator;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/jetty/AbstractGenerator;","flush",new String[]{ },"J"));
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_close(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/AbstractGenerator$Output;","close",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(524,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(525,L1);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitFieldStmt(IPUT_BOOLEAN,0,1,new Field("Lorg/mortbay/jetty/AbstractGenerator$Output;","_closed","Z"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_flush(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/AbstractGenerator$Output;","flush",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(564,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(565,L1);
                ddv.visitStartLocal(1,L1,"content","Lorg/mortbay/io/Buffer;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(566,L2);
                ddv.visitStartLocal(0,L2,"buffer","Lorg/mortbay/io/Buffer;",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(568,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(570,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(571,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(573,L6);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,2,3,new Field("Lorg/mortbay/jetty/AbstractGenerator$Output;","_generator","Lorg/mortbay/jetty/AbstractGenerator;"));
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/AbstractGenerator;","_content","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,2,3,new Field("Lorg/mortbay/jetty/AbstractGenerator$Output;","_generator","Lorg/mortbay/jetty/AbstractGenerator;"));
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/AbstractGenerator;","_buffer","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L2);
                DexLabel L7=new DexLabel();
                code.visitJumpStmt(IF_EQZ,1,-1,L7);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Lorg/mortbay/io/Buffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_GTZ,2,-1,L3);
                code.visitLabel(L7);
                DexLabel L8=new DexLabel();
                code.visitJumpStmt(IF_EQZ,0,-1,L8);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Lorg/mortbay/io/Buffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_GTZ,2,-1,L3);
                code.visitLabel(L8);
                code.visitFieldStmt(IGET_OBJECT,2,3,new Field("Lorg/mortbay/jetty/AbstractGenerator$Output;","_generator","Lorg/mortbay/jetty/AbstractGenerator;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/AbstractGenerator;","isBufferFull",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_EQZ,2,-1,L6);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,2,3,new Field("Lorg/mortbay/jetty/AbstractGenerator$Output;","_generator","Lorg/mortbay/jetty/AbstractGenerator;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/AbstractGenerator;","flush",new String[]{ },"J"));
                code.visitLabel(L4);
                DexLabel L9=new DexLabel();
                code.visitJumpStmt(IF_EQZ,1,-1,L9);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Lorg/mortbay/io/Buffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                DexLabel L10=new DexLabel();
                code.visitJumpStmt(IF_GTZ,2,-1,L10);
                code.visitLabel(L9);
                code.visitJumpStmt(IF_EQZ,0,-1,L6);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Lorg/mortbay/io/Buffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_LEZ,2,-1,L6);
                code.visitLabel(L10);
                code.visitFieldStmt(IGET_OBJECT,2,3,new Field("Lorg/mortbay/jetty/AbstractGenerator$Output;","_generator","Lorg/mortbay/jetty/AbstractGenerator;"));
                code.visitFieldStmt(IGET_OBJECT,2,2,new Field("Lorg/mortbay/jetty/AbstractGenerator;","_endp","Lorg/mortbay/io/EndPoint;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2},new Method("Lorg/mortbay/io/EndPoint;","isOpen",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_EQZ,2,-1,L6);
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/jetty/AbstractGenerator$Output;","blockForOutput",new String[]{ },"V"));
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitLabel(L6);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_print(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/AbstractGenerator$Output;","print",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"s");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(667,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(668,L1);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/lang/String;","getBytes",new String[]{ },"[B"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,0},new Method("Lorg/mortbay/jetty/AbstractGenerator$Output;","write",new String[]{ "[B"},"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_reopen(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(0, new Method("Lorg/mortbay/jetty/AbstractGenerator$Output;","reopen",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(557,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(558,L1);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_BOOLEAN,0,1,new Field("Lorg/mortbay/jetty/AbstractGenerator$Output;","_closed","Z"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m007_write(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/AbstractGenerator$Output;","write",new String[]{ "I"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"b");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(598,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(599,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(600,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(601,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(604,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(606,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(607,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(608,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(609,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(610,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(614,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(616,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(618,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(620,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(621,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(623,L16);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_STRING,2,"Closed");
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_BOOLEAN,0,3,new Field("Lorg/mortbay/jetty/AbstractGenerator$Output;","_closed","Z"));
                code.visitJumpStmt(IF_EQZ,0,-1,L3);
                code.visitLabel(L2);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/io/IOException;");
                code.visitConstStmt(CONST_STRING,1,"Closed");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,2},new Method("Ljava/io/IOException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,0);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/jetty/AbstractGenerator$Output;","_generator","Lorg/mortbay/jetty/AbstractGenerator;"));
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/AbstractGenerator;","_endp","Lorg/mortbay/io/EndPoint;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Lorg/mortbay/io/EndPoint;","isOpen",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_NEZ,0,-1,L5);
                code.visitLabel(L4);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/jetty/EofException;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Lorg/mortbay/jetty/EofException;","<init>",new String[]{ },"V"));
                code.visitStmt1R(THROW,0);
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/jetty/AbstractGenerator$Output;","_generator","Lorg/mortbay/jetty/AbstractGenerator;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/AbstractGenerator;","isBufferFull",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L11);
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/jetty/AbstractGenerator$Output;","blockForOutput",new String[]{ },"V"));
                code.visitLabel(L7);
                code.visitFieldStmt(IGET_BOOLEAN,0,3,new Field("Lorg/mortbay/jetty/AbstractGenerator$Output;","_closed","Z"));
                code.visitJumpStmt(IF_EQZ,0,-1,L9);
                code.visitLabel(L8);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/io/IOException;");
                code.visitConstStmt(CONST_STRING,1,"Closed");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,2},new Method("Ljava/io/IOException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,0);
                code.visitLabel(L9);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/jetty/AbstractGenerator$Output;","_generator","Lorg/mortbay/jetty/AbstractGenerator;"));
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/AbstractGenerator;","_endp","Lorg/mortbay/io/EndPoint;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Lorg/mortbay/io/EndPoint;","isOpen",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_NEZ,0,-1,L5);
                code.visitLabel(L10);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/jetty/EofException;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Lorg/mortbay/jetty/EofException;","<init>",new String[]{ },"V"));
                code.visitStmt1R(THROW,0);
                code.visitLabel(L11);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/jetty/AbstractGenerator$Output;","_generator","Lorg/mortbay/jetty/AbstractGenerator;"));
                code.visitStmt2R(INT_TO_BYTE,1,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/AbstractGenerator;","addContent",new String[]{ "B"},"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L13);
                code.visitLabel(L12);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/jetty/AbstractGenerator$Output;","flush",new String[]{ },"V"));
                code.visitLabel(L13);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/jetty/AbstractGenerator$Output;","_generator","Lorg/mortbay/jetty/AbstractGenerator;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/AbstractGenerator;","isContentWritten",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L16);
                code.visitLabel(L14);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/jetty/AbstractGenerator$Output;","flush",new String[]{ },"V"));
                code.visitLabel(L15);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/jetty/AbstractGenerator$Output;","close",new String[]{ },"V"));
                code.visitLabel(L16);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m008_write(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/AbstractGenerator$Output;","write",new String[]{ "[B"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"b");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(588,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(589,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(590,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/AbstractGenerator$Output;","_buf","Lorg/mortbay/io/ByteArrayBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,2},new Method("Lorg/mortbay/io/ByteArrayBuffer;","wrap",new String[]{ "[B"},"V"));
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/AbstractGenerator$Output;","_buf","Lorg/mortbay/io/ByteArrayBuffer;"));
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,0},new Method("Lorg/mortbay/jetty/AbstractGenerator$Output;","write",new String[]{ "Lorg/mortbay/io/Buffer;"},"V"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m009_write(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/AbstractGenerator$Output;","write",new String[]{ "[B","I","I"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"b");
                ddv.visitParameterName(1,"off");
                ddv.visitParameterName(2,"len");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(578,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(579,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(580,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/AbstractGenerator$Output;","_buf","Lorg/mortbay/io/ByteArrayBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,2,3,4},new Method("Lorg/mortbay/io/ByteArrayBuffer;","wrap",new String[]{ "[B","I","I"},"V"));
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/AbstractGenerator$Output;","_buf","Lorg/mortbay/io/ByteArrayBuffer;"));
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,0},new Method("Lorg/mortbay/jetty/AbstractGenerator$Output;","write",new String[]{ "Lorg/mortbay/io/Buffer;"},"V"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
