package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0182_org_mortbay_jetty_NCSARequestLog {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/jetty/NCSARequestLog;","Lorg/mortbay/component/AbstractLifeCycle;",new String[]{ "Lorg/mortbay/jetty/RequestLog;"});
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("NCSARequestLog.java");
        f000__append(cv);
        f001__buffers(cv);
        f002__closeOut(cv);
        f003__copy(cv);
        f004__extended(cv);
        f005__fileOut(cv);
        f006__filename(cv);
        f007__filenameDateFormat(cv);
        f008__ignorePathMap(cv);
        f009__ignorePaths(cv);
        f010__logCookies(cv);
        f011__logDateCache(cv);
        f012__logDateFormat(cv);
        f013__logLatency(cv);
        f014__logLocale(cv);
        f015__logServer(cv);
        f016__logTimeZone(cv);
        f017__out(cv);
        f018__preferProxiedForAddress(cv);
        f019__retainDays(cv);
        f020__writer(cv);
        m000__init_(cv);
        m001__init_(cv);
        m002_doStart(cv);
        m003_doStop(cv);
        m004_getDatedFilename(cv);
        m005_getFilename(cv);
        m006_getFilenameDateFormat(cv);
        m007_getIgnorePaths(cv);
        m008_getLogCookies(cv);
        m009_getLogDateFormat(cv);
        m010_getLogLatency(cv);
        m011_getLogLocale(cv);
        m012_getLogServer(cv);
        m013_getLogTimeZone(cv);
        m014_getRetainDays(cv);
        m015_isAppend(cv);
        m016_isExtended(cv);
        m017_log(cv);
        m018_logExtended(cv);
        m019_setAppend(cv);
        m020_setExtended(cv);
        m021_setFilename(cv);
        m022_setFilenameDateFormat(cv);
        m023_setIgnorePaths(cv);
        m024_setLogCookies(cv);
        m025_setLogDateFormat(cv);
        m026_setLogLatency(cv);
        m027_setLogLocale(cv);
        m028_setLogServer(cv);
        m029_setLogTimeZone(cv);
        m030_setPreferProxiedForAddress(cv);
        m031_setRetainDays(cv);
    }
    public static void f000__append(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/NCSARequestLog;","_append","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001__buffers(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_TRANSIENT, new Field("Lorg/mortbay/jetty/NCSARequestLog;","_buffers","Ljava/util/ArrayList;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002__closeOut(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/NCSARequestLog;","_closeOut","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003__copy(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_TRANSIENT, new Field("Lorg/mortbay/jetty/NCSARequestLog;","_copy","[C"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f004__extended(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/NCSARequestLog;","_extended","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f005__fileOut(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_TRANSIENT, new Field("Lorg/mortbay/jetty/NCSARequestLog;","_fileOut","Ljava/io/OutputStream;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f006__filename(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/NCSARequestLog;","_filename","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f007__filenameDateFormat(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/NCSARequestLog;","_filenameDateFormat","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f008__ignorePathMap(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_TRANSIENT, new Field("Lorg/mortbay/jetty/NCSARequestLog;","_ignorePathMap","Lorg/mortbay/jetty/servlet/PathMap;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f009__ignorePaths(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/NCSARequestLog;","_ignorePaths","[Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f010__logCookies(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/NCSARequestLog;","_logCookies","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f011__logDateCache(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_TRANSIENT, new Field("Lorg/mortbay/jetty/NCSARequestLog;","_logDateCache","Lorg/mortbay/util/DateCache;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f012__logDateFormat(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/NCSARequestLog;","_logDateFormat","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f013__logLatency(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/NCSARequestLog;","_logLatency","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f014__logLocale(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/NCSARequestLog;","_logLocale","Ljava/util/Locale;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f015__logServer(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/NCSARequestLog;","_logServer","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f016__logTimeZone(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/NCSARequestLog;","_logTimeZone","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f017__out(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_TRANSIENT, new Field("Lorg/mortbay/jetty/NCSARequestLog;","_out","Ljava/io/OutputStream;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f018__preferProxiedForAddress(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/NCSARequestLog;","_preferProxiedForAddress","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f019__retainDays(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/NCSARequestLog;","_retainDays","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f020__writer(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_TRANSIENT, new Field("Lorg/mortbay/jetty/NCSARequestLog;","_writer","Ljava/io/Writer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/NCSARequestLog;","<init>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(74,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(55,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(56,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(57,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(58,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(60,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(61,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(62,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(75,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(76,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(77,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(78,L12);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3},new Method("Lorg/mortbay/component/AbstractLifeCycle;","<init>",new String[]{ },"V"));
                code.visitLabel(L2);
                code.visitConstStmt(CONST_STRING,0,"dd/MMM/yyyy:HH:mm:ss Z");
                code.visitFieldStmt(IPUT_OBJECT,0,3,new Field("Lorg/mortbay/jetty/NCSARequestLog;","_logDateFormat","Ljava/lang/String;"));
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_OBJECT,0,3,new Field("Lorg/mortbay/jetty/NCSARequestLog;","_filenameDateFormat","Ljava/lang/String;"));
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Ljava/util/Locale;","getDefault",new String[]{ },"Ljava/util/Locale;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IPUT_OBJECT,0,3,new Field("Lorg/mortbay/jetty/NCSARequestLog;","_logLocale","Ljava/util/Locale;"));
                code.visitLabel(L5);
                code.visitConstStmt(CONST_STRING,0,"GMT");
                code.visitFieldStmt(IPUT_OBJECT,0,3,new Field("Lorg/mortbay/jetty/NCSARequestLog;","_logTimeZone","Ljava/lang/String;"));
                code.visitLabel(L6);
                code.visitFieldStmt(IPUT_BOOLEAN,1,3,new Field("Lorg/mortbay/jetty/NCSARequestLog;","_logLatency","Z"));
                code.visitLabel(L7);
                code.visitFieldStmt(IPUT_BOOLEAN,1,3,new Field("Lorg/mortbay/jetty/NCSARequestLog;","_logCookies","Z"));
                code.visitLabel(L8);
                code.visitFieldStmt(IPUT_BOOLEAN,1,3,new Field("Lorg/mortbay/jetty/NCSARequestLog;","_logServer","Z"));
                code.visitLabel(L9);
                code.visitFieldStmt(IPUT_BOOLEAN,2,3,new Field("Lorg/mortbay/jetty/NCSARequestLog;","_extended","Z"));
                code.visitLabel(L10);
                code.visitFieldStmt(IPUT_BOOLEAN,2,3,new Field("Lorg/mortbay/jetty/NCSARequestLog;","_append","Z"));
                code.visitLabel(L11);
                code.visitConstStmt(CONST_16,0, Integer.valueOf(31)); // int: 0x0000001f  float:0.000000
                code.visitFieldStmt(IPUT,0,3,new Field("Lorg/mortbay/jetty/NCSARequestLog;","_retainDays","I"));
                code.visitLabel(L12);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/NCSARequestLog;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"filename");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(85,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(55,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(56,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(57,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(58,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(60,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(61,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(62,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(86,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(87,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(88,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(89,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(90,L13);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3},new Method("Lorg/mortbay/component/AbstractLifeCycle;","<init>",new String[]{ },"V"));
                code.visitLabel(L2);
                code.visitConstStmt(CONST_STRING,0,"dd/MMM/yyyy:HH:mm:ss Z");
                code.visitFieldStmt(IPUT_OBJECT,0,3,new Field("Lorg/mortbay/jetty/NCSARequestLog;","_logDateFormat","Ljava/lang/String;"));
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_OBJECT,0,3,new Field("Lorg/mortbay/jetty/NCSARequestLog;","_filenameDateFormat","Ljava/lang/String;"));
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Ljava/util/Locale;","getDefault",new String[]{ },"Ljava/util/Locale;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IPUT_OBJECT,0,3,new Field("Lorg/mortbay/jetty/NCSARequestLog;","_logLocale","Ljava/util/Locale;"));
                code.visitLabel(L5);
                code.visitConstStmt(CONST_STRING,0,"GMT");
                code.visitFieldStmt(IPUT_OBJECT,0,3,new Field("Lorg/mortbay/jetty/NCSARequestLog;","_logTimeZone","Ljava/lang/String;"));
                code.visitLabel(L6);
                code.visitFieldStmt(IPUT_BOOLEAN,1,3,new Field("Lorg/mortbay/jetty/NCSARequestLog;","_logLatency","Z"));
                code.visitLabel(L7);
                code.visitFieldStmt(IPUT_BOOLEAN,1,3,new Field("Lorg/mortbay/jetty/NCSARequestLog;","_logCookies","Z"));
                code.visitLabel(L8);
                code.visitFieldStmt(IPUT_BOOLEAN,1,3,new Field("Lorg/mortbay/jetty/NCSARequestLog;","_logServer","Z"));
                code.visitLabel(L9);
                code.visitFieldStmt(IPUT_BOOLEAN,2,3,new Field("Lorg/mortbay/jetty/NCSARequestLog;","_extended","Z"));
                code.visitLabel(L10);
                code.visitFieldStmt(IPUT_BOOLEAN,2,3,new Field("Lorg/mortbay/jetty/NCSARequestLog;","_append","Z"));
                code.visitLabel(L11);
                code.visitConstStmt(CONST_16,0, Integer.valueOf(31)); // int: 0x0000001f  float:0.000000
                code.visitFieldStmt(IPUT,0,3,new Field("Lorg/mortbay/jetty/NCSARequestLog;","_retainDays","I"));
                code.visitLabel(L12);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Lorg/mortbay/jetty/NCSARequestLog;","setFilename",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L13);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_doStart(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/NCSARequestLog;","doStart",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/Exception;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(9);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(420,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(422,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(423,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(426,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(428,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(429,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(430,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(435,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(437,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(439,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(440,L11);
                DexLabel L12=new DexLabel();
                ddv.visitStartLocal(7,L12,"i","I",null);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(441,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(440,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(433,L15);
                ddv.visitEndLocal(7,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(444,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(446,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(447,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(448,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(449,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(450,L21);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,6, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,8,new Field("Lorg/mortbay/jetty/NCSARequestLog;","_logDateFormat","Ljava/lang/String;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L4);
                code.visitLabel(L2);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/util/DateCache;");
                code.visitFieldStmt(IGET_OBJECT,1,8,new Field("Lorg/mortbay/jetty/NCSARequestLog;","_logDateFormat","Ljava/lang/String;"));
                code.visitFieldStmt(IGET_OBJECT,2,8,new Field("Lorg/mortbay/jetty/NCSARequestLog;","_logLocale","Ljava/util/Locale;"));
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1,2},new Method("Lorg/mortbay/util/DateCache;","<init>",new String[]{ "Ljava/lang/String;","Ljava/util/Locale;"},"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,8,new Field("Lorg/mortbay/jetty/NCSARequestLog;","_logDateCache","Lorg/mortbay/util/DateCache;"));
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,8,new Field("Lorg/mortbay/jetty/NCSARequestLog;","_logDateCache","Lorg/mortbay/util/DateCache;"));
                code.visitFieldStmt(IGET_OBJECT,1,8,new Field("Lorg/mortbay/jetty/NCSARequestLog;","_logTimeZone","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/util/DateCache;","setTimeZoneID",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,0,8,new Field("Lorg/mortbay/jetty/NCSARequestLog;","_filename","Ljava/lang/String;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L15);
                code.visitLabel(L5);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/util/RolloverFileOutputStream;");
                code.visitFieldStmt(IGET_OBJECT,1,8,new Field("Lorg/mortbay/jetty/NCSARequestLog;","_filename","Ljava/lang/String;"));
                code.visitFieldStmt(IGET_BOOLEAN,2,8,new Field("Lorg/mortbay/jetty/NCSARequestLog;","_append","Z"));
                code.visitFieldStmt(IGET,3,8,new Field("Lorg/mortbay/jetty/NCSARequestLog;","_retainDays","I"));
                code.visitFieldStmt(IGET_OBJECT,4,8,new Field("Lorg/mortbay/jetty/NCSARequestLog;","_logTimeZone","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 4},new Method("Ljava/util/TimeZone;","getTimeZone",new String[]{ "Ljava/lang/String;"},"Ljava/util/TimeZone;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitFieldStmt(IGET_OBJECT,5,8,new Field("Lorg/mortbay/jetty/NCSARequestLog;","_filenameDateFormat","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_DIRECT_RANGE,new int[]{ 0,1,2,3,4,5,6},new Method("Lorg/mortbay/util/RolloverFileOutputStream;","<init>",new String[]{ "Ljava/lang/String;","Z","I","Ljava/util/TimeZone;","Ljava/lang/String;","Ljava/lang/String;"},"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,8,new Field("Lorg/mortbay/jetty/NCSARequestLog;","_fileOut","Ljava/io/OutputStream;"));
                code.visitLabel(L6);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitFieldStmt(IPUT_BOOLEAN,0,8,new Field("Lorg/mortbay/jetty/NCSARequestLog;","_closeOut","Z"));
                code.visitLabel(L7);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,1,"Opened ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Lorg/mortbay/jetty/NCSARequestLog;","getDatedFilename",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/log/Log;","info",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L8);
                code.visitFieldStmt(IGET_OBJECT,0,8,new Field("Lorg/mortbay/jetty/NCSARequestLog;","_fileOut","Ljava/io/OutputStream;"));
                code.visitFieldStmt(IPUT_OBJECT,0,8,new Field("Lorg/mortbay/jetty/NCSARequestLog;","_out","Ljava/io/OutputStream;"));
                code.visitLabel(L9);
                code.visitFieldStmt(IGET_OBJECT,0,8,new Field("Lorg/mortbay/jetty/NCSARequestLog;","_ignorePaths","[Ljava/lang/String;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L16);
                code.visitFieldStmt(IGET_OBJECT,0,8,new Field("Lorg/mortbay/jetty/NCSARequestLog;","_ignorePaths","[Ljava/lang/String;"));
                code.visitStmt2R(ARRAY_LENGTH,0,0);
                code.visitJumpStmt(IF_LEZ,0,-1,L16);
                code.visitLabel(L10);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/jetty/servlet/PathMap;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Lorg/mortbay/jetty/servlet/PathMap;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,8,new Field("Lorg/mortbay/jetty/NCSARequestLog;","_ignorePathMap","Lorg/mortbay/jetty/servlet/PathMap;"));
                code.visitLabel(L11);
                code.visitConstStmt(CONST_4,7, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L12);
                code.visitFieldStmt(IGET_OBJECT,0,8,new Field("Lorg/mortbay/jetty/NCSARequestLog;","_ignorePaths","[Ljava/lang/String;"));
                code.visitStmt2R(ARRAY_LENGTH,0,0);
                code.visitJumpStmt(IF_GE,7,0,L17);
                code.visitLabel(L13);
                code.visitFieldStmt(IGET_OBJECT,0,8,new Field("Lorg/mortbay/jetty/NCSARequestLog;","_ignorePathMap","Lorg/mortbay/jetty/servlet/PathMap;"));
                code.visitFieldStmt(IGET_OBJECT,1,8,new Field("Lorg/mortbay/jetty/NCSARequestLog;","_ignorePaths","[Ljava/lang/String;"));
                code.visitStmt3R(AGET_OBJECT,1,1,7);
                code.visitFieldStmt(IGET_OBJECT,2,8,new Field("Lorg/mortbay/jetty/NCSARequestLog;","_ignorePaths","[Ljava/lang/String;"));
                code.visitStmt3R(AGET_OBJECT,2,2,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Lorg/mortbay/jetty/servlet/PathMap;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L14);
                code.visitStmt2R1N(ADD_INT_LIT8,7,7,1);
                code.visitJumpStmt(GOTO,-1,-1,L12);
                code.visitLabel(L15);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Ljava/lang/System;","err","Ljava/io/PrintStream;"));
                code.visitFieldStmt(IPUT_OBJECT,0,8,new Field("Lorg/mortbay/jetty/NCSARequestLog;","_fileOut","Ljava/io/OutputStream;"));
                code.visitJumpStmt(GOTO,-1,-1,L8);
                code.visitLabel(L16);
                code.visitFieldStmt(IPUT_OBJECT,6,8,new Field("Lorg/mortbay/jetty/NCSARequestLog;","_ignorePathMap","Lorg/mortbay/jetty/servlet/PathMap;"));
                code.visitLabel(L17);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/io/OutputStreamWriter;");
                code.visitFieldStmt(IGET_OBJECT,1,8,new Field("Lorg/mortbay/jetty/NCSARequestLog;","_out","Ljava/io/OutputStream;"));
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Ljava/io/OutputStreamWriter;","<init>",new String[]{ "Ljava/io/OutputStream;"},"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,8,new Field("Lorg/mortbay/jetty/NCSARequestLog;","_writer","Ljava/io/Writer;"));
                code.visitLabel(L18);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/util/ArrayList;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/util/ArrayList;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,8,new Field("Lorg/mortbay/jetty/NCSARequestLog;","_buffers","Ljava/util/ArrayList;"));
                code.visitLabel(L19);
                code.visitConstStmt(CONST_16,0, Integer.valueOf(1024)); // int: 0x00000400  float:0.000000
                code.visitTypeStmt(NEW_ARRAY,0,0,"[C");
                code.visitFieldStmt(IPUT_OBJECT,0,8,new Field("Lorg/mortbay/jetty/NCSARequestLog;","_copy","[C"));
                code.visitLabel(L20);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 8},new Method("Lorg/mortbay/component/AbstractLifeCycle;","doStart",new String[]{ },"V"));
                code.visitLabel(L21);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_doStop(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/NCSARequestLog;","doStop",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/Exception;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/io/IOException;"});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                DexLabel L5=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L5},new String[]{ "Ljava/io/IOException;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L6=new DexLabel();
                ddv.visitPrologue(L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(455,L7);
                ddv.visitLineNumber(456,L0);
                ddv.visitLineNumber(457,L1);
                ddv.visitLineNumber(458,L3);
                ddv.visitLineNumber(460,L4);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(461,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(462,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(463,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(464,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(465,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(466,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(467,L14);
                ddv.visitLineNumber(456,L2);
                DexLabel L15=new DexLabel();
                ddv.visitStartLocal(0,L15,"e","Ljava/io/IOException;",null);
                ddv.visitLineNumber(458,L5);
                ddv.visitEndLocal(0,L5);
                DexLabel L16=new DexLabel();
                ddv.visitRestartLocal(0,L16);
                code.visitLabel(L6);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 3},new Method("Lorg/mortbay/component/AbstractLifeCycle;","doStop",new String[]{ },"V"));
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/jetty/NCSARequestLog;","_writer","Ljava/io/Writer;"));
                code.visitJumpStmt(IF_EQZ,1,-1,L1);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/jetty/NCSARequestLog;","_writer","Ljava/io/Writer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/io/Writer;","flush",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/jetty/NCSARequestLog;","_out","Ljava/io/OutputStream;"));
                code.visitJumpStmt(IF_EQZ,1,-1,L4);
                code.visitFieldStmt(IGET_BOOLEAN,1,3,new Field("Lorg/mortbay/jetty/NCSARequestLog;","_closeOut","Z"));
                code.visitJumpStmt(IF_EQZ,1,-1,L4);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/jetty/NCSARequestLog;","_out","Ljava/io/OutputStream;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/io/OutputStream;","close",new String[]{ },"V"));
                code.visitLabel(L4);
                code.visitFieldStmt(IPUT_OBJECT,2,3,new Field("Lorg/mortbay/jetty/NCSARequestLog;","_out","Ljava/io/OutputStream;"));
                code.visitLabel(L8);
                code.visitFieldStmt(IPUT_OBJECT,2,3,new Field("Lorg/mortbay/jetty/NCSARequestLog;","_fileOut","Ljava/io/OutputStream;"));
                code.visitLabel(L9);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_BOOLEAN,1,3,new Field("Lorg/mortbay/jetty/NCSARequestLog;","_closeOut","Z"));
                code.visitLabel(L10);
                code.visitFieldStmt(IPUT_OBJECT,2,3,new Field("Lorg/mortbay/jetty/NCSARequestLog;","_logDateCache","Lorg/mortbay/util/DateCache;"));
                code.visitLabel(L11);
                code.visitFieldStmt(IPUT_OBJECT,2,3,new Field("Lorg/mortbay/jetty/NCSARequestLog;","_writer","Ljava/io/Writer;"));
                code.visitLabel(L12);
                code.visitFieldStmt(IPUT_OBJECT,2,3,new Field("Lorg/mortbay/jetty/NCSARequestLog;","_buffers","Ljava/util/ArrayList;"));
                code.visitLabel(L13);
                code.visitFieldStmt(IPUT_OBJECT,2,3,new Field("Lorg/mortbay/jetty/NCSARequestLog;","_copy","[C"));
                code.visitLabel(L14);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitStmt2R(MOVE_OBJECT,0,1);
                code.visitLabel(L15);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/log/Log;","ignore",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitLabel(L5);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitStmt2R(MOVE_OBJECT,0,1);
                code.visitLabel(L16);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/log/Log;","ignore",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_getDatedFilename(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/NCSARequestLog;","getDatedFilename",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(114,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(115,L1);
                DexLabel L2=new DexLabel();
                ddv.visitEndLocal(1,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(116,L3);
                DexLabel L4=new DexLabel();
                ddv.visitRestartLocal(1,L4);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/NCSARequestLog;","_fileOut","Ljava/io/OutputStream;"));
                code.visitTypeStmt(INSTANCE_OF,0,0,"Lorg/mortbay/util/RolloverFileOutputStream;");
                code.visitJumpStmt(IF_EQZ,0,-1,L4);
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,1,1,new Field("Lorg/mortbay/jetty/NCSARequestLog;","_fileOut","Ljava/io/OutputStream;"));
                code.visitLabel(L2);
                code.visitTypeStmt(CHECK_CAST,1,-1,"Lorg/mortbay/util/RolloverFileOutputStream;");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/util/RolloverFileOutputStream;","getDatedFilename",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L3);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L4);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_getFilename(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/NCSARequestLog;","getFilename",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(109,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/NCSARequestLog;","_filename","Ljava/lang/String;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_getFilenameDateFormat(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/NCSARequestLog;","getFilenameDateFormat",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(475,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/NCSARequestLog;","_filenameDateFormat","Ljava/lang/String;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m007_getIgnorePaths(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/NCSARequestLog;","getIgnorePaths",new String[]{ },"[Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(191,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/NCSARequestLog;","_ignorePaths","[Ljava/lang/String;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m008_getLogCookies(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/NCSARequestLog;","getLogCookies",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(201,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_BOOLEAN,0,1,new Field("Lorg/mortbay/jetty/NCSARequestLog;","_logCookies","Z"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m009_getLogDateFormat(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/NCSARequestLog;","getLogDateFormat",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(131,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/NCSARequestLog;","_logDateFormat","Ljava/lang/String;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m010_getLogLatency(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/NCSARequestLog;","getLogLatency",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(221,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_BOOLEAN,0,1,new Field("Lorg/mortbay/jetty/NCSARequestLog;","_logLatency","Z"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m011_getLogLocale(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/NCSARequestLog;","getLogLocale",new String[]{ },"Ljava/util/Locale;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(141,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/NCSARequestLog;","_logLocale","Ljava/util/Locale;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m012_getLogServer(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/NCSARequestLog;","getLogServer",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(206,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_BOOLEAN,0,1,new Field("Lorg/mortbay/jetty/NCSARequestLog;","_logServer","Z"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m013_getLogTimeZone(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/NCSARequestLog;","getLogTimeZone",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(151,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/NCSARequestLog;","_logTimeZone","Ljava/lang/String;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m014_getRetainDays(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/NCSARequestLog;","getRetainDays",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(161,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,1,new Field("Lorg/mortbay/jetty/NCSARequestLog;","_retainDays","I"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m015_isAppend(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/NCSARequestLog;","isAppend",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(181,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_BOOLEAN,0,1,new Field("Lorg/mortbay/jetty/NCSARequestLog;","_append","Z"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m016_isExtended(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/NCSARequestLog;","isExtended",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(171,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_BOOLEAN,0,1,new Field("Lorg/mortbay/jetty/NCSARequestLog;","_extended","Z"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m017_log(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/NCSARequestLog;","log",new String[]{ "Lorg/mortbay/jetty/Request;","Lorg/mortbay/jetty/Response;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(26);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/io/IOException;"});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                code.visitTryCatch(L1,L3,new DexLabel[]{L4},new String[]{ null});
                DexLabel L5=new DexLabel();
                code.visitTryCatch(L3,L5,new DexLabel[]{L2},new String[]{ "Ljava/io/IOException;"});
                DexLabel L6=new DexLabel();
                DexLabel L7=new DexLabel();
                code.visitTryCatch(L5,L6,new DexLabel[]{L7},new String[]{ null});
                DexLabel L8=new DexLabel();
                code.visitTryCatch(L6,L8,new DexLabel[]{L2},new String[]{ "Ljava/io/IOException;"});
                DexLabel L9=new DexLabel();
                DexLabel L10=new DexLabel();
                code.visitTryCatch(L8,L9,new DexLabel[]{L10},new String[]{ null});
                code.visitTryCatch(L9,L2,new DexLabel[]{L2},new String[]{ "Ljava/io/IOException;"});
                DexLabel L11=new DexLabel();
                DexLabel L12=new DexLabel();
                code.visitTryCatch(L11,L12,new DexLabel[]{L4},new String[]{ null});
                DexLabel L13=new DexLabel();
                code.visitTryCatch(L12,L13,new DexLabel[]{L2},new String[]{ "Ljava/io/IOException;"});
                DexLabel L14=new DexLabel();
                DexLabel L15=new DexLabel();
                code.visitTryCatch(L14,L15,new DexLabel[]{L7},new String[]{ null});
                DexLabel L16=new DexLabel();
                code.visitTryCatch(L15,L16,new DexLabel[]{L2},new String[]{ "Ljava/io/IOException;"});
                DexLabel L17=new DexLabel();
                DexLabel L18=new DexLabel();
                code.visitTryCatch(L17,L18,new DexLabel[]{L7},new String[]{ null});
                DexLabel L19=new DexLabel();
                DexLabel L20=new DexLabel();
                code.visitTryCatch(L19,L20,new DexLabel[]{L2},new String[]{ "Ljava/io/IOException;"});
                DexLabel L21=new DexLabel();
                DexLabel L22=new DexLabel();
                code.visitTryCatch(L20,L21,new DexLabel[]{L22},new String[]{ null});
                DexLabel L23=new DexLabel();
                code.visitTryCatch(L21,L23,new DexLabel[]{L2},new String[]{ "Ljava/io/IOException;"});
                DexLabel L24=new DexLabel();
                code.visitTryCatch(L23,L24,new DexLabel[]{L22},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"request");
                ddv.visitParameterName(1,"response");
                DexLabel L25=new DexLabel();
                ddv.visitPrologue(L25);
                ddv.visitLineNumber(232,L25);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(389,L26);
                ddv.visitLineNumber(237,L0);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(240,L27);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(245,L28);
                ddv.visitLineNumber(247,L1);
                DexLabel L29=new DexLabel();
                ddv.visitLineNumber(248,L29);
                ddv.visitStartLocal(13,L29,"size","I",null);
                DexLabel L30=new DexLabel();
                ddv.visitLineNumber(249,L30);
                ddv.visitStartLocal(15,L30,"u8buf","Lorg/mortbay/util/Utf8StringBuffer;",null);
                DexLabel L31=new DexLabel();
                ddv.visitLineNumber(250,L31);
                ddv.visitStartLocal(6,L31,"buf","Ljava/lang/StringBuffer;",null);
                ddv.visitLineNumber(252,L3);
                ddv.visitLineNumber(254,L5);
                DexLabel L32=new DexLabel();
                ddv.visitLineNumber(256,L32);
                DexLabel L33=new DexLabel();
                ddv.visitLineNumber(257,L33);
                DexLabel L34=new DexLabel();
                ddv.visitLineNumber(260,L34);
                DexLabel L35=new DexLabel();
                ddv.visitLineNumber(261,L35);
                ddv.visitStartLocal(5,L35,"addr","Ljava/lang/String;",null);
                DexLabel L36=new DexLabel();
                ddv.visitLineNumber(263,L36);
                DexLabel L37=new DexLabel();
                ddv.visitLineNumber(266,L37);
                DexLabel L38=new DexLabel();
                ddv.visitLineNumber(267,L38);
                DexLabel L39=new DexLabel();
                ddv.visitLineNumber(269,L39);
                ddv.visitRestartLocal(5,L39);
                DexLabel L40=new DexLabel();
                ddv.visitLineNumber(270,L40);
                DexLabel L41=new DexLabel();
                ddv.visitLineNumber(271,L41);
                DexLabel L42=new DexLabel();
                ddv.visitLineNumber(272,L42);
                ddv.visitStartLocal(16,L42,"user","Ljava/lang/String;",null);
                DexLabel L43=new DexLabel();
                ddv.visitLineNumber(273,L43);
                DexLabel L44=new DexLabel();
                ddv.visitLineNumber(274,L44);
                DexLabel L45=new DexLabel();
                ddv.visitLineNumber(275,L45);
                DexLabel L46=new DexLabel();
                ddv.visitLineNumber(279,L46);
                DexLabel L47=new DexLabel();
                ddv.visitLineNumber(280,L47);
                DexLabel L48=new DexLabel();
                ddv.visitLineNumber(281,L48);
                DexLabel L49=new DexLabel();
                ddv.visitLineNumber(283,L49);
                DexLabel L50=new DexLabel();
                ddv.visitLineNumber(285,L50);
                DexLabel L51=new DexLabel();
                ddv.visitLineNumber(286,L51);
                DexLabel L52=new DexLabel();
                ddv.visitLineNumber(287,L52);
                DexLabel L53=new DexLabel();
                ddv.visitLineNumber(288,L53);
                DexLabel L54=new DexLabel();
                ddv.visitLineNumber(289,L54);
                ddv.visitStartLocal(14,L54,"status","I",null);
                DexLabel L55=new DexLabel();
                ddv.visitLineNumber(290,L55);
                DexLabel L56=new DexLabel();
                ddv.visitLineNumber(291,L56);
                DexLabel L57=new DexLabel();
                ddv.visitLineNumber(292,L57);
                DexLabel L58=new DexLabel();
                ddv.visitLineNumber(293,L58);
                DexLabel L59=new DexLabel();
                ddv.visitLineNumber(296,L59);
                DexLabel L60=new DexLabel();
                ddv.visitLineNumber(297,L60);
                ddv.visitStartLocal(11,L60,"responseLength","J",null);
                DexLabel L61=new DexLabel();
                ddv.visitLineNumber(299,L61);
                DexLabel L62=new DexLabel();
                ddv.visitLineNumber(300,L62);
                DexLabel L63=new DexLabel();
                ddv.visitLineNumber(301,L63);
                DexLabel L64=new DexLabel();
                ddv.visitLineNumber(314,L64);
                DexLabel L65=new DexLabel();
                ddv.visitLineNumber(319,L65);
                ddv.visitLineNumber(321,L6);
                DexLabel L66=new DexLabel();
                ddv.visitLineNumber(323,L66);
                ddv.visitLineNumber(325,L8);
                DexLabel L67=new DexLabel();
                ddv.visitLineNumber(326,L67);
                DexLabel L68=new DexLabel();
                ddv.visitLineNumber(327,L68);
                ddv.visitStartLocal(10,L68,"l","I",null);
                DexLabel L69=new DexLabel();
                ddv.visitLineNumber(328,L69);
                DexLabel L70=new DexLabel();
                ddv.visitLineNumber(329,L70);
                DexLabel L71=new DexLabel();
                ddv.visitLineNumber(330,L71);
                DexLabel L72=new DexLabel();
                ddv.visitLineNumber(331,L72);
                DexLabel L73=new DexLabel();
                ddv.visitLineNumber(332,L73);
                DexLabel L74=new DexLabel();
                ddv.visitLineNumber(333,L74);
                DexLabel L75=new DexLabel();
                ddv.visitLineNumber(334,L75);
                ddv.visitEndLocal(10,L10);
                ddv.visitLineNumber(384,L2);
                ddv.visitEndLocal(13,L2);
                ddv.visitEndLocal(15,L2);
                ddv.visitEndLocal(6,L2);
                ddv.visitEndLocal(5,L2);
                ddv.visitEndLocal(16,L2);
                ddv.visitEndLocal(14,L2);
                ddv.visitEndLocal(11,L2);
                DexLabel L76=new DexLabel();
                ddv.visitLineNumber(386,L76);
                ddv.visitStartLocal(8,L76,"e","Ljava/io/IOException;",null);
                ddv.visitLineNumber(248,L11);
                ddv.visitEndLocal(8,L11);
                ddv.visitRestartLocal(13,L11);
                ddv.visitLineNumber(250,L4);
                ddv.visitEndLocal(13,L4);
                ddv.visitRestartLocal(5,L13);
                ddv.visitRestartLocal(6,L13);
                ddv.visitRestartLocal(13,L13);
                ddv.visitRestartLocal(15,L13);
                ddv.visitRestartLocal(16,L13);
                DexLabel L77=new DexLabel();
                ddv.visitLineNumber(272,L77);
                ddv.visitLineNumber(277,L14);
                ddv.visitLineNumber(319,L7);
                ddv.visitEndLocal(5,L7);
                ddv.visitEndLocal(16,L7);
                ddv.visitLineNumber(304,L16);
                ddv.visitRestartLocal(5,L16);
                ddv.visitRestartLocal(11,L16);
                ddv.visitRestartLocal(14,L16);
                ddv.visitRestartLocal(16,L16);
                DexLabel L78=new DexLabel();
                ddv.visitLineNumber(305,L78);
                DexLabel L79=new DexLabel();
                ddv.visitLineNumber(306,L79);
                DexLabel L80=new DexLabel();
                ddv.visitLineNumber(307,L80);
                DexLabel L81=new DexLabel();
                ddv.visitLineNumber(308,L81);
                DexLabel L82=new DexLabel();
                ddv.visitLineNumber(309,L82);
                DexLabel L83=new DexLabel();
                ddv.visitLineNumber(310,L83);
                DexLabel L84=new DexLabel();
                ddv.visitLineNumber(311,L84);
                DexLabel L85=new DexLabel();
                ddv.visitLineNumber(312,L85);
                DexLabel L86=new DexLabel();
                ddv.visitLineNumber(317,L86);
                ddv.visitLineNumber(338,L19);
                ddv.visitLineNumber(340,L20);
                DexLabel L87=new DexLabel();
                ddv.visitLineNumber(341,L87);
                ddv.visitRestartLocal(10,L87);
                DexLabel L88=new DexLabel();
                ddv.visitLineNumber(342,L88);
                DexLabel L89=new DexLabel();
                ddv.visitLineNumber(343,L89);
                ddv.visitRestartLocal(10,L89);
                DexLabel L90=new DexLabel();
                ddv.visitLineNumber(344,L90);
                DexLabel L91=new DexLabel();
                ddv.visitLineNumber(345,L91);
                DexLabel L92=new DexLabel();
                ddv.visitLineNumber(346,L92);
                DexLabel L93=new DexLabel();
                ddv.visitLineNumber(349,L93);
                DexLabel L94=new DexLabel();
                ddv.visitLineNumber(350,L94);
                DexLabel L95=new DexLabel();
                ddv.visitLineNumber(353,L95);
                DexLabel L96=new DexLabel();
                ddv.visitLineNumber(355,L96);
                DexLabel L97=new DexLabel();
                ddv.visitLineNumber(356,L97);
                ddv.visitStartLocal(7,L97,"cookies","[Ljavax/servlet/http/Cookie;",null);
                DexLabel L98=new DexLabel();
                ddv.visitLineNumber(357,L98);
                DexLabel L99=new DexLabel();
                ddv.visitLineNumber(373,L99);
                ddv.visitEndLocal(7,L99);
                DexLabel L100=new DexLabel();
                ddv.visitLineNumber(375,L100);
                DexLabel L101=new DexLabel();
                ddv.visitLineNumber(376,L101);
                DexLabel L102=new DexLabel();
                ddv.visitLineNumber(379,L102);
                DexLabel L103=new DexLabel();
                ddv.visitLineNumber(380,L103);
                DexLabel L104=new DexLabel();
                ddv.visitLineNumber(381,L104);
                ddv.visitEndLocal(10,L22);
                ddv.visitLineNumber(360,L23);
                ddv.visitRestartLocal(7,L23);
                ddv.visitRestartLocal(10,L23);
                DexLabel L105=new DexLabel();
                ddv.visitLineNumber(361,L105);
                DexLabel L106=new DexLabel();
                ddv.visitStartLocal(9,L106,"i","I",null);
                DexLabel L107=new DexLabel();
                ddv.visitLineNumber(363,L107);
                DexLabel L108=new DexLabel();
                ddv.visitLineNumber(364,L108);
                DexLabel L109=new DexLabel();
                ddv.visitLineNumber(365,L109);
                DexLabel L110=new DexLabel();
                ddv.visitLineNumber(366,L110);
                DexLabel L111=new DexLabel();
                ddv.visitLineNumber(367,L111);
                DexLabel L112=new DexLabel();
                ddv.visitLineNumber(361,L112);
                DexLabel L113=new DexLabel();
                ddv.visitLineNumber(369,L113);
                code.visitLabel(L25);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 23},new Method("Lorg/mortbay/jetty/NCSARequestLog;","isStarted",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,17);
                code.visitJumpStmt(IF_NEZ,17,-1,L0);
                code.visitLabel(L26);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,23);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/NCSARequestLog;","_ignorePathMap","Lorg/mortbay/jetty/servlet/PathMap;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,17,0);
                code.visitJumpStmt(IF_EQZ,17,-1,L27);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,23);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/NCSARequestLog;","_ignorePathMap","Lorg/mortbay/jetty/servlet/PathMap;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,17,0);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 24},new Method("Lorg/mortbay/jetty/Request;","getRequestURI",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,18);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 17,18},new Method("Lorg/mortbay/jetty/servlet/PathMap;","getMatch",new String[]{ "Ljava/lang/String;"},"Lorg/mortbay/jetty/servlet/PathMap$Entry;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,17);
                code.visitJumpStmt(IF_NEZ,17,-1,L26);
                code.visitLabel(L27);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,23);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/NCSARequestLog;","_fileOut","Ljava/io/OutputStream;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,17,0);
                code.visitJumpStmt(IF_EQZ,17,-1,L26);
                code.visitLabel(L28);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,23);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/NCSARequestLog;","_writer","Ljava/io/Writer;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,17,0);
                code.visitStmt1R(MONITOR_ENTER,17);
                code.visitLabel(L1);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,23);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/NCSARequestLog;","_buffers","Ljava/util/ArrayList;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,18,0);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 18},new Method("Ljava/util/ArrayList;","size",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,13);
                code.visitLabel(L29);
                code.visitJumpStmt(IF_NEZ,13,-1,L11);
                code.visitTypeStmt(NEW_INSTANCE,18,-1,"Lorg/mortbay/util/Utf8StringBuffer;");
                code.visitConstStmt(CONST_16,19, Integer.valueOf(160)); // int: 0x000000a0  float:0.000000
                code.visitMethodStmt(INVOKE_DIRECT_RANGE,new int[]{ 18,19},new Method("Lorg/mortbay/util/Utf8StringBuffer;","<init>",new String[]{ "I"},"V"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,15,18);
                code.visitLabel(L30);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 15},new Method("Lorg/mortbay/util/Utf8StringBuffer;","getStringBuffer",new String[]{ },"Ljava/lang/StringBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitLabel(L31);
                code.visitStmt1R(MONITOR_EXIT,17);
                code.visitLabel(L3);
                code.visitStmt1R(MONITOR_ENTER,6);
                code.visitLabel(L5);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,23);
                code.visitFieldStmt(IGET_BOOLEAN,0,0,new Field("Lorg/mortbay/jetty/NCSARequestLog;","_logServer","Z"));
                code.visitStmt2R(MOVE_FROM16,17,0);
                code.visitJumpStmt(IF_EQZ,17,-1,L34);
                code.visitLabel(L32);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 24},new Method("Lorg/mortbay/jetty/Request;","getServerName",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,17);
                code.visitStmt2R(MOVE_OBJECT,0,6);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,17);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L33);
                code.visitConstStmt(CONST_16,17, Integer.valueOf(32)); // int: 0x00000020  float:0.000000
                code.visitStmt2R(MOVE_OBJECT,0,6);
                code.visitStmt2R(MOVE_FROM16,1,17);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "C"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L34);
                code.visitConstStmt(CONST_4,5, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L35);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,23);
                code.visitFieldStmt(IGET_BOOLEAN,0,0,new Field("Lorg/mortbay/jetty/NCSARequestLog;","_preferProxiedForAddress","Z"));
                code.visitStmt2R(MOVE_FROM16,17,0);
                code.visitJumpStmt(IF_EQZ,17,-1,L37);
                code.visitLabel(L36);
                code.visitConstStmt(CONST_STRING,17,"X-Forwarded-For");
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,24);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,17);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/Request;","getHeader",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitLabel(L37);
                code.visitJumpStmt(IF_NEZ,5,-1,L39);
                code.visitLabel(L38);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 24},new Method("Lorg/mortbay/jetty/Request;","getRemoteAddr",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitLabel(L39);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,5},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L40);
                code.visitConstStmt(CONST_STRING,17," - ");
                code.visitStmt2R(MOVE_OBJECT,0,6);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,17);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L41);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 24},new Method("Lorg/mortbay/jetty/Request;","getRemoteUser",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,16);
                code.visitLabel(L42);
                code.visitJumpStmt(IF_NEZ,16,-1,L13);
                code.visitConstStmt(CONST_STRING,17," - ");
                DexLabel L114=new DexLabel();
                code.visitLabel(L114);
                code.visitStmt2R(MOVE_OBJECT,0,6);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,17);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L43);
                code.visitConstStmt(CONST_STRING,17," [");
                code.visitStmt2R(MOVE_OBJECT,0,6);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,17);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L44);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,23);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/NCSARequestLog;","_logDateCache","Lorg/mortbay/util/DateCache;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,17,0);
                code.visitJumpStmt(IF_EQZ,17,-1,L14);
                code.visitLabel(L45);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,23);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/NCSARequestLog;","_logDateCache","Lorg/mortbay/util/DateCache;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,17,0);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 24},new Method("Lorg/mortbay/jetty/Request;","getTimeStamp",new String[]{ },"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,18);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 17,18,19},new Method("Lorg/mortbay/util/DateCache;","format",new String[]{ "J"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,17);
                code.visitStmt2R(MOVE_OBJECT,0,6);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,17);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L46);
                code.visitConstStmt(CONST_STRING,17,"] \"");
                code.visitStmt2R(MOVE_OBJECT,0,6);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,17);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L47);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 24},new Method("Lorg/mortbay/jetty/Request;","getMethod",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,17);
                code.visitStmt2R(MOVE_OBJECT,0,6);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,17);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L48);
                code.visitConstStmt(CONST_16,17, Integer.valueOf(32)); // int: 0x00000020  float:0.000000
                code.visitStmt2R(MOVE_OBJECT,0,6);
                code.visitStmt2R(MOVE_FROM16,1,17);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "C"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L49);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 24},new Method("Lorg/mortbay/jetty/Request;","getUri",new String[]{ },"Lorg/mortbay/jetty/HttpURI;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,17);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,17);
                code.visitStmt2R(MOVE_OBJECT,1,15);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/HttpURI;","writeTo",new String[]{ "Lorg/mortbay/util/Utf8StringBuffer;"},"V"));
                code.visitLabel(L50);
                code.visitConstStmt(CONST_16,17, Integer.valueOf(32)); // int: 0x00000020  float:0.000000
                code.visitStmt2R(MOVE_OBJECT,0,6);
                code.visitStmt2R(MOVE_FROM16,1,17);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "C"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L51);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 24},new Method("Lorg/mortbay/jetty/Request;","getProtocol",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,17);
                code.visitStmt2R(MOVE_OBJECT,0,6);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,17);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L52);
                code.visitConstStmt(CONST_STRING,17,"\" ");
                code.visitStmt2R(MOVE_OBJECT,0,6);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,17);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L53);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 25},new Method("Lorg/mortbay/jetty/Response;","getStatus",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,14);
                code.visitLabel(L54);
                code.visitJumpStmt(IF_GTZ,14,-1,L56);
                code.visitLabel(L55);
                code.visitConstStmt(CONST_16,14, Integer.valueOf(404)); // int: 0x00000194  float:0.000000
                code.visitLabel(L56);
                code.visitStmt2R1N(DIV_INT_LIT8,17,14,100);
                code.visitStmt2R1N(REM_INT_LIT8,17,17,10);
                code.visitStmt2R1N(ADD_INT_LIT8,17,17,48);
                code.visitStmt2R(MOVE_FROM16,0,17);
                code.visitStmt2R(INT_TO_CHAR,0,0);
                code.visitStmt2R(MOVE_FROM16,17,0);
                code.visitStmt2R(MOVE_OBJECT,0,6);
                code.visitStmt2R(MOVE_FROM16,1,17);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "C"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L57);
                code.visitStmt2R1N(DIV_INT_LIT8,17,14,10);
                code.visitStmt2R1N(REM_INT_LIT8,17,17,10);
                code.visitStmt2R1N(ADD_INT_LIT8,17,17,48);
                code.visitStmt2R(MOVE_FROM16,0,17);
                code.visitStmt2R(INT_TO_CHAR,0,0);
                code.visitStmt2R(MOVE_FROM16,17,0);
                code.visitStmt2R(MOVE_OBJECT,0,6);
                code.visitStmt2R(MOVE_FROM16,1,17);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "C"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L58);
                code.visitStmt2R1N(REM_INT_LIT8,17,14,10);
                code.visitStmt2R1N(ADD_INT_LIT8,17,17,48);
                code.visitStmt2R(MOVE_FROM16,0,17);
                code.visitStmt2R(INT_TO_CHAR,0,0);
                code.visitStmt2R(MOVE_FROM16,17,0);
                code.visitStmt2R(MOVE_OBJECT,0,6);
                code.visitStmt2R(MOVE_FROM16,1,17);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "C"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L59);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 25},new Method("Lorg/mortbay/jetty/Response;","getContentCount",new String[]{ },"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,11);
                code.visitLabel(L60);
                code.visitConstStmt(CONST_WIDE_16,17,Long.valueOf(0L)); // long: 0x0000000000000000  double:0.000000
                code.visitStmt3R(CMP_LONG,17,11,17);
                code.visitJumpStmt(IF_LTZ,17,-1,L86);
                code.visitLabel(L61);
                code.visitConstStmt(CONST_16,17, Integer.valueOf(32)); // int: 0x00000020  float:0.000000
                code.visitStmt2R(MOVE_OBJECT,0,6);
                code.visitStmt2R(MOVE_FROM16,1,17);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "C"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L62);
                code.visitConstStmt(CONST_WIDE_32,17,Long.valueOf(99999L)); // long: 0x000000000001869f  double:0.000000
                code.visitStmt3R(CMP_LONG,17,11,17);
                code.visitJumpStmt(IF_LEZ,17,-1,L16);
                code.visitLabel(L63);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 11,12},new Method("Ljava/lang/Long;","toString",new String[]{ "J"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,17);
                code.visitStmt2R(MOVE_OBJECT,0,6);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,17);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L64);
                code.visitConstStmt(CONST_16,17, Integer.valueOf(32)); // int: 0x00000020  float:0.000000
                code.visitStmt2R(MOVE_OBJECT,0,6);
                code.visitStmt2R(MOVE_FROM16,1,17);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "C"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L65);
                code.visitStmt1R(MONITOR_EXIT,6);
                code.visitLabel(L6);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,23);
                code.visitFieldStmt(IGET_BOOLEAN,0,0,new Field("Lorg/mortbay/jetty/NCSARequestLog;","_extended","Z"));
                code.visitStmt2R(MOVE_FROM16,17,0);
                code.visitJumpStmt(IF_NEZ,17,-1,L19);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,23);
                code.visitFieldStmt(IGET_BOOLEAN,0,0,new Field("Lorg/mortbay/jetty/NCSARequestLog;","_logCookies","Z"));
                code.visitStmt2R(MOVE_FROM16,17,0);
                code.visitJumpStmt(IF_NEZ,17,-1,L19);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,23);
                code.visitFieldStmt(IGET_BOOLEAN,0,0,new Field("Lorg/mortbay/jetty/NCSARequestLog;","_logLatency","Z"));
                code.visitStmt2R(MOVE_FROM16,17,0);
                code.visitJumpStmt(IF_NEZ,17,-1,L19);
                code.visitLabel(L66);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,23);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/NCSARequestLog;","_writer","Ljava/io/Writer;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,17,0);
                code.visitStmt1R(MONITOR_ENTER,17);
                code.visitLabel(L8);
                code.visitFieldStmt(SGET_OBJECT,18,-1,new Field("Lorg/mortbay/util/StringUtil;","__LINE_SEPARATOR","Ljava/lang/String;"));
                code.visitStmt2R(MOVE_OBJECT,0,6);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,18);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L67);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/lang/StringBuffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,10);
                code.visitLabel(L68);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,23);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/NCSARequestLog;","_copy","[C"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,18,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,18);
                code.visitStmt2R(ARRAY_LENGTH,0,0);
                code.visitStmt2R(MOVE_FROM16,18,0);
                code.visitStmt2R(MOVE,0,10);
                code.visitStmt2R(MOVE_FROM16,1,18);
                code.visitJumpStmt(IF_LE,0,1,L70);
                code.visitLabel(L69);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,23);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/NCSARequestLog;","_copy","[C"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,18,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,18);
                code.visitStmt2R(ARRAY_LENGTH,0,0);
                code.visitStmt2R(MOVE,10,0);
                code.visitLabel(L70);
                code.visitConstStmt(CONST_16,18, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,23);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/NCSARequestLog;","_copy","[C"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,19,0);
                code.visitConstStmt(CONST_16,20, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt2R(MOVE_OBJECT,0,6);
                code.visitStmt2R(MOVE_FROM16,1,18);
                code.visitStmt2R(MOVE,2,10);
                code.visitStmt2R(MOVE_OBJECT_FROM16,3,19);
                code.visitStmt2R(MOVE_FROM16,4,20);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2,3,4},new Method("Ljava/lang/StringBuffer;","getChars",new String[]{ "I","I","[C","I"},"V"));
                code.visitLabel(L71);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,23);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/NCSARequestLog;","_writer","Ljava/io/Writer;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,18,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,23);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/NCSARequestLog;","_copy","[C"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,19,0);
                code.visitConstStmt(CONST_16,20, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,18);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,19);
                code.visitStmt2R(MOVE_FROM16,2,20);
                code.visitStmt2R(MOVE,3,10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2,3},new Method("Ljava/io/Writer;","write",new String[]{ "[C","I","I"},"V"));
                code.visitLabel(L72);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,23);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/NCSARequestLog;","_writer","Ljava/io/Writer;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,18,0);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 18},new Method("Ljava/io/Writer;","flush",new String[]{ },"V"));
                code.visitLabel(L73);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 15},new Method("Lorg/mortbay/util/Utf8StringBuffer;","reset",new String[]{ },"V"));
                code.visitLabel(L74);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,23);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/NCSARequestLog;","_buffers","Ljava/util/ArrayList;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,18,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,18);
                code.visitStmt2R(MOVE_OBJECT,1,15);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/util/ArrayList;","add",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitLabel(L75);
                code.visitStmt1R(MONITOR_EXIT,17);
                code.visitJumpStmt(GOTO_16,-1,-1,L26);
                code.visitLabel(L10);
                code.visitStmt1R(MOVE_EXCEPTION,18);
                code.visitStmt1R(MONITOR_EXIT,17);
                code.visitLabel(L9);
                code.visitStmt1R(THROW,18);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,17);
                code.visitStmt2R(MOVE_OBJECT_FROM16,8,17);
                code.visitLabel(L76);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 8},new Method("Lorg/mortbay/log/Log;","warn",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitJumpStmt(GOTO_16,-1,-1,L26);
                code.visitLabel(L11);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,23);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/NCSARequestLog;","_buffers","Ljava/util/ArrayList;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,18,0);
                code.visitConstStmt(CONST_16,19, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt3R(SUB_INT,19,13,19);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 18,19},new Method("Ljava/util/ArrayList;","remove",new String[]{ "I"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitTypeStmt(CHECK_CAST,5,-1,"Lorg/mortbay/util/Utf8StringBuffer;");
                code.visitStmt2R(MOVE_OBJECT,15,5);
                code.visitJumpStmt(GOTO_16,-1,-1,L30);
                code.visitLabel(L4);
                code.visitStmt1R(MOVE_EXCEPTION,18);
                code.visitStmt1R(MONITOR_EXIT,17);
                code.visitLabel(L12);
                code.visitStmt1R(THROW,18);
                code.visitLabel(L13);
                code.visitStmt2R(MOVE_OBJECT_FROM16,17,16);
                code.visitLabel(L77);
                code.visitJumpStmt(GOTO_16,-1,-1,L114);
                code.visitLabel(L14);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 24},new Method("Lorg/mortbay/jetty/Request;","getTimeStampBuffer",new String[]{ },"Lorg/mortbay/io/Buffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,17);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 17},new Method("Ljava/lang/Object;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,17);
                code.visitStmt2R(MOVE_OBJECT,0,6);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,17);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitJumpStmt(GOTO_16,-1,-1,L46);
                code.visitLabel(L7);
                code.visitStmt1R(MOVE_EXCEPTION,17);
                code.visitStmt1R(MONITOR_EXIT,6);
                code.visitLabel(L15);
                code.visitStmt1R(THROW,17);
                code.visitLabel(L16);
                code.visitConstStmt(CONST_WIDE_16,17,Long.valueOf(9999L)); // long: 0x000000000000270f  double:0.000000
                code.visitStmt3R(CMP_LONG,17,11,17);
                code.visitJumpStmt(IF_LEZ,17,-1,L79);
                code.visitLabel(L78);
                code.visitConstStmt(CONST_WIDE_16,17,Long.valueOf(48L)); // long: 0x0000000000000030  double:0.000000
                code.visitConstStmt(CONST_WIDE_16,19,Long.valueOf(10000L)); // long: 0x0000000000002710  double:0.000000
                code.visitLabel(L17);
                code.visitStmt3R(DIV_LONG,19,11,19);
                code.visitConstStmt(CONST_WIDE_16,21,Long.valueOf(10L)); // long: 0x000000000000000a  double:0.000000
                code.visitStmt3R(REM_LONG,19,19,21);
                code.visitStmt3R(ADD_LONG,17,17,19);
                code.visitStmt2R(MOVE_WIDE_FROM16,0,17);
                code.visitStmt2R(LONG_TO_INT,0,0);
                code.visitStmt2R(MOVE_FROM16,17,0);
                code.visitStmt2R(MOVE_FROM16,0,17);
                code.visitStmt2R(INT_TO_CHAR,0,0);
                code.visitStmt2R(MOVE_FROM16,17,0);
                code.visitStmt2R(MOVE_OBJECT,0,6);
                code.visitStmt2R(MOVE_FROM16,1,17);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "C"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L79);
                code.visitConstStmt(CONST_WIDE_16,17,Long.valueOf(999L)); // long: 0x00000000000003e7  double:0.000000
                code.visitStmt3R(CMP_LONG,17,11,17);
                code.visitJumpStmt(IF_LEZ,17,-1,L81);
                code.visitLabel(L80);
                code.visitConstStmt(CONST_WIDE_16,17,Long.valueOf(48L)); // long: 0x0000000000000030  double:0.000000
                code.visitConstStmt(CONST_WIDE_16,19,Long.valueOf(1000L)); // long: 0x00000000000003e8  double:0.000000
                code.visitStmt3R(DIV_LONG,19,11,19);
                code.visitConstStmt(CONST_WIDE_16,21,Long.valueOf(10L)); // long: 0x000000000000000a  double:0.000000
                code.visitStmt3R(REM_LONG,19,19,21);
                code.visitStmt3R(ADD_LONG,17,17,19);
                code.visitStmt2R(MOVE_WIDE_FROM16,0,17);
                code.visitStmt2R(LONG_TO_INT,0,0);
                code.visitStmt2R(MOVE_FROM16,17,0);
                code.visitStmt2R(MOVE_FROM16,0,17);
                code.visitStmt2R(INT_TO_CHAR,0,0);
                code.visitStmt2R(MOVE_FROM16,17,0);
                code.visitStmt2R(MOVE_OBJECT,0,6);
                code.visitStmt2R(MOVE_FROM16,1,17);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "C"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L81);
                code.visitConstStmt(CONST_WIDE_16,17,Long.valueOf(99L)); // long: 0x0000000000000063  double:0.000000
                code.visitStmt3R(CMP_LONG,17,11,17);
                code.visitJumpStmt(IF_LEZ,17,-1,L83);
                code.visitLabel(L82);
                code.visitConstStmt(CONST_WIDE_16,17,Long.valueOf(48L)); // long: 0x0000000000000030  double:0.000000
                code.visitConstStmt(CONST_WIDE_16,19,Long.valueOf(100L)); // long: 0x0000000000000064  double:0.000000
                code.visitStmt3R(DIV_LONG,19,11,19);
                code.visitConstStmt(CONST_WIDE_16,21,Long.valueOf(10L)); // long: 0x000000000000000a  double:0.000000
                code.visitStmt3R(REM_LONG,19,19,21);
                code.visitStmt3R(ADD_LONG,17,17,19);
                code.visitStmt2R(MOVE_WIDE_FROM16,0,17);
                code.visitStmt2R(LONG_TO_INT,0,0);
                code.visitStmt2R(MOVE_FROM16,17,0);
                code.visitStmt2R(MOVE_FROM16,0,17);
                code.visitStmt2R(INT_TO_CHAR,0,0);
                code.visitStmt2R(MOVE_FROM16,17,0);
                code.visitStmt2R(MOVE_OBJECT,0,6);
                code.visitStmt2R(MOVE_FROM16,1,17);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "C"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L83);
                code.visitConstStmt(CONST_WIDE_16,17,Long.valueOf(9L)); // long: 0x0000000000000009  double:0.000000
                code.visitStmt3R(CMP_LONG,17,11,17);
                code.visitJumpStmt(IF_LEZ,17,-1,L85);
                code.visitLabel(L84);
                code.visitConstStmt(CONST_WIDE_16,17,Long.valueOf(48L)); // long: 0x0000000000000030  double:0.000000
                code.visitConstStmt(CONST_WIDE_16,19,Long.valueOf(10L)); // long: 0x000000000000000a  double:0.000000
                code.visitStmt3R(DIV_LONG,19,11,19);
                code.visitConstStmt(CONST_WIDE_16,21,Long.valueOf(10L)); // long: 0x000000000000000a  double:0.000000
                code.visitStmt3R(REM_LONG,19,19,21);
                code.visitStmt3R(ADD_LONG,17,17,19);
                code.visitStmt2R(MOVE_WIDE_FROM16,0,17);
                code.visitStmt2R(LONG_TO_INT,0,0);
                code.visitStmt2R(MOVE_FROM16,17,0);
                code.visitStmt2R(MOVE_FROM16,0,17);
                code.visitStmt2R(INT_TO_CHAR,0,0);
                code.visitStmt2R(MOVE_FROM16,17,0);
                code.visitStmt2R(MOVE_OBJECT,0,6);
                code.visitStmt2R(MOVE_FROM16,1,17);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "C"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L85);
                code.visitConstStmt(CONST_WIDE_16,17,Long.valueOf(48L)); // long: 0x0000000000000030  double:0.000000
                code.visitConstStmt(CONST_WIDE_16,19,Long.valueOf(10L)); // long: 0x000000000000000a  double:0.000000
                code.visitStmt3R(REM_LONG,19,11,19);
                code.visitStmt3R(ADD_LONG,17,17,19);
                code.visitStmt2R(MOVE_WIDE_FROM16,0,17);
                code.visitStmt2R(LONG_TO_INT,0,0);
                code.visitStmt2R(MOVE_FROM16,17,0);
                code.visitStmt2R(MOVE_FROM16,0,17);
                code.visitStmt2R(INT_TO_CHAR,0,0);
                code.visitStmt2R(MOVE_FROM16,17,0);
                code.visitStmt2R(MOVE_OBJECT,0,6);
                code.visitStmt2R(MOVE_FROM16,1,17);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "C"},"Ljava/lang/StringBuffer;"));
                code.visitJumpStmt(GOTO_16,-1,-1,L64);
                code.visitLabel(L86);
                code.visitConstStmt(CONST_STRING,17," - ");
                code.visitStmt2R(MOVE_OBJECT,0,6);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,17);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L18);
                code.visitJumpStmt(GOTO_16,-1,-1,L65);
                code.visitLabel(L19);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,23);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/NCSARequestLog;","_writer","Ljava/io/Writer;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,17,0);
                code.visitStmt1R(MONITOR_ENTER,17);
                code.visitLabel(L20);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/lang/StringBuffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,10);
                code.visitLabel(L87);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,23);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/NCSARequestLog;","_copy","[C"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,18,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,18);
                code.visitStmt2R(ARRAY_LENGTH,0,0);
                code.visitStmt2R(MOVE_FROM16,18,0);
                code.visitStmt2R(MOVE,0,10);
                code.visitStmt2R(MOVE_FROM16,1,18);
                code.visitJumpStmt(IF_LE,0,1,L89);
                code.visitLabel(L88);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,23);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/NCSARequestLog;","_copy","[C"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,18,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,18);
                code.visitStmt2R(ARRAY_LENGTH,0,0);
                code.visitStmt2R(MOVE,10,0);
                code.visitLabel(L89);
                code.visitConstStmt(CONST_16,18, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,23);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/NCSARequestLog;","_copy","[C"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,19,0);
                code.visitConstStmt(CONST_16,20, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt2R(MOVE_OBJECT,0,6);
                code.visitStmt2R(MOVE_FROM16,1,18);
                code.visitStmt2R(MOVE,2,10);
                code.visitStmt2R(MOVE_OBJECT_FROM16,3,19);
                code.visitStmt2R(MOVE_FROM16,4,20);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2,3,4},new Method("Ljava/lang/StringBuffer;","getChars",new String[]{ "I","I","[C","I"},"V"));
                code.visitLabel(L90);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,23);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/NCSARequestLog;","_writer","Ljava/io/Writer;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,18,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,23);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/NCSARequestLog;","_copy","[C"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,19,0);
                code.visitConstStmt(CONST_16,20, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,18);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,19);
                code.visitStmt2R(MOVE_FROM16,2,20);
                code.visitStmt2R(MOVE,3,10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2,3},new Method("Ljava/io/Writer;","write",new String[]{ "[C","I","I"},"V"));
                code.visitLabel(L91);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 15},new Method("Lorg/mortbay/util/Utf8StringBuffer;","reset",new String[]{ },"V"));
                code.visitLabel(L92);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,23);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/NCSARequestLog;","_buffers","Ljava/util/ArrayList;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,18,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,18);
                code.visitStmt2R(MOVE_OBJECT,1,15);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/util/ArrayList;","add",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitLabel(L93);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,23);
                code.visitFieldStmt(IGET_BOOLEAN,0,0,new Field("Lorg/mortbay/jetty/NCSARequestLog;","_extended","Z"));
                code.visitStmt2R(MOVE_FROM16,18,0);
                code.visitJumpStmt(IF_EQZ,18,-1,L95);
                code.visitLabel(L94);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,23);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/NCSARequestLog;","_writer","Ljava/io/Writer;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,18,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,23);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,24);
                code.visitStmt2R(MOVE_OBJECT_FROM16,2,25);
                code.visitStmt2R(MOVE_OBJECT_FROM16,3,18);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2,3},new Method("Lorg/mortbay/jetty/NCSARequestLog;","logExtended",new String[]{ "Lorg/mortbay/jetty/Request;","Lorg/mortbay/jetty/Response;","Ljava/io/Writer;"},"V"));
                code.visitLabel(L95);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,23);
                code.visitFieldStmt(IGET_BOOLEAN,0,0,new Field("Lorg/mortbay/jetty/NCSARequestLog;","_logCookies","Z"));
                code.visitStmt2R(MOVE_FROM16,18,0);
                code.visitJumpStmt(IF_EQZ,18,-1,L99);
                code.visitLabel(L96);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 24},new Method("Lorg/mortbay/jetty/Request;","getCookies",new String[]{ },"[Ljavax/servlet/http/Cookie;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitLabel(L97);
                code.visitJumpStmt(IF_EQZ,7,-1,L98);
                code.visitStmt2R(MOVE_OBJECT,0,7);
                code.visitStmt2R(ARRAY_LENGTH,0,0);
                code.visitStmt2R(MOVE_FROM16,18,0);
                code.visitJumpStmt(IF_NEZ,18,-1,L23);
                code.visitLabel(L98);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,23);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/NCSARequestLog;","_writer","Ljava/io/Writer;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,18,0);
                code.visitConstStmt(CONST_STRING,19," -");
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 18,19},new Method("Ljava/io/Writer;","write",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L99);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,23);
                code.visitFieldStmt(IGET_BOOLEAN,0,0,new Field("Lorg/mortbay/jetty/NCSARequestLog;","_logLatency","Z"));
                code.visitStmt2R(MOVE_FROM16,18,0);
                code.visitJumpStmt(IF_EQZ,18,-1,L102);
                code.visitLabel(L100);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,23);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/NCSARequestLog;","_writer","Ljava/io/Writer;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,18,0);
                code.visitConstStmt(CONST_16,19, Integer.valueOf(32)); // int: 0x00000020  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 18,19},new Method("Ljava/io/Writer;","write",new String[]{ "I"},"V"));
                code.visitLabel(L101);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,23);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/NCSARequestLog;","_writer","Ljava/io/Writer;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,18,0);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Ljava/lang/System;","currentTimeMillis",new String[]{ },"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,19);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 24},new Method("Lorg/mortbay/jetty/Request;","getTimeStamp",new String[]{ },"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,21);
                code.visitStmt3R(SUB_LONG,19,19,21);
                code.visitMethodStmt(INVOKE_STATIC_RANGE,new int[]{ 19,20},new Method("Lorg/mortbay/util/TypeUtil;","toString",new String[]{ "J"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,19);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 18,19},new Method("Ljava/io/Writer;","write",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L102);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,23);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/NCSARequestLog;","_writer","Ljava/io/Writer;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,18,0);
                code.visitFieldStmt(SGET_OBJECT,19,-1,new Field("Lorg/mortbay/util/StringUtil;","__LINE_SEPARATOR","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 18,19},new Method("Ljava/io/Writer;","write",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L103);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,23);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/NCSARequestLog;","_writer","Ljava/io/Writer;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,18,0);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 18},new Method("Ljava/io/Writer;","flush",new String[]{ },"V"));
                code.visitLabel(L104);
                code.visitStmt1R(MONITOR_EXIT,17);
                code.visitJumpStmt(GOTO_16,-1,-1,L26);
                code.visitLabel(L22);
                code.visitStmt1R(MOVE_EXCEPTION,18);
                code.visitStmt1R(MONITOR_EXIT,17);
                code.visitLabel(L21);
                code.visitStmt1R(THROW,18);
                code.visitLabel(L23);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,23);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/NCSARequestLog;","_writer","Ljava/io/Writer;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,18,0);
                code.visitConstStmt(CONST_STRING,19," \"");
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 18,19},new Method("Ljava/io/Writer;","write",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L105);
                code.visitConstStmt(CONST_4,9, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L106);
                code.visitStmt2R(MOVE_OBJECT,0,7);
                code.visitStmt2R(ARRAY_LENGTH,0,0);
                code.visitStmt2R(MOVE_FROM16,18,0);
                code.visitStmt2R(MOVE,0,9);
                code.visitStmt2R(MOVE_FROM16,1,18);
                code.visitJumpStmt(IF_GE,0,1,L113);
                code.visitLabel(L107);
                code.visitJumpStmt(IF_EQZ,9,-1,L109);
                code.visitLabel(L108);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,23);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/NCSARequestLog;","_writer","Ljava/io/Writer;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,18,0);
                code.visitConstStmt(CONST_16,19, Integer.valueOf(59)); // int: 0x0000003b  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 18,19},new Method("Ljava/io/Writer;","write",new String[]{ "I"},"V"));
                code.visitLabel(L109);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,23);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/NCSARequestLog;","_writer","Ljava/io/Writer;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,18,0);
                code.visitStmt3R(AGET_OBJECT,19,7,9);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 19},new Method("Ljavax/servlet/http/Cookie;","getName",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,19);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 18,19},new Method("Ljava/io/Writer;","write",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L110);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,23);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/NCSARequestLog;","_writer","Ljava/io/Writer;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,18,0);
                code.visitConstStmt(CONST_16,19, Integer.valueOf(61)); // int: 0x0000003d  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 18,19},new Method("Ljava/io/Writer;","write",new String[]{ "I"},"V"));
                code.visitLabel(L111);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,23);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/NCSARequestLog;","_writer","Ljava/io/Writer;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,18,0);
                code.visitStmt3R(AGET_OBJECT,19,7,9);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 19},new Method("Ljavax/servlet/http/Cookie;","getValue",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,19);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 18,19},new Method("Ljava/io/Writer;","write",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L112);
                code.visitStmt2R1N(ADD_INT_LIT8,9,9,1);
                code.visitJumpStmt(GOTO,-1,-1,L106);
                code.visitLabel(L113);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,23);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/NCSARequestLog;","_writer","Ljava/io/Writer;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,18,0);
                code.visitConstStmt(CONST_16,19, Integer.valueOf(34)); // int: 0x00000022  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 18,19},new Method("Ljava/io/Writer;","write",new String[]{ "I"},"V"));
                code.visitLabel(L24);
                code.visitJumpStmt(GOTO_16,-1,-1,L99);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m018_logExtended(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/NCSARequestLog;","logExtended",new String[]{ "Lorg/mortbay/jetty/Request;","Lorg/mortbay/jetty/Response;","Ljava/io/Writer;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(9);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"request");
                ddv.visitParameterName(1,"response");
                ddv.visitParameterName(2,"writer");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(396,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(397,L2);
                ddv.visitStartLocal(1,L2,"referer","Ljava/lang/String;",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(398,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(406,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(407,L5);
                ddv.visitStartLocal(0,L5,"agent","Ljava/lang/String;",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(408,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(415,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(401,L8);
                ddv.visitEndLocal(0,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(402,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(403,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(411,L11);
                ddv.visitRestartLocal(0,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(412,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(413,L13);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_16,3, Integer.valueOf(34)); // int: 0x00000022  float:0.000000
                code.visitConstStmt(CONST_STRING,4,"\"-\" ");
                code.visitLabel(L1);
                code.visitConstStmt(CONST_STRING,2,"Referer");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,2},new Method("Lorg/mortbay/jetty/Request;","getHeader",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L2);
                code.visitJumpStmt(IF_NEZ,1,-1,L8);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_STRING,2,"\"-\" ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,4},new Method("Ljava/io/Writer;","write",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L4);
                code.visitConstStmt(CONST_STRING,2,"User-Agent");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,2},new Method("Lorg/mortbay/jetty/Request;","getHeader",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L5);
                code.visitJumpStmt(IF_NEZ,0,-1,L11);
                code.visitLabel(L6);
                code.visitConstStmt(CONST_STRING,2,"\"-\" ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,4},new Method("Ljava/io/Writer;","write",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L7);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,3},new Method("Ljava/io/Writer;","write",new String[]{ "I"},"V"));
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,1},new Method("Ljava/io/Writer;","write",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L10);
                code.visitConstStmt(CONST_STRING,2,"\" ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,2},new Method("Ljava/io/Writer;","write",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitLabel(L11);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,3},new Method("Ljava/io/Writer;","write",new String[]{ "I"},"V"));
                code.visitLabel(L12);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,0},new Method("Ljava/io/Writer;","write",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L13);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,3},new Method("Ljava/io/Writer;","write",new String[]{ "I"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L7);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m019_setAppend(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/NCSARequestLog;","setAppend",new String[]{ "Z"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"append");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(176,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(177,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_BOOLEAN,1,0,new Field("Lorg/mortbay/jetty/NCSARequestLog;","_append","Z"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m020_setExtended(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/NCSARequestLog;","setExtended",new String[]{ "Z"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"extended");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(166,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(167,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_BOOLEAN,1,0,new Field("Lorg/mortbay/jetty/NCSARequestLog;","_extended","Z"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m021_setFilename(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/NCSARequestLog;","setFilename",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"filename");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(98,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(100,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(101,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(102,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(104,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(105,L5);
                code.visitLabel(L0);
                code.visitJumpStmt(IF_EQZ,2,-1,L4);
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/lang/String;","trim",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_NEZ,0,-1,L4);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L4);
                code.visitFieldStmt(IPUT_OBJECT,2,1,new Field("Lorg/mortbay/jetty/NCSARequestLog;","_filename","Ljava/lang/String;"));
                code.visitLabel(L5);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m022_setFilenameDateFormat(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/NCSARequestLog;","setFilenameDateFormat",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"logFileDateFormat");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(485,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(486,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/NCSARequestLog;","_filenameDateFormat","Ljava/lang/String;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m023_setIgnorePaths(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/NCSARequestLog;","setIgnorePaths",new String[]{ "[Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"ignorePaths");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(186,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(187,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/NCSARequestLog;","_ignorePaths","[Ljava/lang/String;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m024_setLogCookies(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/NCSARequestLog;","setLogCookies",new String[]{ "Z"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"logCookies");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(196,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(197,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_BOOLEAN,1,0,new Field("Lorg/mortbay/jetty/NCSARequestLog;","_logCookies","Z"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m025_setLogDateFormat(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/NCSARequestLog;","setLogDateFormat",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"format");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(126,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(127,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/NCSARequestLog;","_logDateFormat","Ljava/lang/String;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m026_setLogLatency(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/NCSARequestLog;","setLogLatency",new String[]{ "Z"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"logLatency");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(216,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(217,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_BOOLEAN,1,0,new Field("Lorg/mortbay/jetty/NCSARequestLog;","_logLatency","Z"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m027_setLogLocale(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/NCSARequestLog;","setLogLocale",new String[]{ "Ljava/util/Locale;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"logLocale");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(136,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(137,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/NCSARequestLog;","_logLocale","Ljava/util/Locale;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m028_setLogServer(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/NCSARequestLog;","setLogServer",new String[]{ "Z"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"logServer");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(211,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(212,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_BOOLEAN,1,0,new Field("Lorg/mortbay/jetty/NCSARequestLog;","_logServer","Z"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m029_setLogTimeZone(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/NCSARequestLog;","setLogTimeZone",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"tz");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(146,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(147,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/NCSARequestLog;","_logTimeZone","Ljava/lang/String;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m030_setPreferProxiedForAddress(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/NCSARequestLog;","setPreferProxiedForAddress",new String[]{ "Z"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"preferProxiedForAddress");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(226,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(227,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_BOOLEAN,1,0,new Field("Lorg/mortbay/jetty/NCSARequestLog;","_preferProxiedForAddress","Z"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m031_setRetainDays(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/NCSARequestLog;","setRetainDays",new String[]{ "I"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"retainDays");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(156,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(157,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT,1,0,new Field("Lorg/mortbay/jetty/NCSARequestLog;","_retainDays","I"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
