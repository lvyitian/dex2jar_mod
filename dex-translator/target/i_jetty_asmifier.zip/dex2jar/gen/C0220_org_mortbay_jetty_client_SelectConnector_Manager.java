package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0220_org_mortbay_jetty_client_SelectConnector_Manager {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(0,"Lorg/mortbay/jetty/client/SelectConnector$Manager;","Lorg/mortbay/io/nio/SelectorManager;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("SelectConnector.java");
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/EnclosingClass;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("value", new DexType("Lorg/mortbay/jetty/client/SelectConnector;"));
                av00.visitEnd();
            }
        }
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/InnerClass;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("accessFlags",  Integer.valueOf(0));
                av00.visit("name", "Manager");
                av00.visitEnd();
            }
        }
        f000_this$0(cv);
        m000__init_(cv);
        m001_newSslEngine(cv);
        m002_acceptChannel(cv);
        m003_connectionFailed(cv);
        m004_dispatch(cv);
        m005_endPointClosed(cv);
        m006_endPointOpened(cv);
        m007_newConnection(cv);
        m008_newEndPoint(cv);
    }
    public static void f000_this$0(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_FINAL|ACC_SYNTHETIC, new Field("Lorg/mortbay/jetty/client/SelectConnector$Manager;","this$0","Lorg/mortbay/jetty/client/SelectConnector;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/client/SelectConnector$Manager;","<init>",new String[]{ "Lorg/mortbay/jetty/client/SelectConnector;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(90,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/client/SelectConnector$Manager;","this$0","Lorg/mortbay/jetty/client/SelectConnector;"));
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Lorg/mortbay/io/nio/SelectorManager;","<init>",new String[]{ },"V"));
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001_newSslEngine(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PRIVATE, new Method("Lorg/mortbay/jetty/client/SelectConnector$Manager;","newSslEngine",new String[]{ },"Ljavax/net/ssl/SSLEngine;"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                code.visitTryCatch(L1,L3,new DexLabel[]{L4,L2},new String[]{ "Ljava/lang/Exception;",null});
                DexLabel L5=new DexLabel();
                code.visitTryCatch(L3,L5,new DexLabel[]{L2},new String[]{ null});
                DexLabel L6=new DexLabel();
                code.visitTryCatch(L6,L2,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L7=new DexLabel();
                ddv.visitPrologue(L7);
                ddv.visitLineNumber(149,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(151,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(154,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(155,L10);
                ddv.visitStartLocal(2,L10,"sslEngine","Ljavax/net/ssl/SSLEngine;",null);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(156,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(158,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(160,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(168,L14);
                ddv.visitStartLocal(0,L14,"buffers","Lorg/mortbay/jetty/AbstractBuffers;",null);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(169,L15);
                ddv.visitLineNumber(173,L1);
                ddv.visitLineNumber(179,L3);
                ddv.visitLineNumber(182,L5);
                ddv.visitEndLocal(0,L5);
                ddv.visitLineNumber(175,L4);
                ddv.visitRestartLocal(0,L4);
                ddv.visitLineNumber(177,L6);
                ddv.visitStartLocal(1,L6,"e","Ljava/lang/Exception;",null);
                ddv.visitLineNumber(149,L2);
                ddv.visitEndLocal(2,L2);
                ddv.visitEndLocal(0,L2);
                ddv.visitEndLocal(1,L2);
                code.visitLabel(L7);
                code.visitStmt1R(MONITOR_ENTER,5);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,3,5,new Field("Lorg/mortbay/jetty/client/SelectConnector$Manager;","this$0","Lorg/mortbay/jetty/client/SelectConnector;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3},new Method("Lorg/mortbay/jetty/client/SelectConnector;","access$200",new String[]{ "Lorg/mortbay/jetty/client/SelectConnector;"},"Ljavax/net/ssl/SSLContext;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitJumpStmt(IF_NEZ,3,-1,L9);
                code.visitLabel(L8);
                code.visitFieldStmt(IGET_OBJECT,3,5,new Field("Lorg/mortbay/jetty/client/SelectConnector$Manager;","this$0","Lorg/mortbay/jetty/client/SelectConnector;"));
                code.visitFieldStmt(IGET_OBJECT,4,5,new Field("Lorg/mortbay/jetty/client/SelectConnector$Manager;","this$0","Lorg/mortbay/jetty/client/SelectConnector;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 4},new Method("Lorg/mortbay/jetty/client/SelectConnector;","access$000",new String[]{ "Lorg/mortbay/jetty/client/SelectConnector;"},"Lorg/mortbay/jetty/client/HttpClient;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/jetty/client/HttpClient;","getSSLContext",new String[]{ },"Ljavax/net/ssl/SSLContext;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3,4},new Method("Lorg/mortbay/jetty/client/SelectConnector;","access$202",new String[]{ "Lorg/mortbay/jetty/client/SelectConnector;","Ljavax/net/ssl/SSLContext;"},"Ljavax/net/ssl/SSLContext;"));
                code.visitLabel(L9);
                code.visitFieldStmt(IGET_OBJECT,3,5,new Field("Lorg/mortbay/jetty/client/SelectConnector$Manager;","this$0","Lorg/mortbay/jetty/client/SelectConnector;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3},new Method("Lorg/mortbay/jetty/client/SelectConnector;","access$200",new String[]{ "Lorg/mortbay/jetty/client/SelectConnector;"},"Ljavax/net/ssl/SSLContext;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljavax/net/ssl/SSLContext;","createSSLEngine",new String[]{ },"Ljavax/net/ssl/SSLEngine;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L10);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljavax/net/ssl/SSLEngine;","setUseClientMode",new String[]{ "Z"},"V"));
                code.visitLabel(L11);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljavax/net/ssl/SSLEngine;","beginHandshake",new String[]{ },"V"));
                code.visitLabel(L12);
                code.visitFieldStmt(IGET_OBJECT,3,5,new Field("Lorg/mortbay/jetty/client/SelectConnector$Manager;","this$0","Lorg/mortbay/jetty/client/SelectConnector;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3},new Method("Lorg/mortbay/jetty/client/SelectConnector;","access$100",new String[]{ "Lorg/mortbay/jetty/client/SelectConnector;"},"Lorg/mortbay/io/Buffers;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitJumpStmt(IF_NEZ,3,-1,L5);
                code.visitLabel(L13);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/jetty/client/SelectConnector$Manager$1;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,5},new Method("Lorg/mortbay/jetty/client/SelectConnector$Manager$1;","<init>",new String[]{ "Lorg/mortbay/jetty/client/SelectConnector$Manager;"},"V"));
                code.visitLabel(L14);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljavax/net/ssl/SSLEngine;","getSession",new String[]{ },"Ljavax/net/ssl/SSLSession;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3},new Method("Ljavax/net/ssl/SSLSession;","getPacketBufferSize",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,3},new Method("Lorg/mortbay/jetty/AbstractBuffers;","setRequestBufferSize",new String[]{ "I"},"V"));
                code.visitLabel(L15);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljavax/net/ssl/SSLEngine;","getSession",new String[]{ },"Ljavax/net/ssl/SSLSession;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3},new Method("Ljavax/net/ssl/SSLSession;","getApplicationBufferSize",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,3},new Method("Lorg/mortbay/jetty/AbstractBuffers;","setResponseBufferSize",new String[]{ "I"},"V"));
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/AbstractBuffers;","start",new String[]{ },"V"));
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,3,5,new Field("Lorg/mortbay/jetty/client/SelectConnector$Manager;","this$0","Lorg/mortbay/jetty/client/SelectConnector;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3,0},new Method("Lorg/mortbay/jetty/client/SelectConnector;","access$102",new String[]{ "Lorg/mortbay/jetty/client/SelectConnector;","Lorg/mortbay/io/Buffers;"},"Lorg/mortbay/io/Buffers;"));
                code.visitLabel(L5);
                code.visitStmt1R(MONITOR_EXIT,5);
                code.visitStmt1R(RETURN_OBJECT,2);
                code.visitLabel(L4);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitLabel(L6);
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Ljava/lang/IllegalStateException;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3,1},new Method("Ljava/lang/IllegalStateException;","<init>",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitStmt1R(THROW,3);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,3);
                code.visitStmt1R(MONITOR_EXIT,5);
                code.visitStmt1R(THROW,3);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_acceptChannel(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/client/SelectConnector$Manager;","acceptChannel",new String[]{ "Ljava/nio/channels/SelectionKey;"},"Ljava/nio/channels/SocketChannel;"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"key");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(94,L0);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/IllegalStateException;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/IllegalStateException;","<init>",new String[]{ },"V"));
                code.visitStmt1R(THROW,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_connectionFailed(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/client/SelectConnector$Manager;","connectionFailed",new String[]{ "Ljava/nio/channels/SocketChannel;","Ljava/lang/Throwable;","Ljava/lang/Object;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"channel");
                ddv.visitParameterName(1,"ex");
                ddv.visitParameterName(2,"attachment");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(191,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(192,L1);
                DexLabel L2=new DexLabel();
                ddv.visitEndLocal(4,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(195,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(194,L4);
                ddv.visitRestartLocal(4,L4);
                code.visitLabel(L0);
                code.visitTypeStmt(INSTANCE_OF,0,4,"Lorg/mortbay/jetty/client/HttpDestination;");
                code.visitJumpStmt(IF_EQZ,0,-1,L4);
                code.visitLabel(L1);
                code.visitTypeStmt(CHECK_CAST,4,-1,"Lorg/mortbay/jetty/client/HttpDestination;");
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,3},new Method("Lorg/mortbay/jetty/client/HttpDestination;","onConnectionFailed",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitLabel(L3);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3},new Method("Lorg/mortbay/log/Log;","warn",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_dispatch(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/client/SelectConnector$Manager;","dispatch",new String[]{ "Ljava/lang/Runnable;"},"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"task");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(99,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/client/SelectConnector$Manager;","this$0","Lorg/mortbay/jetty/client/SelectConnector;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/jetty/client/SelectConnector;","access$000",new String[]{ "Lorg/mortbay/jetty/client/SelectConnector;"},"Lorg/mortbay/jetty/client/HttpClient;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/client/HttpClient;","_threadPool","Lorg/mortbay/thread/ThreadPool;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,2},new Method("Lorg/mortbay/thread/ThreadPool;","dispatch",new String[]{ "Ljava/lang/Runnable;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_endPointClosed(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/client/SelectConnector$Manager;","endPointClosed",new String[]{ "Lorg/mortbay/io/nio/SelectChannelEndPoint;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"endpoint");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(108,L0);
                code.visitLabel(L0);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_endPointOpened(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/client/SelectConnector$Manager;","endPointOpened",new String[]{ "Lorg/mortbay/io/nio/SelectChannelEndPoint;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"endpoint");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(104,L0);
                code.visitLabel(L0);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m007_newConnection(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/client/SelectConnector$Manager;","newConnection",new String[]{ "Ljava/nio/channels/SocketChannel;","Lorg/mortbay/io/nio/SelectChannelEndPoint;"},"Lorg/mortbay/io/Connection;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"channel");
                ddv.visitParameterName(1,"endpoint");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(112,L0);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/jetty/client/HttpConnection;");
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/jetty/client/SelectConnector$Manager;","this$0","Lorg/mortbay/jetty/client/SelectConnector;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1},new Method("Lorg/mortbay/jetty/client/SelectConnector;","access$000",new String[]{ "Lorg/mortbay/jetty/client/SelectConnector;"},"Lorg/mortbay/jetty/client/HttpClient;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitFieldStmt(IGET_OBJECT,2,4,new Field("Lorg/mortbay/jetty/client/SelectConnector$Manager;","this$0","Lorg/mortbay/jetty/client/SelectConnector;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2},new Method("Lorg/mortbay/jetty/client/SelectConnector;","access$000",new String[]{ "Lorg/mortbay/jetty/client/SelectConnector;"},"Lorg/mortbay/jetty/client/HttpClient;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/client/HttpClient;","getHeaderBufferSize",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitFieldStmt(IGET_OBJECT,3,4,new Field("Lorg/mortbay/jetty/client/SelectConnector$Manager;","this$0","Lorg/mortbay/jetty/client/SelectConnector;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3},new Method("Lorg/mortbay/jetty/client/SelectConnector;","access$000",new String[]{ "Lorg/mortbay/jetty/client/SelectConnector;"},"Lorg/mortbay/jetty/client/HttpClient;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/jetty/client/HttpClient;","getRequestBufferSize",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1,6,2,3},new Method("Lorg/mortbay/jetty/client/HttpConnection;","<init>",new String[]{ "Lorg/mortbay/io/Buffers;","Lorg/mortbay/io/EndPoint;","I","I"},"V"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m008_newEndPoint(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/client/SelectConnector$Manager;","newEndPoint",new String[]{ "Ljava/nio/channels/SocketChannel;","Lorg/mortbay/io/nio/SelectorManager$SelectSet;","Ljava/nio/channels/SelectionKey;"},"Lorg/mortbay/io/nio/SelectChannelEndPoint;"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(13);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"channel");
                ddv.visitParameterName(1,"selectSet");
                ddv.visitParameterName(2,"key");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(118,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(121,L1);
                ddv.visitStartLocal(8,L1,"dest","Lorg/mortbay/jetty/client/HttpDestination;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(123,L2);
                ddv.visitStartLocal(0,L2,"ep","Lorg/mortbay/io/nio/SelectChannelEndPoint;",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(125,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(127,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(130,L5);
                ddv.visitStartLocal(6,L5,"connect","Ljava/lang/String;",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(133,L6);
                ddv.visitEndLocal(6,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(134,L7);
                ddv.visitStartLocal(5,L7,"engine","Ljavax/net/ssl/SSLEngine;",null);
                DexLabel L8=new DexLabel();
                ddv.visitEndLocal(0,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(141,L9);
                ddv.visitEndLocal(5,L9);
                ddv.visitRestartLocal(0,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(142,L10);
                ddv.visitStartLocal(7,L10,"connection","Lorg/mortbay/jetty/client/HttpConnection;",null);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(143,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(144,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(138,L13);
                ddv.visitEndLocal(7,L13);
                DexLabel L14=new DexLabel();
                ddv.visitEndLocal(0,L14);
                DexLabel L15=new DexLabel();
                ddv.visitRestartLocal(0,L15);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12},new Method("Ljava/nio/channels/SelectionKey;","attachment",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitTypeStmt(CHECK_CAST,8,-1,"Lorg/mortbay/jetty/client/HttpDestination;");
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Lorg/mortbay/jetty/client/HttpDestination;","isSecure",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_EQZ,1,-1,L13);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Lorg/mortbay/jetty/client/HttpDestination;","isProxied",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_EQZ,1,-1,L6);
                code.visitLabel(L4);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,2,"CONNECT ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Lorg/mortbay/jetty/client/HttpDestination;","getAddress",new String[]{ },"Lorg/mortbay/jetty/client/Address;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitConstStmt(CONST_STRING,2,"HTTP/1.0");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitConstStmt(CONST_STRING,2,"\r\n\r\n");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitLabel(L5);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/lang/IllegalStateException;");
                code.visitConstStmt(CONST_STRING,2,"Not Implemented");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,2},new Method("Ljava/lang/IllegalStateException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,1);
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 9},new Method("Lorg/mortbay/jetty/client/SelectConnector$Manager;","newSslEngine",new String[]{ },"Ljavax/net/ssl/SSLEngine;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitLabel(L7);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;");
                code.visitLabel(L8);
                code.visitFieldStmt(IGET_OBJECT,1,9,new Field("Lorg/mortbay/jetty/client/SelectConnector$Manager;","this$0","Lorg/mortbay/jetty/client/SelectConnector;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1},new Method("Lorg/mortbay/jetty/client/SelectConnector;","access$100",new String[]{ "Lorg/mortbay/jetty/client/SelectConnector;"},"Lorg/mortbay/io/Buffers;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitStmt2R(MOVE_OBJECT,2,10);
                code.visitStmt2R(MOVE_OBJECT,3,11);
                code.visitStmt2R(MOVE_OBJECT,4,12);
                code.visitMethodStmt(INVOKE_DIRECT_RANGE,new int[]{ 0,1,2,3,4,5},new Method("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","<init>",new String[]{ "Lorg/mortbay/io/Buffers;","Ljava/nio/channels/SocketChannel;","Lorg/mortbay/io/nio/SelectorManager$SelectSet;","Ljava/nio/channels/SelectionKey;","Ljavax/net/ssl/SSLEngine;"},"V"));
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/io/nio/SelectChannelEndPoint;","getConnection",new String[]{ },"Lorg/mortbay/io/Connection;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitTypeStmt(CHECK_CAST,7,-1,"Lorg/mortbay/jetty/client/HttpConnection;");
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,8},new Method("Lorg/mortbay/jetty/client/HttpConnection;","setDestination",new String[]{ "Lorg/mortbay/jetty/client/HttpDestination;"},"V"));
                code.visitLabel(L11);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,7},new Method("Lorg/mortbay/jetty/client/HttpDestination;","onNewConnection",new String[]{ "Lorg/mortbay/jetty/client/HttpConnection;"},"V"));
                code.visitLabel(L12);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L13);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/io/nio/SelectChannelEndPoint;");
                code.visitLabel(L14);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,10,11,12},new Method("Lorg/mortbay/io/nio/SelectChannelEndPoint;","<init>",new String[]{ "Ljava/nio/channels/SocketChannel;","Lorg/mortbay/io/nio/SelectorManager$SelectSet;","Ljava/nio/channels/SelectionKey;"},"V"));
                code.visitLabel(L15);
                code.visitJumpStmt(GOTO,-1,-1,L9);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
