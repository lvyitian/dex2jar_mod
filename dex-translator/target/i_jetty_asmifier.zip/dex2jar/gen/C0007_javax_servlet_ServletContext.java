package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0007_javax_servlet_ServletContext {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC|ACC_INTERFACE|ACC_ABSTRACT,"Ljavax/servlet/ServletContext;","Ljava/lang/Object;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("ServletContext.java");
        m000_getAttribute(cv);
        m001_getAttributeNames(cv);
        m002_getContext(cv);
        m003_getContextPath(cv);
        m004_getInitParameter(cv);
        m005_getInitParameterNames(cv);
        m006_getMajorVersion(cv);
        m007_getMimeType(cv);
        m008_getMinorVersion(cv);
        m009_getNamedDispatcher(cv);
        m010_getRealPath(cv);
        m011_getRequestDispatcher(cv);
        m012_getResource(cv);
        m013_getResourceAsStream(cv);
        m014_getResourcePaths(cv);
        m015_getServerInfo(cv);
        m016_getServlet(cv);
        m017_getServletContextName(cv);
        m018_getServletNames(cv);
        m019_getServlets(cv);
        m020_log(cv);
        m021_log(cv);
        m022_log(cv);
        m023_removeAttribute(cv);
        m024_setAttribute(cv);
    }
    public static void m000_getAttribute(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Ljavax/servlet/ServletContext;","getAttribute",new String[]{ "Ljava/lang/String;"},"Ljava/lang/Object;"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m001_getAttributeNames(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Ljavax/servlet/ServletContext;","getAttributeNames",new String[]{ },"Ljava/util/Enumeration;"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m002_getContext(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Ljavax/servlet/ServletContext;","getContext",new String[]{ "Ljava/lang/String;"},"Ljavax/servlet/ServletContext;"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m003_getContextPath(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Ljavax/servlet/ServletContext;","getContextPath",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m004_getInitParameter(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Ljavax/servlet/ServletContext;","getInitParameter",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m005_getInitParameterNames(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Ljavax/servlet/ServletContext;","getInitParameterNames",new String[]{ },"Ljava/util/Enumeration;"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m006_getMajorVersion(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Ljavax/servlet/ServletContext;","getMajorVersion",new String[]{ },"I"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m007_getMimeType(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Ljavax/servlet/ServletContext;","getMimeType",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m008_getMinorVersion(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Ljavax/servlet/ServletContext;","getMinorVersion",new String[]{ },"I"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m009_getNamedDispatcher(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Ljavax/servlet/ServletContext;","getNamedDispatcher",new String[]{ "Ljava/lang/String;"},"Ljavax/servlet/RequestDispatcher;"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m010_getRealPath(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Ljavax/servlet/ServletContext;","getRealPath",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m011_getRequestDispatcher(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Ljavax/servlet/ServletContext;","getRequestDispatcher",new String[]{ "Ljava/lang/String;"},"Ljavax/servlet/RequestDispatcher;"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m012_getResource(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Ljavax/servlet/ServletContext;","getResource",new String[]{ "Ljava/lang/String;"},"Ljava/net/URL;"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/net/MalformedURLException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            mv.visitEnd();
        }
    }
    public static void m013_getResourceAsStream(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Ljavax/servlet/ServletContext;","getResourceAsStream",new String[]{ "Ljava/lang/String;"},"Ljava/io/InputStream;"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m014_getResourcePaths(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Ljavax/servlet/ServletContext;","getResourcePaths",new String[]{ "Ljava/lang/String;"},"Ljava/util/Set;"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m015_getServerInfo(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Ljavax/servlet/ServletContext;","getServerInfo",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m016_getServlet(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Ljavax/servlet/ServletContext;","getServlet",new String[]{ "Ljava/lang/String;"},"Ljavax/servlet/Servlet;"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljavax/servlet/ServletException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            mv.visitEnd();
        }
    }
    public static void m017_getServletContextName(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Ljavax/servlet/ServletContext;","getServletContextName",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m018_getServletNames(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Ljavax/servlet/ServletContext;","getServletNames",new String[]{ },"Ljava/util/Enumeration;"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m019_getServlets(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Ljavax/servlet/ServletContext;","getServlets",new String[]{ },"Ljava/util/Enumeration;"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m020_log(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Ljavax/servlet/ServletContext;","log",new String[]{ "Ljava/lang/Exception;","Ljava/lang/String;"},"V"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m021_log(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Ljavax/servlet/ServletContext;","log",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m022_log(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Ljavax/servlet/ServletContext;","log",new String[]{ "Ljava/lang/String;","Ljava/lang/Throwable;"},"V"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m023_removeAttribute(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Ljavax/servlet/ServletContext;","removeAttribute",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m024_setAttribute(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Ljavax/servlet/ServletContext;","setAttribute",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"V"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
}
