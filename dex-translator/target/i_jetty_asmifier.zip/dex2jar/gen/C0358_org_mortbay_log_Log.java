package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0358_org_mortbay_log_Log {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/log/Log;","Ljava/lang/Object;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("Log.java");
        f000_EXCEPTION(cv);
        f001_IGNORED(cv);
        f002_IGNORED_FMT(cv);
        f003_NOT_IMPLEMENTED(cv);
        f004___ignored(cv);
        f005___log(cv);
        f006___logClass(cv);
        f007___nestedEx(cv);
        f008___noArgs(cv);
        f009___verbose(cv);
        m000__clinit_(cv);
        m001__init_(cv);
        m002_debug(cv);
        m003_debug(cv);
        m004_debug(cv);
        m005_debug(cv);
        m006_getLog(cv);
        m007_getLogger(cv);
        m008_ignore(cv);
        m009_info(cv);
        m010_info(cv);
        m011_info(cv);
        m012_isDebugEnabled(cv);
        m013_setLog(cv);
        m014_unwind(cv);
        m015_warn(cv);
        m016_warn(cv);
        m017_warn(cv);
        m018_warn(cv);
        m019_warn(cv);
    }
    public static void f000_EXCEPTION(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/log/Log;","EXCEPTION","Ljava/lang/String;"), "EXCEPTION ");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001_IGNORED(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/log/Log;","IGNORED","Ljava/lang/String;"), "IGNORED");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002_IGNORED_FMT(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/log/Log;","IGNORED_FMT","Ljava/lang/String;"), "IGNORED: {}");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003_NOT_IMPLEMENTED(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/log/Log;","NOT_IMPLEMENTED","Ljava/lang/String;"), "NOT IMPLEMENTED ");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f004___ignored(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC, new Field("Lorg/mortbay/log/Log;","__ignored","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f005___log(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC, new Field("Lorg/mortbay/log/Log;","__log","Lorg/mortbay/log/Logger;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f006___logClass(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC, new Field("Lorg/mortbay/log/Log;","__logClass","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f007___nestedEx(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/log/Log;","__nestedEx","[Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f008___noArgs(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/log/Log;","__noArgs","[Ljava/lang/Class;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f009___verbose(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC, new Field("Lorg/mortbay/log/Log;","__verbose","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__clinit_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/log/Log;","<clinit>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/lang/Throwable;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(36,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(39,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(53,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(64,L7);
                ddv.visitLineNumber(67,L0);
                ddv.visitStartLocal(1,L0,"log_class","Ljava/lang/Class;",null);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(68,L8);
                ddv.visitLineNumber(79,L1);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(80,L9);
                ddv.visitLineNumber(70,L2);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(72,L10);
                ddv.visitStartLocal(0,L10,"e","Ljava/lang/Throwable;",null);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(73,L11);
                ddv.visitRestartLocal(1,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(74,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(75,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(76,L14);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,5, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L4);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(4)); // int: 0x00000004  float:0.000000
                code.visitTypeStmt(NEW_ARRAY,2,2,"[Ljava/lang/String;");
                code.visitConstStmt(CONST_STRING,3,"getTargetException");
                code.visitStmt3R(APUT_OBJECT,3,2,5);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitConstStmt(CONST_STRING,4,"getTargetError");
                code.visitStmt3R(APUT_OBJECT,4,2,3);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitConstStmt(CONST_STRING,4,"getException");
                code.visitStmt3R(APUT_OBJECT,4,2,3);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(3)); // int: 0x00000003  float:0.000000
                code.visitConstStmt(CONST_STRING,4,"getRootCause");
                code.visitStmt3R(APUT_OBJECT,4,2,3);
                code.visitFieldStmt(SPUT_OBJECT,2,-1,new Field("Lorg/mortbay/log/Log;","__nestedEx","[Ljava/lang/String;"));
                code.visitLabel(L5);
                code.visitTypeStmt(NEW_ARRAY,2,5,"[Ljava/lang/Class;");
                code.visitFieldStmt(SPUT_OBJECT,2,-1,new Field("Lorg/mortbay/log/Log;","__noArgs","[Ljava/lang/Class;"));
                code.visitLabel(L6);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Lorg/mortbay/log/Log$1;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2},new Method("Lorg/mortbay/log/Log$1;","<init>",new String[]{ },"V"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2},new Method("Ljava/security/AccessController;","doPrivileged",new String[]{ "Ljava/security/PrivilegedAction;"},"Ljava/lang/Object;"));
                code.visitLabel(L7);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L0);
                code.visitConstStmt(CONST_CLASS,2,new DexType("Lorg/mortbay/log/Log;"));
                code.visitFieldStmt(SGET_OBJECT,3,-1,new Field("Lorg/mortbay/log/Log;","__logClass","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2,3},new Method("Lorg/mortbay/util/Loader;","loadClass",new String[]{ "Ljava/lang/Class;","Ljava/lang/String;"},"Ljava/lang/Class;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/lang/Class;","newInstance",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Lorg/mortbay/log/Logger;");
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/log/Log;","__log","Lorg/mortbay/log/Logger;"));
                code.visitLabel(L1);
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/log/Log;","__log","Lorg/mortbay/log/Logger;"));
                code.visitConstStmt(CONST_STRING,3,"Logging to {} via {}");
                code.visitFieldStmt(SGET_OBJECT,4,-1,new Field("Lorg/mortbay/log/Log;","__log","Lorg/mortbay/log/Logger;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/lang/Class;","getName",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2,3,4,5},new Method("Lorg/mortbay/log/Logger;","info",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L9);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,2);
                code.visitStmt2R(MOVE_OBJECT,0,2);
                code.visitLabel(L10);
                code.visitConstStmt(CONST_CLASS,1,new DexType("Lorg/mortbay/log/StdErrLog;"));
                code.visitLabel(L11);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Lorg/mortbay/log/StdErrLog;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2},new Method("Lorg/mortbay/log/StdErrLog;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(SPUT_OBJECT,2,-1,new Field("Lorg/mortbay/log/Log;","__log","Lorg/mortbay/log/Logger;"));
                code.visitLabel(L12);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/lang/Class;","getName",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitFieldStmt(SPUT_OBJECT,2,-1,new Field("Lorg/mortbay/log/Log;","__logClass","Ljava/lang/String;"));
                code.visitLabel(L13);
                code.visitFieldStmt(SGET_BOOLEAN,2,-1,new Field("Lorg/mortbay/log/Log;","__verbose","Z"));
                code.visitJumpStmt(IF_EQZ,2,-1,L1);
                code.visitLabel(L14);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/Throwable;","printStackTrace",new String[]{ },"V"));
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/log/Log;","<init>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(34,L0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/Object;","<init>",new String[]{ },"V"));
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_debug(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"msg");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(103,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(106,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(105,L3);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/log/Log;","__log","Lorg/mortbay/log/Logger;"));
                code.visitJumpStmt(IF_NEZ,0,-1,L3);
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L3);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/log/Log;","__log","Lorg/mortbay/log/Logger;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,2,1,1},new Method("Lorg/mortbay/log/Logger;","debug",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;","Ljava/lang/Object;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_debug(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"msg");
                ddv.visitParameterName(1,"arg");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(110,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(113,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(112,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/log/Log;","__log","Lorg/mortbay/log/Logger;"));
                code.visitJumpStmt(IF_NEZ,0,-1,L2);
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/log/Log;","__log","Lorg/mortbay/log/Logger;"));
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,2,3,1},new Method("Lorg/mortbay/log/Logger;","debug",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;","Ljava/lang/Object;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_debug(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;","Ljava/lang/Object;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"msg");
                ddv.visitParameterName(1,"arg0");
                ddv.visitParameterName(2,"arg1");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(117,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(120,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(119,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/log/Log;","__log","Lorg/mortbay/log/Logger;"));
                code.visitJumpStmt(IF_NEZ,0,-1,L2);
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/log/Log;","__log","Lorg/mortbay/log/Logger;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1,2,3},new Method("Lorg/mortbay/log/Logger;","debug",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;","Ljava/lang/Object;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_debug(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/Throwable;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"th");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(95,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(99,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(97,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(98,L3);
                code.visitLabel(L0);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/log/Log;","__log","Lorg/mortbay/log/Logger;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L1);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/log/Log;","isDebugEnabled",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_NEZ,0,-1,L2);
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/log/Log;","__log","Lorg/mortbay/log/Logger;"));
                code.visitConstStmt(CONST_STRING,1,"EXCEPTION ");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1,2},new Method("Lorg/mortbay/log/Logger;","debug",new String[]{ "Ljava/lang/String;","Ljava/lang/Throwable;"},"V"));
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2},new Method("Lorg/mortbay/log/Log;","unwind",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_getLog(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/log/Log;","getLog",new String[]{ },"Lorg/mortbay/log/Logger;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(89,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/log/Log;","__log","Lorg/mortbay/log/Logger;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m007_getLogger(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/log/Log;","getLogger",new String[]{ "Ljava/lang/String;"},"Lorg/mortbay/log/Logger;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(213,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(214,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(217,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(215,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(216,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(217,L5);
                code.visitLabel(L0);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/log/Log;","__log","Lorg/mortbay/log/Logger;"));
                code.visitJumpStmt(IF_NEZ,0,-1,L3);
                code.visitLabel(L1);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/log/Log;","__log","Lorg/mortbay/log/Logger;"));
                code.visitLabel(L2);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L3);
                code.visitJumpStmt(IF_NEZ,1,-1,L5);
                code.visitLabel(L4);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/log/Log;","__log","Lorg/mortbay/log/Logger;"));
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L5);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/log/Log;","__log","Lorg/mortbay/log/Logger;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1},new Method("Lorg/mortbay/log/Logger;","getLogger",new String[]{ "Ljava/lang/String;"},"Lorg/mortbay/log/Logger;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m008_ignore(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/log/Log;","ignore",new String[]{ "Ljava/lang/Throwable;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"th");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(129,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(141,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(131,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(133,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(134,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(136,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(138,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(139,L8);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_STRING,2,"IGNORED");
                code.visitLabel(L1);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/log/Log;","__log","Lorg/mortbay/log/Logger;"));
                code.visitJumpStmt(IF_NEZ,0,-1,L3);
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L3);
                code.visitFieldStmt(SGET_BOOLEAN,0,-1,new Field("Lorg/mortbay/log/Log;","__ignored","Z"));
                code.visitJumpStmt(IF_EQZ,0,-1,L6);
                code.visitLabel(L4);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/log/Log;","__log","Lorg/mortbay/log/Logger;"));
                code.visitConstStmt(CONST_STRING,1,"IGNORED");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,2,3},new Method("Lorg/mortbay/log/Logger;","warn",new String[]{ "Ljava/lang/String;","Ljava/lang/Throwable;"},"V"));
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3},new Method("Lorg/mortbay/log/Log;","unwind",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L6);
                code.visitFieldStmt(SGET_BOOLEAN,0,-1,new Field("Lorg/mortbay/log/Log;","__verbose","Z"));
                code.visitJumpStmt(IF_EQZ,0,-1,L2);
                code.visitLabel(L7);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/log/Log;","__log","Lorg/mortbay/log/Logger;"));
                code.visitConstStmt(CONST_STRING,1,"IGNORED");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,2,3},new Method("Lorg/mortbay/log/Logger;","debug",new String[]{ "Ljava/lang/String;","Ljava/lang/Throwable;"},"V"));
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3},new Method("Lorg/mortbay/log/Log;","unwind",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m009_info(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/log/Log;","info",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"msg");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(145,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(148,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(147,L3);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/log/Log;","__log","Lorg/mortbay/log/Logger;"));
                code.visitJumpStmt(IF_NEZ,0,-1,L3);
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L3);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/log/Log;","__log","Lorg/mortbay/log/Logger;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,2,1,1},new Method("Lorg/mortbay/log/Logger;","info",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;","Ljava/lang/Object;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m010_info(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/log/Log;","info",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"msg");
                ddv.visitParameterName(1,"arg");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(152,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(155,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(154,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/log/Log;","__log","Lorg/mortbay/log/Logger;"));
                code.visitJumpStmt(IF_NEZ,0,-1,L2);
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/log/Log;","__log","Lorg/mortbay/log/Logger;"));
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,2,3,1},new Method("Lorg/mortbay/log/Logger;","info",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;","Ljava/lang/Object;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m011_info(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/log/Log;","info",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;","Ljava/lang/Object;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"msg");
                ddv.visitParameterName(1,"arg0");
                ddv.visitParameterName(2,"arg1");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(159,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(162,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(161,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/log/Log;","__log","Lorg/mortbay/log/Logger;"));
                code.visitJumpStmt(IF_NEZ,0,-1,L2);
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/log/Log;","__log","Lorg/mortbay/log/Logger;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1,2,3},new Method("Lorg/mortbay/log/Logger;","info",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;","Ljava/lang/Object;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m012_isDebugEnabled(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/log/Log;","isDebugEnabled",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(166,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(167,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(168,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/log/Log;","__log","Lorg/mortbay/log/Logger;"));
                DexLabel L3=new DexLabel();
                code.visitJumpStmt(IF_NEZ,0,-1,L3);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L2);
                code.visitStmt1R(RETURN,0);
                code.visitLabel(L3);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/log/Log;","__log","Lorg/mortbay/log/Logger;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Lorg/mortbay/log/Logger;","isDebugEnabled",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m013_setLog(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/log/Log;","setLog",new String[]{ "Lorg/mortbay/log/Logger;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"log");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(84,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(85,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/log/Log;","__log","Lorg/mortbay/log/Logger;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m014_unwind(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PRIVATE|ACC_STATIC, new Method("Lorg/mortbay/log/Log;","unwind",new String[]{ "Ljava/lang/Throwable;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/lang/Exception;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"th");
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(222,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(235,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(224,L5);
                DexLabel L6=new DexLabel();
                ddv.visitStartLocal(1,L6,"i","I",null);
                ddv.visitLineNumber(228,L0);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(229,L7);
                ddv.visitStartLocal(0,L7,"get_target","Ljava/lang/reflect/Method;",null);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(230,L8);
                ddv.visitStartLocal(2,L8,"th2","Ljava/lang/Throwable;",null);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(231,L9);
                ddv.visitLineNumber(224,L1);
                ddv.visitEndLocal(0,L1);
                ddv.visitEndLocal(2,L1);
                ddv.visitLineNumber(233,L2);
                code.visitLabel(L3);
                code.visitJumpStmt(IF_NEZ,6,-1,L5);
                code.visitLabel(L4);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L5);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L6);
                code.visitFieldStmt(SGET_OBJECT,3,-1,new Field("Lorg/mortbay/log/Log;","__nestedEx","[Ljava/lang/String;"));
                code.visitStmt2R(ARRAY_LENGTH,3,3);
                code.visitJumpStmt(IF_GE,1,3,L4);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/lang/Object;","getClass",new String[]{ },"Ljava/lang/Class;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitFieldStmt(SGET_OBJECT,4,-1,new Field("Lorg/mortbay/log/Log;","__nestedEx","[Ljava/lang/String;"));
                code.visitStmt3R(AGET_OBJECT,4,4,1);
                code.visitFieldStmt(SGET_OBJECT,5,-1,new Field("Lorg/mortbay/log/Log;","__noArgs","[Ljava/lang/Class;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4,5},new Method("Ljava/lang/Class;","getMethod",new String[]{ "Ljava/lang/String;","[Ljava/lang/Class;"},"Ljava/lang/reflect/Method;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L7);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitTypeStmt(CHECK_CAST,3,-1,"[Ljava/lang/Object;");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,6,3},new Method("Ljava/lang/reflect/Method;","invoke",new String[]{ "Ljava/lang/Object;","[Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitTypeStmt(CHECK_CAST,2,-1,"Ljava/lang/Throwable;");
                code.visitLabel(L8);
                code.visitJumpStmt(IF_EQZ,2,-1,L1);
                code.visitJumpStmt(IF_EQ,2,6,L1);
                code.visitLabel(L9);
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,4,"Nested in ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,6},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitConstStmt(CONST_STRING,4,":");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3,2},new Method("Lorg/mortbay/log/Log;","warn",new String[]{ "Ljava/lang/String;","Ljava/lang/Throwable;"},"V"));
                code.visitLabel(L1);
                code.visitStmt2R1N(ADD_INT_LIT8,1,1,1);
                code.visitJumpStmt(GOTO,-1,-1,L6);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,3);
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m015_warn(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/log/Log;","warn",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"msg");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(173,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(176,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(175,L3);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/log/Log;","__log","Lorg/mortbay/log/Logger;"));
                code.visitJumpStmt(IF_NEZ,0,-1,L3);
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L3);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/log/Log;","__log","Lorg/mortbay/log/Logger;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,2,1,1},new Method("Lorg/mortbay/log/Logger;","warn",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;","Ljava/lang/Object;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m016_warn(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/log/Log;","warn",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"msg");
                ddv.visitParameterName(1,"arg");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(180,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(183,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(182,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/log/Log;","__log","Lorg/mortbay/log/Logger;"));
                code.visitJumpStmt(IF_NEZ,0,-1,L2);
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/log/Log;","__log","Lorg/mortbay/log/Logger;"));
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,2,3,1},new Method("Lorg/mortbay/log/Logger;","warn",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;","Ljava/lang/Object;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m017_warn(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/log/Log;","warn",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;","Ljava/lang/Object;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"msg");
                ddv.visitParameterName(1,"arg0");
                ddv.visitParameterName(2,"arg1");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(187,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(190,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(189,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/log/Log;","__log","Lorg/mortbay/log/Logger;"));
                code.visitJumpStmt(IF_NEZ,0,-1,L2);
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/log/Log;","__log","Lorg/mortbay/log/Logger;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1,2,3},new Method("Lorg/mortbay/log/Logger;","warn",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;","Ljava/lang/Object;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m018_warn(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/log/Log;","warn",new String[]{ "Ljava/lang/String;","Ljava/lang/Throwable;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"msg");
                ddv.visitParameterName(1,"th");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(194,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(198,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(196,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(197,L3);
                code.visitLabel(L0);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/log/Log;","__log","Lorg/mortbay/log/Logger;"));
                code.visitJumpStmt(IF_NEZ,0,-1,L2);
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/log/Log;","__log","Lorg/mortbay/log/Logger;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1,2},new Method("Lorg/mortbay/log/Logger;","warn",new String[]{ "Ljava/lang/String;","Ljava/lang/Throwable;"},"V"));
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2},new Method("Lorg/mortbay/log/Log;","unwind",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m019_warn(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/log/Log;","warn",new String[]{ "Ljava/lang/Throwable;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"th");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(202,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(206,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(204,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(205,L3);
                code.visitLabel(L0);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/log/Log;","__log","Lorg/mortbay/log/Logger;"));
                code.visitJumpStmt(IF_NEZ,0,-1,L2);
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/log/Log;","__log","Lorg/mortbay/log/Logger;"));
                code.visitConstStmt(CONST_STRING,1,"EXCEPTION ");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1,2},new Method("Lorg/mortbay/log/Logger;","warn",new String[]{ "Ljava/lang/String;","Ljava/lang/Throwable;"},"V"));
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2},new Method("Lorg/mortbay/log/Log;","unwind",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
