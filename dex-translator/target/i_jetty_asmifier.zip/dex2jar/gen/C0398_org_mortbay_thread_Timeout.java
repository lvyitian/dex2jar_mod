package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0398_org_mortbay_thread_Timeout {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/thread/Timeout;","Ljava/lang/Object;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("Timeout.java");
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/MemberClasses;", Visibility.SYSTEM);
            if(av00 != null) {
                {
                    DexAnnotationVisitor av01 = av00.visitArray("value");
                    if(av01 != null) {
                        av01.visit(null, new DexType("Lorg/mortbay/thread/Timeout$Task;"));
                        av01.visitEnd();
                    }
                }
                av00.visitEnd();
            }
        }
        f000__duration(cv);
        f001__head(cv);
        f002__lock(cv);
        f003__now(cv);
        m000__init_(cv);
        m001__init_(cv);
        m002_access$200(cv);
        m003_access$300(cv);
        m004_cancelAll(cv);
        m005_expired(cv);
        m006_getDuration(cv);
        m007_getNow(cv);
        m008_getTimeToNext(cv);
        m009_isEmpty(cv);
        m010_schedule(cv);
        m011_schedule(cv);
        m012_setDuration(cv);
        m013_setNow(cv);
        m014_setNow(cv);
        m015_tick(cv);
        m016_tick(cv);
        m017_toString(cv);
    }
    public static void f000__duration(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/thread/Timeout;","_duration","J"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001__head(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/thread/Timeout;","_head","Lorg/mortbay/thread/Timeout$Task;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002__lock(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/thread/Timeout;","_lock","Ljava/lang/Object;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003__now(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/thread/Timeout;","_now","J"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/thread/Timeout;","<init>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(42,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(37,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(38,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(43,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(44,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(45,L5);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2},new Method("Ljava/lang/Object;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Ljava/lang/System;","currentTimeMillis",new String[]{ },"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,0);
                code.visitFieldStmt(IPUT_WIDE,0,2,new Field("Lorg/mortbay/thread/Timeout;","_now","J"));
                code.visitLabel(L2);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/thread/Timeout$Task;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Lorg/mortbay/thread/Timeout$Task;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/thread/Timeout;","_head","Lorg/mortbay/thread/Timeout$Task;"));
                code.visitLabel(L3);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/Object;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/Object;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/thread/Timeout;","_lock","Ljava/lang/Object;"));
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/thread/Timeout;","_head","Lorg/mortbay/thread/Timeout$Task;"));
                code.visitFieldStmt(IPUT_OBJECT,2,0,new Field("Lorg/mortbay/thread/Timeout$Task;","_timeout","Lorg/mortbay/thread/Timeout;"));
                code.visitLabel(L5);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/thread/Timeout;","<init>",new String[]{ "Ljava/lang/Object;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"lock");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(49,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(37,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(38,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(50,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(51,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(52,L5);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2},new Method("Ljava/lang/Object;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Ljava/lang/System;","currentTimeMillis",new String[]{ },"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,0);
                code.visitFieldStmt(IPUT_WIDE,0,2,new Field("Lorg/mortbay/thread/Timeout;","_now","J"));
                code.visitLabel(L2);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/thread/Timeout$Task;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Lorg/mortbay/thread/Timeout$Task;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/thread/Timeout;","_head","Lorg/mortbay/thread/Timeout$Task;"));
                code.visitLabel(L3);
                code.visitFieldStmt(IPUT_OBJECT,3,2,new Field("Lorg/mortbay/thread/Timeout;","_lock","Ljava/lang/Object;"));
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/thread/Timeout;","_head","Lorg/mortbay/thread/Timeout$Task;"));
                code.visitFieldStmt(IPUT_OBJECT,2,0,new Field("Lorg/mortbay/thread/Timeout$Task;","_timeout","Lorg/mortbay/thread/Timeout;"));
                code.visitLabel(L5);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_access$200(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_SYNTHETIC, new Method("Lorg/mortbay/thread/Timeout;","access$200",new String[]{ "Lorg/mortbay/thread/Timeout;"},"J"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"x0");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(33,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_WIDE,0,2,new Field("Lorg/mortbay/thread/Timeout;","_now","J"));
                code.visitStmt1R(RETURN_WIDE,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_access$300(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_SYNTHETIC, new Method("Lorg/mortbay/thread/Timeout;","access$300",new String[]{ "Lorg/mortbay/thread/Timeout;"},"Ljava/lang/Object;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"x0");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(33,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/thread/Timeout;","_lock","Ljava/lang/Object;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_cancelAll(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/thread/Timeout;","cancelAll",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(210,L3);
                ddv.visitLineNumber(212,L0);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(213,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(214,L5);
                ddv.visitLineNumber(213,L2);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/thread/Timeout;","_lock","Ljava/lang/Object;"));
                code.visitStmt1R(MONITOR_ENTER,0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/thread/Timeout;","_head","Lorg/mortbay/thread/Timeout$Task;"));
                code.visitFieldStmt(IGET_OBJECT,2,4,new Field("Lorg/mortbay/thread/Timeout;","_head","Lorg/mortbay/thread/Timeout$Task;"));
                code.visitFieldStmt(IGET_OBJECT,3,4,new Field("Lorg/mortbay/thread/Timeout;","_head","Lorg/mortbay/thread/Timeout$Task;"));
                code.visitFieldStmt(IPUT_OBJECT,3,2,new Field("Lorg/mortbay/thread/Timeout$Task;","_prev","Lorg/mortbay/thread/Timeout$Task;"));
                code.visitFieldStmt(IPUT_OBJECT,3,1,new Field("Lorg/mortbay/thread/Timeout$Task;","_next","Lorg/mortbay/thread/Timeout$Task;"));
                code.visitLabel(L4);
                code.visitStmt1R(MONITOR_EXIT,0);
                code.visitLabel(L5);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitStmt1R(MONITOR_EXIT,0);
                code.visitLabel(L1);
                code.visitStmt1R(THROW,1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_expired(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/thread/Timeout;","expired",new String[]{ },"Lorg/mortbay/thread/Timeout$Task;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(10);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(110,L4);
                ddv.visitLineNumber(112,L0);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(114,L5);
                ddv.visitStartLocal(0,L5,"_expiry","J",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(116,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(117,L7);
                ddv.visitStartLocal(2,L7,"task","Lorg/mortbay/thread/Timeout$Task;",null);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(118,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(124,L9);
                ddv.visitEndLocal(2,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(120,L10);
                ddv.visitRestartLocal(2,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(121,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(122,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(124,L13);
                ddv.visitEndLocal(2,L13);
                ddv.visitLineNumber(125,L2);
                ddv.visitEndLocal(0,L2);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,8, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,3,9,new Field("Lorg/mortbay/thread/Timeout;","_lock","Ljava/lang/Object;"));
                code.visitStmt1R(MONITOR_ENTER,3);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_WIDE,4,9,new Field("Lorg/mortbay/thread/Timeout;","_now","J"));
                code.visitFieldStmt(IGET_WIDE,6,9,new Field("Lorg/mortbay/thread/Timeout;","_duration","J"));
                code.visitStmt3R(SUB_LONG,0,4,6);
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,4,9,new Field("Lorg/mortbay/thread/Timeout;","_head","Lorg/mortbay/thread/Timeout$Task;"));
                code.visitFieldStmt(IGET_OBJECT,4,4,new Field("Lorg/mortbay/thread/Timeout$Task;","_next","Lorg/mortbay/thread/Timeout$Task;"));
                code.visitFieldStmt(IGET_OBJECT,5,9,new Field("Lorg/mortbay/thread/Timeout;","_head","Lorg/mortbay/thread/Timeout$Task;"));
                code.visitJumpStmt(IF_EQ,4,5,L13);
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,4,9,new Field("Lorg/mortbay/thread/Timeout;","_head","Lorg/mortbay/thread/Timeout$Task;"));
                code.visitFieldStmt(IGET_OBJECT,2,4,new Field("Lorg/mortbay/thread/Timeout$Task;","_next","Lorg/mortbay/thread/Timeout$Task;"));
                code.visitLabel(L7);
                code.visitFieldStmt(IGET_WIDE,4,2,new Field("Lorg/mortbay/thread/Timeout$Task;","_timestamp","J"));
                code.visitStmt3R(CMP_LONG,4,4,0);
                code.visitJumpStmt(IF_LEZ,4,-1,L10);
                code.visitLabel(L8);
                code.visitStmt1R(MONITOR_EXIT,3);
                code.visitStmt2R(MOVE_OBJECT,3,8);
                code.visitLabel(L9);
                code.visitStmt1R(RETURN_OBJECT,3);
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2},new Method("Lorg/mortbay/thread/Timeout$Task;","access$000",new String[]{ "Lorg/mortbay/thread/Timeout$Task;"},"V"));
                code.visitLabel(L11);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitFieldStmt(IPUT_BOOLEAN,4,2,new Field("Lorg/mortbay/thread/Timeout$Task;","_expired","Z"));
                code.visitLabel(L12);
                code.visitStmt1R(MONITOR_EXIT,3);
                code.visitStmt2R(MOVE_OBJECT,3,2);
                code.visitJumpStmt(GOTO,-1,-1,L9);
                code.visitLabel(L13);
                code.visitStmt1R(MONITOR_EXIT,3);
                code.visitStmt2R(MOVE_OBJECT,3,8);
                code.visitJumpStmt(GOTO,-1,-1,L9);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,4);
                code.visitStmt1R(MONITOR_EXIT,3);
                code.visitLabel(L1);
                code.visitStmt1R(THROW,4);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_getDuration(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/thread/Timeout;","getDuration",new String[]{ },"J"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(60,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_WIDE,0,2,new Field("Lorg/mortbay/thread/Timeout;","_duration","J"));
                code.visitStmt1R(RETURN_WIDE,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m007_getNow(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/thread/Timeout;","getNow",new String[]{ },"J"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(85,L3);
                ddv.visitLineNumber(87,L0);
                ddv.visitLineNumber(88,L2);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/thread/Timeout;","_lock","Ljava/lang/Object;"));
                code.visitStmt1R(MONITOR_ENTER,0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_WIDE,1,3,new Field("Lorg/mortbay/thread/Timeout;","_now","J"));
                code.visitStmt1R(MONITOR_EXIT,0);
                code.visitStmt1R(RETURN_WIDE,1);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitStmt1R(MONITOR_EXIT,0);
                code.visitLabel(L1);
                code.visitStmt1R(THROW,1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m008_getTimeToNext(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/thread/Timeout;","getTimeToNext",new String[]{ },"J"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(10);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(228,L4);
                ddv.visitLineNumber(230,L0);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(231,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(233,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(232,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(233,L8);
                ddv.visitStartLocal(0,L8,"to_next","J",null);
                ddv.visitLineNumber(234,L2);
                ddv.visitEndLocal(0,L2);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_WIDE_16,7,Long.valueOf(0L)); // long: 0x0000000000000000  double:0.000000
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,2,9,new Field("Lorg/mortbay/thread/Timeout;","_lock","Ljava/lang/Object;"));
                code.visitStmt1R(MONITOR_ENTER,2);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,3,9,new Field("Lorg/mortbay/thread/Timeout;","_head","Lorg/mortbay/thread/Timeout$Task;"));
                code.visitFieldStmt(IGET_OBJECT,3,3,new Field("Lorg/mortbay/thread/Timeout$Task;","_next","Lorg/mortbay/thread/Timeout$Task;"));
                code.visitFieldStmt(IGET_OBJECT,4,9,new Field("Lorg/mortbay/thread/Timeout;","_head","Lorg/mortbay/thread/Timeout$Task;"));
                code.visitJumpStmt(IF_NE,3,4,L7);
                code.visitLabel(L5);
                code.visitConstStmt(CONST_WIDE_16,3,Long.valueOf(-1L)); // long: 0xffffffffffffffff  double:NaN
                code.visitStmt1R(MONITOR_EXIT,2);
                code.visitStmt2R(MOVE_WIDE,2,3);
                code.visitLabel(L6);
                code.visitStmt1R(RETURN_WIDE,2);
                code.visitLabel(L7);
                code.visitFieldStmt(IGET_WIDE,3,9,new Field("Lorg/mortbay/thread/Timeout;","_duration","J"));
                code.visitFieldStmt(IGET_OBJECT,5,9,new Field("Lorg/mortbay/thread/Timeout;","_head","Lorg/mortbay/thread/Timeout$Task;"));
                code.visitFieldStmt(IGET_OBJECT,5,5,new Field("Lorg/mortbay/thread/Timeout$Task;","_next","Lorg/mortbay/thread/Timeout$Task;"));
                code.visitFieldStmt(IGET_WIDE,5,5,new Field("Lorg/mortbay/thread/Timeout$Task;","_timestamp","J"));
                code.visitStmt2R(ADD_LONG_2ADDR,3,5);
                code.visitFieldStmt(IGET_WIDE,5,9,new Field("Lorg/mortbay/thread/Timeout;","_now","J"));
                code.visitStmt3R(SUB_LONG,0,3,5);
                code.visitLabel(L8);
                code.visitStmt3R(CMP_LONG,3,0,7);
                DexLabel L9=new DexLabel();
                code.visitJumpStmt(IF_GEZ,3,-1,L9);
                code.visitStmt2R(MOVE_WIDE,3,7);
                DexLabel L10=new DexLabel();
                code.visitLabel(L10);
                code.visitStmt1R(MONITOR_EXIT,2);
                code.visitStmt2R(MOVE_WIDE,2,3);
                code.visitJumpStmt(GOTO,-1,-1,L6);
                code.visitLabel(L9);
                code.visitStmt2R(MOVE_WIDE,3,0);
                code.visitJumpStmt(GOTO,-1,-1,L10);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,3);
                code.visitStmt1R(MONITOR_EXIT,2);
                code.visitLabel(L1);
                code.visitStmt1R(THROW,3);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m009_isEmpty(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/thread/Timeout;","isEmpty",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(219,L3);
                ddv.visitLineNumber(221,L0);
                ddv.visitLineNumber(222,L2);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/thread/Timeout;","_lock","Ljava/lang/Object;"));
                code.visitStmt1R(MONITOR_ENTER,0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/thread/Timeout;","_head","Lorg/mortbay/thread/Timeout$Task;"));
                code.visitFieldStmt(IGET_OBJECT,1,1,new Field("Lorg/mortbay/thread/Timeout$Task;","_next","Lorg/mortbay/thread/Timeout$Task;"));
                code.visitFieldStmt(IGET_OBJECT,2,3,new Field("Lorg/mortbay/thread/Timeout;","_head","Lorg/mortbay/thread/Timeout$Task;"));
                DexLabel L4=new DexLabel();
                code.visitJumpStmt(IF_NE,1,2,L4);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                DexLabel L5=new DexLabel();
                code.visitLabel(L5);
                code.visitStmt1R(MONITOR_EXIT,0);
                code.visitStmt1R(RETURN,1);
                code.visitLabel(L4);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitStmt1R(MONITOR_EXIT,0);
                code.visitLabel(L1);
                code.visitStmt1R(THROW,1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m010_schedule(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/thread/Timeout;","schedule",new String[]{ "Lorg/mortbay/thread/Timeout$Task;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"task");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(173,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(174,L1);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_WIDE_16,0,Long.valueOf(0L)); // long: 0x0000000000000000  double:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3,0,1},new Method("Lorg/mortbay/thread/Timeout;","schedule",new String[]{ "Lorg/mortbay/thread/Timeout$Task;","J"},"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m011_schedule(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/thread/Timeout;","schedule",new String[]{ "Lorg/mortbay/thread/Timeout$Task;","J"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(10);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"task");
                ddv.visitParameterName(1,"delay");
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(183,L4);
                ddv.visitLineNumber(185,L0);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(187,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(188,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(190,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(191,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(192,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(193,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(195,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(196,L12);
                ddv.visitStartLocal(0,L12,"last","Lorg/mortbay/thread/Timeout$Task;",null);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(198,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(202,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(203,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(204,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(200,L17);
                ddv.visitLineNumber(203,L2);
                ddv.visitEndLocal(0,L2);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_WIDE_16,4,Long.valueOf(0L)); // long: 0x0000000000000000  double:0.000000
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,1,6,new Field("Lorg/mortbay/thread/Timeout;","_lock","Ljava/lang/Object;"));
                code.visitStmt1R(MONITOR_ENTER,1);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_WIDE,2,7,new Field("Lorg/mortbay/thread/Timeout$Task;","_timestamp","J"));
                code.visitStmt3R(CMP_LONG,2,2,4);
                code.visitJumpStmt(IF_EQZ,2,-1,L7);
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 7},new Method("Lorg/mortbay/thread/Timeout$Task;","access$000",new String[]{ "Lorg/mortbay/thread/Timeout$Task;"},"V"));
                code.visitLabel(L6);
                code.visitConstStmt(CONST_WIDE_16,2,Long.valueOf(0L)); // long: 0x0000000000000000  double:0.000000
                code.visitFieldStmt(IPUT_WIDE,2,7,new Field("Lorg/mortbay/thread/Timeout$Task;","_timestamp","J"));
                code.visitLabel(L7);
                code.visitFieldStmt(IPUT_OBJECT,6,7,new Field("Lorg/mortbay/thread/Timeout$Task;","_timeout","Lorg/mortbay/thread/Timeout;"));
                code.visitLabel(L8);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_BOOLEAN,2,7,new Field("Lorg/mortbay/thread/Timeout$Task;","_expired","Z"));
                code.visitLabel(L9);
                code.visitFieldStmt(IPUT_WIDE,8,7,new Field("Lorg/mortbay/thread/Timeout$Task;","_delay","J"));
                code.visitLabel(L10);
                code.visitFieldStmt(IGET_WIDE,2,6,new Field("Lorg/mortbay/thread/Timeout;","_now","J"));
                code.visitStmt2R(ADD_LONG_2ADDR,2,8);
                code.visitFieldStmt(IPUT_WIDE,2,7,new Field("Lorg/mortbay/thread/Timeout$Task;","_timestamp","J"));
                code.visitLabel(L11);
                code.visitFieldStmt(IGET_OBJECT,2,6,new Field("Lorg/mortbay/thread/Timeout;","_head","Lorg/mortbay/thread/Timeout$Task;"));
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/thread/Timeout$Task;","_prev","Lorg/mortbay/thread/Timeout$Task;"));
                code.visitLabel(L12);
                code.visitFieldStmt(IGET_OBJECT,2,6,new Field("Lorg/mortbay/thread/Timeout;","_head","Lorg/mortbay/thread/Timeout$Task;"));
                code.visitJumpStmt(IF_EQ,0,2,L14);
                code.visitLabel(L13);
                code.visitFieldStmt(IGET_WIDE,2,0,new Field("Lorg/mortbay/thread/Timeout$Task;","_timestamp","J"));
                code.visitFieldStmt(IGET_WIDE,4,7,new Field("Lorg/mortbay/thread/Timeout$Task;","_timestamp","J"));
                code.visitStmt3R(CMP_LONG,2,2,4);
                code.visitJumpStmt(IF_GTZ,2,-1,L17);
                code.visitLabel(L14);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,7},new Method("Lorg/mortbay/thread/Timeout$Task;","access$100",new String[]{ "Lorg/mortbay/thread/Timeout$Task;","Lorg/mortbay/thread/Timeout$Task;"},"V"));
                code.visitLabel(L15);
                code.visitStmt1R(MONITOR_EXIT,1);
                code.visitLabel(L16);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L17);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/thread/Timeout$Task;","_prev","Lorg/mortbay/thread/Timeout$Task;"));
                code.visitJumpStmt(GOTO,-1,-1,L12);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,2);
                code.visitStmt1R(MONITOR_EXIT,1);
                code.visitLabel(L1);
                code.visitStmt1R(THROW,2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m012_setDuration(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/thread/Timeout;","setDuration",new String[]{ "J"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"duration");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(69,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(70,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_WIDE,1,0,new Field("Lorg/mortbay/thread/Timeout;","_duration","J"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m013_setNow(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/thread/Timeout;","setNow",new String[]{ },"J"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(75,L3);
                ddv.visitLineNumber(77,L0);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(78,L4);
                ddv.visitLineNumber(79,L2);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/thread/Timeout;","_lock","Ljava/lang/Object;"));
                code.visitStmt1R(MONITOR_ENTER,0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Ljava/lang/System;","currentTimeMillis",new String[]{ },"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,1);
                code.visitFieldStmt(IPUT_WIDE,1,3,new Field("Lorg/mortbay/thread/Timeout;","_now","J"));
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_WIDE,1,3,new Field("Lorg/mortbay/thread/Timeout;","_now","J"));
                code.visitStmt1R(MONITOR_EXIT,0);
                code.visitStmt1R(RETURN_WIDE,1);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitStmt1R(MONITOR_EXIT,0);
                code.visitLabel(L1);
                code.visitStmt1R(THROW,1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m014_setNow(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/thread/Timeout;","setNow",new String[]{ "J"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"now");
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(94,L3);
                ddv.visitLineNumber(96,L0);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(97,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(98,L5);
                ddv.visitLineNumber(97,L2);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/thread/Timeout;","_lock","Ljava/lang/Object;"));
                code.visitStmt1R(MONITOR_ENTER,0);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_WIDE,3,2,new Field("Lorg/mortbay/thread/Timeout;","_now","J"));
                code.visitLabel(L4);
                code.visitStmt1R(MONITOR_EXIT,0);
                code.visitLabel(L5);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitStmt1R(MONITOR_EXIT,0);
                code.visitLabel(L1);
                code.visitStmt1R(THROW,1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m015_tick(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/thread/Timeout;","tick",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(167,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(168,L1);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_WIDE_16,0,Long.valueOf(-1L)); // long: 0xffffffffffffffff  double:NaN
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,0,1},new Method("Lorg/mortbay/thread/Timeout;","tick",new String[]{ "J"},"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m016_tick(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/thread/Timeout;","tick",new String[]{ "J"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(14);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/lang/Throwable;"});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                DexLabel L5=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L5},new String[]{ null});
                DexLabel L6=new DexLabel();
                code.visitTryCatch(L4,L6,new DexLabel[]{L2},new String[]{ "Ljava/lang/Throwable;"});
                DexLabel L7=new DexLabel();
                DexLabel L8=new DexLabel();
                code.visitTryCatch(L7,L8,new DexLabel[]{L5},new String[]{ null});
                DexLabel L9=new DexLabel();
                code.visitTryCatch(L8,L9,new DexLabel[]{L2},new String[]{ "Ljava/lang/Throwable;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"now");
                DexLabel L10=new DexLabel();
                ddv.visitPrologue(L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(131,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(133,L12);
                ddv.visitStartLocal(0,L12,"_expiry","J",null);
                ddv.visitLineNumber(138,L0);
                ddv.visitStartLocal(2,L0,"task","Lorg/mortbay/thread/Timeout$Task;",null);
                ddv.visitLineNumber(140,L1);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(142,L13);
                ddv.visitLineNumber(143,L3);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(144,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(147,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(148,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(149,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(162,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(150,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(151,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(152,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(153,L22);
                ddv.visitLineNumber(155,L4);
                ddv.visitLineNumber(157,L2);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(159,L23);
                ddv.visitStartLocal(3,L23,"th","Ljava/lang/Throwable;",null);
                ddv.visitLineNumber(153,L5);
                ddv.visitEndLocal(3,L5);
                code.visitLabel(L10);
                code.visitConstStmt(CONST_WIDE_16,9,Long.valueOf(-1L)); // long: 0xffffffffffffffff  double:NaN
                code.visitLabel(L11);
                code.visitConstStmt(CONST_WIDE_16,0,Long.valueOf(-1L)); // long: 0xffffffffffffffff  double:NaN
                code.visitLabel(L12);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,4,11,new Field("Lorg/mortbay/thread/Timeout;","_lock","Ljava/lang/Object;"));
                code.visitStmt1R(MONITOR_ENTER,4);
                code.visitLabel(L1);
                code.visitStmt3R(CMP_LONG,5,0,9);
                code.visitJumpStmt(IF_NEZ,5,-1,L15);
                code.visitLabel(L13);
                code.visitStmt3R(CMP_LONG,5,12,9);
                code.visitJumpStmt(IF_EQZ,5,-1,L14);
                code.visitLabel(L3);
                code.visitFieldStmt(IPUT_WIDE,12,11,new Field("Lorg/mortbay/thread/Timeout;","_now","J"));
                code.visitLabel(L14);
                code.visitFieldStmt(IGET_WIDE,5,11,new Field("Lorg/mortbay/thread/Timeout;","_now","J"));
                code.visitFieldStmt(IGET_WIDE,7,11,new Field("Lorg/mortbay/thread/Timeout;","_duration","J"));
                code.visitStmt3R(SUB_LONG,0,5,7);
                code.visitLabel(L15);
                code.visitFieldStmt(IGET_OBJECT,5,11,new Field("Lorg/mortbay/thread/Timeout;","_head","Lorg/mortbay/thread/Timeout$Task;"));
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/thread/Timeout$Task;","_next","Lorg/mortbay/thread/Timeout$Task;"));
                code.visitLabel(L16);
                code.visitFieldStmt(IGET_OBJECT,5,11,new Field("Lorg/mortbay/thread/Timeout;","_head","Lorg/mortbay/thread/Timeout$Task;"));
                code.visitJumpStmt(IF_EQ,2,5,L17);
                code.visitFieldStmt(IGET_WIDE,5,2,new Field("Lorg/mortbay/thread/Timeout$Task;","_timestamp","J"));
                code.visitStmt3R(CMP_LONG,5,5,0);
                code.visitJumpStmt(IF_LEZ,5,-1,L19);
                code.visitLabel(L17);
                code.visitStmt1R(MONITOR_EXIT,4);
                code.visitLabel(L18);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L19);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2},new Method("Lorg/mortbay/thread/Timeout$Task;","access$000",new String[]{ "Lorg/mortbay/thread/Timeout$Task;"},"V"));
                code.visitLabel(L20);
                code.visitConstStmt(CONST_4,5, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitFieldStmt(IPUT_BOOLEAN,5,2,new Field("Lorg/mortbay/thread/Timeout$Task;","_expired","Z"));
                code.visitLabel(L21);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/thread/Timeout$Task;","expire",new String[]{ },"V"));
                code.visitLabel(L22);
                code.visitStmt1R(MONITOR_EXIT,4);
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/thread/Timeout$Task;","expired",new String[]{ },"V"));
                code.visitLabel(L6);
                code.visitJumpStmt(GOTO,-1,-1,L0);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,4);
                code.visitStmt2R(MOVE_OBJECT,3,4);
                code.visitLabel(L23);
                code.visitConstStmt(CONST_STRING,4,"EXCEPTION ");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 4,3},new Method("Lorg/mortbay/log/Log;","warn",new String[]{ "Ljava/lang/String;","Ljava/lang/Throwable;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L0);
                code.visitLabel(L5);
                code.visitStmt1R(MOVE_EXCEPTION,5);
                code.visitLabel(L7);
                code.visitStmt1R(MONITOR_EXIT,4);
                code.visitLabel(L8);
                code.visitStmt1R(THROW,5);
                code.visitLabel(L9);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m017_toString(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/thread/Timeout;","toString",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(240,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(241,L1);
                ddv.visitStartLocal(0,L1,"buf","Ljava/lang/StringBuffer;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(243,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(244,L3);
                ddv.visitStartLocal(1,L3,"task","Lorg/mortbay/thread/Timeout$Task;",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(246,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(247,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(248,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(251,L7);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/StringBuffer;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/StringBuffer;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 3},new Method("Ljava/lang/Object;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,2},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,2,3,new Field("Lorg/mortbay/thread/Timeout;","_head","Lorg/mortbay/thread/Timeout$Task;"));
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/thread/Timeout$Task;","_next","Lorg/mortbay/thread/Timeout$Task;"));
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,2,3,new Field("Lorg/mortbay/thread/Timeout;","_head","Lorg/mortbay/thread/Timeout$Task;"));
                code.visitJumpStmt(IF_EQ,1,2,L7);
                code.visitLabel(L4);
                code.visitConstStmt(CONST_STRING,2,"-->");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,2},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,1,1,new Field("Lorg/mortbay/thread/Timeout$Task;","_next","Lorg/mortbay/thread/Timeout$Task;"));
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/StringBuffer;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitStmt1R(RETURN_OBJECT,2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
