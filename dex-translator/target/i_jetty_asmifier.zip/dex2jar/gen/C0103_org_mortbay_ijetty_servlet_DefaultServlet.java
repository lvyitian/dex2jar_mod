package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0103_org_mortbay_ijetty_servlet_DefaultServlet {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/ijetty/servlet/DefaultServlet;","Ljavax/servlet/http/HttpServlet;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("DefaultServlet.java");
        f000__context(cv);
        f001__dirAllowed(cv);
        f002__redirectWelcome(cv);
        f003__resources(cv);
        f004__welcomes(cv);
        m000__init_(cv);
        m001_getWelcomeFile(cv);
        m002_doGet(cv);
        m003_doPost(cv);
        m004_doTrace(cv);
        m005_getResource(cv);
        m006_init(cv);
        m007_passConditionalHeaders(cv);
        m008_sendData(cv);
        m009_sendDirectory(cv);
        m010_setResources(cv);
        m011_writeHeaders(cv);
    }
    public static void f000__context(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/ijetty/servlet/DefaultServlet;","_context","Lorg/mortbay/jetty/handler/ContextHandler$SContext;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001__dirAllowed(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/ijetty/servlet/DefaultServlet;","_dirAllowed","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002__redirectWelcome(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/ijetty/servlet/DefaultServlet;","_redirectWelcome","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003__resources(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/ijetty/servlet/DefaultServlet;","_resources","Landroid/content/res/Resources;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f004__welcomes(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/ijetty/servlet/DefaultServlet;","_welcomes","[Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/ijetty/servlet/DefaultServlet;","<init>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(54,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(46,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(47,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(48,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(54,L5);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4},new Method("Ljavax/servlet/http/HttpServlet;","<init>",new String[]{ },"V"));
                code.visitLabel(L2);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitTypeStmt(NEW_ARRAY,0,0,"[Ljava/lang/String;");
                code.visitConstStmt(CONST_STRING,1,"index.html");
                code.visitStmt3R(APUT_OBJECT,1,0,2);
                code.visitConstStmt(CONST_STRING,1,"index.htm");
                code.visitStmt3R(APUT_OBJECT,1,0,3);
                code.visitFieldStmt(IPUT_OBJECT,0,4,new Field("Lorg/mortbay/ijetty/servlet/DefaultServlet;","_welcomes","[Ljava/lang/String;"));
                code.visitLabel(L3);
                code.visitFieldStmt(IPUT_BOOLEAN,2,4,new Field("Lorg/mortbay/ijetty/servlet/DefaultServlet;","_redirectWelcome","Z"));
                code.visitLabel(L4);
                code.visitFieldStmt(IPUT_BOOLEAN,3,4,new Field("Lorg/mortbay/ijetty/servlet/DefaultServlet;","_dirAllowed","Z"));
                code.visitLabel(L5);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001_getWelcomeFile(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PRIVATE, new Method("Lorg/mortbay/ijetty/servlet/DefaultServlet;","getWelcomeFile",new String[]{ "Lorg/mortbay/ijetty/resource/AndroidFileResource;"},"Ljava/lang/String;"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"dir");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(328,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(338,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(331,L3);
                DexLabel L4=new DexLabel();
                ddv.visitStartLocal(0,L4,"i","I",null);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(333,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(334,L6);
                ddv.visitStartLocal(1,L6,"welcome","Lorg/mortbay/ijetty/resource/AndroidFileResource;",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(335,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(331,L8);
                DexLabel L9=new DexLabel();
                ddv.visitEndLocal(1,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(338,L10);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/ijetty/resource/AndroidFileResource;","isDirectory",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                DexLabel L11=new DexLabel();
                code.visitJumpStmt(IF_EQZ,2,-1,L11);
                code.visitFieldStmt(IGET_OBJECT,2,4,new Field("Lorg/mortbay/ijetty/servlet/DefaultServlet;","_welcomes","[Ljava/lang/String;"));
                code.visitJumpStmt(IF_NEZ,2,-1,L3);
                code.visitLabel(L11);
                code.visitStmt2R(MOVE_OBJECT,2,3);
                code.visitLabel(L2);
                code.visitStmt1R(RETURN_OBJECT,2);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,2,4,new Field("Lorg/mortbay/ijetty/servlet/DefaultServlet;","_welcomes","[Ljava/lang/String;"));
                code.visitStmt2R(ARRAY_LENGTH,2,2);
                code.visitJumpStmt(IF_GE,0,2,L9);
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,2,4,new Field("Lorg/mortbay/ijetty/servlet/DefaultServlet;","_welcomes","[Ljava/lang/String;"));
                code.visitStmt3R(AGET_OBJECT,2,2,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,2},new Method("Lorg/mortbay/ijetty/resource/AndroidFileResource;","addPath",new String[]{ "Ljava/lang/String;"},"Lorg/mortbay/ijetty/resource/AndroidFileResource;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/ijetty/resource/AndroidFileResource;","exists",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_EQZ,2,-1,L8);
                code.visitLabel(L7);
                code.visitFieldStmt(IGET_OBJECT,2,4,new Field("Lorg/mortbay/ijetty/servlet/DefaultServlet;","_welcomes","[Ljava/lang/String;"));
                code.visitStmt3R(AGET_OBJECT,2,2,0);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L8);
                code.visitStmt2R1N(ADD_INT_LIT8,0,0,1);
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitLabel(L9);
                code.visitStmt2R(MOVE_OBJECT,2,3);
                code.visitLabel(L10);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_doGet(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/ijetty/servlet/DefaultServlet;","doGet",new String[]{ "Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljavax/servlet/ServletException;"));
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(23);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"request");
                ddv.visitParameterName(1,"response");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(82,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(83,L1);
                ddv.visitStartLocal(15,L1,"servletPath","Ljava/lang/String;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(84,L2);
                ddv.visitStartLocal(13,L2,"pathInfo","Ljava/lang/String;",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(86,L3);
                ddv.visitStartLocal(9,L3,"included","Ljava/lang/Boolean;",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(88,L4);
                DexLabel L5=new DexLabel();
                ddv.visitEndLocal(15,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(89,L6);
                ddv.visitRestartLocal(15,L6);
                DexLabel L7=new DexLabel();
                ddv.visitEndLocal(13,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(90,L8);
                ddv.visitRestartLocal(13,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(92,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(93,L10);
                ddv.visitRestartLocal(15,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(103,L11);
                ddv.visitRestartLocal(13,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(104,L12);
                ddv.visitStartLocal(12,L12,"pathInContext","Ljava/lang/String;",null);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(106,L13);
                ddv.visitStartLocal(8,L13,"endsWithSlash","Z",null);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(107,L14);
                ddv.visitStartLocal(16,L14,"url","Ljava/net/URL;",null);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(109,L15);
                ddv.visitStartLocal(5,L15,"androidFileResource","Lorg/mortbay/ijetty/resource/AndroidFileResource;",null);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(111,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(183,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(98,L18);
                ddv.visitEndLocal(12,L18);
                ddv.visitEndLocal(8,L18);
                ddv.visitEndLocal(16,L18);
                ddv.visitEndLocal(5,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(99,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(100,L20);
                ddv.visitRestartLocal(15,L20);
                DexLabel L21=new DexLabel();
                ddv.visitRestartLocal(13,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(113,L22);
                ddv.visitRestartLocal(5,L22);
                ddv.visitRestartLocal(8,L22);
                ddv.visitRestartLocal(12,L22);
                ddv.visitRestartLocal(16,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(116,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(117,L24);
                ddv.visitStartLocal(6,L24,"buf","Ljava/lang/StringBuffer;",null);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(118,L25);
                ddv.visitStartLocal(11,L25,"param","I",null);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(119,L26);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(122,L27);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(123,L28);
                ddv.visitStartLocal(14,L28,"q","Ljava/lang/String;",null);
                DexLabel L29=new DexLabel();
                ddv.visitLineNumber(125,L29);
                DexLabel L30=new DexLabel();
                ddv.visitLineNumber(126,L30);
                DexLabel L31=new DexLabel();
                ddv.visitLineNumber(128,L31);
                DexLabel L32=new DexLabel();
                ddv.visitLineNumber(129,L32);
                DexLabel L33=new DexLabel();
                ddv.visitLineNumber(121,L33);
                ddv.visitEndLocal(14,L33);
                DexLabel L34=new DexLabel();
                ddv.visitLineNumber(131,L34);
                ddv.visitEndLocal(6,L34);
                ddv.visitEndLocal(11,L34);
                DexLabel L35=new DexLabel();
                ddv.visitLineNumber(134,L35);
                DexLabel L36=new DexLabel();
                ddv.visitLineNumber(135,L36);
                ddv.visitStartLocal(17,L36,"welcome","Ljava/lang/String;",null);
                DexLabel L37=new DexLabel();
                ddv.visitLineNumber(137,L37);
                DexLabel L38=new DexLabel();
                ddv.visitLineNumber(138,L38);
                ddv.visitStartLocal(10,L38,"ipath","Ljava/lang/String;",null);
                DexLabel L39=new DexLabel();
                ddv.visitLineNumber(141,L39);
                DexLabel L40=new DexLabel();
                ddv.visitLineNumber(142,L40);
                DexLabel L41=new DexLabel();
                ddv.visitLineNumber(143,L41);
                ddv.visitRestartLocal(14,L41);
                DexLabel L42=new DexLabel();
                ddv.visitLineNumber(144,L42);
                DexLabel L43=new DexLabel();
                ddv.visitLineNumber(146,L43);
                DexLabel L44=new DexLabel();
                ddv.visitLineNumber(151,L44);
                ddv.visitEndLocal(14,L44);
                DexLabel L45=new DexLabel();
                ddv.visitLineNumber(152,L45);
                ddv.visitStartLocal(7,L45,"dispatcher","Ljavax/servlet/RequestDispatcher;",null);
                DexLabel L46=new DexLabel();
                ddv.visitLineNumber(154,L46);
                DexLabel L47=new DexLabel();
                ddv.visitLineNumber(155,L47);
                DexLabel L48=new DexLabel();
                ddv.visitLineNumber(158,L48);
                DexLabel L49=new DexLabel();
                ddv.visitLineNumber(159,L49);
                DexLabel L50=new DexLabel();
                ddv.visitLineNumber(167,L50);
                ddv.visitEndLocal(10,L50);
                ddv.visitEndLocal(7,L50);
                DexLabel L51=new DexLabel();
                ddv.visitLineNumber(168,L51);
                DexLabel L52=new DexLabel();
                ddv.visitLineNumber(173,L52);
                ddv.visitEndLocal(17,L52);
                DexLabel L53=new DexLabel();
                ddv.visitLineNumber(175,L53);
                DexLabel L54=new DexLabel();
                ddv.visitLineNumber(177,L54);
                DexLabel L55=new DexLabel();
                ddv.visitLineNumber(181,L55);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,15, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,13, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L2);
                code.visitConstStmt(CONST_STRING,18,"org.mortbay.jetty.included");
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,18);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1},new Method("Ljavax/servlet/http/HttpServletRequest;","getAttribute",new String[]{ "Ljava/lang/String;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitTypeStmt(CHECK_CAST,9,-1,"Ljava/lang/Boolean;");
                code.visitLabel(L3);
                code.visitJumpStmt(IF_EQZ,9,-1,L18);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9},new Method("Ljava/lang/Boolean;","booleanValue",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,18);
                code.visitJumpStmt(IF_EQZ,18,-1,L18);
                code.visitLabel(L4);
                code.visitConstStmt(CONST_STRING,18,"javax.servlet.include.servlet_path");
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,18);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1},new Method("Ljavax/servlet/http/HttpServletRequest;","getAttribute",new String[]{ "Ljava/lang/String;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,15);
                code.visitLabel(L5);
                code.visitTypeStmt(CHECK_CAST,15,-1,"Ljava/lang/String;");
                code.visitLabel(L6);
                code.visitConstStmt(CONST_STRING,18,"javax.servlet.include.path_info");
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,18);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1},new Method("Ljavax/servlet/http/HttpServletRequest;","getAttribute",new String[]{ "Ljava/lang/String;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,13);
                code.visitLabel(L7);
                code.visitTypeStmt(CHECK_CAST,13,-1,"Ljava/lang/String;");
                code.visitLabel(L8);
                code.visitJumpStmt(IF_NEZ,15,-1,L11);
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 21},new Method("Ljavax/servlet/http/HttpServletRequest;","getServletPath",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,15);
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 21},new Method("Ljavax/servlet/http/HttpServletRequest;","getPathInfo",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,13);
                code.visitLabel(L11);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 15,13},new Method("Lorg/mortbay/util/URIUtil;","addPaths",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,12);
                code.visitLabel(L12);
                code.visitConstStmt(CONST_STRING,18,"/");
                code.visitStmt2R(MOVE_OBJECT,0,12);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,18);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/String;","endsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitLabel(L13);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 20},new Method("Lorg/mortbay/ijetty/servlet/DefaultServlet;","getServletContext",new String[]{ },"Ljavax/servlet/ServletContext;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,18);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,18);
                code.visitStmt2R(MOVE_OBJECT,1,12);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1},new Method("Ljavax/servlet/ServletContext;","getResource",new String[]{ "Ljava/lang/String;"},"Ljava/net/URL;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,16);
                code.visitLabel(L14);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,20);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,16);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/ijetty/servlet/DefaultServlet;","getResource",new String[]{ "Ljava/net/URL;"},"Lorg/mortbay/ijetty/resource/AndroidFileResource;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitLabel(L15);
                code.visitJumpStmt(IF_NEZ,5,-1,L22);
                code.visitLabel(L16);
                code.visitConstStmt(CONST_16,18, Integer.valueOf(404)); // int: 0x00000194  float:0.000000
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,22);
                code.visitStmt2R(MOVE_FROM16,1,18);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1},new Method("Ljavax/servlet/http/HttpServletResponse;","sendError",new String[]{ "I"},"V"));
                code.visitLabel(L17);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L18);
                code.visitFieldStmt(SGET_OBJECT,9,-1,new Field("Ljava/lang/Boolean;","FALSE","Ljava/lang/Boolean;"));
                code.visitLabel(L19);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 21},new Method("Ljavax/servlet/http/HttpServletRequest;","getServletPath",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,15);
                code.visitLabel(L20);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 21},new Method("Ljavax/servlet/http/HttpServletRequest;","getPathInfo",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,13);
                code.visitLabel(L21);
                code.visitJumpStmt(GOTO,-1,-1,L11);
                code.visitLabel(L22);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/ijetty/resource/AndroidFileResource;","isDirectory",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,18);
                code.visitJumpStmt(IF_EQZ,18,-1,L34);
                code.visitJumpStmt(IF_NEZ,8,-1,L34);
                code.visitLabel(L23);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 21},new Method("Ljavax/servlet/http/HttpServletRequest;","getRequestURL",new String[]{ },"Ljava/lang/StringBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitLabel(L24);
                code.visitConstStmt(CONST_STRING,18,";");
                code.visitStmt2R(MOVE_OBJECT,0,6);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,18);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuffer;","lastIndexOf",new String[]{ "Ljava/lang/String;"},"I"));
                code.visitStmt1R(MOVE_RESULT,11);
                code.visitLabel(L25);
                code.visitJumpStmt(IF_GEZ,11,-1,L33);
                code.visitLabel(L26);
                code.visitConstStmt(CONST_16,18, Integer.valueOf(47)); // int: 0x0000002f  float:0.000000
                code.visitStmt2R(MOVE_OBJECT,0,6);
                code.visitStmt2R(MOVE_FROM16,1,18);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "C"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L27);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 21},new Method("Ljavax/servlet/http/HttpServletRequest;","getQueryString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,14);
                code.visitLabel(L28);
                code.visitJumpStmt(IF_EQZ,14,-1,L31);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 14},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,18);
                code.visitJumpStmt(IF_EQZ,18,-1,L31);
                code.visitLabel(L29);
                code.visitConstStmt(CONST_16,18, Integer.valueOf(63)); // int: 0x0000003f  float:0.000000
                code.visitStmt2R(MOVE_OBJECT,0,6);
                code.visitStmt2R(MOVE_FROM16,1,18);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "C"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L30);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,14},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L31);
                code.visitConstStmt(CONST_16,18, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,22);
                code.visitStmt2R(MOVE_FROM16,1,18);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1},new Method("Ljavax/servlet/http/HttpServletResponse;","setContentLength",new String[]{ "I"},"V"));
                code.visitLabel(L32);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/lang/StringBuffer;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,18);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,18);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1},new Method("Ljavax/servlet/http/HttpServletResponse;","encodeRedirectURL",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,18);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,18);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1},new Method("Ljavax/servlet/http/HttpServletResponse;","sendRedirect",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L17);
                code.visitLabel(L33);
                code.visitConstStmt(CONST_16,18, Integer.valueOf(47)); // int: 0x0000002f  float:0.000000
                code.visitStmt2R(MOVE_OBJECT,0,6);
                code.visitStmt2R(MOVE,1,11);
                code.visitStmt2R(MOVE_FROM16,2,18);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Ljava/lang/StringBuffer;","insert",new String[]{ "I","C"},"Ljava/lang/StringBuffer;"));
                code.visitJumpStmt(GOTO,-1,-1,L27);
                code.visitLabel(L34);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/ijetty/resource/AndroidFileResource;","isDirectory",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,18);
                code.visitJumpStmt(IF_EQZ,18,-1,L52);
                code.visitJumpStmt(IF_EQZ,8,-1,L52);
                code.visitLabel(L35);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,20);
                code.visitStmt2R(MOVE_OBJECT,1,5);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Lorg/mortbay/ijetty/servlet/DefaultServlet;","getWelcomeFile",new String[]{ "Lorg/mortbay/ijetty/resource/AndroidFileResource;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,17);
                code.visitLabel(L36);
                code.visitJumpStmt(IF_EQZ,17,-1,L50);
                code.visitLabel(L37);
                code.visitStmt2R(MOVE_OBJECT,0,12);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,17);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,1},new Method("Lorg/mortbay/util/URIUtil;","addPaths",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,10);
                code.visitLabel(L38);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,20);
                code.visitFieldStmt(IGET_BOOLEAN,0,0,new Field("Lorg/mortbay/ijetty/servlet/DefaultServlet;","_redirectWelcome","Z"));
                code.visitStmt2R(MOVE_FROM16,18,0);
                code.visitJumpStmt(IF_EQZ,18,-1,L44);
                code.visitLabel(L39);
                code.visitConstStmt(CONST_16,18, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,22);
                code.visitStmt2R(MOVE_FROM16,1,18);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1},new Method("Ljavax/servlet/http/HttpServletResponse;","setContentLength",new String[]{ "I"},"V"));
                code.visitLabel(L40);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 21},new Method("Ljavax/servlet/http/HttpServletRequest;","getQueryString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,14);
                code.visitLabel(L41);
                code.visitJumpStmt(IF_EQZ,14,-1,L43);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 14},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,18);
                code.visitJumpStmt(IF_EQZ,18,-1,L43);
                code.visitLabel(L42);
                code.visitTypeStmt(NEW_INSTANCE,18,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT_RANGE,new int[]{ 18},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,20);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/ijetty/servlet/DefaultServlet;","_context","Lorg/mortbay/jetty/handler/ContextHandler$SContext;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,19,0);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 19},new Method("Lorg/mortbay/jetty/handler/ContextHandler$SContext;","getContextPath",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,19);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,19);
                code.visitStmt2R(MOVE_OBJECT,1,10);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,1},new Method("Lorg/mortbay/util/URIUtil;","addPaths",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,19);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 18,19},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,18);
                code.visitConstStmt(CONST_STRING,19,"?");
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 18,19},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,18);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,18);
                code.visitStmt2R(MOVE_OBJECT,1,14);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,18);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 18},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,18);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,18);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1},new Method("Ljavax/servlet/http/HttpServletResponse;","sendRedirect",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitJumpStmt(GOTO_16,-1,-1,L17);
                code.visitLabel(L43);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,20);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/ijetty/servlet/DefaultServlet;","_context","Lorg/mortbay/jetty/handler/ContextHandler$SContext;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,18,0);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 18},new Method("Lorg/mortbay/jetty/handler/ContextHandler$SContext;","getContextPath",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,18);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,18);
                code.visitStmt2R(MOVE_OBJECT,1,10);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,1},new Method("Lorg/mortbay/util/URIUtil;","addPaths",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,18);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,18);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1},new Method("Ljavax/servlet/http/HttpServletResponse;","sendRedirect",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitJumpStmt(GOTO_16,-1,-1,L17);
                code.visitLabel(L44);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitStmt2R(MOVE_OBJECT,1,10);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1},new Method("Ljavax/servlet/http/HttpServletRequest;","getRequestDispatcher",new String[]{ "Ljava/lang/String;"},"Ljavax/servlet/RequestDispatcher;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitLabel(L45);
                code.visitJumpStmt(IF_EQZ,7,-1,L17);
                code.visitLabel(L46);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9},new Method("Ljava/lang/Boolean;","booleanValue",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,18);
                code.visitJumpStmt(IF_EQZ,18,-1,L48);
                code.visitLabel(L47);
                code.visitStmt2R(MOVE_OBJECT,0,7);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,21);
                code.visitStmt2R(MOVE_OBJECT_FROM16,2,22);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1,2},new Method("Ljavax/servlet/RequestDispatcher;","include",new String[]{ "Ljavax/servlet/ServletRequest;","Ljavax/servlet/ServletResponse;"},"V"));
                code.visitJumpStmt(GOTO_16,-1,-1,L17);
                code.visitLabel(L48);
                code.visitConstStmt(CONST_STRING,18,"org.mortbay.jetty.welcome");
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,18);
                code.visitStmt2R(MOVE_OBJECT,2,10);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1,2},new Method("Ljavax/servlet/http/HttpServletRequest;","setAttribute",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L49);
                code.visitStmt2R(MOVE_OBJECT,0,7);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,21);
                code.visitStmt2R(MOVE_OBJECT_FROM16,2,22);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1,2},new Method("Ljavax/servlet/RequestDispatcher;","forward",new String[]{ "Ljavax/servlet/ServletRequest;","Ljavax/servlet/ServletResponse;"},"V"));
                code.visitJumpStmt(GOTO_16,-1,-1,L17);
                code.visitLabel(L50);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9},new Method("Ljava/lang/Boolean;","booleanValue",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,18);
                code.visitJumpStmt(IF_NEZ,18,-1,L51);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,20);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,21);
                code.visitStmt2R(MOVE_OBJECT_FROM16,2,22);
                code.visitStmt2R(MOVE_OBJECT,3,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2,3},new Method("Lorg/mortbay/ijetty/servlet/DefaultServlet;","passConditionalHeaders",new String[]{ "Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;","Lorg/mortbay/ijetty/resource/AndroidFileResource;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,18);
                code.visitJumpStmt(IF_EQZ,18,-1,L17);
                code.visitLabel(L51);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,18);
                code.visitConstStmt(CONST_16,19, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt2R(MOVE_FROM16,0,18);
                code.visitStmt2R(MOVE_FROM16,1,19);
                DexLabel L56=new DexLabel();
                code.visitJumpStmt(IF_LE,0,1,L56);
                code.visitConstStmt(CONST_16,18, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                DexLabel L57=new DexLabel();
                code.visitLabel(L57);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,20);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,21);
                code.visitStmt2R(MOVE_OBJECT_FROM16,2,22);
                code.visitStmt2R(MOVE_OBJECT,3,5);
                code.visitStmt2R(MOVE_FROM16,4,18);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2,3,4},new Method("Lorg/mortbay/ijetty/servlet/DefaultServlet;","sendDirectory",new String[]{ "Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;","Lorg/mortbay/ijetty/resource/AndroidFileResource;","Z"},"V"));
                code.visitJumpStmt(GOTO_16,-1,-1,L17);
                code.visitLabel(L56);
                code.visitConstStmt(CONST_16,18, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L57);
                code.visitLabel(L52);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/ijetty/resource/AndroidFileResource;","exists",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,18);
                code.visitJumpStmt(IF_EQZ,18,-1,L55);
                code.visitLabel(L53);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9},new Method("Ljava/lang/Boolean;","booleanValue",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,18);
                code.visitJumpStmt(IF_NEZ,18,-1,L54);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,20);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,21);
                code.visitStmt2R(MOVE_OBJECT_FROM16,2,22);
                code.visitStmt2R(MOVE_OBJECT,3,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2,3},new Method("Lorg/mortbay/ijetty/servlet/DefaultServlet;","passConditionalHeaders",new String[]{ "Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;","Lorg/mortbay/ijetty/resource/AndroidFileResource;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,18);
                code.visitJumpStmt(IF_EQZ,18,-1,L17);
                code.visitLabel(L54);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9},new Method("Ljava/lang/Boolean;","booleanValue",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,18);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,20);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,21);
                code.visitStmt2R(MOVE_OBJECT_FROM16,2,22);
                code.visitStmt2R(MOVE_FROM16,3,18);
                code.visitStmt2R(MOVE_OBJECT,4,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2,3,4},new Method("Lorg/mortbay/ijetty/servlet/DefaultServlet;","sendData",new String[]{ "Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;","Z","Lorg/mortbay/ijetty/resource/AndroidFileResource;"},"V"));
                code.visitJumpStmt(GOTO_16,-1,-1,L17);
                code.visitLabel(L55);
                code.visitConstStmt(CONST_16,18, Integer.valueOf(404)); // int: 0x00000194  float:0.000000
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,22);
                code.visitStmt2R(MOVE_FROM16,1,18);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1},new Method("Ljavax/servlet/http/HttpServletResponse;","sendError",new String[]{ "I"},"V"));
                code.visitJumpStmt(GOTO_16,-1,-1,L17);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_doPost(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/ijetty/servlet/DefaultServlet;","doPost",new String[]{ "Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljavax/servlet/ServletException;"));
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"req");
                ddv.visitParameterName(1,"resp");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(189,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(190,L1);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Lorg/mortbay/ijetty/servlet/DefaultServlet;","doGet",new String[]{ "Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;"},"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_doTrace(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/ijetty/servlet/DefaultServlet;","doTrace",new String[]{ "Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljavax/servlet/ServletException;"));
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"req");
                ddv.visitParameterName(1,"resp");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(194,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(195,L1);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_16,0, Integer.valueOf(405)); // int: 0x00000195  float:0.000000
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3,0},new Method("Ljavax/servlet/http/HttpServletResponse;","sendError",new String[]{ "I"},"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_getResource(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/ijetty/servlet/DefaultServlet;","getResource",new String[]{ "Ljava/net/URL;"},"Lorg/mortbay/ijetty/resource/AndroidFileResource;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"url");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(71,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(72,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(74,L2);
                code.visitLabel(L0);
                DexLabel L3=new DexLabel();
                code.visitJumpStmt(IF_NEZ,2,-1,L3);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L2);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L3);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/ijetty/resource/AndroidFileResource;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,2},new Method("Lorg/mortbay/ijetty/resource/AndroidFileResource;","<init>",new String[]{ "Ljava/net/URL;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_init(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/ijetty/servlet/DefaultServlet;","init",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(59,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(60,L1);
                ddv.visitStartLocal(1,L1,"tmp","Ljava/lang/String;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(61,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(62,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(63,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(64,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(65,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(66,L7);
                ddv.visitStartLocal(0,L7,"config","Ljavax/servlet/ServletContext;",null);
                DexLabel L8=new DexLabel();
                ddv.visitEndLocal(0,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(67,L9);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_STRING,2,"redirectWelcome");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,2},new Method("Lorg/mortbay/ijetty/servlet/DefaultServlet;","getInitParameter",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L1);
                code.visitJumpStmt(IF_EQZ,1,-1,L3);
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/lang/String;","trim",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2},new Method("Ljava/lang/Boolean;","valueOf",new String[]{ "Ljava/lang/String;"},"Ljava/lang/Boolean;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/lang/Boolean;","booleanValue",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitFieldStmt(IPUT_BOOLEAN,2,3,new Field("Lorg/mortbay/ijetty/servlet/DefaultServlet;","_redirectWelcome","Z"));
                code.visitLabel(L3);
                code.visitConstStmt(CONST_STRING,2,"dirAllowed");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,2},new Method("Lorg/mortbay/ijetty/servlet/DefaultServlet;","getInitParameter",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L4);
                code.visitJumpStmt(IF_EQZ,1,-1,L6);
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/lang/String;","trim",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2},new Method("Ljava/lang/Boolean;","valueOf",new String[]{ "Ljava/lang/String;"},"Ljava/lang/Boolean;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/lang/Boolean;","booleanValue",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitFieldStmt(IPUT_BOOLEAN,2,3,new Field("Lorg/mortbay/ijetty/servlet/DefaultServlet;","_dirAllowed","Z"));
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/ijetty/servlet/DefaultServlet;","getServletContext",new String[]{ },"Ljavax/servlet/ServletContext;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L7);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Lorg/mortbay/jetty/handler/ContextHandler$SContext;");
                code.visitLabel(L8);
                code.visitFieldStmt(IPUT_OBJECT,0,3,new Field("Lorg/mortbay/ijetty/servlet/DefaultServlet;","_context","Lorg/mortbay/jetty/handler/ContextHandler$SContext;"));
                code.visitLabel(L9);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m007_passConditionalHeaders(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/ijetty/servlet/DefaultServlet;","passConditionalHeaders",new String[]{ "Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;","Lorg/mortbay/ijetty/resource/AndroidFileResource;"},"Z"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(14);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"request");
                ddv.visitParameterName(1,"response");
                ddv.visitParameterName(2,"androidResource");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(203,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(205,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(206,L3);
                ddv.visitStartLocal(2,L3,"ifms","Ljava/lang/String;",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(208,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(217,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(218,L6);
                ddv.visitStartLocal(3,L6,"ifmsl","J",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(233,L7);
                ddv.visitEndLocal(3,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(235,L8);
                ddv.visitStartLocal(0,L8,"date","J",null);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(247,L9);
                ddv.visitEndLocal(2,L9);
                ddv.visitEndLocal(0,L9);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_WIDE_16,7,Long.valueOf(-1L)); // long: 0xffffffffffffffff  double:NaN
                code.visitConstStmt(CONST_STRING,9,"If-Modified-Since");
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 11},new Method("Ljavax/servlet/http/HttpServletRequest;","getMethod",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitConstStmt(CONST_STRING,6,"HEAD");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitJumpStmt(IF_NEZ,5,-1,L9);
                code.visitLabel(L2);
                code.visitConstStmt(CONST_STRING,5,"If-Modified-Since");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 11,9},new Method("Ljavax/servlet/http/HttpServletRequest;","getHeader",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L3);
                code.visitJumpStmt(IF_EQZ,2,-1,L7);
                code.visitLabel(L4);
                code.visitJumpStmt(IF_EQZ,13,-1,L5);
                code.visitLabel(L5);
                code.visitConstStmt(CONST_STRING,5,"If-Modified-Since");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 11,9},new Method("Ljavax/servlet/http/HttpServletRequest;","getDateHeader",new String[]{ "Ljava/lang/String;"},"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,3);
                code.visitLabel(L6);
                code.visitStmt3R(CMP_LONG,5,3,7);
                code.visitJumpStmt(IF_EQZ,5,-1,L7);
                code.visitLabel(L7);
                code.visitConstStmt(CONST_STRING,5,"If-Unmodified-Since");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 11,5},new Method("Ljavax/servlet/http/HttpServletRequest;","getDateHeader",new String[]{ "Ljava/lang/String;"},"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,0);
                code.visitLabel(L8);
                code.visitStmt3R(CMP_LONG,5,0,7);
                code.visitJumpStmt(IF_EQZ,5,-1,L9);
                code.visitLabel(L9);
                code.visitConstStmt(CONST_4,5, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt1R(RETURN,5);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m008_sendData(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/ijetty/servlet/DefaultServlet;","sendData",new String[]{ "Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;","Z","Lorg/mortbay/ijetty/resource/AndroidFileResource;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(8);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/lang/IllegalStateException;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"request");
                ddv.visitParameterName(1,"response");
                ddv.visitParameterName(2,"include");
                ddv.visitParameterName(3,"afr");
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(288,L3);
                ddv.visitLineNumber(289,L0);
                ddv.visitStartLocal(1,L0,"out","Ljava/io/OutputStream;",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(292,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(294,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(302,L6);
                ddv.visitLineNumber(290,L2);
                DexLabel L7=new DexLabel();
                ddv.visitStartLocal(0,L7,"e","Ljava/lang/IllegalStateException;",null);
                DexLabel L8=new DexLabel();
                ddv.visitEndLocal(1,L8);
                DexLabel L9=new DexLabel();
                ddv.visitRestartLocal(1,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(299,L10);
                ddv.visitEndLocal(0,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(300,L11);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 5},new Method("Ljavax/servlet/http/HttpServletResponse;","getOutputStream",new String[]{ },"Ljavax/servlet/ServletOutputStream;"));
                code.visitLabel(L1);
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L4);
                code.visitJumpStmt(IF_EQZ,6,-1,L10);
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,1},new Method("Lorg/mortbay/ijetty/resource/AndroidFileResource;","writeTo",new String[]{ "Ljava/io/OutputStream;"},"V"));
                code.visitLabel(L6);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,0);
                code.visitLabel(L7);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Lorg/mortbay/io/WriterOutputStream;");
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 5},new Method("Ljavax/servlet/http/HttpServletResponse;","getWriter",new String[]{ },"Ljava/io/PrintWriter;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,2},new Method("Lorg/mortbay/io/WriterOutputStream;","<init>",new String[]{ "Ljava/io/Writer;"},"V"));
                code.visitLabel(L9);
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,5,7},new Method("Lorg/mortbay/ijetty/servlet/DefaultServlet;","writeHeaders",new String[]{ "Ljavax/servlet/http/HttpServletResponse;","Lorg/mortbay/ijetty/resource/AndroidFileResource;"},"V"));
                code.visitLabel(L11);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,1},new Method("Lorg/mortbay/ijetty/resource/AndroidFileResource;","writeTo",new String[]{ "Ljava/io/OutputStream;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L6);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m009_sendDirectory(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/ijetty/servlet/DefaultServlet;","sendDirectory",new String[]{ "Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;","Lorg/mortbay/ijetty/resource/AndroidFileResource;","Z"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(10);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"request");
                ddv.visitParameterName(1,"response");
                ddv.visitParameterName(2,"resource");
                ddv.visitParameterName(3,"parent");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(264,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(265,L1);
                ddv.visitStartLocal(1,L1,"data","[B",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(266,L2);
                ddv.visitStartLocal(0,L2,"base","Ljava/lang/String;",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(267,L3);
                ddv.visitStartLocal(2,L3,"dir","Ljava/lang/String;",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(269,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(278,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(274,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(275,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(276,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(277,L9);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 6},new Method("Ljavax/servlet/http/HttpServletRequest;","getRequestURI",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitConstStmt(CONST_STRING,4,"/");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3,4},new Method("Lorg/mortbay/util/URIUtil;","addPaths",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,0,9},new Method("Lorg/mortbay/ijetty/resource/AndroidFileResource;","getListHTML",new String[]{ "Ljava/lang/String;","Z"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L3);
                code.visitJumpStmt(IF_NEZ,2,-1,L6);
                code.visitLabel(L4);
                code.visitConstStmt(CONST_16,3, Integer.valueOf(403)); // int: 0x00000193  float:0.000000
                code.visitConstStmt(CONST_STRING,4,"No directory");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 7,3,4},new Method("Ljavax/servlet/http/HttpServletResponse;","sendError",new String[]{ "I","Ljava/lang/String;"},"V"));
                code.visitLabel(L5);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L6);
                code.visitConstStmt(CONST_STRING,3,"UTF-8");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/String;","getBytes",new String[]{ "Ljava/lang/String;"},"[B"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L7);
                code.visitConstStmt(CONST_STRING,3,"text/html; charset=UTF-8");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 7,3},new Method("Ljavax/servlet/http/HttpServletResponse;","setContentType",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L8);
                code.visitStmt2R(ARRAY_LENGTH,3,1);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 7,3},new Method("Ljavax/servlet/http/HttpServletResponse;","setContentLength",new String[]{ "I"},"V"));
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 7},new Method("Ljavax/servlet/http/HttpServletResponse;","getOutputStream",new String[]{ },"Ljavax/servlet/ServletOutputStream;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,1},new Method("Ljavax/servlet/ServletOutputStream;","write",new String[]{ "[B"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m010_setResources(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/ijetty/servlet/DefaultServlet;","setResources",new String[]{ "Landroid/content/res/Resources;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"resources");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(343,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(344,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/ijetty/servlet/DefaultServlet;","_resources","Landroid/content/res/Resources;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m011_writeHeaders(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/ijetty/servlet/DefaultServlet;","writeHeaders",new String[]{ "Ljavax/servlet/http/HttpServletResponse;","Lorg/mortbay/ijetty/resource/AndroidFileResource;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(10);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"response");
                ddv.visitParameterName(1,"afr");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(308,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(324,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(311,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(312,L3);
                ddv.visitStartLocal(2,L3,"lml","J",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(314,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(315,L5);
                ddv.visitStartLocal(4,L5,"r","Lorg/mortbay/jetty/Response;",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(316,L6);
                ddv.visitStartLocal(1,L6,"fields","Lorg/mortbay/jetty/HttpFields;",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(317,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(321,L8);
                ddv.visitEndLocal(4,L8);
                ddv.visitEndLocal(1,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(322,L9);
                code.visitLabel(L0);
                code.visitJumpStmt(IF_NEZ,9,-1,L2);
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9},new Method("Lorg/mortbay/ijetty/resource/AndroidFileResource;","lastModified",new String[]{ },"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,2);
                code.visitLabel(L3);
                code.visitTypeStmt(INSTANCE_OF,5,8,"Lorg/mortbay/jetty/Response;");
                code.visitJumpStmt(IF_EQZ,5,-1,L8);
                code.visitLabel(L4);
                code.visitStmt2R(MOVE_OBJECT,0,8);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Lorg/mortbay/jetty/Response;");
                code.visitStmt2R(MOVE_OBJECT,4,0);
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/jetty/Response;","getHttpFields",new String[]{ },"Lorg/mortbay/jetty/HttpFields;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L6);
                code.visitConstStmt(CONST_WIDE_16,5,Long.valueOf(-1L)); // long: 0xffffffffffffffff  double:NaN
                code.visitStmt3R(CMP_LONG,5,2,5);
                code.visitJumpStmt(IF_EQZ,5,-1,L1);
                code.visitLabel(L7);
                code.visitFieldStmt(SGET_OBJECT,5,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","LAST_MODIFIED_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,5,2,3},new Method("Lorg/mortbay/jetty/HttpFields;","putDateField",new String[]{ "Lorg/mortbay/io/Buffer;","J"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitLabel(L8);
                code.visitConstStmt(CONST_WIDE_16,5,Long.valueOf(0L)); // long: 0x0000000000000000  double:0.000000
                code.visitStmt3R(CMP_LONG,5,2,5);
                code.visitJumpStmt(IF_LEZ,5,-1,L1);
                code.visitLabel(L9);
                code.visitConstStmt(CONST_STRING,5,"Last-Modified");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 8,5,2,3},new Method("Ljavax/servlet/http/HttpServletResponse;","setDateHeader",new String[]{ "Ljava/lang/String;","J"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
