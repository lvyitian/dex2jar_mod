package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0184_org_mortbay_jetty_Request {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/jetty/Request;","Ljava/lang/Object;",new String[]{ "Ljavax/servlet/http/HttpServletRequest;"});
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("Request.java");
        f000_STATE_DELIMITER(cv);
        f001_STATE_NAME(cv);
        f002_STATE_QUOTED_VALUE(cv);
        f003_STATE_UNQUOTED_VALUE(cv);
        f004_STATE_VALUE(cv);
        f005__STREAM(cv);
        f006___NONE(cv);
        f007___READER(cv);
        f008___defaultLocale(cv);
        f009__attributes(cv);
        f010__authType(cv);
        f011__baseParameters(cv);
        f012__characterEncoding(cv);
        f013__connection(cv);
        f014__context(cv);
        f015__contextPath(cv);
        f016__continuation(cv);
        f017__cookies(cv);
        f018__cookiesExtracted(cv);
        f019__dns(cv);
        f020__endp(cv);
        f021__handled(cv);
        f022__inputState(cv);
        f023__lastCookies(cv);
        f024__method(cv);
        f025__parameters(cv);
        f026__paramsExtracted(cv);
        f027__pathInfo(cv);
        f028__port(cv);
        f029__protocol(cv);
        f030__queryEncoding(cv);
        f031__queryString(cv);
        f032__reader(cv);
        f033__readerEncoding(cv);
        f034__remoteAddr(cv);
        f035__remoteHost(cv);
        f036__requestAttributeListeners(cv);
        f037__requestListeners(cv);
        f038__requestURI(cv);
        f039__requestedSessionId(cv);
        f040__requestedSessionIdFromCookie(cv);
        f041__roleMap(cv);
        f042__savedNewSessions(cv);
        f043__scheme(cv);
        f044__serverName(cv);
        f045__servletName(cv);
        f046__servletPath(cv);
        f047__session(cv);
        f048__sessionManager(cv);
        f049__timeStamp(cv);
        f050__timeStampBuffer(cv);
        f051__uri(cv);
        f052__userPrincipal(cv);
        f053__userRealm(cv);
        m000__clinit_(cv);
        m001__init_(cv);
        m002__init_(cv);
        m003_extractParameters(cv);
        m004_getRequest(cv);
        m005_addEventListener(cv);
        m006_getAttribute(cv);
        m007_getAttributeNames(cv);
        m008_getAttributes(cv);
        m009_getAuthType(cv);
        m010_getCharacterEncoding(cv);
        m011_getConnection(cv);
        m012_getContentLength(cv);
        m013_getContentRead(cv);
        m014_getContentType(cv);
        m015_getContext(cv);
        m016_getContextPath(cv);
        m017_getContinuation(cv);
        m018_getContinuation(cv);
        m019_getCookies(cv);
        m020_getDateHeader(cv);
        m021_getHeader(cv);
        m022_getHeaderNames(cv);
        m023_getHeaders(cv);
        m024_getInputState(cv);
        m025_getInputStream(cv);
        m026_getIntHeader(cv);
        m027_getLocalAddr(cv);
        m028_getLocalName(cv);
        m029_getLocalPort(cv);
        m030_getLocale(cv);
        m031_getLocales(cv);
        m032_getMethod(cv);
        m033_getParameter(cv);
        m034_getParameterMap(cv);
        m035_getParameterNames(cv);
        m036_getParameterValues(cv);
        m037_getParameters(cv);
        m038_getPathInfo(cv);
        m039_getPathTranslated(cv);
        m040_getProtocol(cv);
        m041_getQueryEncoding(cv);
        m042_getQueryString(cv);
        m043_getReader(cv);
        m044_getRealPath(cv);
        m045_getRemoteAddr(cv);
        m046_getRemoteHost(cv);
        m047_getRemotePort(cv);
        m048_getRemoteUser(cv);
        m049_getRequestDispatcher(cv);
        m050_getRequestURI(cv);
        m051_getRequestURL(cv);
        m052_getRequestedSessionId(cv);
        m053_getRoleMap(cv);
        m054_getRootURL(cv);
        m055_getScheme(cv);
        m056_getServerName(cv);
        m057_getServerPort(cv);
        m058_getServletContext(cv);
        m059_getServletName(cv);
        m060_getServletPath(cv);
        m061_getServletResponse(cv);
        m062_getSession(cv);
        m063_getSession(cv);
        m064_getSessionManager(cv);
        m065_getTimeStamp(cv);
        m066_getTimeStampBuffer(cv);
        m067_getUri(cv);
        m068_getUserPrincipal(cv);
        m069_getUserRealm(cv);
        m070_isHandled(cv);
        m071_isRequestedSessionIdFromCookie(cv);
        m072_isRequestedSessionIdFromURL(cv);
        m073_isRequestedSessionIdFromUrl(cv);
        m074_isRequestedSessionIdValid(cv);
        m075_isSecure(cv);
        m076_isUserInRole(cv);
        m077_recoverNewSession(cv);
        m078_recycle(cv);
        m079_removeAttribute(cv);
        m080_removeEventListener(cv);
        m081_saveNewSession(cv);
        m082_setAttribute(cv);
        m083_setAttributes(cv);
        m084_setAuthType(cv);
        m085_setCharacterEncoding(cv);
        m086_setCharacterEncodingUnchecked(cv);
        m087_setConnection(cv);
        m088_setContentType(cv);
        m089_setContext(cv);
        m090_setContextPath(cv);
        m091_setContinuation(cv);
        m092_setCookies(cv);
        m093_setHandled(cv);
        m094_setMethod(cv);
        m095_setParameters(cv);
        m096_setPathInfo(cv);
        m097_setProtocol(cv);
        m098_setQueryEncoding(cv);
        m099_setQueryString(cv);
        m100_setRemoteAddr(cv);
        m101_setRemoteHost(cv);
        m102_setRequestListeners(cv);
        m103_setRequestURI(cv);
        m104_setRequestedSessionId(cv);
        m105_setRequestedSessionIdFromCookie(cv);
        m106_setRoleMap(cv);
        m107_setScheme(cv);
        m108_setServerName(cv);
        m109_setServerPort(cv);
        m110_setServletName(cv);
        m111_setServletPath(cv);
        m112_setSession(cv);
        m113_setSessionManager(cv);
        m114_setTimeStamp(cv);
        m115_setUri(cv);
        m116_setUserPrincipal(cv);
        m117_setUserRealm(cv);
        m118_takeRequestListeners(cv);
        m119_toString(cv);
    }
    public static void f000_STATE_DELIMITER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/Request;","STATE_DELIMITER","B"), Byte.valueOf((byte)1));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001_STATE_NAME(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/Request;","STATE_NAME","B"), Byte.valueOf((byte)2));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002_STATE_QUOTED_VALUE(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/Request;","STATE_QUOTED_VALUE","B"), Byte.valueOf((byte)8));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003_STATE_UNQUOTED_VALUE(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/Request;","STATE_UNQUOTED_VALUE","B"), Byte.valueOf((byte)16));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f004_STATE_VALUE(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/Request;","STATE_VALUE","B"), Byte.valueOf((byte)4));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f005__STREAM(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/Request;","_STREAM","I"),  Integer.valueOf(1));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f006___NONE(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/Request;","__NONE","I"),  Integer.valueOf(0));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f007___READER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/Request;","__READER","I"),  Integer.valueOf(2));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f008___defaultLocale(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/Request;","__defaultLocale","Ljava/util/Collection;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f009__attributes(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/Request;","_attributes","Lorg/mortbay/util/Attributes;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f010__authType(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/Request;","_authType","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f011__baseParameters(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/Request;","_baseParameters","Lorg/mortbay/util/MultiMap;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f012__characterEncoding(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/Request;","_characterEncoding","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f013__connection(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/Request;","_connection","Lorg/mortbay/jetty/HttpConnection;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f014__context(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/Request;","_context","Lorg/mortbay/jetty/handler/ContextHandler$SContext;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f015__contextPath(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/Request;","_contextPath","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f016__continuation(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/Request;","_continuation","Lorg/mortbay/util/ajax/Continuation;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f017__cookies(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/Request;","_cookies","[Ljavax/servlet/http/Cookie;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f018__cookiesExtracted(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/Request;","_cookiesExtracted","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f019__dns(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/Request;","_dns","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f020__endp(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/Request;","_endp","Lorg/mortbay/io/EndPoint;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f021__handled(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/Request;","_handled","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f022__inputState(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/Request;","_inputState","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f023__lastCookies(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/Request;","_lastCookies","[Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f024__method(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/Request;","_method","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f025__parameters(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/Request;","_parameters","Lorg/mortbay/util/MultiMap;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f026__paramsExtracted(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/Request;","_paramsExtracted","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f027__pathInfo(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/Request;","_pathInfo","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f028__port(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/Request;","_port","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f029__protocol(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/Request;","_protocol","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f030__queryEncoding(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/Request;","_queryEncoding","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f031__queryString(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/Request;","_queryString","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f032__reader(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/Request;","_reader","Ljava/io/BufferedReader;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f033__readerEncoding(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/Request;","_readerEncoding","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f034__remoteAddr(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/Request;","_remoteAddr","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f035__remoteHost(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/Request;","_remoteHost","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f036__requestAttributeListeners(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/Request;","_requestAttributeListeners","Ljava/lang/Object;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f037__requestListeners(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/Request;","_requestListeners","Ljava/lang/Object;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f038__requestURI(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/Request;","_requestURI","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f039__requestedSessionId(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/Request;","_requestedSessionId","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f040__requestedSessionIdFromCookie(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/Request;","_requestedSessionIdFromCookie","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f041__roleMap(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/Request;","_roleMap","Ljava/util/Map;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f042__savedNewSessions(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/Request;","_savedNewSessions","Ljava/util/Map;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f043__scheme(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/Request;","_scheme","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f044__serverName(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/Request;","_serverName","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f045__servletName(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/Request;","_servletName","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f046__servletPath(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/Request;","_servletPath","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f047__session(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/Request;","_session","Ljavax/servlet/http/HttpSession;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f048__sessionManager(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/Request;","_sessionManager","Lorg/mortbay/jetty/SessionManager;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f049__timeStamp(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/Request;","_timeStamp","J"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f050__timeStampBuffer(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/Request;","_timeStampBuffer","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f051__uri(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/Request;","_uri","Lorg/mortbay/jetty/HttpURI;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f052__userPrincipal(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/Request;","_userPrincipal","Ljava/security/Principal;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f053__userRealm(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/Request;","_userRealm","Lorg/mortbay/jetty/security/UserRealm;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__clinit_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/Request;","<clinit>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(111,L0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Ljava/util/Locale;","getDefault",new String[]{ },"Ljava/util/Locale;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Ljava/util/Collections;","singleton",new String[]{ "Ljava/lang/Object;"},"Ljava/util/Set;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/Request;","__defaultLocale","Ljava/util/Collection;"));
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/Request;","<init>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(166,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(114,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(129,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(132,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(134,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(143,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(146,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(150,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(167,L9);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2},new Method("Ljava/lang/Object;","<init>",new String[]{ },"V"));
                code.visitLabel(L2);
                code.visitFieldStmt(IPUT_BOOLEAN,1,2,new Field("Lorg/mortbay/jetty/Request;","_handled","Z"));
                code.visitLabel(L3);
                code.visitConstStmt(CONST_STRING,0,"HTTP/1.1");
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/jetty/Request;","_protocol","Ljava/lang/String;"));
                code.visitLabel(L4);
                code.visitFieldStmt(IPUT_BOOLEAN,1,2,new Field("Lorg/mortbay/jetty/Request;","_requestedSessionIdFromCookie","Z"));
                code.visitLabel(L5);
                code.visitConstStmt(CONST_STRING,0,"http");
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/jetty/Request;","_scheme","Ljava/lang/String;"));
                code.visitLabel(L6);
                code.visitFieldStmt(IPUT,1,2,new Field("Lorg/mortbay/jetty/Request;","_inputState","I"));
                code.visitLabel(L7);
                code.visitFieldStmt(IPUT_BOOLEAN,1,2,new Field("Lorg/mortbay/jetty/Request;","_dns","Z"));
                code.visitLabel(L8);
                code.visitFieldStmt(IPUT_BOOLEAN,1,2,new Field("Lorg/mortbay/jetty/Request;","_cookiesExtracted","Z"));
                code.visitLabel(L9);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/Request;","<init>",new String[]{ "Lorg/mortbay/jetty/HttpConnection;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"connection");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(174,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(114,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(129,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(132,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(134,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(143,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(146,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(150,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(175,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(176,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(177,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(178,L12);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2},new Method("Ljava/lang/Object;","<init>",new String[]{ },"V"));
                code.visitLabel(L2);
                code.visitFieldStmt(IPUT_BOOLEAN,1,2,new Field("Lorg/mortbay/jetty/Request;","_handled","Z"));
                code.visitLabel(L3);
                code.visitConstStmt(CONST_STRING,0,"HTTP/1.1");
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/jetty/Request;","_protocol","Ljava/lang/String;"));
                code.visitLabel(L4);
                code.visitFieldStmt(IPUT_BOOLEAN,1,2,new Field("Lorg/mortbay/jetty/Request;","_requestedSessionIdFromCookie","Z"));
                code.visitLabel(L5);
                code.visitConstStmt(CONST_STRING,0,"http");
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/jetty/Request;","_scheme","Ljava/lang/String;"));
                code.visitLabel(L6);
                code.visitFieldStmt(IPUT,1,2,new Field("Lorg/mortbay/jetty/Request;","_inputState","I"));
                code.visitLabel(L7);
                code.visitFieldStmt(IPUT_BOOLEAN,1,2,new Field("Lorg/mortbay/jetty/Request;","_dns","Z"));
                code.visitLabel(L8);
                code.visitFieldStmt(IPUT_BOOLEAN,1,2,new Field("Lorg/mortbay/jetty/Request;","_cookiesExtracted","Z"));
                code.visitLabel(L9);
                code.visitFieldStmt(IPUT_OBJECT,3,2,new Field("Lorg/mortbay/jetty/Request;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/jetty/HttpConnection;","getEndPoint",new String[]{ },"Lorg/mortbay/io/EndPoint;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/jetty/Request;","_endp","Lorg/mortbay/io/EndPoint;"));
                code.visitLabel(L11);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/Request;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/HttpConnection;","getResolveNames",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitFieldStmt(IPUT_BOOLEAN,0,2,new Field("Lorg/mortbay/jetty/Request;","_dns","Z"));
                code.visitLabel(L12);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_extractParameters(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PRIVATE, new Method("Lorg/mortbay/jetty/Request;","extractParameters",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(16);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L1},new String[]{ "Ljava/io/IOException;"});
                DexLabel L2=new DexLabel();
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                code.visitTryCatch(L2,L3,new DexLabel[]{L4},new String[]{ "Ljava/io/UnsupportedEncodingException;"});
                DexLabel L5=new DexLabel();
                DexLabel L6=new DexLabel();
                code.visitTryCatch(L5,L6,new DexLabel[]{L1},new String[]{ "Ljava/io/IOException;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L7=new DexLabel();
                ddv.visitPrologue(L7);
                ddv.visitLineNumber(1413,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(1414,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(1416,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(1418,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(1419,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(1509,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(1423,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(1426,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(1428,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(1429,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(1449,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(1450,L18);
                ddv.visitStartLocal(3,L18,"encoding","Ljava/lang/String;",null);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(1451,L19);
                ddv.visitStartLocal(1,L19,"content_type","Ljava/lang/String;",null);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(1453,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(1455,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(1458,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(1459,L23);
                ddv.visitStartLocal(0,L23,"content_length","I",null);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(1463,L24);
                ddv.visitLineNumber(1465,L0);
                ddv.visitStartLocal(8,L0,"maxFormContentSize","I",null);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(1466,L25);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(1474,L26);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(1476,L27);
                ddv.visitLineNumber(1483,L1);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(1485,L28);
                ddv.visitStartLocal(2,L28,"e","Ljava/io/IOException;",null);
                DexLabel L29=new DexLabel();
                ddv.visitLineNumber(1486,L29);
                DexLabel L30=new DexLabel();
                ddv.visitLineNumber(1494,L30);
                ddv.visitEndLocal(0,L30);
                ddv.visitEndLocal(8,L30);
                ddv.visitEndLocal(2,L30);
                DexLabel L31=new DexLabel();
                ddv.visitLineNumber(1495,L31);
                ddv.visitLineNumber(1434,L2);
                ddv.visitEndLocal(3,L2);
                ddv.visitEndLocal(1,L2);
                ddv.visitLineNumber(1437,L4);
                DexLabel L32=new DexLabel();
                ddv.visitLineNumber(1439,L32);
                ddv.visitStartLocal(2,L32,"e","Ljava/io/UnsupportedEncodingException;",null);
                DexLabel L33=new DexLabel();
                ddv.visitLineNumber(1440,L33);
                DexLabel L34=new DexLabel();
                ddv.visitLineNumber(1442,L34);
                ddv.visitLineNumber(1469,L5);
                ddv.visitEndLocal(2,L5);
                ddv.visitRestartLocal(0,L5);
                ddv.visitRestartLocal(1,L5);
                ddv.visitRestartLocal(3,L5);
                ddv.visitRestartLocal(8,L5);
                DexLabel L35=new DexLabel();
                ddv.visitLineNumber(1470,L35);
                ddv.visitStartLocal(10,L35,"size","Ljava/lang/Integer;",null);
                DexLabel L36=new DexLabel();
                ddv.visitLineNumber(1471,L36);
                DexLabel L37=new DexLabel();
                ddv.visitRestartLocal(8,L37);
                DexLabel L38=new DexLabel();
                ddv.visitLineNumber(1478,L38);
                ddv.visitEndLocal(10,L38);
                DexLabel L39=new DexLabel();
                ddv.visitLineNumber(1481,L39);
                ddv.visitStartLocal(6,L39,"in","Ljava/io/InputStream;",null);
                DexLabel L40=new DexLabel();
                ddv.visitLineNumber(1488,L40);
                ddv.visitEndLocal(6,L40);
                ddv.visitStartLocal(2,L40,"e","Ljava/io/IOException;",null);
                DexLabel L41=new DexLabel();
                ddv.visitLineNumber(1496,L41);
                ddv.visitEndLocal(0,L41);
                ddv.visitEndLocal(8,L41);
                ddv.visitEndLocal(2,L41);
                DexLabel L42=new DexLabel();
                ddv.visitLineNumber(1499,L42);
                DexLabel L43=new DexLabel();
                ddv.visitLineNumber(1500,L43);
                ddv.visitStartLocal(7,L43,"iter","Ljava/util/Iterator;",null);
                DexLabel L44=new DexLabel();
                ddv.visitLineNumber(1502,L44);
                DexLabel L45=new DexLabel();
                ddv.visitLineNumber(1503,L45);
                ddv.visitStartLocal(4,L45,"entry","Ljava/util/Map$Entry;",null);
                DexLabel L46=new DexLabel();
                ddv.visitLineNumber(1504,L46);
                ddv.visitStartLocal(9,L46,"name","Ljava/lang/String;",null);
                DexLabel L47=new DexLabel();
                ddv.visitLineNumber(1505,L47);
                ddv.visitStartLocal(11,L47,"values","Ljava/lang/Object;",null);
                DexLabel L48=new DexLabel();
                ddv.visitStartLocal(5,L48,"i","I",null);
                DexLabel L49=new DexLabel();
                ddv.visitLineNumber(1506,L49);
                DexLabel L50=new DexLabel();
                ddv.visitLineNumber(1505,L50);
                code.visitLabel(L7);
                code.visitFieldStmt(IGET_OBJECT,12,15,new Field("Lorg/mortbay/jetty/Request;","_baseParameters","Lorg/mortbay/util/MultiMap;"));
                code.visitJumpStmt(IF_NEZ,12,-1,L9);
                code.visitLabel(L8);
                code.visitTypeStmt(NEW_INSTANCE,12,-1,"Lorg/mortbay/util/MultiMap;");
                code.visitConstStmt(CONST_16,13, Integer.valueOf(16)); // int: 0x00000010  float:0.000000
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 12,13},new Method("Lorg/mortbay/util/MultiMap;","<init>",new String[]{ "I"},"V"));
                code.visitFieldStmt(IPUT_OBJECT,12,15,new Field("Lorg/mortbay/jetty/Request;","_baseParameters","Lorg/mortbay/util/MultiMap;"));
                code.visitLabel(L9);
                code.visitFieldStmt(IGET_BOOLEAN,12,15,new Field("Lorg/mortbay/jetty/Request;","_paramsExtracted","Z"));
                code.visitJumpStmt(IF_EQZ,12,-1,L13);
                code.visitLabel(L10);
                code.visitFieldStmt(IGET_OBJECT,12,15,new Field("Lorg/mortbay/jetty/Request;","_parameters","Lorg/mortbay/util/MultiMap;"));
                code.visitJumpStmt(IF_NEZ,12,-1,L12);
                code.visitLabel(L11);
                code.visitFieldStmt(IGET_OBJECT,12,15,new Field("Lorg/mortbay/jetty/Request;","_baseParameters","Lorg/mortbay/util/MultiMap;"));
                code.visitFieldStmt(IPUT_OBJECT,12,15,new Field("Lorg/mortbay/jetty/Request;","_parameters","Lorg/mortbay/util/MultiMap;"));
                code.visitLabel(L12);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L13);
                code.visitConstStmt(CONST_4,12, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitFieldStmt(IPUT_BOOLEAN,12,15,new Field("Lorg/mortbay/jetty/Request;","_paramsExtracted","Z"));
                code.visitLabel(L14);
                code.visitFieldStmt(IGET_OBJECT,12,15,new Field("Lorg/mortbay/jetty/Request;","_uri","Lorg/mortbay/jetty/HttpURI;"));
                code.visitJumpStmt(IF_EQZ,12,-1,L17);
                code.visitFieldStmt(IGET_OBJECT,12,15,new Field("Lorg/mortbay/jetty/Request;","_uri","Lorg/mortbay/jetty/HttpURI;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12},new Method("Lorg/mortbay/jetty/HttpURI;","hasQuery",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,12);
                code.visitJumpStmt(IF_EQZ,12,-1,L17);
                code.visitLabel(L15);
                code.visitFieldStmt(IGET_OBJECT,12,15,new Field("Lorg/mortbay/jetty/Request;","_queryEncoding","Ljava/lang/String;"));
                code.visitJumpStmt(IF_NEZ,12,-1,L2);
                code.visitLabel(L16);
                code.visitFieldStmt(IGET_OBJECT,12,15,new Field("Lorg/mortbay/jetty/Request;","_uri","Lorg/mortbay/jetty/HttpURI;"));
                code.visitFieldStmt(IGET_OBJECT,13,15,new Field("Lorg/mortbay/jetty/Request;","_baseParameters","Lorg/mortbay/util/MultiMap;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12,13},new Method("Lorg/mortbay/jetty/HttpURI;","decodeQueryTo",new String[]{ "Lorg/mortbay/util/MultiMap;"},"V"));
                code.visitLabel(L17);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 15},new Method("Lorg/mortbay/jetty/Request;","getCharacterEncoding",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitLabel(L18);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 15},new Method("Lorg/mortbay/jetty/Request;","getContentType",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L19);
                code.visitJumpStmt(IF_EQZ,1,-1,L30);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,12);
                code.visitJumpStmt(IF_LEZ,12,-1,L30);
                code.visitLabel(L20);
                code.visitConstStmt(CONST_4,12, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1,12},new Method("Lorg/mortbay/jetty/HttpFields;","valueParameters",new String[]{ "Ljava/lang/String;","Ljava/util/Map;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L21);
                code.visitConstStmt(CONST_STRING,12,"application/x-www-form-urlencoded");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12,1},new Method("Ljava/lang/String;","equalsIgnoreCase",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,12);
                code.visitJumpStmt(IF_EQZ,12,-1,L30);
                code.visitConstStmt(CONST_STRING,12,"POST");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 15},new Method("Lorg/mortbay/jetty/Request;","getMethod",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,13);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12,13},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,12);
                code.visitJumpStmt(IF_NEZ,12,-1,L22);
                code.visitConstStmt(CONST_STRING,12,"PUT");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 15},new Method("Lorg/mortbay/jetty/Request;","getMethod",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,13);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12,13},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,12);
                code.visitJumpStmt(IF_EQZ,12,-1,L30);
                code.visitLabel(L22);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 15},new Method("Lorg/mortbay/jetty/Request;","getContentLength",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitLabel(L23);
                code.visitJumpStmt(IF_EQZ,0,-1,L30);
                code.visitLabel(L24);
                code.visitConstStmt(CONST_4,8, Integer.valueOf(-1)); // int: 0xffffffff  float:NaN
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,12,15,new Field("Lorg/mortbay/jetty/Request;","_context","Lorg/mortbay/jetty/handler/ContextHandler$SContext;"));
                code.visitJumpStmt(IF_EQZ,12,-1,L5);
                code.visitLabel(L25);
                code.visitFieldStmt(IGET_OBJECT,12,15,new Field("Lorg/mortbay/jetty/Request;","_context","Lorg/mortbay/jetty/handler/ContextHandler$SContext;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12},new Method("Lorg/mortbay/jetty/handler/ContextHandler$SContext;","getContextHandler",new String[]{ },"Lorg/mortbay/jetty/handler/ContextHandler;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,12);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12},new Method("Lorg/mortbay/jetty/handler/ContextHandler;","getMaxFormContentSize",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitLabel(L26);
                code.visitJumpStmt(IF_LE,0,8,L38);
                code.visitJumpStmt(IF_LEZ,8,-1,L38);
                code.visitLabel(L27);
                code.visitTypeStmt(NEW_INSTANCE,12,-1,"Ljava/lang/IllegalStateException;");
                code.visitTypeStmt(NEW_INSTANCE,13,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 13},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,14,"Form too large");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13,14},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,13);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13,0},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "I"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,13);
                code.visitConstStmt(CONST_STRING,14,">");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13,14},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,13);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13,8},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "I"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,13);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,13);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 12,13},new Method("Ljava/lang/IllegalStateException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,12);
                code.visitLabel(L1);
                code.visitStmt1R(MOVE_EXCEPTION,12);
                code.visitStmt2R(MOVE_OBJECT,2,12);
                code.visitLabel(L28);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/log/Log;","isDebugEnabled",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,12);
                code.visitJumpStmt(IF_EQZ,12,-1,L40);
                code.visitLabel(L29);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2},new Method("Lorg/mortbay/log/Log;","warn",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitLabel(L30);
                code.visitFieldStmt(IGET_OBJECT,12,15,new Field("Lorg/mortbay/jetty/Request;","_parameters","Lorg/mortbay/util/MultiMap;"));
                code.visitJumpStmt(IF_NEZ,12,-1,L41);
                code.visitLabel(L31);
                code.visitFieldStmt(IGET_OBJECT,12,15,new Field("Lorg/mortbay/jetty/Request;","_baseParameters","Lorg/mortbay/util/MultiMap;"));
                code.visitFieldStmt(IPUT_OBJECT,12,15,new Field("Lorg/mortbay/jetty/Request;","_parameters","Lorg/mortbay/util/MultiMap;"));
                code.visitJumpStmt(GOTO_16,-1,-1,L12);
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,12,15,new Field("Lorg/mortbay/jetty/Request;","_uri","Lorg/mortbay/jetty/HttpURI;"));
                code.visitFieldStmt(IGET_OBJECT,13,15,new Field("Lorg/mortbay/jetty/Request;","_baseParameters","Lorg/mortbay/util/MultiMap;"));
                code.visitFieldStmt(IGET_OBJECT,14,15,new Field("Lorg/mortbay/jetty/Request;","_queryEncoding","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12,13,14},new Method("Lorg/mortbay/jetty/HttpURI;","decodeQueryTo",new String[]{ "Lorg/mortbay/util/MultiMap;","Ljava/lang/String;"},"V"));
                code.visitLabel(L3);
                code.visitJumpStmt(GOTO_16,-1,-1,L17);
                code.visitLabel(L4);
                code.visitStmt1R(MOVE_EXCEPTION,12);
                code.visitStmt2R(MOVE_OBJECT,2,12);
                code.visitLabel(L32);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/log/Log;","isDebugEnabled",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,12);
                code.visitJumpStmt(IF_EQZ,12,-1,L34);
                code.visitLabel(L33);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2},new Method("Lorg/mortbay/log/Log;","warn",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitJumpStmt(GOTO_16,-1,-1,L17);
                code.visitLabel(L34);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/io/UnsupportedEncodingException;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,12);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 12},new Method("Lorg/mortbay/log/Log;","warn",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitJumpStmt(GOTO_16,-1,-1,L17);
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,12,15,new Field("Lorg/mortbay/jetty/Request;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12},new Method("Lorg/mortbay/jetty/HttpConnection;","getConnector",new String[]{ },"Lorg/mortbay/jetty/Connector;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,12);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 12},new Method("Lorg/mortbay/jetty/Connector;","getServer",new String[]{ },"Lorg/mortbay/jetty/Server;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,12);
                code.visitConstStmt(CONST_STRING,13,"org.mortbay.jetty.Request.maxFormContentSize");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12,13},new Method("Lorg/mortbay/jetty/Server;","getAttribute",new String[]{ "Ljava/lang/String;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,10);
                code.visitTypeStmt(CHECK_CAST,10,-1,"Ljava/lang/Integer;");
                code.visitLabel(L35);
                code.visitJumpStmt(IF_EQZ,10,-1,L26);
                code.visitLabel(L36);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Ljava/lang/Integer;","intValue",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitLabel(L37);
                code.visitJumpStmt(GOTO,-1,-1,L26);
                code.visitLabel(L38);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 15},new Method("Lorg/mortbay/jetty/Request;","getInputStream",new String[]{ },"Ljavax/servlet/ServletInputStream;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitLabel(L39);
                code.visitFieldStmt(IGET_OBJECT,12,15,new Field("Lorg/mortbay/jetty/Request;","_baseParameters","Lorg/mortbay/util/MultiMap;"));
                DexLabel L51=new DexLabel();
                code.visitJumpStmt(IF_GEZ,0,-1,L51);
                code.visitStmt2R(MOVE,13,8);
                DexLabel L52=new DexLabel();
                code.visitLabel(L52);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 6,12,3,13},new Method("Lorg/mortbay/util/UrlEncoded;","decodeTo",new String[]{ "Ljava/io/InputStream;","Lorg/mortbay/util/MultiMap;","Ljava/lang/String;","I"},"V"));
                code.visitLabel(L6);
                code.visitJumpStmt(GOTO,-1,-1,L30);
                code.visitLabel(L51);
                code.visitConstStmt(CONST_4,13, Integer.valueOf(-1)); // int: 0xffffffff  float:NaN
                code.visitJumpStmt(GOTO,-1,-1,L52);
                code.visitLabel(L40);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/io/IOException;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,12);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 12},new Method("Lorg/mortbay/log/Log;","warn",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L30);
                code.visitLabel(L41);
                code.visitFieldStmt(IGET_OBJECT,12,15,new Field("Lorg/mortbay/jetty/Request;","_parameters","Lorg/mortbay/util/MultiMap;"));
                code.visitFieldStmt(IGET_OBJECT,13,15,new Field("Lorg/mortbay/jetty/Request;","_baseParameters","Lorg/mortbay/util/MultiMap;"));
                code.visitJumpStmt(IF_EQ,12,13,L12);
                code.visitLabel(L42);
                code.visitFieldStmt(IGET_OBJECT,12,15,new Field("Lorg/mortbay/jetty/Request;","_baseParameters","Lorg/mortbay/util/MultiMap;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12},new Method("Lorg/mortbay/util/MultiMap;","entrySet",new String[]{ },"Ljava/util/Set;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,12);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 12},new Method("Ljava/util/Set;","iterator",new String[]{ },"Ljava/util/Iterator;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitLabel(L43);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 7},new Method("Ljava/util/Iterator;","hasNext",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,12);
                code.visitJumpStmt(IF_EQZ,12,-1,L12);
                code.visitLabel(L44);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 7},new Method("Ljava/util/Iterator;","next",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitTypeStmt(CHECK_CAST,4,-1,"Ljava/util/Map$Entry;");
                code.visitLabel(L45);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 4},new Method("Ljava/util/Map$Entry;","getKey",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitTypeStmt(CHECK_CAST,9,-1,"Ljava/lang/String;");
                code.visitLabel(L46);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 4},new Method("Ljava/util/Map$Entry;","getValue",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,11);
                code.visitLabel(L47);
                code.visitConstStmt(CONST_4,5, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L48);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 11},new Method("Lorg/mortbay/util/LazyList;","size",new String[]{ "Ljava/lang/Object;"},"I"));
                code.visitStmt1R(MOVE_RESULT,12);
                code.visitJumpStmt(IF_GE,5,12,L43);
                code.visitLabel(L49);
                code.visitFieldStmt(IGET_OBJECT,12,15,new Field("Lorg/mortbay/jetty/Request;","_parameters","Lorg/mortbay/util/MultiMap;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 11,5},new Method("Lorg/mortbay/util/LazyList;","get",new String[]{ "Ljava/lang/Object;","I"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,13);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12,9,13},new Method("Lorg/mortbay/util/MultiMap;","add",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L50);
                code.visitStmt2R1N(ADD_INT_LIT8,5,5,1);
                code.visitJumpStmt(GOTO,-1,-1,L48);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_getRequest(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/jetty/Request;","getRequest",new String[]{ "Ljavax/servlet/http/HttpServletRequest;"},"Lorg/mortbay/jetty/Request;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"request");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1855,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(1856,L1);
                DexLabel L2=new DexLabel();
                ddv.visitEndLocal(1,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(1864,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(1858,L4);
                ddv.visitRestartLocal(1,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(1859,L5);
                DexLabel L6=new DexLabel();
                ddv.visitEndLocal(1,L6);
                DexLabel L7=new DexLabel();
                ddv.visitRestartLocal(1,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(1861,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(1862,L9);
                DexLabel L10=new DexLabel();
                ddv.visitEndLocal(1,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(1864,L11);
                ddv.visitRestartLocal(1,L11);
                code.visitLabel(L0);
                code.visitTypeStmt(INSTANCE_OF,0,1,"Lorg/mortbay/jetty/Request;");
                code.visitJumpStmt(IF_EQZ,0,-1,L4);
                code.visitLabel(L1);
                code.visitTypeStmt(CHECK_CAST,1,-1,"Lorg/mortbay/jetty/Request;");
                code.visitLabel(L2);
                code.visitStmt2R(MOVE_OBJECT,0,1);
                code.visitLabel(L3);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L4);
                code.visitTypeStmt(INSTANCE_OF,0,1,"Ljavax/servlet/ServletRequestWrapper;");
                code.visitJumpStmt(IF_EQZ,0,-1,L8);
                code.visitLabel(L5);
                code.visitTypeStmt(CHECK_CAST,1,-1,"Ljavax/servlet/ServletRequestWrapper;");
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljavax/servlet/ServletRequestWrapper;","getRequest",new String[]{ },"Ljavax/servlet/ServletRequest;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitTypeStmt(CHECK_CAST,1,-1,"Ljavax/servlet/http/HttpServletRequest;");
                code.visitLabel(L7);
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitLabel(L8);
                code.visitTypeStmt(INSTANCE_OF,0,1,"Lorg/mortbay/jetty/Request;");
                code.visitJumpStmt(IF_EQZ,0,-1,L11);
                code.visitLabel(L9);
                code.visitTypeStmt(CHECK_CAST,1,-1,"Lorg/mortbay/jetty/Request;");
                code.visitLabel(L10);
                code.visitStmt2R(MOVE_OBJECT,0,1);
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitLabel(L11);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/jetty/HttpConnection;","getCurrentConnection",new String[]{ },"Lorg/mortbay/jetty/HttpConnection;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/HttpConnection;","getRequest",new String[]{ },"Lorg/mortbay/jetty/Request;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_addEventListener(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Request;","addEventListener",new String[]{ "Ljava/util/EventListener;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"listener");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1870,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(1871,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(1872,L2);
                code.visitLabel(L0);
                code.visitTypeStmt(INSTANCE_OF,0,2,"Ljavax/servlet/ServletRequestAttributeListener;");
                code.visitJumpStmt(IF_EQZ,0,-1,L2);
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/Request;","_requestAttributeListeners","Ljava/lang/Object;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,2},new Method("Lorg/mortbay/util/LazyList;","add",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/Request;","_requestAttributeListeners","Ljava/lang/Object;"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_getAttribute(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Request;","getAttribute",new String[]{ "Ljava/lang/String;"},"Ljava/lang/Object;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(279,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(280,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(284,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(282,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(283,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(284,L5);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_STRING,0,"org.mortbay.jetty.ajax.Continuation");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,2},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L3);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,0},new Method("Lorg/mortbay/jetty/Request;","getContinuation",new String[]{ "Z"},"Lorg/mortbay/util/ajax/Continuation;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L2);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/Request;","_attributes","Lorg/mortbay/util/Attributes;"));
                code.visitJumpStmt(IF_NEZ,0,-1,L5);
                code.visitLabel(L4);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/Request;","_attributes","Lorg/mortbay/util/Attributes;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,2},new Method("Lorg/mortbay/util/Attributes;","getAttribute",new String[]{ "Ljava/lang/String;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m007_getAttributeNames(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Request;","getAttributeNames",new String[]{ },"Ljava/util/Enumeration;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(293,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(294,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(295,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/Request;","_attributes","Lorg/mortbay/util/Attributes;"));
                DexLabel L3=new DexLabel();
                code.visitJumpStmt(IF_NEZ,0,-1,L3);
                code.visitLabel(L1);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Ljava/util/Collections;","EMPTY_LIST","Ljava/util/List;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Ljava/util/Collections;","enumeration",new String[]{ "Ljava/util/Collection;"},"Ljava/util/Enumeration;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L2);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/Request;","_attributes","Lorg/mortbay/util/Attributes;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/util/AttributesMap;","getAttributeNamesCopy",new String[]{ "Lorg/mortbay/util/Attributes;"},"Ljava/util/Enumeration;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m008_getAttributes(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Request;","getAttributes",new String[]{ },"Lorg/mortbay/util/Attributes;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1792,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(1793,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(1794,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/Request;","_attributes","Lorg/mortbay/util/Attributes;"));
                code.visitJumpStmt(IF_NEZ,0,-1,L2);
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/util/AttributesMap;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Lorg/mortbay/util/AttributesMap;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/Request;","_attributes","Lorg/mortbay/util/Attributes;"));
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/Request;","_attributes","Lorg/mortbay/util/Attributes;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m009_getAuthType(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Request;","getAuthType",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(304,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/Request;","_authType","Ljava/lang/String;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m010_getCharacterEncoding(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Request;","getCharacterEncoding",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(313,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/Request;","_characterEncoding","Ljava/lang/String;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m011_getConnection(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Request;","getConnection",new String[]{ },"Lorg/mortbay/jetty/HttpConnection;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1571,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/Request;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m012_getContentLength(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Request;","getContentLength",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(330,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/Request;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/HttpConnection;","getRequestFields",new String[]{ },"Lorg/mortbay/jetty/HttpFields;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(SGET_OBJECT,1,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","CONTENT_LENGTH_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/HttpFields;","getLongField",new String[]{ "Lorg/mortbay/io/Buffer;"},"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,0);
                code.visitStmt2R(LONG_TO_INT,0,0);
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m013_getContentRead(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Request;","getContentRead",new String[]{ },"J"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(318,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(319,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(321,L2);
                ddv.visitEndLocal(2,L2);
                DexLabel L3=new DexLabel();
                ddv.visitRestartLocal(2,L3);
                DexLabel L4=new DexLabel();
                ddv.visitEndLocal(2,L4);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/Request;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L1);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/Request;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/HttpConnection;","getParser",new String[]{ },"Lorg/mortbay/jetty/Parser;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitJumpStmt(IF_NEZ,0,-1,L3);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_WIDE_16,0,Long.valueOf(-1L)); // long: 0xffffffffffffffff  double:NaN
                code.visitLabel(L2);
                code.visitStmt1R(RETURN_WIDE,0);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/Request;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/HttpConnection;","getParser",new String[]{ },"Lorg/mortbay/jetty/Parser;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L4);
                code.visitTypeStmt(CHECK_CAST,2,-1,"Lorg/mortbay/jetty/HttpParser;");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/HttpParser;","getContentRead",new String[]{ },"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,0);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m014_getContentType(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Request;","getContentType",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(339,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/Request;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/HttpConnection;","getRequestFields",new String[]{ },"Lorg/mortbay/jetty/HttpFields;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(SGET_OBJECT,1,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","CONTENT_TYPE_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/HttpFields;","getStringField",new String[]{ "Lorg/mortbay/io/Buffer;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m015_getContext(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Request;","getContext",new String[]{ },"Lorg/mortbay/jetty/handler/ContextHandler$SContext;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1751,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/Request;","_context","Lorg/mortbay/jetty/handler/ContextHandler$SContext;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m016_getContextPath(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Request;","getContextPath",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(358,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/Request;","_contextPath","Ljava/lang/String;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m017_getContinuation(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Request;","getContinuation",new String[]{ },"Lorg/mortbay/util/ajax/Continuation;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1808,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/Request;","_continuation","Lorg/mortbay/util/ajax/Continuation;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m018_getContinuation(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Request;","getContinuation",new String[]{ "Z"},"Lorg/mortbay/util/ajax/Continuation;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"create");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1814,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(1815,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(1816,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/Request;","_continuation","Lorg/mortbay/util/ajax/Continuation;"));
                code.visitJumpStmt(IF_NEZ,0,-1,L2);
                code.visitJumpStmt(IF_EQZ,2,-1,L2);
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/jetty/Request;","getConnection",new String[]{ },"Lorg/mortbay/jetty/HttpConnection;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/HttpConnection;","getConnector",new String[]{ },"Lorg/mortbay/jetty/Connector;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Lorg/mortbay/jetty/Connector;","newContinuation",new String[]{ },"Lorg/mortbay/util/ajax/Continuation;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/Request;","_continuation","Lorg/mortbay/util/ajax/Continuation;"));
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/Request;","_continuation","Lorg/mortbay/util/ajax/Continuation;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m019_getCookies(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Request;","getCookies",new String[]{ },"[Ljavax/servlet/http/Cookie;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(24);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/lang/Exception;"});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                DexLabel L5=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L5},new String[]{ "Ljava/lang/Exception;"});
                DexLabel L6=new DexLabel();
                DexLabel L7=new DexLabel();
                code.visitTryCatch(L6,L7,new DexLabel[]{L2},new String[]{ "Ljava/lang/Exception;"});
                DexLabel L8=new DexLabel();
                DexLabel L9=new DexLabel();
                code.visitTryCatch(L8,L9,new DexLabel[]{L5},new String[]{ "Ljava/lang/Exception;"});
                DexLabel L10=new DexLabel();
                DexLabel L11=new DexLabel();
                code.visitTryCatch(L10,L11,new DexLabel[]{L2},new String[]{ "Ljava/lang/Exception;"});
                DexLabel L12=new DexLabel();
                DexLabel L13=new DexLabel();
                code.visitTryCatch(L12,L13,new DexLabel[]{L5},new String[]{ "Ljava/lang/Exception;"});
                DexLabel L14=new DexLabel();
                DexLabel L15=new DexLabel();
                DexLabel L16=new DexLabel();
                code.visitTryCatch(L14,L15,new DexLabel[]{L16},new String[]{ "Ljava/lang/Exception;"});
                DexLabel L17=new DexLabel();
                DexLabel L18=new DexLabel();
                code.visitTryCatch(L17,L18,new DexLabel[]{L2},new String[]{ "Ljava/lang/Exception;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L19=new DexLabel();
                ddv.visitPrologue(L19);
                ddv.visitLineNumber(367,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(584,L20);
                ddv.visitLineNumber(372,L0);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(374,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(375,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(376,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(377,L24);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(381,L25);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(383,L26);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(384,L27);
                ddv.visitStartLocal(12,L27,"last","I",null);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(385,L28);
                ddv.visitStartLocal(8,L28,"enm","Ljava/util/Enumeration;",null);
                DexLabel L29=new DexLabel();
                ddv.visitLineNumber(387,L29);
                DexLabel L30=new DexLabel();
                ddv.visitLineNumber(388,L30);
                ddv.visitStartLocal(3,L30,"c","Ljava/lang/String;",null);
                DexLabel L31=new DexLabel();
                ddv.visitLineNumber(390,L31);
                DexLabel L32=new DexLabel();
                ddv.visitLineNumber(395,L32);
                ddv.visitEndLocal(3,L32);
                DexLabel L33=new DexLabel();
                ddv.visitLineNumber(397,L33);
                DexLabel L34=new DexLabel();
                ddv.visitLineNumber(398,L34);
                DexLabel L35=new DexLabel();
                ddv.visitLineNumber(393,L35);
                ddv.visitRestartLocal(3,L35);
                DexLabel L36=new DexLabel();
                ddv.visitLineNumber(394,L36);
                DexLabel L37=new DexLabel();
                ddv.visitLineNumber(403,L37);
                ddv.visitEndLocal(12,L37);
                ddv.visitEndLocal(8,L37);
                ddv.visitEndLocal(3,L37);
                DexLabel L38=new DexLabel();
                ddv.visitLineNumber(404,L38);
                ddv.visitStartLocal(6,L38,"cookies","Ljava/lang/Object;",null);
                DexLabel L39=new DexLabel();
                ddv.visitLineNumber(406,L39);
                ddv.visitStartLocal(13,L39,"lastCookies","Ljava/lang/Object;",null);
                DexLabel L40=new DexLabel();
                ddv.visitLineNumber(409,L40);
                ddv.visitStartLocal(20,L40,"version","I",null);
                DexLabel L41=new DexLabel();
                ddv.visitRestartLocal(8,L41);
                DexLabel L42=new DexLabel();
                ddv.visitLineNumber(410,L42);
                ddv.visitEndLocal(6,L42);
                ddv.visitEndLocal(13,L42);
                DexLabel L43=new DexLabel();
                ddv.visitLineNumber(413,L43);
                DexLabel L44=new DexLabel();
                ddv.visitLineNumber(414,L44);
                ddv.visitStartLocal(9,L44,"hdr","Ljava/lang/String;",null);
                DexLabel L45=new DexLabel();
                ddv.visitLineNumber(417,L45);
                ddv.visitStartLocal(13,L45,"lastCookies","Ljava/lang/Object;",null);
                DexLabel L46=new DexLabel();
                ddv.visitLineNumber(418,L46);
                ddv.visitStartLocal(16,L46,"name","Ljava/lang/String;",null);
                DexLabel L47=new DexLabel();
                ddv.visitLineNumber(420,L47);
                ddv.visitStartLocal(19,L47,"value","Ljava/lang/String;",null);
                DexLabel L48=new DexLabel();
                ddv.visitLineNumber(422,L48);
                ddv.visitStartLocal(4,L48,"cookie","Ljavax/servlet/http/Cookie;",null);
                DexLabel L49=new DexLabel();
                ddv.visitLineNumber(423,L49);
                ddv.visitStartLocal(17,L49,"state","B",null);
                DexLabel L50=new DexLabel();
                ddv.visitStartLocal(10,L50,"i","I",null);
                DexLabel L51=new DexLabel();
                ddv.visitStartLocal(18,L51,"tokenstart","I",null);
                DexLabel L52=new DexLabel();
                ddv.visitStartLocal(14,L52,"length","I",null);
                DexLabel L53=new DexLabel();
                ddv.visitEndLocal(4,L53);
                ddv.visitStartLocal(5,L53,"cookie","Ljavax/servlet/http/Cookie;",null);
                DexLabel L54=new DexLabel();
                ddv.visitLineNumber(425,L54);
                DexLabel L55=new DexLabel();
                ddv.visitLineNumber(426,L55);
                ddv.visitStartLocal(3,L55,"c","C",null);
                DexLabel L56=new DexLabel();
                ddv.visitLineNumber(486,L56);
                DexLabel L57=new DexLabel();
                ddv.visitLineNumber(499,L57);
                DexLabel L58=new DexLabel();
                ddv.visitLineNumber(501,L58);
                DexLabel L59=new DexLabel();
                ddv.visitLineNumber(518,L59);
                DexLabel L60=new DexLabel();
                ddv.visitLineNumber(520,L60);
                ddv.visitLineNumber(524,L3);
                DexLabel L61=new DexLabel();
                ddv.visitLineNumber(526,L61);
                DexLabel L62=new DexLabel();
                ddv.visitLineNumber(527,L62);
                ddv.visitStartLocal(15,L62,"lowercaseName","Ljava/lang/String;",null);
                DexLabel L63=new DexLabel();
                ddv.visitLineNumber(529,L63);
                DexLabel L64=new DexLabel();
                ddv.visitLineNumber(557,L64);
                ddv.visitEndLocal(5,L64);
                ddv.visitEndLocal(15,L64);
                ddv.visitRestartLocal(4,L64);
                DexLabel L65=new DexLabel();
                ddv.visitLineNumber(558,L65);
                DexLabel L66=new DexLabel();
                ddv.visitLineNumber(423,L66);
                DexLabel L67=new DexLabel();
                ddv.visitRestartLocal(5,L67);
                DexLabel L68=new DexLabel();
                ddv.visitLineNumber(430,L68);
                ddv.visitEndLocal(4,L68);
                DexLabel L69=new DexLabel();
                ddv.visitLineNumber(433,L69);
                DexLabel L70=new DexLabel();
                ddv.visitLineNumber(434,L70);
                DexLabel L71=new DexLabel();
                ddv.visitLineNumber(435,L71);
                DexLabel L72=new DexLabel();
                ddv.visitLineNumber(437,L72);
                ddv.visitLineNumber(438,L6);
                DexLabel L73=new DexLabel();
                ddv.visitLineNumber(439,L73);
                DexLabel L74=new DexLabel();
                ddv.visitLineNumber(440,L74);
                DexLabel L75=new DexLabel();
                ddv.visitLineNumber(441,L75);
                ddv.visitRestartLocal(19,L75);
                DexLabel L76=new DexLabel();
                ddv.visitLineNumber(442,L76);
                DexLabel L77=new DexLabel();
                ddv.visitLineNumber(444,L77);
                DexLabel L78=new DexLabel();
                ddv.visitLineNumber(445,L78);
                ddv.visitRestartLocal(16,L78);
                DexLabel L79=new DexLabel();
                ddv.visitLineNumber(446,L79);
                ddv.visitRestartLocal(19,L79);
                DexLabel L80=new DexLabel();
                ddv.visitLineNumber(447,L80);
                DexLabel L81=new DexLabel();
                ddv.visitLineNumber(449,L81);
                DexLabel L82=new DexLabel();
                ddv.visitLineNumber(450,L82);
                DexLabel L83=new DexLabel();
                ddv.visitLineNumber(451,L83);
                ddv.visitRestartLocal(19,L83);
                DexLabel L84=new DexLabel();
                ddv.visitLineNumber(456,L84);
                DexLabel L85=new DexLabel();
                ddv.visitLineNumber(459,L85);
                DexLabel L86=new DexLabel();
                ddv.visitLineNumber(460,L86);
                DexLabel L87=new DexLabel();
                ddv.visitLineNumber(461,L87);
                ddv.visitRestartLocal(16,L87);
                DexLabel L88=new DexLabel();
                ddv.visitLineNumber(462,L88);
                DexLabel L89=new DexLabel();
                ddv.visitLineNumber(464,L89);
                DexLabel L90=new DexLabel();
                ddv.visitLineNumber(465,L90);
                DexLabel L91=new DexLabel();
                ddv.visitLineNumber(470,L91);
                DexLabel L92=new DexLabel();
                ddv.visitLineNumber(473,L92);
                DexLabel L93=new DexLabel();
                ddv.visitLineNumber(474,L93);
                DexLabel L94=new DexLabel();
                ddv.visitLineNumber(475,L94);
                DexLabel L95=new DexLabel();
                ddv.visitLineNumber(477,L95);
                DexLabel L96=new DexLabel();
                ddv.visitLineNumber(478,L96);
                DexLabel L97=new DexLabel();
                ddv.visitRestartLocal(19,L97);
                DexLabel L98=new DexLabel();
                ddv.visitLineNumber(489,L98);
                DexLabel L99=new DexLabel();
                ddv.visitLineNumber(490,L99);
                DexLabel L100=new DexLabel();
                ddv.visitLineNumber(491,L100);
                DexLabel L101=new DexLabel();
                ddv.visitLineNumber(493,L101);
                DexLabel L102=new DexLabel();
                ddv.visitLineNumber(494,L102);
                DexLabel L103=new DexLabel();
                ddv.visitLineNumber(504,L103);
                DexLabel L104=new DexLabel();
                ddv.visitLineNumber(505,L104);
                ddv.visitRestartLocal(19,L104);
                DexLabel L105=new DexLabel();
                ddv.visitLineNumber(506,L105);
                DexLabel L106=new DexLabel();
                ddv.visitRestartLocal(19,L106);
                DexLabel L107=new DexLabel();
                ddv.visitLineNumber(509,L107);
                DexLabel L108=new DexLabel();
                ddv.visitLineNumber(510,L108);
                ddv.visitRestartLocal(16,L108);
                DexLabel L109=new DexLabel();
                ddv.visitLineNumber(511,L109);
                ddv.visitRestartLocal(19,L109);
                DexLabel L110=new DexLabel();
                ddv.visitLineNumber(513,L110);
                ddv.visitRestartLocal(19,L7);
                ddv.visitLineNumber(531,L8);
                ddv.visitRestartLocal(15,L8);
                DexLabel L111=new DexLabel();
                ddv.visitLineNumber(533,L111);
                ddv.visitLineNumber(552,L5);
                ddv.visitEndLocal(15,L5);
                ddv.visitLineNumber(554,L10);
                ddv.visitEndLocal(5,L10);
                ddv.visitRestartLocal(4,L10);
                ddv.visitStartLocal(7,L10,"e","Ljava/lang/Exception;",null);
                ddv.visitLineNumber(577,L2);
                ddv.visitEndLocal(20,L2);
                ddv.visitEndLocal(8,L2);
                ddv.visitEndLocal(9,L2);
                ddv.visitEndLocal(13,L2);
                ddv.visitEndLocal(17,L2);
                ddv.visitEndLocal(10,L2);
                ddv.visitEndLocal(18,L2);
                ddv.visitEndLocal(14,L2);
                ddv.visitEndLocal(3,L2);
                ddv.visitEndLocal(16,L2);
                ddv.visitEndLocal(19,L2);
                ddv.visitEndLocal(4,L2);
                ddv.visitEndLocal(7,L2);
                DexLabel L112=new DexLabel();
                ddv.visitLineNumber(579,L112);
                ddv.visitRestartLocal(7,L112);
                DexLabel L113=new DexLabel();
                ddv.visitLineNumber(582,L113);
                ddv.visitEndLocal(7,L113);
                DexLabel L114=new DexLabel();
                ddv.visitLineNumber(583,L114);
                ddv.visitLineNumber(535,L12);
                ddv.visitRestartLocal(3,L12);
                ddv.visitRestartLocal(5,L12);
                ddv.visitRestartLocal(8,L12);
                ddv.visitRestartLocal(9,L12);
                ddv.visitRestartLocal(10,L12);
                ddv.visitRestartLocal(13,L12);
                ddv.visitRestartLocal(14,L12);
                ddv.visitRestartLocal(15,L12);
                ddv.visitRestartLocal(16,L12);
                ddv.visitRestartLocal(17,L12);
                ddv.visitRestartLocal(18,L12);
                ddv.visitRestartLocal(19,L12);
                ddv.visitRestartLocal(20,L12);
                DexLabel L115=new DexLabel();
                ddv.visitLineNumber(537,L115);
                DexLabel L116=new DexLabel();
                ddv.visitRestartLocal(20,L116);
                DexLabel L117=new DexLabel();
                ddv.visitLineNumber(542,L117);
                ddv.visitEndLocal(15,L117);
                ddv.visitLineNumber(544,L13);
                ddv.visitRestartLocal(4,L13);
                ddv.visitLineNumber(546,L14);
                ddv.visitEndLocal(5,L14);
                DexLabel L118=new DexLabel();
                ddv.visitLineNumber(549,L118);
                DexLabel L119=new DexLabel();
                ddv.visitStartLocal(6,L119,"cookies","Ljava/lang/Object;",null);
                ddv.visitLineNumber(563,L17);
                ddv.visitEndLocal(3,L17);
                ddv.visitEndLocal(9,L17);
                ddv.visitEndLocal(10,L17);
                ddv.visitEndLocal(13,L17);
                ddv.visitEndLocal(14,L17);
                ddv.visitEndLocal(16,L17);
                ddv.visitEndLocal(17,L17);
                ddv.visitEndLocal(18,L17);
                ddv.visitEndLocal(19,L17);
                ddv.visitEndLocal(4,L17);
                ddv.visitEndLocal(6,L17);
                DexLabel L120=new DexLabel();
                ddv.visitLineNumber(564,L120);
                ddv.visitStartLocal(11,L120,"l","I",null);
                DexLabel L121=new DexLabel();
                ddv.visitLineNumber(565,L121);
                DexLabel L122=new DexLabel();
                ddv.visitLineNumber(567,L122);
                DexLabel L123=new DexLabel();
                ddv.visitLineNumber(568,L123);
                DexLabel L124=new DexLabel();
                ddv.visitRestartLocal(10,L124);
                DexLabel L125=new DexLabel();
                ddv.visitLineNumber(569,L125);
                DexLabel L126=new DexLabel();
                ddv.visitLineNumber(568,L126);
                DexLabel L127=new DexLabel();
                ddv.visitLineNumber(571,L127);
                DexLabel L128=new DexLabel();
                ddv.visitLineNumber(572,L128);
                DexLabel L129=new DexLabel();
                ddv.visitLineNumber(573,L129);
                DexLabel L130=new DexLabel();
                ddv.visitLineNumber(574,L130);
                ddv.visitLineNumber(573,L18);
                DexLabel L131=new DexLabel();
                ddv.visitLineNumber(584,L131);
                ddv.visitEndLocal(8,L131);
                ddv.visitEndLocal(20,L131);
                ddv.visitEndLocal(10,L131);
                ddv.visitEndLocal(11,L131);
                ddv.visitLineNumber(552,L16);
                ddv.visitRestartLocal(3,L16);
                ddv.visitRestartLocal(4,L16);
                ddv.visitRestartLocal(8,L16);
                ddv.visitRestartLocal(9,L16);
                ddv.visitRestartLocal(10,L16);
                ddv.visitRestartLocal(13,L16);
                ddv.visitRestartLocal(14,L16);
                ddv.visitRestartLocal(16,L16);
                ddv.visitRestartLocal(17,L16);
                ddv.visitRestartLocal(18,L16);
                ddv.visitRestartLocal(19,L16);
                ddv.visitRestartLocal(20,L16);
                DexLabel L132=new DexLabel();
                ddv.visitEndLocal(4,L132);
                ddv.visitRestartLocal(5,L132);
                DexLabel L133=new DexLabel();
                ddv.visitRestartLocal(4,L133);
                DexLabel L134=new DexLabel();
                ddv.visitLineNumber(426,L134);
                DexLabel L135=new DexLabel();
                ddv.visitLineNumber(486,L135);
                DexLabel L136=new DexLabel();
                ddv.visitLineNumber(501,L136);
                DexLabel L137=new DexLabel();
                ddv.visitLineNumber(430,L137);
                DexLabel L138=new DexLabel();
                ddv.visitLineNumber(456,L138);
                DexLabel L139=new DexLabel();
                ddv.visitLineNumber(470,L139);
                code.visitLabel(L19);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,23);
                code.visitFieldStmt(IGET_BOOLEAN,0,0,new Field("Lorg/mortbay/jetty/Request;","_cookiesExtracted","Z"));
                code.visitStmt2R(MOVE_FROM16,21,0);
                code.visitJumpStmt(IF_EQZ,21,-1,L0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,23);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/Request;","_cookies","[Ljavax/servlet/http/Cookie;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,21,0);
                code.visitLabel(L20);
                code.visitStmt1R(RETURN_OBJECT,21);
                code.visitLabel(L0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,23);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/Request;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,21,0);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 21},new Method("Lorg/mortbay/jetty/HttpConnection;","getRequestFields",new String[]{ },"Lorg/mortbay/jetty/HttpFields;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,21);
                code.visitFieldStmt(SGET_OBJECT,22,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","COOKIE_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 21,22},new Method("Lorg/mortbay/jetty/HttpFields;","containsKey",new String[]{ "Lorg/mortbay/io/Buffer;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,21);
                code.visitJumpStmt(IF_NEZ,21,-1,L25);
                code.visitLabel(L21);
                code.visitConstStmt(CONST_16,21, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,23);
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/Request;","_cookies","[Ljavax/servlet/http/Cookie;"));
                code.visitLabel(L22);
                code.visitConstStmt(CONST_16,21, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt2R(MOVE_FROM16,0,21);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,23);
                code.visitFieldStmt(IPUT_BOOLEAN,0,1,new Field("Lorg/mortbay/jetty/Request;","_cookiesExtracted","Z"));
                code.visitLabel(L23);
                code.visitConstStmt(CONST_16,21, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,23);
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/Request;","_lastCookies","[Ljava/lang/String;"));
                code.visitLabel(L24);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,23);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/Request;","_cookies","[Ljavax/servlet/http/Cookie;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,21,0);
                code.visitJumpStmt(GOTO,-1,-1,L20);
                code.visitLabel(L25);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,23);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/Request;","_lastCookies","[Ljava/lang/String;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,21,0);
                code.visitJumpStmt(IF_EQZ,21,-1,L37);
                code.visitLabel(L26);
                code.visitConstStmt(CONST_4,12, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L27);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,23);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/Request;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,21,0);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 21},new Method("Lorg/mortbay/jetty/HttpConnection;","getRequestFields",new String[]{ },"Lorg/mortbay/jetty/HttpFields;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,21);
                code.visitFieldStmt(SGET_OBJECT,22,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","COOKIE_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 21,22},new Method("Lorg/mortbay/jetty/HttpFields;","getValues",new String[]{ "Lorg/mortbay/io/Buffer;"},"Ljava/util/Enumeration;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitLabel(L28);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 8},new Method("Ljava/util/Enumeration;","hasMoreElements",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,21);
                code.visitJumpStmt(IF_EQZ,21,-1,L32);
                code.visitLabel(L29);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 8},new Method("Ljava/util/Enumeration;","nextElement",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitTypeStmt(CHECK_CAST,3,-1,"Ljava/lang/String;");
                code.visitLabel(L30);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,23);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/Request;","_lastCookies","[Ljava/lang/String;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,21,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitStmt2R(ARRAY_LENGTH,0,0);
                code.visitStmt2R(MOVE_FROM16,21,0);
                code.visitStmt2R(MOVE,0,12);
                code.visitStmt2R(MOVE_FROM16,1,21);
                code.visitJumpStmt(IF_GE,0,1,L31);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,23);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/Request;","_lastCookies","[Ljava/lang/String;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,21,0);
                code.visitStmt3R(AGET_OBJECT,21,21,12);
                code.visitStmt2R(MOVE_OBJECT,0,3);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,21);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,21);
                code.visitJumpStmt(IF_NEZ,21,-1,L35);
                code.visitLabel(L31);
                code.visitConstStmt(CONST_16,21, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,23);
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/Request;","_lastCookies","[Ljava/lang/String;"));
                code.visitLabel(L32);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,23);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/Request;","_lastCookies","[Ljava/lang/String;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,21,0);
                code.visitJumpStmt(IF_EQZ,21,-1,L37);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,23);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/Request;","_lastCookies","[Ljava/lang/String;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,21,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitStmt2R(ARRAY_LENGTH,0,0);
                code.visitStmt2R(MOVE_FROM16,21,0);
                code.visitStmt2R(MOVE_FROM16,0,21);
                code.visitStmt2R(MOVE,1,12);
                code.visitJumpStmt(IF_NE,0,1,L37);
                code.visitLabel(L33);
                code.visitConstStmt(CONST_16,21, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt2R(MOVE_FROM16,0,21);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,23);
                code.visitFieldStmt(IPUT_BOOLEAN,0,1,new Field("Lorg/mortbay/jetty/Request;","_cookiesExtracted","Z"));
                code.visitLabel(L34);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,23);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/Request;","_cookies","[Ljavax/servlet/http/Cookie;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,21,0);
                code.visitJumpStmt(GOTO_16,-1,-1,L20);
                code.visitLabel(L35);
                code.visitStmt2R1N(ADD_INT_LIT8,12,12,1);
                code.visitLabel(L36);
                code.visitJumpStmt(GOTO,-1,-1,L28);
                code.visitLabel(L37);
                code.visitConstStmt(CONST_4,6, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L38);
                code.visitConstStmt(CONST_4,13, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L39);
                code.visitConstStmt(CONST_16,20, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L40);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,23);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/Request;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,21,0);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 21},new Method("Lorg/mortbay/jetty/HttpConnection;","getRequestFields",new String[]{ },"Lorg/mortbay/jetty/HttpFields;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,21);
                code.visitFieldStmt(SGET_OBJECT,22,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","COOKIE_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 21,22},new Method("Lorg/mortbay/jetty/HttpFields;","getValues",new String[]{ "Lorg/mortbay/io/Buffer;"},"Ljava/util/Enumeration;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitLabel(L41);
                code.visitStmt2R(MOVE_OBJECT_FROM16,21,6);
                code.visitLabel(L42);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 8},new Method("Ljava/util/Enumeration;","hasMoreElements",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,22);
                code.visitJumpStmt(IF_EQZ,22,-1,L17);
                code.visitLabel(L43);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 8},new Method("Ljava/util/Enumeration;","nextElement",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitTypeStmt(CHECK_CAST,9,-1,"Ljava/lang/String;");
                code.visitLabel(L44);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 13,9},new Method("Lorg/mortbay/util/LazyList;","add",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,13);
                code.visitLabel(L45);
                code.visitConstStmt(CONST_16,16, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L46);
                code.visitConstStmt(CONST_16,19, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L47);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L48);
                code.visitConstStmt(CONST_16,17, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitLabel(L49);
                code.visitConstStmt(CONST_4,10, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L50);
                code.visitConstStmt(CONST_16,18, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L51);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,14);
                code.visitLabel(L52);
                code.visitStmt2R(MOVE_OBJECT,5,4);
                code.visitLabel(L53);
                code.visitJumpStmt(IF_GE,10,14,L42);
                code.visitLabel(L54);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9,10},new Method("Ljava/lang/String;","charAt",new String[]{ "I"},"C"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitLabel(L55);
                code.visitSparseSwitchStmt(SPARSE_SWITCH,3,new int[]{ 9,32,34,44,59,61},new DexLabel[]{L57,L57,L91,L68,L68,L84});
                code.visitLabel(L56);
                code.visitSparseSwitchStmt(PACKED_SWITCH,17,1,new DexLabel[]{L101,L57,L57,L98});
                code.visitLabel(L57);
                code.visitStmt2R1N(ADD_INT_LIT8,22,10,1);
                code.visitStmt2R(MOVE_FROM16,0,22);
                code.visitStmt2R(MOVE,1,14);
                code.visitJumpStmt(IF_NE,0,1,L59);
                code.visitLabel(L58);
                code.visitSparseSwitchStmt(SPARSE_SWITCH,17,new int[]{ 2,4,16},new DexLabel[]{L107,L110,L103});
                code.visitLabel(L59);
                code.visitJumpStmt(IF_EQZ,16,-1,L132);
                code.visitJumpStmt(IF_EQZ,19,-1,L132);
                code.visitLabel(L60);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 16},new Method("Ljava/lang/String;","trim",new String[]{ },"Ljava/lang/String;"));
                code.visitLabel(L1);
                code.visitStmt1R(MOVE_RESULT_OBJECT,16);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_STRING,22,"$");
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,16);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,22);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/String;","startsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,22);
                code.visitJumpStmt(IF_EQZ,22,-1,L117);
                code.visitLabel(L61);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 16},new Method("Ljava/lang/String;","toLowerCase",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,15);
                code.visitLabel(L62);
                code.visitConstStmt(CONST_STRING,22,"$path");
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,22);
                code.visitStmt2R(MOVE_OBJECT,1,15);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,22);
                code.visitJumpStmt(IF_EQZ,22,-1,L8);
                code.visitLabel(L63);
                code.visitStmt2R(MOVE_OBJECT,0,5);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,19);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljavax/servlet/http/Cookie;","setPath",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L4);
                code.visitStmt2R(MOVE_OBJECT,4,5);
                code.visitLabel(L64);
                code.visitConstStmt(CONST_16,16, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L65);
                code.visitConstStmt(CONST_16,19, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L66);
                code.visitStmt2R1N(ADD_INT_LIT8,10,10,1);
                code.visitStmt2R(MOVE_OBJECT,5,4);
                code.visitLabel(L67);
                code.visitJumpStmt(GOTO,-1,-1,L53);
                code.visitLabel(L68);
                code.visitSparseSwitchStmt(SPARSE_SWITCH,17,new int[]{ 1,2,4,16},new DexLabel[]{L69,L77,L81,L72});
                DexLabel L140=new DexLabel();
                code.visitLabel(L140);
                code.visitJumpStmt(GOTO,-1,-1,L57);
                code.visitLabel(L69);
                code.visitConstStmt(CONST_16,17, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitLabel(L70);
                code.visitStmt2R1N(ADD_INT_LIT8,18,10,1);
                code.visitLabel(L71);
                code.visitJumpStmt(GOTO,-1,-1,L57);
                code.visitLabel(L72);
                code.visitConstStmt(CONST_16,17, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitLabel(L6);
                code.visitStmt2R(MOVE_OBJECT,0,9);
                code.visitStmt2R(MOVE_FROM16,1,18);
                code.visitStmt2R(MOVE,2,10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Ljava/lang/String;","substring",new String[]{ "I","I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,22);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 22},new Method("Ljava/lang/String;","trim",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,19);
                code.visitLabel(L73);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 23},new Method("Lorg/mortbay/jetty/Request;","isRequestedSessionIdFromURL",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,22);
                code.visitJumpStmt(IF_EQZ,22,-1,L75);
                code.visitLabel(L74);
                code.visitMethodStmt(INVOKE_STATIC_RANGE,new int[]{ 19},new Method("Lorg/mortbay/util/URIUtil;","decodePath",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,19);
                code.visitLabel(L75);
                code.visitStmt2R1N(ADD_INT_LIT8,18,10,1);
                code.visitLabel(L76);
                code.visitJumpStmt(GOTO,-1,-1,L57);
                code.visitLabel(L77);
                code.visitStmt2R(MOVE_OBJECT,0,9);
                code.visitStmt2R(MOVE_FROM16,1,18);
                code.visitStmt2R(MOVE,2,10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Ljava/lang/String;","substring",new String[]{ "I","I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,16);
                code.visitLabel(L78);
                code.visitConstStmt(CONST_STRING,19,"");
                code.visitLabel(L79);
                code.visitStmt2R1N(ADD_INT_LIT8,18,10,1);
                code.visitLabel(L80);
                code.visitJumpStmt(GOTO,-1,-1,L57);
                code.visitLabel(L81);
                code.visitConstStmt(CONST_16,17, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitLabel(L82);
                code.visitConstStmt(CONST_STRING,19,"");
                code.visitLabel(L83);
                code.visitStmt2R1N(ADD_INT_LIT8,18,10,1);
                code.visitJumpStmt(GOTO,-1,-1,L57);
                code.visitLabel(L84);
                DexLabel L141=new DexLabel();
                code.visitSparseSwitchStmt(PACKED_SWITCH,17,2,new DexLabel[]{L85,L141,L89});
                code.visitLabel(L141);
                code.visitJumpStmt(GOTO,-1,-1,L57);
                code.visitLabel(L85);
                code.visitConstStmt(CONST_16,17, Integer.valueOf(4)); // int: 0x00000004  float:0.000000
                code.visitLabel(L86);
                code.visitStmt2R(MOVE_OBJECT,0,9);
                code.visitStmt2R(MOVE_FROM16,1,18);
                code.visitStmt2R(MOVE,2,10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Ljava/lang/String;","substring",new String[]{ "I","I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,16);
                code.visitLabel(L87);
                code.visitStmt2R1N(ADD_INT_LIT8,18,10,1);
                code.visitLabel(L88);
                code.visitJumpStmt(GOTO_16,-1,-1,L57);
                code.visitLabel(L89);
                code.visitConstStmt(CONST_16,17, Integer.valueOf(16)); // int: 0x00000010  float:0.000000
                code.visitLabel(L90);
                code.visitStmt2R(MOVE_FROM16,18,10);
                code.visitJumpStmt(GOTO_16,-1,-1,L57);
                code.visitLabel(L91);
                code.visitSparseSwitchStmt(SPARSE_SWITCH,17,new int[]{ 4,8},new DexLabel[]{L92,L95});
                DexLabel L142=new DexLabel();
                code.visitLabel(L142);
                code.visitJumpStmt(GOTO_16,-1,-1,L57);
                code.visitLabel(L92);
                code.visitConstStmt(CONST_16,17, Integer.valueOf(8)); // int: 0x00000008  float:0.000000
                code.visitLabel(L93);
                code.visitStmt2R1N(ADD_INT_LIT8,18,10,1);
                code.visitLabel(L94);
                code.visitJumpStmt(GOTO_16,-1,-1,L57);
                code.visitLabel(L95);
                code.visitConstStmt(CONST_16,17, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L96);
                code.visitStmt2R(MOVE_OBJECT,0,9);
                code.visitStmt2R(MOVE_FROM16,1,18);
                code.visitStmt2R(MOVE,2,10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Ljava/lang/String;","substring",new String[]{ "I","I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,19);
                code.visitLabel(L97);
                code.visitJumpStmt(GOTO_16,-1,-1,L57);
                code.visitLabel(L98);
                code.visitConstStmt(CONST_16,17, Integer.valueOf(16)); // int: 0x00000010  float:0.000000
                code.visitLabel(L99);
                code.visitStmt2R(MOVE_FROM16,18,10);
                code.visitLabel(L100);
                code.visitJumpStmt(GOTO_16,-1,-1,L57);
                code.visitLabel(L101);
                code.visitConstStmt(CONST_16,17, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitLabel(L102);
                code.visitStmt2R(MOVE_FROM16,18,10);
                code.visitJumpStmt(GOTO_16,-1,-1,L57);
                code.visitLabel(L103);
                code.visitStmt2R(MOVE_OBJECT,0,9);
                code.visitStmt2R(MOVE_FROM16,1,18);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/String;","substring",new String[]{ "I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,22);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 22},new Method("Ljava/lang/String;","trim",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,19);
                code.visitLabel(L104);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 23},new Method("Lorg/mortbay/jetty/Request;","isRequestedSessionIdFromURL",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,22);
                code.visitJumpStmt(IF_EQZ,22,-1,L59);
                code.visitLabel(L105);
                code.visitMethodStmt(INVOKE_STATIC_RANGE,new int[]{ 19},new Method("Lorg/mortbay/util/URIUtil;","decodePath",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,19);
                code.visitLabel(L106);
                code.visitJumpStmt(GOTO_16,-1,-1,L59);
                code.visitLabel(L107);
                code.visitStmt2R(MOVE_OBJECT,0,9);
                code.visitStmt2R(MOVE_FROM16,1,18);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/String;","substring",new String[]{ "I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,16);
                code.visitLabel(L108);
                code.visitConstStmt(CONST_STRING,19,"");
                code.visitLabel(L109);
                code.visitJumpStmt(GOTO_16,-1,-1,L59);
                code.visitLabel(L110);
                code.visitConstStmt(CONST_STRING,19,"");
                code.visitLabel(L7);
                code.visitJumpStmt(GOTO_16,-1,-1,L59);
                code.visitLabel(L8);
                code.visitConstStmt(CONST_STRING,22,"$domain");
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,22);
                code.visitStmt2R(MOVE_OBJECT,1,15);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,22);
                code.visitJumpStmt(IF_EQZ,22,-1,L12);
                code.visitLabel(L111);
                code.visitStmt2R(MOVE_OBJECT,0,5);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,19);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljavax/servlet/http/Cookie;","setDomain",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L9);
                code.visitJumpStmt(GOTO_16,-1,-1,L4);
                code.visitLabel(L5);
                code.visitStmt1R(MOVE_EXCEPTION,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,7,22);
                code.visitStmt2R(MOVE_OBJECT,4,5);
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 7},new Method("Lorg/mortbay/log/Log;","ignore",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitLabel(L11);
                code.visitJumpStmt(GOTO_16,-1,-1,L64);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,21);
                code.visitStmt2R(MOVE_OBJECT_FROM16,7,21);
                code.visitLabel(L112);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 7},new Method("Lorg/mortbay/log/Log;","warn",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitLabel(L113);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,23);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/Request;","_cookies","[Ljavax/servlet/http/Cookie;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,21,0);
                code.visitJumpStmt(IF_EQZ,21,-1,L114);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,23);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/Request;","_cookies","[Ljavax/servlet/http/Cookie;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,21,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitStmt2R(ARRAY_LENGTH,0,0);
                code.visitStmt2R(MOVE_FROM16,21,0);
                code.visitJumpStmt(IF_NEZ,21,-1,L131);
                code.visitLabel(L114);
                code.visitConstStmt(CONST_16,21, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO_16,-1,-1,L20);
                code.visitLabel(L12);
                code.visitConstStmt(CONST_STRING,22,"$version");
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,22);
                code.visitStmt2R(MOVE_OBJECT,1,15);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,22);
                code.visitJumpStmt(IF_EQZ,22,-1,L4);
                code.visitLabel(L115);
                code.visitMethodStmt(INVOKE_STATIC_RANGE,new int[]{ 19},new Method("Ljava/lang/Integer;","parseInt",new String[]{ "Ljava/lang/String;"},"I"));
                code.visitStmt1R(MOVE_RESULT,20);
                code.visitLabel(L116);
                code.visitJumpStmt(GOTO_16,-1,-1,L4);
                code.visitLabel(L117);
                code.visitTypeStmt(NEW_INSTANCE,4,-1,"Ljavax/servlet/http/Cookie;");
                code.visitStmt2R(MOVE_OBJECT,0,4);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,16);
                code.visitStmt2R(MOVE_OBJECT_FROM16,2,19);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1,2},new Method("Ljavax/servlet/http/Cookie;","<init>",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"V"));
                code.visitLabel(L13);
                code.visitJumpStmt(IF_LEZ,20,-1,L118);
                code.visitLabel(L14);
                code.visitStmt2R(MOVE_OBJECT,0,4);
                code.visitStmt2R(MOVE_FROM16,1,20);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljavax/servlet/http/Cookie;","setVersion",new String[]{ "I"},"V"));
                code.visitLabel(L118);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitStmt2R(MOVE_OBJECT,1,4);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,1},new Method("Lorg/mortbay/util/LazyList;","add",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L15);
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitLabel(L119);
                code.visitStmt2R(MOVE_OBJECT_FROM16,21,6);
                code.visitJumpStmt(GOTO_16,-1,-1,L64);
                code.visitLabel(L17);
                code.visitMethodStmt(INVOKE_STATIC_RANGE,new int[]{ 21},new Method("Lorg/mortbay/util/LazyList;","size",new String[]{ "Ljava/lang/Object;"},"I"));
                code.visitStmt1R(MOVE_RESULT,11);
                code.visitLabel(L120);
                code.visitConstStmt(CONST_16,22, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt2R(MOVE_FROM16,0,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,23);
                code.visitFieldStmt(IPUT_BOOLEAN,0,1,new Field("Lorg/mortbay/jetty/Request;","_cookiesExtracted","Z"));
                code.visitLabel(L121);
                code.visitJumpStmt(IF_LEZ,11,-1,L113);
                code.visitLabel(L122);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,23);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/Request;","_cookies","[Ljavax/servlet/http/Cookie;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,0);
                DexLabel L143=new DexLabel();
                code.visitJumpStmt(IF_EQZ,22,-1,L143);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,23);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/Request;","_cookies","[Ljavax/servlet/http/Cookie;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,22);
                code.visitStmt2R(ARRAY_LENGTH,0,0);
                code.visitStmt2R(MOVE_FROM16,22,0);
                code.visitStmt2R(MOVE_FROM16,0,22);
                code.visitStmt2R(MOVE,1,11);
                code.visitJumpStmt(IF_EQ,0,1,L123);
                code.visitLabel(L143);
                code.visitStmt2R(MOVE,0,11);
                code.visitTypeStmt(NEW_ARRAY,0,0,"[Ljavax/servlet/http/Cookie;");
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,23);
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/Request;","_cookies","[Ljavax/servlet/http/Cookie;"));
                code.visitLabel(L123);
                code.visitConstStmt(CONST_4,10, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L124);
                code.visitJumpStmt(IF_GE,10,11,L127);
                code.visitLabel(L125);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,23);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/Request;","_cookies","[Ljavax/servlet/http/Cookie;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitStmt2R(MOVE,1,10);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,1},new Method("Lorg/mortbay/util/LazyList;","get",new String[]{ "Ljava/lang/Object;","I"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitTypeStmt(CHECK_CAST,3,-1,"Ljavax/servlet/http/Cookie;");
                code.visitStmt3R(APUT_OBJECT,3,22,10);
                code.visitLabel(L126);
                code.visitStmt2R1N(ADD_INT_LIT8,10,10,1);
                code.visitJumpStmt(GOTO,-1,-1,L124);
                code.visitLabel(L127);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 13},new Method("Lorg/mortbay/util/LazyList;","size",new String[]{ "Ljava/lang/Object;"},"I"));
                code.visitStmt1R(MOVE_RESULT,11);
                code.visitLabel(L128);
                code.visitStmt2R(MOVE,0,11);
                code.visitTypeStmt(NEW_ARRAY,0,0,"[Ljava/lang/String;");
                code.visitStmt2R(MOVE_OBJECT_FROM16,21,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,23);
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/Request;","_lastCookies","[Ljava/lang/String;"));
                code.visitLabel(L129);
                code.visitConstStmt(CONST_4,10, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                DexLabel L144=new DexLabel();
                code.visitLabel(L144);
                code.visitJumpStmt(IF_GE,10,11,L113);
                code.visitLabel(L130);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,23);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/Request;","_lastCookies","[Ljava/lang/String;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,21,0);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 13,10},new Method("Lorg/mortbay/util/LazyList;","get",new String[]{ "Ljava/lang/Object;","I"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitTypeStmt(CHECK_CAST,3,-1,"Ljava/lang/String;");
                code.visitStmt3R(APUT_OBJECT,3,21,10);
                code.visitLabel(L18);
                code.visitStmt2R1N(ADD_INT_LIT8,10,10,1);
                code.visitJumpStmt(GOTO,-1,-1,L144);
                code.visitLabel(L131);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,23);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/Request;","_cookies","[Ljavax/servlet/http/Cookie;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,21,0);
                code.visitJumpStmt(GOTO_16,-1,-1,L20);
                code.visitLabel(L16);
                code.visitStmt1R(MOVE_EXCEPTION,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,7,22);
                code.visitJumpStmt(GOTO_16,-1,-1,L10);
                code.visitLabel(L132);
                code.visitStmt2R(MOVE_OBJECT,4,5);
                code.visitLabel(L133);
                code.visitJumpStmt(GOTO_16,-1,-1,L66);
                code.visitLabel(L134);
                code.visitLabel(L135);
                code.visitLabel(L136);
                code.visitLabel(L137);
                code.visitLabel(L138);
                code.visitLabel(L139);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m020_getDateHeader(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Request;","getDateHeader",new String[]{ "Ljava/lang/String;"},"J"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(593,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/Request;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/HttpConnection;","getRequestFields",new String[]{ },"Lorg/mortbay/jetty/HttpFields;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,3},new Method("Lorg/mortbay/jetty/HttpFields;","getDateField",new String[]{ "Ljava/lang/String;"},"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,0);
                code.visitStmt1R(RETURN_WIDE,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m021_getHeader(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Request;","getHeader",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(602,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/Request;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/HttpConnection;","getRequestFields",new String[]{ },"Lorg/mortbay/jetty/HttpFields;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,2},new Method("Lorg/mortbay/jetty/HttpFields;","getStringField",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m022_getHeaderNames(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Request;","getHeaderNames",new String[]{ },"Ljava/util/Enumeration;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(611,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/Request;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/HttpConnection;","getRequestFields",new String[]{ },"Lorg/mortbay/jetty/HttpFields;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/HttpFields;","getFieldNames",new String[]{ },"Ljava/util/Enumeration;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m023_getHeaders(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Request;","getHeaders",new String[]{ "Ljava/lang/String;"},"Ljava/util/Enumeration;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(620,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(621,L1);
                ddv.visitStartLocal(0,L1,"e","Ljava/util/Enumeration;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(622,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(623,L3);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/Request;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/jetty/HttpConnection;","getRequestFields",new String[]{ },"Lorg/mortbay/jetty/HttpFields;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,3},new Method("Lorg/mortbay/jetty/HttpFields;","getValues",new String[]{ "Ljava/lang/String;"},"Ljava/util/Enumeration;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L1);
                DexLabel L4=new DexLabel();
                code.visitJumpStmt(IF_NEZ,0,-1,L4);
                code.visitLabel(L2);
                code.visitFieldStmt(SGET_OBJECT,1,-1,new Field("Ljava/util/Collections;","EMPTY_LIST","Ljava/util/List;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1},new Method("Ljava/util/Collections;","enumeration",new String[]{ "Ljava/util/Collection;"},"Ljava/util/Enumeration;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L3);
                code.visitStmt1R(RETURN_OBJECT,1);
                code.visitLabel(L4);
                code.visitStmt2R(MOVE_OBJECT,1,0);
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m024_getInputState(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Request;","getInputState",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1580,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,1,new Field("Lorg/mortbay/jetty/Request;","_inputState","I"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m025_getInputStream(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Request;","getInputStream",new String[]{ },"Ljavax/servlet/ServletInputStream;"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(632,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(633,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(634,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(635,L4);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L1);
                code.visitFieldStmt(IGET,0,2,new Field("Lorg/mortbay/jetty/Request;","_inputState","I"));
                code.visitJumpStmt(IF_EQZ,0,-1,L3);
                code.visitFieldStmt(IGET,0,2,new Field("Lorg/mortbay/jetty/Request;","_inputState","I"));
                code.visitJumpStmt(IF_EQ,0,1,L3);
                code.visitLabel(L2);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/IllegalStateException;");
                code.visitConstStmt(CONST_STRING,1,"READER");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Ljava/lang/IllegalStateException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,0);
                code.visitLabel(L3);
                code.visitFieldStmt(IPUT,1,2,new Field("Lorg/mortbay/jetty/Request;","_inputState","I"));
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/Request;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/HttpConnection;","getInputStream",new String[]{ },"Ljavax/servlet/ServletInputStream;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m026_getIntHeader(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Request;","getIntHeader",new String[]{ "Ljava/lang/String;"},"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(644,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/Request;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/HttpConnection;","getRequestFields",new String[]{ },"Lorg/mortbay/jetty/HttpFields;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,3},new Method("Lorg/mortbay/jetty/HttpFields;","getLongField",new String[]{ "Ljava/lang/String;"},"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,0);
                code.visitStmt2R(LONG_TO_INT,0,0);
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m027_getLocalAddr(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Request;","getLocalAddr",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(653,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/Request;","_endp","Lorg/mortbay/io/EndPoint;"));
                DexLabel L1=new DexLabel();
                code.visitJumpStmt(IF_NEZ,0,-1,L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                DexLabel L2=new DexLabel();
                code.visitLabel(L2);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/Request;","_endp","Lorg/mortbay/io/EndPoint;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Lorg/mortbay/io/EndPoint;","getLocalAddr",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m028_getLocalName(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Request;","getLocalName",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(744,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(745,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(746,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(745,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(746,L5);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_BOOLEAN,0,2,new Field("Lorg/mortbay/jetty/Request;","_dns","Z"));
                code.visitJumpStmt(IF_EQZ,0,-1,L5);
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/Request;","_endp","Lorg/mortbay/io/EndPoint;"));
                code.visitJumpStmt(IF_NEZ,0,-1,L4);
                code.visitStmt2R(MOVE_OBJECT,0,1);
                code.visitLabel(L3);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/Request;","_endp","Lorg/mortbay/io/EndPoint;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Lorg/mortbay/io/EndPoint;","getLocalHost",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/Request;","_endp","Lorg/mortbay/io/EndPoint;"));
                DexLabel L6=new DexLabel();
                code.visitJumpStmt(IF_NEZ,0,-1,L6);
                code.visitStmt2R(MOVE_OBJECT,0,1);
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/Request;","_endp","Lorg/mortbay/io/EndPoint;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Lorg/mortbay/io/EndPoint;","getLocalAddr",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m029_getLocalPort(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Request;","getLocalPort",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(755,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/Request;","_endp","Lorg/mortbay/io/EndPoint;"));
                DexLabel L1=new DexLabel();
                code.visitJumpStmt(IF_NEZ,0,-1,L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                DexLabel L2=new DexLabel();
                code.visitLabel(L2);
                code.visitStmt1R(RETURN,0);
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/Request;","_endp","Lorg/mortbay/io/EndPoint;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Lorg/mortbay/io/EndPoint;","getLocalPort",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m030_getLocale(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Request;","getLocale",new String[]{ },"Ljava/util/Locale;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(11);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(662,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(665,L1);
                ddv.visitStartLocal(3,L1,"enm","Ljava/util/Enumeration;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(666,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(690,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(669,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(670,L5);
                ddv.visitStartLocal(0,L5,"acceptLanguage","Ljava/util/List;",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(671,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(673,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(676,L8);
                ddv.visitStartLocal(6,L8,"size","I",null);
                DexLabel L9=new DexLabel();
                ddv.visitStartLocal(4,L9,"i","I",null);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(678,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(679,L11);
                ddv.visitStartLocal(5,L11,"language","Ljava/lang/String;",null);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(680,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(681,L13);
                ddv.visitStartLocal(1,L13,"country","Ljava/lang/String;",null);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(682,L14);
                ddv.visitStartLocal(2,L14,"dash","I",null);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(684,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(685,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(687,L17);
                ddv.visitRestartLocal(5,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(690,L18);
                ddv.visitEndLocal(2,L18);
                ddv.visitEndLocal(1,L18);
                ddv.visitEndLocal(5,L18);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,7,10,new Field("Lorg/mortbay/jetty/Request;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Lorg/mortbay/jetty/HttpConnection;","getRequestFields",new String[]{ },"Lorg/mortbay/jetty/HttpFields;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitConstStmt(CONST_STRING,8,"Accept-Language");
                code.visitConstStmt(CONST_STRING,9,", \t");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,8,9},new Method("Lorg/mortbay/jetty/HttpFields;","getValues",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"Ljava/util/Enumeration;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitLabel(L1);
                code.visitJumpStmt(IF_EQZ,3,-1,L2);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3},new Method("Ljava/util/Enumeration;","hasMoreElements",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitJumpStmt(IF_NEZ,7,-1,L4);
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Ljava/util/Locale;","getDefault",new String[]{ },"Ljava/util/Locale;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitLabel(L3);
                code.visitStmt1R(RETURN_OBJECT,7);
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3},new Method("Lorg/mortbay/jetty/HttpFields;","qualityList",new String[]{ "Ljava/util/Enumeration;"},"Ljava/util/List;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Ljava/util/List;","size",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitJumpStmt(IF_NEZ,7,-1,L7);
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Ljava/util/Locale;","getDefault",new String[]{ },"Ljava/util/Locale;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Ljava/util/List;","size",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitLabel(L8);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L9);
                code.visitJumpStmt(IF_GE,4,6,L18);
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,4},new Method("Ljava/util/List;","get",new String[]{ "I"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitTypeStmt(CHECK_CAST,5,-1,"Ljava/lang/String;");
                code.visitLabel(L11);
                code.visitConstStmt(CONST_4,7, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 5,7},new Method("Lorg/mortbay/jetty/HttpFields;","valueParameters",new String[]{ "Ljava/lang/String;","Ljava/util/Map;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitLabel(L12);
                code.visitConstStmt(CONST_STRING,1,"");
                code.visitLabel(L13);
                code.visitConstStmt(CONST_16,7, Integer.valueOf(45)); // int: 0x0000002d  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,7},new Method("Ljava/lang/String;","indexOf",new String[]{ "I"},"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitLabel(L14);
                code.visitConstStmt(CONST_4,7, Integer.valueOf(-1)); // int: 0xffffffff  float:NaN
                code.visitJumpStmt(IF_LE,2,7,L17);
                code.visitLabel(L15);
                code.visitStmt2R1N(ADD_INT_LIT8,7,2,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,7},new Method("Ljava/lang/String;","substring",new String[]{ "I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Ljava/lang/String;","trim",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L16);
                code.visitConstStmt(CONST_4,7, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,7,2},new Method("Ljava/lang/String;","substring",new String[]{ "I","I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Ljava/lang/String;","trim",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitLabel(L17);
                code.visitTypeStmt(NEW_INSTANCE,7,-1,"Ljava/util/Locale;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 7,5,1},new Method("Ljava/util/Locale;","<init>",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitLabel(L18);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Ljava/util/Locale;","getDefault",new String[]{ },"Ljava/util/Locale;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m031_getLocales(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Request;","getLocales",new String[]{ },"Ljava/util/Enumeration;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(12);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(700,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(703,L1);
                ddv.visitStartLocal(3,L1,"enm","Ljava/util/Enumeration;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(704,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(735,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(707,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(709,L5);
                ddv.visitStartLocal(0,L5,"acceptLanguage","Ljava/util/List;",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(710,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(713,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(714,L8);
                ddv.visitStartLocal(5,L8,"langs","Ljava/lang/Object;",null);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(717,L9);
                ddv.visitStartLocal(7,L9,"size","I",null);
                DexLabel L10=new DexLabel();
                ddv.visitEndLocal(5,L10);
                ddv.visitStartLocal(4,L10,"i","I",null);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(719,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(720,L12);
                ddv.visitStartLocal(6,L12,"language","Ljava/lang/String;",null);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(721,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(722,L14);
                ddv.visitStartLocal(1,L14,"country","Ljava/lang/String;",null);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(723,L15);
                ddv.visitStartLocal(2,L15,"dash","I",null);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(725,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(726,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(728,L18);
                ddv.visitRestartLocal(6,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(729,L19);
                ddv.visitStartLocal(5,L19,"langs","Ljava/lang/Object;",null);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(717,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(732,L21);
                ddv.visitEndLocal(2,L21);
                ddv.visitEndLocal(1,L21);
                ddv.visitEndLocal(6,L21);
                ddv.visitEndLocal(5,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(733,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(735,L23);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,8,11,new Field("Lorg/mortbay/jetty/Request;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Lorg/mortbay/jetty/HttpConnection;","getRequestFields",new String[]{ },"Lorg/mortbay/jetty/HttpFields;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitConstStmt(CONST_STRING,9,"Accept-Language");
                code.visitConstStmt(CONST_STRING,10,", \t");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,9,10},new Method("Lorg/mortbay/jetty/HttpFields;","getValues",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"Ljava/util/Enumeration;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitLabel(L1);
                code.visitJumpStmt(IF_EQZ,3,-1,L2);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3},new Method("Ljava/util/Enumeration;","hasMoreElements",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitJumpStmt(IF_NEZ,8,-1,L4);
                code.visitLabel(L2);
                code.visitFieldStmt(SGET_OBJECT,8,-1,new Field("Lorg/mortbay/jetty/Request;","__defaultLocale","Ljava/util/Collection;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 8},new Method("Ljava/util/Collections;","enumeration",new String[]{ "Ljava/util/Collection;"},"Ljava/util/Enumeration;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitLabel(L3);
                code.visitStmt1R(RETURN_OBJECT,8);
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3},new Method("Lorg/mortbay/jetty/HttpFields;","qualityList",new String[]{ "Ljava/util/Enumeration;"},"Ljava/util/List;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Ljava/util/List;","size",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitJumpStmt(IF_NEZ,8,-1,L7);
                code.visitLabel(L6);
                code.visitFieldStmt(SGET_OBJECT,8,-1,new Field("Lorg/mortbay/jetty/Request;","__defaultLocale","Ljava/util/Collection;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 8},new Method("Ljava/util/Collections;","enumeration",new String[]{ "Ljava/util/Collection;"},"Ljava/util/Enumeration;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitLabel(L7);
                code.visitConstStmt(CONST_4,5, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Ljava/util/List;","size",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitLabel(L9);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L10);
                code.visitJumpStmt(IF_GE,4,7,L21);
                code.visitLabel(L11);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,4},new Method("Ljava/util/List;","get",new String[]{ "I"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitTypeStmt(CHECK_CAST,6,-1,"Ljava/lang/String;");
                code.visitLabel(L12);
                code.visitConstStmt(CONST_4,8, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 6,8},new Method("Lorg/mortbay/jetty/HttpFields;","valueParameters",new String[]{ "Ljava/lang/String;","Ljava/util/Map;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitLabel(L13);
                code.visitConstStmt(CONST_STRING,1,"");
                code.visitLabel(L14);
                code.visitConstStmt(CONST_16,8, Integer.valueOf(45)); // int: 0x0000002d  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,8},new Method("Ljava/lang/String;","indexOf",new String[]{ "I"},"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitLabel(L15);
                code.visitConstStmt(CONST_4,8, Integer.valueOf(-1)); // int: 0xffffffff  float:NaN
                code.visitJumpStmt(IF_LE,2,8,L18);
                code.visitLabel(L16);
                code.visitStmt2R1N(ADD_INT_LIT8,8,2,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,8},new Method("Ljava/lang/String;","substring",new String[]{ "I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Ljava/lang/String;","trim",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L17);
                code.visitConstStmt(CONST_4,8, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,8,2},new Method("Ljava/lang/String;","substring",new String[]{ "I","I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Ljava/lang/String;","trim",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitLabel(L18);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 5,7},new Method("Lorg/mortbay/util/LazyList;","ensureSize",new String[]{ "Ljava/lang/Object;","I"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitLabel(L19);
                code.visitTypeStmt(NEW_INSTANCE,8,-1,"Ljava/util/Locale;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 8,6,1},new Method("Ljava/util/Locale;","<init>",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"V"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 5,8},new Method("Lorg/mortbay/util/LazyList;","add",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitLabel(L20);
                code.visitStmt2R1N(ADD_INT_LIT8,4,4,1);
                code.visitJumpStmt(GOTO,-1,-1,L10);
                code.visitLabel(L21);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 5},new Method("Lorg/mortbay/util/LazyList;","size",new String[]{ "Ljava/lang/Object;"},"I"));
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitJumpStmt(IF_NEZ,8,-1,L23);
                code.visitLabel(L22);
                code.visitFieldStmt(SGET_OBJECT,8,-1,new Field("Lorg/mortbay/jetty/Request;","__defaultLocale","Ljava/util/Collection;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 8},new Method("Ljava/util/Collections;","enumeration",new String[]{ "Ljava/util/Collection;"},"Ljava/util/Enumeration;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitLabel(L23);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 5},new Method("Lorg/mortbay/util/LazyList;","getList",new String[]{ "Ljava/lang/Object;"},"Ljava/util/List;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 8},new Method("Ljava/util/Collections;","enumeration",new String[]{ "Ljava/util/Collection;"},"Ljava/util/Enumeration;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m032_getMethod(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Request;","getMethod",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(764,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/Request;","_method","Ljava/lang/String;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m033_getParameter(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Request;","getParameter",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(773,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(774,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(775,L2);
                DexLabel L3=new DexLabel();
                ddv.visitEndLocal(2,L3);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_BOOLEAN,0,2,new Field("Lorg/mortbay/jetty/Request;","_paramsExtracted","Z"));
                code.visitJumpStmt(IF_NEZ,0,-1,L2);
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2},new Method("Lorg/mortbay/jetty/Request;","extractParameters",new String[]{ },"V"));
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/Request;","_parameters","Lorg/mortbay/util/MultiMap;"));
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,3,1},new Method("Lorg/mortbay/util/MultiMap;","getValue",new String[]{ "Ljava/lang/Object;","I"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L3);
                code.visitTypeStmt(CHECK_CAST,2,-1,"Ljava/lang/String;");
                code.visitStmt1R(RETURN_OBJECT,2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m034_getParameterMap(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Request;","getParameterMap",new String[]{ },"Ljava/util/Map;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(784,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(785,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(787,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_BOOLEAN,0,1,new Field("Lorg/mortbay/jetty/Request;","_paramsExtracted","Z"));
                code.visitJumpStmt(IF_NEZ,0,-1,L2);
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Lorg/mortbay/jetty/Request;","extractParameters",new String[]{ },"V"));
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/Request;","_parameters","Lorg/mortbay/util/MultiMap;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/util/MultiMap;","toStringArrayMap",new String[]{ },"Ljava/util/Map;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Ljava/util/Collections;","unmodifiableMap",new String[]{ "Ljava/util/Map;"},"Ljava/util/Map;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m035_getParameterNames(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Request;","getParameterNames",new String[]{ },"Ljava/util/Enumeration;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(796,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(797,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(798,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_BOOLEAN,0,1,new Field("Lorg/mortbay/jetty/Request;","_paramsExtracted","Z"));
                code.visitJumpStmt(IF_NEZ,0,-1,L2);
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Lorg/mortbay/jetty/Request;","extractParameters",new String[]{ },"V"));
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/Request;","_parameters","Lorg/mortbay/util/MultiMap;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/util/MultiMap;","keySet",new String[]{ },"Ljava/util/Set;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Ljava/util/Collections;","enumeration",new String[]{ "Ljava/util/Collection;"},"Ljava/util/Enumeration;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m036_getParameterValues(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Request;","getParameterValues",new String[]{ "Ljava/lang/String;"},"[Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(807,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(808,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(809,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(810,L3);
                ddv.visitStartLocal(0,L3,"vals","Ljava/util/List;",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(811,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(812,L5);
                ddv.visitEndLocal(2,L5);
                DexLabel L6=new DexLabel();
                ddv.visitRestartLocal(2,L6);
                DexLabel L7=new DexLabel();
                ddv.visitEndLocal(2,L7);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_BOOLEAN,1,2,new Field("Lorg/mortbay/jetty/Request;","_paramsExtracted","Z"));
                code.visitJumpStmt(IF_NEZ,1,-1,L2);
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2},new Method("Lorg/mortbay/jetty/Request;","extractParameters",new String[]{ },"V"));
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/Request;","_parameters","Lorg/mortbay/util/MultiMap;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,3},new Method("Lorg/mortbay/util/MultiMap;","getValues",new String[]{ "Ljava/lang/Object;"},"Ljava/util/List;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L3);
                code.visitJumpStmt(IF_NEZ,0,-1,L6);
                code.visitLabel(L4);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L5);
                code.visitStmt1R(RETURN_OBJECT,1);
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Ljava/util/List;","size",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitTypeStmt(NEW_ARRAY,1,1,"[Ljava/lang/String;");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1},new Method("Ljava/util/List;","toArray",new String[]{ "[Ljava/lang/Object;"},"[Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L7);
                code.visitTypeStmt(CHECK_CAST,2,-1,"[Ljava/lang/String;");
                code.visitTypeStmt(CHECK_CAST,2,-1,"[Ljava/lang/String;");
                code.visitStmt2R(MOVE_OBJECT,1,2);
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m037_getParameters(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Request;","getParameters",new String[]{ },"Lorg/mortbay/util/MultiMap;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1831,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/Request;","_parameters","Lorg/mortbay/util/MultiMap;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m038_getPathInfo(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Request;","getPathInfo",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(821,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/Request;","_pathInfo","Ljava/lang/String;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m039_getPathTranslated(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Request;","getPathTranslated",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(830,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(831,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(832,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/Request;","_pathInfo","Ljava/lang/String;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L1);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/Request;","_context","Lorg/mortbay/jetty/handler/ContextHandler$SContext;"));
                DexLabel L3=new DexLabel();
                code.visitJumpStmt(IF_NEZ,0,-1,L3);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L2);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/Request;","_context","Lorg/mortbay/jetty/handler/ContextHandler$SContext;"));
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/Request;","_pathInfo","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/handler/ContextHandler$SContext;","getRealPath",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m040_getProtocol(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Request;","getProtocol",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(841,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/Request;","_protocol","Ljava/lang/String;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m041_getQueryEncoding(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Request;","getQueryEncoding",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1936,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/Request;","_queryEncoding","Ljava/lang/String;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m042_getQueryString(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Request;","getQueryString",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1206,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(1208,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(1209,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(1213,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(1211,L4);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/Request;","_queryString","Ljava/lang/String;"));
                code.visitJumpStmt(IF_NEZ,0,-1,L3);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/Request;","_uri","Lorg/mortbay/jetty/HttpURI;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L3);
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/Request;","_queryEncoding","Ljava/lang/String;"));
                code.visitJumpStmt(IF_NEZ,0,-1,L4);
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/Request;","_uri","Lorg/mortbay/jetty/HttpURI;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/HttpURI;","getQuery",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/jetty/Request;","_queryString","Ljava/lang/String;"));
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/Request;","_queryString","Ljava/lang/String;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/Request;","_uri","Lorg/mortbay/jetty/HttpURI;"));
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/Request;","_queryEncoding","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/HttpURI;","getQuery",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/jetty/Request;","_queryString","Ljava/lang/String;"));
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m043_getReader(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Request;","getReader",new String[]{ },"Ljava/io/BufferedReader;"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(850,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(851,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(853,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(854,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(873,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(856,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(857,L7);
                ddv.visitStartLocal(0,L7,"encoding","Ljava/lang/String;",null);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(858,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(860,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(862,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(863,L11);
                ddv.visitStartLocal(1,L11,"in","Ljavax/servlet/ServletInputStream;",null);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(864,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(872,L13);
                ddv.visitEndLocal(1,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(873,L14);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitLabel(L1);
                code.visitFieldStmt(IGET,2,5,new Field("Lorg/mortbay/jetty/Request;","_inputState","I"));
                code.visitJumpStmt(IF_EQZ,2,-1,L3);
                code.visitFieldStmt(IGET,2,5,new Field("Lorg/mortbay/jetty/Request;","_inputState","I"));
                code.visitJumpStmt(IF_EQ,2,4,L3);
                code.visitLabel(L2);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Ljava/lang/IllegalStateException;");
                code.visitConstStmt(CONST_STRING,3,"STREAMED");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2,3},new Method("Ljava/lang/IllegalStateException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,2);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET,2,5,new Field("Lorg/mortbay/jetty/Request;","_inputState","I"));
                code.visitJumpStmt(IF_NE,2,4,L6);
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/jetty/Request;","_reader","Ljava/io/BufferedReader;"));
                code.visitLabel(L5);
                code.visitStmt1R(RETURN_OBJECT,2);
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/jetty/Request;","getCharacterEncoding",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L7);
                code.visitJumpStmt(IF_NEZ,0,-1,L9);
                code.visitLabel(L8);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/util/StringUtil;","__ISO_8859_1","Ljava/lang/String;"));
                code.visitLabel(L9);
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/jetty/Request;","_reader","Ljava/io/BufferedReader;"));
                code.visitJumpStmt(IF_EQZ,2,-1,L10);
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/jetty/Request;","_readerEncoding","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,2},new Method("Ljava/lang/String;","equalsIgnoreCase",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_NEZ,2,-1,L13);
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/jetty/Request;","getInputStream",new String[]{ },"Ljavax/servlet/ServletInputStream;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L11);
                code.visitFieldStmt(IPUT_OBJECT,0,5,new Field("Lorg/mortbay/jetty/Request;","_readerEncoding","Ljava/lang/String;"));
                code.visitLabel(L12);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Lorg/mortbay/jetty/Request$1;");
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Ljava/io/InputStreamReader;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3,1,0},new Method("Ljava/io/InputStreamReader;","<init>",new String[]{ "Ljava/io/InputStream;","Ljava/lang/String;"},"V"));
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2,5,3,1},new Method("Lorg/mortbay/jetty/Request$1;","<init>",new String[]{ "Lorg/mortbay/jetty/Request;","Ljava/io/Reader;","Ljavax/servlet/ServletInputStream;"},"V"));
                code.visitFieldStmt(IPUT_OBJECT,2,5,new Field("Lorg/mortbay/jetty/Request;","_reader","Ljava/io/BufferedReader;"));
                code.visitLabel(L13);
                code.visitFieldStmt(IPUT,4,5,new Field("Lorg/mortbay/jetty/Request;","_inputState","I"));
                code.visitLabel(L14);
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/jetty/Request;","_reader","Ljava/io/BufferedReader;"));
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m044_getRealPath(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Request;","getRealPath",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"path");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(882,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(883,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(884,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/Request;","_context","Lorg/mortbay/jetty/handler/ContextHandler$SContext;"));
                DexLabel L3=new DexLabel();
                code.visitJumpStmt(IF_NEZ,0,-1,L3);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L2);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/Request;","_context","Lorg/mortbay/jetty/handler/ContextHandler$SContext;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,2},new Method("Lorg/mortbay/jetty/handler/ContextHandler$SContext;","getRealPath",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m045_getRemoteAddr(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Request;","getRemoteAddr",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(893,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(894,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(895,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/Request;","_remoteAddr","Ljava/lang/String;"));
                DexLabel L3=new DexLabel();
                code.visitJumpStmt(IF_EQZ,0,-1,L3);
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/Request;","_remoteAddr","Ljava/lang/String;"));
                code.visitLabel(L2);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/Request;","_endp","Lorg/mortbay/io/EndPoint;"));
                DexLabel L4=new DexLabel();
                code.visitJumpStmt(IF_NEZ,0,-1,L4);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/Request;","_endp","Lorg/mortbay/io/EndPoint;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Lorg/mortbay/io/EndPoint;","getRemoteAddr",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m046_getRemoteHost(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Request;","getRemoteHost",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(904,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(906,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(908,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(912,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(910,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(912,L5);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_BOOLEAN,0,1,new Field("Lorg/mortbay/jetty/Request;","_dns","Z"));
                code.visitJumpStmt(IF_EQZ,0,-1,L5);
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/Request;","_remoteHost","Ljava/lang/String;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L4);
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/Request;","_remoteHost","Ljava/lang/String;"));
                code.visitLabel(L3);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/Request;","_endp","Lorg/mortbay/io/EndPoint;"));
                DexLabel L6=new DexLabel();
                code.visitJumpStmt(IF_NEZ,0,-1,L6);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/Request;","_endp","Lorg/mortbay/io/EndPoint;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Lorg/mortbay/io/EndPoint;","getRemoteHost",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/jetty/Request;","getRemoteAddr",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m047_getRemotePort(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Request;","getRemotePort",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(921,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/Request;","_endp","Lorg/mortbay/io/EndPoint;"));
                DexLabel L1=new DexLabel();
                code.visitJumpStmt(IF_NEZ,0,-1,L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                DexLabel L2=new DexLabel();
                code.visitLabel(L2);
                code.visitStmt1R(RETURN,0);
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/Request;","_endp","Lorg/mortbay/io/EndPoint;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Lorg/mortbay/io/EndPoint;","getRemotePort",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m048_getRemoteUser(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Request;","getRemoteUser",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(930,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(931,L1);
                ddv.visitStartLocal(0,L1,"p","Ljava/security/Principal;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(932,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(933,L3);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/Request;","getUserPrincipal",new String[]{ },"Ljava/security/Principal;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L1);
                DexLabel L4=new DexLabel();
                code.visitJumpStmt(IF_NEZ,0,-1,L4);
                code.visitLabel(L2);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L3);
                code.visitStmt1R(RETURN_OBJECT,1);
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Ljava/security/Principal;","getName",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m049_getRequestDispatcher(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Request;","getRequestDispatcher",new String[]{ "Ljava/lang/String;"},"Ljavax/servlet/RequestDispatcher;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"path");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(942,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(943,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(957,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(946,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(948,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(949,L6);
                ddv.visitStartLocal(0,L6,"relTo","Ljava/lang/String;",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(950,L7);
                ddv.visitStartLocal(1,L7,"slash","I",null);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(951,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(954,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(957,L10);
                ddv.visitEndLocal(1,L10);
                ddv.visitEndLocal(0,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(953,L11);
                ddv.visitRestartLocal(0,L11);
                ddv.visitRestartLocal(1,L11);
                DexLabel L12=new DexLabel();
                ddv.visitRestartLocal(0,L12);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_STRING,4,"/");
                code.visitLabel(L1);
                code.visitJumpStmt(IF_EQZ,6,-1,L2);
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/jetty/Request;","_context","Lorg/mortbay/jetty/handler/ContextHandler$SContext;"));
                code.visitJumpStmt(IF_NEZ,2,-1,L4);
                code.visitLabel(L2);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L3);
                code.visitStmt1R(RETURN_OBJECT,2);
                code.visitLabel(L4);
                code.visitConstStmt(CONST_STRING,2,"/");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,4},new Method("Ljava/lang/String;","startsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_NEZ,2,-1,L10);
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/jetty/Request;","_servletPath","Ljava/lang/String;"));
                code.visitFieldStmt(IGET_OBJECT,3,5,new Field("Lorg/mortbay/jetty/Request;","_pathInfo","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2,3},new Method("Lorg/mortbay/util/URIUtil;","addPaths",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L6);
                code.visitConstStmt(CONST_STRING,2,"/");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,4},new Method("Ljava/lang/String;","lastIndexOf",new String[]{ "Ljava/lang/String;"},"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitLabel(L7);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitJumpStmt(IF_LE,1,2,L11);
                code.visitLabel(L8);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt2R1N(ADD_INT_LIT8,3,1,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,2,3},new Method("Ljava/lang/String;","substring",new String[]{ "I","I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,6},new Method("Lorg/mortbay/util/URIUtil;","addPaths",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitLabel(L10);
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/jetty/Request;","_context","Lorg/mortbay/jetty/handler/ContextHandler$SContext;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,6},new Method("Lorg/mortbay/jetty/handler/ContextHandler$SContext;","getRequestDispatcher",new String[]{ "Ljava/lang/String;"},"Ljavax/servlet/RequestDispatcher;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitLabel(L11);
                code.visitConstStmt(CONST_STRING,0,"/");
                code.visitLabel(L12);
                code.visitJumpStmt(GOTO,-1,-1,L9);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m050_getRequestURI(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Request;","getRequestURI",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(975,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(976,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(977,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/Request;","_requestURI","Ljava/lang/String;"));
                code.visitJumpStmt(IF_NEZ,0,-1,L2);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/Request;","_uri","Lorg/mortbay/jetty/HttpURI;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L2);
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/Request;","_uri","Lorg/mortbay/jetty/HttpURI;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/HttpURI;","getPathAndParam",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/Request;","_requestURI","Ljava/lang/String;"));
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/Request;","_requestURI","Ljava/lang/String;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m051_getRequestURL(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Request;","getRequestURL",new String[]{ },"Ljava/lang/StringBuffer;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(986,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(987,L4);
                ddv.visitStartLocal(2,L4,"url","Ljava/lang/StringBuffer;",null);
                ddv.visitLineNumber(989,L0);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(990,L5);
                ddv.visitStartLocal(1,L5,"scheme","Ljava/lang/String;",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(992,L6);
                ddv.visitStartLocal(0,L6,"port","I",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(993,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(994,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(995,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(999,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(1000,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(1003,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(1004,L13);
                ddv.visitLineNumber(1005,L2);
                ddv.visitEndLocal(1,L2);
                ddv.visitEndLocal(0,L2);
                code.visitLabel(L3);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Ljava/lang/StringBuffer;");
                code.visitConstStmt(CONST_16,3, Integer.valueOf(48)); // int: 0x00000030  float:0.000000
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2,3},new Method("Ljava/lang/StringBuffer;","<init>",new String[]{ "I"},"V"));
                code.visitLabel(L4);
                code.visitStmt1R(MONITOR_ENTER,2);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/jetty/Request;","getScheme",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/jetty/Request;","getServerPort",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,1},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L7);
                code.visitConstStmt(CONST_STRING,3,"://");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/jetty/Request;","getServerName",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L9);
                code.visitFieldStmt(IGET,3,4,new Field("Lorg/mortbay/jetty/Request;","_port","I"));
                code.visitJumpStmt(IF_LEZ,3,-1,L12);
                code.visitConstStmt(CONST_STRING,3,"http");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,3},new Method("Ljava/lang/String;","equalsIgnoreCase",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,3);
                DexLabel L14=new DexLabel();
                code.visitJumpStmt(IF_EQZ,3,-1,L14);
                code.visitConstStmt(CONST_16,3, Integer.valueOf(80)); // int: 0x00000050  float:0.000000
                code.visitJumpStmt(IF_NE,0,3,L10);
                code.visitLabel(L14);
                code.visitConstStmt(CONST_STRING,3,"https");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,3},new Method("Ljava/lang/String;","equalsIgnoreCase",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_EQZ,3,-1,L12);
                code.visitConstStmt(CONST_16,3, Integer.valueOf(443)); // int: 0x000001bb  float:0.000000
                code.visitJumpStmt(IF_EQ,0,3,L12);
                code.visitLabel(L10);
                code.visitConstStmt(CONST_16,3, Integer.valueOf(58)); // int: 0x0000003a  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "C"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L11);
                code.visitFieldStmt(IGET,3,4,new Field("Lorg/mortbay/jetty/Request;","_port","I"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "I"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L12);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/jetty/Request;","getRequestURI",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L13);
                code.visitStmt1R(MONITOR_EXIT,2);
                code.visitStmt1R(RETURN_OBJECT,2);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,3);
                code.visitStmt1R(MONITOR_EXIT,2);
                code.visitLabel(L1);
                code.visitStmt1R(THROW,3);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m052_getRequestedSessionId(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Request;","getRequestedSessionId",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(966,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/Request;","_requestedSessionId","Ljava/lang/String;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m053_getRoleMap(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Request;","getRoleMap",new String[]{ },"Ljava/util/Map;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1964,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/Request;","_roleMap","Ljava/util/Map;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m054_getRootURL(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Request;","getRootURL",new String[]{ },"Ljava/lang/StringBuffer;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(1768,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(1769,L4);
                ddv.visitStartLocal(2,L4,"url","Ljava/lang/StringBuffer;",null);
                ddv.visitLineNumber(1771,L0);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(1772,L5);
                ddv.visitStartLocal(1,L5,"scheme","Ljava/lang/String;",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(1774,L6);
                ddv.visitStartLocal(0,L6,"port","I",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(1775,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(1776,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(1778,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(1780,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(1781,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(1783,L12);
                ddv.visitLineNumber(1784,L2);
                ddv.visitEndLocal(1,L2);
                ddv.visitEndLocal(0,L2);
                code.visitLabel(L3);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Ljava/lang/StringBuffer;");
                code.visitConstStmt(CONST_16,3, Integer.valueOf(48)); // int: 0x00000030  float:0.000000
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2,3},new Method("Ljava/lang/StringBuffer;","<init>",new String[]{ "I"},"V"));
                code.visitLabel(L4);
                code.visitStmt1R(MONITOR_ENTER,2);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/jetty/Request;","getScheme",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/jetty/Request;","getServerPort",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,1},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L7);
                code.visitConstStmt(CONST_STRING,3,"://");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/jetty/Request;","getServerName",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L9);
                code.visitJumpStmt(IF_LEZ,0,-1,L12);
                code.visitConstStmt(CONST_STRING,3,"http");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,3},new Method("Ljava/lang/String;","equalsIgnoreCase",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,3);
                DexLabel L13=new DexLabel();
                code.visitJumpStmt(IF_EQZ,3,-1,L13);
                code.visitConstStmt(CONST_16,3, Integer.valueOf(80)); // int: 0x00000050  float:0.000000
                code.visitJumpStmt(IF_NE,0,3,L10);
                code.visitLabel(L13);
                code.visitConstStmt(CONST_STRING,3,"https");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,3},new Method("Ljava/lang/String;","equalsIgnoreCase",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_EQZ,3,-1,L12);
                code.visitConstStmt(CONST_16,3, Integer.valueOf(443)); // int: 0x000001bb  float:0.000000
                code.visitJumpStmt(IF_EQ,0,3,L12);
                code.visitLabel(L10);
                code.visitConstStmt(CONST_16,3, Integer.valueOf(58)); // int: 0x0000003a  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "C"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L11);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,0},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "I"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L12);
                code.visitStmt1R(MONITOR_EXIT,2);
                code.visitStmt1R(RETURN_OBJECT,2);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,3);
                code.visitStmt1R(MONITOR_EXIT,2);
                code.visitLabel(L1);
                code.visitStmt1R(THROW,3);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m055_getScheme(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Request;","getScheme",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1014,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/Request;","_scheme","Ljava/lang/String;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m056_getServerName(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Request;","getServerName",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(8);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/net/UnknownHostException;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(1024,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(1025,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(1073,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(1028,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(1029,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(1030,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(1031,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(1034,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(1035,L12);
                ddv.visitStartLocal(1,L12,"hostPort","Lorg/mortbay/io/Buffer;",null);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(1037,L13);
                DexLabel L14=new DexLabel();
                ddv.visitStartLocal(2,L14,"i","I",null);
                DexLabel L15=new DexLabel();
                ddv.visitEndLocal(2,L15);
                ddv.visitStartLocal(3,L15,"i","I",null);
                DexLabel L16=new DexLabel();
                ddv.visitRestartLocal(2,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(1039,L17);
                ddv.visitEndLocal(3,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(1041,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(1042,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(1043,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(1046,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(1048,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(1049,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(1052,L24);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(1056,L25);
                ddv.visitEndLocal(2,L25);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(1058,L26);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(1059,L27);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(1060,L28);
                DexLabel L29=new DexLabel();
                ddv.visitLineNumber(1061,L29);
                ddv.visitLineNumber(1067,L0);
                ddv.visitLineNumber(1073,L1);
                ddv.visitLineNumber(1069,L2);
                DexLabel L30=new DexLabel();
                ddv.visitLineNumber(1071,L30);
                ddv.visitStartLocal(0,L30,"e","Ljava/net/UnknownHostException;",null);
                DexLabel L31=new DexLabel();
                ddv.visitEndLocal(0,L31);
                ddv.visitRestartLocal(2,L31);
                DexLabel L32=new DexLabel();
                ddv.visitRestartLocal(3,L32);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,6, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,4,7,new Field("Lorg/mortbay/jetty/Request;","_serverName","Ljava/lang/String;"));
                code.visitJumpStmt(IF_EQZ,4,-1,L7);
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,4,7,new Field("Lorg/mortbay/jetty/Request;","_serverName","Ljava/lang/String;"));
                code.visitLabel(L6);
                code.visitStmt1R(RETURN_OBJECT,4);
                code.visitLabel(L7);
                code.visitFieldStmt(IGET_OBJECT,4,7,new Field("Lorg/mortbay/jetty/Request;","_uri","Lorg/mortbay/jetty/HttpURI;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/jetty/HttpURI;","getHost",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitFieldStmt(IPUT_OBJECT,4,7,new Field("Lorg/mortbay/jetty/Request;","_serverName","Ljava/lang/String;"));
                code.visitLabel(L8);
                code.visitFieldStmt(IGET_OBJECT,4,7,new Field("Lorg/mortbay/jetty/Request;","_uri","Lorg/mortbay/jetty/HttpURI;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/jetty/HttpURI;","getPort",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitFieldStmt(IPUT,4,7,new Field("Lorg/mortbay/jetty/Request;","_port","I"));
                code.visitLabel(L9);
                code.visitFieldStmt(IGET_OBJECT,4,7,new Field("Lorg/mortbay/jetty/Request;","_serverName","Ljava/lang/String;"));
                code.visitJumpStmt(IF_EQZ,4,-1,L11);
                code.visitLabel(L10);
                code.visitFieldStmt(IGET_OBJECT,4,7,new Field("Lorg/mortbay/jetty/Request;","_serverName","Ljava/lang/String;"));
                code.visitJumpStmt(GOTO,-1,-1,L6);
                code.visitLabel(L11);
                code.visitFieldStmt(IGET_OBJECT,4,7,new Field("Lorg/mortbay/jetty/Request;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/jetty/HttpConnection;","getRequestFields",new String[]{ },"Lorg/mortbay/jetty/HttpFields;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitFieldStmt(SGET_OBJECT,5,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","HOST_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Lorg/mortbay/jetty/HttpFields;","get",new String[]{ "Lorg/mortbay/io/Buffer;"},"Lorg/mortbay/io/Buffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L12);
                code.visitJumpStmt(IF_EQZ,1,-1,L25);
                code.visitLabel(L13);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Lorg/mortbay/io/Buffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitLabel(L14);
                code.visitStmt2R(MOVE,3,2);
                code.visitLabel(L15);
                code.visitStmt3R(SUB_INT,2,3,6);
                code.visitLabel(L16);
                code.visitJumpStmt(IF_LEZ,3,-1,L21);
                code.visitLabel(L17);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Lorg/mortbay/io/Buffer;","getIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitStmt2R(ADD_INT_2ADDR,4,2);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1,4},new Method("Lorg/mortbay/io/Buffer;","peek",new String[]{ "I"},"B"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitConstStmt(CONST_16,5, Integer.valueOf(58)); // int: 0x0000003a  float:0.000000
                code.visitJumpStmt(IF_NE,4,5,L31);
                code.visitLabel(L18);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Lorg/mortbay/io/Buffer;","getIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1,4,2},new Method("Lorg/mortbay/io/Buffer;","peek",new String[]{ "I","I"},"Lorg/mortbay/io/Buffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 4},new Method("Lorg/mortbay/io/BufferUtil;","to8859_1_String",new String[]{ "Lorg/mortbay/io/Buffer;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitFieldStmt(IPUT_OBJECT,4,7,new Field("Lorg/mortbay/jetty/Request;","_serverName","Ljava/lang/String;"));
                code.visitLabel(L19);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Lorg/mortbay/io/Buffer;","getIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitStmt2R(ADD_INT_2ADDR,4,2);
                code.visitStmt2R1N(ADD_INT_LIT8,4,4,1);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Lorg/mortbay/io/Buffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitStmt2R(SUB_INT_2ADDR,5,2);
                code.visitStmt2R(SUB_INT_2ADDR,5,6);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1,4,5},new Method("Lorg/mortbay/io/Buffer;","peek",new String[]{ "I","I"},"Lorg/mortbay/io/Buffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 4},new Method("Lorg/mortbay/io/BufferUtil;","toInt",new String[]{ "Lorg/mortbay/io/Buffer;"},"I"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitFieldStmt(IPUT,4,7,new Field("Lorg/mortbay/jetty/Request;","_port","I"));
                code.visitLabel(L20);
                code.visitFieldStmt(IGET_OBJECT,4,7,new Field("Lorg/mortbay/jetty/Request;","_serverName","Ljava/lang/String;"));
                code.visitJumpStmt(GOTO,-1,-1,L6);
                code.visitLabel(L21);
                code.visitFieldStmt(IGET_OBJECT,4,7,new Field("Lorg/mortbay/jetty/Request;","_serverName","Ljava/lang/String;"));
                code.visitJumpStmt(IF_EQZ,4,-1,L22);
                code.visitFieldStmt(IGET,4,7,new Field("Lorg/mortbay/jetty/Request;","_port","I"));
                code.visitJumpStmt(IF_GEZ,4,-1,L24);
                code.visitLabel(L22);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1},new Method("Lorg/mortbay/io/BufferUtil;","to8859_1_String",new String[]{ "Lorg/mortbay/io/Buffer;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitFieldStmt(IPUT_OBJECT,4,7,new Field("Lorg/mortbay/jetty/Request;","_serverName","Ljava/lang/String;"));
                code.visitLabel(L23);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT,4,7,new Field("Lorg/mortbay/jetty/Request;","_port","I"));
                code.visitLabel(L24);
                code.visitFieldStmt(IGET_OBJECT,4,7,new Field("Lorg/mortbay/jetty/Request;","_serverName","Ljava/lang/String;"));
                code.visitJumpStmt(GOTO,-1,-1,L6);
                code.visitLabel(L25);
                code.visitFieldStmt(IGET_OBJECT,4,7,new Field("Lorg/mortbay/jetty/Request;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitJumpStmt(IF_EQZ,4,-1,L0);
                code.visitLabel(L26);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Lorg/mortbay/jetty/Request;","getLocalName",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitFieldStmt(IPUT_OBJECT,4,7,new Field("Lorg/mortbay/jetty/Request;","_serverName","Ljava/lang/String;"));
                code.visitLabel(L27);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Lorg/mortbay/jetty/Request;","getLocalPort",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitFieldStmt(IPUT,4,7,new Field("Lorg/mortbay/jetty/Request;","_port","I"));
                code.visitLabel(L28);
                code.visitFieldStmt(IGET_OBJECT,4,7,new Field("Lorg/mortbay/jetty/Request;","_serverName","Ljava/lang/String;"));
                code.visitJumpStmt(IF_EQZ,4,-1,L0);
                code.visitConstStmt(CONST_STRING,4,"0.0.0.0");
                code.visitFieldStmt(IGET_OBJECT,5,7,new Field("Lorg/mortbay/jetty/Request;","_serverName","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitJumpStmt(IF_NEZ,4,-1,L0);
                code.visitLabel(L29);
                code.visitFieldStmt(IGET_OBJECT,4,7,new Field("Lorg/mortbay/jetty/Request;","_serverName","Ljava/lang/String;"));
                code.visitJumpStmt(GOTO_16,-1,-1,L6);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Ljava/net/InetAddress;","getLocalHost",new String[]{ },"Ljava/net/InetAddress;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/net/InetAddress;","getHostAddress",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitFieldStmt(IPUT_OBJECT,4,7,new Field("Lorg/mortbay/jetty/Request;","_serverName","Ljava/lang/String;"));
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,4,7,new Field("Lorg/mortbay/jetty/Request;","_serverName","Ljava/lang/String;"));
                code.visitJumpStmt(GOTO_16,-1,-1,L6);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,4);
                code.visitStmt2R(MOVE_OBJECT,0,4);
                code.visitLabel(L30);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/log/Log;","ignore",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitLabel(L31);
                code.visitStmt2R(MOVE,3,2);
                code.visitLabel(L32);
                code.visitJumpStmt(GOTO_16,-1,-1,L15);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m057_getServerPort(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Request;","getServerPort",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1082,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(1084,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(1085,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(1087,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(1089,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(1090,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(1096,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(1098,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(1099,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(1102,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(1092,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(1100,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(1102,L12);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,2,new Field("Lorg/mortbay/jetty/Request;","_port","I"));
                code.visitJumpStmt(IF_GTZ,0,-1,L6);
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/Request;","_serverName","Ljava/lang/String;"));
                code.visitJumpStmt(IF_NEZ,0,-1,L3);
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/Request;","getServerName",new String[]{ },"Ljava/lang/String;"));
                code.visitLabel(L3);
                code.visitFieldStmt(IGET,0,2,new Field("Lorg/mortbay/jetty/Request;","_port","I"));
                code.visitJumpStmt(IF_GTZ,0,-1,L6);
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/Request;","_serverName","Ljava/lang/String;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L10);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/Request;","_uri","Lorg/mortbay/jetty/HttpURI;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L10);
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/Request;","_uri","Lorg/mortbay/jetty/HttpURI;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/HttpURI;","getPort",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitFieldStmt(IPUT,0,2,new Field("Lorg/mortbay/jetty/Request;","_port","I"));
                code.visitLabel(L6);
                code.visitFieldStmt(IGET,0,2,new Field("Lorg/mortbay/jetty/Request;","_port","I"));
                code.visitJumpStmt(IF_GTZ,0,-1,L12);
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/Request;","getScheme",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitConstStmt(CONST_STRING,1,"https");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/String;","equalsIgnoreCase",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L11);
                code.visitLabel(L8);
                code.visitConstStmt(CONST_16,0, Integer.valueOf(443)); // int: 0x000001bb  float:0.000000
                code.visitLabel(L9);
                code.visitStmt1R(RETURN,0);
                code.visitLabel(L10);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/Request;","_endp","Lorg/mortbay/io/EndPoint;"));
                DexLabel L13=new DexLabel();
                code.visitJumpStmt(IF_NEZ,0,-1,L13);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                DexLabel L14=new DexLabel();
                code.visitLabel(L14);
                code.visitFieldStmt(IPUT,0,2,new Field("Lorg/mortbay/jetty/Request;","_port","I"));
                code.visitJumpStmt(GOTO,-1,-1,L6);
                code.visitLabel(L13);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/Request;","_endp","Lorg/mortbay/io/EndPoint;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Lorg/mortbay/io/EndPoint;","getLocalPort",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(GOTO,-1,-1,L14);
                code.visitLabel(L11);
                code.visitConstStmt(CONST_16,0, Integer.valueOf(80)); // int: 0x00000050  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L9);
                code.visitLabel(L12);
                code.visitFieldStmt(IGET,0,2,new Field("Lorg/mortbay/jetty/Request;","_port","I"));
                code.visitJumpStmt(GOTO,-1,-1,L9);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m058_getServletContext(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Request;","getServletContext",new String[]{ },"Ljavax/servlet/ServletContext;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1970,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/Request;","_context","Lorg/mortbay/jetty/handler/ContextHandler$SContext;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m059_getServletName(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Request;","getServletName",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1121,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/Request;","_servletName","Ljava/lang/String;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m060_getServletPath(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Request;","getServletPath",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1111,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(1112,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(1113,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/Request;","_servletPath","Ljava/lang/String;"));
                code.visitJumpStmt(IF_NEZ,0,-1,L2);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_STRING,0,"");
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/Request;","_servletPath","Ljava/lang/String;"));
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/Request;","_servletPath","Ljava/lang/String;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m061_getServletResponse(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Request;","getServletResponse",new String[]{ },"Ljavax/servlet/ServletResponse;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1976,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/Request;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/HttpConnection;","getResponse",new String[]{ },"Lorg/mortbay/jetty/Response;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m062_getSession(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Request;","getSession",new String[]{ },"Ljavax/servlet/http/HttpSession;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1130,L0);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,0},new Method("Lorg/mortbay/jetty/Request;","getSession",new String[]{ "Z"},"Ljavax/servlet/http/HttpSession;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m063_getSession(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Request;","getSession",new String[]{ "Z"},"Ljavax/servlet/http/HttpSession;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(8);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"create");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(1139,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(1140,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(1142,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(1143,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(1164,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(1145,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(1147,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(1149,L8);
                ddv.visitStartLocal(1,L8,"id","Ljava/lang/String;",null);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(1151,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(1152,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(1153,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(1156,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(1158,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(1159,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(1160,L15);
                ddv.visitStartLocal(0,L15,"cookie","Ljavax/servlet/http/Cookie;",null);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(1161,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(1164,L17);
                ddv.visitEndLocal(0,L17);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,2,6,new Field("Lorg/mortbay/jetty/Request;","_sessionManager","Lorg/mortbay/jetty/SessionManager;"));
                code.visitJumpStmt(IF_NEZ,2,-1,L3);
                code.visitJumpStmt(IF_EQZ,7,-1,L3);
                code.visitLabel(L2);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Ljava/lang/IllegalStateException;");
                code.visitConstStmt(CONST_STRING,3,"No SessionHandler or SessionManager");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2,3},new Method("Ljava/lang/IllegalStateException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,2);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,2,6,new Field("Lorg/mortbay/jetty/Request;","_session","Ljavax/servlet/http/HttpSession;"));
                code.visitJumpStmt(IF_EQZ,2,-1,L6);
                code.visitFieldStmt(IGET_OBJECT,2,6,new Field("Lorg/mortbay/jetty/Request;","_sessionManager","Lorg/mortbay/jetty/SessionManager;"));
                code.visitJumpStmt(IF_EQZ,2,-1,L6);
                code.visitFieldStmt(IGET_OBJECT,2,6,new Field("Lorg/mortbay/jetty/Request;","_sessionManager","Lorg/mortbay/jetty/SessionManager;"));
                code.visitFieldStmt(IGET_OBJECT,3,6,new Field("Lorg/mortbay/jetty/Request;","_session","Ljavax/servlet/http/HttpSession;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2,3},new Method("Lorg/mortbay/jetty/SessionManager;","isValid",new String[]{ "Ljavax/servlet/http/HttpSession;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_EQZ,2,-1,L6);
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,2,6,new Field("Lorg/mortbay/jetty/Request;","_session","Ljavax/servlet/http/HttpSession;"));
                code.visitLabel(L5);
                code.visitStmt1R(RETURN_OBJECT,2);
                code.visitLabel(L6);
                code.visitFieldStmt(IPUT_OBJECT,4,6,new Field("Lorg/mortbay/jetty/Request;","_session","Ljavax/servlet/http/HttpSession;"));
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/Request;","getRequestedSessionId",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L8);
                code.visitJumpStmt(IF_EQZ,1,-1,L12);
                code.visitFieldStmt(IGET_OBJECT,2,6,new Field("Lorg/mortbay/jetty/Request;","_sessionManager","Lorg/mortbay/jetty/SessionManager;"));
                code.visitJumpStmt(IF_EQZ,2,-1,L12);
                code.visitLabel(L9);
                code.visitFieldStmt(IGET_OBJECT,2,6,new Field("Lorg/mortbay/jetty/Request;","_sessionManager","Lorg/mortbay/jetty/SessionManager;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2,1},new Method("Lorg/mortbay/jetty/SessionManager;","getHttpSession",new String[]{ "Ljava/lang/String;"},"Ljavax/servlet/http/HttpSession;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitFieldStmt(IPUT_OBJECT,2,6,new Field("Lorg/mortbay/jetty/Request;","_session","Ljavax/servlet/http/HttpSession;"));
                code.visitLabel(L10);
                code.visitFieldStmt(IGET_OBJECT,2,6,new Field("Lorg/mortbay/jetty/Request;","_session","Ljavax/servlet/http/HttpSession;"));
                code.visitJumpStmt(IF_NEZ,2,-1,L12);
                code.visitJumpStmt(IF_NEZ,7,-1,L12);
                code.visitStmt2R(MOVE_OBJECT,2,4);
                code.visitLabel(L11);
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitLabel(L12);
                code.visitFieldStmt(IGET_OBJECT,2,6,new Field("Lorg/mortbay/jetty/Request;","_session","Ljavax/servlet/http/HttpSession;"));
                code.visitJumpStmt(IF_NEZ,2,-1,L17);
                code.visitFieldStmt(IGET_OBJECT,2,6,new Field("Lorg/mortbay/jetty/Request;","_sessionManager","Lorg/mortbay/jetty/SessionManager;"));
                code.visitJumpStmt(IF_EQZ,2,-1,L17);
                code.visitJumpStmt(IF_EQZ,7,-1,L17);
                code.visitLabel(L13);
                code.visitFieldStmt(IGET_OBJECT,2,6,new Field("Lorg/mortbay/jetty/Request;","_sessionManager","Lorg/mortbay/jetty/SessionManager;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2,6},new Method("Lorg/mortbay/jetty/SessionManager;","newHttpSession",new String[]{ "Ljavax/servlet/http/HttpServletRequest;"},"Ljavax/servlet/http/HttpSession;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitFieldStmt(IPUT_OBJECT,2,6,new Field("Lorg/mortbay/jetty/Request;","_session","Ljavax/servlet/http/HttpSession;"));
                code.visitLabel(L14);
                code.visitFieldStmt(IGET_OBJECT,2,6,new Field("Lorg/mortbay/jetty/Request;","_sessionManager","Lorg/mortbay/jetty/SessionManager;"));
                code.visitFieldStmt(IGET_OBJECT,3,6,new Field("Lorg/mortbay/jetty/Request;","_session","Ljavax/servlet/http/HttpSession;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/Request;","getContextPath",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/Request;","isSecure",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2,3,4,5},new Method("Lorg/mortbay/jetty/SessionManager;","getSessionCookie",new String[]{ "Ljavax/servlet/http/HttpSession;","Ljava/lang/String;","Z"},"Ljavax/servlet/http/Cookie;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L15);
                code.visitJumpStmt(IF_EQZ,0,-1,L17);
                code.visitLabel(L16);
                code.visitFieldStmt(IGET_OBJECT,2,6,new Field("Lorg/mortbay/jetty/Request;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/HttpConnection;","getResponse",new String[]{ },"Lorg/mortbay/jetty/Response;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,0},new Method("Lorg/mortbay/jetty/Response;","addCookie",new String[]{ "Ljavax/servlet/http/Cookie;"},"V"));
                code.visitLabel(L17);
                code.visitFieldStmt(IGET_OBJECT,2,6,new Field("Lorg/mortbay/jetty/Request;","_session","Ljavax/servlet/http/HttpSession;"));
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m064_getSessionManager(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Request;","getSessionManager",new String[]{ },"Lorg/mortbay/jetty/SessionManager;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1643,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/Request;","_sessionManager","Lorg/mortbay/jetty/SessionManager;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m065_getTimeStamp(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Request;","getTimeStamp",new String[]{ },"J"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(251,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_WIDE,0,2,new Field("Lorg/mortbay/jetty/Request;","_timeStamp","J"));
                code.visitStmt1R(RETURN_WIDE,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m066_getTimeStampBuffer(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Request;","getTimeStampBuffer",new String[]{ },"Lorg/mortbay/io/Buffer;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(238,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(239,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(240,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/jetty/Request;","_timeStampBuffer","Lorg/mortbay/io/Buffer;"));
                code.visitJumpStmt(IF_NEZ,0,-1,L2);
                code.visitFieldStmt(IGET_WIDE,0,4,new Field("Lorg/mortbay/jetty/Request;","_timeStamp","J"));
                code.visitConstStmt(CONST_WIDE_16,2,Long.valueOf(0L)); // long: 0x0000000000000000  double:0.000000
                code.visitStmt3R(CMP_LONG,0,0,2);
                code.visitJumpStmt(IF_LEZ,0,-1,L2);
                code.visitLabel(L1);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpFields;","__dateCache","Lorg/mortbay/io/BufferDateCache;"));
                code.visitFieldStmt(IGET_WIDE,1,4,new Field("Lorg/mortbay/jetty/Request;","_timeStamp","J"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Lorg/mortbay/io/BufferDateCache;","formatBuffer",new String[]{ "J"},"Lorg/mortbay/io/Buffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IPUT_OBJECT,0,4,new Field("Lorg/mortbay/jetty/Request;","_timeStampBuffer","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/jetty/Request;","_timeStampBuffer","Lorg/mortbay/io/Buffer;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m067_getUri(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Request;","getUri",new String[]{ },"Lorg/mortbay/jetty/HttpURI;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1553,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/Request;","_uri","Lorg/mortbay/jetty/HttpURI;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m068_getUserPrincipal(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Request;","getUserPrincipal",new String[]{ },"Ljava/security/Principal;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(9);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/lang/Exception;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(1173,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(1175,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(1176,L6);
                ddv.visitStartLocal(2,L6,"not_checked","Lorg/mortbay/jetty/security/SecurityHandler$NotChecked;",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(1178,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(1179,L8);
                ddv.visitStartLocal(0,L8,"auth","Lorg/mortbay/jetty/security/Authenticator;",null);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(1180,L9);
                ddv.visitStartLocal(4,L9,"realm","Lorg/mortbay/jetty/security/UserRealm;",null);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(1182,L10);
                ddv.visitStartLocal(3,L10,"pathInContext","Ljava/lang/String;",null);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(1186,L11);
                ddv.visitLineNumber(1195,L1);
                ddv.visitEndLocal(2,L1);
                ddv.visitEndLocal(0,L1);
                ddv.visitEndLocal(4,L1);
                ddv.visitEndLocal(3,L1);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(1197,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(1180,L13);
                ddv.visitRestartLocal(0,L13);
                ddv.visitRestartLocal(2,L13);
                ddv.visitRestartLocal(4,L13);
                ddv.visitLineNumber(1188,L2);
                ddv.visitRestartLocal(3,L2);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(1190,L14);
                ddv.visitStartLocal(1,L14,"e","Ljava/lang/Exception;",null);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(1197,L15);
                ddv.visitEndLocal(0,L15);
                ddv.visitEndLocal(2,L15);
                ddv.visitEndLocal(4,L15);
                ddv.visitEndLocal(3,L15);
                ddv.visitEndLocal(1,L15);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,7, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,5,8,new Field("Lorg/mortbay/jetty/Request;","_userPrincipal","Ljava/security/Principal;"));
                code.visitJumpStmt(IF_EQZ,5,-1,L1);
                code.visitFieldStmt(IGET_OBJECT,5,8,new Field("Lorg/mortbay/jetty/Request;","_userPrincipal","Ljava/security/Principal;"));
                code.visitTypeStmt(INSTANCE_OF,5,5,"Lorg/mortbay/jetty/security/SecurityHandler$NotChecked;");
                code.visitJumpStmt(IF_EQZ,5,-1,L1);
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,2,8,new Field("Lorg/mortbay/jetty/Request;","_userPrincipal","Ljava/security/Principal;"));
                code.visitTypeStmt(CHECK_CAST,2,-1,"Lorg/mortbay/jetty/security/SecurityHandler$NotChecked;");
                code.visitLabel(L6);
                code.visitFieldStmt(SGET_OBJECT,5,-1,new Field("Lorg/mortbay/jetty/security/SecurityHandler;","__NO_USER","Ljava/security/Principal;"));
                code.visitFieldStmt(IPUT_OBJECT,5,8,new Field("Lorg/mortbay/jetty/Request;","_userPrincipal","Ljava/security/Principal;"));
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/security/SecurityHandler$NotChecked;","getSecurityHandler",new String[]{ },"Lorg/mortbay/jetty/security/SecurityHandler;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/jetty/security/SecurityHandler;","getAuthenticator",new String[]{ },"Lorg/mortbay/jetty/security/Authenticator;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/security/SecurityHandler$NotChecked;","getSecurityHandler",new String[]{ },"Lorg/mortbay/jetty/security/SecurityHandler;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/jetty/security/SecurityHandler;","getUserRealm",new String[]{ },"Lorg/mortbay/jetty/security/UserRealm;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Lorg/mortbay/jetty/Request;","getPathInfo",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitJumpStmt(IF_NEZ,5,-1,L13);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Lorg/mortbay/jetty/Request;","getServletPath",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitStmt2R(MOVE_OBJECT,3,5);
                code.visitLabel(L10);
                code.visitJumpStmt(IF_EQZ,4,-1,L1);
                code.visitJumpStmt(IF_EQZ,0,-1,L1);
                code.visitLabel(L11);
                code.visitConstStmt(CONST_4,5, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,4,3,8,5},new Method("Lorg/mortbay/jetty/security/Authenticator;","authenticate",new String[]{ "Lorg/mortbay/jetty/security/UserRealm;","Ljava/lang/String;","Lorg/mortbay/jetty/Request;","Lorg/mortbay/jetty/Response;"},"Ljava/security/Principal;"));
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,5,8,new Field("Lorg/mortbay/jetty/Request;","_userPrincipal","Ljava/security/Principal;"));
                code.visitFieldStmt(SGET_OBJECT,6,-1,new Field("Lorg/mortbay/jetty/security/SecurityHandler;","__NO_USER","Ljava/security/Principal;"));
                code.visitJumpStmt(IF_NE,5,6,L15);
                code.visitStmt2R(MOVE_OBJECT,5,7);
                code.visitLabel(L12);
                code.visitStmt1R(RETURN_OBJECT,5);
                code.visitLabel(L13);
                code.visitTypeStmt(NEW_INSTANCE,5,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 5},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Lorg/mortbay/jetty/Request;","getServletPath",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Lorg/mortbay/jetty/Request;","getPathInfo",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitStmt2R(MOVE_OBJECT,3,5);
                code.visitJumpStmt(GOTO,-1,-1,L10);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitLabel(L14);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1},new Method("Lorg/mortbay/log/Log;","ignore",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitLabel(L15);
                code.visitFieldStmt(IGET_OBJECT,5,8,new Field("Lorg/mortbay/jetty/Request;","_userPrincipal","Ljava/security/Principal;"));
                code.visitJumpStmt(GOTO,-1,-1,L12);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m069_getUserRealm(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Request;","getUserRealm",new String[]{ },"Lorg/mortbay/jetty/security/UserRealm;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1921,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/Request;","_userRealm","Lorg/mortbay/jetty/security/UserRealm;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m070_isHandled(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Request;","isHandled",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(263,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_BOOLEAN,0,1,new Field("Lorg/mortbay/jetty/Request;","_handled","Z"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m071_isRequestedSessionIdFromCookie(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Request;","isRequestedSessionIdFromCookie",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1222,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/Request;","_requestedSessionId","Ljava/lang/String;"));
                DexLabel L1=new DexLabel();
                code.visitJumpStmt(IF_EQZ,0,-1,L1);
                code.visitFieldStmt(IGET_BOOLEAN,0,1,new Field("Lorg/mortbay/jetty/Request;","_requestedSessionIdFromCookie","Z"));
                code.visitJumpStmt(IF_EQZ,0,-1,L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                DexLabel L2=new DexLabel();
                code.visitLabel(L2);
                code.visitStmt1R(RETURN,0);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m072_isRequestedSessionIdFromURL(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Request;","isRequestedSessionIdFromURL",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1240,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/Request;","_requestedSessionId","Ljava/lang/String;"));
                DexLabel L1=new DexLabel();
                code.visitJumpStmt(IF_EQZ,0,-1,L1);
                code.visitFieldStmt(IGET_BOOLEAN,0,1,new Field("Lorg/mortbay/jetty/Request;","_requestedSessionIdFromCookie","Z"));
                code.visitJumpStmt(IF_NEZ,0,-1,L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                DexLabel L2=new DexLabel();
                code.visitLabel(L2);
                code.visitStmt1R(RETURN,0);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m073_isRequestedSessionIdFromUrl(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Request;","isRequestedSessionIdFromUrl",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1231,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/Request;","_requestedSessionId","Ljava/lang/String;"));
                DexLabel L1=new DexLabel();
                code.visitJumpStmt(IF_EQZ,0,-1,L1);
                code.visitFieldStmt(IGET_BOOLEAN,0,1,new Field("Lorg/mortbay/jetty/Request;","_requestedSessionIdFromCookie","Z"));
                code.visitJumpStmt(IF_NEZ,0,-1,L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                DexLabel L2=new DexLabel();
                code.visitLabel(L2);
                code.visitStmt1R(RETURN,0);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m074_isRequestedSessionIdValid(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Request;","isRequestedSessionIdValid",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(1249,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(1253,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(1252,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(1253,L4);
                ddv.visitStartLocal(0,L4,"session","Ljavax/servlet/http/HttpSession;",null);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/jetty/Request;","_requestedSessionId","Ljava/lang/String;"));
                code.visitJumpStmt(IF_NEZ,1,-1,L3);
                code.visitStmt2R(MOVE,1,2);
                code.visitLabel(L2);
                code.visitStmt1R(RETURN,1);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,2},new Method("Lorg/mortbay/jetty/Request;","getSession",new String[]{ "Z"},"Ljavax/servlet/http/HttpSession;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L4);
                DexLabel L5=new DexLabel();
                code.visitJumpStmt(IF_NEZ,0,-1,L5);
                code.visitStmt2R(MOVE,1,2);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/jetty/Request;","_sessionManager","Lorg/mortbay/jetty/SessionManager;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Lorg/mortbay/jetty/SessionManager;","getIdManager",new String[]{ },"Lorg/mortbay/jetty/SessionIdManager;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitFieldStmt(IGET_OBJECT,2,3,new Field("Lorg/mortbay/jetty/Request;","_requestedSessionId","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1,2},new Method("Lorg/mortbay/jetty/SessionIdManager;","getClusterId",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitFieldStmt(IGET_OBJECT,2,3,new Field("Lorg/mortbay/jetty/Request;","_sessionManager","Lorg/mortbay/jetty/SessionManager;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2,0},new Method("Lorg/mortbay/jetty/SessionManager;","getClusterId",new String[]{ "Ljavax/servlet/http/HttpSession;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m075_isSecure(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Request;","isSecure",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1262,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/Request;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/HttpConnection;","isConfidential",new String[]{ "Lorg/mortbay/jetty/Request;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m076_isUserInRole(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Request;","isUserInRole",new String[]{ "Ljava/lang/String;"},"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"role");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1271,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(1273,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(1274,L2);
                ddv.visitStartLocal(1,L2,"r","Ljava/lang/String;",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(1275,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(1278,L4);
                ddv.visitEndLocal(1,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(1280,L5);
                ddv.visitStartLocal(0,L5,"principal","Ljava/security/Principal;",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(1281,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(1283,L7);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,2,3,new Field("Lorg/mortbay/jetty/Request;","_roleMap","Ljava/util/Map;"));
                code.visitJumpStmt(IF_EQZ,2,-1,L4);
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,2,3,new Field("Lorg/mortbay/jetty/Request;","_roleMap","Ljava/util/Map;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2,4},new Method("Ljava/util/Map;","get",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitTypeStmt(CHECK_CAST,1,-1,"Ljava/lang/String;");
                code.visitLabel(L2);
                code.visitJumpStmt(IF_EQZ,1,-1,L4);
                code.visitLabel(L3);
                code.visitStmt2R(MOVE_OBJECT,4,1);
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/jetty/Request;","getUserPrincipal",new String[]{ },"Ljava/security/Principal;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,2,3,new Field("Lorg/mortbay/jetty/Request;","_userRealm","Lorg/mortbay/jetty/security/UserRealm;"));
                DexLabel L8=new DexLabel();
                code.visitJumpStmt(IF_EQZ,2,-1,L8);
                code.visitJumpStmt(IF_EQZ,0,-1,L8);
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,2,3,new Field("Lorg/mortbay/jetty/Request;","_userRealm","Lorg/mortbay/jetty/security/UserRealm;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2,0,4},new Method("Lorg/mortbay/jetty/security/UserRealm;","isUserInRole",new String[]{ "Ljava/security/Principal;","Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitLabel(L7);
                code.visitStmt1R(RETURN,2);
                code.visitLabel(L8);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L7);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m077_recoverNewSession(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Request;","recoverNewSession",new String[]{ "Ljava/lang/Object;"},"Ljavax/servlet/http/HttpSession;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"key");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1910,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(1911,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(1912,L2);
                ddv.visitEndLocal(1,L2);
                DexLabel L3=new DexLabel();
                ddv.visitRestartLocal(1,L3);
                DexLabel L4=new DexLabel();
                ddv.visitEndLocal(1,L4);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/Request;","_savedNewSessions","Ljava/util/Map;"));
                code.visitJumpStmt(IF_NEZ,0,-1,L3);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L2);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/Request;","_savedNewSessions","Ljava/util/Map;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,2},new Method("Ljava/util/Map;","get",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L4);
                code.visitTypeStmt(CHECK_CAST,1,-1,"Ljavax/servlet/http/HttpSession;");
                code.visitStmt2R(MOVE_OBJECT,0,1);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m078_recycle(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/Request;","recycle",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(191,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(192,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(193,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(194,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(195,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(196,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(197,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(198,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(199,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(200,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(201,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(202,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(203,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(204,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(205,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(206,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(207,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(208,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(209,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(210,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(211,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(212,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(213,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(214,L24);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(215,L25);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(216,L26);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(217,L27);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(218,L28);
                DexLabel L29=new DexLabel();
                ddv.visitLineNumber(219,L29);
                DexLabel L30=new DexLabel();
                ddv.visitLineNumber(220,L30);
                DexLabel L31=new DexLabel();
                ddv.visitLineNumber(222,L31);
                DexLabel L32=new DexLabel();
                ddv.visitLineNumber(223,L32);
                DexLabel L33=new DexLabel();
                ddv.visitLineNumber(224,L33);
                DexLabel L34=new DexLabel();
                ddv.visitLineNumber(225,L34);
                DexLabel L35=new DexLabel();
                ddv.visitLineNumber(226,L35);
                DexLabel L36=new DexLabel();
                ddv.visitLineNumber(227,L36);
                DexLabel L37=new DexLabel();
                ddv.visitLineNumber(228,L37);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitFieldStmt(IPUT_BOOLEAN,3,4,new Field("Lorg/mortbay/jetty/Request;","_handled","Z"));
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/jetty/Request;","_context","Lorg/mortbay/jetty/handler/ContextHandler$SContext;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L4);
                code.visitLabel(L3);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/IllegalStateException;");
                code.visitConstStmt(CONST_STRING,1,"Request in context!");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Ljava/lang/IllegalStateException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,0);
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/jetty/Request;","_attributes","Lorg/mortbay/util/Attributes;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L6);
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/jetty/Request;","_attributes","Lorg/mortbay/util/Attributes;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Lorg/mortbay/util/Attributes;","clearAttributes",new String[]{ },"V"));
                code.visitLabel(L6);
                code.visitFieldStmt(IPUT_OBJECT,2,4,new Field("Lorg/mortbay/jetty/Request;","_authType","Ljava/lang/String;"));
                code.visitLabel(L7);
                code.visitFieldStmt(IPUT_OBJECT,2,4,new Field("Lorg/mortbay/jetty/Request;","_characterEncoding","Ljava/lang/String;"));
                code.visitLabel(L8);
                code.visitFieldStmt(IPUT_OBJECT,2,4,new Field("Lorg/mortbay/jetty/Request;","_queryEncoding","Ljava/lang/String;"));
                code.visitLabel(L9);
                code.visitFieldStmt(IPUT_OBJECT,2,4,new Field("Lorg/mortbay/jetty/Request;","_context","Lorg/mortbay/jetty/handler/ContextHandler$SContext;"));
                code.visitLabel(L10);
                code.visitFieldStmt(IPUT_OBJECT,2,4,new Field("Lorg/mortbay/jetty/Request;","_serverName","Ljava/lang/String;"));
                code.visitLabel(L11);
                code.visitFieldStmt(IPUT_OBJECT,2,4,new Field("Lorg/mortbay/jetty/Request;","_method","Ljava/lang/String;"));
                code.visitLabel(L12);
                code.visitFieldStmt(IPUT_OBJECT,2,4,new Field("Lorg/mortbay/jetty/Request;","_pathInfo","Ljava/lang/String;"));
                code.visitLabel(L13);
                code.visitFieldStmt(IPUT,3,4,new Field("Lorg/mortbay/jetty/Request;","_port","I"));
                code.visitLabel(L14);
                code.visitConstStmt(CONST_STRING,0,"HTTP/1.1");
                code.visitFieldStmt(IPUT_OBJECT,0,4,new Field("Lorg/mortbay/jetty/Request;","_protocol","Ljava/lang/String;"));
                code.visitLabel(L15);
                code.visitFieldStmt(IPUT_OBJECT,2,4,new Field("Lorg/mortbay/jetty/Request;","_queryString","Ljava/lang/String;"));
                code.visitLabel(L16);
                code.visitFieldStmt(IPUT_OBJECT,2,4,new Field("Lorg/mortbay/jetty/Request;","_requestedSessionId","Ljava/lang/String;"));
                code.visitLabel(L17);
                code.visitFieldStmt(IPUT_BOOLEAN,3,4,new Field("Lorg/mortbay/jetty/Request;","_requestedSessionIdFromCookie","Z"));
                code.visitLabel(L18);
                code.visitFieldStmt(IPUT_OBJECT,2,4,new Field("Lorg/mortbay/jetty/Request;","_session","Ljavax/servlet/http/HttpSession;"));
                code.visitLabel(L19);
                code.visitFieldStmt(IPUT_OBJECT,2,4,new Field("Lorg/mortbay/jetty/Request;","_requestURI","Ljava/lang/String;"));
                code.visitLabel(L20);
                code.visitConstStmt(CONST_STRING,0,"http");
                code.visitFieldStmt(IPUT_OBJECT,0,4,new Field("Lorg/mortbay/jetty/Request;","_scheme","Ljava/lang/String;"));
                code.visitLabel(L21);
                code.visitFieldStmt(IPUT_OBJECT,2,4,new Field("Lorg/mortbay/jetty/Request;","_servletPath","Ljava/lang/String;"));
                code.visitLabel(L22);
                code.visitConstStmt(CONST_WIDE_16,0,Long.valueOf(0L)); // long: 0x0000000000000000  double:0.000000
                code.visitFieldStmt(IPUT_WIDE,0,4,new Field("Lorg/mortbay/jetty/Request;","_timeStamp","J"));
                code.visitLabel(L23);
                code.visitFieldStmt(IPUT_OBJECT,2,4,new Field("Lorg/mortbay/jetty/Request;","_timeStampBuffer","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L24);
                code.visitFieldStmt(IPUT_OBJECT,2,4,new Field("Lorg/mortbay/jetty/Request;","_uri","Lorg/mortbay/jetty/HttpURI;"));
                code.visitLabel(L25);
                code.visitFieldStmt(IPUT_OBJECT,2,4,new Field("Lorg/mortbay/jetty/Request;","_userPrincipal","Ljava/security/Principal;"));
                code.visitLabel(L26);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/jetty/Request;","_baseParameters","Lorg/mortbay/util/MultiMap;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L28);
                code.visitLabel(L27);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/jetty/Request;","_baseParameters","Lorg/mortbay/util/MultiMap;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/util/MultiMap;","clear",new String[]{ },"V"));
                code.visitLabel(L28);
                code.visitFieldStmt(IPUT_OBJECT,2,4,new Field("Lorg/mortbay/jetty/Request;","_parameters","Lorg/mortbay/util/MultiMap;"));
                code.visitLabel(L29);
                code.visitFieldStmt(IPUT_BOOLEAN,3,4,new Field("Lorg/mortbay/jetty/Request;","_paramsExtracted","Z"));
                code.visitLabel(L30);
                code.visitFieldStmt(IPUT,3,4,new Field("Lorg/mortbay/jetty/Request;","_inputState","I"));
                code.visitLabel(L31);
                code.visitFieldStmt(IPUT_BOOLEAN,3,4,new Field("Lorg/mortbay/jetty/Request;","_cookiesExtracted","Z"));
                code.visitLabel(L32);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/jetty/Request;","_savedNewSessions","Ljava/util/Map;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L34);
                code.visitLabel(L33);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/jetty/Request;","_savedNewSessions","Ljava/util/Map;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Ljava/util/Map;","clear",new String[]{ },"V"));
                code.visitLabel(L34);
                code.visitFieldStmt(IPUT_OBJECT,2,4,new Field("Lorg/mortbay/jetty/Request;","_savedNewSessions","Ljava/util/Map;"));
                code.visitLabel(L35);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/jetty/Request;","_continuation","Lorg/mortbay/util/ajax/Continuation;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L37);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/jetty/Request;","_continuation","Lorg/mortbay/util/ajax/Continuation;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Lorg/mortbay/util/ajax/Continuation;","isPending",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L37);
                code.visitLabel(L36);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/jetty/Request;","_continuation","Lorg/mortbay/util/ajax/Continuation;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Lorg/mortbay/util/ajax/Continuation;","reset",new String[]{ },"V"));
                code.visitLabel(L37);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m079_removeAttribute(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Request;","removeAttribute",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(10);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1292,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(1294,L1);
                ddv.visitStartLocal(5,L1,"old_value","Ljava/lang/Object;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(1295,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(1297,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(1299,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(1301,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(1303,L6);
                ddv.visitStartLocal(1,L6,"event","Ljavax/servlet/ServletRequestAttributeEvent;",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(1304,L7);
                ddv.visitStartLocal(6,L7,"size","I",null);
                DexLabel L8=new DexLabel();
                ddv.visitStartLocal(2,L8,"i","I",null);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(1306,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(1307,L10);
                ddv.visitStartLocal(4,L10,"listener","Ljava/util/EventListener;",null);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(1309,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(1310,L12);
                ddv.visitStartLocal(3,L12,"l","Ljavax/servlet/ServletRequestAttributeListener;",null);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(1304,L13);
                ddv.visitEndLocal(3,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(1292,L14);
                ddv.visitEndLocal(5,L14);
                ddv.visitEndLocal(1,L14);
                ddv.visitEndLocal(6,L14);
                ddv.visitEndLocal(2,L14);
                ddv.visitEndLocal(4,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(1315,L15);
                ddv.visitRestartLocal(5,L15);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,7,8,new Field("Lorg/mortbay/jetty/Request;","_attributes","Lorg/mortbay/util/Attributes;"));
                code.visitJumpStmt(IF_NEZ,7,-1,L14);
                code.visitConstStmt(CONST_4,7, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt2R(MOVE_OBJECT,5,7);
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,7,8,new Field("Lorg/mortbay/jetty/Request;","_attributes","Lorg/mortbay/util/Attributes;"));
                code.visitJumpStmt(IF_EQZ,7,-1,L3);
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,7,8,new Field("Lorg/mortbay/jetty/Request;","_attributes","Lorg/mortbay/util/Attributes;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 7,9},new Method("Lorg/mortbay/util/Attributes;","removeAttribute",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L3);
                code.visitJumpStmt(IF_EQZ,5,-1,L15);
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,7,8,new Field("Lorg/mortbay/jetty/Request;","_requestAttributeListeners","Ljava/lang/Object;"));
                code.visitJumpStmt(IF_EQZ,7,-1,L15);
                code.visitLabel(L5);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljavax/servlet/ServletRequestAttributeEvent;");
                code.visitFieldStmt(IGET_OBJECT,7,8,new Field("Lorg/mortbay/jetty/Request;","_context","Lorg/mortbay/jetty/handler/ContextHandler$SContext;"));
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,7,8,9,5},new Method("Ljavax/servlet/ServletRequestAttributeEvent;","<init>",new String[]{ "Ljavax/servlet/ServletContext;","Ljavax/servlet/ServletRequest;","Ljava/lang/String;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,7,8,new Field("Lorg/mortbay/jetty/Request;","_requestAttributeListeners","Ljava/lang/Object;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 7},new Method("Lorg/mortbay/util/LazyList;","size",new String[]{ "Ljava/lang/Object;"},"I"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitLabel(L7);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L8);
                code.visitJumpStmt(IF_GE,2,6,L15);
                code.visitLabel(L9);
                code.visitFieldStmt(IGET_OBJECT,7,8,new Field("Lorg/mortbay/jetty/Request;","_requestAttributeListeners","Ljava/lang/Object;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 7,2},new Method("Lorg/mortbay/util/LazyList;","get",new String[]{ "Ljava/lang/Object;","I"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitTypeStmt(CHECK_CAST,4,-1,"Ljavax/servlet/ServletRequestAttributeListener;");
                code.visitLabel(L10);
                code.visitTypeStmt(INSTANCE_OF,7,4,"Ljavax/servlet/ServletRequestAttributeListener;");
                code.visitJumpStmt(IF_EQZ,7,-1,L13);
                code.visitLabel(L11);
                code.visitStmt2R(MOVE_OBJECT,0,4);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Ljavax/servlet/ServletRequestAttributeListener;");
                code.visitStmt2R(MOVE_OBJECT,3,0);
                code.visitLabel(L12);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3,1},new Method("Ljavax/servlet/ServletRequestAttributeListener;","attributeRemoved",new String[]{ "Ljavax/servlet/ServletRequestAttributeEvent;"},"V"));
                code.visitLabel(L13);
                code.visitStmt2R1N(ADD_INT_LIT8,2,2,1);
                code.visitJumpStmt(GOTO,-1,-1,L8);
                code.visitLabel(L14);
                code.visitFieldStmt(IGET_OBJECT,7,8,new Field("Lorg/mortbay/jetty/Request;","_attributes","Lorg/mortbay/util/Attributes;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 7,9},new Method("Lorg/mortbay/util/Attributes;","getAttribute",new String[]{ "Ljava/lang/String;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitStmt2R(MOVE_OBJECT,5,7);
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitLabel(L15);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m080_removeEventListener(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Request;","removeEventListener",new String[]{ "Ljava/util/EventListener;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"listener");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1877,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(1878,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/Request;","_requestAttributeListeners","Ljava/lang/Object;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,2},new Method("Lorg/mortbay/util/LazyList;","remove",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/Request;","_requestAttributeListeners","Ljava/lang/Object;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m081_saveNewSession(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Request;","saveNewSession",new String[]{ "Ljava/lang/Object;","Ljavax/servlet/http/HttpSession;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"key");
                ddv.visitParameterName(1,"session");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1903,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(1904,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(1905,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(1906,L3);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/Request;","_savedNewSessions","Ljava/util/Map;"));
                code.visitJumpStmt(IF_NEZ,0,-1,L2);
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/util/HashMap;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/util/HashMap;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/Request;","_savedNewSessions","Ljava/util/Map;"));
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/Request;","_savedNewSessions","Ljava/util/Map;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,2,3},new Method("Ljava/util/Map;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L3);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m082_setAttribute(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Request;","setAttribute",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(15);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/io/IOException;"});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                code.visitTryCatch(L1,L3,new DexLabel[]{L4},new String[]{ null});
                code.visitTryCatch(L3,L2,new DexLabel[]{L2},new String[]{ "Ljava/io/IOException;"});
                DexLabel L5=new DexLabel();
                DexLabel L6=new DexLabel();
                code.visitTryCatch(L5,L6,new DexLabel[]{L4},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                ddv.visitParameterName(1,"value");
                DexLabel L7=new DexLabel();
                ddv.visitPrologue(L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(1330,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(1332,L9);
                ddv.visitStartLocal(8,L9,"old_value","Ljava/lang/Object;",null);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(1333,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(1354,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(1355,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(1356,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(1358,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(1360,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(1362,L16);
                ddv.visitStartLocal(4,L16,"event","Ljavax/servlet/ServletRequestAttributeEvent;",null);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(1363,L17);
                ddv.visitStartLocal(9,L17,"size","I",null);
                DexLabel L18=new DexLabel();
                ddv.visitStartLocal(5,L18,"i","I",null);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(1365,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(1366,L20);
                ddv.visitStartLocal(7,L20,"listener","Ljava/util/EventListener;",null);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(1368,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(1370,L22);
                ddv.visitStartLocal(6,L22,"l","Ljavax/servlet/ServletRequestAttributeListener;",null);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(1371,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(1363,L24);
                ddv.visitEndLocal(6,L24);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(1330,L25);
                ddv.visitEndLocal(8,L25);
                ddv.visitEndLocal(4,L25);
                ddv.visitEndLocal(9,L25);
                ddv.visitEndLocal(5,L25);
                ddv.visitEndLocal(7,L25);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(1333,L26);
                ddv.visitRestartLocal(8,L26);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(1334,L27);
                ddv.visitLineNumber(1338,L0);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(1339,L28);
                ddv.visitStartLocal(2,L28,"byteBuffer","Ljava/nio/ByteBuffer;",null);
                ddv.visitLineNumber(1341,L1);
                DexLabel L29=new DexLabel();
                ddv.visitLineNumber(1344,L29);
                ddv.visitStartLocal(1,L29,"buffer","Lorg/mortbay/io/nio/NIOBuffer;",null);
                DexLabel L30=new DexLabel();
                ddv.visitLineNumber(1345,L30);
                ddv.visitEndLocal(1,L4);
                ddv.visitLineNumber(1347,L2);
                ddv.visitEndLocal(2,L2);
                DexLabel L31=new DexLabel();
                ddv.visitLineNumber(1349,L31);
                ddv.visitStartLocal(3,L31,"e","Ljava/io/IOException;",null);
                ddv.visitLineNumber(1341,L5);
                ddv.visitEndLocal(3,L5);
                ddv.visitRestartLocal(2,L5);
                DexLabel L32=new DexLabel();
                ddv.visitEndLocal(2,L32);
                DexLabel L33=new DexLabel();
                ddv.visitLineNumber(1360,L33);
                DexLabel L34=new DexLabel();
                ddv.visitLineNumber(1372,L34);
                ddv.visitRestartLocal(4,L34);
                ddv.visitRestartLocal(5,L34);
                ddv.visitRestartLocal(6,L34);
                ddv.visitRestartLocal(7,L34);
                ddv.visitRestartLocal(9,L34);
                DexLabel L35=new DexLabel();
                ddv.visitLineNumber(1373,L35);
                DexLabel L36=new DexLabel();
                ddv.visitLineNumber(1375,L36);
                DexLabel L37=new DexLabel();
                ddv.visitLineNumber(1379,L37);
                ddv.visitEndLocal(4,L37);
                ddv.visitEndLocal(5,L37);
                ddv.visitEndLocal(6,L37);
                ddv.visitEndLocal(7,L37);
                ddv.visitEndLocal(9,L37);
                code.visitLabel(L7);
                code.visitConstStmt(CONST_4,11, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L8);
                code.visitFieldStmt(IGET_OBJECT,10,12,new Field("Lorg/mortbay/jetty/Request;","_attributes","Lorg/mortbay/util/Attributes;"));
                code.visitJumpStmt(IF_NEZ,10,-1,L25);
                code.visitStmt2R(MOVE_OBJECT,8,11);
                code.visitLabel(L9);
                code.visitConstStmt(CONST_STRING,10,"org.mortbay.jetty.Request.queryEncoding");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10,13},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,10);
                code.visitJumpStmt(IF_EQZ,10,-1,L27);
                code.visitLabel(L10);
                code.visitJumpStmt(IF_NEZ,14,-1,L26);
                code.visitStmt2R(MOVE_OBJECT,10,11);
                DexLabel L38=new DexLabel();
                code.visitLabel(L38);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12,10},new Method("Lorg/mortbay/jetty/Request;","setQueryEncoding",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L11);
                code.visitFieldStmt(IGET_OBJECT,10,12,new Field("Lorg/mortbay/jetty/Request;","_attributes","Lorg/mortbay/util/Attributes;"));
                code.visitJumpStmt(IF_NEZ,10,-1,L13);
                code.visitLabel(L12);
                code.visitTypeStmt(NEW_INSTANCE,10,-1,"Lorg/mortbay/util/AttributesMap;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 10},new Method("Lorg/mortbay/util/AttributesMap;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,10,12,new Field("Lorg/mortbay/jetty/Request;","_attributes","Lorg/mortbay/util/Attributes;"));
                code.visitLabel(L13);
                code.visitFieldStmt(IGET_OBJECT,10,12,new Field("Lorg/mortbay/jetty/Request;","_attributes","Lorg/mortbay/util/Attributes;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 10,13,14},new Method("Lorg/mortbay/util/Attributes;","setAttribute",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L14);
                code.visitFieldStmt(IGET_OBJECT,10,12,new Field("Lorg/mortbay/jetty/Request;","_requestAttributeListeners","Ljava/lang/Object;"));
                code.visitJumpStmt(IF_EQZ,10,-1,L37);
                code.visitLabel(L15);
                code.visitTypeStmt(NEW_INSTANCE,4,-1,"Ljavax/servlet/ServletRequestAttributeEvent;");
                code.visitFieldStmt(IGET_OBJECT,10,12,new Field("Lorg/mortbay/jetty/Request;","_context","Lorg/mortbay/jetty/handler/ContextHandler$SContext;"));
                code.visitJumpStmt(IF_NEZ,8,-1,L32);
                code.visitStmt2R(MOVE_OBJECT,11,14);
                DexLabel L39=new DexLabel();
                code.visitLabel(L39);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4,10,12,13,11},new Method("Ljavax/servlet/ServletRequestAttributeEvent;","<init>",new String[]{ "Ljavax/servlet/ServletContext;","Ljavax/servlet/ServletRequest;","Ljava/lang/String;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L16);
                code.visitFieldStmt(IGET_OBJECT,10,12,new Field("Lorg/mortbay/jetty/Request;","_requestAttributeListeners","Ljava/lang/Object;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 10},new Method("Lorg/mortbay/util/LazyList;","size",new String[]{ "Ljava/lang/Object;"},"I"));
                code.visitStmt1R(MOVE_RESULT,9);
                code.visitLabel(L17);
                code.visitConstStmt(CONST_4,5, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L18);
                code.visitJumpStmt(IF_GE,5,9,L37);
                code.visitLabel(L19);
                code.visitFieldStmt(IGET_OBJECT,10,12,new Field("Lorg/mortbay/jetty/Request;","_requestAttributeListeners","Ljava/lang/Object;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 10,5},new Method("Lorg/mortbay/util/LazyList;","get",new String[]{ "Ljava/lang/Object;","I"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitTypeStmt(CHECK_CAST,7,-1,"Ljavax/servlet/ServletRequestAttributeListener;");
                code.visitLabel(L20);
                code.visitTypeStmt(INSTANCE_OF,10,7,"Ljavax/servlet/ServletRequestAttributeListener;");
                code.visitJumpStmt(IF_EQZ,10,-1,L24);
                code.visitLabel(L21);
                code.visitStmt2R(MOVE_OBJECT,0,7);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Ljavax/servlet/ServletRequestAttributeListener;");
                code.visitStmt2R(MOVE_OBJECT,6,0);
                code.visitLabel(L22);
                code.visitJumpStmt(IF_NEZ,8,-1,L34);
                code.visitLabel(L23);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 6,4},new Method("Ljavax/servlet/ServletRequestAttributeListener;","attributeAdded",new String[]{ "Ljavax/servlet/ServletRequestAttributeEvent;"},"V"));
                code.visitLabel(L24);
                code.visitStmt2R1N(ADD_INT_LIT8,5,5,1);
                code.visitJumpStmt(GOTO,-1,-1,L18);
                code.visitLabel(L25);
                code.visitFieldStmt(IGET_OBJECT,10,12,new Field("Lorg/mortbay/jetty/Request;","_attributes","Lorg/mortbay/util/Attributes;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 10,13},new Method("Lorg/mortbay/util/Attributes;","getAttribute",new String[]{ "Ljava/lang/String;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,10);
                code.visitStmt2R(MOVE_OBJECT,8,10);
                code.visitJumpStmt(GOTO,-1,-1,L9);
                code.visitLabel(L26);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 14},new Method("Ljava/lang/Object;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,10);
                code.visitJumpStmt(GOTO,-1,-1,L38);
                code.visitLabel(L27);
                code.visitConstStmt(CONST_STRING,10,"org.mortbay.jetty.ResponseBuffer");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10,13},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,10);
                code.visitJumpStmt(IF_EQZ,10,-1,L11);
                code.visitLabel(L0);
                code.visitStmt2R(MOVE_OBJECT,0,14);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Ljava/nio/ByteBuffer;");
                code.visitStmt2R(MOVE_OBJECT,2,0);
                code.visitLabel(L28);
                code.visitStmt1R(MONITOR_ENTER,2);
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/nio/ByteBuffer;","isDirect",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,10);
                code.visitJumpStmt(IF_EQZ,10,-1,L5);
                code.visitTypeStmt(NEW_INSTANCE,10,-1,"Lorg/mortbay/io/nio/DirectNIOBuffer;");
                code.visitConstStmt(CONST_4,11, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 10,2,11},new Method("Lorg/mortbay/io/nio/DirectNIOBuffer;","<init>",new String[]{ "Ljava/nio/ByteBuffer;","Z"},"V"));
                code.visitStmt2R(MOVE_OBJECT,1,10);
                code.visitLabel(L29);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12},new Method("Lorg/mortbay/jetty/Request;","getServletResponse",new String[]{ },"Ljavax/servlet/ServletResponse;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,10);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 10},new Method("Ljavax/servlet/ServletResponse;","getOutputStream",new String[]{ },"Ljavax/servlet/ServletOutputStream;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,10);
                code.visitTypeStmt(CHECK_CAST,10,-1,"Lorg/mortbay/jetty/HttpConnection$Output;");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10,1},new Method("Lorg/mortbay/jetty/HttpConnection$Output;","sendResponse",new String[]{ "Lorg/mortbay/io/Buffer;"},"V"));
                code.visitLabel(L30);
                code.visitStmt1R(MONITOR_EXIT,2);
                code.visitJumpStmt(GOTO,-1,-1,L11);
                code.visitLabel(L4);
                code.visitStmt1R(MOVE_EXCEPTION,10);
                code.visitStmt1R(MONITOR_EXIT,2);
                code.visitLabel(L3);
                code.visitStmt1R(THROW,10);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,10);
                code.visitStmt2R(MOVE_OBJECT,3,10);
                code.visitLabel(L31);
                code.visitTypeStmt(NEW_INSTANCE,10,-1,"Ljava/lang/RuntimeException;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 10,3},new Method("Ljava/lang/RuntimeException;","<init>",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitStmt1R(THROW,10);
                code.visitLabel(L5);
                code.visitTypeStmt(NEW_INSTANCE,10,-1,"Lorg/mortbay/io/nio/IndirectNIOBuffer;");
                code.visitConstStmt(CONST_4,11, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 10,2,11},new Method("Lorg/mortbay/io/nio/IndirectNIOBuffer;","<init>",new String[]{ "Ljava/nio/ByteBuffer;","Z"},"V"));
                code.visitLabel(L6);
                code.visitStmt2R(MOVE_OBJECT,1,10);
                code.visitJumpStmt(GOTO,-1,-1,L29);
                code.visitLabel(L32);
                code.visitStmt2R(MOVE_OBJECT,11,8);
                code.visitLabel(L33);
                code.visitJumpStmt(GOTO,-1,-1,L39);
                code.visitLabel(L34);
                code.visitJumpStmt(IF_NEZ,14,-1,L36);
                code.visitLabel(L35);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 6,4},new Method("Ljavax/servlet/ServletRequestAttributeListener;","attributeRemoved",new String[]{ "Ljavax/servlet/ServletRequestAttributeEvent;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L24);
                code.visitLabel(L36);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 6,4},new Method("Ljavax/servlet/ServletRequestAttributeListener;","attributeReplaced",new String[]{ "Ljavax/servlet/ServletRequestAttributeEvent;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L24);
                code.visitLabel(L37);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m083_setAttributes(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Request;","setAttributes",new String[]{ "Lorg/mortbay/util/Attributes;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"attributes");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1802,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(1803,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/Request;","_attributes","Lorg/mortbay/util/Attributes;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m084_setAuthType(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Request;","setAuthType",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"authType");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1589,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(1590,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/Request;","_authType","Ljava/lang/String;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m085_setCharacterEncoding(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Request;","setCharacterEncoding",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/UnsupportedEncodingException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"encoding");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1387,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(1395,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(1390,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(1393,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(1394,L4);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,1,new Field("Lorg/mortbay/jetty/Request;","_inputState","I"));
                code.visitJumpStmt(IF_EQZ,0,-1,L2);
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitFieldStmt(IPUT_OBJECT,2,1,new Field("Lorg/mortbay/jetty/Request;","_characterEncoding","Ljava/lang/String;"));
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2},new Method("Lorg/mortbay/util/StringUtil;","isUTF8",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_NEZ,0,-1,L1);
                code.visitLabel(L4);
                code.visitConstStmt(CONST_STRING,0,"");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,2},new Method("Ljava/lang/String;","getBytes",new String[]{ "Ljava/lang/String;"},"[B"));
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m086_setCharacterEncodingUnchecked(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Request;","setCharacterEncodingUnchecked",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"encoding");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1403,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(1404,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/Request;","_characterEncoding","Ljava/lang/String;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m087_setConnection(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/Request;","setConnection",new String[]{ "Lorg/mortbay/jetty/HttpConnection;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"connection");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(183,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(184,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(185,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(186,L3);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,2,1,new Field("Lorg/mortbay/jetty/Request;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/HttpConnection;","getEndPoint",new String[]{ },"Lorg/mortbay/io/EndPoint;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/Request;","_endp","Lorg/mortbay/io/EndPoint;"));
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/HttpConnection;","getResolveNames",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitFieldStmt(IPUT_BOOLEAN,0,1,new Field("Lorg/mortbay/jetty/Request;","_dns","Z"));
                code.visitLabel(L3);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m088_setContentType(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Request;","setContentType",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"contentType");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(348,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(350,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/Request;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/HttpConnection;","getRequestFields",new String[]{ },"Lorg/mortbay/jetty/HttpFields;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(SGET_OBJECT,1,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","CONTENT_TYPE_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,3},new Method("Lorg/mortbay/jetty/HttpFields;","put",new String[]{ "Lorg/mortbay/io/Buffer;","Ljava/lang/String;"},"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m089_setContext(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Request;","setContext",new String[]{ "Lorg/mortbay/jetty/handler/ContextHandler$SContext;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"context");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1741,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(1742,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/Request;","_context","Lorg/mortbay/jetty/handler/ContextHandler$SContext;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m090_setContextPath(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Request;","setContextPath",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"contextPath");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1705,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(1706,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/Request;","_contextPath","Ljava/lang/String;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m091_setContinuation(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(0, new Method("Lorg/mortbay/jetty/Request;","setContinuation",new String[]{ "Lorg/mortbay/util/ajax/Continuation;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"cont");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1822,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(1823,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/Request;","_continuation","Lorg/mortbay/util/ajax/Continuation;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m092_setCookies(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Request;","setCookies",new String[]{ "[Ljavax/servlet/http/Cookie;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"cookies");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1598,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(1599,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/Request;","_cookies","[Ljavax/servlet/http/Cookie;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m093_setHandled(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Request;","setHandled",new String[]{ "Z"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"h");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(269,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(270,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_BOOLEAN,1,0,new Field("Lorg/mortbay/jetty/Request;","_handled","Z"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m094_setMethod(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Request;","setMethod",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"method");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1607,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(1608,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/Request;","_method","Ljava/lang/String;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m095_setParameters(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Request;","setParameters",new String[]{ "Lorg/mortbay/util/MultiMap;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"parameters");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1840,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(1841,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(1842,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(1840,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(1843,L4);
                code.visitLabel(L0);
                DexLabel L5=new DexLabel();
                code.visitJumpStmt(IF_NEZ,2,-1,L5);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/Request;","_baseParameters","Lorg/mortbay/util/MultiMap;"));
                DexLabel L6=new DexLabel();
                code.visitLabel(L6);
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/Request;","_parameters","Lorg/mortbay/util/MultiMap;"));
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_BOOLEAN,0,1,new Field("Lorg/mortbay/jetty/Request;","_paramsExtracted","Z"));
                code.visitJumpStmt(IF_EQZ,0,-1,L4);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/Request;","_parameters","Lorg/mortbay/util/MultiMap;"));
                code.visitJumpStmt(IF_NEZ,0,-1,L4);
                code.visitLabel(L2);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/IllegalStateException;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/IllegalStateException;","<init>",new String[]{ },"V"));
                code.visitStmt1R(THROW,0);
                code.visitLabel(L5);
                code.visitStmt2R(MOVE_OBJECT,0,2);
                code.visitLabel(L3);
                code.visitJumpStmt(GOTO,-1,-1,L6);
                code.visitLabel(L4);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m096_setPathInfo(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Request;","setPathInfo",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"pathInfo");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1616,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(1617,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/Request;","_pathInfo","Ljava/lang/String;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m097_setProtocol(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Request;","setProtocol",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"protocol");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1625,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(1626,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/Request;","_protocol","Ljava/lang/String;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m098_setQueryEncoding(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Request;","setQueryEncoding",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"queryEncoding");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1951,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(1952,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(1953,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,2,1,new Field("Lorg/mortbay/jetty/Request;","_queryEncoding","Ljava/lang/String;"));
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/Request;","_queryString","Ljava/lang/String;"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m099_setQueryString(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Request;","setQueryString",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"queryString");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1688,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(1689,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/Request;","_queryString","Ljava/lang/String;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m100_setRemoteAddr(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Request;","setRemoteAddr",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"addr");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1535,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(1536,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/Request;","_remoteAddr","Ljava/lang/String;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m101_setRemoteHost(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Request;","setRemoteHost",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"host");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1544,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(1545,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/Request;","_remoteHost","Ljava/lang/String;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m102_setRequestListeners(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Request;","setRequestListeners",new String[]{ "Ljava/lang/Object;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"requestListeners");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1886,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(1887,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/Request;","_requestListeners","Ljava/lang/Object;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m103_setRequestURI(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Request;","setRequestURI",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"requestURI");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1696,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(1697,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/Request;","_requestURI","Ljava/lang/String;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m104_setRequestedSessionId(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Request;","setRequestedSessionId",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"requestedSessionId");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1634,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(1635,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/Request;","_requestedSessionId","Ljava/lang/String;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m105_setRequestedSessionIdFromCookie(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Request;","setRequestedSessionIdFromCookie",new String[]{ "Z"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"requestedSessionIdCookie");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1661,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(1662,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_BOOLEAN,1,0,new Field("Lorg/mortbay/jetty/Request;","_requestedSessionIdFromCookie","Z"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m106_setRoleMap(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Request;","setRoleMap",new String[]{ "Ljava/util/Map;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"map");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1958,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(1959,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/Request;","_roleMap","Ljava/util/Map;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m107_setScheme(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Request;","setScheme",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"scheme");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1679,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(1680,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/Request;","_scheme","Ljava/lang/String;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m108_setServerName(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Request;","setServerName",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"host");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1517,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(1518,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/Request;","_serverName","Ljava/lang/String;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m109_setServerPort(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Request;","setServerPort",new String[]{ "I"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"port");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1526,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(1527,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT,1,0,new Field("Lorg/mortbay/jetty/Request;","_port","I"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m110_setServletName(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Request;","setServletName",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1723,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(1724,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/Request;","_servletName","Ljava/lang/String;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m111_setServletPath(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Request;","setServletPath",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"servletPath");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1714,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(1715,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/Request;","_servletPath","Ljava/lang/String;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m112_setSession(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Request;","setSession",new String[]{ "Ljavax/servlet/http/HttpSession;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"session");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1670,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(1671,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/Request;","_session","Ljavax/servlet/http/HttpSession;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m113_setSessionManager(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Request;","setSessionManager",new String[]{ "Lorg/mortbay/jetty/SessionManager;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"sessionManager");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1652,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(1653,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/Request;","_sessionManager","Lorg/mortbay/jetty/SessionManager;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m114_setTimeStamp(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Request;","setTimeStamp",new String[]{ "J"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"ts");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(257,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(258,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_WIDE,1,0,new Field("Lorg/mortbay/jetty/Request;","_timeStamp","J"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m115_setUri(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Request;","setUri",new String[]{ "Lorg/mortbay/jetty/HttpURI;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"uri");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1562,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(1563,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/Request;","_uri","Lorg/mortbay/jetty/HttpURI;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m116_setUserPrincipal(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Request;","setUserPrincipal",new String[]{ "Ljava/security/Principal;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"userPrincipal");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1732,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(1733,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/Request;","_userPrincipal","Ljava/security/Principal;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m117_setUserRealm(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Request;","setUserRealm",new String[]{ "Lorg/mortbay/jetty/security/UserRealm;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"userRealm");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1930,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(1931,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/Request;","_userRealm","Lorg/mortbay/jetty/security/UserRealm;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m118_takeRequestListeners(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Request;","takeRequestListeners",new String[]{ },"Ljava/lang/Object;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1895,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(1896,L1);
                ddv.visitStartLocal(0,L1,"listeners","Ljava/lang/Object;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(1897,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/Request;","_requestListeners","Ljava/lang/Object;"));
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_OBJECT,1,2,new Field("Lorg/mortbay/jetty/Request;","_requestListeners","Ljava/lang/Object;"));
                code.visitLabel(L2);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m119_toString(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Request;","toString",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(1848,L1);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_STRING,2," ");
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/jetty/Request;","getMethod",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitConstStmt(CONST_STRING,1," ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/jetty/Request;","_uri","Lorg/mortbay/jetty/HttpURI;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitConstStmt(CONST_STRING,1," ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/jetty/Request;","getProtocol",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitConstStmt(CONST_STRING,1,"\n");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/jetty/Request;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/jetty/HttpConnection;","getRequestFields",new String[]{ },"Lorg/mortbay/jetty/HttpFields;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/jetty/HttpFields;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
