package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0302_org_mortbay_jetty_security_ServletSSL {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/jetty/security/ServletSSL;","Ljava/lang/Object;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("ServletSSL.java");
        m000__init_(cv);
        m001_deduceKeyLength(cv);
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/security/ServletSSL;","<init>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(29,L0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/Object;","<init>",new String[]{ },"V"));
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001_deduceKeyLength(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Method("Lorg/mortbay/jetty/security/ServletSSL;","deduceKeyLength",new String[]{ "Ljava/lang/String;"},"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"cipherSuite");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(61,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(82,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(63,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(64,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(65,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(66,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(67,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(68,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(69,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(70,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(71,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(72,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(73,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(74,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(75,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(76,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(77,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(78,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(79,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(80,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(82,L21);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitConstStmt(CONST_16,2, Integer.valueOf(128)); // int: 0x00000080  float:0.000000
                code.visitConstStmt(CONST_16,1, Integer.valueOf(40)); // int: 0x00000028  float:0.000000
                code.visitLabel(L1);
                code.visitJumpStmt(IF_NEZ,4,-1,L3);
                code.visitStmt2R(MOVE,0,3);
                code.visitLabel(L2);
                code.visitStmt1R(RETURN,0);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_STRING,0,"WITH_AES_256_");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,0},new Method("Ljava/lang/String;","indexOf",new String[]{ "Ljava/lang/String;"},"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_LTZ,0,-1,L5);
                code.visitLabel(L4);
                code.visitConstStmt(CONST_16,0, Integer.valueOf(256)); // int: 0x00000100  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L5);
                code.visitConstStmt(CONST_STRING,0,"WITH_RC4_128_");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,0},new Method("Ljava/lang/String;","indexOf",new String[]{ "Ljava/lang/String;"},"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_LTZ,0,-1,L7);
                code.visitStmt2R(MOVE,0,2);
                code.visitLabel(L6);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L7);
                code.visitConstStmt(CONST_STRING,0,"WITH_AES_128_");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,0},new Method("Ljava/lang/String;","indexOf",new String[]{ "Ljava/lang/String;"},"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_LTZ,0,-1,L9);
                code.visitStmt2R(MOVE,0,2);
                code.visitLabel(L8);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L9);
                code.visitConstStmt(CONST_STRING,0,"WITH_RC4_40_");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,0},new Method("Ljava/lang/String;","indexOf",new String[]{ "Ljava/lang/String;"},"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_LTZ,0,-1,L11);
                code.visitStmt2R(MOVE,0,1);
                code.visitLabel(L10);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L11);
                code.visitConstStmt(CONST_STRING,0,"WITH_3DES_EDE_CBC_");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,0},new Method("Ljava/lang/String;","indexOf",new String[]{ "Ljava/lang/String;"},"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_LTZ,0,-1,L13);
                code.visitLabel(L12);
                code.visitConstStmt(CONST_16,0, Integer.valueOf(168)); // int: 0x000000a8  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L13);
                code.visitConstStmt(CONST_STRING,0,"WITH_IDEA_CBC_");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,0},new Method("Ljava/lang/String;","indexOf",new String[]{ "Ljava/lang/String;"},"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_LTZ,0,-1,L15);
                code.visitStmt2R(MOVE,0,2);
                code.visitLabel(L14);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L15);
                code.visitConstStmt(CONST_STRING,0,"WITH_RC2_CBC_40_");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,0},new Method("Ljava/lang/String;","indexOf",new String[]{ "Ljava/lang/String;"},"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_LTZ,0,-1,L17);
                code.visitStmt2R(MOVE,0,1);
                code.visitLabel(L16);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L17);
                code.visitConstStmt(CONST_STRING,0,"WITH_DES40_CBC_");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,0},new Method("Ljava/lang/String;","indexOf",new String[]{ "Ljava/lang/String;"},"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_LTZ,0,-1,L19);
                code.visitStmt2R(MOVE,0,1);
                code.visitLabel(L18);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L19);
                code.visitConstStmt(CONST_STRING,0,"WITH_DES_CBC_");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,0},new Method("Ljava/lang/String;","indexOf",new String[]{ "Ljava/lang/String;"},"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                DexLabel L22=new DexLabel();
                code.visitJumpStmt(IF_LTZ,0,-1,L22);
                code.visitLabel(L20);
                code.visitConstStmt(CONST_16,0, Integer.valueOf(56)); // int: 0x00000038  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L22);
                code.visitStmt2R(MOVE,0,3);
                code.visitLabel(L21);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
