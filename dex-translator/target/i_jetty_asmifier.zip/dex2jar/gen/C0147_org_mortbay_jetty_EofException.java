package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0147_org_mortbay_jetty_EofException {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/jetty/EofException;","Ljava/io/EOFException;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("EofException.java");
        m000__init_(cv);
        m001__init_(cv);
        m002__init_(cv);
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/EofException;","<init>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(22,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(23,L1);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/io/EOFException;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/EofException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"reason");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(27,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(28,L1);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Ljava/io/EOFException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/EofException;","<init>",new String[]{ "Ljava/lang/Throwable;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"th");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(31,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(32,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(33,L2);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/io/EOFException;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/EofException;","initCause",new String[]{ "Ljava/lang/Throwable;"},"Ljava/lang/Throwable;"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
