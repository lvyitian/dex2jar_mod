package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0026_javax_servlet_http_HttpServlet {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC|ACC_ABSTRACT,"Ljavax/servlet/http/HttpServlet;","Ljavax/servlet/GenericServlet;",new String[]{ "Ljava/io/Serializable;"});
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("HttpServlet.java");
        f000_HEADER_IFMODSINCE(cv);
        f001_HEADER_LASTMOD(cv);
        f002_LSTRING_FILE(cv);
        f003_METHOD_DELETE(cv);
        f004_METHOD_GET(cv);
        f005_METHOD_HEAD(cv);
        f006_METHOD_OPTIONS(cv);
        f007_METHOD_POST(cv);
        f008_METHOD_PUT(cv);
        f009_METHOD_TRACE(cv);
        f010_lStrings(cv);
        m000__clinit_(cv);
        m001__init_(cv);
        m002_getAllDeclaredMethods(cv);
        m003_maybeSetLastModified(cv);
        m004_doDelete(cv);
        m005_doGet(cv);
        m006_doHead(cv);
        m007_doOptions(cv);
        m008_doPost(cv);
        m009_doPut(cv);
        m010_doTrace(cv);
        m011_getLastModified(cv);
        m012_service(cv);
        m013_service(cv);
    }
    public static void f000_HEADER_IFMODSINCE(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC|ACC_FINAL, new Field("Ljavax/servlet/http/HttpServlet;","HEADER_IFMODSINCE","Ljava/lang/String;"), "If-Modified-Since");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001_HEADER_LASTMOD(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC|ACC_FINAL, new Field("Ljavax/servlet/http/HttpServlet;","HEADER_LASTMOD","Ljava/lang/String;"), "Last-Modified");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002_LSTRING_FILE(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC|ACC_FINAL, new Field("Ljavax/servlet/http/HttpServlet;","LSTRING_FILE","Ljava/lang/String;"), "/javax/servlet/http/LocalStrings.properties");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003_METHOD_DELETE(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC|ACC_FINAL, new Field("Ljavax/servlet/http/HttpServlet;","METHOD_DELETE","Ljava/lang/String;"), "DELETE");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f004_METHOD_GET(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC|ACC_FINAL, new Field("Ljavax/servlet/http/HttpServlet;","METHOD_GET","Ljava/lang/String;"), "GET");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f005_METHOD_HEAD(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC|ACC_FINAL, new Field("Ljavax/servlet/http/HttpServlet;","METHOD_HEAD","Ljava/lang/String;"), "HEAD");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f006_METHOD_OPTIONS(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC|ACC_FINAL, new Field("Ljavax/servlet/http/HttpServlet;","METHOD_OPTIONS","Ljava/lang/String;"), "OPTIONS");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f007_METHOD_POST(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC|ACC_FINAL, new Field("Ljavax/servlet/http/HttpServlet;","METHOD_POST","Ljava/lang/String;"), "POST");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f008_METHOD_PUT(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC|ACC_FINAL, new Field("Ljavax/servlet/http/HttpServlet;","METHOD_PUT","Ljava/lang/String;"), "PUT");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f009_METHOD_TRACE(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC|ACC_FINAL, new Field("Ljavax/servlet/http/HttpServlet;","METHOD_TRACE","Ljava/lang/String;"), "TRACE");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f010_lStrings(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC, new Field("Ljavax/servlet/http/HttpServlet;","lStrings","Ljava/util/ResourceBundle;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__clinit_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_CONSTRUCTOR, new Method("Ljavax/servlet/http/HttpServlet;","<clinit>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/lang/Exception;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(115,L0);
                ddv.visitLineNumber(121,L1);
                ddv.visitLineNumber(117,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(119,L3);
                ddv.visitStartLocal(0,L3,"e","Ljava/lang/Exception;",null);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/util/PropertyResourceBundle;");
                code.visitConstStmt(CONST_CLASS,2,new DexType("Ljavax/servlet/http/HttpServlet;"));
                code.visitConstStmt(CONST_STRING,3,"/javax/servlet/http/LocalStrings.properties");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/Class;","getResourceAsStream",new String[]{ "Ljava/lang/String;"},"Ljava/io/InputStream;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,2},new Method("Ljava/util/PropertyResourceBundle;","<init>",new String[]{ "Ljava/io/InputStream;"},"V"));
                code.visitFieldStmt(SPUT_OBJECT,1,-1,new Field("Ljavax/servlet/http/HttpServlet;","lStrings","Ljava/util/ResourceBundle;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitStmt2R(MOVE_OBJECT,0,1);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/Exception;","printStackTrace",new String[]{ },"V"));
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Ljavax/servlet/http/HttpServlet;","<init>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(131,L0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljavax/servlet/GenericServlet;","<init>",new String[]{ },"V"));
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_getAllDeclaredMethods(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PRIVATE, new Method("Ljavax/servlet/http/HttpServlet;","getAllDeclaredMethods",new String[]{ "Ljava/lang/Class;"},"[Ljava/lang/reflect/Method;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(8);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"c");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(496,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(497,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(514,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(500,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(501,L5);
                ddv.visitStartLocal(1,L5,"parentMethods","[Ljava/lang/reflect/Method;",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(503,L6);
                ddv.visitStartLocal(2,L6,"thisMethods","[Ljava/lang/reflect/Method;",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(504,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(506,L8);
                ddv.visitStartLocal(0,L8,"allMethods","[Ljava/lang/reflect/Method;",null);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(508,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(511,L10);
                DexLabel L11=new DexLabel();
                ddv.visitEndLocal(0,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(514,L12);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,5, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitConstStmt(CONST_CLASS,3,new DexType("Ljavax/servlet/http/HttpServlet;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,3},new Method("Ljava/lang/Object;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_EQZ,3,-1,L4);
                code.visitLabel(L2);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L3);
                code.visitStmt1R(RETURN_OBJECT,3);
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Ljava/lang/Class;","getSuperclass",new String[]{ },"Ljava/lang/Class;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 6,3},new Method("Ljavax/servlet/http/HttpServlet;","getAllDeclaredMethods",new String[]{ "Ljava/lang/Class;"},"[Ljava/lang/reflect/Method;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Ljava/lang/Class;","getDeclaredMethods",new String[]{ },"[Ljava/lang/reflect/Method;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L6);
                code.visitJumpStmt(IF_EQZ,1,-1,L11);
                code.visitStmt2R(ARRAY_LENGTH,3,1);
                code.visitJumpStmt(IF_LEZ,3,-1,L11);
                code.visitLabel(L7);
                code.visitStmt2R(ARRAY_LENGTH,3,1);
                code.visitStmt2R(ARRAY_LENGTH,4,2);
                code.visitStmt2R(ADD_INT_2ADDR,3,4);
                code.visitTypeStmt(NEW_ARRAY,0,3,"[Ljava/lang/reflect/Method;");
                code.visitLabel(L8);
                code.visitStmt2R(ARRAY_LENGTH,3,1);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1,5,0,5,3},new Method("Ljava/lang/System;","arraycopy",new String[]{ "Ljava/lang/Object;","I","Ljava/lang/Object;","I","I"},"V"));
                code.visitLabel(L9);
                code.visitStmt2R(ARRAY_LENGTH,3,1);
                code.visitStmt2R(ARRAY_LENGTH,4,2);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2,5,0,3,4},new Method("Ljava/lang/System;","arraycopy",new String[]{ "Ljava/lang/Object;","I","Ljava/lang/Object;","I","I"},"V"));
                code.visitLabel(L10);
                code.visitStmt2R(MOVE_OBJECT,2,0);
                code.visitLabel(L11);
                code.visitStmt2R(MOVE_OBJECT,3,2);
                code.visitLabel(L12);
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_maybeSetLastModified(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PRIVATE, new Method("Ljavax/servlet/http/HttpServlet;","maybeSetLastModified",new String[]{ "Ljavax/servlet/http/HttpServletResponse;","J"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"resp");
                ddv.visitParameterName(1,"lastModified");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(782,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(786,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(784,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(785,L4);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_STRING,2,"Last-Modified");
                code.visitLabel(L1);
                code.visitConstStmt(CONST_STRING,0,"Last-Modified");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 4,2},new Method("Ljavax/servlet/http/HttpServletResponse;","containsHeader",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L3);
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_WIDE_16,0,Long.valueOf(0L)); // long: 0x0000000000000000  double:0.000000
                code.visitStmt3R(CMP_LONG,0,5,0);
                code.visitJumpStmt(IF_LTZ,0,-1,L2);
                code.visitLabel(L4);
                code.visitConstStmt(CONST_STRING,0,"Last-Modified");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 4,2,5,6},new Method("Ljavax/servlet/http/HttpServletResponse;","setDateHeader",new String[]{ "Ljava/lang/String;","J"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_doDelete(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Ljavax/servlet/http/HttpServlet;","doDelete",new String[]{ "Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljavax/servlet/ServletException;"));
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"req");
                ddv.visitParameterName(1,"resp");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(481,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(482,L1);
                ddv.visitStartLocal(1,L1,"protocol","Ljava/lang/String;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(483,L2);
                ddv.visitStartLocal(0,L2,"msg","Ljava/lang/String;",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(484,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(488,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(486,L5);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 5},new Method("Ljavax/servlet/http/HttpServletRequest;","getProtocol",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L1);
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Ljavax/servlet/http/HttpServlet;","lStrings","Ljava/util/ResourceBundle;"));
                code.visitConstStmt(CONST_STRING,3,"http.method_delete_not_supported");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/util/ResourceBundle;","getString",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L2);
                code.visitConstStmt(CONST_STRING,2,"1.1");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/lang/String;","endsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_EQZ,2,-1,L5);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_16,2, Integer.valueOf(405)); // int: 0x00000195  float:0.000000
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 6,2,0},new Method("Ljavax/servlet/http/HttpServletResponse;","sendError",new String[]{ "I","Ljava/lang/String;"},"V"));
                code.visitLabel(L4);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L5);
                code.visitConstStmt(CONST_16,2, Integer.valueOf(400)); // int: 0x00000190  float:0.000000
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 6,2,0},new Method("Ljavax/servlet/http/HttpServletResponse;","sendError",new String[]{ "I","Ljava/lang/String;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_doGet(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Ljavax/servlet/http/HttpServlet;","doGet",new String[]{ "Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljavax/servlet/ServletException;"));
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"req");
                ddv.visitParameterName(1,"resp");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(207,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(208,L1);
                ddv.visitStartLocal(1,L1,"protocol","Ljava/lang/String;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(209,L2);
                ddv.visitStartLocal(0,L2,"msg","Ljava/lang/String;",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(210,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(214,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(212,L5);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 5},new Method("Ljavax/servlet/http/HttpServletRequest;","getProtocol",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L1);
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Ljavax/servlet/http/HttpServlet;","lStrings","Ljava/util/ResourceBundle;"));
                code.visitConstStmt(CONST_STRING,3,"http.method_get_not_supported");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/util/ResourceBundle;","getString",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L2);
                code.visitConstStmt(CONST_STRING,2,"1.1");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/lang/String;","endsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_EQZ,2,-1,L5);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_16,2, Integer.valueOf(405)); // int: 0x00000195  float:0.000000
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 6,2,0},new Method("Ljavax/servlet/http/HttpServletResponse;","sendError",new String[]{ "I","Ljava/lang/String;"},"V"));
                code.visitLabel(L4);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L5);
                code.visitConstStmt(CONST_16,2, Integer.valueOf(400)); // int: 0x00000190  float:0.000000
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 6,2,0},new Method("Ljavax/servlet/http/HttpServletResponse;","sendError",new String[]{ "I","Ljava/lang/String;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_doHead(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Ljavax/servlet/http/HttpServlet;","doHead",new String[]{ "Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljavax/servlet/ServletException;"));
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"req");
                ddv.visitParameterName(1,"resp");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(291,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(293,L1);
                ddv.visitStartLocal(0,L1,"response","Ljavax/servlet/http/NoBodyResponse;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(294,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(295,L3);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljavax/servlet/http/NoBodyResponse;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,3},new Method("Ljavax/servlet/http/NoBodyResponse;","<init>",new String[]{ "Ljavax/servlet/http/HttpServletResponse;"},"V"));
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2,0},new Method("Ljavax/servlet/http/HttpServlet;","doGet",new String[]{ "Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;"},"V"));
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljavax/servlet/http/NoBodyResponse;","setContentLength",new String[]{ },"V"));
                code.visitLabel(L3);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m007_doOptions(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Ljavax/servlet/http/HttpServlet;","doOptions",new String[]{ "Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljavax/servlet/ServletException;"));
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(16);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"req");
                ddv.visitParameterName(1,"resp");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(560,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(562,L1);
                ddv.visitStartLocal(10,L1,"methods","[Ljava/lang/reflect/Method;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(563,L2);
                ddv.visitStartLocal(1,L2,"ALLOW_GET","Z",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(564,L3);
                ddv.visitStartLocal(2,L3,"ALLOW_HEAD","Z",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(565,L4);
                ddv.visitStartLocal(4,L4,"ALLOW_POST","Z",null);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(566,L5);
                ddv.visitStartLocal(5,L5,"ALLOW_PUT","Z",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(567,L6);
                ddv.visitStartLocal(0,L6,"ALLOW_DELETE","Z",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(568,L7);
                ddv.visitStartLocal(6,L7,"ALLOW_TRACE","Z",null);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(570,L8);
                ddv.visitStartLocal(3,L8,"ALLOW_OPTIONS","Z",null);
                DexLabel L9=new DexLabel();
                ddv.visitStartLocal(8,L9,"i","I",null);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(571,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(573,L11);
                ddv.visitStartLocal(9,L11,"m","Ljava/lang/reflect/Method;",null);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(574,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(575,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(577,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(578,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(579,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(580,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(581,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(582,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(570,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(586,L21);
                ddv.visitEndLocal(9,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(587,L22);
                ddv.visitStartLocal(7,L22,"allow","Ljava/lang/String;",null);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(588,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(589,L24);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(590,L25);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(592,L26);
                ddv.visitRestartLocal(7,L26);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(593,L27);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(595,L28);
                ddv.visitRestartLocal(7,L28);
                DexLabel L29=new DexLabel();
                ddv.visitLineNumber(596,L29);
                DexLabel L30=new DexLabel();
                ddv.visitLineNumber(598,L30);
                ddv.visitRestartLocal(7,L30);
                DexLabel L31=new DexLabel();
                ddv.visitLineNumber(599,L31);
                DexLabel L32=new DexLabel();
                ddv.visitLineNumber(601,L32);
                ddv.visitRestartLocal(7,L32);
                DexLabel L33=new DexLabel();
                ddv.visitLineNumber(602,L33);
                DexLabel L34=new DexLabel();
                ddv.visitLineNumber(604,L34);
                ddv.visitRestartLocal(7,L34);
                DexLabel L35=new DexLabel();
                ddv.visitLineNumber(605,L35);
                DexLabel L36=new DexLabel();
                ddv.visitLineNumber(608,L36);
                ddv.visitRestartLocal(7,L36);
                DexLabel L37=new DexLabel();
                ddv.visitLineNumber(609,L37);
                DexLabel L38=new DexLabel();
                ddv.visitLineNumber(591,L38);
                DexLabel L39=new DexLabel();
                ddv.visitRestartLocal(7,L39);
                DexLabel L40=new DexLabel();
                ddv.visitLineNumber(594,L40);
                DexLabel L41=new DexLabel();
                ddv.visitRestartLocal(7,L41);
                DexLabel L42=new DexLabel();
                ddv.visitLineNumber(597,L42);
                DexLabel L43=new DexLabel();
                ddv.visitRestartLocal(7,L43);
                DexLabel L44=new DexLabel();
                ddv.visitLineNumber(600,L44);
                DexLabel L45=new DexLabel();
                ddv.visitRestartLocal(7,L45);
                DexLabel L46=new DexLabel();
                ddv.visitLineNumber(603,L46);
                DexLabel L47=new DexLabel();
                ddv.visitRestartLocal(7,L47);
                DexLabel L48=new DexLabel();
                ddv.visitLineNumber(606,L48);
                DexLabel L49=new DexLabel();
                ddv.visitRestartLocal(7,L49);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13},new Method("Ljava/lang/Object;","getClass",new String[]{ },"Ljava/lang/Class;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,11);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 13,11},new Method("Ljavax/servlet/http/HttpServlet;","getAllDeclaredMethods",new String[]{ "Ljava/lang/Class;"},"[Ljava/lang/reflect/Method;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,10);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L2);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L4);
                code.visitConstStmt(CONST_4,5, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L5);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L6);
                code.visitConstStmt(CONST_4,6, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L7);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L8);
                code.visitConstStmt(CONST_4,8, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L9);
                code.visitStmt2R(ARRAY_LENGTH,11,10);
                code.visitJumpStmt(IF_GE,8,11,L21);
                code.visitLabel(L10);
                code.visitStmt3R(AGET_OBJECT,9,10,8);
                code.visitLabel(L11);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9},new Method("Ljava/lang/reflect/Method;","getName",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,11);
                code.visitConstStmt(CONST_STRING,12,"doGet");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11,12},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,11);
                code.visitJumpStmt(IF_EQZ,11,-1,L14);
                code.visitLabel(L12);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L13);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L14);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9},new Method("Ljava/lang/reflect/Method;","getName",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,11);
                code.visitConstStmt(CONST_STRING,12,"doPost");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11,12},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,11);
                code.visitJumpStmt(IF_EQZ,11,-1,L16);
                code.visitLabel(L15);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L16);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9},new Method("Ljava/lang/reflect/Method;","getName",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,11);
                code.visitConstStmt(CONST_STRING,12,"doPut");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11,12},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,11);
                code.visitJumpStmt(IF_EQZ,11,-1,L18);
                code.visitLabel(L17);
                code.visitConstStmt(CONST_4,5, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L18);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9},new Method("Ljava/lang/reflect/Method;","getName",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,11);
                code.visitConstStmt(CONST_STRING,12,"doDelete");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11,12},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,11);
                code.visitJumpStmt(IF_EQZ,11,-1,L20);
                code.visitLabel(L19);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L20);
                code.visitStmt2R1N(ADD_INT_LIT8,8,8,1);
                code.visitJumpStmt(GOTO,-1,-1,L9);
                code.visitLabel(L21);
                code.visitConstStmt(CONST_4,7, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L22);
                code.visitJumpStmt(IF_EQZ,1,-1,L24);
                code.visitLabel(L23);
                code.visitJumpStmt(IF_NEZ,7,-1,L24);
                code.visitConstStmt(CONST_STRING,7,"GET");
                code.visitLabel(L24);
                code.visitJumpStmt(IF_EQZ,2,-1,L26);
                code.visitLabel(L25);
                code.visitJumpStmt(IF_NEZ,7,-1,L38);
                code.visitConstStmt(CONST_STRING,7,"HEAD");
                code.visitLabel(L26);
                code.visitJumpStmt(IF_EQZ,4,-1,L28);
                code.visitLabel(L27);
                code.visitJumpStmt(IF_NEZ,7,-1,L40);
                code.visitConstStmt(CONST_STRING,7,"POST");
                code.visitLabel(L28);
                code.visitJumpStmt(IF_EQZ,5,-1,L30);
                code.visitLabel(L29);
                code.visitJumpStmt(IF_NEZ,7,-1,L42);
                code.visitConstStmt(CONST_STRING,7,"PUT");
                code.visitLabel(L30);
                code.visitJumpStmt(IF_EQZ,0,-1,L32);
                code.visitLabel(L31);
                code.visitJumpStmt(IF_NEZ,7,-1,L44);
                code.visitConstStmt(CONST_STRING,7,"DELETE");
                code.visitLabel(L32);
                code.visitJumpStmt(IF_EQZ,6,-1,L34);
                code.visitLabel(L33);
                code.visitJumpStmt(IF_NEZ,7,-1,L46);
                code.visitConstStmt(CONST_STRING,7,"TRACE");
                code.visitLabel(L34);
                code.visitJumpStmt(IF_EQZ,3,-1,L36);
                code.visitLabel(L35);
                code.visitJumpStmt(IF_NEZ,7,-1,L48);
                code.visitConstStmt(CONST_STRING,7,"OPTIONS");
                code.visitLabel(L36);
                code.visitConstStmt(CONST_STRING,11,"Allow");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 15,11,7},new Method("Ljavax/servlet/http/HttpServletResponse;","setHeader",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"V"));
                code.visitLabel(L37);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L38);
                code.visitTypeStmt(NEW_INSTANCE,11,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 11},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11,7},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,11);
                code.visitConstStmt(CONST_STRING,12,", HEAD");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11,12},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,11);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitLabel(L39);
                code.visitJumpStmt(GOTO,-1,-1,L26);
                code.visitLabel(L40);
                code.visitTypeStmt(NEW_INSTANCE,11,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 11},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11,7},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,11);
                code.visitConstStmt(CONST_STRING,12,", POST");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11,12},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,11);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitLabel(L41);
                code.visitJumpStmt(GOTO,-1,-1,L28);
                code.visitLabel(L42);
                code.visitTypeStmt(NEW_INSTANCE,11,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 11},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11,7},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,11);
                code.visitConstStmt(CONST_STRING,12,", PUT");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11,12},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,11);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitLabel(L43);
                code.visitJumpStmt(GOTO,-1,-1,L30);
                code.visitLabel(L44);
                code.visitTypeStmt(NEW_INSTANCE,11,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 11},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11,7},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,11);
                code.visitConstStmt(CONST_STRING,12,", DELETE");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11,12},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,11);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitLabel(L45);
                code.visitJumpStmt(GOTO,-1,-1,L32);
                code.visitLabel(L46);
                code.visitTypeStmt(NEW_INSTANCE,11,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 11},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11,7},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,11);
                code.visitConstStmt(CONST_STRING,12,", TRACE");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11,12},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,11);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitLabel(L47);
                code.visitJumpStmt(GOTO,-1,-1,L34);
                code.visitLabel(L48);
                code.visitTypeStmt(NEW_INSTANCE,11,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 11},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11,7},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,11);
                code.visitConstStmt(CONST_STRING,12,", OPTIONS");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11,12},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,11);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitLabel(L49);
                code.visitJumpStmt(GOTO,-1,-1,L36);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m008_doPost(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Ljavax/servlet/http/HttpServlet;","doPost",new String[]{ "Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljavax/servlet/ServletException;"));
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"req");
                ddv.visitParameterName(1,"resp");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(366,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(367,L1);
                ddv.visitStartLocal(1,L1,"protocol","Ljava/lang/String;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(368,L2);
                ddv.visitStartLocal(0,L2,"msg","Ljava/lang/String;",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(369,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(373,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(371,L5);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 5},new Method("Ljavax/servlet/http/HttpServletRequest;","getProtocol",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L1);
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Ljavax/servlet/http/HttpServlet;","lStrings","Ljava/util/ResourceBundle;"));
                code.visitConstStmt(CONST_STRING,3,"http.method_post_not_supported");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/util/ResourceBundle;","getString",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L2);
                code.visitConstStmt(CONST_STRING,2,"1.1");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/lang/String;","endsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_EQZ,2,-1,L5);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_16,2, Integer.valueOf(405)); // int: 0x00000195  float:0.000000
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 6,2,0},new Method("Ljavax/servlet/http/HttpServletResponse;","sendError",new String[]{ "I","Ljava/lang/String;"},"V"));
                code.visitLabel(L4);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L5);
                code.visitConstStmt(CONST_16,2, Integer.valueOf(400)); // int: 0x00000190  float:0.000000
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 6,2,0},new Method("Ljavax/servlet/http/HttpServletResponse;","sendError",new String[]{ "I","Ljava/lang/String;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m009_doPut(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Ljavax/servlet/http/HttpServlet;","doPut",new String[]{ "Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljavax/servlet/ServletException;"));
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"req");
                ddv.visitParameterName(1,"resp");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(426,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(427,L1);
                ddv.visitStartLocal(1,L1,"protocol","Ljava/lang/String;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(428,L2);
                ddv.visitStartLocal(0,L2,"msg","Ljava/lang/String;",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(429,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(433,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(431,L5);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 5},new Method("Ljavax/servlet/http/HttpServletRequest;","getProtocol",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L1);
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Ljavax/servlet/http/HttpServlet;","lStrings","Ljava/util/ResourceBundle;"));
                code.visitConstStmt(CONST_STRING,3,"http.method_put_not_supported");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/util/ResourceBundle;","getString",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L2);
                code.visitConstStmt(CONST_STRING,2,"1.1");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/lang/String;","endsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_EQZ,2,-1,L5);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_16,2, Integer.valueOf(405)); // int: 0x00000195  float:0.000000
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 6,2,0},new Method("Ljavax/servlet/http/HttpServletResponse;","sendError",new String[]{ "I","Ljava/lang/String;"},"V"));
                code.visitLabel(L4);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L5);
                code.visitConstStmt(CONST_16,2, Integer.valueOf(400)); // int: 0x00000190  float:0.000000
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 6,2,0},new Method("Ljavax/servlet/http/HttpServletResponse;","sendError",new String[]{ "I","Ljava/lang/String;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m010_doTrace(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Ljavax/servlet/http/HttpServlet;","doTrace",new String[]{ "Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljavax/servlet/ServletException;"));
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(11);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"req");
                ddv.visitParameterName(1,"resp");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(649,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(650,L1);
                ddv.visitStartLocal(0,L1,"CRLF","Ljava/lang/String;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(653,L2);
                ddv.visitStartLocal(5,L2,"responseString","Ljava/lang/String;",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(655,L3);
                ddv.visitStartLocal(3,L3,"reqHeaderEnum","Ljava/util/Enumeration;",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(656,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(657,L5);
                ddv.visitStartLocal(1,L5,"headerName","Ljava/lang/String;",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(659,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(661,L7);
                ddv.visitEndLocal(1,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(663,L8);
                ddv.visitRestartLocal(5,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(665,L9);
                ddv.visitStartLocal(4,L9,"responseLength","I",null);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(666,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(667,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(668,L12);
                ddv.visitStartLocal(2,L12,"out","Ljavax/servlet/ServletOutputStream;",null);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(669,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(670,L14);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_STRING,0,"\r\n");
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,6,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 6},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,7,"TRACE ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,7},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 9},new Method("Ljavax/servlet/http/HttpServletRequest;","getRequestURI",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,7},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitConstStmt(CONST_STRING,7," ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,7},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 9},new Method("Ljavax/servlet/http/HttpServletRequest;","getProtocol",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,7},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 9},new Method("Ljavax/servlet/http/HttpServletRequest;","getHeaderNames",new String[]{ },"Ljava/util/Enumeration;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3},new Method("Ljava/util/Enumeration;","hasMoreElements",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitJumpStmt(IF_EQZ,6,-1,L7);
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3},new Method("Ljava/util/Enumeration;","nextElement",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitTypeStmt(CHECK_CAST,1,-1,"Ljava/lang/String;");
                code.visitLabel(L5);
                code.visitTypeStmt(NEW_INSTANCE,6,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 6},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,0},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitConstStmt(CONST_STRING,7,": ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,7},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 9,1},new Method("Ljavax/servlet/http/HttpServletRequest;","getHeader",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,7},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitLabel(L6);
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitLabel(L7);
                code.visitTypeStmt(NEW_INSTANCE,6,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 6},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,0},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitLabel(L9);
                code.visitConstStmt(CONST_STRING,6,"message/http");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 10,6},new Method("Ljavax/servlet/http/HttpServletResponse;","setContentType",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 10,4},new Method("Ljavax/servlet/http/HttpServletResponse;","setContentLength",new String[]{ "I"},"V"));
                code.visitLabel(L11);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 10},new Method("Ljavax/servlet/http/HttpServletResponse;","getOutputStream",new String[]{ },"Ljavax/servlet/ServletOutputStream;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L12);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,5},new Method("Ljavax/servlet/ServletOutputStream;","print",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L13);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljavax/servlet/ServletOutputStream;","close",new String[]{ },"V"));
                code.visitLabel(L14);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m011_getLastModified(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Ljavax/servlet/http/HttpServlet;","getLastModified",new String[]{ "Ljavax/servlet/http/HttpServletRequest;"},"J"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"req");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(246,L0);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_WIDE_16,0,Long.valueOf(-1L)); // long: 0xffffffffffffffff  double:NaN
                code.visitStmt1R(RETURN_WIDE,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m012_service(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Ljavax/servlet/http/HttpServlet;","service",new String[]{ "Ljavax/servlet/ServletRequest;","Ljavax/servlet/ServletResponse;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljavax/servlet/ServletException;"));
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(9);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/lang/ClassCastException;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"req");
                ddv.visitParameterName(1,"res");
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(827,L0);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(828,L3);
                ddv.visitStartLocal(2,L3,"request","Ljavax/servlet/http/HttpServletRequest;",null);
                ddv.visitLineNumber(832,L1);
                ddv.visitStartLocal(3,L1,"response","Ljavax/servlet/http/HttpServletResponse;",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(833,L4);
                ddv.visitLineNumber(829,L2);
                ddv.visitEndLocal(2,L2);
                ddv.visitEndLocal(3,L2);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(830,L5);
                ddv.visitStartLocal(1,L5,"e","Ljava/lang/ClassCastException;",null);
                code.visitLabel(L0);
                code.visitStmt2R(MOVE_OBJECT,0,7);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Ljavax/servlet/http/HttpServletRequest;");
                code.visitStmt2R(MOVE_OBJECT,2,0);
                code.visitLabel(L3);
                code.visitStmt2R(MOVE_OBJECT,0,8);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Ljavax/servlet/http/HttpServletResponse;");
                code.visitStmt2R(MOVE_OBJECT,3,0);
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,2,3},new Method("Ljavax/servlet/http/HttpServlet;","service",new String[]{ "Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;"},"V"));
                code.visitLabel(L4);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,4);
                code.visitStmt2R(MOVE_OBJECT,1,4);
                code.visitLabel(L5);
                code.visitTypeStmt(NEW_INSTANCE,4,-1,"Ljavax/servlet/ServletException;");
                code.visitConstStmt(CONST_STRING,5,"non-HTTP request or response");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4,5},new Method("Ljavax/servlet/ServletException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,4);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m013_service(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Ljavax/servlet/http/HttpServlet;","service",new String[]{ "Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljavax/servlet/ServletException;"));
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(14);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"req");
                ddv.visitParameterName(1,"resp");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(712,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(714,L2);
                ddv.visitStartLocal(6,L2,"method","Ljava/lang/String;",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(715,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(716,L4);
                ddv.visitStartLocal(4,L4,"lastModified","J",null);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(719,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(766,L6);
                ddv.visitEndLocal(4,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(721,L7);
                ddv.visitRestartLocal(4,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(722,L8);
                ddv.visitStartLocal(2,L8,"ifModifiedSince","J",null);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(726,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(727,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(729,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(733,L12);
                ddv.visitEndLocal(4,L12);
                ddv.visitEndLocal(2,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(734,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(735,L14);
                ddv.visitRestartLocal(4,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(736,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(738,L16);
                ddv.visitEndLocal(4,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(739,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(741,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(742,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(744,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(745,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(747,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(748,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(750,L24);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(751,L25);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(759,L26);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(760,L27);
                ddv.visitStartLocal(1,L27,"errMsg","Ljava/lang/String;",null);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(761,L28);
                ddv.visitStartLocal(0,L28,"errArgs","[Ljava/lang/Object;",null);
                DexLabel L29=new DexLabel();
                ddv.visitLineNumber(762,L29);
                DexLabel L30=new DexLabel();
                ddv.visitLineNumber(764,L30);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_WIDE_16,9,Long.valueOf(1000L)); // long: 0x00000000000003e8  double:0.000000
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 12},new Method("Ljavax/servlet/http/HttpServletRequest;","getMethod",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitLabel(L2);
                code.visitConstStmt(CONST_STRING,7,"GET");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,7},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitJumpStmt(IF_EQZ,7,-1,L12);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11,12},new Method("Ljavax/servlet/http/HttpServlet;","getLastModified",new String[]{ "Ljavax/servlet/http/HttpServletRequest;"},"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,4);
                code.visitLabel(L4);
                code.visitConstStmt(CONST_WIDE_16,7,Long.valueOf(-1L)); // long: 0xffffffffffffffff  double:NaN
                code.visitStmt3R(CMP_LONG,7,4,7);
                code.visitJumpStmt(IF_NEZ,7,-1,L7);
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11,12,13},new Method("Ljavax/servlet/http/HttpServlet;","doGet",new String[]{ "Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;"},"V"));
                code.visitLabel(L6);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L7);
                code.visitConstStmt(CONST_STRING,7,"If-Modified-Since");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 12,7},new Method("Ljavax/servlet/http/HttpServletRequest;","getDateHeader",new String[]{ "Ljava/lang/String;"},"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,2);
                code.visitLabel(L8);
                code.visitStmt3R(DIV_LONG,7,4,9);
                code.visitStmt2R(MUL_LONG_2ADDR,7,9);
                code.visitStmt3R(CMP_LONG,7,2,7);
                code.visitJumpStmt(IF_GEZ,7,-1,L11);
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 11,13,4,5},new Method("Ljavax/servlet/http/HttpServlet;","maybeSetLastModified",new String[]{ "Ljavax/servlet/http/HttpServletResponse;","J"},"V"));
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11,12,13},new Method("Ljavax/servlet/http/HttpServlet;","doGet",new String[]{ "Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L6);
                code.visitLabel(L11);
                code.visitConstStmt(CONST_16,7, Integer.valueOf(304)); // int: 0x00000130  float:0.000000
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 13,7},new Method("Ljavax/servlet/http/HttpServletResponse;","setStatus",new String[]{ "I"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L6);
                code.visitLabel(L12);
                code.visitConstStmt(CONST_STRING,7,"HEAD");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,7},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitJumpStmt(IF_EQZ,7,-1,L16);
                code.visitLabel(L13);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11,12},new Method("Ljavax/servlet/http/HttpServlet;","getLastModified",new String[]{ "Ljavax/servlet/http/HttpServletRequest;"},"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,4);
                code.visitLabel(L14);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 11,13,4,5},new Method("Ljavax/servlet/http/HttpServlet;","maybeSetLastModified",new String[]{ "Ljavax/servlet/http/HttpServletResponse;","J"},"V"));
                code.visitLabel(L15);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11,12,13},new Method("Ljavax/servlet/http/HttpServlet;","doHead",new String[]{ "Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L6);
                code.visitLabel(L16);
                code.visitConstStmt(CONST_STRING,7,"POST");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,7},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitJumpStmt(IF_EQZ,7,-1,L18);
                code.visitLabel(L17);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11,12,13},new Method("Ljavax/servlet/http/HttpServlet;","doPost",new String[]{ "Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L6);
                code.visitLabel(L18);
                code.visitConstStmt(CONST_STRING,7,"PUT");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,7},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitJumpStmt(IF_EQZ,7,-1,L20);
                code.visitLabel(L19);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11,12,13},new Method("Ljavax/servlet/http/HttpServlet;","doPut",new String[]{ "Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L6);
                code.visitLabel(L20);
                code.visitConstStmt(CONST_STRING,7,"DELETE");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,7},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitJumpStmt(IF_EQZ,7,-1,L22);
                code.visitLabel(L21);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11,12,13},new Method("Ljavax/servlet/http/HttpServlet;","doDelete",new String[]{ "Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L6);
                code.visitLabel(L22);
                code.visitConstStmt(CONST_STRING,7,"OPTIONS");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,7},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitJumpStmt(IF_EQZ,7,-1,L24);
                code.visitLabel(L23);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11,12,13},new Method("Ljavax/servlet/http/HttpServlet;","doOptions",new String[]{ "Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L6);
                code.visitLabel(L24);
                code.visitConstStmt(CONST_STRING,7,"TRACE");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,7},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitJumpStmt(IF_EQZ,7,-1,L26);
                code.visitLabel(L25);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11,12,13},new Method("Ljavax/servlet/http/HttpServlet;","doTrace",new String[]{ "Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L6);
                code.visitLabel(L26);
                code.visitFieldStmt(SGET_OBJECT,7,-1,new Field("Ljavax/servlet/http/HttpServlet;","lStrings","Ljava/util/ResourceBundle;"));
                code.visitConstStmt(CONST_STRING,8,"http.method_not_implemented");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,8},new Method("Ljava/util/ResourceBundle;","getString",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L27);
                code.visitConstStmt(CONST_4,7, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitTypeStmt(NEW_ARRAY,0,7,"[Ljava/lang/Object;");
                code.visitLabel(L28);
                code.visitConstStmt(CONST_4,7, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt3R(APUT_OBJECT,6,0,7);
                code.visitLabel(L29);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1,0},new Method("Ljava/text/MessageFormat;","format",new String[]{ "Ljava/lang/String;","[Ljava/lang/Object;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L30);
                code.visitConstStmt(CONST_16,7, Integer.valueOf(501)); // int: 0x000001f5  float:0.000000
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 13,7,1},new Method("Ljavax/servlet/http/HttpServletResponse;","sendError",new String[]{ "I","Ljava/lang/String;"},"V"));
                code.visitJumpStmt(GOTO_16,-1,-1,L6);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
