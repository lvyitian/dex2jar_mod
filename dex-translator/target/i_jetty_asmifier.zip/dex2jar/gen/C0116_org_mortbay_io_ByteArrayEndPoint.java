package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0116_org_mortbay_io_ByteArrayEndPoint {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/io/ByteArrayEndPoint;","Ljava/lang/Object;",new String[]{ "Lorg/mortbay/io/EndPoint;"});
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("ByteArrayEndPoint.java");
        f000__closed(cv);
        f001__growOutput(cv);
        f002__in(cv);
        f003__inBytes(cv);
        f004__nonBlocking(cv);
        f005__out(cv);
        m000__init_(cv);
        m001__init_(cv);
        m002_blockReadable(cv);
        m003_blockWritable(cv);
        m004_close(cv);
        m005_fill(cv);
        m006_flush(cv);
        m007_flush(cv);
        m008_flush(cv);
        m009_getIn(cv);
        m010_getLocalAddr(cv);
        m011_getLocalHost(cv);
        m012_getLocalPort(cv);
        m013_getOut(cv);
        m014_getRemoteAddr(cv);
        m015_getRemoteHost(cv);
        m016_getRemotePort(cv);
        m017_getTransport(cv);
        m018_isBlocking(cv);
        m019_isBufferingInput(cv);
        m020_isBufferingOutput(cv);
        m021_isBufferred(cv);
        m022_isGrowOutput(cv);
        m023_isNonBlocking(cv);
        m024_isOpen(cv);
        m025_reset(cv);
        m026_setGrowOutput(cv);
        m027_setIn(cv);
        m028_setNonBlocking(cv);
        m029_setOut(cv);
    }
    public static void f000__closed(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/io/ByteArrayEndPoint;","_closed","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001__growOutput(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/io/ByteArrayEndPoint;","_growOutput","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002__in(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/io/ByteArrayEndPoint;","_in","Lorg/mortbay/io/ByteArrayBuffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003__inBytes(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/io/ByteArrayEndPoint;","_inBytes","[B"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f004__nonBlocking(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/io/ByteArrayEndPoint;","_nonBlocking","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f005__out(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/io/ByteArrayEndPoint;","_out","Lorg/mortbay/io/ByteArrayBuffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/io/ByteArrayEndPoint;","<init>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(41,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(42,L1);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/Object;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/io/ByteArrayEndPoint;","<init>",new String[]{ "[B","I"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"input");
                ddv.visitParameterName(1,"outputSize");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(67,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(68,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(69,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(70,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(71,L4);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljava/lang/Object;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitFieldStmt(IPUT_OBJECT,2,1,new Field("Lorg/mortbay/io/ByteArrayEndPoint;","_inBytes","[B"));
                code.visitLabel(L2);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/io/ByteArrayBuffer;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,2},new Method("Lorg/mortbay/io/ByteArrayBuffer;","<init>",new String[]{ "[B"},"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/io/ByteArrayEndPoint;","_in","Lorg/mortbay/io/ByteArrayBuffer;"));
                code.visitLabel(L3);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/io/ByteArrayBuffer;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,3},new Method("Lorg/mortbay/io/ByteArrayBuffer;","<init>",new String[]{ "I"},"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/io/ByteArrayEndPoint;","_out","Lorg/mortbay/io/ByteArrayBuffer;"));
                code.visitLabel(L4);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_blockReadable(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/ByteArrayEndPoint;","blockReadable",new String[]{ "J"},"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"millisecs");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(126,L0);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_blockWritable(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/ByteArrayEndPoint;","blockWritable",new String[]{ "J"},"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"millisecs");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(132,L0);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_close(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/ByteArrayEndPoint;","close",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(141,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(142,L1);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitFieldStmt(IPUT_BOOLEAN,0,1,new Field("Lorg/mortbay/io/ByteArrayEndPoint;","_closed","Z"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_fill(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/ByteArrayEndPoint;","fill",new String[]{ "Lorg/mortbay/io/Buffer;"},"I"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"buffer");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(150,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(151,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(152,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(158,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(154,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(155,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(156,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(157,L8);
                ddv.visitStartLocal(0,L8,"len","I",null);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(158,L9);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(-1)); // int: 0xffffffff  float:NaN
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_BOOLEAN,1,3,new Field("Lorg/mortbay/io/ByteArrayEndPoint;","_closed","Z"));
                code.visitJumpStmt(IF_EQZ,1,-1,L3);
                code.visitLabel(L2);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/io/IOException;");
                code.visitConstStmt(CONST_STRING,2,"CLOSED");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,2},new Method("Ljava/io/IOException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,1);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/io/ByteArrayEndPoint;","_in","Lorg/mortbay/io/ByteArrayBuffer;"));
                code.visitJumpStmt(IF_NEZ,1,-1,L5);
                code.visitStmt2R(MOVE,1,2);
                code.visitLabel(L4);
                code.visitStmt1R(RETURN,1);
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/io/ByteArrayEndPoint;","_in","Lorg/mortbay/io/ByteArrayBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/io/ByteArrayBuffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_GTZ,1,-1,L7);
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_BOOLEAN,1,3,new Field("Lorg/mortbay/io/ByteArrayEndPoint;","_nonBlocking","Z"));
                DexLabel L10=new DexLabel();
                code.visitJumpStmt(IF_EQZ,1,-1,L10);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitLabel(L10);
                code.visitStmt2R(MOVE,1,2);
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitLabel(L7);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/io/ByteArrayEndPoint;","_in","Lorg/mortbay/io/ByteArrayBuffer;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 4,1},new Method("Lorg/mortbay/io/Buffer;","put",new String[]{ "Lorg/mortbay/io/Buffer;"},"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitLabel(L8);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/io/ByteArrayEndPoint;","_in","Lorg/mortbay/io/ByteArrayBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,0},new Method("Lorg/mortbay/io/ByteArrayBuffer;","skip",new String[]{ "I"},"I"));
                code.visitStmt2R(MOVE,1,0);
                code.visitLabel(L9);
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_flush(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/ByteArrayEndPoint;","flush",new String[]{ "Lorg/mortbay/io/Buffer;"},"I"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"buffer");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(167,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(168,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(169,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(171,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(173,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(175,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(177,L6);
                ddv.visitStartLocal(1,L6,"n","Lorg/mortbay/io/ByteArrayBuffer;",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(178,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(180,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(181,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(183,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(186,L11);
                ddv.visitEndLocal(1,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(187,L12);
                ddv.visitStartLocal(0,L12,"len","I",null);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(188,L13);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_BOOLEAN,2,5,new Field("Lorg/mortbay/io/ByteArrayEndPoint;","_closed","Z"));
                code.visitJumpStmt(IF_EQZ,2,-1,L2);
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Ljava/io/IOException;");
                code.visitConstStmt(CONST_STRING,3,"CLOSED");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2,3},new Method("Ljava/io/IOException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,2);
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_BOOLEAN,2,5,new Field("Lorg/mortbay/io/ByteArrayEndPoint;","_growOutput","Z"));
                code.visitJumpStmt(IF_EQZ,2,-1,L11);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 6},new Method("Lorg/mortbay/io/Buffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitFieldStmt(IGET_OBJECT,3,5,new Field("Lorg/mortbay/io/ByteArrayEndPoint;","_out","Lorg/mortbay/io/ByteArrayBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/io/ByteArrayBuffer;","space",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_LE,2,3,L11);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/io/ByteArrayEndPoint;","_out","Lorg/mortbay/io/ByteArrayBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/io/ByteArrayBuffer;","compact",new String[]{ },"V"));
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 6},new Method("Lorg/mortbay/io/Buffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitFieldStmt(IGET_OBJECT,3,5,new Field("Lorg/mortbay/io/ByteArrayEndPoint;","_out","Lorg/mortbay/io/ByteArrayBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/io/ByteArrayBuffer;","space",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_LE,2,3,L11);
                code.visitLabel(L5);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Lorg/mortbay/io/ByteArrayBuffer;");
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/io/ByteArrayEndPoint;","_out","Lorg/mortbay/io/ByteArrayBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/io/ByteArrayBuffer;","putIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 6},new Method("Lorg/mortbay/io/Buffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitStmt2R(ADD_INT_2ADDR,2,3);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,2},new Method("Lorg/mortbay/io/ByteArrayBuffer;","<init>",new String[]{ "I"},"V"));
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/io/ByteArrayEndPoint;","_out","Lorg/mortbay/io/ByteArrayBuffer;"));
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IGET_OBJECT,4,5,new Field("Lorg/mortbay/io/ByteArrayEndPoint;","_out","Lorg/mortbay/io/ByteArrayBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/io/ByteArrayBuffer;","putIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3,4},new Method("Lorg/mortbay/io/ByteArrayBuffer;","peek",new String[]{ "I","I"},"Lorg/mortbay/io/Buffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Lorg/mortbay/io/ByteArrayBuffer;","put",new String[]{ "Lorg/mortbay/io/Buffer;"},"I"));
                code.visitLabel(L7);
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/io/ByteArrayEndPoint;","_out","Lorg/mortbay/io/ByteArrayBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/io/ByteArrayBuffer;","getIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_LEZ,2,-1,L10);
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/io/ByteArrayBuffer;","mark",new String[]{ },"V"));
                code.visitLabel(L9);
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/io/ByteArrayEndPoint;","_out","Lorg/mortbay/io/ByteArrayBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/io/ByteArrayBuffer;","getIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Lorg/mortbay/io/ByteArrayBuffer;","setGetIndex",new String[]{ "I"},"V"));
                code.visitLabel(L10);
                code.visitFieldStmt(IPUT_OBJECT,1,5,new Field("Lorg/mortbay/io/ByteArrayEndPoint;","_out","Lorg/mortbay/io/ByteArrayBuffer;"));
                code.visitLabel(L11);
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/io/ByteArrayEndPoint;","_out","Lorg/mortbay/io/ByteArrayBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,6},new Method("Lorg/mortbay/io/ByteArrayBuffer;","put",new String[]{ "Lorg/mortbay/io/Buffer;"},"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitLabel(L12);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 6,0},new Method("Lorg/mortbay/io/Buffer;","skip",new String[]{ "I"},"I"));
                code.visitLabel(L13);
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m007_flush(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/ByteArrayEndPoint;","flush",new String[]{ "Lorg/mortbay/io/Buffer;","Lorg/mortbay/io/Buffer;","Lorg/mortbay/io/Buffer;"},"I"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"header");
                ddv.visitParameterName(1,"buffer");
                ddv.visitParameterName(2,"trailer");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(197,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(198,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(200,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(202,L3);
                ddv.visitStartLocal(0,L3,"flushed","I",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(203,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(205,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(207,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(208,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(210,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(212,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(214,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(219,L11);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_BOOLEAN,1,3,new Field("Lorg/mortbay/io/ByteArrayEndPoint;","_closed","Z"));
                code.visitJumpStmt(IF_EQZ,1,-1,L2);
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/io/IOException;");
                code.visitConstStmt(CONST_STRING,2,"CLOSED");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,2},new Method("Ljava/io/IOException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,1);
                code.visitLabel(L2);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L3);
                code.visitJumpStmt(IF_EQZ,4,-1,L5);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 4},new Method("Lorg/mortbay/io/Buffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_LEZ,1,-1,L5);
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Lorg/mortbay/io/ByteArrayEndPoint;","flush",new String[]{ "Lorg/mortbay/io/Buffer;"},"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitLabel(L5);
                code.visitJumpStmt(IF_EQZ,4,-1,L6);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 4},new Method("Lorg/mortbay/io/Buffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_NEZ,1,-1,L11);
                code.visitLabel(L6);
                code.visitJumpStmt(IF_EQZ,5,-1,L8);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 5},new Method("Lorg/mortbay/io/Buffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_LEZ,1,-1,L8);
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,5},new Method("Lorg/mortbay/io/ByteArrayEndPoint;","flush",new String[]{ "Lorg/mortbay/io/Buffer;"},"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitStmt2R(ADD_INT_2ADDR,0,1);
                code.visitLabel(L8);
                code.visitJumpStmt(IF_EQZ,5,-1,L9);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 5},new Method("Lorg/mortbay/io/Buffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_NEZ,1,-1,L11);
                code.visitLabel(L9);
                code.visitJumpStmt(IF_EQZ,6,-1,L11);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 6},new Method("Lorg/mortbay/io/Buffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_LEZ,1,-1,L11);
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,6},new Method("Lorg/mortbay/io/ByteArrayEndPoint;","flush",new String[]{ "Lorg/mortbay/io/Buffer;"},"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitStmt2R(ADD_INT_2ADDR,0,1);
                code.visitLabel(L11);
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m008_flush(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/ByteArrayEndPoint;","flush",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(301,L0);
                code.visitLabel(L0);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m009_getIn(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/ByteArrayEndPoint;","getIn",new String[]{ },"Lorg/mortbay/io/ByteArrayBuffer;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(79,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/io/ByteArrayEndPoint;","_in","Lorg/mortbay/io/ByteArrayBuffer;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m010_getLocalAddr(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/ByteArrayEndPoint;","getLocalAddr",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(241,L0);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m011_getLocalHost(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/ByteArrayEndPoint;","getLocalHost",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(250,L0);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m012_getLocalPort(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/ByteArrayEndPoint;","getLocalPort",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(259,L0);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m013_getOut(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/ByteArrayEndPoint;","getOut",new String[]{ },"Lorg/mortbay/io/ByteArrayBuffer;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(95,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/io/ByteArrayEndPoint;","_out","Lorg/mortbay/io/ByteArrayBuffer;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m014_getRemoteAddr(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/ByteArrayEndPoint;","getRemoteAddr",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(268,L0);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m015_getRemoteHost(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/ByteArrayEndPoint;","getRemoteHost",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(277,L0);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m016_getRemotePort(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/ByteArrayEndPoint;","getRemotePort",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(286,L0);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m017_getTransport(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/ByteArrayEndPoint;","getTransport",new String[]{ },"Ljava/lang/Object;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(295,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/io/ByteArrayEndPoint;","_inBytes","[B"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m018_isBlocking(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/ByteArrayEndPoint;","isBlocking",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(120,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_BOOLEAN,0,1,new Field("Lorg/mortbay/io/ByteArrayEndPoint;","_nonBlocking","Z"));
                DexLabel L1=new DexLabel();
                code.visitJumpStmt(IF_NEZ,0,-1,L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                DexLabel L2=new DexLabel();
                code.visitLabel(L2);
                code.visitStmt1R(RETURN,0);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m019_isBufferingInput(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/ByteArrayEndPoint;","isBufferingInput",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(306,L0);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m020_isBufferingOutput(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/ByteArrayEndPoint;","isBufferingOutput",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(312,L0);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m021_isBufferred(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/ByteArrayEndPoint;","isBufferred",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(318,L0);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m022_isGrowOutput(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/ByteArrayEndPoint;","isGrowOutput",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(327,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_BOOLEAN,0,1,new Field("Lorg/mortbay/io/ByteArrayEndPoint;","_growOutput","Z"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m023_isNonBlocking(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/ByteArrayEndPoint;","isNonBlocking",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(50,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_BOOLEAN,0,1,new Field("Lorg/mortbay/io/ByteArrayEndPoint;","_nonBlocking","Z"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m024_isOpen(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/ByteArrayEndPoint;","isOpen",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(111,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_BOOLEAN,0,1,new Field("Lorg/mortbay/io/ByteArrayEndPoint;","_closed","Z"));
                DexLabel L1=new DexLabel();
                code.visitJumpStmt(IF_NEZ,0,-1,L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                DexLabel L2=new DexLabel();
                code.visitLabel(L2);
                code.visitStmt1R(RETURN,0);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m025_reset(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/ByteArrayEndPoint;","reset",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(228,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(229,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(230,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(231,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(232,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(233,L5);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_BOOLEAN,0,2,new Field("Lorg/mortbay/io/ByteArrayEndPoint;","_closed","Z"));
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/io/ByteArrayEndPoint;","_in","Lorg/mortbay/io/ByteArrayBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/io/ByteArrayBuffer;","clear",new String[]{ },"V"));
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/io/ByteArrayEndPoint;","_out","Lorg/mortbay/io/ByteArrayBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/io/ByteArrayBuffer;","clear",new String[]{ },"V"));
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/io/ByteArrayEndPoint;","_inBytes","[B"));
                code.visitJumpStmt(IF_EQZ,0,-1,L5);
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/io/ByteArrayEndPoint;","_in","Lorg/mortbay/io/ByteArrayBuffer;"));
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/io/ByteArrayEndPoint;","_inBytes","[B"));
                code.visitStmt2R(ARRAY_LENGTH,1,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/io/ByteArrayBuffer;","setPutIndex",new String[]{ "I"},"V"));
                code.visitLabel(L5);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m026_setGrowOutput(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/ByteArrayEndPoint;","setGrowOutput",new String[]{ "Z"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"growOutput");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(336,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(337,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_BOOLEAN,1,0,new Field("Lorg/mortbay/io/ByteArrayEndPoint;","_growOutput","Z"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m027_setIn(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/ByteArrayEndPoint;","setIn",new String[]{ "Lorg/mortbay/io/ByteArrayBuffer;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"in");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(87,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(88,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/io/ByteArrayEndPoint;","_in","Lorg/mortbay/io/ByteArrayBuffer;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m028_setNonBlocking(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/ByteArrayEndPoint;","setNonBlocking",new String[]{ "Z"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"nonBlocking");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(59,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(60,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_BOOLEAN,1,0,new Field("Lorg/mortbay/io/ByteArrayEndPoint;","_nonBlocking","Z"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m029_setOut(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/ByteArrayEndPoint;","setOut",new String[]{ "Lorg/mortbay/io/ByteArrayBuffer;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"out");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(103,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(104,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/io/ByteArrayEndPoint;","_out","Lorg/mortbay/io/ByteArrayBuffer;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
