package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0465_org_mortbay_xml_XmlParser_Node {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/xml/XmlParser$Node;","Ljava/util/AbstractList;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("XmlParser.java");
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/EnclosingClass;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("value", new DexType("Lorg/mortbay/xml/XmlParser;"));
                av00.visitEnd();
            }
        }
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/InnerClass;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("accessFlags",  Integer.valueOf(9));
                av00.visit("name", "Node");
                av00.visitEnd();
            }
        }
        f000__attrs(cv);
        f001__lastString(cv);
        f002__list(cv);
        f003__parent(cv);
        f004__path(cv);
        f005__tag(cv);
        m000__init_(cv);
        m001_access$600(cv);
        m002_access$700(cv);
        m003_toString(cv);
        m004_add(cv);
        m005_clear(cv);
        m006_get(cv);
        m007_get(cv);
        m008_getAttribute(cv);
        m009_getAttribute(cv);
        m010_getAttributes(cv);
        m011_getParent(cv);
        m012_getPath(cv);
        m013_getString(cv);
        m014_getTag(cv);
        m015_iterator(cv);
        m016_size(cv);
        m017_toString(cv);
        m018_toString(cv);
        m019_toString(cv);
    }
    public static void f000__attrs(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/xml/XmlParser$Node;","_attrs","[Lorg/mortbay/xml/XmlParser$Attribute;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001__lastString(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/xml/XmlParser$Node;","_lastString","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002__list(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/xml/XmlParser$Node;","_list","Ljava/util/ArrayList;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003__parent(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/xml/XmlParser$Node;","_parent","Lorg/mortbay/xml/XmlParser$Node;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f004__path(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/xml/XmlParser$Node;","_path","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f005__tag(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/xml/XmlParser$Node;","_tag","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_CONSTRUCTOR, new Method("Lorg/mortbay/xml/XmlParser$Node;","<init>",new String[]{ "Lorg/mortbay/xml/XmlParser$Node;","Ljava/lang/String;","Lorg/xml/sax/Attributes;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(9);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"parent");
                ddv.visitParameterName(1,"tag");
                ddv.visitParameterName(2,"attrs");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(480,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(475,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(481,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(482,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(484,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(486,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(487,L6);
                DexLabel L7=new DexLabel();
                ddv.visitStartLocal(0,L7,"i","I",null);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(489,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(490,L9);
                ddv.visitStartLocal(1,L9,"name","Ljava/lang/String;",null);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(491,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(492,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(487,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(495,L13);
                ddv.visitEndLocal(0,L13);
                ddv.visitEndLocal(1,L13);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 5},new Method("Ljava/util/AbstractList;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_BOOLEAN,2,5,new Field("Lorg/mortbay/xml/XmlParser$Node;","_lastString","Z"));
                code.visitLabel(L2);
                code.visitFieldStmt(IPUT_OBJECT,6,5,new Field("Lorg/mortbay/xml/XmlParser$Node;","_parent","Lorg/mortbay/xml/XmlParser$Node;"));
                code.visitLabel(L3);
                code.visitFieldStmt(IPUT_OBJECT,7,5,new Field("Lorg/mortbay/xml/XmlParser$Node;","_tag","Ljava/lang/String;"));
                code.visitLabel(L4);
                code.visitJumpStmt(IF_EQZ,8,-1,L13);
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 8},new Method("Lorg/xml/sax/Attributes;","getLength",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitTypeStmt(NEW_ARRAY,2,2,"[Lorg/mortbay/xml/XmlParser$Attribute;");
                code.visitFieldStmt(IPUT_OBJECT,2,5,new Field("Lorg/mortbay/xml/XmlParser$Node;","_attrs","[Lorg/mortbay/xml/XmlParser$Attribute;"));
                code.visitLabel(L6);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 8},new Method("Lorg/xml/sax/Attributes;","getLength",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_GE,0,2,L13);
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 8,0},new Method("Lorg/xml/sax/Attributes;","getLocalName",new String[]{ "I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L9);
                code.visitJumpStmt(IF_EQZ,1,-1,L10);
                code.visitConstStmt(CONST_STRING,2,"");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_EQZ,2,-1,L11);
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 8,0},new Method("Lorg/xml/sax/Attributes;","getQName",new String[]{ "I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L11);
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/xml/XmlParser$Node;","_attrs","[Lorg/mortbay/xml/XmlParser$Attribute;"));
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Lorg/mortbay/xml/XmlParser$Attribute;");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 8,0},new Method("Lorg/xml/sax/Attributes;","getValue",new String[]{ "I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3,1,4},new Method("Lorg/mortbay/xml/XmlParser$Attribute;","<init>",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"V"));
                code.visitStmt3R(APUT_OBJECT,3,2,0);
                code.visitLabel(L12);
                code.visitStmt2R1N(ADD_INT_LIT8,0,0,1);
                code.visitJumpStmt(GOTO,-1,-1,L7);
                code.visitLabel(L13);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001_access$600(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_SYNTHETIC, new Method("Lorg/mortbay/xml/XmlParser$Node;","access$600",new String[]{ "Lorg/mortbay/xml/XmlParser$Node;"},"Ljava/util/ArrayList;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"x0");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(469,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/xml/XmlParser$Node;","_list","Ljava/util/ArrayList;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_access$700(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_SYNTHETIC, new Method("Lorg/mortbay/xml/XmlParser$Node;","access$700",new String[]{ "Lorg/mortbay/xml/XmlParser$Node;"},"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"x0");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(469,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/xml/XmlParser$Node;","_tag","Ljava/lang/String;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_toString(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PRIVATE, new Method("Lorg/mortbay/xml/XmlParser$Node;","toString",new String[]{ "Ljava/lang/StringBuffer;","Z"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L2},new String[]{ null});
                DexLabel L5=new DexLabel();
                DexLabel L6=new DexLabel();
                code.visitTryCatch(L5,L6,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"buf");
                ddv.visitParameterName(1,"tag");
                DexLabel L7=new DexLabel();
                ddv.visitPrologue(L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(697,L8);
                ddv.visitLineNumber(699,L0);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(700,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(702,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(704,L11);
                DexLabel L12=new DexLabel();
                ddv.visitStartLocal(0,L12,"i","I",null);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(706,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(707,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(708,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(709,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(710,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(704,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(715,L19);
                ddv.visitEndLocal(0,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(717,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(718,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(719,L22);
                DexLabel L23=new DexLabel();
                ddv.visitRestartLocal(0,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(721,L24);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(722,L25);
                ddv.visitStartLocal(1,L25,"o","Ljava/lang/Object;",null);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(719,L26);
                ddv.visitEndLocal(1,L26);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(724,L27);
                ddv.visitRestartLocal(1,L27);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(725,L28);
                DexLabel L29=new DexLabel();
                ddv.visitEndLocal(1,L29);
                ddv.visitLineNumber(697,L2);
                ddv.visitEndLocal(0,L2);
                ddv.visitLineNumber(727,L3);
                ddv.visitRestartLocal(0,L3);
                ddv.visitRestartLocal(1,L3);
                DexLabel L30=new DexLabel();
                ddv.visitLineNumber(729,L30);
                ddv.visitEndLocal(1,L30);
                DexLabel L31=new DexLabel();
                ddv.visitLineNumber(731,L31);
                DexLabel L32=new DexLabel();
                ddv.visitLineNumber(732,L32);
                DexLabel L33=new DexLabel();
                ddv.visitLineNumber(733,L33);
                ddv.visitLineNumber(738,L4);
                ddv.visitEndLocal(0,L4);
                DexLabel L34=new DexLabel();
                ddv.visitLineNumber(736,L34);
                ddv.visitLineNumber(737,L5);
                code.visitLabel(L7);
                code.visitConstStmt(CONST_STRING,2,">");
                code.visitLabel(L8);
                code.visitStmt1R(MONITOR_ENTER,3);
                code.visitJumpStmt(IF_EQZ,5,-1,L19);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_STRING,2,"<");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,2},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L9);
                code.visitFieldStmt(IGET_OBJECT,2,3,new Field("Lorg/mortbay/xml/XmlParser$Node;","_tag","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,2},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L10);
                code.visitFieldStmt(IGET_OBJECT,2,3,new Field("Lorg/mortbay/xml/XmlParser$Node;","_attrs","[Lorg/mortbay/xml/XmlParser$Attribute;"));
                code.visitJumpStmt(IF_EQZ,2,-1,L19);
                code.visitLabel(L11);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L12);
                code.visitFieldStmt(IGET_OBJECT,2,3,new Field("Lorg/mortbay/xml/XmlParser$Node;","_attrs","[Lorg/mortbay/xml/XmlParser$Attribute;"));
                code.visitStmt2R(ARRAY_LENGTH,2,2);
                code.visitJumpStmt(IF_GE,0,2,L19);
                code.visitLabel(L13);
                code.visitConstStmt(CONST_16,2, Integer.valueOf(32)); // int: 0x00000020  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,2},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "C"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L14);
                code.visitFieldStmt(IGET_OBJECT,2,3,new Field("Lorg/mortbay/xml/XmlParser$Node;","_attrs","[Lorg/mortbay/xml/XmlParser$Attribute;"));
                code.visitStmt3R(AGET_OBJECT,2,2,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/xml/XmlParser$Attribute;","getName",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,2},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L15);
                code.visitConstStmt(CONST_STRING,2,"=\"");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,2},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L16);
                code.visitFieldStmt(IGET_OBJECT,2,3,new Field("Lorg/mortbay/xml/XmlParser$Node;","_attrs","[Lorg/mortbay/xml/XmlParser$Attribute;"));
                code.visitStmt3R(AGET_OBJECT,2,2,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/xml/XmlParser$Attribute;","getValue",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,2},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L17);
                code.visitConstStmt(CONST_STRING,2,"\"");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,2},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L18);
                code.visitStmt2R1N(ADD_INT_LIT8,0,0,1);
                code.visitJumpStmt(GOTO,-1,-1,L12);
                code.visitLabel(L19);
                code.visitFieldStmt(IGET_OBJECT,2,3,new Field("Lorg/mortbay/xml/XmlParser$Node;","_list","Ljava/util/ArrayList;"));
                code.visitJumpStmt(IF_EQZ,2,-1,L34);
                code.visitLabel(L20);
                code.visitJumpStmt(IF_EQZ,5,-1,L22);
                code.visitLabel(L21);
                code.visitConstStmt(CONST_STRING,2,">");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,2},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L22);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L23);
                code.visitFieldStmt(IGET_OBJECT,2,3,new Field("Lorg/mortbay/xml/XmlParser$Node;","_list","Ljava/util/ArrayList;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/util/ArrayList;","size",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_GE,0,2,L30);
                code.visitLabel(L24);
                code.visitFieldStmt(IGET_OBJECT,2,3,new Field("Lorg/mortbay/xml/XmlParser$Node;","_list","Ljava/util/ArrayList;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,0},new Method("Ljava/util/ArrayList;","get",new String[]{ "I"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L25);
                code.visitJumpStmt(IF_NEZ,1,-1,L27);
                code.visitLabel(L26);
                code.visitStmt2R1N(ADD_INT_LIT8,0,0,1);
                code.visitJumpStmt(GOTO,-1,-1,L23);
                code.visitLabel(L27);
                code.visitTypeStmt(INSTANCE_OF,2,1,"Lorg/mortbay/xml/XmlParser$Node;");
                code.visitJumpStmt(IF_EQZ,2,-1,L3);
                code.visitLabel(L28);
                code.visitTypeStmt(CHECK_CAST,1,-1,"Lorg/mortbay/xml/XmlParser$Node;");
                code.visitLabel(L29);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,4,5},new Method("Lorg/mortbay/xml/XmlParser$Node;","toString",new String[]{ "Ljava/lang/StringBuffer;","Z"},"V"));
                code.visitLabel(L1);
                code.visitJumpStmt(GOTO,-1,-1,L26);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,2);
                code.visitStmt1R(MONITOR_EXIT,3);
                code.visitStmt1R(THROW,2);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/lang/Object;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,2},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitJumpStmt(GOTO,-1,-1,L26);
                code.visitLabel(L30);
                code.visitJumpStmt(IF_EQZ,5,-1,L4);
                code.visitLabel(L31);
                code.visitConstStmt(CONST_STRING,2,"</");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,2},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L32);
                code.visitFieldStmt(IGET_OBJECT,2,3,new Field("Lorg/mortbay/xml/XmlParser$Node;","_tag","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,2},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L33);
                code.visitConstStmt(CONST_STRING,2,">");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,2},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L4);
                code.visitStmt1R(MONITOR_EXIT,3);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L34);
                code.visitJumpStmt(IF_EQZ,5,-1,L4);
                code.visitLabel(L5);
                code.visitConstStmt(CONST_STRING,2,"/>");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,2},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L6);
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_add(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/xml/XmlParser$Node;","add",new String[]{ "I","Ljava/lang/Object;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(8);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"i");
                ddv.visitParameterName(1,"o");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(610,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(611,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(612,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(614,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(616,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(617,L6);
                ddv.visitStartLocal(0,L6,"last","I",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(621,L7);
                ddv.visitEndLocal(0,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(628,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(620,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(625,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(626,L11);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,1,5,new Field("Lorg/mortbay/xml/XmlParser$Node;","_list","Ljava/util/ArrayList;"));
                code.visitJumpStmt(IF_NEZ,1,-1,L3);
                code.visitLabel(L2);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/util/ArrayList;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljava/util/ArrayList;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,1,5,new Field("Lorg/mortbay/xml/XmlParser$Node;","_list","Ljava/util/ArrayList;"));
                code.visitLabel(L3);
                code.visitTypeStmt(INSTANCE_OF,1,7,"Ljava/lang/String;");
                code.visitJumpStmt(IF_EQZ,1,-1,L10);
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_BOOLEAN,1,5,new Field("Lorg/mortbay/xml/XmlParser$Node;","_lastString","Z"));
                code.visitJumpStmt(IF_EQZ,1,-1,L9);
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,1,5,new Field("Lorg/mortbay/xml/XmlParser$Node;","_list","Ljava/util/ArrayList;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/util/ArrayList;","size",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitStmt3R(SUB_INT,0,1,4);
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/xml/XmlParser$Node;","_list","Ljava/util/ArrayList;"));
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IGET_OBJECT,1,5,new Field("Lorg/mortbay/xml/XmlParser$Node;","_list","Ljava/util/ArrayList;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,0},new Method("Ljava/util/ArrayList;","get",new String[]{ "I"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitTypeStmt(CHECK_CAST,1,-1,"Ljava/lang/String;");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,7},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,0,1},new Method("Ljava/util/ArrayList;","set",new String[]{ "I","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L7);
                code.visitFieldStmt(IPUT_BOOLEAN,4,5,new Field("Lorg/mortbay/xml/XmlParser$Node;","_lastString","Z"));
                code.visitLabel(L8);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L9);
                code.visitFieldStmt(IGET_OBJECT,1,5,new Field("Lorg/mortbay/xml/XmlParser$Node;","_list","Ljava/util/ArrayList;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,6,7},new Method("Ljava/util/ArrayList;","add",new String[]{ "I","Ljava/lang/Object;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L7);
                code.visitLabel(L10);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_BOOLEAN,1,5,new Field("Lorg/mortbay/xml/XmlParser$Node;","_lastString","Z"));
                code.visitLabel(L11);
                code.visitFieldStmt(IGET_OBJECT,1,5,new Field("Lorg/mortbay/xml/XmlParser$Node;","_list","Ljava/util/ArrayList;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,6,7},new Method("Ljava/util/ArrayList;","add",new String[]{ "I","Ljava/lang/Object;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L8);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_clear(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/xml/XmlParser$Node;","clear",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(633,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(634,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(635,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(636,L3);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/xml/XmlParser$Node;","_list","Ljava/util/ArrayList;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L2);
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/xml/XmlParser$Node;","_list","Ljava/util/ArrayList;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/util/ArrayList;","clear",new String[]{ },"V"));
                code.visitLabel(L2);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/xml/XmlParser$Node;","_list","Ljava/util/ArrayList;"));
                code.visitLabel(L3);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_get(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/xml/XmlParser$Node;","get",new String[]{ "I"},"Ljava/lang/Object;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"i");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(577,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(578,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(579,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/xml/XmlParser$Node;","_list","Ljava/util/ArrayList;"));
                DexLabel L3=new DexLabel();
                code.visitJumpStmt(IF_EQZ,0,-1,L3);
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/xml/XmlParser$Node;","_list","Ljava/util/ArrayList;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,2},new Method("Ljava/util/ArrayList;","get",new String[]{ "I"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L2);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m007_get(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/xml/XmlParser$Node;","get",new String[]{ "Ljava/lang/String;"},"Lorg/mortbay/xml/XmlParser$Node;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"tag");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(591,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(593,L1);
                DexLabel L2=new DexLabel();
                ddv.visitStartLocal(1,L2,"i","I",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(595,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(596,L4);
                ddv.visitStartLocal(3,L4,"o","Ljava/lang/Object;",null);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(598,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(599,L6);
                ddv.visitStartLocal(2,L6,"n","Lorg/mortbay/xml/XmlParser$Node;",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(604,L7);
                ddv.visitEndLocal(1,L7);
                ddv.visitEndLocal(3,L7);
                ddv.visitEndLocal(2,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(593,L8);
                ddv.visitRestartLocal(1,L8);
                ddv.visitRestartLocal(3,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(604,L9);
                ddv.visitEndLocal(1,L9);
                ddv.visitEndLocal(3,L9);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,4,5,new Field("Lorg/mortbay/xml/XmlParser$Node;","_list","Ljava/util/ArrayList;"));
                code.visitJumpStmt(IF_EQZ,4,-1,L9);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,4,5,new Field("Lorg/mortbay/xml/XmlParser$Node;","_list","Ljava/util/ArrayList;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/util/ArrayList;","size",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitJumpStmt(IF_GE,1,4,L9);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,4,5,new Field("Lorg/mortbay/xml/XmlParser$Node;","_list","Ljava/util/ArrayList;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,1},new Method("Ljava/util/ArrayList;","get",new String[]{ "I"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitLabel(L4);
                code.visitTypeStmt(INSTANCE_OF,4,3,"Lorg/mortbay/xml/XmlParser$Node;");
                code.visitJumpStmt(IF_EQZ,4,-1,L8);
                code.visitLabel(L5);
                code.visitStmt2R(MOVE_OBJECT,0,3);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Lorg/mortbay/xml/XmlParser$Node;");
                code.visitStmt2R(MOVE_OBJECT,2,0);
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,4,2,new Field("Lorg/mortbay/xml/XmlParser$Node;","_tag","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,4},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitJumpStmt(IF_EQZ,4,-1,L8);
                code.visitStmt2R(MOVE_OBJECT,4,2);
                code.visitLabel(L7);
                code.visitStmt1R(RETURN_OBJECT,4);
                code.visitLabel(L8);
                code.visitStmt2R1N(ADD_INT_LIT8,1,1,1);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L9);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L7);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m008_getAttribute(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/xml/XmlParser$Node;","getAttribute",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(539,L0);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2,0},new Method("Lorg/mortbay/xml/XmlParser$Node;","getAttribute",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m009_getAttribute(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/xml/XmlParser$Node;","getAttribute",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                ddv.visitParameterName(1,"dft");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(550,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(555,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(552,L2);
                DexLabel L3=new DexLabel();
                ddv.visitStartLocal(0,L3,"i","I",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(553,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(554,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(552,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(555,L7);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/xml/XmlParser$Node;","_attrs","[Lorg/mortbay/xml/XmlParser$Attribute;"));
                DexLabel L8=new DexLabel();
                code.visitJumpStmt(IF_EQZ,1,-1,L8);
                code.visitJumpStmt(IF_NEZ,3,-1,L2);
                code.visitLabel(L8);
                code.visitStmt2R(MOVE_OBJECT,1,4);
                code.visitLabel(L1);
                code.visitStmt1R(RETURN_OBJECT,1);
                code.visitLabel(L2);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/xml/XmlParser$Node;","_attrs","[Lorg/mortbay/xml/XmlParser$Attribute;"));
                code.visitStmt2R(ARRAY_LENGTH,1,1);
                DexLabel L9=new DexLabel();
                code.visitJumpStmt(IF_GE,0,1,L9);
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/xml/XmlParser$Node;","_attrs","[Lorg/mortbay/xml/XmlParser$Attribute;"));
                code.visitStmt3R(AGET_OBJECT,1,1,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/xml/XmlParser$Attribute;","getName",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,1},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_EQZ,1,-1,L6);
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/xml/XmlParser$Node;","_attrs","[Lorg/mortbay/xml/XmlParser$Attribute;"));
                code.visitStmt3R(AGET_OBJECT,1,1,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/xml/XmlParser$Attribute;","getValue",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitLabel(L6);
                code.visitStmt2R1N(ADD_INT_LIT8,0,0,1);
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitLabel(L9);
                code.visitStmt2R(MOVE_OBJECT,1,4);
                code.visitLabel(L7);
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m010_getAttributes(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/xml/XmlParser$Node;","getAttributes",new String[]{ },"[Lorg/mortbay/xml/XmlParser$Attribute;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(528,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/xml/XmlParser$Node;","_attrs","[Lorg/mortbay/xml/XmlParser$Attribute;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m011_getParent(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/xml/XmlParser$Node;","getParent",new String[]{ },"Lorg/mortbay/xml/XmlParser$Node;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(500,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/xml/XmlParser$Node;","_parent","Lorg/mortbay/xml/XmlParser$Node;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m012_getPath(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/xml/XmlParser$Node;","getPath",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(512,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(514,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(515,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(519,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(517,L5);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_STRING,2,"/");
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/xml/XmlParser$Node;","_path","Ljava/lang/String;"));
                code.visitJumpStmt(IF_NEZ,0,-1,L4);
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/xml/XmlParser$Node;","getParent",new String[]{ },"Lorg/mortbay/xml/XmlParser$Node;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/xml/XmlParser$Node;","getParent",new String[]{ },"Lorg/mortbay/xml/XmlParser$Node;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/xml/XmlParser$Node;","getTag",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L5);
                code.visitLabel(L3);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/xml/XmlParser$Node;","getParent",new String[]{ },"Lorg/mortbay/xml/XmlParser$Node;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/xml/XmlParser$Node;","getPath",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitConstStmt(CONST_STRING,1,"/");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/xml/XmlParser$Node;","_tag","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IPUT_OBJECT,0,3,new Field("Lorg/mortbay/xml/XmlParser$Node;","_path","Ljava/lang/String;"));
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/xml/XmlParser$Node;","_path","Ljava/lang/String;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L5);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,1,"/");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/xml/XmlParser$Node;","_tag","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IPUT_OBJECT,0,3,new Field("Lorg/mortbay/xml/XmlParser$Node;","_path","Ljava/lang/String;"));
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m013_getString(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/xml/XmlParser$Node;","getString",new String[]{ "Ljava/lang/String;","Z","Z"},"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"tag");
                ddv.visitParameterName(1,"tags");
                ddv.visitParameterName(2,"trim");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(649,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(650,L1);
                ddv.visitStartLocal(0,L1,"node","Lorg/mortbay/xml/XmlParser$Node;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(651,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(655,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(652,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(653,L5);
                ddv.visitStartLocal(1,L5,"s","Ljava/lang/String;",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(654,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(655,L7);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Lorg/mortbay/xml/XmlParser$Node;","get",new String[]{ "Ljava/lang/String;"},"Lorg/mortbay/xml/XmlParser$Node;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L1);
                code.visitJumpStmt(IF_NEZ,0,-1,L4);
                code.visitLabel(L2);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L3);
                code.visitStmt1R(RETURN_OBJECT,2);
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,5},new Method("Lorg/mortbay/xml/XmlParser$Node;","toString",new String[]{ "Z"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L5);
                DexLabel L8=new DexLabel();
                code.visitJumpStmt(IF_EQZ,1,-1,L8);
                code.visitJumpStmt(IF_EQZ,6,-1,L8);
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/lang/String;","trim",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L8);
                code.visitStmt2R(MOVE_OBJECT,2,1);
                code.visitLabel(L7);
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m014_getTag(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/xml/XmlParser$Node;","getTag",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(506,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/xml/XmlParser$Node;","_tag","Ljava/lang/String;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m015_iterator(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/xml/XmlParser$Node;","iterator",new String[]{ "Ljava/lang/String;"},"Ljava/util/Iterator;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"tag");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(749,L0);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/xml/XmlParser$Node$1;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1,2},new Method("Lorg/mortbay/xml/XmlParser$Node$1;","<init>",new String[]{ "Lorg/mortbay/xml/XmlParser$Node;","Ljava/lang/String;"},"V"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m016_size(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/xml/XmlParser$Node;","size",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(564,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(565,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(566,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/xml/XmlParser$Node;","_list","Ljava/util/ArrayList;"));
                DexLabel L3=new DexLabel();
                code.visitJumpStmt(IF_EQZ,0,-1,L3);
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/xml/XmlParser$Node;","_list","Ljava/util/ArrayList;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/util/ArrayList;","size",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitLabel(L2);
                code.visitStmt1R(RETURN,0);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m017_toString(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/xml/XmlParser$Node;","toString",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(661,L3);
                code.visitLabel(L3);
                code.visitStmt1R(MONITOR_ENTER,1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,0},new Method("Lorg/mortbay/xml/XmlParser$Node;","toString",new String[]{ "Z"},"Ljava/lang/String;"));
                code.visitLabel(L1);
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt1R(MONITOR_EXIT,1);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,0);
                code.visitStmt1R(MONITOR_EXIT,1);
                code.visitStmt1R(THROW,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m018_toString(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/xml/XmlParser$Node;","toString",new String[]{ "Z"},"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                code.visitTryCatch(L1,L3,new DexLabel[]{L4},new String[]{ null});
                DexLabel L5=new DexLabel();
                DexLabel L6=new DexLabel();
                code.visitTryCatch(L5,L6,new DexLabel[]{L4},new String[]{ null});
                code.visitTryCatch(L6,L2,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"tag");
                DexLabel L7=new DexLabel();
                ddv.visitPrologue(L7);
                ddv.visitLineNumber(672,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(673,L8);
                ddv.visitStartLocal(0,L8,"buf","Ljava/lang/StringBuffer;",null);
                ddv.visitLineNumber(675,L1);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(676,L9);
                ddv.visitLineNumber(677,L4);
                ddv.visitLineNumber(672,L2);
                ddv.visitEndLocal(0,L2);
                code.visitLabel(L7);
                code.visitStmt1R(MONITOR_ENTER,2);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/StringBuffer;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/StringBuffer;","<init>",new String[]{ },"V"));
                code.visitLabel(L8);
                code.visitStmt1R(MONITOR_ENTER,0);
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2,0,3},new Method("Lorg/mortbay/xml/XmlParser$Node;","toString",new String[]{ "Ljava/lang/StringBuffer;","Z"},"V"));
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/StringBuffer;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitStmt1R(MONITOR_EXIT,0);
                code.visitLabel(L3);
                code.visitStmt1R(MONITOR_EXIT,2);
                code.visitStmt1R(RETURN_OBJECT,1);
                code.visitLabel(L4);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitLabel(L5);
                code.visitStmt1R(MONITOR_EXIT,0);
                code.visitLabel(L6);
                code.visitStmt1R(THROW,1);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitStmt1R(MONITOR_EXIT,2);
                code.visitStmt1R(THROW,1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m019_toString(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/xml/XmlParser$Node;","toString",new String[]{ "Z","Z"},"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"tag");
                ddv.visitParameterName(1,"trim");
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(688,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(689,L4);
                ddv.visitStartLocal(0,L4,"s","Ljava/lang/String;",null);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(690,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(691,L6);
                ddv.visitLineNumber(688,L2);
                ddv.visitEndLocal(0,L2);
                code.visitLabel(L3);
                code.visitStmt1R(MONITOR_ENTER,2);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Lorg/mortbay/xml/XmlParser$Node;","toString",new String[]{ "Z"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L4);
                code.visitJumpStmt(IF_EQZ,0,-1,L6);
                code.visitJumpStmt(IF_EQZ,4,-1,L6);
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/String;","trim",new String[]{ },"Ljava/lang/String;"));
                code.visitLabel(L1);
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L6);
                code.visitStmt1R(MONITOR_EXIT,2);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitStmt1R(MONITOR_EXIT,2);
                code.visitStmt1R(THROW,1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
