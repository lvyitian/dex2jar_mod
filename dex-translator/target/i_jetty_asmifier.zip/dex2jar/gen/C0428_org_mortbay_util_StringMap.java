package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0428_org_mortbay_util_StringMap {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/util/StringMap;","Ljava/util/AbstractMap;",new String[]{ "Ljava/io/Externalizable;"});
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("StringMap.java");
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/MemberClasses;", Visibility.SYSTEM);
            if(av00 != null) {
                {
                    DexAnnotationVisitor av01 = av00.visitArray("value");
                    if(av01 != null) {
                        av01.visit(null, new DexType("Lorg/mortbay/util/StringMap$1;"));
                        av01.visit(null, new DexType("Lorg/mortbay/util/StringMap$NullEntry;"));
                        av01.visit(null, new DexType("Lorg/mortbay/util/StringMap$Node;"));
                        av01.visitEnd();
                    }
                }
                av00.visitEnd();
            }
        }
        f000_CASE_INSENSTIVE(cv);
        f001___HASH_WIDTH(cv);
        f002__entrySet(cv);
        f003__ignoreCase(cv);
        f004__nullEntry(cv);
        f005__nullValue(cv);
        f006__root(cv);
        f007__umEntrySet(cv);
        f008__width(cv);
        m000__init_(cv);
        m001__init_(cv);
        m002__init_(cv);
        m003_clear(cv);
        m004_containsKey(cv);
        m005_entrySet(cv);
        m006_get(cv);
        m007_get(cv);
        m008_getBestEntry(cv);
        m009_getEntry(cv);
        m010_getEntry(cv);
        m011_getWidth(cv);
        m012_isEmpty(cv);
        m013_isIgnoreCase(cv);
        m014_put(cv);
        m015_put(cv);
        m016_readExternal(cv);
        m017_remove(cv);
        m018_remove(cv);
        m019_setIgnoreCase(cv);
        m020_setWidth(cv);
        m021_size(cv);
        m022_writeExternal(cv);
    }
    public static void f000_CASE_INSENSTIVE(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/util/StringMap;","CASE_INSENSTIVE","Z"), Boolean.valueOf(true));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001___HASH_WIDTH(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/util/StringMap;","__HASH_WIDTH","I"),  Integer.valueOf(17));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002__entrySet(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/util/StringMap;","_entrySet","Ljava/util/HashSet;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003__ignoreCase(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/util/StringMap;","_ignoreCase","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f004__nullEntry(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/util/StringMap;","_nullEntry","Lorg/mortbay/util/StringMap$NullEntry;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f005__nullValue(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/util/StringMap;","_nullValue","Ljava/lang/Object;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f006__root(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/util/StringMap;","_root","Lorg/mortbay/util/StringMap$Node;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f007__umEntrySet(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/util/StringMap;","_umEntrySet","Ljava/util/Set;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f008__width(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/util/StringMap;","_width","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/util/StringMap;","<init>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(57,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(45,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(46,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(47,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(48,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(49,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(50,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(51,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(57,L9);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2},new Method("Ljava/util/AbstractMap;","<init>",new String[]{ },"V"));
                code.visitLabel(L2);
                code.visitConstStmt(CONST_16,0, Integer.valueOf(17)); // int: 0x00000011  float:0.000000
                code.visitFieldStmt(IPUT,0,2,new Field("Lorg/mortbay/util/StringMap;","_width","I"));
                code.visitLabel(L3);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/util/StringMap$Node;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Lorg/mortbay/util/StringMap$Node;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/util/StringMap;","_root","Lorg/mortbay/util/StringMap$Node;"));
                code.visitLabel(L4);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_BOOLEAN,0,2,new Field("Lorg/mortbay/util/StringMap;","_ignoreCase","Z"));
                code.visitLabel(L5);
                code.visitFieldStmt(IPUT_OBJECT,1,2,new Field("Lorg/mortbay/util/StringMap;","_nullEntry","Lorg/mortbay/util/StringMap$NullEntry;"));
                code.visitLabel(L6);
                code.visitFieldStmt(IPUT_OBJECT,1,2,new Field("Lorg/mortbay/util/StringMap;","_nullValue","Ljava/lang/Object;"));
                code.visitLabel(L7);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/util/HashSet;");
                code.visitConstStmt(CONST_4,1, Integer.valueOf(3)); // int: 0x00000003  float:0.000000
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Ljava/util/HashSet;","<init>",new String[]{ "I"},"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/util/StringMap;","_entrySet","Ljava/util/HashSet;"));
                code.visitLabel(L8);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/util/StringMap;","_entrySet","Ljava/util/HashSet;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Ljava/util/Collections;","unmodifiableSet",new String[]{ "Ljava/util/Set;"},"Ljava/util/Set;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/util/StringMap;","_umEntrySet","Ljava/util/Set;"));
                code.visitLabel(L9);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/util/StringMap;","<init>",new String[]{ "Z"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"ignoreCase");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(65,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(66,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(67,L2);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Lorg/mortbay/util/StringMap;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitFieldStmt(IPUT_BOOLEAN,1,0,new Field("Lorg/mortbay/util/StringMap;","_ignoreCase","Z"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/util/StringMap;","<init>",new String[]{ "Z","I"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"ignoreCase");
                ddv.visitParameterName(1,"width");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(77,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(78,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(79,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(80,L3);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Lorg/mortbay/util/StringMap;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitFieldStmt(IPUT_BOOLEAN,1,0,new Field("Lorg/mortbay/util/StringMap;","_ignoreCase","Z"));
                code.visitLabel(L2);
                code.visitFieldStmt(IPUT,2,0,new Field("Lorg/mortbay/util/StringMap;","_width","I"));
                code.visitLabel(L3);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_clear(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/StringMap;","clear",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(533,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(534,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(535,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(536,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(537,L5);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/util/StringMap$Node;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Lorg/mortbay/util/StringMap$Node;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/util/StringMap;","_root","Lorg/mortbay/util/StringMap$Node;"));
                code.visitLabel(L2);
                code.visitFieldStmt(IPUT_OBJECT,1,2,new Field("Lorg/mortbay/util/StringMap;","_nullEntry","Lorg/mortbay/util/StringMap$NullEntry;"));
                code.visitLabel(L3);
                code.visitFieldStmt(IPUT_OBJECT,1,2,new Field("Lorg/mortbay/util/StringMap;","_nullValue","Ljava/lang/Object;"));
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/util/StringMap;","_entrySet","Ljava/util/HashSet;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/util/HashSet;","clear",new String[]{ },"V"));
                code.visitLabel(L5);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_containsKey(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/StringMap;","containsKey",new String[]{ "Ljava/lang/Object;"},"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"key");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(524,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(525,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(526,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(525,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(526,L5);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitJumpStmt(IF_NEZ,5,-1,L5);
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/util/StringMap;","_nullEntry","Lorg/mortbay/util/StringMap$NullEntry;"));
                DexLabel L6=new DexLabel();
                code.visitJumpStmt(IF_EQZ,0,-1,L6);
                code.visitStmt2R(MOVE,0,3);
                code.visitLabel(L3);
                code.visitStmt1R(RETURN,0);
                code.visitLabel(L6);
                code.visitStmt2R(MOVE,0,2);
                code.visitLabel(L4);
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/lang/Object;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                DexLabel L7=new DexLabel();
                code.visitJumpStmt(IF_NEZ,5,-1,L7);
                code.visitStmt2R(MOVE,1,2);
                DexLabel L8=new DexLabel();
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,0,2,1},new Method("Lorg/mortbay/util/StringMap;","getEntry",new String[]{ "Ljava/lang/String;","I","I"},"Ljava/util/Map$Entry;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                DexLabel L9=new DexLabel();
                code.visitJumpStmt(IF_EQZ,0,-1,L9);
                code.visitStmt2R(MOVE,0,3);
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/lang/Object;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(GOTO,-1,-1,L8);
                code.visitLabel(L9);
                code.visitStmt2R(MOVE,0,2);
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_entrySet(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/StringMap;","entrySet",new String[]{ },"Ljava/util/Set;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(506,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/util/StringMap;","_umEntrySet","Ljava/util/Set;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_get(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/StringMap;","get",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/Object;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"key");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(237,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(238,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(241,L2);
                ddv.visitEndLocal(2,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(239,L3);
                ddv.visitRestartLocal(2,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(240,L4);
                DexLabel L5=new DexLabel();
                ddv.visitEndLocal(2,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(241,L6);
                ddv.visitRestartLocal(2,L6);
                code.visitLabel(L0);
                code.visitJumpStmt(IF_NEZ,2,-1,L3);
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/util/StringMap;","_nullValue","Ljava/lang/Object;"));
                code.visitLabel(L2);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L3);
                code.visitTypeStmt(INSTANCE_OF,0,2,"Ljava/lang/String;");
                code.visitJumpStmt(IF_EQZ,0,-1,L6);
                code.visitLabel(L4);
                code.visitTypeStmt(CHECK_CAST,2,-1,"Ljava/lang/String;");
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Lorg/mortbay/util/StringMap;","get",new String[]{ "Ljava/lang/String;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/lang/Object;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,0},new Method("Lorg/mortbay/util/StringMap;","get",new String[]{ "Ljava/lang/String;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m007_get(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/StringMap;","get",new String[]{ "Ljava/lang/String;"},"Ljava/lang/Object;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"key");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(247,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(248,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(253,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(250,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(251,L4);
                ddv.visitStartLocal(0,L4,"entry","Ljava/util/Map$Entry;",null);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(252,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(253,L6);
                code.visitLabel(L0);
                code.visitJumpStmt(IF_NEZ,4,-1,L3);
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/util/StringMap;","_nullValue","Ljava/lang/Object;"));
                code.visitLabel(L2);
                code.visitStmt1R(RETURN_OBJECT,1);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4,1,2},new Method("Lorg/mortbay/util/StringMap;","getEntry",new String[]{ "Ljava/lang/String;","I","I"},"Ljava/util/Map$Entry;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L4);
                code.visitJumpStmt(IF_NEZ,0,-1,L6);
                code.visitLabel(L5);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Ljava/util/Map$Entry;","getValue",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m008_getBestEntry(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/StringMap;","getBestEntry",new String[]{ "[B","I","I"},"Ljava/util/Map$Entry;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(12);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"key");
                ddv.visitParameterName(1,"offset");
                ddv.visitParameterName(2,"maxLength");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(379,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(380,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(427,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(382,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(383,L5);
                ddv.visitStartLocal(4,L5,"node","Lorg/mortbay/util/StringMap$Node;",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(387,L6);
                ddv.visitStartLocal(3,L6,"ni","I",null);
                DexLabel L7=new DexLabel();
                ddv.visitStartLocal(2,L7,"i","I",null);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(389,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(392,L9);
                ddv.visitStartLocal(0,L9,"c","C",null);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(394,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(396,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(398,L12);
                ddv.visitStartLocal(1,L12,"child","Lorg/mortbay/util/StringMap$Node;",null);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(399,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(396,L14);
                ddv.visitEndLocal(1,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(400,L15);
                ddv.visitRestartLocal(1,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(404,L16);
                ddv.visitEndLocal(1,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(407,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(409,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(410,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(411,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(387,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(416,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(419,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(421,L24);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(424,L25);
                ddv.visitEndLocal(0,L25);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(425,L26);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(426,L27);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(427,L28);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,7, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitJumpStmt(IF_NEZ,9,-1,L4);
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,5,8,new Field("Lorg/mortbay/util/StringMap;","_nullEntry","Lorg/mortbay/util/StringMap$NullEntry;"));
                code.visitLabel(L3);
                code.visitStmt1R(RETURN_OBJECT,5);
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,4,8,new Field("Lorg/mortbay/util/StringMap;","_root","Lorg/mortbay/util/StringMap$Node;"));
                code.visitLabel(L5);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(-1)); // int: 0xffffffff  float:NaN
                code.visitLabel(L6);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L7);
                code.visitJumpStmt(IF_GE,2,11,L25);
                code.visitLabel(L8);
                code.visitStmt3R(ADD_INT,5,10,2);
                code.visitStmt3R(AGET_BYTE,5,9,5);
                code.visitStmt2R(INT_TO_CHAR,0,5);
                code.visitLabel(L9);
                code.visitConstStmt(CONST_4,5, Integer.valueOf(-1)); // int: 0xffffffff  float:NaN
                code.visitJumpStmt(IF_NE,3,5,L16);
                code.visitLabel(L10);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L11);
                code.visitFieldStmt(IGET_OBJECT,5,4,new Field("Lorg/mortbay/util/StringMap$Node;","_children","[Lorg/mortbay/util/StringMap$Node;"));
                code.visitJumpStmt(IF_NEZ,5,-1,L14);
                code.visitStmt2R(MOVE_OBJECT,1,7);
                code.visitLabel(L12);
                code.visitJumpStmt(IF_NEZ,1,-1,L15);
                code.visitJumpStmt(IF_LEZ,2,-1,L15);
                code.visitStmt2R(MOVE_OBJECT,5,4);
                code.visitLabel(L13);
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitLabel(L14);
                code.visitFieldStmt(IGET_OBJECT,5,4,new Field("Lorg/mortbay/util/StringMap$Node;","_children","[Lorg/mortbay/util/StringMap$Node;"));
                code.visitFieldStmt(IGET,6,8,new Field("Lorg/mortbay/util/StringMap;","_width","I"));
                code.visitStmt3R(REM_INT,6,0,6);
                code.visitStmt3R(AGET_OBJECT,5,5,6);
                code.visitStmt2R(MOVE_OBJECT,1,5);
                code.visitJumpStmt(GOTO,-1,-1,L12);
                code.visitLabel(L15);
                code.visitStmt2R(MOVE_OBJECT,4,1);
                code.visitLabel(L16);
                DexLabel L29=new DexLabel();
                code.visitJumpStmt(IF_EQZ,4,-1,L29);
                code.visitLabel(L17);
                code.visitFieldStmt(IGET_OBJECT,5,4,new Field("Lorg/mortbay/util/StringMap$Node;","_char","[C"));
                code.visitStmt3R(AGET_CHAR,5,5,3);
                code.visitJumpStmt(IF_EQ,5,0,L18);
                code.visitFieldStmt(IGET_BOOLEAN,5,8,new Field("Lorg/mortbay/util/StringMap;","_ignoreCase","Z"));
                code.visitJumpStmt(IF_EQZ,5,-1,L22);
                code.visitFieldStmt(IGET_OBJECT,5,4,new Field("Lorg/mortbay/util/StringMap$Node;","_ochar","[C"));
                code.visitStmt3R(AGET_CHAR,5,5,3);
                code.visitJumpStmt(IF_NE,5,0,L22);
                code.visitLabel(L18);
                code.visitStmt2R1N(ADD_INT_LIT8,3,3,1);
                code.visitLabel(L19);
                code.visitFieldStmt(IGET_OBJECT,5,4,new Field("Lorg/mortbay/util/StringMap$Node;","_char","[C"));
                code.visitStmt2R(ARRAY_LENGTH,5,5);
                code.visitJumpStmt(IF_NE,3,5,L21);
                code.visitLabel(L20);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(-1)); // int: 0xffffffff  float:NaN
                code.visitLabel(L21);
                code.visitStmt2R1N(ADD_INT_LIT8,2,2,1);
                code.visitJumpStmt(GOTO,-1,-1,L7);
                code.visitLabel(L22);
                code.visitJumpStmt(IF_LEZ,3,-1,L23);
                code.visitStmt2R(MOVE_OBJECT,5,7);
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitLabel(L23);
                code.visitFieldStmt(IGET_OBJECT,4,4,new Field("Lorg/mortbay/util/StringMap$Node;","_next","Lorg/mortbay/util/StringMap$Node;"));
                code.visitJumpStmt(GOTO,-1,-1,L16);
                code.visitLabel(L29);
                code.visitStmt2R(MOVE_OBJECT,5,7);
                code.visitLabel(L24);
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitLabel(L25);
                code.visitJumpStmt(IF_LEZ,3,-1,L26);
                code.visitStmt2R(MOVE_OBJECT,5,7);
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitLabel(L26);
                DexLabel L30=new DexLabel();
                code.visitJumpStmt(IF_EQZ,4,-1,L30);
                code.visitFieldStmt(IGET_OBJECT,5,4,new Field("Lorg/mortbay/util/StringMap$Node;","_key","Ljava/lang/String;"));
                code.visitJumpStmt(IF_NEZ,5,-1,L30);
                code.visitStmt2R(MOVE_OBJECT,5,7);
                code.visitLabel(L27);
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitLabel(L30);
                code.visitStmt2R(MOVE_OBJECT,5,4);
                code.visitLabel(L28);
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m009_getEntry(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/StringMap;","getEntry",new String[]{ "Ljava/lang/String;","I","I"},"Ljava/util/Map$Entry;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(11);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"key");
                ddv.visitParameterName(1,"offset");
                ddv.visitParameterName(2,"length");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(266,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(267,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(309,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(269,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(270,L5);
                ddv.visitStartLocal(3,L5,"node","Lorg/mortbay/util/StringMap$Node;",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(274,L6);
                ddv.visitStartLocal(2,L6,"ni","I",null);
                DexLabel L7=new DexLabel();
                ddv.visitStartLocal(1,L7,"i","I",null);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(276,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(279,L9);
                ddv.visitStartLocal(0,L9,"c","C",null);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(281,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(282,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(286,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(289,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(291,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(292,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(293,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(274,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(282,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(298,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(301,L20);
                DexLabel L21=new DexLabel();
                ddv.visitRestartLocal(3,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(303,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(306,L23);
                ddv.visitEndLocal(0,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(307,L24);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(308,L25);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(309,L26);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,6, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitJumpStmt(IF_NEZ,8,-1,L4);
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,4,7,new Field("Lorg/mortbay/util/StringMap;","_nullEntry","Lorg/mortbay/util/StringMap$NullEntry;"));
                code.visitLabel(L3);
                code.visitStmt1R(RETURN_OBJECT,4);
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,3,7,new Field("Lorg/mortbay/util/StringMap;","_root","Lorg/mortbay/util/StringMap$Node;"));
                code.visitLabel(L5);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(-1)); // int: 0xffffffff  float:NaN
                code.visitLabel(L6);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L7);
                code.visitJumpStmt(IF_GE,1,10,L23);
                code.visitLabel(L8);
                code.visitStmt3R(ADD_INT,4,9,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,4},new Method("Ljava/lang/String;","charAt",new String[]{ "I"},"C"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitLabel(L9);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(-1)); // int: 0xffffffff  float:NaN
                code.visitJumpStmt(IF_NE,2,4,L12);
                code.visitLabel(L10);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L11);
                code.visitFieldStmt(IGET_OBJECT,4,3,new Field("Lorg/mortbay/util/StringMap$Node;","_children","[Lorg/mortbay/util/StringMap$Node;"));
                code.visitJumpStmt(IF_NEZ,4,-1,L18);
                code.visitStmt2R(MOVE_OBJECT,3,6);
                code.visitLabel(L12);
                DexLabel L27=new DexLabel();
                code.visitJumpStmt(IF_EQZ,3,-1,L27);
                code.visitLabel(L13);
                code.visitFieldStmt(IGET_OBJECT,4,3,new Field("Lorg/mortbay/util/StringMap$Node;","_char","[C"));
                code.visitStmt3R(AGET_CHAR,4,4,2);
                code.visitJumpStmt(IF_EQ,4,0,L14);
                code.visitFieldStmt(IGET_BOOLEAN,4,7,new Field("Lorg/mortbay/util/StringMap;","_ignoreCase","Z"));
                code.visitJumpStmt(IF_EQZ,4,-1,L19);
                code.visitFieldStmt(IGET_OBJECT,4,3,new Field("Lorg/mortbay/util/StringMap$Node;","_ochar","[C"));
                code.visitStmt3R(AGET_CHAR,4,4,2);
                code.visitJumpStmt(IF_NE,4,0,L19);
                code.visitLabel(L14);
                code.visitStmt2R1N(ADD_INT_LIT8,2,2,1);
                code.visitLabel(L15);
                code.visitFieldStmt(IGET_OBJECT,4,3,new Field("Lorg/mortbay/util/StringMap$Node;","_char","[C"));
                code.visitStmt2R(ARRAY_LENGTH,4,4);
                code.visitJumpStmt(IF_NE,2,4,L17);
                code.visitLabel(L16);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(-1)); // int: 0xffffffff  float:NaN
                code.visitLabel(L17);
                code.visitStmt2R1N(ADD_INT_LIT8,1,1,1);
                code.visitJumpStmt(GOTO,-1,-1,L7);
                code.visitLabel(L18);
                code.visitFieldStmt(IGET_OBJECT,4,3,new Field("Lorg/mortbay/util/StringMap$Node;","_children","[Lorg/mortbay/util/StringMap$Node;"));
                code.visitFieldStmt(IGET,5,7,new Field("Lorg/mortbay/util/StringMap;","_width","I"));
                code.visitStmt3R(REM_INT,5,0,5);
                code.visitStmt3R(AGET_OBJECT,4,4,5);
                code.visitStmt2R(MOVE_OBJECT,3,4);
                code.visitJumpStmt(GOTO,-1,-1,L12);
                code.visitLabel(L19);
                code.visitJumpStmt(IF_LEZ,2,-1,L20);
                code.visitStmt2R(MOVE_OBJECT,4,6);
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitLabel(L20);
                code.visitFieldStmt(IGET_OBJECT,3,3,new Field("Lorg/mortbay/util/StringMap$Node;","_next","Lorg/mortbay/util/StringMap$Node;"));
                code.visitLabel(L21);
                code.visitJumpStmt(GOTO,-1,-1,L12);
                code.visitLabel(L27);
                code.visitStmt2R(MOVE_OBJECT,4,6);
                code.visitLabel(L22);
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitLabel(L23);
                code.visitJumpStmt(IF_LEZ,2,-1,L24);
                code.visitStmt2R(MOVE_OBJECT,4,6);
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitLabel(L24);
                DexLabel L28=new DexLabel();
                code.visitJumpStmt(IF_EQZ,3,-1,L28);
                code.visitFieldStmt(IGET_OBJECT,4,3,new Field("Lorg/mortbay/util/StringMap$Node;","_key","Ljava/lang/String;"));
                code.visitJumpStmt(IF_NEZ,4,-1,L28);
                code.visitStmt2R(MOVE_OBJECT,4,6);
                code.visitLabel(L25);
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitLabel(L28);
                code.visitStmt2R(MOVE_OBJECT,4,3);
                code.visitLabel(L26);
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m010_getEntry(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/StringMap;","getEntry",new String[]{ "[C","I","I"},"Ljava/util/Map$Entry;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(11);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"key");
                ddv.visitParameterName(1,"offset");
                ddv.visitParameterName(2,"length");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(322,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(323,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(365,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(325,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(326,L5);
                ddv.visitStartLocal(3,L5,"node","Lorg/mortbay/util/StringMap$Node;",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(330,L6);
                ddv.visitStartLocal(2,L6,"ni","I",null);
                DexLabel L7=new DexLabel();
                ddv.visitStartLocal(1,L7,"i","I",null);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(332,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(335,L9);
                ddv.visitStartLocal(0,L9,"c","C",null);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(337,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(338,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(342,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(345,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(347,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(348,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(349,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(330,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(338,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(354,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(357,L20);
                DexLabel L21=new DexLabel();
                ddv.visitRestartLocal(3,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(359,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(362,L23);
                ddv.visitEndLocal(0,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(363,L24);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(364,L25);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(365,L26);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,6, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitJumpStmt(IF_NEZ,8,-1,L4);
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,4,7,new Field("Lorg/mortbay/util/StringMap;","_nullEntry","Lorg/mortbay/util/StringMap$NullEntry;"));
                code.visitLabel(L3);
                code.visitStmt1R(RETURN_OBJECT,4);
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,3,7,new Field("Lorg/mortbay/util/StringMap;","_root","Lorg/mortbay/util/StringMap$Node;"));
                code.visitLabel(L5);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(-1)); // int: 0xffffffff  float:NaN
                code.visitLabel(L6);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L7);
                code.visitJumpStmt(IF_GE,1,10,L23);
                code.visitLabel(L8);
                code.visitStmt3R(ADD_INT,4,9,1);
                code.visitStmt3R(AGET_CHAR,0,8,4);
                code.visitLabel(L9);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(-1)); // int: 0xffffffff  float:NaN
                code.visitJumpStmt(IF_NE,2,4,L12);
                code.visitLabel(L10);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L11);
                code.visitFieldStmt(IGET_OBJECT,4,3,new Field("Lorg/mortbay/util/StringMap$Node;","_children","[Lorg/mortbay/util/StringMap$Node;"));
                code.visitJumpStmt(IF_NEZ,4,-1,L18);
                code.visitStmt2R(MOVE_OBJECT,3,6);
                code.visitLabel(L12);
                DexLabel L27=new DexLabel();
                code.visitJumpStmt(IF_EQZ,3,-1,L27);
                code.visitLabel(L13);
                code.visitFieldStmt(IGET_OBJECT,4,3,new Field("Lorg/mortbay/util/StringMap$Node;","_char","[C"));
                code.visitStmt3R(AGET_CHAR,4,4,2);
                code.visitJumpStmt(IF_EQ,4,0,L14);
                code.visitFieldStmt(IGET_BOOLEAN,4,7,new Field("Lorg/mortbay/util/StringMap;","_ignoreCase","Z"));
                code.visitJumpStmt(IF_EQZ,4,-1,L19);
                code.visitFieldStmt(IGET_OBJECT,4,3,new Field("Lorg/mortbay/util/StringMap$Node;","_ochar","[C"));
                code.visitStmt3R(AGET_CHAR,4,4,2);
                code.visitJumpStmt(IF_NE,4,0,L19);
                code.visitLabel(L14);
                code.visitStmt2R1N(ADD_INT_LIT8,2,2,1);
                code.visitLabel(L15);
                code.visitFieldStmt(IGET_OBJECT,4,3,new Field("Lorg/mortbay/util/StringMap$Node;","_char","[C"));
                code.visitStmt2R(ARRAY_LENGTH,4,4);
                code.visitJumpStmt(IF_NE,2,4,L17);
                code.visitLabel(L16);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(-1)); // int: 0xffffffff  float:NaN
                code.visitLabel(L17);
                code.visitStmt2R1N(ADD_INT_LIT8,1,1,1);
                code.visitJumpStmt(GOTO,-1,-1,L7);
                code.visitLabel(L18);
                code.visitFieldStmt(IGET_OBJECT,4,3,new Field("Lorg/mortbay/util/StringMap$Node;","_children","[Lorg/mortbay/util/StringMap$Node;"));
                code.visitFieldStmt(IGET,5,7,new Field("Lorg/mortbay/util/StringMap;","_width","I"));
                code.visitStmt3R(REM_INT,5,0,5);
                code.visitStmt3R(AGET_OBJECT,4,4,5);
                code.visitStmt2R(MOVE_OBJECT,3,4);
                code.visitJumpStmt(GOTO,-1,-1,L12);
                code.visitLabel(L19);
                code.visitJumpStmt(IF_LEZ,2,-1,L20);
                code.visitStmt2R(MOVE_OBJECT,4,6);
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitLabel(L20);
                code.visitFieldStmt(IGET_OBJECT,3,3,new Field("Lorg/mortbay/util/StringMap$Node;","_next","Lorg/mortbay/util/StringMap$Node;"));
                code.visitLabel(L21);
                code.visitJumpStmt(GOTO,-1,-1,L12);
                code.visitLabel(L27);
                code.visitStmt2R(MOVE_OBJECT,4,6);
                code.visitLabel(L22);
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitLabel(L23);
                code.visitJumpStmt(IF_LEZ,2,-1,L24);
                code.visitStmt2R(MOVE_OBJECT,4,6);
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitLabel(L24);
                DexLabel L28=new DexLabel();
                code.visitJumpStmt(IF_EQZ,3,-1,L28);
                code.visitFieldStmt(IGET_OBJECT,4,3,new Field("Lorg/mortbay/util/StringMap$Node;","_key","Ljava/lang/String;"));
                code.visitJumpStmt(IF_NEZ,4,-1,L28);
                code.visitStmt2R(MOVE_OBJECT,4,6);
                code.visitLabel(L25);
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitLabel(L28);
                code.visitStmt2R(MOVE_OBJECT,4,3);
                code.visitLabel(L26);
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m011_getWidth(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/StringMap;","getWidth",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(112,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,1,new Field("Lorg/mortbay/util/StringMap;","_width","I"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m012_isEmpty(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/StringMap;","isEmpty",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(518,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/util/StringMap;","_entrySet","Ljava/util/HashSet;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/util/HashSet;","isEmpty",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m013_isIgnoreCase(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/StringMap;","isIgnoreCase",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(96,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_BOOLEAN,0,1,new Field("Lorg/mortbay/util/StringMap;","_ignoreCase","Z"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m014_put(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/StringMap;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"key");
                ddv.visitParameterName(1,"value");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(118,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(119,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(120,L2);
                code.visitLabel(L0);
                DexLabel L3=new DexLabel();
                code.visitJumpStmt(IF_NEZ,2,-1,L3);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,0,3},new Method("Lorg/mortbay/util/StringMap;","put",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L2);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/lang/Object;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,0,3},new Method("Lorg/mortbay/util/StringMap;","put",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m015_put(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/StringMap;","put",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(15);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"key");
                ddv.visitParameterName(1,"value");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(126,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(128,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(129,L2);
                ddv.visitStartLocal(7,L2,"oldValue","Ljava/lang/Object;",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(130,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(132,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(133,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(231,L6);
                ddv.visitEndLocal(7,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(138,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(139,L8);
                ddv.visitStartLocal(4,L8,"node","Lorg/mortbay/util/StringMap$Node;",null);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(140,L9);
                ddv.visitStartLocal(3,L9,"ni","I",null);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(141,L10);
                ddv.visitStartLocal(9,L10,"prev","Lorg/mortbay/util/StringMap$Node;",null);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(145,L11);
                ddv.visitStartLocal(8,L11,"parent","Lorg/mortbay/util/StringMap$Node;",null);
                DexLabel L12=new DexLabel();
                ddv.visitStartLocal(1,L12,"i","I",null);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(147,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(150,L14);
                ddv.visitStartLocal(0,L14,"c","C",null);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(152,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(153,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(154,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(155,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(159,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(162,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(164,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(165,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(166,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(167,L24);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(145,L25);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(155,L26);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(173,L27);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(176,L28);
                DexLabel L29=new DexLabel();
                ddv.visitLineNumber(177,L29);
                DexLabel L30=new DexLabel();
                ddv.visitRestartLocal(4,L30);
                DexLabel L31=new DexLabel();
                ddv.visitLineNumber(182,L31);
                DexLabel L32=new DexLabel();
                ddv.visitLineNumber(183,L32);
                DexLabel L33=new DexLabel();
                ddv.visitLineNumber(184,L33);
                DexLabel L34=new DexLabel();
                ddv.visitLineNumber(185,L34);
                DexLabel L35=new DexLabel();
                ddv.visitLineNumber(190,L35);
                DexLabel L36=new DexLabel();
                ddv.visitEndLocal(4,L36);
                DexLabel L37=new DexLabel();
                ddv.visitLineNumber(192,L37);
                ddv.visitRestartLocal(4,L37);
                DexLabel L38=new DexLabel();
                ddv.visitLineNumber(193,L38);
                DexLabel L39=new DexLabel();
                ddv.visitLineNumber(219,L39);
                ddv.visitEndLocal(0,L39);
                DexLabel L40=new DexLabel();
                ddv.visitLineNumber(222,L40);
                DexLabel L41=new DexLabel();
                ddv.visitLineNumber(223,L41);
                DexLabel L42=new DexLabel();
                ddv.visitLineNumber(225,L42);
                DexLabel L43=new DexLabel();
                ddv.visitLineNumber(226,L43);
                ddv.visitStartLocal(6,L43,"old","Ljava/lang/Object;",null);
                DexLabel L44=new DexLabel();
                ddv.visitLineNumber(227,L44);
                DexLabel L45=new DexLabel();
                ddv.visitLineNumber(228,L45);
                DexLabel L46=new DexLabel();
                ddv.visitLineNumber(229,L46);
                DexLabel L47=new DexLabel();
                ddv.visitLineNumber(194,L47);
                ddv.visitEndLocal(6,L47);
                ddv.visitRestartLocal(0,L47);
                DexLabel L48=new DexLabel();
                ddv.visitLineNumber(196,L48);
                DexLabel L49=new DexLabel();
                ddv.visitLineNumber(197,L49);
                DexLabel L50=new DexLabel();
                ddv.visitLineNumber(198,L50);
                DexLabel L51=new DexLabel();
                ddv.visitLineNumber(199,L51);
                DexLabel L52=new DexLabel();
                ddv.visitLineNumber(200,L52);
                ddv.visitStartLocal(5,L52,"oi","I",null);
                DexLabel L53=new DexLabel();
                ddv.visitLineNumber(202,L53);
                DexLabel L54=new DexLabel();
                ddv.visitLineNumber(203,L54);
                DexLabel L55=new DexLabel();
                ddv.visitLineNumber(206,L55);
                DexLabel L56=new DexLabel();
                ddv.visitLineNumber(207,L56);
                ddv.visitStartLocal(2,L56,"n","Lorg/mortbay/util/StringMap$Node;",null);
                DexLabel L57=new DexLabel();
                ddv.visitLineNumber(208,L57);
                DexLabel L58=new DexLabel();
                ddv.visitLineNumber(209,L58);
                DexLabel L59=new DexLabel();
                ddv.visitLineNumber(214,L59);
                ddv.visitEndLocal(5,L59);
                ddv.visitEndLocal(2,L59);
                DexLabel L60=new DexLabel();
                ddv.visitLineNumber(231,L60);
                ddv.visitEndLocal(0,L60);
                code.visitLabel(L0);
                code.visitJumpStmt(IF_NEZ,13,-1,L7);
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,7,12,new Field("Lorg/mortbay/util/StringMap;","_nullValue","Ljava/lang/Object;"));
                code.visitLabel(L2);
                code.visitFieldStmt(IPUT_OBJECT,14,12,new Field("Lorg/mortbay/util/StringMap;","_nullValue","Ljava/lang/Object;"));
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,10,12,new Field("Lorg/mortbay/util/StringMap;","_nullEntry","Lorg/mortbay/util/StringMap$NullEntry;"));
                DexLabel L61=new DexLabel();
                code.visitJumpStmt(IF_NEZ,10,-1,L61);
                code.visitLabel(L4);
                code.visitTypeStmt(NEW_INSTANCE,10,-1,"Lorg/mortbay/util/StringMap$NullEntry;");
                code.visitConstStmt(CONST_4,11, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 10,12,11},new Method("Lorg/mortbay/util/StringMap$NullEntry;","<init>",new String[]{ "Lorg/mortbay/util/StringMap;","Lorg/mortbay/util/StringMap$1;"},"V"));
                code.visitFieldStmt(IPUT_OBJECT,10,12,new Field("Lorg/mortbay/util/StringMap;","_nullEntry","Lorg/mortbay/util/StringMap$NullEntry;"));
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,10,12,new Field("Lorg/mortbay/util/StringMap;","_entrySet","Ljava/util/HashSet;"));
                code.visitFieldStmt(IGET_OBJECT,11,12,new Field("Lorg/mortbay/util/StringMap;","_nullEntry","Lorg/mortbay/util/StringMap$NullEntry;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10,11},new Method("Ljava/util/HashSet;","add",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitLabel(L61);
                code.visitStmt2R(MOVE_OBJECT,10,7);
                code.visitLabel(L6);
                code.visitStmt1R(RETURN_OBJECT,10);
                code.visitLabel(L7);
                code.visitFieldStmt(IGET_OBJECT,4,12,new Field("Lorg/mortbay/util/StringMap;","_root","Lorg/mortbay/util/StringMap$Node;"));
                code.visitLabel(L8);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(-1)); // int: 0xffffffff  float:NaN
                code.visitLabel(L9);
                code.visitConstStmt(CONST_4,9, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L10);
                code.visitConstStmt(CONST_4,8, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L11);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L12);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,10);
                code.visitJumpStmt(IF_GE,1,10,L39);
                code.visitLabel(L13);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13,1},new Method("Ljava/lang/String;","charAt",new String[]{ "I"},"C"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitLabel(L14);
                code.visitConstStmt(CONST_4,10, Integer.valueOf(-1)); // int: 0xffffffff  float:NaN
                code.visitJumpStmt(IF_NE,3,10,L19);
                code.visitLabel(L15);
                code.visitStmt2R(MOVE_OBJECT,8,4);
                code.visitLabel(L16);
                code.visitConstStmt(CONST_4,9, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L17);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L18);
                code.visitFieldStmt(IGET_OBJECT,10,4,new Field("Lorg/mortbay/util/StringMap$Node;","_children","[Lorg/mortbay/util/StringMap$Node;"));
                code.visitJumpStmt(IF_NEZ,10,-1,L26);
                code.visitConstStmt(CONST_4,10, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt2R(MOVE_OBJECT,4,10);
                code.visitLabel(L19);
                code.visitJumpStmt(IF_EQZ,4,-1,L35);
                code.visitLabel(L20);
                code.visitFieldStmt(IGET_OBJECT,10,4,new Field("Lorg/mortbay/util/StringMap$Node;","_char","[C"));
                code.visitStmt3R(AGET_CHAR,10,10,3);
                code.visitJumpStmt(IF_EQ,10,0,L21);
                code.visitFieldStmt(IGET_BOOLEAN,10,12,new Field("Lorg/mortbay/util/StringMap;","_ignoreCase","Z"));
                code.visitJumpStmt(IF_EQZ,10,-1,L27);
                code.visitFieldStmt(IGET_OBJECT,10,4,new Field("Lorg/mortbay/util/StringMap$Node;","_ochar","[C"));
                code.visitStmt3R(AGET_CHAR,10,10,3);
                code.visitJumpStmt(IF_NE,10,0,L27);
                code.visitLabel(L21);
                code.visitConstStmt(CONST_4,9, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L22);
                code.visitStmt2R1N(ADD_INT_LIT8,3,3,1);
                code.visitLabel(L23);
                code.visitFieldStmt(IGET_OBJECT,10,4,new Field("Lorg/mortbay/util/StringMap$Node;","_char","[C"));
                code.visitStmt2R(ARRAY_LENGTH,10,10);
                code.visitJumpStmt(IF_NE,3,10,L25);
                code.visitLabel(L24);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(-1)); // int: 0xffffffff  float:NaN
                code.visitLabel(L25);
                code.visitStmt2R1N(ADD_INT_LIT8,1,1,1);
                code.visitJumpStmt(GOTO,-1,-1,L12);
                code.visitLabel(L26);
                code.visitFieldStmt(IGET_OBJECT,10,4,new Field("Lorg/mortbay/util/StringMap$Node;","_children","[Lorg/mortbay/util/StringMap$Node;"));
                code.visitFieldStmt(IGET,11,12,new Field("Lorg/mortbay/util/StringMap;","_width","I"));
                code.visitStmt3R(REM_INT,11,0,11);
                code.visitStmt3R(AGET_OBJECT,10,10,11);
                code.visitStmt2R(MOVE_OBJECT,4,10);
                code.visitJumpStmt(GOTO,-1,-1,L19);
                code.visitLabel(L27);
                code.visitJumpStmt(IF_NEZ,3,-1,L31);
                code.visitLabel(L28);
                code.visitStmt2R(MOVE_OBJECT,9,4);
                code.visitLabel(L29);
                code.visitFieldStmt(IGET_OBJECT,4,4,new Field("Lorg/mortbay/util/StringMap$Node;","_next","Lorg/mortbay/util/StringMap$Node;"));
                code.visitLabel(L30);
                code.visitJumpStmt(GOTO,-1,-1,L19);
                code.visitLabel(L31);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,12,3},new Method("Lorg/mortbay/util/StringMap$Node;","split",new String[]{ "Lorg/mortbay/util/StringMap;","I"},"Lorg/mortbay/util/StringMap$Node;"));
                code.visitLabel(L32);
                code.visitStmt2R1N(ADD_INT_LIT8,1,1,-1);
                code.visitLabel(L33);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(-1)); // int: 0xffffffff  float:NaN
                code.visitLabel(L34);
                code.visitJumpStmt(GOTO,-1,-1,L25);
                code.visitLabel(L35);
                code.visitTypeStmt(NEW_INSTANCE,4,-1,"Lorg/mortbay/util/StringMap$Node;");
                code.visitLabel(L36);
                code.visitFieldStmt(IGET_BOOLEAN,10,12,new Field("Lorg/mortbay/util/StringMap;","_ignoreCase","Z"));
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4,10,13,1},new Method("Lorg/mortbay/util/StringMap$Node;","<init>",new String[]{ "Z","Ljava/lang/String;","I"},"V"));
                code.visitLabel(L37);
                code.visitJumpStmt(IF_EQZ,9,-1,L47);
                code.visitLabel(L38);
                code.visitFieldStmt(IPUT_OBJECT,4,9,new Field("Lorg/mortbay/util/StringMap$Node;","_next","Lorg/mortbay/util/StringMap$Node;"));
                code.visitLabel(L39);
                code.visitJumpStmt(IF_EQZ,4,-1,L60);
                code.visitLabel(L40);
                code.visitJumpStmt(IF_LEZ,3,-1,L42);
                code.visitLabel(L41);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,12,3},new Method("Lorg/mortbay/util/StringMap$Node;","split",new String[]{ "Lorg/mortbay/util/StringMap;","I"},"Lorg/mortbay/util/StringMap$Node;"));
                code.visitLabel(L42);
                code.visitFieldStmt(IGET_OBJECT,6,4,new Field("Lorg/mortbay/util/StringMap$Node;","_value","Ljava/lang/Object;"));
                code.visitLabel(L43);
                code.visitFieldStmt(IPUT_OBJECT,13,4,new Field("Lorg/mortbay/util/StringMap$Node;","_key","Ljava/lang/String;"));
                code.visitLabel(L44);
                code.visitFieldStmt(IPUT_OBJECT,14,4,new Field("Lorg/mortbay/util/StringMap$Node;","_value","Ljava/lang/Object;"));
                code.visitLabel(L45);
                code.visitFieldStmt(IGET_OBJECT,10,12,new Field("Lorg/mortbay/util/StringMap;","_entrySet","Ljava/util/HashSet;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10,4},new Method("Ljava/util/HashSet;","add",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt2R(MOVE_OBJECT,10,6);
                code.visitLabel(L46);
                code.visitJumpStmt(GOTO,-1,-1,L6);
                code.visitLabel(L47);
                code.visitJumpStmt(IF_EQZ,8,-1,L59);
                code.visitLabel(L48);
                code.visitFieldStmt(IGET_OBJECT,10,8,new Field("Lorg/mortbay/util/StringMap$Node;","_children","[Lorg/mortbay/util/StringMap$Node;"));
                code.visitJumpStmt(IF_NEZ,10,-1,L50);
                code.visitLabel(L49);
                code.visitFieldStmt(IGET,10,12,new Field("Lorg/mortbay/util/StringMap;","_width","I"));
                code.visitTypeStmt(NEW_ARRAY,10,10,"[Lorg/mortbay/util/StringMap$Node;");
                code.visitFieldStmt(IPUT_OBJECT,10,8,new Field("Lorg/mortbay/util/StringMap$Node;","_children","[Lorg/mortbay/util/StringMap$Node;"));
                code.visitLabel(L50);
                code.visitFieldStmt(IGET_OBJECT,10,8,new Field("Lorg/mortbay/util/StringMap$Node;","_children","[Lorg/mortbay/util/StringMap$Node;"));
                code.visitFieldStmt(IGET,11,12,new Field("Lorg/mortbay/util/StringMap;","_width","I"));
                code.visitStmt3R(REM_INT,11,0,11);
                code.visitStmt3R(APUT_OBJECT,4,10,11);
                code.visitLabel(L51);
                code.visitFieldStmt(IGET_OBJECT,10,4,new Field("Lorg/mortbay/util/StringMap$Node;","_ochar","[C"));
                code.visitConstStmt(CONST_4,11, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt3R(AGET_CHAR,10,10,11);
                code.visitFieldStmt(IGET,11,12,new Field("Lorg/mortbay/util/StringMap;","_width","I"));
                code.visitStmt3R(REM_INT,5,10,11);
                code.visitLabel(L52);
                code.visitFieldStmt(IGET_OBJECT,10,4,new Field("Lorg/mortbay/util/StringMap$Node;","_ochar","[C"));
                code.visitJumpStmt(IF_EQZ,10,-1,L39);
                code.visitFieldStmt(IGET_OBJECT,10,4,new Field("Lorg/mortbay/util/StringMap$Node;","_char","[C"));
                code.visitConstStmt(CONST_4,11, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt3R(AGET_CHAR,10,10,11);
                code.visitFieldStmt(IGET,11,12,new Field("Lorg/mortbay/util/StringMap;","_width","I"));
                code.visitStmt2R(REM_INT_2ADDR,10,11);
                code.visitJumpStmt(IF_EQ,10,5,L39);
                code.visitLabel(L53);
                code.visitFieldStmt(IGET_OBJECT,10,8,new Field("Lorg/mortbay/util/StringMap$Node;","_children","[Lorg/mortbay/util/StringMap$Node;"));
                code.visitStmt3R(AGET_OBJECT,10,10,5);
                code.visitJumpStmt(IF_NEZ,10,-1,L55);
                code.visitLabel(L54);
                code.visitFieldStmt(IGET_OBJECT,10,8,new Field("Lorg/mortbay/util/StringMap$Node;","_children","[Lorg/mortbay/util/StringMap$Node;"));
                code.visitStmt3R(APUT_OBJECT,4,10,5);
                code.visitJumpStmt(GOTO,-1,-1,L39);
                code.visitLabel(L55);
                code.visitFieldStmt(IGET_OBJECT,10,8,new Field("Lorg/mortbay/util/StringMap$Node;","_children","[Lorg/mortbay/util/StringMap$Node;"));
                code.visitStmt3R(AGET_OBJECT,2,10,5);
                code.visitLabel(L56);
                code.visitFieldStmt(IGET_OBJECT,10,2,new Field("Lorg/mortbay/util/StringMap$Node;","_next","Lorg/mortbay/util/StringMap$Node;"));
                code.visitJumpStmt(IF_EQZ,10,-1,L58);
                code.visitLabel(L57);
                code.visitFieldStmt(IGET_OBJECT,2,2,new Field("Lorg/mortbay/util/StringMap$Node;","_next","Lorg/mortbay/util/StringMap$Node;"));
                code.visitJumpStmt(GOTO,-1,-1,L56);
                code.visitLabel(L58);
                code.visitFieldStmt(IPUT_OBJECT,4,2,new Field("Lorg/mortbay/util/StringMap$Node;","_next","Lorg/mortbay/util/StringMap$Node;"));
                code.visitJumpStmt(GOTO,-1,-1,L39);
                code.visitLabel(L59);
                code.visitFieldStmt(IPUT_OBJECT,4,12,new Field("Lorg/mortbay/util/StringMap;","_root","Lorg/mortbay/util/StringMap$Node;"));
                code.visitJumpStmt(GOTO,-1,-1,L39);
                code.visitLabel(L60);
                code.visitConstStmt(CONST_4,10, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO_16,-1,-1,L6);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m016_readExternal(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/StringMap;","readExternal",new String[]{ "Ljava/io/ObjectInput;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visit(null, new DexType("Ljava/lang/ClassNotFoundException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"in");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(681,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(682,L1);
                ddv.visitStartLocal(0,L1,"ic","Z",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(683,L2);
                ddv.visitStartLocal(1,L2,"map","Ljava/util/HashMap;",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(684,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(685,L4);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3},new Method("Ljava/io/ObjectInput;","readBoolean",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3},new Method("Ljava/io/ObjectInput;","readObject",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitTypeStmt(CHECK_CAST,1,-1,"Ljava/util/HashMap;");
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,0},new Method("Lorg/mortbay/util/StringMap;","setIgnoreCase",new String[]{ "Z"},"V"));
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,1},new Method("Lorg/mortbay/util/StringMap;","putAll",new String[]{ "Ljava/util/Map;"},"V"));
                code.visitLabel(L4);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m017_remove(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/StringMap;","remove",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/Object;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"key");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(434,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(435,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(436,L2);
                code.visitLabel(L0);
                DexLabel L3=new DexLabel();
                code.visitJumpStmt(IF_NEZ,2,-1,L3);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,0},new Method("Lorg/mortbay/util/StringMap;","remove",new String[]{ "Ljava/lang/String;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L2);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/lang/Object;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,0},new Method("Lorg/mortbay/util/StringMap;","remove",new String[]{ "Ljava/lang/String;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m018_remove(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/StringMap;","remove",new String[]{ "Ljava/lang/String;"},"Ljava/lang/Object;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(11);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"key");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(442,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(444,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(445,L3);
                ddv.visitStartLocal(5,L3,"oldValue","Ljava/lang/Object;",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(447,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(448,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(449,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(500,L7);
                ddv.visitEndLocal(5,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(454,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(455,L9);
                ddv.visitStartLocal(3,L9,"node","Lorg/mortbay/util/StringMap$Node;",null);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(459,L10);
                ddv.visitStartLocal(2,L10,"ni","I",null);
                DexLabel L11=new DexLabel();
                ddv.visitStartLocal(1,L11,"i","I",null);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(461,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(464,L13);
                ddv.visitStartLocal(0,L13,"c","C",null);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(466,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(467,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(471,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(474,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(476,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(477,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(478,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(459,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(467,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(483,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(486,L24);
                DexLabel L25=new DexLabel();
                ddv.visitRestartLocal(3,L25);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(488,L26);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(491,L27);
                ddv.visitEndLocal(0,L27);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(492,L28);
                DexLabel L29=new DexLabel();
                ddv.visitLineNumber(493,L29);
                DexLabel L30=new DexLabel();
                ddv.visitLineNumber(495,L30);
                DexLabel L31=new DexLabel();
                ddv.visitLineNumber(496,L31);
                ddv.visitStartLocal(4,L31,"old","Ljava/lang/Object;",null);
                DexLabel L32=new DexLabel();
                ddv.visitLineNumber(497,L32);
                DexLabel L33=new DexLabel();
                ddv.visitLineNumber(498,L33);
                DexLabel L34=new DexLabel();
                ddv.visitLineNumber(500,L34);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,8, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitJumpStmt(IF_NEZ,10,-1,L8);
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,5,9,new Field("Lorg/mortbay/util/StringMap;","_nullValue","Ljava/lang/Object;"));
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,6,9,new Field("Lorg/mortbay/util/StringMap;","_nullEntry","Lorg/mortbay/util/StringMap$NullEntry;"));
                DexLabel L35=new DexLabel();
                code.visitJumpStmt(IF_EQZ,6,-1,L35);
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,6,9,new Field("Lorg/mortbay/util/StringMap;","_entrySet","Ljava/util/HashSet;"));
                code.visitFieldStmt(IGET_OBJECT,7,9,new Field("Lorg/mortbay/util/StringMap;","_nullEntry","Lorg/mortbay/util/StringMap$NullEntry;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,7},new Method("Ljava/util/HashSet;","remove",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitLabel(L5);
                code.visitFieldStmt(IPUT_OBJECT,8,9,new Field("Lorg/mortbay/util/StringMap;","_nullEntry","Lorg/mortbay/util/StringMap$NullEntry;"));
                code.visitLabel(L6);
                code.visitFieldStmt(IPUT_OBJECT,8,9,new Field("Lorg/mortbay/util/StringMap;","_nullValue","Ljava/lang/Object;"));
                code.visitLabel(L35);
                code.visitStmt2R(MOVE_OBJECT,6,5);
                code.visitLabel(L7);
                code.visitStmt1R(RETURN_OBJECT,6);
                code.visitLabel(L8);
                code.visitFieldStmt(IGET_OBJECT,3,9,new Field("Lorg/mortbay/util/StringMap;","_root","Lorg/mortbay/util/StringMap$Node;"));
                code.visitLabel(L9);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(-1)); // int: 0xffffffff  float:NaN
                code.visitLabel(L10);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L11);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitJumpStmt(IF_GE,1,6,L27);
                code.visitLabel(L12);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10,1},new Method("Ljava/lang/String;","charAt",new String[]{ "I"},"C"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitLabel(L13);
                code.visitConstStmt(CONST_4,6, Integer.valueOf(-1)); // int: 0xffffffff  float:NaN
                code.visitJumpStmt(IF_NE,2,6,L16);
                code.visitLabel(L14);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L15);
                code.visitFieldStmt(IGET_OBJECT,6,3,new Field("Lorg/mortbay/util/StringMap$Node;","_children","[Lorg/mortbay/util/StringMap$Node;"));
                code.visitJumpStmt(IF_NEZ,6,-1,L22);
                code.visitStmt2R(MOVE_OBJECT,3,8);
                code.visitLabel(L16);
                DexLabel L36=new DexLabel();
                code.visitJumpStmt(IF_EQZ,3,-1,L36);
                code.visitLabel(L17);
                code.visitFieldStmt(IGET_OBJECT,6,3,new Field("Lorg/mortbay/util/StringMap$Node;","_char","[C"));
                code.visitStmt3R(AGET_CHAR,6,6,2);
                code.visitJumpStmt(IF_EQ,6,0,L18);
                code.visitFieldStmt(IGET_BOOLEAN,6,9,new Field("Lorg/mortbay/util/StringMap;","_ignoreCase","Z"));
                code.visitJumpStmt(IF_EQZ,6,-1,L23);
                code.visitFieldStmt(IGET_OBJECT,6,3,new Field("Lorg/mortbay/util/StringMap$Node;","_ochar","[C"));
                code.visitStmt3R(AGET_CHAR,6,6,2);
                code.visitJumpStmt(IF_NE,6,0,L23);
                code.visitLabel(L18);
                code.visitStmt2R1N(ADD_INT_LIT8,2,2,1);
                code.visitLabel(L19);
                code.visitFieldStmt(IGET_OBJECT,6,3,new Field("Lorg/mortbay/util/StringMap$Node;","_char","[C"));
                code.visitStmt2R(ARRAY_LENGTH,6,6);
                code.visitJumpStmt(IF_NE,2,6,L21);
                code.visitLabel(L20);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(-1)); // int: 0xffffffff  float:NaN
                code.visitLabel(L21);
                code.visitStmt2R1N(ADD_INT_LIT8,1,1,1);
                code.visitJumpStmt(GOTO,-1,-1,L11);
                code.visitLabel(L22);
                code.visitFieldStmt(IGET_OBJECT,6,3,new Field("Lorg/mortbay/util/StringMap$Node;","_children","[Lorg/mortbay/util/StringMap$Node;"));
                code.visitFieldStmt(IGET,7,9,new Field("Lorg/mortbay/util/StringMap;","_width","I"));
                code.visitStmt3R(REM_INT,7,0,7);
                code.visitStmt3R(AGET_OBJECT,6,6,7);
                code.visitStmt2R(MOVE_OBJECT,3,6);
                code.visitJumpStmt(GOTO,-1,-1,L16);
                code.visitLabel(L23);
                code.visitJumpStmt(IF_LEZ,2,-1,L24);
                code.visitStmt2R(MOVE_OBJECT,6,8);
                code.visitJumpStmt(GOTO,-1,-1,L7);
                code.visitLabel(L24);
                code.visitFieldStmt(IGET_OBJECT,3,3,new Field("Lorg/mortbay/util/StringMap$Node;","_next","Lorg/mortbay/util/StringMap$Node;"));
                code.visitLabel(L25);
                code.visitJumpStmt(GOTO,-1,-1,L16);
                code.visitLabel(L36);
                code.visitStmt2R(MOVE_OBJECT,6,8);
                code.visitLabel(L26);
                code.visitJumpStmt(GOTO,-1,-1,L7);
                code.visitLabel(L27);
                code.visitJumpStmt(IF_LEZ,2,-1,L28);
                code.visitStmt2R(MOVE_OBJECT,6,8);
                code.visitJumpStmt(GOTO,-1,-1,L7);
                code.visitLabel(L28);
                code.visitJumpStmt(IF_EQZ,3,-1,L30);
                code.visitFieldStmt(IGET_OBJECT,6,3,new Field("Lorg/mortbay/util/StringMap$Node;","_key","Ljava/lang/String;"));
                code.visitJumpStmt(IF_NEZ,6,-1,L30);
                code.visitStmt2R(MOVE_OBJECT,6,8);
                code.visitLabel(L29);
                code.visitJumpStmt(GOTO,-1,-1,L7);
                code.visitLabel(L30);
                code.visitFieldStmt(IGET_OBJECT,4,3,new Field("Lorg/mortbay/util/StringMap$Node;","_value","Ljava/lang/Object;"));
                code.visitLabel(L31);
                code.visitFieldStmt(IGET_OBJECT,6,9,new Field("Lorg/mortbay/util/StringMap;","_entrySet","Ljava/util/HashSet;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,3},new Method("Ljava/util/HashSet;","remove",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitLabel(L32);
                code.visitFieldStmt(IPUT_OBJECT,8,3,new Field("Lorg/mortbay/util/StringMap$Node;","_value","Ljava/lang/Object;"));
                code.visitLabel(L33);
                code.visitFieldStmt(IPUT_OBJECT,8,3,new Field("Lorg/mortbay/util/StringMap$Node;","_key","Ljava/lang/String;"));
                code.visitStmt2R(MOVE_OBJECT,6,4);
                code.visitLabel(L34);
                code.visitJumpStmt(GOTO,-1,-1,L7);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m019_setIgnoreCase(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/StringMap;","setIgnoreCase",new String[]{ "Z"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"ic");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(88,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(89,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(90,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(91,L3);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/util/StringMap;","_root","Lorg/mortbay/util/StringMap$Node;"));
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/util/StringMap$Node;","_children","[Lorg/mortbay/util/StringMap$Node;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L2);
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/IllegalStateException;");
                code.visitConstStmt(CONST_STRING,1,"Must be set before first put");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Ljava/lang/IllegalStateException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,0);
                code.visitLabel(L2);
                code.visitFieldStmt(IPUT_BOOLEAN,3,2,new Field("Lorg/mortbay/util/StringMap;","_ignoreCase","Z"));
                code.visitLabel(L3);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m020_setWidth(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/StringMap;","setWidth",new String[]{ "I"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"width");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(106,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(107,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT,1,0,new Field("Lorg/mortbay/util/StringMap;","_width","I"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m021_size(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/StringMap;","size",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(512,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/util/StringMap;","_entrySet","Ljava/util/HashSet;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/util/HashSet;","size",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m022_writeExternal(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/StringMap;","writeExternal",new String[]{ "Ljava/io/ObjectOutput;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"out");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(672,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(673,L1);
                ddv.visitStartLocal(0,L1,"map","Ljava/util/HashMap;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(674,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(675,L3);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/util/HashMap;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,2},new Method("Ljava/util/HashMap;","<init>",new String[]{ "Ljava/util/Map;"},"V"));
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_BOOLEAN,1,2,new Field("Lorg/mortbay/util/StringMap;","_ignoreCase","Z"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3,1},new Method("Ljava/io/ObjectOutput;","writeBoolean",new String[]{ "Z"},"V"));
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3,0},new Method("Ljava/io/ObjectOutput;","writeObject",new String[]{ "Ljava/lang/Object;"},"V"));
                code.visitLabel(L3);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
