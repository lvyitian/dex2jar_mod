package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0043_org_mortbay_component_AbstractLifeCycle {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC|ACC_ABSTRACT,"Lorg/mortbay/component/AbstractLifeCycle;","Ljava/lang/Object;",new String[]{ "Lorg/mortbay/component/LifeCycle;"});
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("AbstractLifeCycle.java");
        f000_FAILED(cv);
        f001_STARTED(cv);
        f002_STARTING(cv);
        f003_STOPPED(cv);
        f004_STOPPING(cv);
        f005__listeners(cv);
        f006__lock(cv);
        f007__state(cv);
        m000__init_(cv);
        m001_setFailed(cv);
        m002_setStarted(cv);
        m003_setStarting(cv);
        m004_setStopped(cv);
        m005_setStopping(cv);
        m006_addLifeCycleListener(cv);
        m007_doStart(cv);
        m008_doStop(cv);
        m009_isFailed(cv);
        m010_isRunning(cv);
        m011_isStarted(cv);
        m012_isStarting(cv);
        m013_isStopped(cv);
        m014_isStopping(cv);
        m015_removeLifeCycleListener(cv);
        m016_start(cv);
        m017_stop(cv);
    }
    public static void f000_FAILED(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_FINAL, new Field("Lorg/mortbay/component/AbstractLifeCycle;","FAILED","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001_STARTED(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_FINAL, new Field("Lorg/mortbay/component/AbstractLifeCycle;","STARTED","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002_STARTING(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_FINAL, new Field("Lorg/mortbay/component/AbstractLifeCycle;","STARTING","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003_STOPPED(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_FINAL, new Field("Lorg/mortbay/component/AbstractLifeCycle;","STOPPED","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f004_STOPPING(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_FINAL, new Field("Lorg/mortbay/component/AbstractLifeCycle;","STOPPING","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f005__listeners(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/component/AbstractLifeCycle;","_listeners","[Lorg/mortbay/component/LifeCycle$Listener;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f006__lock(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/component/AbstractLifeCycle;","_lock","Ljava/lang/Object;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f007__state(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_TRANSIENT, new Field("Lorg/mortbay/component/AbstractLifeCycle;","_state","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/component/AbstractLifeCycle;","<init>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(26,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(28,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(29,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(30,L4);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2},new Method("Ljava/lang/Object;","<init>",new String[]{ },"V"));
                code.visitLabel(L2);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/Object;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/Object;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/component/AbstractLifeCycle;","_lock","Ljava/lang/Object;"));
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(-1)); // int: 0xffffffff  float:NaN
                code.visitFieldStmt(IPUT,0,2,new Field("Lorg/mortbay/component/AbstractLifeCycle;","FAILED","I"));
                code.visitFieldStmt(IPUT,1,2,new Field("Lorg/mortbay/component/AbstractLifeCycle;","STOPPED","I"));
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitFieldStmt(IPUT,0,2,new Field("Lorg/mortbay/component/AbstractLifeCycle;","STARTING","I"));
                code.visitConstStmt(CONST_4,0, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitFieldStmt(IPUT,0,2,new Field("Lorg/mortbay/component/AbstractLifeCycle;","STARTED","I"));
                code.visitConstStmt(CONST_4,0, Integer.valueOf(3)); // int: 0x00000003  float:0.000000
                code.visitFieldStmt(IPUT,0,2,new Field("Lorg/mortbay/component/AbstractLifeCycle;","STOPPING","I"));
                code.visitLabel(L4);
                code.visitFieldStmt(IPUT,1,2,new Field("Lorg/mortbay/component/AbstractLifeCycle;","_state","I"));
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001_setFailed(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PRIVATE, new Method("Lorg/mortbay/component/AbstractLifeCycle;","setFailed",new String[]{ "Ljava/lang/Throwable;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"error");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(187,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(188,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(190,L2);
                DexLabel L3=new DexLabel();
                ddv.visitStartLocal(0,L3,"i","I",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(192,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(190,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(195,L6);
                ddv.visitEndLocal(0,L6);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(-1)); // int: 0xffffffff  float:NaN
                code.visitFieldStmt(IPUT,1,2,new Field("Lorg/mortbay/component/AbstractLifeCycle;","_state","I"));
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/component/AbstractLifeCycle;","_listeners","[Lorg/mortbay/component/LifeCycle$Listener;"));
                code.visitJumpStmt(IF_EQZ,1,-1,L6);
                code.visitLabel(L2);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/component/AbstractLifeCycle;","_listeners","[Lorg/mortbay/component/LifeCycle$Listener;"));
                code.visitStmt2R(ARRAY_LENGTH,1,1);
                code.visitJumpStmt(IF_GE,0,1,L6);
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/component/AbstractLifeCycle;","_listeners","[Lorg/mortbay/component/LifeCycle$Listener;"));
                code.visitStmt3R(AGET_OBJECT,1,1,0);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1,2,3},new Method("Lorg/mortbay/component/LifeCycle$Listener;","lifeCycleFailure",new String[]{ "Lorg/mortbay/component/LifeCycle;","Ljava/lang/Throwable;"},"V"));
                code.visitLabel(L5);
                code.visitStmt2R1N(ADD_INT_LIT8,0,0,1);
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitLabel(L6);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_setStarted(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PRIVATE, new Method("Lorg/mortbay/component/AbstractLifeCycle;","setStarted",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(139,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(140,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(142,L2);
                DexLabel L3=new DexLabel();
                ddv.visitStartLocal(0,L3,"i","I",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(144,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(142,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(147,L6);
                ddv.visitEndLocal(0,L6);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitFieldStmt(IPUT,1,2,new Field("Lorg/mortbay/component/AbstractLifeCycle;","_state","I"));
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/component/AbstractLifeCycle;","_listeners","[Lorg/mortbay/component/LifeCycle$Listener;"));
                code.visitJumpStmt(IF_EQZ,1,-1,L6);
                code.visitLabel(L2);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/component/AbstractLifeCycle;","_listeners","[Lorg/mortbay/component/LifeCycle$Listener;"));
                code.visitStmt2R(ARRAY_LENGTH,1,1);
                code.visitJumpStmt(IF_GE,0,1,L6);
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/component/AbstractLifeCycle;","_listeners","[Lorg/mortbay/component/LifeCycle$Listener;"));
                code.visitStmt3R(AGET_OBJECT,1,1,0);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1,2},new Method("Lorg/mortbay/component/LifeCycle$Listener;","lifeCycleStarted",new String[]{ "Lorg/mortbay/component/LifeCycle;"},"V"));
                code.visitLabel(L5);
                code.visitStmt2R1N(ADD_INT_LIT8,0,0,1);
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitLabel(L6);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_setStarting(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PRIVATE, new Method("Lorg/mortbay/component/AbstractLifeCycle;","setStarting",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(151,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(152,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(154,L2);
                DexLabel L3=new DexLabel();
                ddv.visitStartLocal(0,L3,"i","I",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(156,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(154,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(159,L6);
                ddv.visitEndLocal(0,L6);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitFieldStmt(IPUT,1,2,new Field("Lorg/mortbay/component/AbstractLifeCycle;","_state","I"));
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/component/AbstractLifeCycle;","_listeners","[Lorg/mortbay/component/LifeCycle$Listener;"));
                code.visitJumpStmt(IF_EQZ,1,-1,L6);
                code.visitLabel(L2);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/component/AbstractLifeCycle;","_listeners","[Lorg/mortbay/component/LifeCycle$Listener;"));
                code.visitStmt2R(ARRAY_LENGTH,1,1);
                code.visitJumpStmt(IF_GE,0,1,L6);
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/component/AbstractLifeCycle;","_listeners","[Lorg/mortbay/component/LifeCycle$Listener;"));
                code.visitStmt3R(AGET_OBJECT,1,1,0);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1,2},new Method("Lorg/mortbay/component/LifeCycle$Listener;","lifeCycleStarting",new String[]{ "Lorg/mortbay/component/LifeCycle;"},"V"));
                code.visitLabel(L5);
                code.visitStmt2R1N(ADD_INT_LIT8,0,0,1);
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitLabel(L6);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_setStopped(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PRIVATE, new Method("Lorg/mortbay/component/AbstractLifeCycle;","setStopped",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(175,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(176,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(178,L2);
                DexLabel L3=new DexLabel();
                ddv.visitStartLocal(0,L3,"i","I",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(180,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(178,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(183,L6);
                ddv.visitEndLocal(0,L6);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT,1,2,new Field("Lorg/mortbay/component/AbstractLifeCycle;","_state","I"));
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/component/AbstractLifeCycle;","_listeners","[Lorg/mortbay/component/LifeCycle$Listener;"));
                code.visitJumpStmt(IF_EQZ,1,-1,L6);
                code.visitLabel(L2);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/component/AbstractLifeCycle;","_listeners","[Lorg/mortbay/component/LifeCycle$Listener;"));
                code.visitStmt2R(ARRAY_LENGTH,1,1);
                code.visitJumpStmt(IF_GE,0,1,L6);
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/component/AbstractLifeCycle;","_listeners","[Lorg/mortbay/component/LifeCycle$Listener;"));
                code.visitStmt3R(AGET_OBJECT,1,1,0);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1,2},new Method("Lorg/mortbay/component/LifeCycle$Listener;","lifeCycleStopped",new String[]{ "Lorg/mortbay/component/LifeCycle;"},"V"));
                code.visitLabel(L5);
                code.visitStmt2R1N(ADD_INT_LIT8,0,0,1);
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitLabel(L6);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_setStopping(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PRIVATE, new Method("Lorg/mortbay/component/AbstractLifeCycle;","setStopping",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(163,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(164,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(166,L2);
                DexLabel L3=new DexLabel();
                ddv.visitStartLocal(0,L3,"i","I",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(168,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(166,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(171,L6);
                ddv.visitEndLocal(0,L6);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(3)); // int: 0x00000003  float:0.000000
                code.visitFieldStmt(IPUT,1,2,new Field("Lorg/mortbay/component/AbstractLifeCycle;","_state","I"));
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/component/AbstractLifeCycle;","_listeners","[Lorg/mortbay/component/LifeCycle$Listener;"));
                code.visitJumpStmt(IF_EQZ,1,-1,L6);
                code.visitLabel(L2);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/component/AbstractLifeCycle;","_listeners","[Lorg/mortbay/component/LifeCycle$Listener;"));
                code.visitStmt2R(ARRAY_LENGTH,1,1);
                code.visitJumpStmt(IF_GE,0,1,L6);
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/component/AbstractLifeCycle;","_listeners","[Lorg/mortbay/component/LifeCycle$Listener;"));
                code.visitStmt3R(AGET_OBJECT,1,1,0);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1,2},new Method("Lorg/mortbay/component/LifeCycle$Listener;","lifeCycleStopping",new String[]{ "Lorg/mortbay/component/LifeCycle;"},"V"));
                code.visitLabel(L5);
                code.visitStmt2R1N(ADD_INT_LIT8,0,0,1);
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitLabel(L6);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_addLifeCycleListener(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/component/AbstractLifeCycle;","addLifeCycleListener",new String[]{ "Lorg/mortbay/component/LifeCycle$Listener;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"listener");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(129,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(130,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/component/AbstractLifeCycle;","_listeners","[Lorg/mortbay/component/LifeCycle$Listener;"));
                code.visitConstStmt(CONST_CLASS,1,new DexType("Lorg/mortbay/component/LifeCycle$Listener;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,3,1},new Method("Lorg/mortbay/util/LazyList;","addToArray",new String[]{ "[Ljava/lang/Object;","Ljava/lang/Object;","Ljava/lang/Class;"},"[Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitTypeStmt(CHECK_CAST,0,-1,"[Lorg/mortbay/component/LifeCycle$Listener;");
                code.visitTypeStmt(CHECK_CAST,0,-1,"[Lorg/mortbay/component/LifeCycle$Listener;");
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/component/AbstractLifeCycle;","_listeners","[Lorg/mortbay/component/LifeCycle$Listener;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m007_doStart(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/component/AbstractLifeCycle;","doStart",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/Exception;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(35,L0);
                code.visitLabel(L0);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m008_doStop(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/component/AbstractLifeCycle;","doStop",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/Exception;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(39,L0);
                code.visitLabel(L0);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m009_isFailed(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/component/AbstractLifeCycle;","isFailed",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(124,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,2,new Field("Lorg/mortbay/component/AbstractLifeCycle;","_state","I"));
                code.visitConstStmt(CONST_4,1, Integer.valueOf(-1)); // int: 0xffffffff  float:NaN
                DexLabel L1=new DexLabel();
                code.visitJumpStmt(IF_NE,0,1,L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                DexLabel L2=new DexLabel();
                code.visitLabel(L2);
                code.visitStmt1R(RETURN,0);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m010_isRunning(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/component/AbstractLifeCycle;","isRunning",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(99,L1);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L1);
                code.visitFieldStmt(IGET,0,3,new Field("Lorg/mortbay/component/AbstractLifeCycle;","_state","I"));
                code.visitConstStmt(CONST_4,1, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                DexLabel L2=new DexLabel();
                code.visitJumpStmt(IF_EQ,0,1,L2);
                code.visitFieldStmt(IGET,0,3,new Field("Lorg/mortbay/component/AbstractLifeCycle;","_state","I"));
                DexLabel L3=new DexLabel();
                code.visitJumpStmt(IF_NE,0,2,L3);
                code.visitLabel(L2);
                code.visitStmt2R(MOVE,0,2);
                DexLabel L4=new DexLabel();
                code.visitLabel(L4);
                code.visitStmt1R(RETURN,0);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m011_isStarted(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/component/AbstractLifeCycle;","isStarted",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(104,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,2,new Field("Lorg/mortbay/component/AbstractLifeCycle;","_state","I"));
                code.visitConstStmt(CONST_4,1, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                DexLabel L1=new DexLabel();
                code.visitJumpStmt(IF_NE,0,1,L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                DexLabel L2=new DexLabel();
                code.visitLabel(L2);
                code.visitStmt1R(RETURN,0);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m012_isStarting(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/component/AbstractLifeCycle;","isStarting",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(109,L1);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L1);
                code.visitFieldStmt(IGET,0,2,new Field("Lorg/mortbay/component/AbstractLifeCycle;","_state","I"));
                DexLabel L2=new DexLabel();
                code.visitJumpStmt(IF_NE,0,1,L2);
                code.visitStmt2R(MOVE,0,1);
                DexLabel L3=new DexLabel();
                code.visitLabel(L3);
                code.visitStmt1R(RETURN,0);
                code.visitLabel(L2);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m013_isStopped(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/component/AbstractLifeCycle;","isStopped",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(119,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,1,new Field("Lorg/mortbay/component/AbstractLifeCycle;","_state","I"));
                DexLabel L1=new DexLabel();
                code.visitJumpStmt(IF_NEZ,0,-1,L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                DexLabel L2=new DexLabel();
                code.visitLabel(L2);
                code.visitStmt1R(RETURN,0);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m014_isStopping(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/component/AbstractLifeCycle;","isStopping",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(114,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,2,new Field("Lorg/mortbay/component/AbstractLifeCycle;","_state","I"));
                code.visitConstStmt(CONST_4,1, Integer.valueOf(3)); // int: 0x00000003  float:0.000000
                DexLabel L1=new DexLabel();
                code.visitJumpStmt(IF_NE,0,1,L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                DexLabel L2=new DexLabel();
                code.visitLabel(L2);
                code.visitStmt1R(RETURN,0);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m015_removeLifeCycleListener(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/component/AbstractLifeCycle;","removeLifeCycleListener",new String[]{ "Lorg/mortbay/component/LifeCycle$Listener;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"listener");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(134,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(135,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/component/AbstractLifeCycle;","_listeners","[Lorg/mortbay/component/LifeCycle$Listener;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,2},new Method("Lorg/mortbay/util/LazyList;","removeFromArray",new String[]{ "[Ljava/lang/Object;","Ljava/lang/Object;"},"[Ljava/lang/Object;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m016_start(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_FINAL, new Method("Lorg/mortbay/component/AbstractLifeCycle;","start",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/Exception;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2,L3,L4},new String[]{ "Ljava/lang/Exception;","Ljava/lang/Error;",null});
                DexLabel L5=new DexLabel();
                DexLabel L6=new DexLabel();
                code.visitTryCatch(L5,L6,new DexLabel[]{L4},new String[]{ null});
                DexLabel L7=new DexLabel();
                DexLabel L8=new DexLabel();
                code.visitTryCatch(L7,L8,new DexLabel[]{L2,L3,L4},new String[]{ "Ljava/lang/Exception;","Ljava/lang/Error;",null});
                DexLabel L9=new DexLabel();
                code.visitTryCatch(L8,L9,new DexLabel[]{L4},new String[]{ null});
                DexLabel L10=new DexLabel();
                DexLabel L11=new DexLabel();
                code.visitTryCatch(L10,L11,new DexLabel[]{L4},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L12=new DexLabel();
                ddv.visitPrologue(L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(43,L13);
                ddv.visitLineNumber(47,L0);
                ddv.visitLineNumber(48,L5);
                ddv.visitLineNumber(67,L6);
                ddv.visitLineNumber(49,L7);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(50,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(51,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(52,L16);
                ddv.visitLineNumber(66,L8);
                ddv.visitLineNumber(54,L2);
                ddv.visitLineNumber(56,L10);
                ddv.visitStartLocal(0,L10,"e","Ljava/lang/Exception;",null);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(57,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(58,L18);
                ddv.visitLineNumber(60,L3);
                ddv.visitEndLocal(0,L3);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(62,L19);
                ddv.visitStartLocal(0,L19,"e","Ljava/lang/Error;",null);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(63,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(64,L21);
                code.visitLabel(L12);
                code.visitConstStmt(CONST_STRING,1,"failed ");
                code.visitLabel(L13);
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/component/AbstractLifeCycle;","_lock","Ljava/lang/Object;"));
                code.visitStmt1R(MONITOR_ENTER,1);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,2,4,new Field("Lorg/mortbay/component/AbstractLifeCycle;","_state","I"));
                code.visitConstStmt(CONST_4,3, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitJumpStmt(IF_EQ,2,3,L5);
                code.visitFieldStmt(IGET,2,4,new Field("Lorg/mortbay/component/AbstractLifeCycle;","_state","I"));
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitJumpStmt(IF_NE,2,3,L7);
                code.visitLabel(L5);
                code.visitStmt1R(MONITOR_EXIT,1);
                code.visitLabel(L6);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4},new Method("Lorg/mortbay/component/AbstractLifeCycle;","setStarting",new String[]{ },"V"));
                code.visitLabel(L14);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/component/AbstractLifeCycle;","doStart",new String[]{ },"V"));
                code.visitLabel(L15);
                code.visitConstStmt(CONST_STRING,2,"started {}");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2,4},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L16);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4},new Method("Lorg/mortbay/component/AbstractLifeCycle;","setStarted",new String[]{ },"V"));
                code.visitLabel(L8);
                code.visitStmt1R(MONITOR_EXIT,1);
                code.visitJumpStmt(GOTO,-1,-1,L6);
                code.visitLabel(L4);
                code.visitStmt1R(MOVE_EXCEPTION,2);
                code.visitStmt1R(MONITOR_EXIT,1);
                code.visitLabel(L9);
                code.visitStmt1R(THROW,2);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,2);
                code.visitStmt2R(MOVE_OBJECT,0,2);
                code.visitLabel(L10);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,3,"failed ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2,0},new Method("Lorg/mortbay/log/Log;","warn",new String[]{ "Ljava/lang/String;","Ljava/lang/Throwable;"},"V"));
                code.visitLabel(L17);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4,0},new Method("Lorg/mortbay/component/AbstractLifeCycle;","setFailed",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitLabel(L18);
                code.visitStmt1R(THROW,0);
                code.visitLabel(L3);
                code.visitStmt1R(MOVE_EXCEPTION,2);
                code.visitStmt2R(MOVE_OBJECT,0,2);
                code.visitLabel(L19);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,3,"failed ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2,0},new Method("Lorg/mortbay/log/Log;","warn",new String[]{ "Ljava/lang/String;","Ljava/lang/Throwable;"},"V"));
                code.visitLabel(L20);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4,0},new Method("Lorg/mortbay/component/AbstractLifeCycle;","setFailed",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitLabel(L21);
                code.visitStmt1R(THROW,0);
                code.visitLabel(L11);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m017_stop(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_FINAL, new Method("Lorg/mortbay/component/AbstractLifeCycle;","stop",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/Exception;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2,L3,L4},new String[]{ "Ljava/lang/Exception;","Ljava/lang/Error;",null});
                DexLabel L5=new DexLabel();
                DexLabel L6=new DexLabel();
                code.visitTryCatch(L5,L6,new DexLabel[]{L4},new String[]{ null});
                DexLabel L7=new DexLabel();
                DexLabel L8=new DexLabel();
                code.visitTryCatch(L7,L8,new DexLabel[]{L2,L3,L4},new String[]{ "Ljava/lang/Exception;","Ljava/lang/Error;",null});
                DexLabel L9=new DexLabel();
                code.visitTryCatch(L8,L9,new DexLabel[]{L4},new String[]{ null});
                DexLabel L10=new DexLabel();
                DexLabel L11=new DexLabel();
                code.visitTryCatch(L10,L11,new DexLabel[]{L4},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L12=new DexLabel();
                ddv.visitPrologue(L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(71,L13);
                ddv.visitLineNumber(75,L0);
                ddv.visitLineNumber(76,L5);
                ddv.visitLineNumber(95,L6);
                ddv.visitLineNumber(77,L7);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(78,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(79,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(80,L16);
                ddv.visitLineNumber(94,L8);
                ddv.visitLineNumber(82,L2);
                ddv.visitLineNumber(84,L10);
                ddv.visitStartLocal(0,L10,"e","Ljava/lang/Exception;",null);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(85,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(86,L18);
                ddv.visitLineNumber(88,L3);
                ddv.visitEndLocal(0,L3);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(90,L19);
                ddv.visitStartLocal(0,L19,"e","Ljava/lang/Error;",null);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(91,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(92,L21);
                code.visitLabel(L12);
                code.visitConstStmt(CONST_STRING,1,"failed ");
                code.visitLabel(L13);
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/component/AbstractLifeCycle;","_lock","Ljava/lang/Object;"));
                code.visitStmt1R(MONITOR_ENTER,1);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,2,4,new Field("Lorg/mortbay/component/AbstractLifeCycle;","_state","I"));
                code.visitConstStmt(CONST_4,3, Integer.valueOf(3)); // int: 0x00000003  float:0.000000
                code.visitJumpStmt(IF_EQ,2,3,L5);
                code.visitFieldStmt(IGET,2,4,new Field("Lorg/mortbay/component/AbstractLifeCycle;","_state","I"));
                code.visitLabel(L1);
                code.visitJumpStmt(IF_NEZ,2,-1,L7);
                code.visitLabel(L5);
                code.visitStmt1R(MONITOR_EXIT,1);
                code.visitLabel(L6);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4},new Method("Lorg/mortbay/component/AbstractLifeCycle;","setStopping",new String[]{ },"V"));
                code.visitLabel(L14);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/component/AbstractLifeCycle;","doStop",new String[]{ },"V"));
                code.visitLabel(L15);
                code.visitConstStmt(CONST_STRING,2,"stopped {}");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2,4},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L16);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4},new Method("Lorg/mortbay/component/AbstractLifeCycle;","setStopped",new String[]{ },"V"));
                code.visitLabel(L8);
                code.visitStmt1R(MONITOR_EXIT,1);
                code.visitJumpStmt(GOTO,-1,-1,L6);
                code.visitLabel(L4);
                code.visitStmt1R(MOVE_EXCEPTION,2);
                code.visitStmt1R(MONITOR_EXIT,1);
                code.visitLabel(L9);
                code.visitStmt1R(THROW,2);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,2);
                code.visitStmt2R(MOVE_OBJECT,0,2);
                code.visitLabel(L10);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,3,"failed ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2,0},new Method("Lorg/mortbay/log/Log;","warn",new String[]{ "Ljava/lang/String;","Ljava/lang/Throwable;"},"V"));
                code.visitLabel(L17);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4,0},new Method("Lorg/mortbay/component/AbstractLifeCycle;","setFailed",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitLabel(L18);
                code.visitStmt1R(THROW,0);
                code.visitLabel(L3);
                code.visitStmt1R(MOVE_EXCEPTION,2);
                code.visitStmt2R(MOVE_OBJECT,0,2);
                code.visitLabel(L19);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,3,"failed ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2,0},new Method("Lorg/mortbay/log/Log;","warn",new String[]{ "Ljava/lang/String;","Ljava/lang/Throwable;"},"V"));
                code.visitLabel(L20);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4,0},new Method("Lorg/mortbay/component/AbstractLifeCycle;","setFailed",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitLabel(L21);
                code.visitStmt1R(THROW,0);
                code.visitLabel(L11);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
