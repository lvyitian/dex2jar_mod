package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0467_org_mortbay_xml_XmlParser {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/xml/XmlParser;","Ljava/lang/Object;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("XmlParser.java");
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/MemberClasses;", Visibility.SYSTEM);
            if(av00 != null) {
                {
                    DexAnnotationVisitor av01 = av00.visitArray("value");
                    if(av01 != null) {
                        av01.visit(null, new DexType("Lorg/mortbay/xml/XmlParser$Node;"));
                        av01.visit(null, new DexType("Lorg/mortbay/xml/XmlParser$Attribute;"));
                        av01.visit(null, new DexType("Lorg/mortbay/xml/XmlParser$Handler;"));
                        av01.visit(null, new DexType("Lorg/mortbay/xml/XmlParser$NoopHandler;"));
                        av01.visitEnd();
                    }
                }
                av00.visitEnd();
            }
        }
        f000__dtd(cv);
        f001__observerMap(cv);
        f002__observers(cv);
        f003__parser(cv);
        f004__redirectMap(cv);
        f005__xpath(cv);
        f006__xpaths(cv);
        m000__init_(cv);
        m001__init_(cv);
        m002_access$000(cv);
        m003_access$100(cv);
        m004_access$200(cv);
        m005_access$300(cv);
        m006_access$402(cv);
        m007_access$500(cv);
        m008_addContentHandler(cv);
        m009_getDTD(cv);
        m010_getXpath(cv);
        m011_parse(cv);
        m012_parse(cv);
        m013_parse(cv);
        m014_parse(cv);
        m015_redirectEntity(cv);
        m016_setValidating(cv);
        m017_setXpath(cv);
    }
    public static void f000__dtd(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/xml/XmlParser;","_dtd","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001__observerMap(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/xml/XmlParser;","_observerMap","Ljava/util/Map;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002__observers(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/xml/XmlParser;","_observers","Ljava/util/Stack;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003__parser(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/xml/XmlParser;","_parser","Ljavax/xml/parsers/SAXParser;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f004__redirectMap(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/xml/XmlParser;","_redirectMap","Ljava/util/Map;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f005__xpath(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/xml/XmlParser;","_xpath","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f006__xpaths(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/xml/XmlParser;","_xpaths","Ljava/lang/Object;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/xml/XmlParser;","<init>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(8);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(68,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(55,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(58,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(69,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(70,L4);
                ddv.visitStartLocal(0,L4,"factory","Ljavax/xml/parsers/SAXParserFactory;",null);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(71,L5);
                ddv.visitStartLocal(3,L5,"validating_dft","Z",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(72,L6);
                ddv.visitStartLocal(4,L6,"validating_prop","Ljava/lang/String;",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(73,L7);
                ddv.visitStartLocal(1,L7,"notValidating","Z",null);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(74,L8);
                ddv.visitStartLocal(2,L8,"validating","Z",null);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(75,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(71,L10);
                ddv.visitEndLocal(4,L10);
                ddv.visitEndLocal(1,L10);
                ddv.visitEndLocal(2,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(73,L11);
                ddv.visitRestartLocal(1,L11);
                ddv.visitRestartLocal(4,L11);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 7},new Method("Ljava/lang/Object;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,5,-1,"Ljava/util/HashMap;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 5},new Method("Ljava/util/HashMap;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,5,7,new Field("Lorg/mortbay/xml/XmlParser;","_redirectMap","Ljava/util/Map;"));
                code.visitLabel(L2);
                code.visitTypeStmt(NEW_INSTANCE,5,-1,"Ljava/util/Stack;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 5},new Method("Ljava/util/Stack;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,5,7,new Field("Lorg/mortbay/xml/XmlParser;","_observers","Ljava/util/Stack;"));
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Ljavax/xml/parsers/SAXParserFactory;","newInstance",new String[]{ },"Ljavax/xml/parsers/SAXParserFactory;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/Object;","getClass",new String[]{ },"Ljava/lang/Class;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/lang/Class;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitConstStmt(CONST_STRING,6,"org.apache.xerces.");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Ljava/lang/String;","startsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitLabel(L5);
                code.visitConstStmt(CONST_STRING,5,"org.mortbay.xml.XmlParser.Validating");
                code.visitJumpStmt(IF_EQZ,3,-1,L10);
                code.visitConstStmt(CONST_STRING,6,"true");
                DexLabel L12=new DexLabel();
                code.visitLabel(L12);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 5,6},new Method("Ljava/lang/System;","getProperty",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitLabel(L6);
                code.visitConstStmt(CONST_STRING,5,"org.mortbay.xml.XmlParser.NotValidating");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 5},new Method("Ljava/lang/Boolean;","getBoolean",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitLabel(L7);
                code.visitJumpStmt(IF_NEZ,1,-1,L11);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 4},new Method("Ljava/lang/Boolean;","valueOf",new String[]{ "Ljava/lang/String;"},"Ljava/lang/Boolean;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/lang/Boolean;","booleanValue",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitJumpStmt(IF_EQZ,5,-1,L11);
                code.visitConstStmt(CONST_4,5, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt2R(MOVE,2,5);
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,2},new Method("Lorg/mortbay/xml/XmlParser;","setValidating",new String[]{ "Z"},"V"));
                code.visitLabel(L9);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L10);
                code.visitConstStmt(CONST_STRING,6,"false");
                code.visitJumpStmt(GOTO,-1,-1,L12);
                code.visitLabel(L11);
                code.visitConstStmt(CONST_4,5, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt2R(MOVE,2,5);
                code.visitJumpStmt(GOTO,-1,-1,L8);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/xml/XmlParser;","<init>",new String[]{ "Z"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"validating");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(82,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(55,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(58,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(83,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(84,L4);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljava/lang/Object;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/util/HashMap;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/util/HashMap;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/xml/XmlParser;","_redirectMap","Ljava/util/Map;"));
                code.visitLabel(L2);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/util/Stack;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/util/Stack;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/xml/XmlParser;","_observers","Ljava/util/Stack;"));
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Lorg/mortbay/xml/XmlParser;","setValidating",new String[]{ "Z"},"V"));
                code.visitLabel(L4);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_access$000(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_SYNTHETIC, new Method("Lorg/mortbay/xml/XmlParser;","access$000",new String[]{ "Lorg/mortbay/xml/XmlParser;"},"Ljavax/xml/parsers/SAXParser;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"x0");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(53,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/xml/XmlParser;","_parser","Ljavax/xml/parsers/SAXParser;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_access$100(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_SYNTHETIC, new Method("Lorg/mortbay/xml/XmlParser;","access$100",new String[]{ "Lorg/mortbay/xml/XmlParser;"},"Ljava/lang/Object;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"x0");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(53,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/xml/XmlParser;","_xpaths","Ljava/lang/Object;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_access$200(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_SYNTHETIC, new Method("Lorg/mortbay/xml/XmlParser;","access$200",new String[]{ "Lorg/mortbay/xml/XmlParser;"},"Ljava/util/Map;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"x0");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(53,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/xml/XmlParser;","_observerMap","Ljava/util/Map;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_access$300(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_SYNTHETIC, new Method("Lorg/mortbay/xml/XmlParser;","access$300",new String[]{ "Lorg/mortbay/xml/XmlParser;"},"Ljava/util/Stack;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"x0");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(53,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/xml/XmlParser;","_observers","Ljava/util/Stack;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_access$402(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_SYNTHETIC, new Method("Lorg/mortbay/xml/XmlParser;","access$402",new String[]{ "Lorg/mortbay/xml/XmlParser;","Ljava/lang/String;"},"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"x0");
                ddv.visitParameterName(1,"x1");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(53,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/xml/XmlParser;","_dtd","Ljava/lang/String;"));
                code.visitStmt1R(RETURN_OBJECT,1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m007_access$500(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_SYNTHETIC, new Method("Lorg/mortbay/xml/XmlParser;","access$500",new String[]{ "Lorg/mortbay/xml/XmlParser;"},"Ljava/util/Map;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"x0");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(53,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/xml/XmlParser;","_redirectMap","Ljava/util/Map;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m008_addContentHandler(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/xml/XmlParser;","addContentHandler",new String[]{ "Ljava/lang/String;","Lorg/xml/sax/ContentHandler;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"trigger");
                ddv.visitParameterName(1,"observer");
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(172,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(173,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(174,L5);
                ddv.visitLineNumber(175,L1);
                ddv.visitLineNumber(172,L2);
                code.visitLabel(L3);
                code.visitStmt1R(MONITOR_ENTER,1);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/xml/XmlParser;","_observerMap","Ljava/util/Map;"));
                code.visitJumpStmt(IF_NEZ,0,-1,L5);
                code.visitLabel(L4);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/util/HashMap;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/util/HashMap;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/xml/XmlParser;","_observerMap","Ljava/util/Map;"));
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/xml/XmlParser;","_observerMap","Ljava/util/Map;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,2,3},new Method("Ljava/util/Map;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L1);
                code.visitStmt1R(MONITOR_EXIT,1);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,0);
                code.visitStmt1R(MONITOR_EXIT,1);
                code.visitStmt1R(THROW,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m009_getDTD(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/xml/XmlParser;","getDTD",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(158,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/xml/XmlParser;","_dtd","Ljava/lang/String;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m010_getXpath(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/xml/XmlParser;","getXpath",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(137,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/xml/XmlParser;","_xpath","Ljava/lang/String;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m011_parse(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/xml/XmlParser;","parse",new String[]{ "Ljava/io/File;"},"Lorg/mortbay/xml/XmlParser$Node;"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visit(null, new DexType("Lorg/xml/sax/SAXException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"file");
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(213,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(214,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(215,L5);
                ddv.visitLineNumber(213,L2);
                code.visitLabel(L3);
                code.visitStmt1R(MONITOR_ENTER,2);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/log/Log;","isDebugEnabled",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L5);
                code.visitLabel(L4);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,1,"parse: ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L5);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/xml/sax/InputSource;");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/io/File;","toURL",new String[]{ },"Ljava/net/URL;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/net/URL;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Lorg/xml/sax/InputSource;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,0},new Method("Lorg/mortbay/xml/XmlParser;","parse",new String[]{ "Lorg/xml/sax/InputSource;"},"Lorg/mortbay/xml/XmlParser$Node;"));
                code.visitLabel(L1);
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt1R(MONITOR_EXIT,2);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,0);
                code.visitStmt1R(MONITOR_EXIT,2);
                code.visitStmt1R(THROW,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m012_parse(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/xml/XmlParser;","parse",new String[]{ "Ljava/io/InputStream;"},"Lorg/mortbay/xml/XmlParser$Node;"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visit(null, new DexType("Lorg/xml/sax/SAXException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L1},new String[]{ null});
                DexLabel L2=new DexLabel();
                DexLabel L3=new DexLabel();
                code.visitTryCatch(L2,L3,new DexLabel[]{L1},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"in");
                DexLabel L4=new DexLabel();
                ddv.visitPrologue(L4);
                ddv.visitLineNumber(224,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(225,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(226,L6);
                ddv.visitStartLocal(1,L6,"handler","Lorg/mortbay/xml/XmlParser$Handler;",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(227,L7);
                ddv.visitStartLocal(2,L7,"reader","Lorg/xml/sax/XMLReader;",null);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(228,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(229,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(230,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(231,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(232,L12);
                ddv.visitLineNumber(224,L1);
                ddv.visitEndLocal(1,L1);
                ddv.visitEndLocal(2,L1);
                ddv.visitLineNumber(233,L2);
                ddv.visitRestartLocal(1,L2);
                ddv.visitRestartLocal(2,L2);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(234,L13);
                ddv.visitStartLocal(0,L13,"doc","Lorg/mortbay/xml/XmlParser$Node;",null);
                ddv.visitLineNumber(235,L3);
                code.visitLabel(L4);
                code.visitStmt1R(MONITOR_ENTER,5);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,3,5,new Field("Lorg/mortbay/xml/XmlParser;","_dtd","Ljava/lang/String;"));
                code.visitLabel(L5);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Lorg/mortbay/xml/XmlParser$Handler;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,5},new Method("Lorg/mortbay/xml/XmlParser$Handler;","<init>",new String[]{ "Lorg/mortbay/xml/XmlParser;"},"V"));
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,3,5,new Field("Lorg/mortbay/xml/XmlParser;","_parser","Ljavax/xml/parsers/SAXParser;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljavax/xml/parsers/SAXParser;","getXMLReader",new String[]{ },"Lorg/xml/sax/XMLReader;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2,1},new Method("Lorg/xml/sax/XMLReader;","setContentHandler",new String[]{ "Lorg/xml/sax/ContentHandler;"},"V"));
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2,1},new Method("Lorg/xml/sax/XMLReader;","setErrorHandler",new String[]{ "Lorg/xml/sax/ErrorHandler;"},"V"));
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2,1},new Method("Lorg/xml/sax/XMLReader;","setEntityResolver",new String[]{ "Lorg/xml/sax/EntityResolver;"},"V"));
                code.visitLabel(L10);
                code.visitFieldStmt(IGET_OBJECT,3,5,new Field("Lorg/mortbay/xml/XmlParser;","_parser","Ljavax/xml/parsers/SAXParser;"));
                code.visitTypeStmt(NEW_INSTANCE,4,-1,"Lorg/xml/sax/InputSource;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4,6},new Method("Lorg/xml/sax/InputSource;","<init>",new String[]{ "Ljava/io/InputStream;"},"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4,1},new Method("Ljavax/xml/parsers/SAXParser;","parse",new String[]{ "Lorg/xml/sax/InputSource;","Lorg/xml/sax/helpers/DefaultHandler;"},"V"));
                code.visitLabel(L11);
                code.visitFieldStmt(IGET_OBJECT,3,1,new Field("Lorg/mortbay/xml/XmlParser$Handler;","_error","Lorg/xml/sax/SAXParseException;"));
                code.visitJumpStmt(IF_EQZ,3,-1,L2);
                code.visitLabel(L12);
                code.visitFieldStmt(IGET_OBJECT,3,1,new Field("Lorg/mortbay/xml/XmlParser$Handler;","_error","Lorg/xml/sax/SAXParseException;"));
                code.visitStmt1R(THROW,3);
                code.visitLabel(L1);
                code.visitStmt1R(MOVE_EXCEPTION,3);
                code.visitStmt1R(MONITOR_EXIT,5);
                code.visitStmt1R(THROW,3);
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,3,1,new Field("Lorg/mortbay/xml/XmlParser$Handler;","_top","Lorg/mortbay/xml/XmlParser$Node;"));
                code.visitConstStmt(CONST_4,4, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Lorg/mortbay/xml/XmlParser$Node;","get",new String[]{ "I"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Lorg/mortbay/xml/XmlParser$Node;");
                code.visitLabel(L13);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/xml/XmlParser$Handler;","clear",new String[]{ },"V"));
                code.visitLabel(L3);
                code.visitStmt1R(MONITOR_EXIT,5);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m013_parse(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/xml/XmlParser;","parse",new String[]{ "Ljava/lang/String;"},"Lorg/mortbay/xml/XmlParser$Node;"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visit(null, new DexType("Lorg/xml/sax/SAXException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"url");
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(202,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(203,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(204,L5);
                ddv.visitLineNumber(202,L2);
                code.visitLabel(L3);
                code.visitStmt1R(MONITOR_ENTER,2);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/log/Log;","isDebugEnabled",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L5);
                code.visitLabel(L4);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,1,"parse: ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L5);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/xml/sax/InputSource;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,3},new Method("Lorg/xml/sax/InputSource;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,0},new Method("Lorg/mortbay/xml/XmlParser;","parse",new String[]{ "Lorg/xml/sax/InputSource;"},"Lorg/mortbay/xml/XmlParser$Node;"));
                code.visitLabel(L1);
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt1R(MONITOR_EXIT,2);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,0);
                code.visitStmt1R(MONITOR_EXIT,2);
                code.visitStmt1R(THROW,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m014_parse(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/xml/XmlParser;","parse",new String[]{ "Lorg/xml/sax/InputSource;"},"Lorg/mortbay/xml/XmlParser$Node;"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visit(null, new DexType("Lorg/xml/sax/SAXException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L1},new String[]{ null});
                DexLabel L2=new DexLabel();
                DexLabel L3=new DexLabel();
                code.visitTryCatch(L2,L3,new DexLabel[]{L1},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"source");
                DexLabel L4=new DexLabel();
                ddv.visitPrologue(L4);
                ddv.visitLineNumber(180,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(181,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(182,L6);
                ddv.visitStartLocal(1,L6,"handler","Lorg/mortbay/xml/XmlParser$Handler;",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(183,L7);
                ddv.visitStartLocal(2,L7,"reader","Lorg/xml/sax/XMLReader;",null);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(184,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(185,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(186,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(187,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(188,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(189,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(190,L14);
                ddv.visitLineNumber(180,L1);
                ddv.visitEndLocal(1,L1);
                ddv.visitEndLocal(2,L1);
                ddv.visitLineNumber(191,L2);
                ddv.visitRestartLocal(1,L2);
                ddv.visitRestartLocal(2,L2);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(192,L15);
                ddv.visitStartLocal(0,L15,"doc","Lorg/mortbay/xml/XmlParser$Node;",null);
                ddv.visitLineNumber(193,L3);
                code.visitLabel(L4);
                code.visitStmt1R(MONITOR_ENTER,5);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,3,5,new Field("Lorg/mortbay/xml/XmlParser;","_dtd","Ljava/lang/String;"));
                code.visitLabel(L5);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Lorg/mortbay/xml/XmlParser$Handler;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,5},new Method("Lorg/mortbay/xml/XmlParser$Handler;","<init>",new String[]{ "Lorg/mortbay/xml/XmlParser;"},"V"));
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,3,5,new Field("Lorg/mortbay/xml/XmlParser;","_parser","Ljavax/xml/parsers/SAXParser;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljavax/xml/parsers/SAXParser;","getXMLReader",new String[]{ },"Lorg/xml/sax/XMLReader;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2,1},new Method("Lorg/xml/sax/XMLReader;","setContentHandler",new String[]{ "Lorg/xml/sax/ContentHandler;"},"V"));
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2,1},new Method("Lorg/xml/sax/XMLReader;","setErrorHandler",new String[]{ "Lorg/xml/sax/ErrorHandler;"},"V"));
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2,1},new Method("Lorg/xml/sax/XMLReader;","setEntityResolver",new String[]{ "Lorg/xml/sax/EntityResolver;"},"V"));
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/log/Log;","isDebugEnabled",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_EQZ,3,-1,L12);
                code.visitLabel(L11);
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,4,"parsing: sid=");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/xml/sax/InputSource;","getSystemId",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitConstStmt(CONST_STRING,4,",pid=");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/xml/sax/InputSource;","getPublicId",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L12);
                code.visitFieldStmt(IGET_OBJECT,3,5,new Field("Lorg/mortbay/xml/XmlParser;","_parser","Ljavax/xml/parsers/SAXParser;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,6,1},new Method("Ljavax/xml/parsers/SAXParser;","parse",new String[]{ "Lorg/xml/sax/InputSource;","Lorg/xml/sax/helpers/DefaultHandler;"},"V"));
                code.visitLabel(L13);
                code.visitFieldStmt(IGET_OBJECT,3,1,new Field("Lorg/mortbay/xml/XmlParser$Handler;","_error","Lorg/xml/sax/SAXParseException;"));
                code.visitJumpStmt(IF_EQZ,3,-1,L2);
                code.visitLabel(L14);
                code.visitFieldStmt(IGET_OBJECT,3,1,new Field("Lorg/mortbay/xml/XmlParser$Handler;","_error","Lorg/xml/sax/SAXParseException;"));
                code.visitStmt1R(THROW,3);
                code.visitLabel(L1);
                code.visitStmt1R(MOVE_EXCEPTION,3);
                code.visitStmt1R(MONITOR_EXIT,5);
                code.visitStmt1R(THROW,3);
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,3,1,new Field("Lorg/mortbay/xml/XmlParser$Handler;","_top","Lorg/mortbay/xml/XmlParser$Node;"));
                code.visitConstStmt(CONST_4,4, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Lorg/mortbay/xml/XmlParser$Node;","get",new String[]{ "I"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Lorg/mortbay/xml/XmlParser$Node;");
                code.visitLabel(L15);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/xml/XmlParser$Handler;","clear",new String[]{ },"V"));
                code.visitLabel(L3);
                code.visitStmt1R(MONITOR_EXIT,5);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m015_redirectEntity(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/xml/XmlParser;","redirectEntity",new String[]{ "Ljava/lang/String;","Ljava/net/URL;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                ddv.visitParameterName(1,"entity");
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(126,L3);
                ddv.visitLineNumber(127,L0);
                ddv.visitLineNumber(128,L1);
                ddv.visitLineNumber(126,L2);
                code.visitLabel(L3);
                code.visitStmt1R(MONITOR_ENTER,1);
                code.visitJumpStmt(IF_EQZ,3,-1,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/xml/XmlParser;","_redirectMap","Ljava/util/Map;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,2,3},new Method("Ljava/util/Map;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L1);
                code.visitStmt1R(MONITOR_EXIT,1);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,0);
                code.visitStmt1R(MONITOR_EXIT,1);
                code.visitStmt1R(THROW,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m016_setValidating(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/xml/XmlParser;","setValidating",new String[]{ "Z"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/lang/Exception;"});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                DexLabel L5=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L5},new String[]{ "Ljava/lang/Exception;"});
                DexLabel L6=new DexLabel();
                code.visitTryCatch(L4,L6,new DexLabel[]{L2},new String[]{ "Ljava/lang/Exception;"});
                DexLabel L7=new DexLabel();
                DexLabel L8=new DexLabel();
                code.visitTryCatch(L7,L8,new DexLabel[]{L2},new String[]{ "Ljava/lang/Exception;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"validating");
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(91,L0);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(92,L9);
                ddv.visitStartLocal(1,L9,"factory","Ljavax/xml/parsers/SAXParserFactory;",null);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(93,L10);
                ddv.visitLineNumber(97,L1);
                ddv.visitLineNumber(98,L3);
                ddv.visitLineNumber(108,L4);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(109,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(110,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(117,L13);
                ddv.visitLineNumber(100,L5);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(102,L14);
                ddv.visitStartLocal(0,L14,"e","Ljava/lang/Exception;",null);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(103,L15);
                ddv.visitLineNumber(112,L2);
                ddv.visitEndLocal(1,L2);
                ddv.visitEndLocal(0,L2);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(114,L16);
                ddv.visitRestartLocal(0,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(115,L17);
                ddv.visitLineNumber(105,L7);
                ddv.visitRestartLocal(1,L7);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Ljavax/xml/parsers/SAXParserFactory;","newInstance",new String[]{ },"Ljavax/xml/parsers/SAXParserFactory;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,6},new Method("Ljavax/xml/parsers/SAXParserFactory;","setValidating",new String[]{ "Z"},"V"));
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljavax/xml/parsers/SAXParserFactory;","newSAXParser",new String[]{ },"Ljavax/xml/parsers/SAXParser;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitFieldStmt(IPUT_OBJECT,2,5,new Field("Lorg/mortbay/xml/XmlParser;","_parser","Ljavax/xml/parsers/SAXParser;"));
                code.visitLabel(L1);
                code.visitJumpStmt(IF_EQZ,6,-1,L4);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/xml/XmlParser;","_parser","Ljavax/xml/parsers/SAXParser;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljavax/xml/parsers/SAXParser;","getXMLReader",new String[]{ },"Lorg/xml/sax/XMLReader;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitConstStmt(CONST_STRING,3,"http://apache.org/xml/features/validation/schema");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2,3,6},new Method("Lorg/xml/sax/XMLReader;","setFeature",new String[]{ "Ljava/lang/String;","Z"},"V"));
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/xml/XmlParser;","_parser","Ljavax/xml/parsers/SAXParser;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljavax/xml/parsers/SAXParser;","getXMLReader",new String[]{ },"Lorg/xml/sax/XMLReader;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitConstStmt(CONST_STRING,3,"http://xml.org/sax/features/validation");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2,3,6},new Method("Lorg/xml/sax/XMLReader;","setFeature",new String[]{ "Ljava/lang/String;","Z"},"V"));
                code.visitLabel(L11);
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/xml/XmlParser;","_parser","Ljavax/xml/parsers/SAXParser;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljavax/xml/parsers/SAXParser;","getXMLReader",new String[]{ },"Lorg/xml/sax/XMLReader;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitConstStmt(CONST_STRING,3,"http://xml.org/sax/features/namespaces");
                code.visitConstStmt(CONST_4,4, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2,3,4},new Method("Lorg/xml/sax/XMLReader;","setFeature",new String[]{ "Ljava/lang/String;","Z"},"V"));
                code.visitLabel(L12);
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/xml/XmlParser;","_parser","Ljavax/xml/parsers/SAXParser;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljavax/xml/parsers/SAXParser;","getXMLReader",new String[]{ },"Lorg/xml/sax/XMLReader;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitConstStmt(CONST_STRING,3,"http://xml.org/sax/features/namespace-prefixes");
                code.visitConstStmt(CONST_4,4, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2,3,4},new Method("Lorg/xml/sax/XMLReader;","setFeature",new String[]{ "Ljava/lang/String;","Z"},"V"));
                code.visitLabel(L13);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L5);
                code.visitStmt1R(MOVE_EXCEPTION,2);
                code.visitStmt2R(MOVE_OBJECT,0,2);
                code.visitLabel(L14);
                code.visitJumpStmt(IF_EQZ,6,-1,L7);
                code.visitLabel(L15);
                code.visitConstStmt(CONST_STRING,2,"Schema validation may not be supported: ");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2,0},new Method("Lorg/mortbay/log/Log;","warn",new String[]{ "Ljava/lang/String;","Ljava/lang/Throwable;"},"V"));
                code.visitLabel(L6);
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,2);
                code.visitStmt2R(MOVE_OBJECT,0,2);
                code.visitLabel(L16);
                code.visitConstStmt(CONST_STRING,2,"EXCEPTION ");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2,0},new Method("Lorg/mortbay/log/Log;","warn",new String[]{ "Ljava/lang/String;","Ljava/lang/Throwable;"},"V"));
                code.visitLabel(L17);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Ljava/lang/Error;");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/Exception;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2,3},new Method("Ljava/lang/Error;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,2);
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/log/Log;","ignore",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitLabel(L8);
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m017_setXpath(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/xml/XmlParser;","setXpath",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"xpath");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(149,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(150,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(151,L2);
                ddv.visitStartLocal(0,L2,"tok","Ljava/util/StringTokenizer;",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(152,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(153,L4);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,4,3,new Field("Lorg/mortbay/xml/XmlParser;","_xpath","Ljava/lang/String;"));
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/util/StringTokenizer;");
                code.visitConstStmt(CONST_STRING,1,"| ");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,4,1},new Method("Ljava/util/StringTokenizer;","<init>",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"V"));
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/util/StringTokenizer;","hasMoreTokens",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_EQZ,1,-1,L4);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/xml/XmlParser;","_xpaths","Ljava/lang/Object;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/util/StringTokenizer;","nextToken",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1,2},new Method("Lorg/mortbay/util/LazyList;","add",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitFieldStmt(IPUT_OBJECT,1,3,new Field("Lorg/mortbay/xml/XmlParser;","_xpaths","Ljava/lang/Object;"));
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L4);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
