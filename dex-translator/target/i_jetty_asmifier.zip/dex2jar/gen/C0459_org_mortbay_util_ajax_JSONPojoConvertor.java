package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0459_org_mortbay_util_ajax_JSONPojoConvertor {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/util/ajax/JSONPojoConvertor;","Ljava/lang/Object;",new String[]{ "Lorg/mortbay/util/ajax/JSON$Convertor;"});
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("JSONPojoConvertor.java");
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/MemberClasses;", Visibility.SYSTEM);
            if(av00 != null) {
                {
                    DexAnnotationVisitor av01 = av00.visitArray("value");
                    if(av01 != null) {
                        av01.visit(null, new DexType("Lorg/mortbay/util/ajax/JSONPojoConvertor$NumberType;"));
                        av01.visit(null, new DexType("Lorg/mortbay/util/ajax/JSONPojoConvertor$Setter;"));
                        av01.visitEnd();
                    }
                }
                av00.visitEnd();
            }
        }
        f000_DOUBLE(cv);
        f001_FLOAT(cv);
        f002_GETTER_ARG(cv);
        f003_INTEGER(cv);
        f004_LONG(cv);
        f005_NULL_ARG(cv);
        f006_SHORT(cv);
        f007___numberTypes(cv);
        f008__excluded(cv);
        f009__fromJSON(cv);
        f010__getters(cv);
        f011__pojoClass(cv);
        f012__setters(cv);
        m000__clinit_(cv);
        m001__init_(cv);
        m002__init_(cv);
        m003__init_(cv);
        m004__init_(cv);
        m005__init_(cv);
        m006_access$000(cv);
        m007_getNumberType(cv);
        m008_addGetter(cv);
        m009_addSetter(cv);
        m010_fromJSON(cv);
        m011_getExcludedCount(cv);
        m012_getSetter(cv);
        m013_includeField(cv);
        m014_init(cv);
        m015_log(cv);
        m016_setProps(cv);
        m017_toJSON(cv);
    }
    public static void f000_DOUBLE(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/util/ajax/JSONPojoConvertor;","DOUBLE","Lorg/mortbay/util/ajax/JSONPojoConvertor$NumberType;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001_FLOAT(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/util/ajax/JSONPojoConvertor;","FLOAT","Lorg/mortbay/util/ajax/JSONPojoConvertor$NumberType;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002_GETTER_ARG(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/util/ajax/JSONPojoConvertor;","GETTER_ARG","[Ljava/lang/Object;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003_INTEGER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/util/ajax/JSONPojoConvertor;","INTEGER","Lorg/mortbay/util/ajax/JSONPojoConvertor$NumberType;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f004_LONG(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/util/ajax/JSONPojoConvertor;","LONG","Lorg/mortbay/util/ajax/JSONPojoConvertor$NumberType;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f005_NULL_ARG(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/util/ajax/JSONPojoConvertor;","NULL_ARG","[Ljava/lang/Object;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f006_SHORT(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/util/ajax/JSONPojoConvertor;","SHORT","Lorg/mortbay/util/ajax/JSONPojoConvertor$NumberType;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f007___numberTypes(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/util/ajax/JSONPojoConvertor;","__numberTypes","Ljava/util/Map;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f008__excluded(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/util/ajax/JSONPojoConvertor;","_excluded","Ljava/util/Set;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f009__fromJSON(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/util/ajax/JSONPojoConvertor;","_fromJSON","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f010__getters(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/util/ajax/JSONPojoConvertor;","_getters","Ljava/util/Map;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f011__pojoClass(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/util/ajax/JSONPojoConvertor;","_pojoClass","Ljava/lang/Class;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f012__setters(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/util/ajax/JSONPojoConvertor;","_setters","Ljava/util/Map;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__clinit_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/util/ajax/JSONPojoConvertor;","<clinit>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(44,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(45,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(341,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(349,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(357,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(365,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(373,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(383,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(384,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(385,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(386,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(387,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(388,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(389,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(390,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(391,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(392,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(393,L18);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_ARRAY,0,2,"[Ljava/lang/Object;");
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/util/ajax/JSONPojoConvertor;","GETTER_ARG","[Ljava/lang/Object;"));
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitTypeStmt(NEW_ARRAY,0,0,"[Ljava/lang/Object;");
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt3R(APUT_OBJECT,1,0,2);
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/util/ajax/JSONPojoConvertor;","NULL_ARG","[Ljava/lang/Object;"));
                code.visitLabel(L2);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/util/HashMap;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/util/HashMap;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/util/ajax/JSONPojoConvertor;","__numberTypes","Ljava/util/Map;"));
                code.visitLabel(L3);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/util/ajax/JSONPojoConvertor$1;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Lorg/mortbay/util/ajax/JSONPojoConvertor$1;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/util/ajax/JSONPojoConvertor;","SHORT","Lorg/mortbay/util/ajax/JSONPojoConvertor$NumberType;"));
                code.visitLabel(L4);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/util/ajax/JSONPojoConvertor$2;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Lorg/mortbay/util/ajax/JSONPojoConvertor$2;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/util/ajax/JSONPojoConvertor;","INTEGER","Lorg/mortbay/util/ajax/JSONPojoConvertor$NumberType;"));
                code.visitLabel(L5);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/util/ajax/JSONPojoConvertor$3;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Lorg/mortbay/util/ajax/JSONPojoConvertor$3;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/util/ajax/JSONPojoConvertor;","FLOAT","Lorg/mortbay/util/ajax/JSONPojoConvertor$NumberType;"));
                code.visitLabel(L6);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/util/ajax/JSONPojoConvertor$4;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Lorg/mortbay/util/ajax/JSONPojoConvertor$4;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/util/ajax/JSONPojoConvertor;","LONG","Lorg/mortbay/util/ajax/JSONPojoConvertor$NumberType;"));
                code.visitLabel(L7);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/util/ajax/JSONPojoConvertor$5;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Lorg/mortbay/util/ajax/JSONPojoConvertor$5;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/util/ajax/JSONPojoConvertor;","DOUBLE","Lorg/mortbay/util/ajax/JSONPojoConvertor$NumberType;"));
                code.visitLabel(L8);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/util/ajax/JSONPojoConvertor;","__numberTypes","Ljava/util/Map;"));
                code.visitConstStmt(CONST_CLASS,1,new DexType("Ljava/lang/Short;"));
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/util/ajax/JSONPojoConvertor;","SHORT","Lorg/mortbay/util/ajax/JSONPojoConvertor$NumberType;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1,2},new Method("Ljava/util/Map;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L9);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/util/ajax/JSONPojoConvertor;","__numberTypes","Ljava/util/Map;"));
                code.visitFieldStmt(SGET_OBJECT,1,-1,new Field("Ljava/lang/Short;","TYPE","Ljava/lang/Class;"));
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/util/ajax/JSONPojoConvertor;","SHORT","Lorg/mortbay/util/ajax/JSONPojoConvertor$NumberType;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1,2},new Method("Ljava/util/Map;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L10);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/util/ajax/JSONPojoConvertor;","__numberTypes","Ljava/util/Map;"));
                code.visitConstStmt(CONST_CLASS,1,new DexType("Ljava/lang/Integer;"));
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/util/ajax/JSONPojoConvertor;","INTEGER","Lorg/mortbay/util/ajax/JSONPojoConvertor$NumberType;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1,2},new Method("Ljava/util/Map;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L11);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/util/ajax/JSONPojoConvertor;","__numberTypes","Ljava/util/Map;"));
                code.visitFieldStmt(SGET_OBJECT,1,-1,new Field("Ljava/lang/Integer;","TYPE","Ljava/lang/Class;"));
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/util/ajax/JSONPojoConvertor;","INTEGER","Lorg/mortbay/util/ajax/JSONPojoConvertor$NumberType;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1,2},new Method("Ljava/util/Map;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L12);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/util/ajax/JSONPojoConvertor;","__numberTypes","Ljava/util/Map;"));
                code.visitConstStmt(CONST_CLASS,1,new DexType("Ljava/lang/Long;"));
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/util/ajax/JSONPojoConvertor;","LONG","Lorg/mortbay/util/ajax/JSONPojoConvertor$NumberType;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1,2},new Method("Ljava/util/Map;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L13);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/util/ajax/JSONPojoConvertor;","__numberTypes","Ljava/util/Map;"));
                code.visitFieldStmt(SGET_OBJECT,1,-1,new Field("Ljava/lang/Long;","TYPE","Ljava/lang/Class;"));
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/util/ajax/JSONPojoConvertor;","LONG","Lorg/mortbay/util/ajax/JSONPojoConvertor$NumberType;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1,2},new Method("Ljava/util/Map;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L14);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/util/ajax/JSONPojoConvertor;","__numberTypes","Ljava/util/Map;"));
                code.visitConstStmt(CONST_CLASS,1,new DexType("Ljava/lang/Float;"));
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/util/ajax/JSONPojoConvertor;","FLOAT","Lorg/mortbay/util/ajax/JSONPojoConvertor$NumberType;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1,2},new Method("Ljava/util/Map;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L15);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/util/ajax/JSONPojoConvertor;","__numberTypes","Ljava/util/Map;"));
                code.visitFieldStmt(SGET_OBJECT,1,-1,new Field("Ljava/lang/Float;","TYPE","Ljava/lang/Class;"));
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/util/ajax/JSONPojoConvertor;","FLOAT","Lorg/mortbay/util/ajax/JSONPojoConvertor$NumberType;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1,2},new Method("Ljava/util/Map;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L16);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/util/ajax/JSONPojoConvertor;","__numberTypes","Ljava/util/Map;"));
                code.visitConstStmt(CONST_CLASS,1,new DexType("Ljava/lang/Double;"));
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/util/ajax/JSONPojoConvertor;","DOUBLE","Lorg/mortbay/util/ajax/JSONPojoConvertor$NumberType;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1,2},new Method("Ljava/util/Map;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L17);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/util/ajax/JSONPojoConvertor;","__numberTypes","Ljava/util/Map;"));
                code.visitFieldStmt(SGET_OBJECT,1,-1,new Field("Ljava/lang/Double;","TYPE","Ljava/lang/Class;"));
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/util/ajax/JSONPojoConvertor;","DOUBLE","Lorg/mortbay/util/ajax/JSONPojoConvertor$NumberType;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1,2},new Method("Ljava/util/Map;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L18);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/util/ajax/JSONPojoConvertor;","<init>",new String[]{ "Ljava/lang/Class;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"pojoClass");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(60,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(61,L1);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitTypeStmt(CHECK_CAST,0,-1,"Ljava/util/Set;");
                code.visitConstStmt(CONST_4,1, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2,3,0,1},new Method("Lorg/mortbay/util/ajax/JSONPojoConvertor;","<init>",new String[]{ "Ljava/lang/Class;","Ljava/util/Set;","Z"},"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/util/ajax/JSONPojoConvertor;","<init>",new String[]{ "Ljava/lang/Class;","Ljava/util/Set;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"pojoClass");
                ddv.visitParameterName(1,"excluded");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(70,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(71,L1);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,2,3,0},new Method("Lorg/mortbay/util/ajax/JSONPojoConvertor;","<init>",new String[]{ "Ljava/lang/Class;","Ljava/util/Set;","Z"},"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/util/ajax/JSONPojoConvertor;","<init>",new String[]{ "Ljava/lang/Class;","Ljava/util/Set;","Z"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"pojoClass");
                ddv.visitParameterName(1,"excluded");
                ddv.visitParameterName(2,"fromJSON");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(74,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(54,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(55,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(75,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(76,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(77,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(78,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(79,L7);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljava/lang/Object;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/util/HashMap;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/util/HashMap;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/util/ajax/JSONPojoConvertor;","_getters","Ljava/util/Map;"));
                code.visitLabel(L2);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/util/HashMap;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/util/HashMap;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/util/ajax/JSONPojoConvertor;","_setters","Ljava/util/Map;"));
                code.visitLabel(L3);
                code.visitFieldStmt(IPUT_OBJECT,2,1,new Field("Lorg/mortbay/util/ajax/JSONPojoConvertor;","_pojoClass","Ljava/lang/Class;"));
                code.visitLabel(L4);
                code.visitFieldStmt(IPUT_OBJECT,3,1,new Field("Lorg/mortbay/util/ajax/JSONPojoConvertor;","_excluded","Ljava/util/Set;"));
                code.visitLabel(L5);
                code.visitFieldStmt(IPUT_BOOLEAN,4,1,new Field("Lorg/mortbay/util/ajax/JSONPojoConvertor;","_fromJSON","Z"));
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/util/ajax/JSONPojoConvertor;","init",new String[]{ },"V"));
                code.visitLabel(L7);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/util/ajax/JSONPojoConvertor;","<init>",new String[]{ "Ljava/lang/Class;","Z"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"pojoClass");
                ddv.visitParameterName(1,"fromJSON");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(83,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(84,L1);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitTypeStmt(CHECK_CAST,0,-1,"Ljava/util/Set;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,2,0,3},new Method("Lorg/mortbay/util/ajax/JSONPojoConvertor;","<init>",new String[]{ "Ljava/lang/Class;","Ljava/util/Set;","Z"},"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/util/ajax/JSONPojoConvertor;","<init>",new String[]{ "Ljava/lang/Class;","[Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"pojoClass");
                ddv.visitParameterName(1,"excluded");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(65,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(66,L1);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/util/HashSet;");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 4},new Method("Ljava/util/Arrays;","asList",new String[]{ "[Ljava/lang/Object;"},"Ljava/util/List;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Ljava/util/HashSet;","<init>",new String[]{ "Ljava/util/Collection;"},"V"));
                code.visitConstStmt(CONST_4,1, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2,3,0,1},new Method("Lorg/mortbay/util/ajax/JSONPojoConvertor;","<init>",new String[]{ "Ljava/lang/Class;","Ljava/util/Set;","Z"},"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_access$000(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_SYNTHETIC, new Method("Lorg/mortbay/util/ajax/JSONPojoConvertor;","access$000",new String[]{ },"Ljava/util/Map;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(41,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/util/ajax/JSONPojoConvertor;","__numberTypes","Ljava/util/Map;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m007_getNumberType(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/util/ajax/JSONPojoConvertor;","getNumberType",new String[]{ "Ljava/lang/Class;"},"Lorg/mortbay/util/ajax/JSONPojoConvertor$NumberType;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"clazz");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(49,L0);
                DexLabel L1=new DexLabel();
                ddv.visitEndLocal(1,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/util/ajax/JSONPojoConvertor;","__numberTypes","Ljava/util/Map;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1},new Method("Ljava/util/Map;","get",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L1);
                code.visitTypeStmt(CHECK_CAST,1,-1,"Lorg/mortbay/util/ajax/JSONPojoConvertor$NumberType;");
                code.visitStmt1R(RETURN_OBJECT,1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m008_addGetter(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/util/ajax/JSONPojoConvertor;","addGetter",new String[]{ "Ljava/lang/String;","Ljava/lang/reflect/Method;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                ddv.visitParameterName(1,"method");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(128,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(129,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/util/ajax/JSONPojoConvertor;","_getters","Ljava/util/Map;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,2,3},new Method("Ljava/util/Map;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m009_addSetter(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/util/ajax/JSONPojoConvertor;","addSetter",new String[]{ "Ljava/lang/String;","Ljava/lang/reflect/Method;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                ddv.visitParameterName(1,"method");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(134,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(135,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/util/ajax/JSONPojoConvertor;","_setters","Ljava/util/Map;"));
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Lorg/mortbay/util/ajax/JSONPojoConvertor$Setter;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,3,4},new Method("Lorg/mortbay/util/ajax/JSONPojoConvertor$Setter;","<init>",new String[]{ "Ljava/lang/String;","Ljava/lang/reflect/Method;"},"V"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,3,1},new Method("Ljava/util/Map;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m010_fromJSON(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/ajax/JSONPojoConvertor;","fromJSON",new String[]{ "Ljava/util/Map;"},"Ljava/lang/Object;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/lang/Exception;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"object");
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(158,L3);
                ddv.visitLineNumber(161,L0);
                ddv.visitStartLocal(1,L0,"obj","Ljava/lang/Object;",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(168,L4);
                ddv.visitStartLocal(1,L4,"obj","Ljava/lang/Object;",null);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(169,L5);
                ddv.visitLineNumber(163,L2);
                ddv.visitStartLocal(1,L2,"obj","Ljava/lang/Object;",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(166,L6);
                ddv.visitStartLocal(0,L6,"e","Ljava/lang/Exception;",null);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,2,3,new Field("Lorg/mortbay/util/ajax/JSONPojoConvertor;","_pojoClass","Ljava/lang/Class;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/lang/Class;","newInstance",new String[]{ },"Ljava/lang/Object;"));
                code.visitLabel(L1);
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,1,4},new Method("Lorg/mortbay/util/ajax/JSONPojoConvertor;","setProps",new String[]{ "Ljava/lang/Object;","Ljava/util/Map;"},"I"));
                code.visitLabel(L5);
                code.visitStmt1R(RETURN_OBJECT,1);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,2);
                code.visitStmt2R(MOVE_OBJECT,0,2);
                code.visitLabel(L6);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Ljava/lang/RuntimeException;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2,0},new Method("Ljava/lang/RuntimeException;","<init>",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitStmt1R(THROW,2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m011_getExcludedCount(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/util/ajax/JSONPojoConvertor;","getExcludedCount",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(152,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/util/ajax/JSONPojoConvertor;","_excluded","Ljava/util/Set;"));
                DexLabel L1=new DexLabel();
                code.visitJumpStmt(IF_NEZ,0,-1,L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                DexLabel L2=new DexLabel();
                code.visitLabel(L2);
                code.visitStmt1R(RETURN,0);
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/util/ajax/JSONPojoConvertor;","_excluded","Ljava/util/Set;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Ljava/util/Set;","size",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m012_getSetter(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/util/ajax/JSONPojoConvertor;","getSetter",new String[]{ "Ljava/lang/String;"},"Lorg/mortbay/util/ajax/JSONPojoConvertor$Setter;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(140,L0);
                DexLabel L1=new DexLabel();
                ddv.visitEndLocal(1,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/util/ajax/JSONPojoConvertor;","_setters","Ljava/util/Map;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,2},new Method("Ljava/util/Map;","get",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L1);
                code.visitTypeStmt(CHECK_CAST,1,-1,"Lorg/mortbay/util/ajax/JSONPojoConvertor$Setter;");
                code.visitStmt1R(RETURN_OBJECT,1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m013_includeField(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/util/ajax/JSONPojoConvertor;","includeField",new String[]{ "Ljava/lang/String;","Ljava/lang/reflect/Method;"},"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                ddv.visitParameterName(1,"m");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(146,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/util/ajax/JSONPojoConvertor;","_excluded","Ljava/util/Set;"));
                DexLabel L1=new DexLabel();
                code.visitJumpStmt(IF_EQZ,0,-1,L1);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/util/ajax/JSONPojoConvertor;","_excluded","Ljava/util/Set;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,2},new Method("Ljava/util/Set;","contains",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                DexLabel L2=new DexLabel();
                code.visitJumpStmt(IF_NEZ,0,-1,L2);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                DexLabel L3=new DexLabel();
                code.visitLabel(L3);
                code.visitStmt1R(RETURN,0);
                code.visitLabel(L2);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m014_init(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/util/ajax/JSONPojoConvertor;","init",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(10);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(89,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(90,L2);
                ddv.visitStartLocal(2,L2,"methods","[Ljava/lang/reflect/Method;",null);
                DexLabel L3=new DexLabel();
                ddv.visitStartLocal(0,L3,"i","I",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(92,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(93,L5);
                ddv.visitStartLocal(1,L5,"m","Ljava/lang/reflect/Method;",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(95,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(96,L7);
                ddv.visitStartLocal(3,L7,"name","Ljava/lang/String;",null);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(90,L8);
                ddv.visitEndLocal(3,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(100,L9);
                ddv.visitRestartLocal(3,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(102,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(103,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(108,L12);
                ddv.visitRestartLocal(3,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(109,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(104,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(105,L15);
                DexLabel L16=new DexLabel();
                ddv.visitRestartLocal(3,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(113,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(115,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(116,L19);
                ddv.visitRestartLocal(3,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(117,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(123,L21);
                ddv.visitEndLocal(1,L21);
                ddv.visitEndLocal(3,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(96,L22);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,8, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitConstStmt(CONST_4,7, Integer.valueOf(4)); // int: 0x00000004  float:0.000000
                code.visitConstStmt(CONST_4,6, Integer.valueOf(3)); // int: 0x00000003  float:0.000000
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,4,9,new Field("Lorg/mortbay/util/ajax/JSONPojoConvertor;","_pojoClass","Ljava/lang/Class;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/lang/Class;","getMethods",new String[]{ },"[Ljava/lang/reflect/Method;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L2);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L3);
                code.visitStmt2R(ARRAY_LENGTH,4,2);
                code.visitJumpStmt(IF_GE,0,4,L21);
                code.visitLabel(L4);
                code.visitStmt3R(AGET_OBJECT,1,2,0);
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/lang/reflect/Method;","getModifiers",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 4},new Method("Ljava/lang/reflect/Modifier;","isStatic",new String[]{ "I"},"Z"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitJumpStmt(IF_NEZ,4,-1,L8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/lang/reflect/Method;","getDeclaringClass",new String[]{ },"Ljava/lang/Class;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitConstStmt(CONST_CLASS,5,new DexType("Ljava/lang/Object;"));
                code.visitJumpStmt(IF_EQ,4,5,L8);
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/lang/reflect/Method;","getName",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/lang/reflect/Method;","getParameterTypes",new String[]{ },"[Ljava/lang/Class;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitStmt2R(ARRAY_LENGTH,4,4);
                code.visitSparseSwitchStmt(PACKED_SWITCH,4,0,new DexLabel[]{L9,L17});
                code.visitLabel(L8);
                code.visitStmt2R1N(ADD_INT_LIT8,0,0,1);
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/lang/reflect/Method;","getReturnType",new String[]{ },"Ljava/lang/Class;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitJumpStmt(IF_EQZ,4,-1,L8);
                code.visitLabel(L10);
                code.visitConstStmt(CONST_STRING,4,"is");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/String;","startsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitJumpStmt(IF_EQZ,4,-1,L14);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitJumpStmt(IF_LE,4,8,L14);
                code.visitLabel(L11);
                code.visitTypeStmt(NEW_INSTANCE,4,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,8,6},new Method("Ljava/lang/String;","substring",new String[]{ "I","I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/lang/String;","toLowerCase",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,6},new Method("Ljava/lang/String;","substring",new String[]{ "I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitLabel(L12);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9,3,1},new Method("Lorg/mortbay/util/ajax/JSONPojoConvertor;","includeField",new String[]{ "Ljava/lang/String;","Ljava/lang/reflect/Method;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitJumpStmt(IF_EQZ,4,-1,L8);
                code.visitLabel(L13);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9,3,1},new Method("Lorg/mortbay/util/ajax/JSONPojoConvertor;","addGetter",new String[]{ "Ljava/lang/String;","Ljava/lang/reflect/Method;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L8);
                code.visitLabel(L14);
                code.visitConstStmt(CONST_STRING,4,"get");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/String;","startsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitJumpStmt(IF_EQZ,4,-1,L8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitJumpStmt(IF_LE,4,6,L8);
                code.visitLabel(L15);
                code.visitTypeStmt(NEW_INSTANCE,4,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,6,7},new Method("Ljava/lang/String;","substring",new String[]{ "I","I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/lang/String;","toLowerCase",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,7},new Method("Ljava/lang/String;","substring",new String[]{ "I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitLabel(L16);
                code.visitJumpStmt(GOTO,-1,-1,L12);
                code.visitLabel(L17);
                code.visitConstStmt(CONST_STRING,4,"set");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/String;","startsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitJumpStmt(IF_EQZ,4,-1,L8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitJumpStmt(IF_LE,4,6,L8);
                code.visitLabel(L18);
                code.visitTypeStmt(NEW_INSTANCE,4,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,6,7},new Method("Ljava/lang/String;","substring",new String[]{ "I","I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/lang/String;","toLowerCase",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,7},new Method("Ljava/lang/String;","substring",new String[]{ "I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitLabel(L19);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9,3,1},new Method("Lorg/mortbay/util/ajax/JSONPojoConvertor;","includeField",new String[]{ "Ljava/lang/String;","Ljava/lang/reflect/Method;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitJumpStmt(IF_EQZ,4,-1,L8);
                code.visitLabel(L20);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9,3,1},new Method("Lorg/mortbay/util/ajax/JSONPojoConvertor;","addSetter",new String[]{ "Ljava/lang/String;","Ljava/lang/reflect/Method;"},"V"));
                code.visitJumpStmt(GOTO_16,-1,-1,L8);
                code.visitLabel(L21);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L22);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m015_log(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/util/ajax/JSONPojoConvertor;","log",new String[]{ "Ljava/lang/Throwable;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"t");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(225,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(226,L1);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1},new Method("Lorg/mortbay/log/Log;","ignore",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m016_setProps(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/ajax/JSONPojoConvertor;","setProps",new String[]{ "Ljava/lang/Object;","Ljava/util/Map;"},"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(11);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/lang/Exception;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"obj");
                ddv.visitParameterName(1,"props");
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(175,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(176,L4);
                ddv.visitStartLocal(0,L4,"count","I",null);
                DexLabel L5=new DexLabel();
                ddv.visitStartLocal(3,L5,"iterator","Ljava/util/Iterator;",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(178,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(179,L7);
                ddv.visitStartLocal(2,L7,"entry","Ljava/util/Map$Entry;",null);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(180,L8);
                ddv.visitStartLocal(4,L8,"setter","Lorg/mortbay/util/ajax/JSONPojoConvertor$Setter;",null);
                ddv.visitLineNumber(184,L0);
                ddv.visitLineNumber(185,L1);
                ddv.visitLineNumber(187,L2);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(190,L9);
                ddv.visitStartLocal(1,L9,"e","Ljava/lang/Exception;",null);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(192,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(196,L11);
                ddv.visitEndLocal(2,L11);
                ddv.visitEndLocal(4,L11);
                ddv.visitEndLocal(1,L11);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 10},new Method("Ljava/util/Map;","entrySet",new String[]{ },"Ljava/util/Set;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 5},new Method("Ljava/util/Set;","iterator",new String[]{ },"Ljava/util/Iterator;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3},new Method("Ljava/util/Iterator;","hasNext",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitJumpStmt(IF_EQZ,5,-1,L11);
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3},new Method("Ljava/util/Iterator;","next",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitTypeStmt(CHECK_CAST,2,-1,"Ljava/util/Map$Entry;");
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2},new Method("Ljava/util/Map$Entry;","getKey",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitTypeStmt(CHECK_CAST,5,-1,"Ljava/lang/String;");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,5},new Method("Lorg/mortbay/util/ajax/JSONPojoConvertor;","getSetter",new String[]{ "Ljava/lang/String;"},"Lorg/mortbay/util/ajax/JSONPojoConvertor$Setter;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitLabel(L8);
                code.visitJumpStmt(IF_EQZ,4,-1,L5);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2},new Method("Ljava/util/Map$Entry;","getValue",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,9,5},new Method("Lorg/mortbay/util/ajax/JSONPojoConvertor$Setter;","invoke",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L1);
                code.visitStmt2R1N(ADD_INT_LIT8,0,0,1);
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,5);
                code.visitStmt2R(MOVE_OBJECT,1,5);
                code.visitLabel(L9);
                code.visitConstStmt(CONST_STRING,5,"{} property \'{}\' not set. (errors)");
                code.visitFieldStmt(IGET_OBJECT,6,8,new Field("Lorg/mortbay/util/ajax/JSONPojoConvertor;","_pojoClass","Ljava/lang/Class;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/lang/Class;","getName",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/util/ajax/JSONPojoConvertor$Setter;","getPropertyName",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 5,6,7},new Method("Lorg/mortbay/log/Log;","warn",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,1},new Method("Lorg/mortbay/util/ajax/JSONPojoConvertor;","log",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitLabel(L11);
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m017_toJSON(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/ajax/JSONPojoConvertor;","toJSON",new String[]{ "Ljava/lang/Object;","Lorg/mortbay/util/ajax/JSON$Output;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(9);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/lang/Exception;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"obj");
                ddv.visitParameterName(1,"out");
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(202,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(203,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(204,L5);
                DexLabel L6=new DexLabel();
                ddv.visitStartLocal(2,L6,"iterator","Ljava/util/Iterator;",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(206,L7);
                ddv.visitLineNumber(209,L0);
                ddv.visitStartLocal(1,L0,"entry","Ljava/util/Map$Entry;",null);
                ddv.visitLineNumber(212,L2);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(215,L8);
                ddv.visitStartLocal(0,L8,"e","Ljava/lang/Exception;",null);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(217,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(220,L10);
                ddv.visitEndLocal(1,L10);
                ddv.visitEndLocal(0,L10);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_BOOLEAN,3,6,new Field("Lorg/mortbay/util/ajax/JSONPojoConvertor;","_fromJSON","Z"));
                code.visitJumpStmt(IF_EQZ,3,-1,L5);
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,3,6,new Field("Lorg/mortbay/util/ajax/JSONPojoConvertor;","_pojoClass","Ljava/lang/Class;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 8,3},new Method("Lorg/mortbay/util/ajax/JSON$Output;","addClass",new String[]{ "Ljava/lang/Class;"},"V"));
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,3,6,new Field("Lorg/mortbay/util/ajax/JSONPojoConvertor;","_getters","Ljava/util/Map;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3},new Method("Ljava/util/Map;","entrySet",new String[]{ },"Ljava/util/Set;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3},new Method("Ljava/util/Set;","iterator",new String[]{ },"Ljava/util/Iterator;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2},new Method("Ljava/util/Iterator;","hasNext",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_EQZ,3,-1,L10);
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2},new Method("Ljava/util/Iterator;","next",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitTypeStmt(CHECK_CAST,1,-1,"Ljava/util/Map$Entry;");
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Ljava/util/Map$Entry;","getKey",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitTypeStmt(CHECK_CAST,3,-1,"Ljava/lang/String;");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Ljava/util/Map$Entry;","getValue",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitTypeStmt(CHECK_CAST,4,-1,"Ljava/lang/reflect/Method;");
                code.visitFieldStmt(SGET_OBJECT,5,-1,new Field("Lorg/mortbay/util/ajax/JSONPojoConvertor;","GETTER_ARG","[Ljava/lang/Object;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,7,5},new Method("Ljava/lang/reflect/Method;","invoke",new String[]{ "Ljava/lang/Object;","[Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 8,3,4},new Method("Lorg/mortbay/util/ajax/JSON$Output;","add",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L1);
                code.visitJumpStmt(GOTO,-1,-1,L6);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,3);
                code.visitStmt2R(MOVE_OBJECT,0,3);
                code.visitLabel(L8);
                code.visitConstStmt(CONST_STRING,3,"{} property \'{}\' excluded. (errors)");
                code.visitFieldStmt(IGET_OBJECT,4,6,new Field("Lorg/mortbay/util/ajax/JSONPojoConvertor;","_pojoClass","Ljava/lang/Class;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/lang/Class;","getName",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Ljava/util/Map$Entry;","getKey",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3,4,5},new Method("Lorg/mortbay/log/Log;","warn",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,0},new Method("Lorg/mortbay/util/ajax/JSONPojoConvertor;","log",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L6);
                code.visitLabel(L10);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
