package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0411_org_mortbay_util_LazyList {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/util/LazyList;","Ljava/lang/Object;",new String[]{ "Ljava/lang/Cloneable;","Ljava/io/Serializable;"});
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("LazyList.java");
        f000___EMTPY_STRING_ARRAY(cv);
        m000__clinit_(cv);
        m001__init_(cv);
        m002_add(cv);
        m003_add(cv);
        m004_addArray(cv);
        m005_addCollection(cv);
        m006_addToArray(cv);
        m007_array2List(cv);
        m008_clone(cv);
        m009_contains(cv);
        m010_ensureSize(cv);
        m011_get(cv);
        m012_getList(cv);
        m013_getList(cv);
        m014_iterator(cv);
        m015_listIterator(cv);
        m016_remove(cv);
        m017_remove(cv);
        m018_removeFromArray(cv);
        m019_size(cv);
        m020_toArray(cv);
        m021_toString(cv);
        m022_toStringArray(cv);
    }
    public static void f000___EMTPY_STRING_ARRAY(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/util/LazyList;","__EMTPY_STRING_ARRAY","[Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__clinit_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/util/LazyList;","<clinit>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(55,L0);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitTypeStmt(NEW_ARRAY,0,0,"[Ljava/lang/String;");
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/util/LazyList;","__EMTPY_STRING_ARRAY","[Ljava/lang/String;"));
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PRIVATE|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/util/LazyList;","<init>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(59,L0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/Object;","<init>",new String[]{ },"V"));
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_add(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/util/LazyList;","add",new String[]{ "Ljava/lang/Object;","I","Ljava/lang/Object;"},"Ljava/lang/Object;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"list");
                ddv.visitParameterName(1,"index");
                ddv.visitParameterName(2,"item");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(102,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(104,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(106,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(107,L3);
                ddv.visitStartLocal(1,L3,"l","Ljava/util/List;",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(122,L4);
                ddv.visitEndLocal(1,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(110,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(113,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(115,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(116,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(119,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(120,L10);
                ddv.visitRestartLocal(1,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(121,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(122,L12);
                code.visitLabel(L0);
                code.visitJumpStmt(IF_NEZ,3,-1,L6);
                code.visitLabel(L1);
                code.visitJumpStmt(IF_GTZ,4,-1,L2);
                code.visitTypeStmt(INSTANCE_OF,2,5,"Ljava/util/List;");
                code.visitJumpStmt(IF_NEZ,2,-1,L2);
                DexLabel L13=new DexLabel();
                code.visitJumpStmt(IF_NEZ,5,-1,L13);
                code.visitLabel(L2);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/util/ArrayList;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljava/util/ArrayList;","<init>",new String[]{ },"V"));
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1,4,5},new Method("Ljava/util/List;","add",new String[]{ "I","Ljava/lang/Object;"},"V"));
                code.visitStmt2R(MOVE_OBJECT,2,1);
                code.visitLabel(L4);
                code.visitStmt1R(RETURN_OBJECT,2);
                code.visitLabel(L13);
                code.visitStmt2R(MOVE_OBJECT,2,5);
                code.visitLabel(L5);
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitLabel(L6);
                code.visitTypeStmt(INSTANCE_OF,2,3,"Ljava/util/List;");
                code.visitJumpStmt(IF_EQZ,2,-1,L9);
                code.visitLabel(L7);
                code.visitStmt2R(MOVE_OBJECT,0,3);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Ljava/util/List;");
                code.visitStmt2R(MOVE_OBJECT,2,0);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2,4,5},new Method("Ljava/util/List;","add",new String[]{ "I","Ljava/lang/Object;"},"V"));
                code.visitStmt2R(MOVE_OBJECT,2,3);
                code.visitLabel(L8);
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitLabel(L9);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/util/ArrayList;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljava/util/ArrayList;","<init>",new String[]{ },"V"));
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1,3},new Method("Ljava/util/List;","add",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitLabel(L11);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1,4,5},new Method("Ljava/util/List;","add",new String[]{ "I","Ljava/lang/Object;"},"V"));
                code.visitStmt2R(MOVE_OBJECT,2,1);
                code.visitLabel(L12);
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_add(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/util/LazyList;","add",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"list");
                ddv.visitParameterName(1,"item");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(69,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(71,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(73,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(74,L3);
                ddv.visitStartLocal(1,L3,"l","Ljava/util/List;",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(90,L4);
                ddv.visitEndLocal(1,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(78,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(81,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(83,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(84,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(87,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(88,L10);
                ddv.visitRestartLocal(1,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(89,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(90,L12);
                code.visitLabel(L0);
                code.visitJumpStmt(IF_NEZ,3,-1,L6);
                code.visitLabel(L1);
                code.visitTypeStmt(INSTANCE_OF,2,4,"Ljava/util/List;");
                code.visitJumpStmt(IF_NEZ,2,-1,L2);
                DexLabel L13=new DexLabel();
                code.visitJumpStmt(IF_NEZ,4,-1,L13);
                code.visitLabel(L2);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/util/ArrayList;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljava/util/ArrayList;","<init>",new String[]{ },"V"));
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1,4},new Method("Ljava/util/List;","add",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt2R(MOVE_OBJECT,2,1);
                code.visitLabel(L4);
                code.visitStmt1R(RETURN_OBJECT,2);
                code.visitLabel(L13);
                code.visitStmt2R(MOVE_OBJECT,2,4);
                code.visitLabel(L5);
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitLabel(L6);
                code.visitTypeStmt(INSTANCE_OF,2,3,"Ljava/util/List;");
                code.visitJumpStmt(IF_EQZ,2,-1,L9);
                code.visitLabel(L7);
                code.visitStmt2R(MOVE_OBJECT,0,3);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Ljava/util/List;");
                code.visitStmt2R(MOVE_OBJECT,2,0);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2,4},new Method("Ljava/util/List;","add",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt2R(MOVE_OBJECT,2,3);
                code.visitLabel(L8);
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitLabel(L9);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/util/ArrayList;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljava/util/ArrayList;","<init>",new String[]{ },"V"));
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1,3},new Method("Ljava/util/List;","add",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitLabel(L11);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1,4},new Method("Ljava/util/List;","add",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt2R(MOVE_OBJECT,2,1);
                code.visitLabel(L12);
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_addArray(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/util/LazyList;","addArray",new String[]{ "Ljava/lang/Object;","[Ljava/lang/Object;"},"Ljava/lang/Object;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"list");
                ddv.visitParameterName(1,"array");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(147,L0);
                DexLabel L1=new DexLabel();
                ddv.visitStartLocal(0,L1,"i","I",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(148,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(147,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(149,L4);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitJumpStmt(IF_EQZ,3,-1,L4);
                code.visitStmt2R(ARRAY_LENGTH,1,3);
                code.visitJumpStmt(IF_GE,0,1,L4);
                code.visitLabel(L2);
                code.visitStmt3R(AGET_OBJECT,1,3,0);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2,1},new Method("Lorg/mortbay/util/LazyList;","add",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L3);
                code.visitStmt2R1N(ADD_INT_LIT8,0,0,1);
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitLabel(L4);
                code.visitStmt1R(RETURN_OBJECT,2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_addCollection(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/util/LazyList;","addCollection",new String[]{ "Ljava/lang/Object;","Ljava/util/Collection;"},"Ljava/lang/Object;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"list");
                ddv.visitParameterName(1,"collection");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(133,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(134,L1);
                ddv.visitStartLocal(0,L1,"i","Ljava/util/Iterator;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(135,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(136,L3);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3},new Method("Ljava/util/Collection;","iterator",new String[]{ },"Ljava/util/Iterator;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Ljava/util/Iterator;","hasNext",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_EQZ,1,-1,L3);
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Ljava/util/Iterator;","next",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2,1},new Method("Lorg/mortbay/util/LazyList;","add",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitLabel(L3);
                code.visitStmt1R(RETURN_OBJECT,2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_addToArray(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/util/LazyList;","addToArray",new String[]{ "[Ljava/lang/Object;","Ljava/lang/Object;","Ljava/lang/Class;"},"[Ljava/lang/Object;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(8);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"array");
                ddv.visitParameterName(1,"item");
                ddv.visitParameterName(2,"type");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(406,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(408,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(409,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(410,L4);
                DexLabel L5=new DexLabel();
                ddv.visitEndLocal(5,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(411,L6);
                ddv.visitStartLocal(2,L6,"na","[Ljava/lang/Object;",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(420,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(416,L8);
                ddv.visitEndLocal(2,L8);
                ddv.visitRestartLocal(5,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(417,L9);
                ddv.visitStartLocal(1,L9,"c","Ljava/lang/Class;",null);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(418,L10);
                ddv.visitRestartLocal(2,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(419,L11);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitJumpStmt(IF_NEZ,5,-1,L8);
                code.visitLabel(L2);
                code.visitJumpStmt(IF_NEZ,7,-1,L4);
                code.visitJumpStmt(IF_EQZ,6,-1,L4);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/lang/Object;","getClass",new String[]{ },"Ljava/lang/Class;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitLabel(L4);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 7,3},new Method("Ljava/lang/reflect/Array;","newInstance",new String[]{ "Ljava/lang/Class;","I"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitLabel(L5);
                code.visitTypeStmt(CHECK_CAST,5,-1,"[Ljava/lang/Object;");
                code.visitStmt2R(MOVE_OBJECT,0,5);
                code.visitTypeStmt(CHECK_CAST,0,-1,"[Ljava/lang/Object;");
                code.visitStmt2R(MOVE_OBJECT,2,0);
                code.visitLabel(L6);
                code.visitStmt3R(APUT_OBJECT,6,2,4);
                code.visitLabel(L7);
                code.visitStmt1R(RETURN_OBJECT,2);
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/lang/Object;","getClass",new String[]{ },"Ljava/lang/Class;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/lang/Class;","getComponentType",new String[]{ },"Ljava/lang/Class;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 5},new Method("Ljava/lang/reflect/Array;","getLength",new String[]{ "Ljava/lang/Object;"},"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitStmt2R1N(ADD_INT_LIT8,3,3,1);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1,3},new Method("Ljava/lang/reflect/Array;","newInstance",new String[]{ "Ljava/lang/Class;","I"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitTypeStmt(CHECK_CAST,3,-1,"[Ljava/lang/Object;");
                code.visitStmt2R(MOVE_OBJECT,0,3);
                code.visitTypeStmt(CHECK_CAST,0,-1,"[Ljava/lang/Object;");
                code.visitStmt2R(MOVE_OBJECT,2,0);
                code.visitLabel(L10);
                code.visitStmt2R(ARRAY_LENGTH,3,5);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 5,4,2,4,3},new Method("Ljava/lang/System;","arraycopy",new String[]{ "Ljava/lang/Object;","I","Ljava/lang/Object;","I","I"},"V"));
                code.visitLabel(L11);
                code.visitStmt2R(ARRAY_LENGTH,3,5);
                code.visitStmt3R(APUT_OBJECT,6,2,3);
                code.visitJumpStmt(GOTO,-1,-1,L7);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m007_array2List(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/util/LazyList;","array2List",new String[]{ "[Ljava/lang/Object;"},"Ljava/util/List;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"array");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(392,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(393,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(394,L2);
                code.visitLabel(L0);
                code.visitJumpStmt(IF_EQZ,2,-1,L1);
                code.visitStmt2R(ARRAY_LENGTH,0,2);
                DexLabel L3=new DexLabel();
                code.visitJumpStmt(IF_NEZ,0,-1,L3);
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/util/ArrayList;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/util/ArrayList;","<init>",new String[]{ },"V"));
                code.visitLabel(L2);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L3);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/util/ArrayList;");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2},new Method("Ljava/util/Arrays;","asList",new String[]{ "[Ljava/lang/Object;"},"Ljava/util/List;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Ljava/util/ArrayList;","<init>",new String[]{ "Ljava/util/Collection;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m008_clone(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/util/LazyList;","clone",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/Object;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"list");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(348,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(349,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(352,L2);
                ddv.visitEndLocal(1,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(350,L3);
                ddv.visitRestartLocal(1,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(351,L4);
                DexLabel L5=new DexLabel();
                ddv.visitEndLocal(1,L5);
                DexLabel L6=new DexLabel();
                ddv.visitRestartLocal(1,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(352,L7);
                code.visitLabel(L0);
                code.visitJumpStmt(IF_NEZ,1,-1,L3);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L2);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L3);
                code.visitTypeStmt(INSTANCE_OF,0,1,"Ljava/util/List;");
                code.visitJumpStmt(IF_EQZ,0,-1,L6);
                code.visitLabel(L4);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/util/ArrayList;");
                code.visitTypeStmt(CHECK_CAST,1,-1,"Ljava/util/List;");
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Ljava/util/ArrayList;","<init>",new String[]{ "Ljava/util/Collection;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L6);
                code.visitStmt2R(MOVE_OBJECT,0,1);
                code.visitLabel(L7);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m009_contains(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/util/LazyList;","contains",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"list");
                ddv.visitParameterName(1,"item");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(335,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(336,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(341,L2);
                ddv.visitEndLocal(1,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(338,L3);
                ddv.visitRestartLocal(1,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(339,L4);
                DexLabel L5=new DexLabel();
                ddv.visitEndLocal(1,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(341,L6);
                ddv.visitRestartLocal(1,L6);
                code.visitLabel(L0);
                code.visitJumpStmt(IF_NEZ,1,-1,L3);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L2);
                code.visitStmt1R(RETURN,0);
                code.visitLabel(L3);
                code.visitTypeStmt(INSTANCE_OF,0,1,"Ljava/util/List;");
                code.visitJumpStmt(IF_EQZ,0,-1,L6);
                code.visitLabel(L4);
                code.visitTypeStmt(CHECK_CAST,1,-1,"Ljava/util/List;");
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1,2},new Method("Ljava/util/List;","contains",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/lang/Object;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m010_ensureSize(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/util/LazyList;","ensureSize",new String[]{ "Ljava/lang/Object;","I"},"Ljava/lang/Object;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"list");
                ddv.visitParameterName(1,"initialSize");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(158,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(159,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(171,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(160,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(162,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(163,L5);
                ddv.visitStartLocal(3,L5,"ol","Ljava/util/ArrayList;",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(164,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(165,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(166,L8);
                ddv.visitStartLocal(2,L8,"nl","Ljava/util/ArrayList;",null);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(167,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(169,L10);
                ddv.visitEndLocal(3,L10);
                ddv.visitEndLocal(2,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(170,L11);
                ddv.visitStartLocal(1,L11,"l","Ljava/util/List;",null);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(171,L12);
                code.visitLabel(L0);
                code.visitJumpStmt(IF_NEZ,5,-1,L3);
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,4,-1,"Ljava/util/ArrayList;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4,6},new Method("Ljava/util/ArrayList;","<init>",new String[]{ "I"},"V"));
                code.visitLabel(L2);
                code.visitStmt1R(RETURN_OBJECT,4);
                code.visitLabel(L3);
                code.visitTypeStmt(INSTANCE_OF,4,5,"Ljava/util/ArrayList;");
                code.visitJumpStmt(IF_EQZ,4,-1,L10);
                code.visitLabel(L4);
                code.visitStmt2R(MOVE_OBJECT,0,5);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Ljava/util/ArrayList;");
                code.visitStmt2R(MOVE_OBJECT,3,0);
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/util/ArrayList;","size",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitJumpStmt(IF_LE,4,6,L7);
                code.visitStmt2R(MOVE_OBJECT,4,3);
                code.visitLabel(L6);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L7);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Ljava/util/ArrayList;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2,6},new Method("Ljava/util/ArrayList;","<init>",new String[]{ "I"},"V"));
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/util/ArrayList;","addAll",new String[]{ "Ljava/util/Collection;"},"Z"));
                code.visitStmt2R(MOVE_OBJECT,4,2);
                code.visitLabel(L9);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L10);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/util/ArrayList;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,6},new Method("Ljava/util/ArrayList;","<init>",new String[]{ "I"},"V"));
                code.visitLabel(L11);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1,5},new Method("Ljava/util/List;","add",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt2R(MOVE_OBJECT,4,1);
                code.visitLabel(L12);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m011_get(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/util/LazyList;","get",new String[]{ "Ljava/lang/Object;","I"},"Ljava/lang/Object;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"list");
                ddv.visitParameterName(1,"i");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(320,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(321,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(323,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(324,L3);
                DexLabel L4=new DexLabel();
                ddv.visitEndLocal(1,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(327,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(326,L6);
                ddv.visitRestartLocal(1,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(327,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(329,L8);
                code.visitLabel(L0);
                code.visitJumpStmt(IF_NEZ,1,-1,L2);
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/IndexOutOfBoundsException;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/IndexOutOfBoundsException;","<init>",new String[]{ },"V"));
                code.visitStmt1R(THROW,0);
                code.visitLabel(L2);
                code.visitTypeStmt(INSTANCE_OF,0,1,"Ljava/util/List;");
                code.visitJumpStmt(IF_EQZ,0,-1,L6);
                code.visitLabel(L3);
                code.visitTypeStmt(CHECK_CAST,1,-1,"Ljava/util/List;");
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1,2},new Method("Ljava/util/List;","get",new String[]{ "I"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L5);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L6);
                code.visitJumpStmt(IF_NEZ,2,-1,L8);
                code.visitStmt2R(MOVE_OBJECT,0,1);
                code.visitLabel(L7);
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitLabel(L8);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/IndexOutOfBoundsException;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/IndexOutOfBoundsException;","<init>",new String[]{ },"V"));
                code.visitStmt1R(THROW,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m012_getList(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/util/LazyList;","getList",new String[]{ "Ljava/lang/Object;"},"Ljava/util/List;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"list");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(225,L0);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1,0},new Method("Lorg/mortbay/util/LazyList;","getList",new String[]{ "Ljava/lang/Object;","Z"},"Ljava/util/List;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m013_getList(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/util/LazyList;","getList",new String[]{ "Ljava/lang/Object;","Z"},"Ljava/util/List;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"list");
                ddv.visitParameterName(1,"nullForEmpty");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(240,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(241,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(247,L2);
                ddv.visitEndLocal(2,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(241,L3);
                ddv.visitRestartLocal(2,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(242,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(243,L5);
                DexLabel L6=new DexLabel();
                ddv.visitEndLocal(2,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(245,L7);
                ddv.visitRestartLocal(2,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(246,L8);
                ddv.visitStartLocal(0,L8,"l","Ljava/util/List;",null);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(247,L9);
                code.visitLabel(L0);
                code.visitJumpStmt(IF_NEZ,2,-1,L4);
                code.visitLabel(L1);
                code.visitJumpStmt(IF_EQZ,3,-1,L3);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L2);
                code.visitStmt1R(RETURN_OBJECT,1);
                code.visitLabel(L3);
                code.visitFieldStmt(SGET_OBJECT,1,-1,new Field("Ljava/util/Collections;","EMPTY_LIST","Ljava/util/List;"));
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L4);
                code.visitTypeStmt(INSTANCE_OF,1,2,"Ljava/util/List;");
                code.visitJumpStmt(IF_EQZ,1,-1,L7);
                code.visitLabel(L5);
                code.visitTypeStmt(CHECK_CAST,2,-1,"Ljava/util/List;");
                code.visitLabel(L6);
                code.visitStmt2R(MOVE_OBJECT,1,2);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L7);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/util/ArrayList;");
                code.visitConstStmt(CONST_4,1, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Ljava/util/ArrayList;","<init>",new String[]{ "I"},"V"));
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,2},new Method("Ljava/util/List;","add",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt2R(MOVE_OBJECT,1,0);
                code.visitLabel(L9);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m014_iterator(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/util/LazyList;","iterator",new String[]{ "Ljava/lang/Object;"},"Ljava/util/Iterator;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"list");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(368,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(369,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(372,L2);
                ddv.visitEndLocal(1,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(370,L3);
                ddv.visitRestartLocal(1,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(371,L4);
                DexLabel L5=new DexLabel();
                ddv.visitEndLocal(1,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(372,L6);
                ddv.visitRestartLocal(1,L6);
                code.visitLabel(L0);
                code.visitJumpStmt(IF_NEZ,1,-1,L3);
                code.visitLabel(L1);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Ljava/util/Collections;","EMPTY_LIST","Ljava/util/List;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Ljava/util/List;","iterator",new String[]{ },"Ljava/util/Iterator;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L2);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L3);
                code.visitTypeStmt(INSTANCE_OF,0,1,"Ljava/util/List;");
                code.visitJumpStmt(IF_EQZ,0,-1,L6);
                code.visitLabel(L4);
                code.visitTypeStmt(CHECK_CAST,1,-1,"Ljava/util/List;");
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Ljava/util/List;","iterator",new String[]{ },"Ljava/util/Iterator;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1},new Method("Lorg/mortbay/util/LazyList;","getList",new String[]{ "Ljava/lang/Object;"},"Ljava/util/List;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Ljava/util/List;","iterator",new String[]{ },"Ljava/util/Iterator;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m015_listIterator(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/util/LazyList;","listIterator",new String[]{ "Ljava/lang/Object;"},"Ljava/util/ListIterator;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"list");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(378,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(379,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(382,L2);
                ddv.visitEndLocal(1,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(380,L3);
                ddv.visitRestartLocal(1,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(381,L4);
                DexLabel L5=new DexLabel();
                ddv.visitEndLocal(1,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(382,L6);
                ddv.visitRestartLocal(1,L6);
                code.visitLabel(L0);
                code.visitJumpStmt(IF_NEZ,1,-1,L3);
                code.visitLabel(L1);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Ljava/util/Collections;","EMPTY_LIST","Ljava/util/List;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Ljava/util/List;","listIterator",new String[]{ },"Ljava/util/ListIterator;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L2);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L3);
                code.visitTypeStmt(INSTANCE_OF,0,1,"Ljava/util/List;");
                code.visitJumpStmt(IF_EQZ,0,-1,L6);
                code.visitLabel(L4);
                code.visitTypeStmt(CHECK_CAST,1,-1,"Ljava/util/List;");
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Ljava/util/List;","listIterator",new String[]{ },"Ljava/util/ListIterator;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1},new Method("Lorg/mortbay/util/LazyList;","getList",new String[]{ "Ljava/lang/Object;"},"Ljava/util/List;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Ljava/util/List;","listIterator",new String[]{ },"Ljava/util/ListIterator;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m016_remove(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/util/LazyList;","remove",new String[]{ "Ljava/lang/Object;","I"},"Ljava/lang/Object;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"list");
                ddv.visitParameterName(1,"i");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(197,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(211,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(200,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(202,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(203,L5);
                ddv.visitStartLocal(1,L5,"l","Ljava/util/List;",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(204,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(205,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(206,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(209,L9);
                ddv.visitEndLocal(1,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(210,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(211,L11);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitJumpStmt(IF_NEZ,4,-1,L3);
                code.visitStmt2R(MOVE_OBJECT,2,3);
                code.visitLabel(L2);
                code.visitStmt1R(RETURN_OBJECT,2);
                code.visitLabel(L3);
                code.visitTypeStmt(INSTANCE_OF,2,4,"Ljava/util/List;");
                code.visitJumpStmt(IF_EQZ,2,-1,L9);
                code.visitLabel(L4);
                code.visitStmt2R(MOVE_OBJECT,0,4);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Ljava/util/List;");
                code.visitStmt2R(MOVE_OBJECT,1,0);
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1,5},new Method("Ljava/util/List;","remove",new String[]{ "I"},"Ljava/lang/Object;"));
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Ljava/util/List;","size",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                DexLabel L12=new DexLabel();
                code.visitJumpStmt(IF_NEZ,2,-1,L12);
                code.visitStmt2R(MOVE_OBJECT,2,3);
                code.visitLabel(L7);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L12);
                code.visitStmt2R(MOVE_OBJECT,2,4);
                code.visitLabel(L8);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L9);
                DexLabel L13=new DexLabel();
                code.visitJumpStmt(IF_NEZ,5,-1,L13);
                code.visitStmt2R(MOVE_OBJECT,2,3);
                code.visitLabel(L10);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L13);
                code.visitStmt2R(MOVE_OBJECT,2,4);
                code.visitLabel(L11);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m017_remove(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/util/LazyList;","remove",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"list");
                ddv.visitParameterName(1,"o");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(177,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(191,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(180,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(182,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(183,L5);
                ddv.visitStartLocal(1,L5,"l","Ljava/util/List;",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(184,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(185,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(186,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(189,L9);
                ddv.visitEndLocal(1,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(190,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(191,L11);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitJumpStmt(IF_NEZ,4,-1,L3);
                code.visitStmt2R(MOVE_OBJECT,2,3);
                code.visitLabel(L2);
                code.visitStmt1R(RETURN_OBJECT,2);
                code.visitLabel(L3);
                code.visitTypeStmt(INSTANCE_OF,2,4,"Ljava/util/List;");
                code.visitJumpStmt(IF_EQZ,2,-1,L9);
                code.visitLabel(L4);
                code.visitStmt2R(MOVE_OBJECT,0,4);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Ljava/util/List;");
                code.visitStmt2R(MOVE_OBJECT,1,0);
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1,5},new Method("Ljava/util/List;","remove",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Ljava/util/List;","size",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                DexLabel L12=new DexLabel();
                code.visitJumpStmt(IF_NEZ,2,-1,L12);
                code.visitStmt2R(MOVE_OBJECT,2,3);
                code.visitLabel(L7);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L12);
                code.visitStmt2R(MOVE_OBJECT,2,4);
                code.visitLabel(L8);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Ljava/lang/Object;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                DexLabel L13=new DexLabel();
                code.visitJumpStmt(IF_EQZ,2,-1,L13);
                code.visitStmt2R(MOVE_OBJECT,2,3);
                code.visitLabel(L10);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L13);
                code.visitStmt2R(MOVE_OBJECT,2,4);
                code.visitLabel(L11);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m018_removeFromArray(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/util/LazyList;","removeFromArray",new String[]{ "[Ljava/lang/Object;","Ljava/lang/Object;"},"[Ljava/lang/Object;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(10);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"array");
                ddv.visitParameterName(1,"item");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(427,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(442,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(429,L3);
                DexLabel L4=new DexLabel();
                ddv.visitStartLocal(2,L4,"i","I",null);
                DexLabel L5=new DexLabel();
                ddv.visitEndLocal(2,L5);
                ddv.visitStartLocal(3,L5,"i","I",null);
                DexLabel L6=new DexLabel();
                ddv.visitRestartLocal(2,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(431,L7);
                ddv.visitEndLocal(3,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(433,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(434,L9);
                ddv.visitStartLocal(1,L9,"c","Ljava/lang/Class;",null);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(435,L10);
                ddv.visitStartLocal(4,L10,"na","[Ljava/lang/Object;",null);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(436,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(437,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(438,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(439,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(433,L15);
                ddv.visitEndLocal(1,L15);
                ddv.visitEndLocal(4,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(442,L16);
                DexLabel L17=new DexLabel();
                ddv.visitRestartLocal(3,L17);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,7, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitConstStmt(CONST_4,6, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                DexLabel L18=new DexLabel();
                code.visitJumpStmt(IF_EQZ,9,-1,L18);
                code.visitJumpStmt(IF_NEZ,8,-1,L3);
                code.visitLabel(L18);
                code.visitStmt2R(MOVE_OBJECT,5,8);
                code.visitLabel(L2);
                code.visitStmt1R(RETURN_OBJECT,5);
                code.visitLabel(L3);
                code.visitStmt2R(ARRAY_LENGTH,2,8);
                code.visitLabel(L4);
                code.visitStmt2R(MOVE,3,2);
                code.visitLabel(L5);
                code.visitStmt3R(SUB_INT,2,3,7);
                code.visitLabel(L6);
                DexLabel L19=new DexLabel();
                code.visitJumpStmt(IF_LEZ,3,-1,L19);
                code.visitLabel(L7);
                code.visitStmt3R(AGET_OBJECT,5,8,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9,5},new Method("Ljava/lang/Object;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,5);
                DexLabel L20=new DexLabel();
                code.visitJumpStmt(IF_EQZ,5,-1,L20);
                code.visitLabel(L8);
                code.visitJumpStmt(IF_NEZ,8,-1,L15);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9},new Method("Ljava/lang/Object;","getClass",new String[]{ },"Ljava/lang/Class;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitStmt2R(MOVE_OBJECT,1,5);
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 8},new Method("Ljava/lang/reflect/Array;","getLength",new String[]{ "Ljava/lang/Object;"},"I"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitStmt2R(SUB_INT_2ADDR,5,7);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1,5},new Method("Ljava/lang/reflect/Array;","newInstance",new String[]{ "Ljava/lang/Class;","I"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitTypeStmt(CHECK_CAST,5,-1,"[Ljava/lang/Object;");
                code.visitStmt2R(MOVE_OBJECT,0,5);
                code.visitTypeStmt(CHECK_CAST,0,-1,"[Ljava/lang/Object;");
                code.visitStmt2R(MOVE_OBJECT,4,0);
                code.visitLabel(L10);
                code.visitJumpStmt(IF_LEZ,2,-1,L12);
                code.visitLabel(L11);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 8,6,4,6,2},new Method("Ljava/lang/System;","arraycopy",new String[]{ "Ljava/lang/Object;","I","Ljava/lang/Object;","I","I"},"V"));
                code.visitLabel(L12);
                code.visitStmt2R1N(ADD_INT_LIT8,5,2,1);
                code.visitStmt2R(ARRAY_LENGTH,6,8);
                DexLabel L21=new DexLabel();
                code.visitJumpStmt(IF_GE,5,6,L21);
                code.visitLabel(L13);
                code.visitStmt2R1N(ADD_INT_LIT8,5,2,1);
                code.visitStmt2R(ARRAY_LENGTH,6,8);
                code.visitStmt2R1N(ADD_INT_LIT8,7,2,1);
                code.visitStmt2R(SUB_INT_2ADDR,6,7);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 8,5,4,2,6},new Method("Ljava/lang/System;","arraycopy",new String[]{ "Ljava/lang/Object;","I","Ljava/lang/Object;","I","I"},"V"));
                code.visitLabel(L21);
                code.visitStmt2R(MOVE_OBJECT,5,4);
                code.visitLabel(L14);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L15);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Ljava/lang/Object;","getClass",new String[]{ },"Ljava/lang/Class;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/lang/Class;","getComponentType",new String[]{ },"Ljava/lang/Class;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitStmt2R(MOVE_OBJECT,1,5);
                code.visitJumpStmt(GOTO,-1,-1,L9);
                code.visitLabel(L19);
                code.visitStmt2R(MOVE_OBJECT,5,8);
                code.visitLabel(L16);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L20);
                code.visitStmt2R(MOVE,3,2);
                code.visitLabel(L17);
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m019_size(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/util/LazyList;","size",new String[]{ "Ljava/lang/Object;"},"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"list");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(305,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(306,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(309,L2);
                ddv.visitEndLocal(1,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(307,L3);
                ddv.visitRestartLocal(1,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(308,L4);
                DexLabel L5=new DexLabel();
                ddv.visitEndLocal(1,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(309,L6);
                ddv.visitRestartLocal(1,L6);
                code.visitLabel(L0);
                code.visitJumpStmt(IF_NEZ,1,-1,L3);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L2);
                code.visitStmt1R(RETURN,0);
                code.visitLabel(L3);
                code.visitTypeStmt(INSTANCE_OF,0,1,"Ljava/util/List;");
                code.visitJumpStmt(IF_EQZ,0,-1,L6);
                code.visitLabel(L4);
                code.visitTypeStmt(CHECK_CAST,1,-1,"Ljava/util/List;");
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Ljava/util/List;","size",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L6);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m020_toArray(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/util/LazyList;","toArray",new String[]{ "Ljava/lang/Object;","Ljava/lang/Class;"},"Ljava/lang/Object;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(8);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"list");
                ddv.visitParameterName(1,"aClass");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(276,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(277,L2);
                DexLabel L3=new DexLabel();
                ddv.visitEndLocal(6,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(295,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(279,L5);
                ddv.visitRestartLocal(6,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(281,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(282,L7);
                ddv.visitStartLocal(3,L7,"l","Ljava/util/List;",null);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(284,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(285,L9);
                ddv.visitStartLocal(1,L9,"a","Ljava/lang/Object;",null);
                DexLabel L10=new DexLabel();
                ddv.visitStartLocal(2,L10,"i","I",null);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(286,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(285,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(287,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(289,L14);
                ddv.visitEndLocal(1,L14);
                ddv.visitEndLocal(2,L14);
                DexLabel L15=new DexLabel();
                ddv.visitEndLocal(6,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(293,L16);
                ddv.visitEndLocal(3,L16);
                ddv.visitRestartLocal(6,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(294,L17);
                ddv.visitRestartLocal(1,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(295,L18);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,5, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitJumpStmt(IF_NEZ,6,-1,L5);
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 7,5},new Method("Ljava/lang/reflect/Array;","newInstance",new String[]{ "Ljava/lang/Class;","I"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitLabel(L3);
                code.visitTypeStmt(CHECK_CAST,6,-1,"[Ljava/lang/Object;");
                code.visitTypeStmt(CHECK_CAST,6,-1,"[Ljava/lang/Object;");
                code.visitStmt2R(MOVE_OBJECT,4,6);
                code.visitLabel(L4);
                code.visitStmt1R(RETURN_OBJECT,4);
                code.visitLabel(L5);
                code.visitTypeStmt(INSTANCE_OF,4,6,"Ljava/util/List;");
                code.visitJumpStmt(IF_EQZ,4,-1,L16);
                code.visitLabel(L6);
                code.visitStmt2R(MOVE_OBJECT,0,6);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Ljava/util/List;");
                code.visitStmt2R(MOVE_OBJECT,3,0);
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Ljava/lang/Class;","isPrimitive",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitJumpStmt(IF_EQZ,4,-1,L14);
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3},new Method("Ljava/util/List;","size",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 7,4},new Method("Ljava/lang/reflect/Array;","newInstance",new String[]{ "Ljava/lang/Class;","I"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L9);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3},new Method("Ljava/util/List;","size",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,4);
                DexLabel L19=new DexLabel();
                code.visitJumpStmt(IF_GE,2,4,L19);
                code.visitLabel(L11);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3,2},new Method("Ljava/util/List;","get",new String[]{ "I"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1,2,4},new Method("Ljava/lang/reflect/Array;","set",new String[]{ "Ljava/lang/Object;","I","Ljava/lang/Object;"},"V"));
                code.visitLabel(L12);
                code.visitStmt2R1N(ADD_INT_LIT8,2,2,1);
                code.visitJumpStmt(GOTO,-1,-1,L10);
                code.visitLabel(L19);
                code.visitStmt2R(MOVE_OBJECT,4,1);
                code.visitLabel(L13);
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitLabel(L14);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3},new Method("Ljava/util/List;","size",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 7,4},new Method("Ljava/lang/reflect/Array;","newInstance",new String[]{ "Ljava/lang/Class;","I"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitLabel(L15);
                code.visitTypeStmt(CHECK_CAST,6,-1,"[Ljava/lang/Object;");
                code.visitTypeStmt(CHECK_CAST,6,-1,"[Ljava/lang/Object;");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3,6},new Method("Ljava/util/List;","toArray",new String[]{ "[Ljava/lang/Object;"},"[Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitLabel(L16);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 7,4},new Method("Ljava/lang/reflect/Array;","newInstance",new String[]{ "Ljava/lang/Class;","I"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L17);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1,5,6},new Method("Ljava/lang/reflect/Array;","set",new String[]{ "Ljava/lang/Object;","I","Ljava/lang/Object;"},"V"));
                code.visitStmt2R(MOVE_OBJECT,4,1);
                code.visitLabel(L18);
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m021_toString(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/util/LazyList;","toString",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"list");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(358,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(359,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(362,L2);
                ddv.visitEndLocal(2,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(360,L3);
                ddv.visitRestartLocal(2,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(361,L4);
                DexLabel L5=new DexLabel();
                ddv.visitEndLocal(2,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(362,L6);
                ddv.visitRestartLocal(2,L6);
                code.visitLabel(L0);
                code.visitJumpStmt(IF_NEZ,2,-1,L3);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_STRING,0,"[]");
                code.visitLabel(L2);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L3);
                code.visitTypeStmt(INSTANCE_OF,0,2,"Ljava/util/List;");
                code.visitJumpStmt(IF_EQZ,0,-1,L6);
                code.visitLabel(L4);
                code.visitTypeStmt(CHECK_CAST,2,-1,"Ljava/util/List;");
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/lang/Object;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L6);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,1,"[");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitConstStmt(CONST_STRING,1,"]");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m022_toStringArray(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/util/LazyList;","toStringArray",new String[]{ "Ljava/lang/Object;"},"[Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(10);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"list");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(254,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(255,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(270,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(257,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(259,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(260,L6);
                ddv.visitStartLocal(4,L6,"l","Ljava/util/List;",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(261,L7);
                ddv.visitStartLocal(1,L7,"a","[Ljava/lang/String;",null);
                DexLabel L8=new DexLabel();
                ddv.visitStartLocal(2,L8,"i","I",null);
                DexLabel L9=new DexLabel();
                ddv.visitEndLocal(2,L9);
                ddv.visitStartLocal(3,L9,"i","I",null);
                DexLabel L10=new DexLabel();
                ddv.visitRestartLocal(2,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(263,L11);
                ddv.visitEndLocal(3,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(264,L12);
                ddv.visitStartLocal(5,L12,"o","Ljava/lang/Object;",null);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(265,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(266,L14);
                ddv.visitRestartLocal(3,L14);
                DexLabel L15=new DexLabel();
                ddv.visitEndLocal(5,L15);
                ddv.visitEndLocal(3,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(267,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(270,L17);
                ddv.visitEndLocal(4,L17);
                ddv.visitEndLocal(1,L17);
                ddv.visitEndLocal(2,L17);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,7, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L1);
                code.visitJumpStmt(IF_NEZ,9,-1,L4);
                code.visitLabel(L2);
                code.visitFieldStmt(SGET_OBJECT,6,-1,new Field("Lorg/mortbay/util/LazyList;","__EMTPY_STRING_ARRAY","[Ljava/lang/String;"));
                code.visitLabel(L3);
                code.visitStmt1R(RETURN_OBJECT,6);
                code.visitLabel(L4);
                code.visitTypeStmt(INSTANCE_OF,6,9,"Ljava/util/List;");
                code.visitJumpStmt(IF_EQZ,6,-1,L17);
                code.visitLabel(L5);
                code.visitStmt2R(MOVE_OBJECT,0,9);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Ljava/util/List;");
                code.visitStmt2R(MOVE_OBJECT,4,0);
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 4},new Method("Ljava/util/List;","size",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitTypeStmt(NEW_ARRAY,1,6,"[Ljava/lang/String;");
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 4},new Method("Ljava/util/List;","size",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitLabel(L8);
                code.visitStmt2R(MOVE,3,2);
                code.visitLabel(L9);
                code.visitStmt3R(SUB_INT,2,3,7);
                code.visitLabel(L10);
                code.visitJumpStmt(IF_LEZ,3,-1,L15);
                code.visitLabel(L11);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 4,2},new Method("Ljava/util/List;","get",new String[]{ "I"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitLabel(L12);
                DexLabel L18=new DexLabel();
                code.visitJumpStmt(IF_EQZ,5,-1,L18);
                code.visitLabel(L13);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/lang/Object;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitStmt3R(APUT_OBJECT,6,1,2);
                code.visitLabel(L18);
                code.visitStmt2R(MOVE,3,2);
                code.visitLabel(L14);
                code.visitJumpStmt(GOTO,-1,-1,L9);
                code.visitLabel(L15);
                code.visitStmt2R(MOVE_OBJECT,6,1);
                code.visitLabel(L16);
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitLabel(L17);
                code.visitTypeStmt(NEW_ARRAY,6,7,"[Ljava/lang/String;");
                code.visitConstStmt(CONST_4,7, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9},new Method("Ljava/lang/Object;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitStmt3R(APUT_OBJECT,8,6,7);
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
