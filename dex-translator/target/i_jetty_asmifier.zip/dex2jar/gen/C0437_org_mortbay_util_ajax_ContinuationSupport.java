package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0437_org_mortbay_util_ajax_ContinuationSupport {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/util/ajax/ContinuationSupport;","Ljava/lang/Object;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("ContinuationSupport.java");
        m000__init_(cv);
        m001_getContinuation(cv);
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/util/ajax/ContinuationSupport;","<init>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(26,L0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/Object;","<init>",new String[]{ },"V"));
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001_getContinuation(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/util/ajax/ContinuationSupport;","getContinuation",new String[]{ "Ljavax/servlet/http/HttpServletRequest;","Ljava/lang/Object;"},"Lorg/mortbay/util/ajax/Continuation;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"request");
                ddv.visitParameterName(1,"lock");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(30,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(31,L1);
                ddv.visitStartLocal(1,L1,"continuation","Lorg/mortbay/util/ajax/Continuation;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(32,L2);
                DexLabel L3=new DexLabel();
                ddv.visitEndLocal(1,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(35,L4);
                ddv.visitRestartLocal(1,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(33,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(34,L6);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_STRING,2,"org.mortbay.jetty.ajax.Continuation");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3,2},new Method("Ljavax/servlet/http/HttpServletRequest;","getAttribute",new String[]{ "Ljava/lang/String;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitTypeStmt(CHECK_CAST,1,-1,"Lorg/mortbay/util/ajax/Continuation;");
                code.visitLabel(L1);
                code.visitJumpStmt(IF_NEZ,1,-1,L5);
                code.visitLabel(L2);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Lorg/mortbay/util/ajax/WaitingContinuation;");
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,4},new Method("Lorg/mortbay/util/ajax/WaitingContinuation;","<init>",new String[]{ "Ljava/lang/Object;"},"V"));
                code.visitLabel(L4);
                code.visitStmt1R(RETURN_OBJECT,1);
                code.visitLabel(L5);
                code.visitTypeStmt(INSTANCE_OF,2,1,"Lorg/mortbay/util/ajax/WaitingContinuation;");
                code.visitJumpStmt(IF_EQZ,2,-1,L4);
                code.visitJumpStmt(IF_EQZ,4,-1,L4);
                code.visitLabel(L6);
                code.visitStmt2R(MOVE_OBJECT,0,1);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Lorg/mortbay/util/ajax/WaitingContinuation;");
                code.visitStmt2R(MOVE_OBJECT,2,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,4},new Method("Lorg/mortbay/util/ajax/WaitingContinuation;","setMutex",new String[]{ "Ljava/lang/Object;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
