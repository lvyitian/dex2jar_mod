package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0210_org_mortbay_jetty_client_HttpConnection_Handler {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(0,"Lorg/mortbay/jetty/client/HttpConnection$Handler;","Lorg/mortbay/jetty/HttpParser$EventHandler;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("HttpConnection.java");
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/EnclosingClass;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("value", new DexType("Lorg/mortbay/jetty/client/HttpConnection;"));
                av00.visitEnd();
            }
        }
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/InnerClass;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("accessFlags",  Integer.valueOf(2));
                av00.visit("name", "Handler");
                av00.visitEnd();
            }
        }
        f000_this$0(cv);
        m000__init_(cv);
        m001__init_(cv);
        m002_content(cv);
        m003_headerComplete(cv);
        m004_messageComplete(cv);
        m005_parsedHeader(cv);
        m006_startRequest(cv);
        m007_startResponse(cv);
    }
    public static void f000_this$0(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_FINAL|ACC_SYNTHETIC, new Field("Lorg/mortbay/jetty/client/HttpConnection$Handler;","this$0","Lorg/mortbay/jetty/client/HttpConnection;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PRIVATE|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/client/HttpConnection$Handler;","<init>",new String[]{ "Lorg/mortbay/jetty/client/HttpConnection;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(474,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/client/HttpConnection$Handler;","this$0","Lorg/mortbay/jetty/client/HttpConnection;"));
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Lorg/mortbay/jetty/HttpParser$EventHandler;","<init>",new String[]{ },"V"));
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_SYNTHETIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/client/HttpConnection$Handler;","<init>",new String[]{ "Lorg/mortbay/jetty/client/HttpConnection;","Lorg/mortbay/jetty/client/HttpConnection$1;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"x0");
                ddv.visitParameterName(1,"x1");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(474,L0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/client/HttpConnection$Handler;","<init>",new String[]{ "Lorg/mortbay/jetty/client/HttpConnection;"},"V"));
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_content(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/client/HttpConnection$Handler;","content",new String[]{ "Lorg/mortbay/io/Buffer;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"ref");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(523,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(524,L1);
                ddv.visitStartLocal(0,L1,"exchange","Lorg/mortbay/jetty/client/HttpExchange;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(525,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(526,L3);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/client/HttpConnection$Handler;","this$0","Lorg/mortbay/jetty/client/HttpConnection;"));
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_exchange","Lorg/mortbay/jetty/client/HttpExchange;"));
                code.visitLabel(L1);
                code.visitJumpStmt(IF_EQZ,0,-1,L3);
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/client/HttpExchange;","getEventListener",new String[]{ },"Lorg/mortbay/jetty/client/HttpEventListener;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1,3},new Method("Lorg/mortbay/jetty/client/HttpEventListener;","onResponseContent",new String[]{ "Lorg/mortbay/io/Buffer;"},"V"));
                code.visitLabel(L3);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_headerComplete(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/client/HttpConnection$Handler;","headerComplete",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(515,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(516,L1);
                ddv.visitStartLocal(0,L1,"exchange","Lorg/mortbay/jetty/client/HttpExchange;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(517,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(518,L3);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/client/HttpConnection$Handler;","this$0","Lorg/mortbay/jetty/client/HttpConnection;"));
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_exchange","Lorg/mortbay/jetty/client/HttpExchange;"));
                code.visitLabel(L1);
                code.visitJumpStmt(IF_EQZ,0,-1,L3);
                code.visitLabel(L2);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(6)); // int: 0x00000006  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/client/HttpExchange;","setStatus",new String[]{ "I"},"V"));
                code.visitLabel(L3);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_messageComplete(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/client/HttpConnection$Handler;","messageComplete",new String[]{ "J"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"contextLength");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(531,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(532,L1);
                ddv.visitStartLocal(0,L1,"exchange","Lorg/mortbay/jetty/client/HttpExchange;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(533,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(534,L3);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/client/HttpConnection$Handler;","this$0","Lorg/mortbay/jetty/client/HttpConnection;"));
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_exchange","Lorg/mortbay/jetty/client/HttpExchange;"));
                code.visitLabel(L1);
                code.visitJumpStmt(IF_EQZ,0,-1,L3);
                code.visitLabel(L2);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(7)); // int: 0x00000007  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/client/HttpExchange;","setStatus",new String[]{ "I"},"V"));
                code.visitLabel(L3);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_parsedHeader(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/client/HttpConnection$Handler;","parsedHeader",new String[]{ "Lorg/mortbay/io/Buffer;","Lorg/mortbay/io/Buffer;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                ddv.visitParameterName(1,"value");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(501,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(502,L1);
                ddv.visitStartLocal(0,L1,"exchange","Lorg/mortbay/jetty/client/HttpExchange;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(504,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(506,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(508,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(510,L5);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/jetty/client/HttpConnection$Handler;","this$0","Lorg/mortbay/jetty/client/HttpConnection;"));
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_exchange","Lorg/mortbay/jetty/client/HttpExchange;"));
                code.visitLabel(L1);
                code.visitJumpStmt(IF_EQZ,0,-1,L5);
                code.visitLabel(L2);
                code.visitFieldStmt(SGET_OBJECT,1,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","CACHE","Lorg/mortbay/jetty/HttpHeaders;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,4},new Method("Lorg/mortbay/jetty/HttpHeaders;","getOrdinal",new String[]{ "Lorg/mortbay/io/Buffer;"},"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitJumpStmt(IF_NE,1,2,L4);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/jetty/client/HttpConnection$Handler;","this$0","Lorg/mortbay/jetty/client/HttpConnection;"));
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/jetty/HttpHeaderValues;","CACHE","Lorg/mortbay/jetty/HttpHeaderValues;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,5},new Method("Lorg/mortbay/jetty/HttpHeaderValues;","lookup",new String[]{ "Lorg/mortbay/io/Buffer;"},"Lorg/mortbay/io/Buffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitFieldStmt(IPUT_OBJECT,2,1,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_connectionHeader","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/client/HttpExchange;","getEventListener",new String[]{ },"Lorg/mortbay/jetty/client/HttpEventListener;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1,4,5},new Method("Lorg/mortbay/jetty/client/HttpEventListener;","onResponseHeader",new String[]{ "Lorg/mortbay/io/Buffer;","Lorg/mortbay/io/Buffer;"},"V"));
                code.visitLabel(L5);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_startRequest(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/client/HttpConnection$Handler;","startRequest",new String[]{ "Lorg/mortbay/io/Buffer;","Lorg/mortbay/io/Buffer;","Lorg/mortbay/io/Buffer;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"method");
                ddv.visitParameterName(1,"url");
                ddv.visitParameterName(2,"version");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(484,L0);
                code.visitLabel(L0);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m007_startResponse(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/client/HttpConnection$Handler;","startResponse",new String[]{ "Lorg/mortbay/io/Buffer;","I","Lorg/mortbay/io/Buffer;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"version");
                ddv.visitParameterName(1,"status");
                ddv.visitParameterName(2,"reason");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(489,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(490,L1);
                ddv.visitStartLocal(0,L1,"exchange","Lorg/mortbay/jetty/client/HttpExchange;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(492,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(493,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(494,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(496,L5);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/jetty/client/HttpConnection$Handler;","this$0","Lorg/mortbay/jetty/client/HttpConnection;"));
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_exchange","Lorg/mortbay/jetty/client/HttpExchange;"));
                code.visitLabel(L1);
                code.visitJumpStmt(IF_EQZ,0,-1,L5);
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/jetty/client/HttpConnection$Handler;","this$0","Lorg/mortbay/jetty/client/HttpConnection;"));
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/jetty/HttpVersions;","HTTP_1_1_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,4},new Method("Ljava/lang/Object;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitFieldStmt(IPUT_BOOLEAN,2,1,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_http11","Z"));
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/client/HttpExchange;","getEventListener",new String[]{ },"Lorg/mortbay/jetty/client/HttpEventListener;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1,4,5,6},new Method("Lorg/mortbay/jetty/client/HttpEventListener;","onResponseStatus",new String[]{ "Lorg/mortbay/io/Buffer;","I","Lorg/mortbay/io/Buffer;"},"V"));
                code.visitLabel(L4);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(5)); // int: 0x00000005  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/client/HttpExchange;","setStatus",new String[]{ "I"},"V"));
                code.visitLabel(L5);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
