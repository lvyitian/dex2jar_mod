package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0160_org_mortbay_jetty_HttpFields_3 {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(0,"Lorg/mortbay/jetty/HttpFields$3;","Ljava/lang/Object;",new String[]{ "Ljava/util/Enumeration;"});
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("HttpFields.java");
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/EnclosingMethod;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("value", new Method("Lorg/mortbay/jetty/HttpFields;","getValues",new String[]{ "Ljava/lang/String;"},"Ljava/util/Enumeration;"));
                av00.visitEnd();
            }
        }
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/InnerClass;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("accessFlags",  Integer.valueOf(0));
                av00.visit("name", null);
                av00.visitEnd();
            }
        }
        f000_f(cv);
        f001_this$0(cv);
        f002_val$field(cv);
        f003_val$revision(cv);
        m000__init_(cv);
        m001_hasMoreElements(cv);
        m002_nextElement(cv);
    }
    public static void f000_f(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/jetty/HttpFields$3;","f","Lorg/mortbay/jetty/HttpFields$Field;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001_this$0(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_FINAL|ACC_SYNTHETIC, new Field("Lorg/mortbay/jetty/HttpFields$3;","this$0","Lorg/mortbay/jetty/HttpFields;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002_val$field(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_FINAL|ACC_SYNTHETIC, new Field("Lorg/mortbay/jetty/HttpFields$3;","val$field","Lorg/mortbay/jetty/HttpFields$Field;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003_val$revision(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_FINAL|ACC_SYNTHETIC, new Field("Lorg/mortbay/jetty/HttpFields$3;","val$revision","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/HttpFields$3;","<init>",new String[]{ "Lorg/mortbay/jetty/HttpFields;","Lorg/mortbay/jetty/HttpFields$Field;","I"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(392,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(383,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,2,1,new Field("Lorg/mortbay/jetty/HttpFields$3;","this$0","Lorg/mortbay/jetty/HttpFields;"));
                code.visitFieldStmt(IPUT_OBJECT,3,1,new Field("Lorg/mortbay/jetty/HttpFields$3;","val$field","Lorg/mortbay/jetty/HttpFields$Field;"));
                code.visitFieldStmt(IPUT,4,1,new Field("Lorg/mortbay/jetty/HttpFields$3;","val$revision","I"));
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljava/lang/Object;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/HttpFields$3;","val$field","Lorg/mortbay/jetty/HttpFields$Field;"));
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/HttpFields$3;","f","Lorg/mortbay/jetty/HttpFields$Field;"));
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001_hasMoreElements(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpFields$3;","hasMoreElements",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(387,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(388,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(389,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/HttpFields$3;","f","Lorg/mortbay/jetty/HttpFields$Field;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L2);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/HttpFields$3;","f","Lorg/mortbay/jetty/HttpFields$Field;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/jetty/HttpFields$Field;","access$100",new String[]{ "Lorg/mortbay/jetty/HttpFields$Field;"},"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitFieldStmt(IGET,1,2,new Field("Lorg/mortbay/jetty/HttpFields$3;","val$revision","I"));
                code.visitJumpStmt(IF_EQ,0,1,L2);
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/HttpFields$3;","f","Lorg/mortbay/jetty/HttpFields$Field;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/jetty/HttpFields$Field;","access$400",new String[]{ "Lorg/mortbay/jetty/HttpFields$Field;"},"Lorg/mortbay/jetty/HttpFields$Field;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/jetty/HttpFields$3;","f","Lorg/mortbay/jetty/HttpFields$Field;"));
                code.visitJumpStmt(GOTO,-1,-1,L0);
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/HttpFields$3;","f","Lorg/mortbay/jetty/HttpFields$Field;"));
                DexLabel L3=new DexLabel();
                code.visitJumpStmt(IF_EQZ,0,-1,L3);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                DexLabel L4=new DexLabel();
                code.visitLabel(L4);
                code.visitStmt1R(RETURN,0);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_nextElement(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpFields$3;","nextElement",new String[]{ },"Ljava/lang/Object;"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/util/NoSuchElementException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(394,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(395,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(397,L2);
                ddv.visitStartLocal(0,L2,"n","Lorg/mortbay/jetty/HttpFields$Field;",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(398,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(399,L4);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/jetty/HttpFields$3;","f","Lorg/mortbay/jetty/HttpFields$Field;"));
                code.visitJumpStmt(IF_NEZ,1,-1,L1);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/util/NoSuchElementException;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljava/util/NoSuchElementException;","<init>",new String[]{ },"V"));
                code.visitStmt1R(THROW,1);
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/jetty/HttpFields$3;","f","Lorg/mortbay/jetty/HttpFields$Field;"));
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/jetty/HttpFields$3;","f","Lorg/mortbay/jetty/HttpFields$Field;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1},new Method("Lorg/mortbay/jetty/HttpFields$Field;","access$400",new String[]{ "Lorg/mortbay/jetty/HttpFields$Field;"},"Lorg/mortbay/jetty/HttpFields$Field;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitFieldStmt(IPUT_OBJECT,1,3,new Field("Lorg/mortbay/jetty/HttpFields$3;","f","Lorg/mortbay/jetty/HttpFields$Field;"));
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/jetty/HttpFields$3;","f","Lorg/mortbay/jetty/HttpFields$Field;"));
                code.visitJumpStmt(IF_EQZ,1,-1,L4);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/jetty/HttpFields$3;","f","Lorg/mortbay/jetty/HttpFields$Field;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1},new Method("Lorg/mortbay/jetty/HttpFields$Field;","access$100",new String[]{ "Lorg/mortbay/jetty/HttpFields$Field;"},"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitFieldStmt(IGET,2,3,new Field("Lorg/mortbay/jetty/HttpFields$3;","val$revision","I"));
                code.visitJumpStmt(IF_NE,1,2,L2);
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/HttpFields$Field;","getValue",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitStmt1R(RETURN_OBJECT,1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
