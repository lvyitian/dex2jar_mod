package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0366_org_mortbay_resource_FileResource {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/resource/FileResource;","Lorg/mortbay/resource/URLResource;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("FileResource.java");
        f000___checkAliases(cv);
        f001__alias(cv);
        f002__aliasChecked(cv);
        f003__file(cv);
        m000__clinit_(cv);
        m001__init_(cv);
        m002__init_(cv);
        m003_getCheckAliases(cv);
        m004_setCheckAliases(cv);
        m005_addPath(cv);
        m006_delete(cv);
        m007_encode(cv);
        m008_equals(cv);
        m009_exists(cv);
        m010_getAlias(cv);
        m011_getFile(cv);
        m012_getInputStream(cv);
        m013_getName(cv);
        m014_getOutputStream(cv);
        m015_hashCode(cv);
        m016_isDirectory(cv);
        m017_lastModified(cv);
        m018_length(cv);
        m019_list(cv);
        m020_renameTo(cv);
    }
    public static void f000___checkAliases(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC, new Field("Lorg/mortbay/resource/FileResource;","__checkAliases","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001__alias(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_TRANSIENT, new Field("Lorg/mortbay/resource/FileResource;","_alias","Ljava/net/URL;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002__aliasChecked(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_TRANSIENT, new Field("Lorg/mortbay/resource/FileResource;","_aliasChecked","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003__file(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/resource/FileResource;","_file","Ljava/io/File;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__clinit_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/resource/FileResource;","<clinit>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(49,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(53,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(54,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(55,L4);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_STRING,2,"true");
                code.visitLabel(L1);
                code.visitConstStmt(CONST_STRING,0,"true");
                code.visitConstStmt(CONST_STRING,0,"org.mortbay.util.FileResource.checkAliases");
                code.visitConstStmt(CONST_STRING,1,"true");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,2},new Method("Ljava/lang/System;","getProperty",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,0},new Method("Ljava/lang/String;","equalsIgnoreCase",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitFieldStmt(SPUT_BOOLEAN,0,-1,new Field("Lorg/mortbay/resource/FileResource;","__checkAliases","Z"));
                code.visitLabel(L2);
                code.visitFieldStmt(SGET_BOOLEAN,0,-1,new Field("Lorg/mortbay/resource/FileResource;","__checkAliases","Z"));
                code.visitJumpStmt(IF_EQZ,0,-1,L4);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_STRING,0,"Checking Resource aliases");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L4);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/resource/FileResource;","<init>",new String[]{ "Ljava/net/URL;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visit(null, new DexType("Ljava/net/URISyntaxException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(12);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/lang/Exception;"});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                DexLabel L5=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L5},new String[]{ "Ljava/lang/Exception;"});
                DexLabel L6=new DexLabel();
                DexLabel L7=new DexLabel();
                code.visitTryCatch(L6,L7,new DexLabel[]{L5},new String[]{ "Ljava/lang/Exception;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"url");
                DexLabel L8=new DexLabel();
                ddv.visitPrologue(L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(84,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(59,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(60,L11);
                ddv.visitLineNumber(89,L0);
                ddv.visitLineNumber(115,L1);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(117,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(118,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(126,L14);
                ddv.visitLineNumber(91,L2);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(93,L15);
                ddv.visitStartLocal(0,L15,"e","Ljava/lang/Exception;",null);
                ddv.visitLineNumber(98,L3);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(99,L16);
                ddv.visitStartLocal(2,L16,"file_url","Ljava/lang/String;",null);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(100,L17);
                ddv.visitStartLocal(4,L17,"uri","Ljava/net/URI;",null);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(101,L18);
                ddv.visitLineNumber(105,L5);
                ddv.visitEndLocal(2,L5);
                ddv.visitEndLocal(4,L5);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(107,L19);
                ddv.visitStartLocal(1,L19,"e2","Ljava/lang/Exception;",null);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(110,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(111,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(112,L22);
                ddv.visitStartLocal(3,L22,"perm","Ljava/security/Permission;",null);
                ddv.visitLineNumber(103,L6);
                ddv.visitEndLocal(1,L6);
                ddv.visitEndLocal(3,L6);
                ddv.visitRestartLocal(2,L6);
                ddv.visitRestartLocal(4,L6);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(112,L23);
                ddv.visitEndLocal(2,L23);
                ddv.visitEndLocal(4,L23);
                ddv.visitRestartLocal(1,L23);
                ddv.visitRestartLocal(3,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(122,L24);
                ddv.visitEndLocal(0,L24);
                ddv.visitEndLocal(1,L24);
                ddv.visitEndLocal(3,L24);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(123,L25);
                code.visitLabel(L8);
                code.visitConstStmt(CONST_4,5, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitConstStmt(CONST_4,9, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitConstStmt(CONST_STRING,8,"/");
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 10,11,5},new Method("Lorg/mortbay/resource/URLResource;","<init>",new String[]{ "Ljava/net/URL;","Ljava/net/URLConnection;"},"V"));
                code.visitLabel(L10);
                code.visitFieldStmt(IPUT_OBJECT,5,10,new Field("Lorg/mortbay/resource/FileResource;","_alias","Ljava/net/URL;"));
                code.visitLabel(L11);
                code.visitFieldStmt(IPUT_BOOLEAN,9,10,new Field("Lorg/mortbay/resource/FileResource;","_aliasChecked","Z"));
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,5,-1,"Ljava/io/File;");
                code.visitTypeStmt(NEW_INSTANCE,6,-1,"Ljava/net/URI;");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11},new Method("Ljava/net/URL;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 6,7},new Method("Ljava/net/URI;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 5,6},new Method("Ljava/io/File;","<init>",new String[]{ "Ljava/net/URI;"},"V"));
                code.visitFieldStmt(IPUT_OBJECT,5,10,new Field("Lorg/mortbay/resource/FileResource;","_file","Ljava/io/File;"));
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,5,10,new Field("Lorg/mortbay/resource/FileResource;","_file","Ljava/io/File;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/io/File;","isDirectory",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitJumpStmt(IF_EQZ,5,-1,L24);
                code.visitLabel(L12);
                code.visitFieldStmt(IGET_OBJECT,5,10,new Field("Lorg/mortbay/resource/FileResource;","_urlString","Ljava/lang/String;"));
                code.visitConstStmt(CONST_STRING,6,"/");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,8},new Method("Ljava/lang/String;","endsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitJumpStmt(IF_NEZ,5,-1,L14);
                code.visitLabel(L13);
                code.visitTypeStmt(NEW_INSTANCE,5,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 5},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IGET_OBJECT,6,10,new Field("Lorg/mortbay/resource/FileResource;","_urlString","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitConstStmt(CONST_STRING,6,"/");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,8},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitFieldStmt(IPUT_OBJECT,5,10,new Field("Lorg/mortbay/resource/FileResource;","_urlString","Ljava/lang/String;"));
                code.visitLabel(L14);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,5);
                code.visitStmt2R(MOVE_OBJECT,0,5);
                code.visitLabel(L15);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/log/Log;","ignore",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitLabel(L3);
                code.visitTypeStmt(NEW_INSTANCE,5,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 5},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,6,"file:");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11},new Method("Ljava/net/URL;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitConstStmt(CONST_4,7, Integer.valueOf(5)); // int: 0x00000005  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,7},new Method("Ljava/lang/String;","substring",new String[]{ "I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 6},new Method("Lorg/mortbay/util/URIUtil;","encodePath",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L16);
                code.visitTypeStmt(NEW_INSTANCE,4,-1,"Ljava/net/URI;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4,2},new Method("Ljava/net/URI;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L17);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/net/URI;","getAuthority",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitJumpStmt(IF_NEZ,5,-1,L6);
                code.visitLabel(L18);
                code.visitTypeStmt(NEW_INSTANCE,5,-1,"Ljava/io/File;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 5,4},new Method("Ljava/io/File;","<init>",new String[]{ "Ljava/net/URI;"},"V"));
                code.visitFieldStmt(IPUT_OBJECT,5,10,new Field("Lorg/mortbay/resource/FileResource;","_file","Ljava/io/File;"));
                code.visitLabel(L4);
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitLabel(L5);
                code.visitStmt1R(MOVE_EXCEPTION,5);
                code.visitStmt2R(MOVE_OBJECT,1,5);
                code.visitLabel(L19);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1},new Method("Lorg/mortbay/log/Log;","ignore",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitLabel(L20);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Lorg/mortbay/resource/FileResource;","checkConnection",new String[]{ },"Z"));
                code.visitLabel(L21);
                code.visitFieldStmt(IGET_OBJECT,5,10,new Field("Lorg/mortbay/resource/FileResource;","_connection","Ljava/net/URLConnection;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/net/URLConnection;","getPermission",new String[]{ },"Ljava/security/Permission;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitLabel(L22);
                code.visitTypeStmt(NEW_INSTANCE,5,-1,"Ljava/io/File;");
                code.visitJumpStmt(IF_NEZ,3,-1,L23);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11},new Method("Ljava/net/URL;","getFile",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                DexLabel L26=new DexLabel();
                code.visitLabel(L26);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 5,6},new Method("Ljava/io/File;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitFieldStmt(IPUT_OBJECT,5,10,new Field("Lorg/mortbay/resource/FileResource;","_file","Ljava/io/File;"));
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitLabel(L6);
                code.visitTypeStmt(NEW_INSTANCE,5,-1,"Ljava/io/File;");
                code.visitTypeStmt(NEW_INSTANCE,6,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 6},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,7,"//");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,7},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/net/URI;","getAuthority",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,7},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11},new Method("Ljava/net/URL;","getFile",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 7},new Method("Lorg/mortbay/util/URIUtil;","decodePath",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,7},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 5,6},new Method("Ljava/io/File;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitFieldStmt(IPUT_OBJECT,5,10,new Field("Lorg/mortbay/resource/FileResource;","_file","Ljava/io/File;"));
                code.visitLabel(L7);
                code.visitJumpStmt(GOTO_16,-1,-1,L1);
                code.visitLabel(L23);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/security/Permission;","getName",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitJumpStmt(GOTO,-1,-1,L26);
                code.visitLabel(L24);
                code.visitFieldStmt(IGET_OBJECT,5,10,new Field("Lorg/mortbay/resource/FileResource;","_urlString","Ljava/lang/String;"));
                code.visitConstStmt(CONST_STRING,6,"/");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,8},new Method("Ljava/lang/String;","endsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitJumpStmt(IF_EQZ,5,-1,L14);
                code.visitLabel(L25);
                code.visitFieldStmt(IGET_OBJECT,5,10,new Field("Lorg/mortbay/resource/FileResource;","_urlString","Ljava/lang/String;"));
                code.visitFieldStmt(IGET_OBJECT,6,10,new Field("Lorg/mortbay/resource/FileResource;","_urlString","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitConstStmt(CONST_4,7, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt2R(SUB_INT_2ADDR,6,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,9,6},new Method("Ljava/lang/String;","substring",new String[]{ "I","I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitFieldStmt(IPUT_OBJECT,5,10,new Field("Lorg/mortbay/resource/FileResource;","_urlString","Ljava/lang/String;"));
                code.visitJumpStmt(GOTO_16,-1,-1,L14);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_CONSTRUCTOR, new Method("Lorg/mortbay/resource/FileResource;","<init>",new String[]{ "Ljava/net/URL;","Ljava/net/URLConnection;","Ljava/io/File;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"url");
                ddv.visitParameterName(1,"connection");
                ddv.visitParameterName(2,"file");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(131,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(59,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(60,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(132,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(133,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(134,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(135,L7);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_STRING,2,"/");
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3,4,5},new Method("Lorg/mortbay/resource/URLResource;","<init>",new String[]{ "Ljava/net/URL;","Ljava/net/URLConnection;"},"V"));
                code.visitLabel(L2);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_OBJECT,0,3,new Field("Lorg/mortbay/resource/FileResource;","_alias","Ljava/net/URL;"));
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_BOOLEAN,0,3,new Field("Lorg/mortbay/resource/FileResource;","_aliasChecked","Z"));
                code.visitLabel(L4);
                code.visitFieldStmt(IPUT_OBJECT,6,3,new Field("Lorg/mortbay/resource/FileResource;","_file","Ljava/io/File;"));
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/resource/FileResource;","_file","Ljava/io/File;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/io/File;","isDirectory",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L7);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/resource/FileResource;","_urlString","Ljava/lang/String;"));
                code.visitConstStmt(CONST_STRING,1,"/");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,2},new Method("Ljava/lang/String;","endsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_NEZ,0,-1,L7);
                code.visitLabel(L6);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/resource/FileResource;","_urlString","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitConstStmt(CONST_STRING,1,"/");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IPUT_OBJECT,0,3,new Field("Lorg/mortbay/resource/FileResource;","_urlString","Ljava/lang/String;"));
                code.visitLabel(L7);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_getCheckAliases(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/resource/FileResource;","getCheckAliases",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(77,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(SGET_BOOLEAN,0,-1,new Field("Lorg/mortbay/resource/FileResource;","__checkAliases","Z"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_setCheckAliases(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/resource/FileResource;","setCheckAliases",new String[]{ "Z"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"checkAliases");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(68,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(69,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(SPUT_BOOLEAN,0,-1,new Field("Lorg/mortbay/resource/FileResource;","__checkAliases","Z"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_addPath(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/resource/FileResource;","addPath",new String[]{ "Ljava/lang/String;"},"Lorg/mortbay/resource/Resource;"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visit(null, new DexType("Ljava/net/MalformedURLException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(13);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"path");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(141,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(142,L2);
                ddv.visitStartLocal(4,L2,"r","Lorg/mortbay/resource/URLResource;",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(144,L3);
                ddv.visitStartLocal(6,L3,"url","Ljava/lang/String;",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(146,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(148,L5);
                DexLabel L6=new DexLabel();
                ddv.visitEndLocal(4,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(149,L7);
                ddv.visitRestartLocal(4,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(165,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(166,L9);
                ddv.visitStartLocal(1,L9,"encoded","Ljava/lang/String;",null);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(167,L10);
                ddv.visitStartLocal(2,L10,"expected","I",null);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(169,L11);
                ddv.visitStartLocal(3,L11,"index","I",null);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(171,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(173,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(174,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(177,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(153,L16);
                ddv.visitEndLocal(1,L16);
                ddv.visitEndLocal(2,L16);
                ddv.visitEndLocal(3,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(154,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(157,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(158,L19);
                ddv.visitStartLocal(5,L19,"rel","Ljava/lang/String;",null);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(159,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(161,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(162,L22);
                ddv.visitRestartLocal(6,L22);
                DexLabel L23=new DexLabel();
                ddv.visitEndLocal(4,L23);
                DexLabel L24=new DexLabel();
                ddv.visitRestartLocal(4,L24);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,9, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitConstStmt(CONST_STRING,10,"/");
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L2);
                code.visitConstStmt(CONST_4,6, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 12},new Method("Lorg/mortbay/util/URIUtil;","canonicalPath",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,12);
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11},new Method("Lorg/mortbay/resource/FileResource;","isDirectory",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitJumpStmt(IF_NEZ,7,-1,L16);
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 11,12},new Method("Lorg/mortbay/resource/URLResource;","addPath",new String[]{ "Ljava/lang/String;"},"Lorg/mortbay/resource/Resource;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitLabel(L6);
                code.visitTypeStmt(CHECK_CAST,4,-1,"Lorg/mortbay/resource/FileResource;");
                code.visitLabel(L7);
                code.visitFieldStmt(IGET_OBJECT,6,4,new Field("Lorg/mortbay/resource/URLResource;","_urlString","Ljava/lang/String;"));
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 12},new Method("Lorg/mortbay/util/URIUtil;","encodePath",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/resource/URLResource;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitStmt3R(SUB_INT,2,7,8);
                code.visitLabel(L10);
                code.visitFieldStmt(IGET_OBJECT,7,4,new Field("Lorg/mortbay/resource/URLResource;","_urlString","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,1,2},new Method("Ljava/lang/String;","lastIndexOf",new String[]{ "Ljava/lang/String;","I"},"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitLabel(L11);
                code.visitJumpStmt(IF_EQ,2,3,L15);
                code.visitStmt3R(SUB_INT,7,2,9);
                code.visitJumpStmt(IF_NE,7,3,L12);
                code.visitConstStmt(CONST_STRING,7,"/");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12,10},new Method("Ljava/lang/String;","endsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitJumpStmt(IF_NEZ,7,-1,L12);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/resource/URLResource;","isDirectory",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitJumpStmt(IF_NEZ,7,-1,L15);
                code.visitLabel(L12);
                code.visitTypeStmt(INSTANCE_OF,7,4,"Lorg/mortbay/resource/BadResource;");
                code.visitJumpStmt(IF_NEZ,7,-1,L15);
                code.visitLabel(L13);
                code.visitStmt2R(MOVE_OBJECT,0,4);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Lorg/mortbay/resource/FileResource;");
                code.visitStmt2R(MOVE_OBJECT,7,0);
                code.visitTypeStmt(NEW_INSTANCE,8,-1,"Ljava/net/URL;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 8,6},new Method("Ljava/net/URL;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitFieldStmt(IPUT_OBJECT,8,7,new Field("Lorg/mortbay/resource/FileResource;","_alias","Ljava/net/URL;"));
                code.visitLabel(L14);
                code.visitStmt2R(MOVE_OBJECT,0,4);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Lorg/mortbay/resource/FileResource;");
                code.visitStmt2R(MOVE_OBJECT,7,0);
                code.visitFieldStmt(IPUT_BOOLEAN,9,7,new Field("Lorg/mortbay/resource/FileResource;","_aliasChecked","Z"));
                code.visitLabel(L15);
                code.visitStmt1R(RETURN_OBJECT,4);
                code.visitLabel(L16);
                code.visitJumpStmt(IF_NEZ,12,-1,L18);
                code.visitLabel(L17);
                code.visitTypeStmt(NEW_INSTANCE,7,-1,"Ljava/net/MalformedURLException;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 7},new Method("Ljava/net/MalformedURLException;","<init>",new String[]{ },"V"));
                code.visitStmt1R(THROW,7);
                code.visitLabel(L18);
                code.visitStmt2R(MOVE_OBJECT,5,12);
                code.visitLabel(L19);
                code.visitConstStmt(CONST_STRING,7,"/");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12,10},new Method("Ljava/lang/String;","startsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitJumpStmt(IF_EQZ,7,-1,L21);
                code.visitLabel(L20);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12,9},new Method("Ljava/lang/String;","substring",new String[]{ "I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitLabel(L21);
                code.visitFieldStmt(IGET_OBJECT,7,11,new Field("Lorg/mortbay/resource/FileResource;","_urlString","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 5},new Method("Lorg/mortbay/util/URIUtil;","encodePath",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 7,8},new Method("Lorg/mortbay/util/URIUtil;","addPaths",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitLabel(L22);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 6},new Method("Lorg/mortbay/resource/Resource;","newResource",new String[]{ "Ljava/lang/String;"},"Lorg/mortbay/resource/Resource;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitLabel(L23);
                code.visitTypeStmt(CHECK_CAST,4,-1,"Lorg/mortbay/resource/URLResource;");
                code.visitLabel(L24);
                code.visitJumpStmt(GOTO,-1,-1,L8);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_delete(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/resource/FileResource;","delete",new String[]{ },"Z"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/SecurityException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(293,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/resource/FileResource;","_file","Ljava/io/File;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/io/File;","delete",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m007_encode(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/resource/FileResource;","encode",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"uri");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(335,L0);
                code.visitLabel(L0);
                code.visitStmt1R(RETURN_OBJECT,1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m008_equals(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/resource/FileResource;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(8);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"o");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(345,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(352,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(348,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(349,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(351,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(352,L6);
                ddv.visitStartLocal(1,L6,"f","Lorg/mortbay/resource/FileResource;",null);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,5, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitConstStmt(CONST_4,4, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitJumpStmt(IF_NE,6,7,L3);
                code.visitStmt2R(MOVE,2,5);
                code.visitLabel(L2);
                code.visitStmt1R(RETURN,2);
                code.visitLabel(L3);
                DexLabel L7=new DexLabel();
                code.visitJumpStmt(IF_EQZ,7,-1,L7);
                code.visitTypeStmt(INSTANCE_OF,2,7,"Lorg/mortbay/resource/FileResource;");
                code.visitJumpStmt(IF_NEZ,2,-1,L5);
                code.visitLabel(L7);
                code.visitStmt2R(MOVE,2,4);
                code.visitLabel(L4);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L5);
                code.visitStmt2R(MOVE_OBJECT,0,7);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Lorg/mortbay/resource/FileResource;");
                code.visitStmt2R(MOVE_OBJECT,1,0);
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,2,1,new Field("Lorg/mortbay/resource/FileResource;","_file","Ljava/io/File;"));
                code.visitFieldStmt(IGET_OBJECT,3,6,new Field("Lorg/mortbay/resource/FileResource;","_file","Ljava/io/File;"));
                DexLabel L8=new DexLabel();
                code.visitJumpStmt(IF_EQ,2,3,L8);
                code.visitFieldStmt(IGET_OBJECT,2,6,new Field("Lorg/mortbay/resource/FileResource;","_file","Ljava/io/File;"));
                DexLabel L9=new DexLabel();
                code.visitJumpStmt(IF_EQZ,2,-1,L9);
                code.visitFieldStmt(IGET_OBJECT,2,6,new Field("Lorg/mortbay/resource/FileResource;","_file","Ljava/io/File;"));
                code.visitFieldStmt(IGET_OBJECT,3,1,new Field("Lorg/mortbay/resource/FileResource;","_file","Ljava/io/File;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/io/File;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_EQZ,2,-1,L9);
                code.visitLabel(L8);
                code.visitStmt2R(MOVE,2,5);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L9);
                code.visitStmt2R(MOVE,2,4);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m009_exists(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/resource/FileResource;","exists",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(217,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/resource/FileResource;","_file","Ljava/io/File;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/io/File;","exists",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m010_getAlias(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/resource/FileResource;","getAlias",new String[]{ },"Ljava/net/URL;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/lang/Exception;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(184,L3);
                ddv.visitLineNumber(188,L0);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(189,L4);
                ddv.visitStartLocal(0,L4,"abs","Ljava/lang/String;",null);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(191,L5);
                ddv.visitStartLocal(1,L5,"can","Ljava/lang/String;",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(192,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(194,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(196,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(198,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(199,L10);
                ddv.visitLineNumber(208,L1);
                ddv.visitEndLocal(0,L1);
                ddv.visitEndLocal(1,L1);
                ddv.visitLineNumber(202,L2);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(204,L11);
                ddv.visitStartLocal(2,L11,"e","Ljava/lang/Exception;",null);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(205,L12);
                code.visitLabel(L3);
                code.visitFieldStmt(SGET_BOOLEAN,3,-1,new Field("Lorg/mortbay/resource/FileResource;","__checkAliases","Z"));
                code.visitJumpStmt(IF_EQZ,3,-1,L1);
                code.visitFieldStmt(IGET_BOOLEAN,3,5,new Field("Lorg/mortbay/resource/FileResource;","_aliasChecked","Z"));
                code.visitJumpStmt(IF_NEZ,3,-1,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,3,5,new Field("Lorg/mortbay/resource/FileResource;","_file","Ljava/io/File;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/io/File;","getAbsolutePath",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,3,5,new Field("Lorg/mortbay/resource/FileResource;","_file","Ljava/io/File;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/io/File;","getCanonicalPath",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitJumpStmt(IF_NE,3,4,L6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_NEZ,3,-1,L7);
                code.visitLabel(L6);
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Ljava/io/File;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3,1},new Method("Ljava/io/File;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/io/File;","toURI",new String[]{ },"Ljava/net/URI;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/net/URI;","toURL",new String[]{ },"Ljava/net/URL;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitFieldStmt(IPUT_OBJECT,3,5,new Field("Lorg/mortbay/resource/FileResource;","_alias","Ljava/net/URL;"));
                code.visitLabel(L7);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitFieldStmt(IPUT_BOOLEAN,3,5,new Field("Lorg/mortbay/resource/FileResource;","_aliasChecked","Z"));
                code.visitLabel(L8);
                code.visitFieldStmt(IGET_OBJECT,3,5,new Field("Lorg/mortbay/resource/FileResource;","_alias","Ljava/net/URL;"));
                code.visitJumpStmt(IF_EQZ,3,-1,L1);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/log/Log;","isDebugEnabled",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_EQZ,3,-1,L1);
                code.visitLabel(L9);
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,4,"ALIAS abs=");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,0},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L10);
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,4,"ALIAS can=");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,3,5,new Field("Lorg/mortbay/resource/FileResource;","_alias","Ljava/net/URL;"));
                DexLabel L13=new DexLabel();
                code.visitLabel(L13);
                code.visitStmt1R(RETURN_OBJECT,3);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,3);
                code.visitStmt2R(MOVE_OBJECT,2,3);
                code.visitLabel(L11);
                code.visitConstStmt(CONST_STRING,3,"EXCEPTION ");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3,2},new Method("Lorg/mortbay/log/Log;","warn",new String[]{ "Ljava/lang/String;","Ljava/lang/Throwable;"},"V"));
                code.visitLabel(L12);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/resource/FileResource;","getURL",new String[]{ },"Ljava/net/URL;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitJumpStmt(GOTO,-1,-1,L13);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m011_getFile(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/resource/FileResource;","getFile",new String[]{ },"Ljava/io/File;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(264,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/resource/FileResource;","_file","Ljava/io/File;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m012_getInputStream(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/resource/FileResource;","getInputStream",new String[]{ },"Ljava/io/InputStream;"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(273,L0);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/io/FileInputStream;");
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/resource/FileResource;","_file","Ljava/io/File;"));
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Ljava/io/FileInputStream;","<init>",new String[]{ "Ljava/io/File;"},"V"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m013_getName(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/resource/FileResource;","getName",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(254,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/resource/FileResource;","_file","Ljava/io/File;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/io/File;","getAbsolutePath",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m014_getOutputStream(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/resource/FileResource;","getOutputStream",new String[]{ },"Ljava/io/OutputStream;"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visit(null, new DexType("Ljava/lang/SecurityException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(283,L0);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/io/FileOutputStream;");
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/resource/FileResource;","_file","Ljava/io/File;"));
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Ljava/io/FileOutputStream;","<init>",new String[]{ "Ljava/io/File;"},"V"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m015_hashCode(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/resource/FileResource;","hashCode",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(361,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/resource/FileResource;","_file","Ljava/io/File;"));
                DexLabel L1=new DexLabel();
                code.visitJumpStmt(IF_NEZ,0,-1,L1);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 1},new Method("Lorg/mortbay/resource/URLResource;","hashCode",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                DexLabel L2=new DexLabel();
                code.visitLabel(L2);
                code.visitStmt1R(RETURN,0);
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/resource/FileResource;","_file","Ljava/io/File;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/io/File;","hashCode",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m016_isDirectory(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/resource/FileResource;","isDirectory",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(235,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/resource/FileResource;","_file","Ljava/io/File;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/io/File;","isDirectory",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m017_lastModified(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/resource/FileResource;","lastModified",new String[]{ },"J"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(226,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/resource/FileResource;","_file","Ljava/io/File;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/io/File;","lastModified",new String[]{ },"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,0);
                code.visitStmt1R(RETURN_WIDE,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m018_length(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/resource/FileResource;","length",new String[]{ },"J"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(244,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/resource/FileResource;","_file","Ljava/io/File;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/io/File;","length",new String[]{ },"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,0);
                code.visitStmt1R(RETURN_WIDE,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m019_list(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/resource/FileResource;","list",new String[]{ },"[Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(8);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(315,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(316,L2);
                ddv.visitStartLocal(2,L2,"list","[Ljava/lang/String;",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(317,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(324,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(318,L5);
                DexLabel L6=new DexLabel();
                ddv.visitStartLocal(0,L6,"i","I",null);
                DexLabel L7=new DexLabel();
                ddv.visitEndLocal(0,L7);
                ddv.visitStartLocal(1,L7,"i","I",null);
                DexLabel L8=new DexLabel();
                ddv.visitRestartLocal(0,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(320,L9);
                ddv.visitEndLocal(1,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(322,L10);
                DexLabel L11=new DexLabel();
                ddv.visitRestartLocal(1,L11);
                DexLabel L12=new DexLabel();
                ddv.visitEndLocal(1,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(324,L13);
                DexLabel L14=new DexLabel();
                ddv.visitRestartLocal(1,L14);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_STRING,6,"/");
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,3,7,new Field("Lorg/mortbay/resource/FileResource;","_file","Ljava/io/File;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/io/File;","list",new String[]{ },"[Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L2);
                code.visitJumpStmt(IF_NEZ,2,-1,L5);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L4);
                code.visitStmt1R(RETURN_OBJECT,3);
                code.visitLabel(L5);
                code.visitStmt2R(ARRAY_LENGTH,0,2);
                code.visitLabel(L6);
                code.visitStmt2R(MOVE,1,0);
                code.visitLabel(L7);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt3R(SUB_INT,0,1,3);
                code.visitLabel(L8);
                code.visitJumpStmt(IF_LEZ,1,-1,L12);
                code.visitLabel(L9);
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Ljava/io/File;");
                code.visitFieldStmt(IGET_OBJECT,4,7,new Field("Lorg/mortbay/resource/FileResource;","_file","Ljava/io/File;"));
                code.visitStmt3R(AGET_OBJECT,5,2,0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3,4,5},new Method("Ljava/io/File;","<init>",new String[]{ "Ljava/io/File;","Ljava/lang/String;"},"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/io/File;","isDirectory",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,3);
                DexLabel L15=new DexLabel();
                code.visitJumpStmt(IF_EQZ,3,-1,L15);
                code.visitStmt3R(AGET_OBJECT,3,2,0);
                code.visitConstStmt(CONST_STRING,4,"/");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,6},new Method("Ljava/lang/String;","endsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_NEZ,3,-1,L15);
                code.visitLabel(L10);
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitStmt3R(AGET_OBJECT,4,2,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitConstStmt(CONST_STRING,4,"/");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,6},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitStmt3R(APUT_OBJECT,3,2,0);
                code.visitStmt2R(MOVE,1,0);
                code.visitLabel(L11);
                code.visitJumpStmt(GOTO,-1,-1,L7);
                code.visitLabel(L12);
                code.visitStmt2R(MOVE_OBJECT,3,2);
                code.visitLabel(L13);
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitLabel(L15);
                code.visitStmt2R(MOVE,1,0);
                code.visitLabel(L14);
                code.visitJumpStmt(GOTO,-1,-1,L7);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m020_renameTo(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/resource/FileResource;","renameTo",new String[]{ "Lorg/mortbay/resource/Resource;"},"Z"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/SecurityException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"dest");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(303,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(304,L1);
                DexLabel L2=new DexLabel();
                ddv.visitEndLocal(3,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(306,L3);
                DexLabel L4=new DexLabel();
                ddv.visitRestartLocal(3,L4);
                code.visitLabel(L0);
                code.visitTypeStmt(INSTANCE_OF,0,3,"Lorg/mortbay/resource/FileResource;");
                code.visitJumpStmt(IF_EQZ,0,-1,L4);
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/resource/FileResource;","_file","Ljava/io/File;"));
                code.visitTypeStmt(CHECK_CAST,3,-1,"Lorg/mortbay/resource/FileResource;");
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/resource/FileResource;","_file","Ljava/io/File;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/io/File;","renameTo",new String[]{ "Ljava/io/File;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitLabel(L3);
                code.visitStmt1R(RETURN,0);
                code.visitLabel(L4);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
