package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0100_org_mortbay_ijetty_console_User {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/ijetty/console/User;","Ljava/lang/Object;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("User.java");
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/MemberClasses;", Visibility.SYSTEM);
            if(av00 != null) {
                {
                    DexAnnotationVisitor av01 = av00.visitArray("value");
                    if(av01 != null) {
                        av01.visit(null, new DexType("Lorg/mortbay/ijetty/console/User$UserCollection;"));
                        av01.visitEnd();
                    }
                }
                av00.visitEnd();
            }
        }
        f000_baseProjection(cv);
        m000__clinit_(cv);
        m001__init_(cv);
        m002_create(cv);
        m003_cursorToUserValues(cv);
        m004_delete(cv);
        m005_get(cv);
        m006_getAll(cv);
        m007_save(cv);
        m008_savePhoto(cv);
    }
    public static void f000_baseProjection(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/ijetty/console/User;","baseProjection","[Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__clinit_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/ijetty/console/User;","<clinit>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(58,L0);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(6)); // int: 0x00000006  float:0.000000
                code.visitTypeStmt(NEW_ARRAY,0,0,"[Ljava/lang/String;");
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitConstStmt(CONST_STRING,2,"_id");
                code.visitStmt3R(APUT_OBJECT,2,0,1);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitConstStmt(CONST_STRING,2,"display_name");
                code.visitStmt3R(APUT_OBJECT,2,0,1);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitConstStmt(CONST_STRING,2,"notes");
                code.visitStmt3R(APUT_OBJECT,2,0,1);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(3)); // int: 0x00000003  float:0.000000
                code.visitConstStmt(CONST_STRING,2,"starred");
                code.visitStmt3R(APUT_OBJECT,2,0,1);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(4)); // int: 0x00000004  float:0.000000
                code.visitConstStmt(CONST_STRING,2,"send_to_voicemail");
                code.visitStmt3R(APUT_OBJECT,2,0,1);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(5)); // int: 0x00000005  float:0.000000
                code.visitConstStmt(CONST_STRING,2,"custom_ringtone");
                code.visitStmt3R(APUT_OBJECT,2,0,1);
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/ijetty/console/User;","baseProjection","[Ljava/lang/String;"));
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/ijetty/console/User;","<init>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(33,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(41,L1);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/Object;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_create(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/ijetty/console/User;","create",new String[]{ "Landroid/content/ContentResolver;","Landroid/content/ContentValues;"},"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"resolver");
                ddv.visitParameterName(1,"values");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(83,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(89,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(85,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(87,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(89,L5);
                ddv.visitStartLocal(0,L5,"uri","Landroid/net/Uri;",null);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitJumpStmt(IF_NEZ,3,-1,L3);
                code.visitLabel(L2);
                code.visitStmt1R(RETURN_OBJECT,1);
                code.visitLabel(L3);
                code.visitJumpStmt(IF_EQZ,4,-1,L2);
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3,4},new Method("Landroid/provider/Contacts$People;","createPersonInMyContactsGroup",new String[]{ "Landroid/content/ContentResolver;","Landroid/content/ContentValues;"},"Landroid/net/Uri;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Landroid/content/ContentUris;","parseId",new String[]{ "Landroid/net/Uri;"},"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,1);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1,2},new Method("Ljava/lang/String;","valueOf",new String[]{ "J"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_cursorToUserValues(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/ijetty/console/User;","cursorToUserValues",new String[]{ "Landroid/database/Cursor;"},"Landroid/content/ContentValues;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(10);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"cursor");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(199,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(200,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(221,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(202,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(204,L5);
                ddv.visitStartLocal(2,L5,"values","Landroid/content/ContentValues;",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(205,L6);
                ddv.visitStartLocal(1,L6,"val","Ljava/lang/String;",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(207,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(208,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(210,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(211,L10);
                ddv.visitStartLocal(0,L10,"intVal","Ljava/lang/Integer;",null);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(213,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(214,L12);
                ddv.visitRestartLocal(1,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(216,L13);
                DexLabel L14=new DexLabel();
                ddv.visitEndLocal(0,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(217,L15);
                ddv.visitRestartLocal(0,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(219,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(220,L17);
                ddv.visitRestartLocal(1,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(221,L18);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_STRING,8,"send_to_voicemail");
                code.visitConstStmt(CONST_STRING,7,"notes");
                code.visitConstStmt(CONST_STRING,6,"display_name");
                code.visitConstStmt(CONST_STRING,5,"custom_ringtone");
                code.visitConstStmt(CONST_STRING,4,"_id");
                code.visitLabel(L1);
                code.visitJumpStmt(IF_NEZ,9,-1,L4);
                code.visitLabel(L2);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L3);
                code.visitStmt1R(RETURN_OBJECT,3);
                code.visitLabel(L4);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Landroid/content/ContentValues;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2},new Method("Landroid/content/ContentValues;","<init>",new String[]{ },"V"));
                code.visitLabel(L5);
                code.visitConstStmt(CONST_STRING,3,"_id");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 9,4},new Method("Landroid/database/Cursor;","getColumnIndex",new String[]{ "Ljava/lang/String;"},"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 9,3},new Method("Landroid/database/Cursor;","getString",new String[]{ "I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L6);
                code.visitConstStmt(CONST_STRING,3,"_id");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,4,1},new Method("Landroid/content/ContentValues;","put",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"V"));
                code.visitLabel(L7);
                code.visitConstStmt(CONST_STRING,3,"display_name");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 9,6},new Method("Landroid/database/Cursor;","getColumnIndex",new String[]{ "Ljava/lang/String;"},"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 9,3},new Method("Landroid/database/Cursor;","getString",new String[]{ "I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L8);
                code.visitConstStmt(CONST_STRING,3,"display_name");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,6,1},new Method("Landroid/content/ContentValues;","put",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"V"));
                code.visitLabel(L9);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/Integer;");
                code.visitConstStmt(CONST_STRING,3,"starred");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 9,3},new Method("Landroid/database/Cursor;","getColumnIndex",new String[]{ "Ljava/lang/String;"},"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 9,3},new Method("Landroid/database/Cursor;","getInt",new String[]{ "I"},"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,3},new Method("Ljava/lang/Integer;","<init>",new String[]{ "I"},"V"));
                code.visitLabel(L10);
                code.visitConstStmt(CONST_STRING,3,"starred");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3,0},new Method("Landroid/content/ContentValues;","put",new String[]{ "Ljava/lang/String;","Ljava/lang/Integer;"},"V"));
                code.visitLabel(L11);
                code.visitConstStmt(CONST_STRING,3,"notes");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 9,7},new Method("Landroid/database/Cursor;","getColumnIndex",new String[]{ "Ljava/lang/String;"},"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 9,3},new Method("Landroid/database/Cursor;","getString",new String[]{ "I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L12);
                code.visitConstStmt(CONST_STRING,3,"notes");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,7,1},new Method("Landroid/content/ContentValues;","put",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"V"));
                code.visitLabel(L13);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/Integer;");
                code.visitLabel(L14);
                code.visitConstStmt(CONST_STRING,3,"send_to_voicemail");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 9,8},new Method("Landroid/database/Cursor;","getColumnIndex",new String[]{ "Ljava/lang/String;"},"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 9,3},new Method("Landroid/database/Cursor;","getInt",new String[]{ "I"},"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,3},new Method("Ljava/lang/Integer;","<init>",new String[]{ "I"},"V"));
                code.visitLabel(L15);
                code.visitConstStmt(CONST_STRING,3,"send_to_voicemail");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,8,0},new Method("Landroid/content/ContentValues;","put",new String[]{ "Ljava/lang/String;","Ljava/lang/Integer;"},"V"));
                code.visitLabel(L16);
                code.visitConstStmt(CONST_STRING,3,"custom_ringtone");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 9,5},new Method("Landroid/database/Cursor;","getColumnIndex",new String[]{ "Ljava/lang/String;"},"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 9,3},new Method("Landroid/database/Cursor;","getString",new String[]{ "I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L17);
                code.visitConstStmt(CONST_STRING,3,"custom_ringtone");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,5,1},new Method("Landroid/content/ContentValues;","put",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"V"));
                code.visitStmt2R(MOVE_OBJECT,3,2);
                code.visitLabel(L18);
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_delete(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/ijetty/console/User;","delete",new String[]{ "Landroid/content/ContentResolver;","Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"resolver");
                ddv.visitParameterName(1,"id");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(147,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(151,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(150,L3);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitJumpStmt(IF_NEZ,3,-1,L3);
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L3);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Landroid/provider/Contacts$People;","CONTENT_URI","Landroid/net/Uri;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,3},new Method("Landroid/net/Uri;","withAppendedPath",new String[]{ "Landroid/net/Uri;","Ljava/lang/String;"},"Landroid/net/Uri;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,0,1,1},new Method("Landroid/content/ContentResolver;","delete",new String[]{ "Landroid/net/Uri;","Ljava/lang/String;","[Ljava/lang/String;"},"I"));
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_get(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/ijetty/console/User;","get",new String[]{ "Landroid/content/ContentResolver;","Ljava/lang/String;"},"Landroid/content/ContentValues;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(10);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"resolver");
                ddv.visitParameterName(1,"id");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(181,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(182,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(191,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(184,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(185,L4);
                ddv.visitStartLocal(4,L4,"whereArgs","[Ljava/lang/String;",null);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(188,L5);
                ddv.visitStartLocal(6,L5,"cursor","Landroid/database/Cursor;",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(189,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(190,L7);
                ddv.visitStartLocal(7,L7,"values","Landroid/content/ContentValues;",null);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(191,L8);
                code.visitLabel(L0);
                code.visitJumpStmt(IF_NEZ,9,-1,L3);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L2);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitTypeStmt(NEW_ARRAY,4,0,"[Ljava/lang/String;");
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt3R(APUT_OBJECT,9,4,0);
                code.visitLabel(L4);
                code.visitFieldStmt(SGET_OBJECT,1,-1,new Field("Landroid/provider/Contacts$People;","CONTENT_URI","Landroid/net/Uri;"));
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/ijetty/console/User;","baseProjection","[Ljava/lang/String;"));
                code.visitConstStmt(CONST_STRING,3,"people._id = ?");
                code.visitConstStmt(CONST_STRING,5,"name ASC");
                code.visitStmt2R(MOVE_OBJECT,0,8);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 0,1,2,3,4,5},new Method("Landroid/content/ContentResolver;","query",new String[]{ "Landroid/net/Uri;","[Ljava/lang/String;","Ljava/lang/String;","[Ljava/lang/String;","Ljava/lang/String;"},"Landroid/database/Cursor;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 6},new Method("Landroid/database/Cursor;","moveToFirst",new String[]{ },"Z"));
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 6},new Method("Lorg/mortbay/ijetty/console/User;","cursorToUserValues",new String[]{ "Landroid/database/Cursor;"},"Landroid/content/ContentValues;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 6},new Method("Landroid/database/Cursor;","close",new String[]{ },"V"));
                code.visitStmt2R(MOVE_OBJECT,0,7);
                code.visitLabel(L8);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_getAll(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/ijetty/console/User;","getAll",new String[]{ "Landroid/content/ContentResolver;"},"Lorg/mortbay/ijetty/console/User$UserCollection;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(8);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"resolver");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(165,L1);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,6,-1,"Lorg/mortbay/ijetty/console/User$UserCollection;");
                code.visitFieldStmt(SGET_OBJECT,1,-1,new Field("Landroid/provider/Contacts$People;","CONTENT_URI","Landroid/net/Uri;"));
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/ijetty/console/User;","baseProjection","[Ljava/lang/String;"));
                code.visitStmt2R(MOVE_OBJECT,0,7);
                code.visitStmt2R(MOVE_OBJECT,4,3);
                code.visitStmt2R(MOVE_OBJECT,5,3);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 0,1,2,3,4,5},new Method("Landroid/content/ContentResolver;","query",new String[]{ "Landroid/net/Uri;","[Ljava/lang/String;","Ljava/lang/String;","[Ljava/lang/String;","Ljava/lang/String;"},"Landroid/database/Cursor;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 6,0},new Method("Lorg/mortbay/ijetty/console/User$UserCollection;","<init>",new String[]{ "Landroid/database/Cursor;"},"V"));
                code.visitStmt1R(RETURN_OBJECT,6);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m007_save(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/ijetty/console/User;","save",new String[]{ "Landroid/content/ContentResolver;","Landroid/content/ContentValues;","Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"resolver");
                ddv.visitParameterName(1,"values");
                ddv.visitParameterName(2,"id");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(125,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(133,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(127,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(129,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(131,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(132,L6);
                ddv.visitStartLocal(0,L6,"uri","Landroid/net/Uri;",null);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitJumpStmt(IF_NEZ,3,-1,L3);
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L3);
                code.visitJumpStmt(IF_EQZ,4,-1,L2);
                code.visitLabel(L4);
                code.visitJumpStmt(IF_EQZ,5,-1,L2);
                code.visitLabel(L5);
                code.visitFieldStmt(SGET_OBJECT,1,-1,new Field("Landroid/provider/Contacts$People;","CONTENT_URI","Landroid/net/Uri;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1,5},new Method("Landroid/net/Uri;","withAppendedPath",new String[]{ "Landroid/net/Uri;","Ljava/lang/String;"},"Landroid/net/Uri;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,0,4,2,2},new Method("Landroid/content/ContentResolver;","update",new String[]{ "Landroid/net/Uri;","Landroid/content/ContentValues;","Ljava/lang/String;","[Ljava/lang/String;"},"I"));
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m008_savePhoto(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/ijetty/console/User;","savePhoto",new String[]{ "Landroid/content/ContentResolver;","Ljava/lang/String;","Ljava/io/File;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(9);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/lang/Exception;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"resolver");
                ddv.visitParameterName(1,"id");
                ddv.visitParameterName(2,"photo");
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(95,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(112,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(97,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(99,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(101,L7);
                ddv.visitLineNumber(104,L0);
                ddv.visitStartLocal(2,L0,"uri","Landroid/net/Uri;",null);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(105,L8);
                ddv.visitStartLocal(1,L8,"out","Ljava/io/ByteArrayOutputStream;",null);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(106,L9);
                ddv.visitLineNumber(108,L2);
                ddv.visitEndLocal(1,L2);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(110,L10);
                ddv.visitStartLocal(0,L10,"e","Ljava/lang/Exception;",null);
                code.visitLabel(L3);
                code.visitJumpStmt(IF_NEZ,6,-1,L5);
                code.visitLabel(L4);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L5);
                code.visitJumpStmt(IF_EQZ,8,-1,L4);
                code.visitLabel(L6);
                code.visitJumpStmt(IF_EQZ,7,-1,L4);
                code.visitLabel(L7);
                code.visitFieldStmt(SGET_OBJECT,3,-1,new Field("Landroid/provider/Contacts$People;","CONTENT_URI","Landroid/net/Uri;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3,7},new Method("Landroid/net/Uri;","withAppendedPath",new String[]{ "Landroid/net/Uri;","Ljava/lang/String;"},"Landroid/net/Uri;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/io/ByteArrayOutputStream;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljava/io/ByteArrayOutputStream;","<init>",new String[]{ },"V"));
                code.visitLabel(L8);
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Ljava/io/FileInputStream;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3,8},new Method("Ljava/io/FileInputStream;","<init>",new String[]{ "Ljava/io/File;"},"V"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3,1},new Method("Lorg/mortbay/util/IO;","copy",new String[]{ "Ljava/io/InputStream;","Ljava/io/OutputStream;"},"V"));
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/io/ByteArrayOutputStream;","toByteArray",new String[]{ },"[B"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 6,2,3},new Method("Landroid/provider/Contacts$People;","setPhotoData",new String[]{ "Landroid/content/ContentResolver;","Landroid/net/Uri;","[B"},"V"));
                code.visitLabel(L1);
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,3);
                code.visitStmt2R(MOVE_OBJECT,0,3);
                code.visitLabel(L10);
                code.visitConstStmt(CONST_STRING,3,"Jetty");
                code.visitTypeStmt(NEW_INSTANCE,4,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,5,"Problem converting photo to bytes for ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Ljava/io/File;","getAbsolutePath",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3,4,0},new Method("Landroid/util/Log;","e",new String[]{ "Ljava/lang/String;","Ljava/lang/String;","Ljava/lang/Throwable;"},"I"));
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
