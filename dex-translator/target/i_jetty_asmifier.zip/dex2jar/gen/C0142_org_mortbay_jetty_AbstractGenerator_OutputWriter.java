package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0142_org_mortbay_jetty_AbstractGenerator_OutputWriter {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/jetty/AbstractGenerator$OutputWriter;","Ljava/io/Writer;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("AbstractGenerator.java");
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/EnclosingClass;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("value", new DexType("Lorg/mortbay/jetty/AbstractGenerator;"));
                av00.visitEnd();
            }
        }
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/InnerClass;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("accessFlags",  Integer.valueOf(9));
                av00.visit("name", "OutputWriter");
                av00.visitEnd();
            }
        }
        f000_WRITE_CONV(cv);
        f001_WRITE_ISO1(cv);
        f002_WRITE_UTF8(cv);
        f003__generator(cv);
        f004__out(cv);
        f005__surrogate(cv);
        f006__writeMode(cv);
        m000__init_(cv);
        m001_getConverter(cv);
        m002_close(cv);
        m003_flush(cv);
        m004_setCharacterEncoding(cv);
        m005_write(cv);
        m006_write(cv);
    }
    public static void f000_WRITE_CONV(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/AbstractGenerator$OutputWriter;","WRITE_CONV","I"),  Integer.valueOf(0));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001_WRITE_ISO1(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/AbstractGenerator$OutputWriter;","WRITE_ISO1","I"),  Integer.valueOf(1));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002_WRITE_UTF8(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/AbstractGenerator$OutputWriter;","WRITE_UTF8","I"),  Integer.valueOf(2));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003__generator(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/jetty/AbstractGenerator$OutputWriter;","_generator","Lorg/mortbay/jetty/AbstractGenerator;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f004__out(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/jetty/AbstractGenerator$OutputWriter;","_out","Lorg/mortbay/jetty/AbstractGenerator$Output;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f005__surrogate(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/jetty/AbstractGenerator$OutputWriter;","_surrogate","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f006__writeMode(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/jetty/AbstractGenerator$OutputWriter;","_writeMode","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/AbstractGenerator$OutputWriter;","<init>",new String[]{ "Lorg/mortbay/jetty/AbstractGenerator$Output;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"out");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(695,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(696,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(697,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(699,L3);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljava/io/Writer;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitFieldStmt(IPUT_OBJECT,2,1,new Field("Lorg/mortbay/jetty/AbstractGenerator$OutputWriter;","_out","Lorg/mortbay/jetty/AbstractGenerator$Output;"));
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/AbstractGenerator$OutputWriter;","_out","Lorg/mortbay/jetty/AbstractGenerator$Output;"));
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/AbstractGenerator$Output;","_generator","Lorg/mortbay/jetty/AbstractGenerator;"));
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/AbstractGenerator$OutputWriter;","_generator","Lorg/mortbay/jetty/AbstractGenerator;"));
                code.visitLabel(L3);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001_getConverter(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PRIVATE, new Method("Lorg/mortbay/jetty/AbstractGenerator$OutputWriter;","getConverter",new String[]{ },"Ljava/io/Writer;"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(912,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(913,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(914,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/jetty/AbstractGenerator$OutputWriter;","_out","Lorg/mortbay/jetty/AbstractGenerator$Output;"));
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/AbstractGenerator$Output;","_converter","Ljava/io/Writer;"));
                code.visitJumpStmt(IF_NEZ,0,-1,L2);
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/jetty/AbstractGenerator$OutputWriter;","_out","Lorg/mortbay/jetty/AbstractGenerator$Output;"));
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/io/OutputStreamWriter;");
                code.visitFieldStmt(IGET_OBJECT,2,4,new Field("Lorg/mortbay/jetty/AbstractGenerator$OutputWriter;","_out","Lorg/mortbay/jetty/AbstractGenerator$Output;"));
                code.visitFieldStmt(IGET_OBJECT,2,2,new Field("Lorg/mortbay/jetty/AbstractGenerator$Output;","_bytes","Lorg/mortbay/util/ByteArrayOutputStream2;"));
                code.visitFieldStmt(IGET_OBJECT,3,4,new Field("Lorg/mortbay/jetty/AbstractGenerator$OutputWriter;","_out","Lorg/mortbay/jetty/AbstractGenerator$Output;"));
                code.visitFieldStmt(IGET_OBJECT,3,3,new Field("Lorg/mortbay/jetty/AbstractGenerator$Output;","_characterEncoding","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,2,3},new Method("Ljava/io/OutputStreamWriter;","<init>",new String[]{ "Ljava/io/OutputStream;","Ljava/lang/String;"},"V"));
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/AbstractGenerator$Output;","_converter","Ljava/io/Writer;"));
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/jetty/AbstractGenerator$OutputWriter;","_out","Lorg/mortbay/jetty/AbstractGenerator$Output;"));
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/AbstractGenerator$Output;","_converter","Ljava/io/Writer;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_close(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/AbstractGenerator$OutputWriter;","close",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(727,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(728,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/AbstractGenerator$OutputWriter;","_out","Lorg/mortbay/jetty/AbstractGenerator$Output;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/AbstractGenerator$Output;","close",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_flush(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/AbstractGenerator$OutputWriter;","flush",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(733,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(734,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/AbstractGenerator$OutputWriter;","_out","Lorg/mortbay/jetty/AbstractGenerator$Output;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/AbstractGenerator$Output;","flush",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_setCharacterEncoding(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/AbstractGenerator$OutputWriter;","setCharacterEncoding",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"encoding");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(704,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(706,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(719,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(720,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(721,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(722,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(708,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(710,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(714,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(715,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(716,L10);
                code.visitLabel(L0);
                code.visitJumpStmt(IF_EQZ,4,-1,L1);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/util/StringUtil;","__ISO_8859_1","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,4},new Method("Ljava/lang/String;","equalsIgnoreCase",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L6);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitFieldStmt(IPUT,0,3,new Field("Lorg/mortbay/jetty/AbstractGenerator$OutputWriter;","_writeMode","I"));
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/jetty/AbstractGenerator$OutputWriter;","_out","Lorg/mortbay/jetty/AbstractGenerator$Output;"));
                code.visitFieldStmt(IPUT_OBJECT,4,0,new Field("Lorg/mortbay/jetty/AbstractGenerator$Output;","_characterEncoding","Ljava/lang/String;"));
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/jetty/AbstractGenerator$OutputWriter;","_out","Lorg/mortbay/jetty/AbstractGenerator$Output;"));
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/AbstractGenerator$Output;","_bytes","Lorg/mortbay/util/ByteArrayOutputStream2;"));
                code.visitJumpStmt(IF_NEZ,0,-1,L5);
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/jetty/AbstractGenerator$OutputWriter;","_out","Lorg/mortbay/jetty/AbstractGenerator$Output;"));
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Lorg/mortbay/util/ByteArrayOutputStream2;");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/jetty/AbstractGenerator;","access$100",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,2},new Method("Lorg/mortbay/util/ByteArrayOutputStream2;","<init>",new String[]{ "I"},"V"));
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/AbstractGenerator$Output;","_bytes","Lorg/mortbay/util/ByteArrayOutputStream2;"));
                code.visitLabel(L5);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L6);
                code.visitConstStmt(CONST_STRING,0,"UTF-8");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,4},new Method("Ljava/lang/String;","equalsIgnoreCase",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L8);
                code.visitLabel(L7);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitFieldStmt(IPUT,0,3,new Field("Lorg/mortbay/jetty/AbstractGenerator$OutputWriter;","_writeMode","I"));
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L8);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT,0,3,new Field("Lorg/mortbay/jetty/AbstractGenerator$OutputWriter;","_writeMode","I"));
                code.visitLabel(L9);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/jetty/AbstractGenerator$OutputWriter;","_out","Lorg/mortbay/jetty/AbstractGenerator$Output;"));
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/AbstractGenerator$Output;","_characterEncoding","Ljava/lang/String;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L10);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/jetty/AbstractGenerator$OutputWriter;","_out","Lorg/mortbay/jetty/AbstractGenerator$Output;"));
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/AbstractGenerator$Output;","_characterEncoding","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,4},new Method("Ljava/lang/String;","equalsIgnoreCase",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_NEZ,0,-1,L2);
                code.visitLabel(L10);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/jetty/AbstractGenerator$OutputWriter;","_out","Lorg/mortbay/jetty/AbstractGenerator$Output;"));
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/AbstractGenerator$Output;","_converter","Ljava/io/Writer;"));
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_write(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/AbstractGenerator$OutputWriter;","write",new String[]{ "Ljava/lang/String;","I","I"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(8);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"s");
                ddv.visitParameterName(1,"offset");
                ddv.visitParameterName(2,"length");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(739,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(741,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(742,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(743,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(746,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(748,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(750,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(751,L8);
                ddv.visitStartLocal(0,L8,"chars","[C",null);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(752,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(753,L10);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/jetty/AbstractGenerator;","access$100",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_LE,7,1,L5);
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/jetty/AbstractGenerator;","access$100",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5,6,1},new Method("Lorg/mortbay/jetty/AbstractGenerator$OutputWriter;","write",new String[]{ "Ljava/lang/String;","I","I"},"V"));
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/jetty/AbstractGenerator;","access$100",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitStmt2R(ADD_INT_2ADDR,6,1);
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/jetty/AbstractGenerator;","access$100",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitStmt2R(SUB_INT_2ADDR,7,1);
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/jetty/AbstractGenerator$OutputWriter;","_out","Lorg/mortbay/jetty/AbstractGenerator$Output;"));
                code.visitFieldStmt(IGET_OBJECT,1,1,new Field("Lorg/mortbay/jetty/AbstractGenerator$Output;","_chars","[C"));
                code.visitJumpStmt(IF_NEZ,1,-1,L7);
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/jetty/AbstractGenerator$OutputWriter;","_out","Lorg/mortbay/jetty/AbstractGenerator$Output;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/jetty/AbstractGenerator;","access$100",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitTypeStmt(NEW_ARRAY,2,2,"[C");
                code.visitFieldStmt(IPUT_OBJECT,2,1,new Field("Lorg/mortbay/jetty/AbstractGenerator$Output;","_chars","[C"));
                code.visitLabel(L7);
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/jetty/AbstractGenerator$OutputWriter;","_out","Lorg/mortbay/jetty/AbstractGenerator$Output;"));
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/AbstractGenerator$Output;","_chars","[C"));
                code.visitLabel(L8);
                code.visitStmt3R(ADD_INT,1,6,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6,1,0,3},new Method("Ljava/lang/String;","getChars",new String[]{ "I","I","[C","I"},"V"));
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,0,3,7},new Method("Lorg/mortbay/jetty/AbstractGenerator$OutputWriter;","write",new String[]{ "[C","I","I"},"V"));
                code.visitLabel(L10);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_write(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/AbstractGenerator$OutputWriter;","write",new String[]{ "[C","I","I"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(15);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"s");
                ddv.visitParameterName(1,"offset");
                ddv.visitParameterName(2,"length");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(758,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(760,L1);
                ddv.visitStartLocal(8,L1,"out","Lorg/mortbay/jetty/AbstractGenerator$Output;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(762,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(763,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(765,L4);
                ddv.visitStartLocal(4,L4,"chars","I",null);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(900,L5);
                DexLabel L6=new DexLabel();
                ddv.visitEndLocal(4,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(763,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(769,L8);
                ddv.visitRestartLocal(4,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(770,L9);
                ddv.visitStartLocal(6,L9,"converter","Ljava/io/Writer;",null);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(771,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(903,L11);
                ddv.visitEndLocal(6,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(904,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(905,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(906,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(777,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(778,L16);
                ddv.visitStartLocal(0,L16,"buffer","[B",null);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(780,L17);
                ddv.visitStartLocal(1,L17,"bytes","I",null);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(781,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(783,L19);
                DexLabel L20=new DexLabel();
                ddv.visitStartLocal(7,L20,"i","I",null);
                DexLabel L21=new DexLabel();
                ddv.visitEndLocal(1,L21);
                ddv.visitStartLocal(2,L21,"bytes","I",null);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(785,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(786,L23);
                ddv.visitStartLocal(3,L23,"c","I",null);
                DexLabel L24=new DexLabel();
                ddv.visitRestartLocal(1,L24);
                DexLabel L25=new DexLabel();
                ddv.visitEndLocal(2,L25);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(783,L26);
                DexLabel L27=new DexLabel();
                ddv.visitRestartLocal(2,L27);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(786,L28);
                ddv.visitEndLocal(2,L28);
                DexLabel L29=new DexLabel();
                ddv.visitLineNumber(788,L29);
                ddv.visitEndLocal(3,L29);
                ddv.visitEndLocal(1,L29);
                ddv.visitRestartLocal(2,L29);
                DexLabel L30=new DexLabel();
                ddv.visitLineNumber(789,L30);
                DexLabel L31=new DexLabel();
                ddv.visitLineNumber(796,L31);
                ddv.visitEndLocal(0,L31);
                ddv.visitEndLocal(7,L31);
                ddv.visitEndLocal(2,L31);
                DexLabel L32=new DexLabel();
                ddv.visitLineNumber(797,L32);
                ddv.visitRestartLocal(0,L32);
                DexLabel L33=new DexLabel();
                ddv.visitLineNumber(799,L33);
                ddv.visitRestartLocal(1,L33);
                DexLabel L34=new DexLabel();
                ddv.visitLineNumber(800,L34);
                DexLabel L35=new DexLabel();
                ddv.visitLineNumber(802,L35);
                DexLabel L36=new DexLabel();
                ddv.visitRestartLocal(7,L36);
                DexLabel L37=new DexLabel();
                ddv.visitEndLocal(1,L37);
                ddv.visitRestartLocal(2,L37);
                DexLabel L38=new DexLabel();
                ddv.visitLineNumber(804,L38);
                DexLabel L39=new DexLabel();
                ddv.visitLineNumber(806,L39);
                ddv.visitStartLocal(5,L39,"code","I",null);
                DexLabel L40=new DexLabel();
                ddv.visitLineNumber(809,L40);
                DexLabel L41=new DexLabel();
                ddv.visitRestartLocal(1,L41);
                DexLabel L42=new DexLabel();
                ddv.visitLineNumber(802,L42);
                ddv.visitEndLocal(2,L42);
                DexLabel L43=new DexLabel();
                ddv.visitRestartLocal(2,L43);
                DexLabel L44=new DexLabel();
                ddv.visitLineNumber(811,L44);
                ddv.visitEndLocal(1,L44);
                DexLabel L45=new DexLabel();
                ddv.visitLineNumber(814,L45);
                DexLabel L46=new DexLabel();
                ddv.visitLineNumber(816,L46);
                DexLabel L47=new DexLabel();
                ddv.visitLineNumber(896,L47);
                ddv.visitEndLocal(5,L47);
                DexLabel L48=new DexLabel();
                ddv.visitLineNumber(819,L48);
                ddv.visitRestartLocal(5,L48);
                DexLabel L49=new DexLabel();
                ddv.visitRestartLocal(1,L49);
                DexLabel L50=new DexLabel();
                ddv.visitLineNumber(820,L50);
                ddv.visitEndLocal(2,L50);
                DexLabel L51=new DexLabel();
                ddv.visitRestartLocal(2,L51);
                DexLabel L52=new DexLabel();
                ddv.visitLineNumber(822,L52);
                ddv.visitEndLocal(1,L52);
                DexLabel L53=new DexLabel();
                ddv.visitLineNumber(823,L53);
                DexLabel L54=new DexLabel();
                ddv.visitRestartLocal(1,L54);
                DexLabel L55=new DexLabel();
                ddv.visitLineNumber(825,L55);
                ddv.visitEndLocal(1,L55);
                DexLabel L56=new DexLabel();
                ddv.visitLineNumber(828,L56);
                DexLabel L57=new DexLabel();
                ddv.visitLineNumber(830,L57);
                DexLabel L58=new DexLabel();
                ddv.visitLineNumber(831,L58);
                DexLabel L59=new DexLabel();
                ddv.visitLineNumber(833,L59);
                DexLabel L60=new DexLabel();
                ddv.visitRestartLocal(1,L60);
                DexLabel L61=new DexLabel();
                ddv.visitLineNumber(834,L61);
                ddv.visitEndLocal(2,L61);
                DexLabel L62=new DexLabel();
                ddv.visitRestartLocal(2,L62);
                DexLabel L63=new DexLabel();
                ddv.visitLineNumber(835,L63);
                ddv.visitEndLocal(1,L63);
                DexLabel L64=new DexLabel();
                ddv.visitRestartLocal(1,L64);
                DexLabel L65=new DexLabel();
                ddv.visitLineNumber(837,L65);
                ddv.visitEndLocal(2,L65);
                DexLabel L66=new DexLabel();
                ddv.visitLineNumber(838,L66);
                DexLabel L67=new DexLabel();
                ddv.visitLineNumber(840,L67);
                ddv.visitEndLocal(1,L67);
                ddv.visitRestartLocal(2,L67);
                DexLabel L68=new DexLabel();
                ddv.visitLineNumber(843,L68);
                DexLabel L69=new DexLabel();
                ddv.visitLineNumber(845,L69);
                DexLabel L70=new DexLabel();
                ddv.visitLineNumber(846,L70);
                DexLabel L71=new DexLabel();
                ddv.visitLineNumber(848,L71);
                DexLabel L72=new DexLabel();
                ddv.visitRestartLocal(1,L72);
                DexLabel L73=new DexLabel();
                ddv.visitLineNumber(849,L73);
                ddv.visitEndLocal(2,L73);
                DexLabel L74=new DexLabel();
                ddv.visitRestartLocal(2,L74);
                DexLabel L75=new DexLabel();
                ddv.visitLineNumber(850,L75);
                ddv.visitEndLocal(1,L75);
                DexLabel L76=new DexLabel();
                ddv.visitRestartLocal(1,L76);
                DexLabel L77=new DexLabel();
                ddv.visitLineNumber(851,L77);
                ddv.visitEndLocal(2,L77);
                DexLabel L78=new DexLabel();
                ddv.visitRestartLocal(2,L78);
                DexLabel L79=new DexLabel();
                ddv.visitLineNumber(853,L79);
                ddv.visitEndLocal(1,L79);
                DexLabel L80=new DexLabel();
                ddv.visitLineNumber(854,L80);
                DexLabel L81=new DexLabel();
                ddv.visitRestartLocal(1,L81);
                DexLabel L82=new DexLabel();
                ddv.visitLineNumber(856,L82);
                ddv.visitEndLocal(1,L82);
                DexLabel L83=new DexLabel();
                ddv.visitLineNumber(859,L83);
                DexLabel L84=new DexLabel();
                ddv.visitLineNumber(861,L84);
                DexLabel L85=new DexLabel();
                ddv.visitLineNumber(862,L85);
                DexLabel L86=new DexLabel();
                ddv.visitLineNumber(864,L86);
                DexLabel L87=new DexLabel();
                ddv.visitRestartLocal(1,L87);
                DexLabel L88=new DexLabel();
                ddv.visitLineNumber(865,L88);
                ddv.visitEndLocal(2,L88);
                DexLabel L89=new DexLabel();
                ddv.visitRestartLocal(2,L89);
                DexLabel L90=new DexLabel();
                ddv.visitLineNumber(866,L90);
                ddv.visitEndLocal(1,L90);
                DexLabel L91=new DexLabel();
                ddv.visitRestartLocal(1,L91);
                DexLabel L92=new DexLabel();
                ddv.visitLineNumber(867,L92);
                ddv.visitEndLocal(2,L92);
                DexLabel L93=new DexLabel();
                ddv.visitRestartLocal(2,L93);
                DexLabel L94=new DexLabel();
                ddv.visitLineNumber(868,L94);
                ddv.visitEndLocal(1,L94);
                DexLabel L95=new DexLabel();
                ddv.visitRestartLocal(1,L95);
                DexLabel L96=new DexLabel();
                ddv.visitLineNumber(870,L96);
                ddv.visitEndLocal(2,L96);
                DexLabel L97=new DexLabel();
                ddv.visitLineNumber(871,L97);
                DexLabel L98=new DexLabel();
                ddv.visitLineNumber(873,L98);
                ddv.visitEndLocal(1,L98);
                ddv.visitRestartLocal(2,L98);
                DexLabel L99=new DexLabel();
                ddv.visitLineNumber(876,L99);
                DexLabel L100=new DexLabel();
                ddv.visitLineNumber(878,L100);
                DexLabel L101=new DexLabel();
                ddv.visitLineNumber(879,L101);
                DexLabel L102=new DexLabel();
                ddv.visitLineNumber(881,L102);
                DexLabel L103=new DexLabel();
                ddv.visitRestartLocal(1,L103);
                DexLabel L104=new DexLabel();
                ddv.visitLineNumber(882,L104);
                ddv.visitEndLocal(2,L104);
                DexLabel L105=new DexLabel();
                ddv.visitRestartLocal(2,L105);
                DexLabel L106=new DexLabel();
                ddv.visitLineNumber(883,L106);
                ddv.visitEndLocal(1,L106);
                DexLabel L107=new DexLabel();
                ddv.visitRestartLocal(1,L107);
                DexLabel L108=new DexLabel();
                ddv.visitLineNumber(884,L108);
                ddv.visitEndLocal(2,L108);
                DexLabel L109=new DexLabel();
                ddv.visitRestartLocal(2,L109);
                DexLabel L110=new DexLabel();
                ddv.visitLineNumber(885,L110);
                ddv.visitEndLocal(1,L110);
                DexLabel L111=new DexLabel();
                ddv.visitRestartLocal(1,L111);
                DexLabel L112=new DexLabel();
                ddv.visitLineNumber(886,L112);
                ddv.visitEndLocal(2,L112);
                DexLabel L113=new DexLabel();
                ddv.visitRestartLocal(2,L113);
                DexLabel L114=new DexLabel();
                ddv.visitLineNumber(888,L114);
                ddv.visitEndLocal(1,L114);
                DexLabel L115=new DexLabel();
                ddv.visitLineNumber(889,L115);
                DexLabel L116=new DexLabel();
                ddv.visitRestartLocal(1,L116);
                DexLabel L117=new DexLabel();
                ddv.visitLineNumber(893,L117);
                ddv.visitEndLocal(1,L117);
                DexLabel L118=new DexLabel();
                ddv.visitRestartLocal(1,L118);
                DexLabel L119=new DexLabel();
                ddv.visitLineNumber(907,L119);
                ddv.visitEndLocal(4,L119);
                ddv.visitEndLocal(0,L119);
                ddv.visitEndLocal(7,L119);
                ddv.visitEndLocal(5,L119);
                ddv.visitEndLocal(2,L119);
                ddv.visitEndLocal(1,L119);
                DexLabel L120=new DexLabel();
                ddv.visitRestartLocal(0,L120);
                ddv.visitRestartLocal(2,L120);
                ddv.visitRestartLocal(4,L120);
                ddv.visitRestartLocal(5,L120);
                ddv.visitRestartLocal(7,L120);
                DexLabel L121=new DexLabel();
                ddv.visitRestartLocal(1,L121);
                DexLabel L122=new DexLabel();
                ddv.visitLineNumber(765,L122);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,8,11,new Field("Lorg/mortbay/jetty/AbstractGenerator$OutputWriter;","_out","Lorg/mortbay/jetty/AbstractGenerator$Output;"));
                code.visitLabel(L1);
                code.visitJumpStmt(IF_LEZ,14,-1,L119);
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,9,8,new Field("Lorg/mortbay/jetty/AbstractGenerator$Output;","_bytes","Lorg/mortbay/util/ByteArrayOutputStream2;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9},new Method("Lorg/mortbay/util/ByteArrayOutputStream2;","reset",new String[]{ },"V"));
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/jetty/AbstractGenerator;","access$100",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,9);
                code.visitJumpStmt(IF_LE,14,9,L6);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/jetty/AbstractGenerator;","access$100",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,9);
                code.visitStmt2R(MOVE,4,9);
                code.visitLabel(L4);
                code.visitFieldStmt(IGET,9,11,new Field("Lorg/mortbay/jetty/AbstractGenerator$OutputWriter;","_writeMode","I"));
                code.visitSparseSwitchStmt(PACKED_SWITCH,9,0,new DexLabel[]{L8,L15,L31});
                code.visitLabel(L5);
                code.visitTypeStmt(NEW_INSTANCE,9,-1,"Ljava/lang/IllegalStateException;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 9},new Method("Ljava/lang/IllegalStateException;","<init>",new String[]{ },"V"));
                code.visitStmt1R(THROW,9);
                code.visitLabel(L6);
                code.visitStmt2R(MOVE,4,14);
                code.visitLabel(L7);
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 11},new Method("Lorg/mortbay/jetty/AbstractGenerator$OutputWriter;","getConverter",new String[]{ },"Ljava/io/Writer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,12,13,4},new Method("Ljava/io/Writer;","write",new String[]{ "[C","I","I"},"V"));
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/io/Writer;","flush",new String[]{ },"V"));
                code.visitLabel(L11);
                code.visitFieldStmt(IGET_OBJECT,9,8,new Field("Lorg/mortbay/jetty/AbstractGenerator$Output;","_bytes","Lorg/mortbay/util/ByteArrayOutputStream2;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9,8},new Method("Lorg/mortbay/util/ByteArrayOutputStream2;","writeTo",new String[]{ "Ljava/io/OutputStream;"},"V"));
                code.visitLabel(L12);
                code.visitStmt2R(SUB_INT_2ADDR,14,4);
                code.visitLabel(L13);
                code.visitStmt2R(ADD_INT_2ADDR,13,4);
                code.visitLabel(L14);
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitLabel(L15);
                code.visitFieldStmt(IGET_OBJECT,9,8,new Field("Lorg/mortbay/jetty/AbstractGenerator$Output;","_bytes","Lorg/mortbay/util/ByteArrayOutputStream2;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9},new Method("Lorg/mortbay/util/ByteArrayOutputStream2;","getBuf",new String[]{ },"[B"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L16);
                code.visitFieldStmt(IGET_OBJECT,9,8,new Field("Lorg/mortbay/jetty/AbstractGenerator$Output;","_bytes","Lorg/mortbay/util/ByteArrayOutputStream2;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9},new Method("Lorg/mortbay/util/ByteArrayOutputStream2;","getCount",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitLabel(L17);
                code.visitStmt2R(ARRAY_LENGTH,9,0);
                code.visitStmt2R(SUB_INT_2ADDR,9,1);
                code.visitJumpStmt(IF_LE,4,9,L19);
                code.visitLabel(L18);
                code.visitStmt2R(ARRAY_LENGTH,9,0);
                code.visitStmt3R(SUB_INT,4,9,1);
                code.visitLabel(L19);
                code.visitConstStmt(CONST_4,7, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L20);
                code.visitStmt2R(MOVE,2,1);
                code.visitLabel(L21);
                code.visitJumpStmt(IF_GE,7,4,L29);
                code.visitLabel(L22);
                code.visitStmt3R(ADD_INT,9,13,7);
                code.visitStmt3R(AGET_CHAR,3,12,9);
                code.visitLabel(L23);
                code.visitStmt2R1N(ADD_INT_LIT8,1,2,1);
                code.visitLabel(L24);
                code.visitConstStmt(CONST_16,9, Integer.valueOf(256)); // int: 0x00000100  float:0.000000
                code.visitJumpStmt(IF_GE,3,9,L28);
                code.visitLabel(L25);
                code.visitStmt2R(MOVE,9,3);
                DexLabel L123=new DexLabel();
                code.visitLabel(L123);
                code.visitStmt2R(INT_TO_BYTE,9,9);
                code.visitStmt3R(APUT_BYTE,9,0,2);
                code.visitLabel(L26);
                code.visitStmt2R1N(ADD_INT_LIT8,7,7,1);
                code.visitStmt2R(MOVE,2,1);
                code.visitLabel(L27);
                code.visitJumpStmt(GOTO,-1,-1,L21);
                code.visitLabel(L28);
                code.visitConstStmt(CONST_16,9, Integer.valueOf(63)); // int: 0x0000003f  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L123);
                code.visitLabel(L29);
                code.visitJumpStmt(IF_LTZ,2,-1,L11);
                code.visitLabel(L30);
                code.visitFieldStmt(IGET_OBJECT,9,8,new Field("Lorg/mortbay/jetty/AbstractGenerator$Output;","_bytes","Lorg/mortbay/util/ByteArrayOutputStream2;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9,2},new Method("Lorg/mortbay/util/ByteArrayOutputStream2;","setCount",new String[]{ "I"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L11);
                code.visitLabel(L31);
                code.visitFieldStmt(IGET_OBJECT,9,8,new Field("Lorg/mortbay/jetty/AbstractGenerator$Output;","_bytes","Lorg/mortbay/util/ByteArrayOutputStream2;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9},new Method("Lorg/mortbay/util/ByteArrayOutputStream2;","getBuf",new String[]{ },"[B"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L32);
                code.visitFieldStmt(IGET_OBJECT,9,8,new Field("Lorg/mortbay/jetty/AbstractGenerator$Output;","_bytes","Lorg/mortbay/util/ByteArrayOutputStream2;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9},new Method("Lorg/mortbay/util/ByteArrayOutputStream2;","getCount",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitLabel(L33);
                code.visitStmt3R(ADD_INT,9,1,4);
                code.visitStmt2R(ARRAY_LENGTH,10,0);
                code.visitJumpStmt(IF_LE,9,10,L35);
                code.visitLabel(L34);
                code.visitStmt2R(ARRAY_LENGTH,9,0);
                code.visitStmt3R(SUB_INT,4,9,1);
                code.visitLabel(L35);
                code.visitConstStmt(CONST_4,7, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L36);
                code.visitStmt2R(MOVE,2,1);
                code.visitLabel(L37);
                code.visitJumpStmt(IF_GE,7,4,L47);
                code.visitLabel(L38);
                code.visitStmt3R(ADD_INT,9,13,7);
                code.visitStmt3R(AGET_CHAR,5,12,9);
                code.visitLabel(L39);
                code.visitStmt2R1N(AND_INT_LIT8,9,5,-128);
                code.visitJumpStmt(IF_NEZ,9,-1,L44);
                code.visitLabel(L40);
                code.visitStmt2R1N(ADD_INT_LIT8,1,2,1);
                code.visitLabel(L41);
                code.visitStmt2R(INT_TO_BYTE,9,5);
                code.visitStmt3R(APUT_BYTE,9,0,2);
                code.visitLabel(L42);
                code.visitStmt2R1N(ADD_INT_LIT8,7,7,1);
                code.visitStmt2R(MOVE,2,1);
                code.visitLabel(L43);
                code.visitJumpStmt(GOTO,-1,-1,L37);
                code.visitLabel(L44);
                code.visitStmt2R1N(AND_INT_LIT16,9,5,-2048);
                code.visitJumpStmt(IF_NEZ,9,-1,L55);
                code.visitLabel(L45);
                code.visitStmt2R1N(ADD_INT_LIT8,9,2,2);
                code.visitStmt2R(ARRAY_LENGTH,10,0);
                code.visitJumpStmt(IF_LE,9,10,L48);
                code.visitLabel(L46);
                code.visitStmt2R(MOVE,4,7);
                code.visitLabel(L47);
                code.visitFieldStmt(IGET_OBJECT,9,8,new Field("Lorg/mortbay/jetty/AbstractGenerator$Output;","_bytes","Lorg/mortbay/util/ByteArrayOutputStream2;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9,2},new Method("Lorg/mortbay/util/ByteArrayOutputStream2;","setCount",new String[]{ "I"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L11);
                code.visitLabel(L48);
                code.visitStmt2R1N(ADD_INT_LIT8,1,2,1);
                code.visitLabel(L49);
                code.visitStmt2R1N(SHR_INT_LIT8,9,5,6);
                code.visitStmt2R1N(OR_INT_LIT16,9,9,192);
                code.visitStmt2R(INT_TO_BYTE,9,9);
                code.visitStmt3R(APUT_BYTE,9,0,2);
                code.visitLabel(L50);
                code.visitStmt2R1N(ADD_INT_LIT8,2,1,1);
                code.visitLabel(L51);
                code.visitStmt2R1N(AND_INT_LIT8,9,5,63);
                code.visitStmt2R1N(OR_INT_LIT16,9,9,128);
                code.visitStmt2R(INT_TO_BYTE,9,9);
                code.visitStmt3R(APUT_BYTE,9,0,1);
                code.visitLabel(L52);
                code.visitStmt3R(ADD_INT,9,2,4);
                code.visitStmt2R(SUB_INT_2ADDR,9,7);
                code.visitConstStmt(CONST_4,10, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt2R(SUB_INT_2ADDR,9,10);
                code.visitStmt2R(ARRAY_LENGTH,10,0);
                code.visitJumpStmt(IF_LE,9,10,L120);
                code.visitLabel(L53);
                code.visitStmt2R1N(ADD_INT_LIT8,4,4,-1);
                code.visitStmt2R(MOVE,1,2);
                code.visitLabel(L54);
                code.visitJumpStmt(GOTO,-1,-1,L42);
                code.visitLabel(L55);
                code.visitConstStmt(CONST_HIGH16,9, Integer.valueOf(-65536)); // int: 0xffff0000  float:NaN
                code.visitStmt2R(AND_INT_2ADDR,9,5);
                code.visitJumpStmt(IF_NEZ,9,-1,L67);
                code.visitLabel(L56);
                code.visitStmt2R1N(ADD_INT_LIT8,9,2,3);
                code.visitStmt2R(ARRAY_LENGTH,10,0);
                code.visitJumpStmt(IF_LE,9,10,L59);
                code.visitLabel(L57);
                code.visitStmt2R(MOVE,4,7);
                code.visitLabel(L58);
                code.visitJumpStmt(GOTO,-1,-1,L47);
                code.visitLabel(L59);
                code.visitStmt2R1N(ADD_INT_LIT8,1,2,1);
                code.visitLabel(L60);
                code.visitStmt2R1N(SHR_INT_LIT8,9,5,12);
                code.visitStmt2R1N(OR_INT_LIT16,9,9,224);
                code.visitStmt2R(INT_TO_BYTE,9,9);
                code.visitStmt3R(APUT_BYTE,9,0,2);
                code.visitLabel(L61);
                code.visitStmt2R1N(ADD_INT_LIT8,2,1,1);
                code.visitLabel(L62);
                code.visitStmt2R1N(SHR_INT_LIT8,9,5,6);
                code.visitStmt2R1N(AND_INT_LIT8,9,9,63);
                code.visitStmt2R1N(OR_INT_LIT16,9,9,128);
                code.visitStmt2R(INT_TO_BYTE,9,9);
                code.visitStmt3R(APUT_BYTE,9,0,1);
                code.visitLabel(L63);
                code.visitStmt2R1N(ADD_INT_LIT8,1,2,1);
                code.visitLabel(L64);
                code.visitStmt2R1N(AND_INT_LIT8,9,5,63);
                code.visitStmt2R1N(OR_INT_LIT16,9,9,128);
                code.visitStmt2R(INT_TO_BYTE,9,9);
                code.visitStmt3R(APUT_BYTE,9,0,2);
                code.visitLabel(L65);
                code.visitStmt3R(ADD_INT,9,1,4);
                code.visitStmt2R(SUB_INT_2ADDR,9,7);
                code.visitConstStmt(CONST_4,10, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt2R(SUB_INT_2ADDR,9,10);
                code.visitStmt2R(ARRAY_LENGTH,10,0);
                code.visitJumpStmt(IF_LE,9,10,L42);
                code.visitLabel(L66);
                code.visitStmt2R1N(ADD_INT_LIT8,4,4,-2);
                code.visitJumpStmt(GOTO,-1,-1,L42);
                code.visitLabel(L67);
                code.visitConstStmt(CONST_HIGH16,9, Integer.valueOf(-14680064)); // int: 0xff200000  float:-212676479325586540000000000000000000000.000000
                code.visitStmt2R(AND_INT_2ADDR,9,5);
                code.visitJumpStmt(IF_NEZ,9,-1,L82);
                code.visitLabel(L68);
                code.visitStmt2R1N(ADD_INT_LIT8,9,2,4);
                code.visitStmt2R(ARRAY_LENGTH,10,0);
                code.visitJumpStmt(IF_LE,9,10,L71);
                code.visitLabel(L69);
                code.visitStmt2R(MOVE,4,7);
                code.visitLabel(L70);
                code.visitJumpStmt(GOTO,-1,-1,L47);
                code.visitLabel(L71);
                code.visitStmt2R1N(ADD_INT_LIT8,1,2,1);
                code.visitLabel(L72);
                code.visitStmt2R1N(SHR_INT_LIT8,9,5,18);
                code.visitStmt2R1N(OR_INT_LIT16,9,9,240);
                code.visitStmt2R(INT_TO_BYTE,9,9);
                code.visitStmt3R(APUT_BYTE,9,0,2);
                code.visitLabel(L73);
                code.visitStmt2R1N(ADD_INT_LIT8,2,1,1);
                code.visitLabel(L74);
                code.visitStmt2R1N(SHR_INT_LIT8,9,5,12);
                code.visitStmt2R1N(AND_INT_LIT8,9,9,63);
                code.visitStmt2R1N(OR_INT_LIT16,9,9,128);
                code.visitStmt2R(INT_TO_BYTE,9,9);
                code.visitStmt3R(APUT_BYTE,9,0,1);
                code.visitLabel(L75);
                code.visitStmt2R1N(ADD_INT_LIT8,1,2,1);
                code.visitLabel(L76);
                code.visitStmt2R1N(SHR_INT_LIT8,9,5,6);
                code.visitStmt2R1N(AND_INT_LIT8,9,9,63);
                code.visitStmt2R1N(OR_INT_LIT16,9,9,128);
                code.visitStmt2R(INT_TO_BYTE,9,9);
                code.visitStmt3R(APUT_BYTE,9,0,2);
                code.visitLabel(L77);
                code.visitStmt2R1N(ADD_INT_LIT8,2,1,1);
                code.visitLabel(L78);
                code.visitStmt2R1N(AND_INT_LIT8,9,5,63);
                code.visitStmt2R1N(OR_INT_LIT16,9,9,128);
                code.visitStmt2R(INT_TO_BYTE,9,9);
                code.visitStmt3R(APUT_BYTE,9,0,1);
                code.visitLabel(L79);
                code.visitStmt3R(ADD_INT,9,2,4);
                code.visitStmt2R(SUB_INT_2ADDR,9,7);
                code.visitConstStmt(CONST_4,10, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt2R(SUB_INT_2ADDR,9,10);
                code.visitStmt2R(ARRAY_LENGTH,10,0);
                code.visitJumpStmt(IF_LE,9,10,L120);
                code.visitLabel(L80);
                code.visitStmt2R1N(ADD_INT_LIT8,4,4,-3);
                code.visitStmt2R(MOVE,1,2);
                code.visitLabel(L81);
                code.visitJumpStmt(GOTO_16,-1,-1,L42);
                code.visitLabel(L82);
                code.visitConstStmt(CONST_HIGH16,9, Integer.valueOf(-201326592)); // int: 0xf4000000  float:-40564819207303340000000000000000.000000
                code.visitStmt2R(AND_INT_2ADDR,9,5);
                code.visitJumpStmt(IF_NEZ,9,-1,L98);
                code.visitLabel(L83);
                code.visitStmt2R1N(ADD_INT_LIT8,9,2,5);
                code.visitStmt2R(ARRAY_LENGTH,10,0);
                code.visitJumpStmt(IF_LE,9,10,L86);
                code.visitLabel(L84);
                code.visitStmt2R(MOVE,4,7);
                code.visitLabel(L85);
                code.visitJumpStmt(GOTO_16,-1,-1,L47);
                code.visitLabel(L86);
                code.visitStmt2R1N(ADD_INT_LIT8,1,2,1);
                code.visitLabel(L87);
                code.visitStmt2R1N(SHR_INT_LIT8,9,5,24);
                code.visitStmt2R1N(OR_INT_LIT16,9,9,248);
                code.visitStmt2R(INT_TO_BYTE,9,9);
                code.visitStmt3R(APUT_BYTE,9,0,2);
                code.visitLabel(L88);
                code.visitStmt2R1N(ADD_INT_LIT8,2,1,1);
                code.visitLabel(L89);
                code.visitStmt2R1N(SHR_INT_LIT8,9,5,18);
                code.visitStmt2R1N(AND_INT_LIT8,9,9,63);
                code.visitStmt2R1N(OR_INT_LIT16,9,9,128);
                code.visitStmt2R(INT_TO_BYTE,9,9);
                code.visitStmt3R(APUT_BYTE,9,0,1);
                code.visitLabel(L90);
                code.visitStmt2R1N(ADD_INT_LIT8,1,2,1);
                code.visitLabel(L91);
                code.visitStmt2R1N(SHR_INT_LIT8,9,5,12);
                code.visitStmt2R1N(AND_INT_LIT8,9,9,63);
                code.visitStmt2R1N(OR_INT_LIT16,9,9,128);
                code.visitStmt2R(INT_TO_BYTE,9,9);
                code.visitStmt3R(APUT_BYTE,9,0,2);
                code.visitLabel(L92);
                code.visitStmt2R1N(ADD_INT_LIT8,2,1,1);
                code.visitLabel(L93);
                code.visitStmt2R1N(SHR_INT_LIT8,9,5,6);
                code.visitStmt2R1N(AND_INT_LIT8,9,9,63);
                code.visitStmt2R1N(OR_INT_LIT16,9,9,128);
                code.visitStmt2R(INT_TO_BYTE,9,9);
                code.visitStmt3R(APUT_BYTE,9,0,1);
                code.visitLabel(L94);
                code.visitStmt2R1N(ADD_INT_LIT8,1,2,1);
                code.visitLabel(L95);
                code.visitStmt2R1N(AND_INT_LIT8,9,5,63);
                code.visitStmt2R1N(OR_INT_LIT16,9,9,128);
                code.visitStmt2R(INT_TO_BYTE,9,9);
                code.visitStmt3R(APUT_BYTE,9,0,2);
                code.visitLabel(L96);
                code.visitStmt3R(ADD_INT,9,1,4);
                code.visitStmt2R(SUB_INT_2ADDR,9,7);
                code.visitConstStmt(CONST_4,10, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt2R(SUB_INT_2ADDR,9,10);
                code.visitStmt2R(ARRAY_LENGTH,10,0);
                code.visitJumpStmt(IF_LE,9,10,L42);
                code.visitLabel(L97);
                code.visitStmt2R1N(ADD_INT_LIT8,4,4,-4);
                code.visitJumpStmt(GOTO_16,-1,-1,L42);
                code.visitLabel(L98);
                code.visitConstStmt(CONST_HIGH16,9, Integer.valueOf(-2147483648)); // int: 0x80000000  float:-0.000000
                code.visitStmt2R(AND_INT_2ADDR,9,5);
                code.visitJumpStmt(IF_NEZ,9,-1,L117);
                code.visitLabel(L99);
                code.visitStmt2R1N(ADD_INT_LIT8,9,2,6);
                code.visitStmt2R(ARRAY_LENGTH,10,0);
                code.visitJumpStmt(IF_LE,9,10,L102);
                code.visitLabel(L100);
                code.visitStmt2R(MOVE,4,7);
                code.visitLabel(L101);
                code.visitJumpStmt(GOTO_16,-1,-1,L47);
                code.visitLabel(L102);
                code.visitStmt2R1N(ADD_INT_LIT8,1,2,1);
                code.visitLabel(L103);
                code.visitStmt2R1N(SHR_INT_LIT8,9,5,30);
                code.visitStmt2R1N(OR_INT_LIT16,9,9,252);
                code.visitStmt2R(INT_TO_BYTE,9,9);
                code.visitStmt3R(APUT_BYTE,9,0,2);
                code.visitLabel(L104);
                code.visitStmt2R1N(ADD_INT_LIT8,2,1,1);
                code.visitLabel(L105);
                code.visitStmt2R1N(SHR_INT_LIT8,9,5,24);
                code.visitStmt2R1N(AND_INT_LIT8,9,9,63);
                code.visitStmt2R1N(OR_INT_LIT16,9,9,128);
                code.visitStmt2R(INT_TO_BYTE,9,9);
                code.visitStmt3R(APUT_BYTE,9,0,1);
                code.visitLabel(L106);
                code.visitStmt2R1N(ADD_INT_LIT8,1,2,1);
                code.visitLabel(L107);
                code.visitStmt2R1N(SHR_INT_LIT8,9,5,18);
                code.visitStmt2R1N(AND_INT_LIT8,9,9,63);
                code.visitStmt2R1N(OR_INT_LIT16,9,9,128);
                code.visitStmt2R(INT_TO_BYTE,9,9);
                code.visitStmt3R(APUT_BYTE,9,0,2);
                code.visitLabel(L108);
                code.visitStmt2R1N(ADD_INT_LIT8,2,1,1);
                code.visitLabel(L109);
                code.visitStmt2R1N(SHR_INT_LIT8,9,5,12);
                code.visitStmt2R1N(AND_INT_LIT8,9,9,63);
                code.visitStmt2R1N(OR_INT_LIT16,9,9,128);
                code.visitStmt2R(INT_TO_BYTE,9,9);
                code.visitStmt3R(APUT_BYTE,9,0,1);
                code.visitLabel(L110);
                code.visitStmt2R1N(ADD_INT_LIT8,1,2,1);
                code.visitLabel(L111);
                code.visitStmt2R1N(SHR_INT_LIT8,9,5,6);
                code.visitStmt2R1N(AND_INT_LIT8,9,9,63);
                code.visitStmt2R1N(OR_INT_LIT16,9,9,128);
                code.visitStmt2R(INT_TO_BYTE,9,9);
                code.visitStmt3R(APUT_BYTE,9,0,2);
                code.visitLabel(L112);
                code.visitStmt2R1N(ADD_INT_LIT8,2,1,1);
                code.visitLabel(L113);
                code.visitStmt2R1N(AND_INT_LIT8,9,5,63);
                code.visitStmt2R1N(OR_INT_LIT16,9,9,128);
                code.visitStmt2R(INT_TO_BYTE,9,9);
                code.visitStmt3R(APUT_BYTE,9,0,1);
                code.visitLabel(L114);
                code.visitStmt3R(ADD_INT,9,2,4);
                code.visitStmt2R(SUB_INT_2ADDR,9,7);
                code.visitConstStmt(CONST_4,10, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt2R(SUB_INT_2ADDR,9,10);
                code.visitStmt2R(ARRAY_LENGTH,10,0);
                code.visitJumpStmt(IF_LE,9,10,L120);
                code.visitLabel(L115);
                code.visitStmt2R1N(ADD_INT_LIT8,4,4,-5);
                code.visitStmt2R(MOVE,1,2);
                code.visitLabel(L116);
                code.visitJumpStmt(GOTO_16,-1,-1,L42);
                code.visitLabel(L117);
                code.visitStmt2R1N(ADD_INT_LIT8,1,2,1);
                code.visitLabel(L118);
                code.visitConstStmt(CONST_16,9, Integer.valueOf(63)); // int: 0x0000003f  float:0.000000
                code.visitStmt3R(APUT_BYTE,9,0,2);
                code.visitJumpStmt(GOTO_16,-1,-1,L42);
                code.visitLabel(L119);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L120);
                code.visitStmt2R(MOVE,1,2);
                code.visitLabel(L121);
                code.visitJumpStmt(GOTO_16,-1,-1,L42);
                code.visitLabel(L122);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
