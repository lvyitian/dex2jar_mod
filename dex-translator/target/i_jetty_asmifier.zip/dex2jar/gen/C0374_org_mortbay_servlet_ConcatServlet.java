package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0374_org_mortbay_servlet_ConcatServlet {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/servlet/ConcatServlet;","Ljavax/servlet/http/HttpServlet;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("ConcatServlet.java");
        f000__context(cv);
        f001__development(cv);
        f002__lastModified(cv);
        m000__init_(cv);
        m001_doGet(cv);
        m002_getLastModified(cv);
        m003_init(cv);
    }
    public static void f000__context(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/servlet/ConcatServlet;","_context","Ljavax/servlet/ServletContext;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001__development(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/servlet/ConcatServlet;","_development","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002__lastModified(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/servlet/ConcatServlet;","_lastModified","J"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/servlet/ConcatServlet;","<init>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(61,L0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljavax/servlet/http/HttpServlet;","<init>",new String[]{ },"V"));
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001_doGet(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/servlet/ConcatServlet;","doGet",new String[]{ "Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljavax/servlet/ServletException;"));
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(11);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"req");
                ddv.visitParameterName(1,"resp");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(87,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(88,L1);
                ddv.visitStartLocal(3,L1,"q","Ljava/lang/String;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(90,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(120,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(94,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(95,L5);
                ddv.visitStartLocal(2,L5,"parts","[Ljava/lang/String;",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(96,L6);
                ddv.visitStartLocal(5,L6,"type","Ljava/lang/String;",null);
                DexLabel L7=new DexLabel();
                ddv.visitStartLocal(1,L7,"i","I",null);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(98,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(99,L9);
                ddv.visitStartLocal(4,L9,"t","Ljava/lang/String;",null);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(101,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(102,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(96,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(103,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(105,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(111,L15);
                ddv.visitEndLocal(4,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(112,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(114,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(116,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(117,L19);
                ddv.visitStartLocal(0,L19,"dispatcher","Ljavax/servlet/RequestDispatcher;",null);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(118,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(114,L21);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 9},new Method("Ljavax/servlet/http/HttpServletRequest;","getQueryString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitLabel(L1);
                code.visitJumpStmt(IF_NEZ,3,-1,L4);
                code.visitLabel(L2);
                code.visitConstStmt(CONST_16,6, Integer.valueOf(204)); // int: 0x000000cc  float:0.000000
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 10,6},new Method("Ljavax/servlet/http/HttpServletResponse;","sendError",new String[]{ "I"},"V"));
                code.visitLabel(L3);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L4);
                code.visitConstStmt(CONST_STRING,6,"\\&");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,6},new Method("Ljava/lang/String;","split",new String[]{ "Ljava/lang/String;"},"[Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L5);
                code.visitConstStmt(CONST_4,5, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L6);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L7);
                code.visitStmt2R(ARRAY_LENGTH,6,2);
                code.visitJumpStmt(IF_GE,1,6,L15);
                code.visitLabel(L8);
                code.visitFieldStmt(IGET_OBJECT,6,8,new Field("Lorg/mortbay/servlet/ConcatServlet;","_context","Ljavax/servlet/ServletContext;"));
                code.visitStmt3R(AGET_OBJECT,7,2,1);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 6,7},new Method("Ljavax/servlet/ServletContext;","getMimeType",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitLabel(L9);
                code.visitJumpStmt(IF_EQZ,4,-1,L12);
                code.visitLabel(L10);
                code.visitJumpStmt(IF_NEZ,5,-1,L13);
                code.visitLabel(L11);
                code.visitStmt2R(MOVE_OBJECT,5,4);
                code.visitLabel(L12);
                code.visitStmt2R1N(ADD_INT_LIT8,1,1,1);
                code.visitJumpStmt(GOTO,-1,-1,L7);
                code.visitLabel(L13);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,4},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitJumpStmt(IF_NEZ,6,-1,L12);
                code.visitLabel(L14);
                code.visitConstStmt(CONST_16,6, Integer.valueOf(415)); // int: 0x0000019f  float:0.000000
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 10,6},new Method("Ljavax/servlet/http/HttpServletResponse;","sendError",new String[]{ "I"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitLabel(L15);
                code.visitJumpStmt(IF_EQZ,5,-1,L17);
                code.visitLabel(L16);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 10,5},new Method("Ljavax/servlet/http/HttpServletResponse;","setContentType",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L17);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                DexLabel L22=new DexLabel();
                code.visitLabel(L22);
                code.visitStmt2R(ARRAY_LENGTH,6,2);
                code.visitJumpStmt(IF_GE,1,6,L3);
                code.visitLabel(L18);
                code.visitFieldStmt(IGET_OBJECT,6,8,new Field("Lorg/mortbay/servlet/ConcatServlet;","_context","Ljavax/servlet/ServletContext;"));
                code.visitStmt3R(AGET_OBJECT,7,2,1);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 6,7},new Method("Ljavax/servlet/ServletContext;","getRequestDispatcher",new String[]{ "Ljava/lang/String;"},"Ljavax/servlet/RequestDispatcher;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L19);
                code.visitJumpStmt(IF_EQZ,0,-1,L21);
                code.visitLabel(L20);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,9,10},new Method("Ljavax/servlet/RequestDispatcher;","include",new String[]{ "Ljavax/servlet/ServletRequest;","Ljavax/servlet/ServletResponse;"},"V"));
                code.visitLabel(L21);
                code.visitStmt2R1N(ADD_INT_LIT8,1,1,1);
                code.visitJumpStmt(GOTO,-1,-1,L22);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_getLastModified(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/servlet/ConcatServlet;","getLastModified",new String[]{ "Ljavax/servlet/http/HttpServletRequest;"},"J"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"req");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(81,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_BOOLEAN,0,2,new Field("Lorg/mortbay/servlet/ConcatServlet;","_development","Z"));
                DexLabel L1=new DexLabel();
                code.visitJumpStmt(IF_EQZ,0,-1,L1);
                code.visitConstStmt(CONST_WIDE_16,0,Long.valueOf(-1L)); // long: 0xffffffffffffffff  double:NaN
                DexLabel L2=new DexLabel();
                code.visitLabel(L2);
                code.visitStmt1R(RETURN_WIDE,0);
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_WIDE,0,2,new Field("Lorg/mortbay/servlet/ConcatServlet;","_lastModified","J"));
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_init(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/servlet/ConcatServlet;","init",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljavax/servlet/ServletException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(70,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(71,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(72,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(73,L3);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Ljava/lang/System;","currentTimeMillis",new String[]{ },"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,0);
                code.visitFieldStmt(IPUT_WIDE,0,2,new Field("Lorg/mortbay/servlet/ConcatServlet;","_lastModified","J"));
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/servlet/ConcatServlet;","getServletContext",new String[]{ },"Ljavax/servlet/ServletContext;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/servlet/ConcatServlet;","_context","Ljavax/servlet/ServletContext;"));
                code.visitLabel(L2);
                code.visitConstStmt(CONST_STRING,0,"true");
                code.visitConstStmt(CONST_STRING,1,"development");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,1},new Method("Lorg/mortbay/servlet/ConcatServlet;","getInitParameter",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitFieldStmt(IPUT_BOOLEAN,0,2,new Field("Lorg/mortbay/servlet/ConcatServlet;","_development","Z"));
                code.visitLabel(L3);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
