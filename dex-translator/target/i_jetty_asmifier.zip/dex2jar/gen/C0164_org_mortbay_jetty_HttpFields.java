package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0164_org_mortbay_jetty_HttpFields {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/jetty/HttpFields;","Ljava/lang/Object;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("HttpFields.java");
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/MemberClasses;", Visibility.SYSTEM);
            if(av00 != null) {
                {
                    DexAnnotationVisitor av01 = av00.visitArray("value");
                    if(av01 != null) {
                        av01.visit(null, new DexType("Lorg/mortbay/jetty/HttpFields$Field;"));
                        av01.visitEnd();
                    }
                }
                av00.visitEnd();
            }
        }
        f000_DAYS(cv);
        f001_MONTHS(cv);
        f002___01Jan1970(cv);
        f003___01Jan1970_BUFFER(cv);
        f004___GMT(cv);
        f005___dateCache(cv);
        f006___dateReceive(cv);
        f007___dateReceiveFmt(cv);
        f008___dateReceiveInit(cv);
        f009___one(cv);
        f010___qualities(cv);
        f011___separators(cv);
        f012___zero(cv);
        f013__bufferMap(cv);
        f014__calendar(cv);
        f015__dateBuffer(cv);
        f016__dateReceive(cv);
        f017__fields(cv);
        f018__revision(cv);
        m000__clinit_(cv);
        m001__init_(cv);
        m002_add(cv);
        m003_formatDate(cv);
        m004_formatDate(cv);
        m005_formatDate(cv);
        m006_formatDate(cv);
        m007_getField(cv);
        m008_getField(cv);
        m009_getQuality(cv);
        m010_qualityList(cv);
        m011_valueParameters(cv);
        m012_add(cv);
        m013_add(cv);
        m014_add(cv);
        m015_addDateField(cv);
        m016_addLongField(cv);
        m017_addLongField(cv);
        m018_addSetCookie(cv);
        m019_clear(cv);
        m020_containsKey(cv);
        m021_containsKey(cv);
        m022_destroy(cv);
        m023_get(cv);
        m024_getDateField(cv);
        m025_getFieldNames(cv);
        m026_getFields(cv);
        m027_getLongField(cv);
        m028_getLongField(cv);
        m029_getStringField(cv);
        m030_getStringField(cv);
        m031_getValues(cv);
        m032_getValues(cv);
        m033_getValues(cv);
        m034_put(cv);
        m035_put(cv);
        m036_put(cv);
        m037_put(cv);
        m038_put(cv);
        m039_put(cv);
        m040_putDateField(cv);
        m041_putDateField(cv);
        m042_putLongField(cv);
        m043_putLongField(cv);
        m044_remove(cv);
        m045_remove(cv);
        m046_toString(cv);
    }
    public static void f000_DAYS(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC, new Field("Lorg/mortbay/jetty/HttpFields;","DAYS","[Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001_MONTHS(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC, new Field("Lorg/mortbay/jetty/HttpFields;","MONTHS","[Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002___01Jan1970(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpFields;","__01Jan1970","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003___01Jan1970_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpFields;","__01Jan1970_BUFFER","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f004___GMT(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC, new Field("Lorg/mortbay/jetty/HttpFields;","__GMT","Ljava/util/TimeZone;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f005___dateCache(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpFields;","__dateCache","Lorg/mortbay/io/BufferDateCache;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f006___dateReceive(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC, new Field("Lorg/mortbay/jetty/HttpFields;","__dateReceive","[Ljava/text/SimpleDateFormat;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f007___dateReceiveFmt(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpFields;","__dateReceiveFmt","[Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f008___dateReceiveInit(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC, new Field("Lorg/mortbay/jetty/HttpFields;","__dateReceiveInit","I"),  Integer.valueOf(0));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f009___one(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC, new Field("Lorg/mortbay/jetty/HttpFields;","__one","Ljava/lang/Float;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f010___qualities(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC, new Field("Lorg/mortbay/jetty/HttpFields;","__qualities","Lorg/mortbay/util/StringMap;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f011___separators(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpFields;","__separators","Ljava/lang/String;"), ", \t");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f012___zero(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC, new Field("Lorg/mortbay/jetty/HttpFields;","__zero","Ljava/lang/Float;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f013__bufferMap(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/jetty/HttpFields;","_bufferMap","Ljava/util/HashMap;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f014__calendar(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/HttpFields;","_calendar","Ljava/util/Calendar;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f015__dateBuffer(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/HttpFields;","_dateBuffer","Ljava/lang/StringBuffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f016__dateReceive(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/jetty/HttpFields;","_dateReceive","[Ljava/text/SimpleDateFormat;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f017__fields(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/jetty/HttpFields;","_fields","Ljava/util/ArrayList;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f018__revision(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/jetty/HttpFields;","_revision","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__clinit_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/HttpFields;","<clinit>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(9);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(65,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(67,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(162,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(163,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(166,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(179,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(183,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(184,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(185,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(187,L10);
                DexLabel L11=new DexLabel();
                ddv.visitStartLocal(0,L11,"i","I",null);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(189,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(190,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(187,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(193,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(194,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(1158,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(1159,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(1160,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(1163,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(1164,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(1165,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(1166,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(1167,L24);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(1168,L25);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(1169,L26);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(1170,L27);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(1171,L28);
                DexLabel L29=new DexLabel();
                ddv.visitLineNumber(1172,L29);
                DexLabel L30=new DexLabel();
                ddv.visitLineNumber(1173,L30);
                DexLabel L31=new DexLabel();
                ddv.visitLineNumber(1174,L31);
                DexLabel L32=new DexLabel();
                ddv.visitLineNumber(1175,L32);
                DexLabel L33=new DexLabel();
                ddv.visitLineNumber(1176,L33);
                DexLabel L34=new DexLabel();
                ddv.visitLineNumber(1177,L34);
                DexLabel L35=new DexLabel();
                ddv.visitLineNumber(1178,L35);
                DexLabel L36=new DexLabel();
                ddv.visitLineNumber(1179,L36);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,8, Integer.valueOf(4)); // int: 0x00000004  float:0.000000
                code.visitConstStmt(CONST_4,7, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitConstStmt(CONST_4,6, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitConstStmt(CONST_4,4, Integer.valueOf(3)); // int: 0x00000003  float:0.000000
                code.visitConstStmt(CONST_4,5, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitConstStmt(CONST_16,1, Integer.valueOf(8)); // int: 0x00000008  float:0.000000
                code.visitTypeStmt(NEW_ARRAY,1,1,"[Ljava/lang/String;");
                code.visitConstStmt(CONST_STRING,2,"Sat");
                code.visitStmt3R(APUT_OBJECT,2,1,5);
                code.visitConstStmt(CONST_STRING,2,"Sun");
                code.visitStmt3R(APUT_OBJECT,2,1,6);
                code.visitConstStmt(CONST_STRING,2,"Mon");
                code.visitStmt3R(APUT_OBJECT,2,1,7);
                code.visitConstStmt(CONST_STRING,2,"Tue");
                code.visitStmt3R(APUT_OBJECT,2,1,4);
                code.visitConstStmt(CONST_STRING,2,"Wed");
                code.visitStmt3R(APUT_OBJECT,2,1,8);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(5)); // int: 0x00000005  float:0.000000
                code.visitConstStmt(CONST_STRING,3,"Thu");
                code.visitStmt3R(APUT_OBJECT,3,1,2);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(6)); // int: 0x00000006  float:0.000000
                code.visitConstStmt(CONST_STRING,3,"Fri");
                code.visitStmt3R(APUT_OBJECT,3,1,2);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(7)); // int: 0x00000007  float:0.000000
                code.visitConstStmt(CONST_STRING,3,"Sat");
                code.visitStmt3R(APUT_OBJECT,3,1,2);
                code.visitFieldStmt(SPUT_OBJECT,1,-1,new Field("Lorg/mortbay/jetty/HttpFields;","DAYS","[Ljava/lang/String;"));
                code.visitLabel(L2);
                code.visitConstStmt(CONST_16,1, Integer.valueOf(13)); // int: 0x0000000d  float:0.000000
                code.visitTypeStmt(NEW_ARRAY,1,1,"[Ljava/lang/String;");
                code.visitConstStmt(CONST_STRING,2,"Jan");
                code.visitStmt3R(APUT_OBJECT,2,1,5);
                code.visitConstStmt(CONST_STRING,2,"Feb");
                code.visitStmt3R(APUT_OBJECT,2,1,6);
                code.visitConstStmt(CONST_STRING,2,"Mar");
                code.visitStmt3R(APUT_OBJECT,2,1,7);
                code.visitConstStmt(CONST_STRING,2,"Apr");
                code.visitStmt3R(APUT_OBJECT,2,1,4);
                code.visitConstStmt(CONST_STRING,2,"May");
                code.visitStmt3R(APUT_OBJECT,2,1,8);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(5)); // int: 0x00000005  float:0.000000
                code.visitConstStmt(CONST_STRING,3,"Jun");
                code.visitStmt3R(APUT_OBJECT,3,1,2);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(6)); // int: 0x00000006  float:0.000000
                code.visitConstStmt(CONST_STRING,3,"Jul");
                code.visitStmt3R(APUT_OBJECT,3,1,2);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(7)); // int: 0x00000007  float:0.000000
                code.visitConstStmt(CONST_STRING,3,"Aug");
                code.visitStmt3R(APUT_OBJECT,3,1,2);
                code.visitConstStmt(CONST_16,2, Integer.valueOf(8)); // int: 0x00000008  float:0.000000
                code.visitConstStmt(CONST_STRING,3,"Sep");
                code.visitStmt3R(APUT_OBJECT,3,1,2);
                code.visitConstStmt(CONST_16,2, Integer.valueOf(9)); // int: 0x00000009  float:0.000000
                code.visitConstStmt(CONST_STRING,3,"Oct");
                code.visitStmt3R(APUT_OBJECT,3,1,2);
                code.visitConstStmt(CONST_16,2, Integer.valueOf(10)); // int: 0x0000000a  float:0.000000
                code.visitConstStmt(CONST_STRING,3,"Nov");
                code.visitStmt3R(APUT_OBJECT,3,1,2);
                code.visitConstStmt(CONST_16,2, Integer.valueOf(11)); // int: 0x0000000b  float:0.000000
                code.visitConstStmt(CONST_STRING,3,"Dec");
                code.visitStmt3R(APUT_OBJECT,3,1,2);
                code.visitConstStmt(CONST_16,2, Integer.valueOf(12)); // int: 0x0000000c  float:0.000000
                code.visitConstStmt(CONST_STRING,3,"Jan");
                code.visitStmt3R(APUT_OBJECT,3,1,2);
                code.visitFieldStmt(SPUT_OBJECT,1,-1,new Field("Lorg/mortbay/jetty/HttpFields;","MONTHS","[Ljava/lang/String;"));
                code.visitLabel(L3);
                code.visitConstStmt(CONST_STRING,1,"GMT");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1},new Method("Ljava/util/TimeZone;","getTimeZone",new String[]{ "Ljava/lang/String;"},"Ljava/util/TimeZone;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitFieldStmt(SPUT_OBJECT,1,-1,new Field("Lorg/mortbay/jetty/HttpFields;","__GMT","Ljava/util/TimeZone;"));
                code.visitLabel(L4);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Lorg/mortbay/io/BufferDateCache;");
                code.visitConstStmt(CONST_STRING,2,"EEE, dd MMM yyyy HH:mm:ss \'GMT\'");
                code.visitFieldStmt(SGET_OBJECT,3,-1,new Field("Ljava/util/Locale;","US","Ljava/util/Locale;"));
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,2,3},new Method("Lorg/mortbay/io/BufferDateCache;","<init>",new String[]{ "Ljava/lang/String;","Ljava/util/Locale;"},"V"));
                code.visitFieldStmt(SPUT_OBJECT,1,-1,new Field("Lorg/mortbay/jetty/HttpFields;","__dateCache","Lorg/mortbay/io/BufferDateCache;"));
                code.visitLabel(L5);
                code.visitConstStmt(CONST_16,1, Integer.valueOf(22)); // int: 0x00000016  float:0.000000
                code.visitTypeStmt(NEW_ARRAY,1,1,"[Ljava/lang/String;");
                code.visitConstStmt(CONST_STRING,2,"EEE, dd MMM yyyy HH:mm:ss zzz");
                code.visitStmt3R(APUT_OBJECT,2,1,5);
                code.visitConstStmt(CONST_STRING,2,"EEE, dd-MMM-yy HH:mm:ss");
                code.visitStmt3R(APUT_OBJECT,2,1,6);
                code.visitConstStmt(CONST_STRING,2,"EEE MMM dd HH:mm:ss yyyy");
                code.visitStmt3R(APUT_OBJECT,2,1,7);
                code.visitConstStmt(CONST_STRING,2,"EEE, dd MMM yyyy HH:mm:ss");
                code.visitStmt3R(APUT_OBJECT,2,1,4);
                code.visitConstStmt(CONST_STRING,2,"EEE dd MMM yyyy HH:mm:ss zzz");
                code.visitStmt3R(APUT_OBJECT,2,1,8);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(5)); // int: 0x00000005  float:0.000000
                code.visitConstStmt(CONST_STRING,3,"EEE dd MMM yyyy HH:mm:ss");
                code.visitStmt3R(APUT_OBJECT,3,1,2);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(6)); // int: 0x00000006  float:0.000000
                code.visitConstStmt(CONST_STRING,3,"EEE MMM dd yyyy HH:mm:ss zzz");
                code.visitStmt3R(APUT_OBJECT,3,1,2);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(7)); // int: 0x00000007  float:0.000000
                code.visitConstStmt(CONST_STRING,3,"EEE MMM dd yyyy HH:mm:ss");
                code.visitStmt3R(APUT_OBJECT,3,1,2);
                code.visitConstStmt(CONST_16,2, Integer.valueOf(8)); // int: 0x00000008  float:0.000000
                code.visitConstStmt(CONST_STRING,3,"EEE MMM-dd-yyyy HH:mm:ss zzz");
                code.visitStmt3R(APUT_OBJECT,3,1,2);
                code.visitConstStmt(CONST_16,2, Integer.valueOf(9)); // int: 0x00000009  float:0.000000
                code.visitConstStmt(CONST_STRING,3,"EEE MMM-dd-yyyy HH:mm:ss");
                code.visitStmt3R(APUT_OBJECT,3,1,2);
                code.visitConstStmt(CONST_16,2, Integer.valueOf(10)); // int: 0x0000000a  float:0.000000
                code.visitConstStmt(CONST_STRING,3,"dd MMM yyyy HH:mm:ss zzz");
                code.visitStmt3R(APUT_OBJECT,3,1,2);
                code.visitConstStmt(CONST_16,2, Integer.valueOf(11)); // int: 0x0000000b  float:0.000000
                code.visitConstStmt(CONST_STRING,3,"dd MMM yyyy HH:mm:ss");
                code.visitStmt3R(APUT_OBJECT,3,1,2);
                code.visitConstStmt(CONST_16,2, Integer.valueOf(12)); // int: 0x0000000c  float:0.000000
                code.visitConstStmt(CONST_STRING,3,"dd-MMM-yy HH:mm:ss zzz");
                code.visitStmt3R(APUT_OBJECT,3,1,2);
                code.visitConstStmt(CONST_16,2, Integer.valueOf(13)); // int: 0x0000000d  float:0.000000
                code.visitConstStmt(CONST_STRING,3,"dd-MMM-yy HH:mm:ss");
                code.visitStmt3R(APUT_OBJECT,3,1,2);
                code.visitConstStmt(CONST_16,2, Integer.valueOf(14)); // int: 0x0000000e  float:0.000000
                code.visitConstStmt(CONST_STRING,3,"MMM dd HH:mm:ss yyyy zzz");
                code.visitStmt3R(APUT_OBJECT,3,1,2);
                code.visitConstStmt(CONST_16,2, Integer.valueOf(15)); // int: 0x0000000f  float:0.000000
                code.visitConstStmt(CONST_STRING,3,"MMM dd HH:mm:ss yyyy");
                code.visitStmt3R(APUT_OBJECT,3,1,2);
                code.visitConstStmt(CONST_16,2, Integer.valueOf(16)); // int: 0x00000010  float:0.000000
                code.visitConstStmt(CONST_STRING,3,"EEE MMM dd HH:mm:ss yyyy zzz");
                code.visitStmt3R(APUT_OBJECT,3,1,2);
                code.visitConstStmt(CONST_16,2, Integer.valueOf(17)); // int: 0x00000011  float:0.000000
                code.visitConstStmt(CONST_STRING,3,"EEE, MMM dd HH:mm:ss yyyy zzz");
                code.visitStmt3R(APUT_OBJECT,3,1,2);
                code.visitConstStmt(CONST_16,2, Integer.valueOf(18)); // int: 0x00000012  float:0.000000
                code.visitConstStmt(CONST_STRING,3,"EEE, MMM dd HH:mm:ss yyyy");
                code.visitStmt3R(APUT_OBJECT,3,1,2);
                code.visitConstStmt(CONST_16,2, Integer.valueOf(19)); // int: 0x00000013  float:0.000000
                code.visitConstStmt(CONST_STRING,3,"EEE, dd-MMM-yy HH:mm:ss zzz");
                code.visitStmt3R(APUT_OBJECT,3,1,2);
                code.visitConstStmt(CONST_16,2, Integer.valueOf(20)); // int: 0x00000014  float:0.000000
                code.visitConstStmt(CONST_STRING,3,"EEE dd-MMM-yy HH:mm:ss zzz");
                code.visitStmt3R(APUT_OBJECT,3,1,2);
                code.visitConstStmt(CONST_16,2, Integer.valueOf(21)); // int: 0x00000015  float:0.000000
                code.visitConstStmt(CONST_STRING,3,"EEE dd-MMM-yy HH:mm:ss");
                code.visitStmt3R(APUT_OBJECT,3,1,2);
                code.visitFieldStmt(SPUT_OBJECT,1,-1,new Field("Lorg/mortbay/jetty/HttpFields;","__dateReceiveFmt","[Ljava/lang/String;"));
                code.visitLabel(L6);
                code.visitFieldStmt(SPUT,4,-1,new Field("Lorg/mortbay/jetty/HttpFields;","__dateReceiveInit","I"));
                code.visitLabel(L7);
                code.visitFieldStmt(SGET_OBJECT,1,-1,new Field("Lorg/mortbay/jetty/HttpFields;","__GMT","Ljava/util/TimeZone;"));
                code.visitConstStmt(CONST_STRING,2,"GMT");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/util/TimeZone;","setID",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L8);
                code.visitFieldStmt(SGET_OBJECT,1,-1,new Field("Lorg/mortbay/jetty/HttpFields;","__dateCache","Lorg/mortbay/io/BufferDateCache;"));
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/jetty/HttpFields;","__GMT","Ljava/util/TimeZone;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Lorg/mortbay/io/BufferDateCache;","setTimeZone",new String[]{ "Ljava/util/TimeZone;"},"V"));
                code.visitLabel(L9);
                code.visitFieldStmt(SGET_OBJECT,1,-1,new Field("Lorg/mortbay/jetty/HttpFields;","__dateReceiveFmt","[Ljava/lang/String;"));
                code.visitStmt2R(ARRAY_LENGTH,1,1);
                code.visitTypeStmt(NEW_ARRAY,1,1,"[Ljava/text/SimpleDateFormat;");
                code.visitFieldStmt(SPUT_OBJECT,1,-1,new Field("Lorg/mortbay/jetty/HttpFields;","__dateReceive","[Ljava/text/SimpleDateFormat;"));
                code.visitLabel(L10);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L11);
                code.visitFieldStmt(SGET,1,-1,new Field("Lorg/mortbay/jetty/HttpFields;","__dateReceiveInit","I"));
                code.visitJumpStmt(IF_GE,0,1,L15);
                code.visitLabel(L12);
                code.visitFieldStmt(SGET_OBJECT,1,-1,new Field("Lorg/mortbay/jetty/HttpFields;","__dateReceive","[Ljava/text/SimpleDateFormat;"));
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Ljava/text/SimpleDateFormat;");
                code.visitFieldStmt(SGET_OBJECT,3,-1,new Field("Lorg/mortbay/jetty/HttpFields;","__dateReceiveFmt","[Ljava/lang/String;"));
                code.visitStmt3R(AGET_OBJECT,3,3,0);
                code.visitFieldStmt(SGET_OBJECT,4,-1,new Field("Ljava/util/Locale;","US","Ljava/util/Locale;"));
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2,3,4},new Method("Ljava/text/SimpleDateFormat;","<init>",new String[]{ "Ljava/lang/String;","Ljava/util/Locale;"},"V"));
                code.visitStmt3R(APUT_OBJECT,2,1,0);
                code.visitLabel(L13);
                code.visitFieldStmt(SGET_OBJECT,1,-1,new Field("Lorg/mortbay/jetty/HttpFields;","__dateReceive","[Ljava/text/SimpleDateFormat;"));
                code.visitStmt3R(AGET_OBJECT,1,1,0);
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/jetty/HttpFields;","__GMT","Ljava/util/TimeZone;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/text/SimpleDateFormat;","setTimeZone",new String[]{ "Ljava/util/TimeZone;"},"V"));
                code.visitLabel(L14);
                code.visitStmt2R1N(ADD_INT_LIT8,0,0,1);
                code.visitJumpStmt(GOTO,-1,-1,L11);
                code.visitLabel(L15);
                code.visitConstStmt(CONST_WIDE_16,1,Long.valueOf(0L)); // long: 0x0000000000000000  double:0.000000
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1,2,5},new Method("Lorg/mortbay/jetty/HttpFields;","formatDate",new String[]{ "J","Z"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitFieldStmt(SPUT_OBJECT,1,-1,new Field("Lorg/mortbay/jetty/HttpFields;","__01Jan1970","Ljava/lang/String;"));
                code.visitLabel(L16);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Lorg/mortbay/io/ByteArrayBuffer;");
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/jetty/HttpFields;","__01Jan1970","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,2},new Method("Lorg/mortbay/io/ByteArrayBuffer;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitFieldStmt(SPUT_OBJECT,1,-1,new Field("Lorg/mortbay/jetty/HttpFields;","__01Jan1970_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L17);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/lang/Float;");
                code.visitConstStmt(CONST_STRING,2,"1.0");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,2},new Method("Ljava/lang/Float;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitFieldStmt(SPUT_OBJECT,1,-1,new Field("Lorg/mortbay/jetty/HttpFields;","__one","Ljava/lang/Float;"));
                code.visitLabel(L18);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/lang/Float;");
                code.visitConstStmt(CONST_STRING,2,"0.0");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,2},new Method("Ljava/lang/Float;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitFieldStmt(SPUT_OBJECT,1,-1,new Field("Lorg/mortbay/jetty/HttpFields;","__zero","Ljava/lang/Float;"));
                code.visitLabel(L19);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Lorg/mortbay/util/StringMap;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Lorg/mortbay/util/StringMap;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(SPUT_OBJECT,1,-1,new Field("Lorg/mortbay/jetty/HttpFields;","__qualities","Lorg/mortbay/util/StringMap;"));
                code.visitLabel(L20);
                code.visitFieldStmt(SGET_OBJECT,1,-1,new Field("Lorg/mortbay/jetty/HttpFields;","__qualities","Lorg/mortbay/util/StringMap;"));
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(SGET_OBJECT,3,-1,new Field("Lorg/mortbay/jetty/HttpFields;","__one","Ljava/lang/Float;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2,3},new Method("Lorg/mortbay/util/StringMap;","put",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L21);
                code.visitFieldStmt(SGET_OBJECT,1,-1,new Field("Lorg/mortbay/jetty/HttpFields;","__qualities","Lorg/mortbay/util/StringMap;"));
                code.visitConstStmt(CONST_STRING,2,"1.0");
                code.visitFieldStmt(SGET_OBJECT,3,-1,new Field("Lorg/mortbay/jetty/HttpFields;","__one","Ljava/lang/Float;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2,3},new Method("Lorg/mortbay/util/StringMap;","put",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L22);
                code.visitFieldStmt(SGET_OBJECT,1,-1,new Field("Lorg/mortbay/jetty/HttpFields;","__qualities","Lorg/mortbay/util/StringMap;"));
                code.visitConstStmt(CONST_STRING,2,"1");
                code.visitFieldStmt(SGET_OBJECT,3,-1,new Field("Lorg/mortbay/jetty/HttpFields;","__one","Ljava/lang/Float;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2,3},new Method("Lorg/mortbay/util/StringMap;","put",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L23);
                code.visitFieldStmt(SGET_OBJECT,1,-1,new Field("Lorg/mortbay/jetty/HttpFields;","__qualities","Lorg/mortbay/util/StringMap;"));
                code.visitConstStmt(CONST_STRING,2,"0.9");
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Ljava/lang/Float;");
                code.visitConstStmt(CONST_STRING,4,"0.9");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3,4},new Method("Ljava/lang/Float;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2,3},new Method("Lorg/mortbay/util/StringMap;","put",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L24);
                code.visitFieldStmt(SGET_OBJECT,1,-1,new Field("Lorg/mortbay/jetty/HttpFields;","__qualities","Lorg/mortbay/util/StringMap;"));
                code.visitConstStmt(CONST_STRING,2,"0.8");
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Ljava/lang/Float;");
                code.visitConstStmt(CONST_STRING,4,"0.8");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3,4},new Method("Ljava/lang/Float;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2,3},new Method("Lorg/mortbay/util/StringMap;","put",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L25);
                code.visitFieldStmt(SGET_OBJECT,1,-1,new Field("Lorg/mortbay/jetty/HttpFields;","__qualities","Lorg/mortbay/util/StringMap;"));
                code.visitConstStmt(CONST_STRING,2,"0.7");
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Ljava/lang/Float;");
                code.visitConstStmt(CONST_STRING,4,"0.7");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3,4},new Method("Ljava/lang/Float;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2,3},new Method("Lorg/mortbay/util/StringMap;","put",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L26);
                code.visitFieldStmt(SGET_OBJECT,1,-1,new Field("Lorg/mortbay/jetty/HttpFields;","__qualities","Lorg/mortbay/util/StringMap;"));
                code.visitConstStmt(CONST_STRING,2,"0.66");
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Ljava/lang/Float;");
                code.visitConstStmt(CONST_STRING,4,"0.66");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3,4},new Method("Ljava/lang/Float;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2,3},new Method("Lorg/mortbay/util/StringMap;","put",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L27);
                code.visitFieldStmt(SGET_OBJECT,1,-1,new Field("Lorg/mortbay/jetty/HttpFields;","__qualities","Lorg/mortbay/util/StringMap;"));
                code.visitConstStmt(CONST_STRING,2,"0.6");
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Ljava/lang/Float;");
                code.visitConstStmt(CONST_STRING,4,"0.6");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3,4},new Method("Ljava/lang/Float;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2,3},new Method("Lorg/mortbay/util/StringMap;","put",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L28);
                code.visitFieldStmt(SGET_OBJECT,1,-1,new Field("Lorg/mortbay/jetty/HttpFields;","__qualities","Lorg/mortbay/util/StringMap;"));
                code.visitConstStmt(CONST_STRING,2,"0.5");
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Ljava/lang/Float;");
                code.visitConstStmt(CONST_STRING,4,"0.5");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3,4},new Method("Ljava/lang/Float;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2,3},new Method("Lorg/mortbay/util/StringMap;","put",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L29);
                code.visitFieldStmt(SGET_OBJECT,1,-1,new Field("Lorg/mortbay/jetty/HttpFields;","__qualities","Lorg/mortbay/util/StringMap;"));
                code.visitConstStmt(CONST_STRING,2,"0.4");
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Ljava/lang/Float;");
                code.visitConstStmt(CONST_STRING,4,"0.4");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3,4},new Method("Ljava/lang/Float;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2,3},new Method("Lorg/mortbay/util/StringMap;","put",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L30);
                code.visitFieldStmt(SGET_OBJECT,1,-1,new Field("Lorg/mortbay/jetty/HttpFields;","__qualities","Lorg/mortbay/util/StringMap;"));
                code.visitConstStmt(CONST_STRING,2,"0.33");
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Ljava/lang/Float;");
                code.visitConstStmt(CONST_STRING,4,"0.33");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3,4},new Method("Ljava/lang/Float;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2,3},new Method("Lorg/mortbay/util/StringMap;","put",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L31);
                code.visitFieldStmt(SGET_OBJECT,1,-1,new Field("Lorg/mortbay/jetty/HttpFields;","__qualities","Lorg/mortbay/util/StringMap;"));
                code.visitConstStmt(CONST_STRING,2,"0.3");
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Ljava/lang/Float;");
                code.visitConstStmt(CONST_STRING,4,"0.3");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3,4},new Method("Ljava/lang/Float;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2,3},new Method("Lorg/mortbay/util/StringMap;","put",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L32);
                code.visitFieldStmt(SGET_OBJECT,1,-1,new Field("Lorg/mortbay/jetty/HttpFields;","__qualities","Lorg/mortbay/util/StringMap;"));
                code.visitConstStmt(CONST_STRING,2,"0.2");
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Ljava/lang/Float;");
                code.visitConstStmt(CONST_STRING,4,"0.2");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3,4},new Method("Ljava/lang/Float;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2,3},new Method("Lorg/mortbay/util/StringMap;","put",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L33);
                code.visitFieldStmt(SGET_OBJECT,1,-1,new Field("Lorg/mortbay/jetty/HttpFields;","__qualities","Lorg/mortbay/util/StringMap;"));
                code.visitConstStmt(CONST_STRING,2,"0.1");
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Ljava/lang/Float;");
                code.visitConstStmt(CONST_STRING,4,"0.1");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3,4},new Method("Ljava/lang/Float;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2,3},new Method("Lorg/mortbay/util/StringMap;","put",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L34);
                code.visitFieldStmt(SGET_OBJECT,1,-1,new Field("Lorg/mortbay/jetty/HttpFields;","__qualities","Lorg/mortbay/util/StringMap;"));
                code.visitConstStmt(CONST_STRING,2,"0");
                code.visitFieldStmt(SGET_OBJECT,3,-1,new Field("Lorg/mortbay/jetty/HttpFields;","__zero","Ljava/lang/Float;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2,3},new Method("Lorg/mortbay/util/StringMap;","put",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L35);
                code.visitFieldStmt(SGET_OBJECT,1,-1,new Field("Lorg/mortbay/jetty/HttpFields;","__qualities","Lorg/mortbay/util/StringMap;"));
                code.visitConstStmt(CONST_STRING,2,"0.0");
                code.visitFieldStmt(SGET_OBJECT,3,-1,new Field("Lorg/mortbay/jetty/HttpFields;","__zero","Ljava/lang/Float;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2,3},new Method("Lorg/mortbay/util/StringMap;","put",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L36);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/HttpFields;","<init>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(209,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(197,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(199,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(200,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(210,L4);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2},new Method("Ljava/lang/Object;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/util/ArrayList;");
                code.visitConstStmt(CONST_16,1, Integer.valueOf(20)); // int: 0x00000014  float:0.000000
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Ljava/util/ArrayList;","<init>",new String[]{ "I"},"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/jetty/HttpFields;","_fields","Ljava/util/ArrayList;"));
                code.visitLabel(L2);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/util/HashMap;");
                code.visitConstStmt(CONST_16,1, Integer.valueOf(32)); // int: 0x00000020  float:0.000000
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Ljava/util/HashMap;","<init>",new String[]{ "I"},"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/jetty/HttpFields;","_bufferMap","Ljava/util/HashMap;"));
                code.visitLabel(L3);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpFields;","__dateReceive","[Ljava/text/SimpleDateFormat;"));
                code.visitStmt2R(ARRAY_LENGTH,0,0);
                code.visitTypeStmt(NEW_ARRAY,0,0,"[Ljava/text/SimpleDateFormat;");
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/jetty/HttpFields;","_dateReceive","[Ljava/text/SimpleDateFormat;"));
                code.visitLabel(L4);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_add(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PRIVATE, new Method("Lorg/mortbay/jetty/HttpFields;","add",new String[]{ "Lorg/mortbay/io/Buffer;","Lorg/mortbay/io/Buffer;","J"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/IllegalArgumentException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(13);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                ddv.visitParameterName(1,"value");
                ddv.visitParameterName(2,"numValue");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(643,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(645,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(647,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(648,L3);
                ddv.visitStartLocal(0,L3,"field","Lorg/mortbay/jetty/HttpFields$Field;",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(649,L4);
                ddv.visitStartLocal(7,L4,"last","Lorg/mortbay/jetty/HttpFields$Field;",null);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(651,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(653,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(654,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(658,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(659,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(676,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(663,L11);
                DexLabel L12=new DexLabel();
                ddv.visitEndLocal(0,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(666,L13);
                ddv.visitRestartLocal(0,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(668,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(669,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(674,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(672,L17);
                code.visitLabel(L0);
                code.visitJumpStmt(IF_NEZ,10,-1,L1);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/lang/IllegalArgumentException;");
                code.visitConstStmt(CONST_STRING,2,"null value");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,2},new Method("Ljava/lang/IllegalArgumentException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,1);
                code.visitLabel(L1);
                code.visitTypeStmt(INSTANCE_OF,1,9,"Lorg/mortbay/io/BufferCache$CachedBuffer;");
                code.visitJumpStmt(IF_NEZ,1,-1,L2);
                code.visitFieldStmt(SGET_OBJECT,1,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","CACHE","Lorg/mortbay/jetty/HttpHeaders;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,9},new Method("Lorg/mortbay/jetty/HttpHeaders;","lookup",new String[]{ "Lorg/mortbay/io/Buffer;"},"Lorg/mortbay/io/Buffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,1,8,new Field("Lorg/mortbay/jetty/HttpFields;","_bufferMap","Ljava/util/HashMap;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,9},new Method("Ljava/util/HashMap;","get",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Lorg/mortbay/jetty/HttpFields$Field;");
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,7, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L4);
                code.visitJumpStmt(IF_EQZ,0,-1,L8);
                code.visitLabel(L5);
                code.visitJumpStmt(IF_EQZ,0,-1,L8);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/jetty/HttpFields$Field;","access$100",new String[]{ "Lorg/mortbay/jetty/HttpFields$Field;"},"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitFieldStmt(IGET,2,8,new Field("Lorg/mortbay/jetty/HttpFields;","_revision","I"));
                code.visitJumpStmt(IF_NE,1,2,L8);
                code.visitLabel(L6);
                code.visitStmt2R(MOVE_OBJECT,7,0);
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/jetty/HttpFields$Field;","access$400",new String[]{ "Lorg/mortbay/jetty/HttpFields$Field;"},"Lorg/mortbay/jetty/HttpFields$Field;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitLabel(L8);
                code.visitJumpStmt(IF_EQZ,0,-1,L11);
                code.visitLabel(L9);
                code.visitFieldStmt(IGET,1,8,new Field("Lorg/mortbay/jetty/HttpFields;","_revision","I"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,10,11,12,1},new Method("Lorg/mortbay/jetty/HttpFields$Field;","access$500",new String[]{ "Lorg/mortbay/jetty/HttpFields$Field;","Lorg/mortbay/io/Buffer;","J","I"},"V"));
                code.visitLabel(L10);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L11);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/jetty/HttpFields$Field;");
                code.visitLabel(L12);
                code.visitFieldStmt(IGET,5,8,new Field("Lorg/mortbay/jetty/HttpFields;","_revision","I"));
                code.visitConstStmt(CONST_4,6, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt2R(MOVE_OBJECT,1,9);
                code.visitStmt2R(MOVE_OBJECT,2,10);
                code.visitStmt2R(MOVE_WIDE,3,11);
                code.visitMethodStmt(INVOKE_DIRECT_RANGE,new int[]{ 0,1,2,3,4,5,6},new Method("Lorg/mortbay/jetty/HttpFields$Field;","<init>",new String[]{ "Lorg/mortbay/io/Buffer;","Lorg/mortbay/io/Buffer;","J","I","Lorg/mortbay/jetty/HttpFields$1;"},"V"));
                code.visitLabel(L13);
                code.visitJumpStmt(IF_EQZ,7,-1,L17);
                code.visitLabel(L14);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,7},new Method("Lorg/mortbay/jetty/HttpFields$Field;","access$002",new String[]{ "Lorg/mortbay/jetty/HttpFields$Field;","Lorg/mortbay/jetty/HttpFields$Field;"},"Lorg/mortbay/jetty/HttpFields$Field;"));
                code.visitLabel(L15);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 7,0},new Method("Lorg/mortbay/jetty/HttpFields$Field;","access$402",new String[]{ "Lorg/mortbay/jetty/HttpFields$Field;","Lorg/mortbay/jetty/HttpFields$Field;"},"Lorg/mortbay/jetty/HttpFields$Field;"));
                code.visitLabel(L16);
                code.visitFieldStmt(IGET_OBJECT,1,8,new Field("Lorg/mortbay/jetty/HttpFields;","_fields","Ljava/util/ArrayList;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,0},new Method("Ljava/util/ArrayList;","add",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitJumpStmt(GOTO,-1,-1,L10);
                code.visitLabel(L17);
                code.visitFieldStmt(IGET_OBJECT,1,8,new Field("Lorg/mortbay/jetty/HttpFields;","_bufferMap","Ljava/util/HashMap;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/HttpFields$Field;","getNameBuffer",new String[]{ },"Lorg/mortbay/io/Buffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2,0},new Method("Ljava/util/HashMap;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitJumpStmt(GOTO,-1,-1,L16);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_formatDate(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/jetty/HttpFields;","formatDate",new String[]{ "J","Z"},"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"date");
                ddv.visitParameterName(1,"cookie");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(77,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(78,L1);
                ddv.visitStartLocal(0,L1,"buf","Ljava/lang/StringBuffer;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(79,L2);
                ddv.visitStartLocal(1,L2,"gc","Ljava/util/GregorianCalendar;",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(80,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(81,L4);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/StringBuffer;");
                code.visitConstStmt(CONST_16,2, Integer.valueOf(32)); // int: 0x00000020  float:0.000000
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,2},new Method("Ljava/lang/StringBuffer;","<init>",new String[]{ "I"},"V"));
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/util/GregorianCalendar;");
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/jetty/HttpFields;","__GMT","Ljava/util/TimeZone;"));
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,2},new Method("Ljava/util/GregorianCalendar;","<init>",new String[]{ "Ljava/util/TimeZone;"},"V"));
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,3,4},new Method("Ljava/util/GregorianCalendar;","setTimeInMillis",new String[]{ "J"},"V"));
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,1,5},new Method("Lorg/mortbay/jetty/HttpFields;","formatDate",new String[]{ "Ljava/lang/StringBuffer;","Ljava/util/Calendar;","Z"},"V"));
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/StringBuffer;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitStmt1R(RETURN_OBJECT,2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_formatDate(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/jetty/HttpFields;","formatDate",new String[]{ "Ljava/lang/StringBuffer;","J","Z"},"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"buf");
                ddv.visitParameterName(1,"date");
                ddv.visitParameterName(2,"cookie");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(103,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(104,L1);
                ddv.visitStartLocal(0,L1,"gc","Ljava/util/GregorianCalendar;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(105,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(106,L3);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/util/GregorianCalendar;");
                code.visitFieldStmt(SGET_OBJECT,1,-1,new Field("Lorg/mortbay/jetty/HttpFields;","__GMT","Ljava/util/TimeZone;"));
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Ljava/util/GregorianCalendar;","<init>",new String[]{ "Ljava/util/TimeZone;"},"V"));
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,3,4},new Method("Ljava/util/GregorianCalendar;","setTimeInMillis",new String[]{ "J"},"V"));
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2,0,5},new Method("Lorg/mortbay/jetty/HttpFields;","formatDate",new String[]{ "Ljava/lang/StringBuffer;","Ljava/util/Calendar;","Z"},"V"));
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/lang/StringBuffer;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitStmt1R(RETURN_OBJECT,1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_formatDate(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/jetty/HttpFields;","formatDate",new String[]{ "Ljava/util/Calendar;","Z"},"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"calendar");
                ddv.visitParameterName(1,"cookie");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(91,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(92,L1);
                ddv.visitStartLocal(0,L1,"buf","Ljava/lang/StringBuffer;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(93,L2);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/StringBuffer;");
                code.visitConstStmt(CONST_16,1, Integer.valueOf(32)); // int: 0x00000020  float:0.000000
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Ljava/lang/StringBuffer;","<init>",new String[]{ "I"},"V"));
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,2,3},new Method("Lorg/mortbay/jetty/HttpFields;","formatDate",new String[]{ "Ljava/lang/StringBuffer;","Ljava/util/Calendar;","Z"},"V"));
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/StringBuffer;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitStmt1R(RETURN_OBJECT,1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_formatDate(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/jetty/HttpFields;","formatDate",new String[]{ "Ljava/lang/StringBuffer;","Ljava/util/Calendar;","Z"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(14);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"buf");
                ddv.visitParameterName(1,"calendar");
                ddv.visitParameterName(2,"cookie");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(119,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(120,L1);
                ddv.visitStartLocal(2,L1,"day_of_week","I",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(121,L2);
                ddv.visitStartLocal(1,L2,"day_of_month","I",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(122,L3);
                ddv.visitStartLocal(4,L3,"month","I",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(123,L4);
                ddv.visitStartLocal(3,L4,"year","I",null);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(124,L5);
                ddv.visitStartLocal(0,L5,"century","I",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(126,L6);
                ddv.visitStartLocal(6,L6,"year","I",null);
                DexLabel L7=new DexLabel();
                ddv.visitEndLocal(3,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(127,L8);
                ddv.visitStartLocal(12,L8,"epoch","I",null);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(128,L9);
                ddv.visitStartLocal(5,L9,"seconds","I",null);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(129,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(130,L11);
                ddv.visitStartLocal(3,L11,"minutes","I",null);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(132,L12);
                ddv.visitStartLocal(12,L12,"hours","I",null);
                DexLabel L13=new DexLabel();
                ddv.visitEndLocal(2,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(133,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(134,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(135,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(137,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(139,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(140,L19);
                ddv.visitEndLocal(13,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(141,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(142,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(152,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(153,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(154,L24);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(155,L25);
                ddv.visitEndLocal(12,L25);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(156,L26);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(157,L27);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(158,L28);
                DexLabel L29=new DexLabel();
                ddv.visitLineNumber(159,L29);
                DexLabel L30=new DexLabel();
                ddv.visitLineNumber(146,L30);
                ddv.visitRestartLocal(12,L30);
                ddv.visitRestartLocal(13,L30);
                DexLabel L31=new DexLabel();
                ddv.visitLineNumber(147,L31);
                ddv.visitEndLocal(13,L31);
                DexLabel L32=new DexLabel();
                ddv.visitLineNumber(148,L32);
                DexLabel L33=new DexLabel();
                ddv.visitLineNumber(149,L33);
                DexLabel L34=new DexLabel();
                ddv.visitLineNumber(150,L34);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(7)); // int: 0x00000007  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12,0},new Method("Ljava/util/Calendar;","get",new String[]{ "I"},"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(5)); // int: 0x00000005  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12,0},new Method("Ljava/util/Calendar;","get",new String[]{ "I"},"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitLabel(L2);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12,0},new Method("Ljava/util/Calendar;","get",new String[]{ "I"},"I"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12,0},new Method("Ljava/util/Calendar;","get",new String[]{ "I"},"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitLabel(L4);
                code.visitStmt2R1N(DIV_INT_LIT8,0,3,100);
                code.visitLabel(L5);
                code.visitStmt2R1N(REM_INT_LIT8,6,3,100);
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12},new Method("Ljava/util/Calendar;","getTimeInMillis",new String[]{ },"J"));
                code.visitLabel(L7);
                code.visitStmt1R(MOVE_RESULT_WIDE,7);
                code.visitConstStmt(CONST_WIDE_16,9,Long.valueOf(1000L)); // long: 0x00000000000003e8  double:0.000000
                code.visitStmt2R(DIV_LONG_2ADDR,7,9);
                code.visitConstStmt(CONST_WIDE_32,9,Long.valueOf(86400L)); // long: 0x0000000000015180  double:0.000000
                code.visitStmt2R(REM_LONG_2ADDR,7,9);
                code.visitStmt2R(LONG_TO_INT,12,7);
                code.visitLabel(L8);
                code.visitStmt2R1N(REM_INT_LIT8,5,12,60);
                code.visitLabel(L9);
                code.visitStmt2R1N(DIV_INT_LIT8,12,12,60);
                code.visitLabel(L10);
                code.visitStmt2R1N(REM_INT_LIT8,3,12,60);
                code.visitLabel(L11);
                code.visitStmt2R1N(DIV_INT_LIT8,12,12,60);
                code.visitLabel(L12);
                code.visitFieldStmt(SGET_OBJECT,7,-1,new Field("Lorg/mortbay/jetty/HttpFields;","DAYS","[Ljava/lang/String;"));
                code.visitStmt3R(AGET_OBJECT,2,7,2);
                code.visitLabel(L13);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11,2},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L14);
                code.visitConstStmt(CONST_16,2, Integer.valueOf(44)); // int: 0x0000002c  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11,2},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "C"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L15);
                code.visitConstStmt(CONST_16,2, Integer.valueOf(32)); // int: 0x00000020  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11,2},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "C"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L16);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 11,1},new Method("Lorg/mortbay/util/StringUtil;","append2digits",new String[]{ "Ljava/lang/StringBuffer;","I"},"V"));
                code.visitLabel(L17);
                code.visitJumpStmt(IF_EQZ,13,-1,L30);
                code.visitLabel(L18);
                code.visitConstStmt(CONST_16,13, Integer.valueOf(45)); // int: 0x0000002d  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11,13},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "C"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L19);
                code.visitFieldStmt(SGET_OBJECT,13,-1,new Field("Lorg/mortbay/jetty/HttpFields;","MONTHS","[Ljava/lang/String;"));
                code.visitStmt3R(AGET_OBJECT,13,13,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11,13},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L20);
                code.visitConstStmt(CONST_16,13, Integer.valueOf(45)); // int: 0x0000002d  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11,13},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "C"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L21);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 11,6},new Method("Lorg/mortbay/util/StringUtil;","append2digits",new String[]{ "Ljava/lang/StringBuffer;","I"},"V"));
                code.visitLabel(L22);
                code.visitConstStmt(CONST_16,13, Integer.valueOf(32)); // int: 0x00000020  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11,13},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "C"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L23);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 11,12},new Method("Lorg/mortbay/util/StringUtil;","append2digits",new String[]{ "Ljava/lang/StringBuffer;","I"},"V"));
                code.visitLabel(L24);
                code.visitConstStmt(CONST_16,12, Integer.valueOf(58)); // int: 0x0000003a  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11,12},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "C"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L25);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 11,3},new Method("Lorg/mortbay/util/StringUtil;","append2digits",new String[]{ "Ljava/lang/StringBuffer;","I"},"V"));
                code.visitLabel(L26);
                code.visitConstStmt(CONST_16,12, Integer.valueOf(58)); // int: 0x0000003a  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11,12},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "C"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L27);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 11,5},new Method("Lorg/mortbay/util/StringUtil;","append2digits",new String[]{ "Ljava/lang/StringBuffer;","I"},"V"));
                code.visitLabel(L28);
                code.visitConstStmt(CONST_STRING,12," GMT");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11,12},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L29);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L30);
                code.visitConstStmt(CONST_16,13, Integer.valueOf(32)); // int: 0x00000020  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11,13},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "C"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L31);
                code.visitFieldStmt(SGET_OBJECT,13,-1,new Field("Lorg/mortbay/jetty/HttpFields;","MONTHS","[Ljava/lang/String;"));
                code.visitStmt3R(AGET_OBJECT,13,13,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11,13},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L32);
                code.visitConstStmt(CONST_16,13, Integer.valueOf(32)); // int: 0x00000020  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11,13},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "C"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L33);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 11,0},new Method("Lorg/mortbay/util/StringUtil;","append2digits",new String[]{ "Ljava/lang/StringBuffer;","I"},"V"));
                code.visitLabel(L34);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 11,6},new Method("Lorg/mortbay/util/StringUtil;","append2digits",new String[]{ "Ljava/lang/StringBuffer;","I"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L22);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m007_getField(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PRIVATE, new Method("Lorg/mortbay/jetty/HttpFields;","getField",new String[]{ "Ljava/lang/String;"},"Lorg/mortbay/jetty/HttpFields$Field;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(301,L0);
                DexLabel L1=new DexLabel();
                ddv.visitEndLocal(2,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/HttpFields;","_bufferMap","Ljava/util/HashMap;"));
                code.visitFieldStmt(SGET_OBJECT,1,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","CACHE","Lorg/mortbay/jetty/HttpHeaders;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,3},new Method("Lorg/mortbay/jetty/HttpHeaders;","lookup",new String[]{ "Ljava/lang/String;"},"Lorg/mortbay/io/Buffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/util/HashMap;","get",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L1);
                code.visitTypeStmt(CHECK_CAST,2,-1,"Lorg/mortbay/jetty/HttpFields$Field;");
                code.visitStmt1R(RETURN_OBJECT,2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m008_getField(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PRIVATE, new Method("Lorg/mortbay/jetty/HttpFields;","getField",new String[]{ "Lorg/mortbay/io/Buffer;"},"Lorg/mortbay/jetty/HttpFields$Field;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(307,L0);
                DexLabel L1=new DexLabel();
                ddv.visitEndLocal(1,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/HttpFields;","_bufferMap","Ljava/util/HashMap;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,2},new Method("Ljava/util/HashMap;","get",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L1);
                code.visitTypeStmt(CHECK_CAST,1,-1,"Lorg/mortbay/jetty/HttpFields$Field;");
                code.visitStmt1R(RETURN_OBJECT,1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m009_getQuality(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/jetty/HttpFields;","getQuality",new String[]{ "Ljava/lang/String;"},"Ljava/lang/Float;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(10);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/lang/Exception;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"value");
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(1184,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(1211,L4);
                ddv.visitEndLocal(9,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(1186,L5);
                ddv.visitRestartLocal(9,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(1187,L6);
                ddv.visitStartLocal(4,L6,"qe","I",null);
                DexLabel L7=new DexLabel();
                ddv.visitStartLocal(5,L7,"qe","I",null);
                DexLabel L8=new DexLabel();
                ddv.visitEndLocal(4,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(1189,L9);
                DexLabel L10=new DexLabel();
                ddv.visitRestartLocal(4,L10);
                DexLabel L11=new DexLabel();
                ddv.visitEndLocal(5,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(1191,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(1192,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(1193,L14);
                ddv.visitStartLocal(1,L14,"entry","Ljava/util/Map$Entry;",null);
                DexLabel L15=new DexLabel();
                ddv.visitEndLocal(9,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(1196,L16);
                ddv.visitEndLocal(1,L16);
                ddv.visitRestartLocal(9,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(1197,L17);
                ddv.visitStartLocal(2,L17,"params","Ljava/util/HashMap;",null);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(1198,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(1199,L19);
                ddv.visitStartLocal(6,L19,"qs","Ljava/lang/String;",null);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(1200,L20);
                ddv.visitStartLocal(3,L20,"q","Ljava/lang/Float;",null);
                ddv.visitLineNumber(1204,L0);
                DexLabel L21=new DexLabel();
                ddv.visitEndLocal(3,L21);
                ddv.visitRestartLocal(3,L1);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(1211,L22);
                ddv.visitLineNumber(1206,L2);
                ddv.visitEndLocal(3,L2);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(1208,L23);
                ddv.visitStartLocal(0,L23,"e","Ljava/lang/Exception;",null);
                DexLabel L24=new DexLabel();
                ddv.visitRestartLocal(3,L24);
                code.visitLabel(L3);
                code.visitJumpStmt(IF_NEZ,9,-1,L5);
                code.visitFieldStmt(SGET_OBJECT,7,-1,new Field("Lorg/mortbay/jetty/HttpFields;","__zero","Ljava/lang/Float;"));
                code.visitLabel(L4);
                code.visitStmt1R(RETURN_OBJECT,7);
                code.visitLabel(L5);
                code.visitConstStmt(CONST_STRING,7,";");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9,7},new Method("Ljava/lang/String;","indexOf",new String[]{ "Ljava/lang/String;"},"I"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitLabel(L6);
                code.visitStmt2R1N(ADD_INT_LIT8,5,4,1);
                code.visitLabel(L7);
                DexLabel L25=new DexLabel();
                code.visitJumpStmt(IF_LTZ,4,-1,L25);
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitJumpStmt(IF_NE,5,7,L9);
                code.visitLabel(L25);
                code.visitFieldStmt(SGET_OBJECT,7,-1,new Field("Lorg/mortbay/jetty/HttpFields;","__one","Ljava/lang/Float;"));
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitLabel(L9);
                code.visitStmt2R1N(ADD_INT_LIT8,4,5,1);
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9,5},new Method("Ljava/lang/String;","charAt",new String[]{ "I"},"C"));
                code.visitLabel(L11);
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitConstStmt(CONST_16,8, Integer.valueOf(113)); // int: 0x00000071  float:0.000000
                code.visitJumpStmt(IF_NE,7,8,L16);
                code.visitLabel(L12);
                code.visitStmt2R1N(ADD_INT_LIT8,4,4,1);
                code.visitLabel(L13);
                code.visitFieldStmt(SGET_OBJECT,7,-1,new Field("Lorg/mortbay/jetty/HttpFields;","__qualities","Lorg/mortbay/util/StringMap;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitStmt2R(SUB_INT_2ADDR,8,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,9,4,8},new Method("Lorg/mortbay/util/StringMap;","getEntry",new String[]{ "Ljava/lang/String;","I","I"},"Ljava/util/Map$Entry;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L14);
                code.visitJumpStmt(IF_EQZ,1,-1,L16);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Ljava/util/Map$Entry;","getValue",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitLabel(L15);
                code.visitTypeStmt(CHECK_CAST,9,-1,"Ljava/lang/Float;");
                code.visitStmt2R(MOVE_OBJECT,7,9);
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitLabel(L16);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Ljava/util/HashMap;");
                code.visitConstStmt(CONST_4,7, Integer.valueOf(3)); // int: 0x00000003  float:0.000000
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2,7},new Method("Ljava/util/HashMap;","<init>",new String[]{ "I"},"V"));
                code.visitLabel(L17);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 9,2},new Method("Lorg/mortbay/jetty/HttpFields;","valueParameters",new String[]{ "Ljava/lang/String;","Ljava/util/Map;"},"Ljava/lang/String;"));
                code.visitLabel(L18);
                code.visitConstStmt(CONST_STRING,7,"q");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,7},new Method("Ljava/util/HashMap;","get",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitTypeStmt(CHECK_CAST,6,-1,"Ljava/lang/String;");
                code.visitLabel(L19);
                code.visitFieldStmt(SGET_OBJECT,7,-1,new Field("Lorg/mortbay/jetty/HttpFields;","__qualities","Lorg/mortbay/util/StringMap;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,6},new Method("Lorg/mortbay/util/StringMap;","get",new String[]{ "Ljava/lang/String;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitTypeStmt(CHECK_CAST,3,-1,"Ljava/lang/Float;");
                code.visitLabel(L20);
                code.visitJumpStmt(IF_NEZ,3,-1,L1);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Ljava/lang/Float;");
                code.visitLabel(L21);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3,6},new Method("Ljava/lang/Float;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L1);
                code.visitStmt2R(MOVE_OBJECT,7,3);
                code.visitLabel(L22);
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,7);
                code.visitStmt2R(MOVE_OBJECT,0,7);
                code.visitLabel(L23);
                code.visitFieldStmt(SGET_OBJECT,3,-1,new Field("Lorg/mortbay/jetty/HttpFields;","__one","Ljava/lang/Float;"));
                code.visitLabel(L24);
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m010_qualityList(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/jetty/HttpFields;","qualityList",new String[]{ "Ljava/util/Enumeration;"},"Ljava/util/List;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(10);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"e");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1223,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(1265,L1);
                ddv.visitEndLocal(9,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(1225,L2);
                ddv.visitRestartLocal(9,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(1226,L3);
                ddv.visitStartLocal(0,L3,"list","Ljava/lang/Object;",null);
                DexLabel L4=new DexLabel();
                ddv.visitStartLocal(1,L4,"qual","Ljava/lang/Object;",null);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(1229,L5);
                ddv.visitEndLocal(0,L5);
                ddv.visitEndLocal(1,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(1231,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(1232,L7);
                ddv.visitStartLocal(0,L7,"v","Ljava/lang/String;",null);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(1234,L8);
                ddv.visitStartLocal(1,L8,"q","Ljava/lang/Float;",null);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(1236,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(1237,L10);
                ddv.visitStartLocal(0,L10,"list","Ljava/lang/Object;",null);
                DexLabel L11=new DexLabel();
                ddv.visitStartLocal(1,L11,"qual","Ljava/lang/Object;",null);
                DexLabel L12=new DexLabel();
                ddv.visitEndLocal(0,L12);
                ddv.visitEndLocal(1,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(1239,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(1241,L14);
                DexLabel L15=new DexLabel();
                ddv.visitEndLocal(9,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(1242,L16);
                ddv.visitStartLocal(3,L16,"vl","Ljava/util/List;",null);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(1244,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(1247,L18);
                ddv.visitStartLocal(2,L18,"ql","Ljava/util/List;",null);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(1248,L19);
                ddv.visitStartLocal(0,L19,"last","Ljava/lang/Float;",null);
                DexLabel L20=new DexLabel();
                ddv.visitStartLocal(9,L20,"i","I",null);
                DexLabel L21=new DexLabel();
                ddv.visitStartLocal(1,L21,"last","Ljava/lang/Float;",null);
                DexLabel L22=new DexLabel();
                ddv.visitEndLocal(9,L22);
                ddv.visitStartLocal(0,L22,"i","I",null);
                DexLabel L23=new DexLabel();
                ddv.visitRestartLocal(9,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(1250,L24);
                ddv.visitEndLocal(0,L24);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(1251,L25);
                ddv.visitStartLocal(0,L25,"q","Ljava/lang/Float;",null);
                DexLabel L26=new DexLabel();
                ddv.visitEndLocal(1,L26);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(1253,L27);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(1254,L28);
                ddv.visitStartLocal(1,L28,"tmp","Ljava/lang/Object;",null);
                DexLabel L29=new DexLabel();
                ddv.visitLineNumber(1255,L29);
                DexLabel L30=new DexLabel();
                ddv.visitLineNumber(1256,L30);
                DexLabel L31=new DexLabel();
                ddv.visitEndLocal(1,L31);
                DexLabel L32=new DexLabel();
                ddv.visitLineNumber(1257,L32);
                DexLabel L33=new DexLabel();
                ddv.visitLineNumber(1258,L33);
                ddv.visitEndLocal(9,L33);
                DexLabel L34=new DexLabel();
                ddv.visitLineNumber(1259,L34);
                ddv.visitStartLocal(0,L34,"last","Ljava/lang/Float;",null);
                DexLabel L35=new DexLabel();
                ddv.visitRestartLocal(9,L35);
                DexLabel L36=new DexLabel();
                ddv.visitStartLocal(1,L36,"last","Ljava/lang/Float;",null);
                DexLabel L37=new DexLabel();
                ddv.visitLineNumber(1260,L37);
                ddv.visitStartLocal(0,L37,"i","I",null);
                DexLabel L38=new DexLabel();
                ddv.visitLineNumber(1262,L38);
                ddv.visitEndLocal(1,L38);
                ddv.visitStartLocal(0,L38,"q","Ljava/lang/Float;",null);
                DexLabel L39=new DexLabel();
                ddv.visitStartLocal(0,L39,"last","Ljava/lang/Float;",null);
                DexLabel L40=new DexLabel();
                ddv.visitRestartLocal(1,L40);
                DexLabel L41=new DexLabel();
                ddv.visitLineNumber(1263,L41);
                ddv.visitStartLocal(0,L41,"i","I",null);
                DexLabel L42=new DexLabel();
                ddv.visitLineNumber(1264,L42);
                ddv.visitEndLocal(0,L42);
                DexLabel L43=new DexLabel();
                ddv.visitLineNumber(1265,L43);
                DexLabel L44=new DexLabel();
                ddv.visitEndLocal(3,L44);
                ddv.visitEndLocal(2,L44);
                ddv.visitStartLocal(0,L44,"v","Ljava/lang/String;",null);
                ddv.visitStartLocal(1,L44,"q","Ljava/lang/Float;",null);
                ddv.visitStartLocal(9,L44,"e","Ljava/util/Enumeration;",null);
                code.visitLabel(L0);
                DexLabel L45=new DexLabel();
                code.visitJumpStmt(IF_EQZ,9,-1,L45);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 9},new Method("Ljava/util/Enumeration;","hasMoreElements",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_NEZ,0,-1,L2);
                code.visitLabel(L45);
                code.visitFieldStmt(SGET_OBJECT,9,-1,new Field("Ljava/util/Collections;","EMPTY_LIST","Ljava/util/List;"));
                code.visitLabel(L1);
                code.visitStmt1R(RETURN_OBJECT,9);
                code.visitLabel(L2);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L4);
                code.visitStmt2R(MOVE_OBJECT,2,1);
                code.visitStmt2R(MOVE_OBJECT,3,0);
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 9},new Method("Ljava/util/Enumeration;","hasMoreElements",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L14);
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 9},new Method("Ljava/util/Enumeration;","nextElement",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/Object;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/jetty/HttpFields;","getQuality",new String[]{ "Ljava/lang/String;"},"Ljava/lang/Float;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/lang/Float;","floatValue",new String[]{ },"F"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitStmt2R(FLOAT_TO_DOUBLE,4,4);
                code.visitConstStmt(CONST_WIDE,6,Long.valueOf(4562254508917369340L)); // long: 0x3f50624dd2f1a9fc  double:0.001000
                code.visitStmt3R(CMPL_DOUBLE,4,4,6);
                code.visitJumpStmt(IF_LTZ,4,-1,L44);
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3,0},new Method("Lorg/mortbay/util/LazyList;","add",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2,1},new Method("Lorg/mortbay/util/LazyList;","add",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L11);
                code.visitStmt2R(MOVE_OBJECT,8,1);
                code.visitStmt2R(MOVE_OBJECT,1,0);
                code.visitStmt2R(MOVE_OBJECT,0,8);
                code.visitLabel(L12);
                code.visitStmt2R(MOVE_OBJECT,2,0);
                code.visitStmt2R(MOVE_OBJECT,3,1);
                code.visitLabel(L13);
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitLabel(L14);
                code.visitConstStmt(CONST_4,9, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3,9},new Method("Lorg/mortbay/util/LazyList;","getList",new String[]{ "Ljava/lang/Object;","Z"},"Ljava/util/List;"));
                code.visitLabel(L15);
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitLabel(L16);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3},new Method("Ljava/util/List;","size",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,9);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitJumpStmt(IF_GE,9,0,L17);
                code.visitStmt2R(MOVE_OBJECT,9,3);
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitLabel(L17);
                code.visitConstStmt(CONST_4,9, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2,9},new Method("Lorg/mortbay/util/LazyList;","getList",new String[]{ "Ljava/lang/Object;","Z"},"Ljava/util/List;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L18);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpFields;","__zero","Ljava/lang/Float;"));
                code.visitLabel(L19);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3},new Method("Ljava/util/List;","size",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,9);
                code.visitLabel(L20);
                code.visitStmt2R(MOVE_OBJECT,1,0);
                code.visitLabel(L21);
                code.visitStmt2R(MOVE,0,9);
                code.visitLabel(L22);
                code.visitConstStmt(CONST_4,9, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt3R(SUB_INT,9,0,9);
                code.visitLabel(L23);
                code.visitJumpStmt(IF_LEZ,0,-1,L42);
                code.visitLabel(L24);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2,9},new Method("Ljava/util/List;","get",new String[]{ "I"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Ljava/lang/Float;");
                code.visitLabel(L25);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,0},new Method("Ljava/lang/Float;","compareTo",new String[]{ "Ljava/lang/Float;"},"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitLabel(L26);
                code.visitJumpStmt(IF_LEZ,1,-1,L38);
                code.visitLabel(L27);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3,9},new Method("Ljava/util/List;","get",new String[]{ "I"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L28);
                code.visitStmt2R1N(ADD_INT_LIT8,4,9,1);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3,4},new Method("Ljava/util/List;","get",new String[]{ "I"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3,9,4},new Method("Ljava/util/List;","set",new String[]{ "I","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L29);
                code.visitStmt2R1N(ADD_INT_LIT8,4,9,1);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3,4,1},new Method("Ljava/util/List;","set",new String[]{ "I","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L30);
                code.visitStmt2R1N(ADD_INT_LIT8,1,9,1);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2,1},new Method("Ljava/util/List;","get",new String[]{ "I"},"Ljava/lang/Object;"));
                code.visitLabel(L31);
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2,9,1},new Method("Ljava/util/List;","set",new String[]{ "I","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L32);
                code.visitStmt2R1N(ADD_INT_LIT8,9,9,1);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2,9,0},new Method("Ljava/util/List;","set",new String[]{ "I","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L33);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpFields;","__zero","Ljava/lang/Float;"));
                code.visitLabel(L34);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3},new Method("Ljava/util/List;","size",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,9);
                code.visitLabel(L35);
                code.visitStmt2R(MOVE_OBJECT,1,0);
                code.visitLabel(L36);
                code.visitStmt2R(MOVE,0,9);
                code.visitLabel(L37);
                code.visitJumpStmt(GOTO,-1,-1,L22);
                code.visitLabel(L38);
                code.visitStmt2R(MOVE_OBJECT,0,0);
                code.visitLabel(L39);
                code.visitStmt2R(MOVE_OBJECT,1,0);
                code.visitLabel(L40);
                code.visitStmt2R(MOVE,0,9);
                code.visitLabel(L41);
                code.visitJumpStmt(GOTO,-1,-1,L22);
                code.visitLabel(L42);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2},new Method("Ljava/util/List;","clear",new String[]{ },"V"));
                code.visitStmt2R(MOVE_OBJECT,9,3);
                code.visitLabel(L43);
                code.visitJumpStmt(GOTO_16,-1,-1,L1);
                code.visitLabel(L44);
                code.visitStmt2R(MOVE_OBJECT,0,2);
                code.visitStmt2R(MOVE_OBJECT,1,3);
                code.visitJumpStmt(GOTO,-1,-1,L12);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m011_valueParameters(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/jetty/HttpFields;","valueParameters",new String[]{ "Ljava/lang/String;","Ljava/util/Map;"},"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(12);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"value");
                ddv.visitParameterName(1,"parameters");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(1134,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(1154,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(1136,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(1137,L4);
                ddv.visitStartLocal(0,L4,"i","I",null);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(1138,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(1140,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(1141,L7);
                ddv.visitStartLocal(3,L7,"tok1","Ljava/util/StringTokenizer;",null);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(1143,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(1144,L9);
                ddv.visitStartLocal(5,L9,"token","Ljava/lang/String;",null);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(1145,L10);
                ddv.visitStartLocal(4,L10,"tok2","Ljava/util/StringTokenizer;",null);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(1147,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(1148,L12);
                ddv.visitStartLocal(1,L12,"paramName","Ljava/lang/String;",null);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(1149,L13);
                ddv.visitStartLocal(2,L13,"paramVal","Ljava/lang/String;",null);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(1150,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(1154,L15);
                ddv.visitEndLocal(5,L15);
                ddv.visitEndLocal(4,L15);
                ddv.visitEndLocal(1,L15);
                ddv.visitEndLocal(2,L15);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,9, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitJumpStmt(IF_NEZ,10,-1,L3);
                code.visitConstStmt(CONST_4,6, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L2);
                code.visitStmt1R(RETURN_OBJECT,6);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_16,6, Integer.valueOf(59)); // int: 0x0000003b  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10,6},new Method("Ljava/lang/String;","indexOf",new String[]{ "I"},"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitLabel(L4);
                code.visitJumpStmt(IF_GEZ,0,-1,L5);
                code.visitStmt2R(MOVE_OBJECT,6,10);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L5);
                code.visitJumpStmt(IF_NEZ,11,-1,L6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10,9,0},new Method("Ljava/lang/String;","substring",new String[]{ "I","I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/lang/String;","trim",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L6);
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Lorg/mortbay/util/QuotedStringTokenizer;");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10,0},new Method("Ljava/lang/String;","substring",new String[]{ "I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitConstStmt(CONST_STRING,7,";");
                code.visitConstStmt(CONST_4,8, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3,6,7,9,8},new Method("Lorg/mortbay/util/QuotedStringTokenizer;","<init>",new String[]{ "Ljava/lang/String;","Ljava/lang/String;","Z","Z"},"V"));
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/util/StringTokenizer;","hasMoreTokens",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitJumpStmt(IF_EQZ,6,-1,L15);
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/util/StringTokenizer;","nextToken",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitLabel(L9);
                code.visitTypeStmt(NEW_INSTANCE,4,-1,"Lorg/mortbay/util/QuotedStringTokenizer;");
                code.visitConstStmt(CONST_STRING,6,"= ");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4,5,6},new Method("Lorg/mortbay/util/QuotedStringTokenizer;","<init>",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"V"));
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/util/StringTokenizer;","hasMoreTokens",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitJumpStmt(IF_EQZ,6,-1,L7);
                code.visitLabel(L11);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/util/StringTokenizer;","nextToken",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L12);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L13);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/util/StringTokenizer;","hasMoreTokens",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitJumpStmt(IF_EQZ,6,-1,L14);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/util/StringTokenizer;","nextToken",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L14);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 11,1,2},new Method("Ljava/util/Map;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitJumpStmt(GOTO,-1,-1,L7);
                code.visitLabel(L15);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10,9,0},new Method("Ljava/lang/String;","substring",new String[]{ "I","I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/lang/String;","trim",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m012_add(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpFields;","add",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/IllegalArgumentException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                ddv.visitParameterName(1,"value");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(611,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(612,L1);
                ddv.visitStartLocal(0,L1,"n","Lorg/mortbay/io/Buffer;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(613,L2);
                ddv.visitStartLocal(1,L2,"v","Lorg/mortbay/io/Buffer;",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(614,L3);
                code.visitLabel(L0);
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","CACHE","Lorg/mortbay/jetty/HttpHeaders;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,5},new Method("Lorg/mortbay/jetty/HttpHeaders;","lookup",new String[]{ "Ljava/lang/String;"},"Lorg/mortbay/io/Buffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L1);
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/jetty/HttpHeaderValues;","CACHE","Lorg/mortbay/jetty/HttpHeaderValues;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,6},new Method("Lorg/mortbay/jetty/HttpHeaderValues;","lookup",new String[]{ "Ljava/lang/String;"},"Lorg/mortbay/io/Buffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L2);
                code.visitConstStmt(CONST_WIDE_16,2,Long.valueOf(-1L)); // long: 0xffffffffffffffff  double:NaN
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4,0,1,2,3},new Method("Lorg/mortbay/jetty/HttpFields;","add",new String[]{ "Lorg/mortbay/io/Buffer;","Lorg/mortbay/io/Buffer;","J"},"V"));
                code.visitLabel(L3);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m013_add(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpFields;","add",new String[]{ "Lorg/mortbay/io/Buffer;","Lorg/mortbay/io/Buffer;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/IllegalArgumentException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                ddv.visitParameterName(1,"value");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(628,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(629,L1);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_WIDE_16,0,Long.valueOf(-1L)); // long: 0xffffffffffffffff  double:NaN
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2,3,4,0,1},new Method("Lorg/mortbay/jetty/HttpFields;","add",new String[]{ "Lorg/mortbay/io/Buffer;","Lorg/mortbay/io/Buffer;","J"},"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m014_add(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpFields;","add",new String[]{ "Lorg/mortbay/jetty/HttpFields;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"fields");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1105,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(1115,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(1107,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(1108,L3);
                ddv.visitStartLocal(0,L3,"e","Ljava/util/Enumeration;",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(1110,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(1111,L5);
                ddv.visitStartLocal(1,L5,"name","Ljava/lang/String;",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(1112,L6);
                ddv.visitStartLocal(2,L6,"values","Ljava/util/Enumeration;",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(1113,L7);
                code.visitLabel(L0);
                code.visitJumpStmt(IF_NEZ,5,-1,L2);
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/jetty/HttpFields;","getFieldNames",new String[]{ },"Ljava/util/Enumeration;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Ljava/util/Enumeration;","hasMoreElements",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_EQZ,3,-1,L1);
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Ljava/util/Enumeration;","nextElement",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitTypeStmt(CHECK_CAST,1,-1,"Ljava/lang/String;");
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,1},new Method("Lorg/mortbay/jetty/HttpFields;","getValues",new String[]{ "Ljava/lang/String;"},"Ljava/util/Enumeration;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2},new Method("Ljava/util/Enumeration;","hasMoreElements",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_EQZ,3,-1,L3);
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2},new Method("Ljava/util/Enumeration;","nextElement",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitTypeStmt(CHECK_CAST,3,-1,"Ljava/lang/String;");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,1,3},new Method("Lorg/mortbay/jetty/HttpFields;","add",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L6);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m015_addDateField(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpFields;","addDateField",new String[]{ "Ljava/lang/String;","J"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(9);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                ddv.visitParameterName(1,"date");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(931,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(933,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(934,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(936,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(937,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(938,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(939,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(940,L8);
                ddv.visitStartLocal(0,L8,"n","Lorg/mortbay/io/Buffer;",null);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(941,L9);
                ddv.visitStartLocal(1,L9,"v","Lorg/mortbay/io/Buffer;",null);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(942,L10);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/jetty/HttpFields;","_dateBuffer","Ljava/lang/StringBuffer;"));
                code.visitJumpStmt(IF_NEZ,2,-1,L4);
                code.visitLabel(L2);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Ljava/lang/StringBuffer;");
                code.visitConstStmt(CONST_16,3, Integer.valueOf(32)); // int: 0x00000020  float:0.000000
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2,3},new Method("Ljava/lang/StringBuffer;","<init>",new String[]{ "I"},"V"));
                code.visitFieldStmt(IPUT_OBJECT,2,5,new Field("Lorg/mortbay/jetty/HttpFields;","_dateBuffer","Ljava/lang/StringBuffer;"));
                code.visitLabel(L3);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Ljava/util/GregorianCalendar;");
                code.visitFieldStmt(SGET_OBJECT,3,-1,new Field("Lorg/mortbay/jetty/HttpFields;","__GMT","Ljava/util/TimeZone;"));
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2,3},new Method("Ljava/util/GregorianCalendar;","<init>",new String[]{ "Ljava/util/TimeZone;"},"V"));
                code.visitFieldStmt(IPUT_OBJECT,2,5,new Field("Lorg/mortbay/jetty/HttpFields;","_calendar","Ljava/util/Calendar;"));
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/jetty/HttpFields;","_dateBuffer","Ljava/lang/StringBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,4},new Method("Ljava/lang/StringBuffer;","setLength",new String[]{ "I"},"V"));
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/jetty/HttpFields;","_calendar","Ljava/util/Calendar;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,7,8},new Method("Ljava/util/Calendar;","setTimeInMillis",new String[]{ "J"},"V"));
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/jetty/HttpFields;","_dateBuffer","Ljava/lang/StringBuffer;"));
                code.visitFieldStmt(IGET_OBJECT,3,5,new Field("Lorg/mortbay/jetty/HttpFields;","_calendar","Ljava/util/Calendar;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2,3,4},new Method("Lorg/mortbay/jetty/HttpFields;","formatDate",new String[]{ "Ljava/lang/StringBuffer;","Ljava/util/Calendar;","Z"},"V"));
                code.visitLabel(L7);
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","CACHE","Lorg/mortbay/jetty/HttpHeaders;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,6},new Method("Lorg/mortbay/jetty/HttpHeaders;","lookup",new String[]{ "Ljava/lang/String;"},"Lorg/mortbay/io/Buffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L8);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Lorg/mortbay/io/ByteArrayBuffer;");
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/jetty/HttpFields;","_dateBuffer","Ljava/lang/StringBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/lang/StringBuffer;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,2},new Method("Lorg/mortbay/io/ByteArrayBuffer;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 5,0,1,7,8},new Method("Lorg/mortbay/jetty/HttpFields;","add",new String[]{ "Lorg/mortbay/io/Buffer;","Lorg/mortbay/io/Buffer;","J"},"V"));
                code.visitLabel(L10);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m016_addLongField(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpFields;","addLongField",new String[]{ "Ljava/lang/String;","J"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                ddv.visitParameterName(1,"value");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(870,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(871,L1);
                ddv.visitStartLocal(0,L1,"n","Lorg/mortbay/io/Buffer;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(872,L2);
                ddv.visitStartLocal(1,L2,"v","Lorg/mortbay/io/Buffer;",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(873,L3);
                code.visitLabel(L0);
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","CACHE","Lorg/mortbay/jetty/HttpHeaders;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,4},new Method("Lorg/mortbay/jetty/HttpHeaders;","lookup",new String[]{ "Ljava/lang/String;"},"Lorg/mortbay/io/Buffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 5,6},new Method("Lorg/mortbay/io/BufferUtil;","toBuffer",new String[]{ "J"},"Lorg/mortbay/io/Buffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3,0,1,5,6},new Method("Lorg/mortbay/jetty/HttpFields;","add",new String[]{ "Lorg/mortbay/io/Buffer;","Lorg/mortbay/io/Buffer;","J"},"V"));
                code.visitLabel(L3);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m017_addLongField(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpFields;","addLongField",new String[]{ "Lorg/mortbay/io/Buffer;","J"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                ddv.visitParameterName(1,"value");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(884,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(885,L1);
                ddv.visitStartLocal(0,L1,"v","Lorg/mortbay/io/Buffer;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(886,L2);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3,4},new Method("Lorg/mortbay/io/BufferUtil;","toBuffer",new String[]{ "J"},"Lorg/mortbay/io/Buffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,2,0,3,4},new Method("Lorg/mortbay/jetty/HttpFields;","add",new String[]{ "Lorg/mortbay/io/Buffer;","Lorg/mortbay/io/Buffer;","J"},"V"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m018_addSetCookie(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpFields;","addSetCookie",new String[]{ "Ljavax/servlet/http/Cookie;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(16);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L2},new String[]{ null});
                DexLabel L5=new DexLabel();
                DexLabel L6=new DexLabel();
                code.visitTryCatch(L5,L6,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"cookie");
                DexLabel L7=new DexLabel();
                ddv.visitPrologue(L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(953,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(954,L9);
                ddv.visitStartLocal(5,L9,"name","Ljava/lang/String;",null);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(955,L10);
                ddv.visitStartLocal(8,L10,"value","Ljava/lang/String;",null);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(958,L11);
                ddv.visitStartLocal(9,L11,"version","I",null);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(961,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(962,L13);
                ddv.visitStartLocal(0,L13,"buf","Ljava/lang/StringBuffer;",null);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(963,L14);
                ddv.visitStartLocal(6,L14,"name_value_params","Ljava/lang/String;",null);
                ddv.visitLineNumber(965,L0);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(966,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(967,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(968,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(970,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(972,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(973,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(974,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(975,L22);
                ddv.visitStartLocal(1,L22,"comment","Ljava/lang/String;",null);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(977,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(978,L24);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(981,L25);
                ddv.visitEndLocal(1,L25);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(982,L26);
                ddv.visitStartLocal(7,L26,"path","Ljava/lang/String;",null);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(984,L27);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(985,L28);
                DexLabel L29=new DexLabel();
                ddv.visitLineNumber(987,L29);
                DexLabel L30=new DexLabel();
                ddv.visitLineNumber(988,L30);
                ddv.visitStartLocal(2,L30,"domain","Ljava/lang/String;",null);
                DexLabel L31=new DexLabel();
                ddv.visitLineNumber(990,L31);
                DexLabel L32=new DexLabel();
                ddv.visitLineNumber(991,L32);
                DexLabel L33=new DexLabel();
                ddv.visitLineNumber(994,L33);
                DexLabel L34=new DexLabel();
                ddv.visitLineNumber(995,L34);
                ddv.visitStartLocal(3,L34,"maxAge","J",null);
                DexLabel L35=new DexLabel();
                ddv.visitLineNumber(997,L35);
                DexLabel L36=new DexLabel();
                ddv.visitLineNumber(999,L36);
                DexLabel L37=new DexLabel();
                ddv.visitLineNumber(1000,L37);
                DexLabel L38=new DexLabel();
                ddv.visitLineNumber(1001,L38);
                DexLabel L39=new DexLabel();
                ddv.visitLineNumber(1016,L39);
                DexLabel L40=new DexLabel();
                ddv.visitLineNumber(1018,L40);
                DexLabel L41=new DexLabel();
                ddv.visitLineNumber(1020,L41);
                DexLabel L42=new DexLabel();
                ddv.visitLineNumber(1021,L42);
                DexLabel L43=new DexLabel();
                ddv.visitLineNumber(1024,L43);
                DexLabel L44=new DexLabel();
                ddv.visitLineNumber(1025,L44);
                ddv.visitLineNumber(1026,L1);
                DexLabel L45=new DexLabel();
                ddv.visitLineNumber(1027,L45);
                DexLabel L46=new DexLabel();
                ddv.visitLineNumber(1028,L46);
                ddv.visitLineNumber(1003,L3);
                ddv.visitLineNumber(1025,L2);
                ddv.visitEndLocal(7,L2);
                ddv.visitEndLocal(2,L2);
                ddv.visitEndLocal(3,L2);
                ddv.visitLineNumber(1007,L5);
                ddv.visitRestartLocal(2,L5);
                ddv.visitRestartLocal(3,L5);
                ddv.visitRestartLocal(7,L5);
                DexLabel L47=new DexLabel();
                ddv.visitLineNumber(1008,L47);
                DexLabel L48=new DexLabel();
                ddv.visitLineNumber(1011,L48);
                DexLabel L49=new DexLabel();
                ddv.visitLineNumber(1013,L49);
                code.visitLabel(L7);
                code.visitConstStmt(CONST_WIDE_16,11,Long.valueOf(0L)); // long: 0x0000000000000000  double:0.000000
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 15},new Method("Ljavax/servlet/http/Cookie;","getName",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 15},new Method("Ljavax/servlet/http/Cookie;","getValue",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 15},new Method("Ljavax/servlet/http/Cookie;","getVersion",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,9);
                code.visitLabel(L11);
                DexLabel L50=new DexLabel();
                code.visitJumpStmt(IF_EQZ,5,-1,L50);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,10);
                code.visitJumpStmt(IF_NEZ,10,-1,L12);
                code.visitLabel(L50);
                code.visitTypeStmt(NEW_INSTANCE,10,-1,"Ljava/lang/IllegalArgumentException;");
                code.visitConstStmt(CONST_STRING,11,"Bad cookie name");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 10,11},new Method("Ljava/lang/IllegalArgumentException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,10);
                code.visitLabel(L12);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/StringBuffer;");
                code.visitConstStmt(CONST_16,10, Integer.valueOf(128)); // int: 0x00000080  float:0.000000
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,10},new Method("Ljava/lang/StringBuffer;","<init>",new String[]{ "I"},"V"));
                code.visitLabel(L13);
                code.visitConstStmt(CONST_4,6, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L14);
                code.visitStmt1R(MONITOR_ENTER,0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,5},new Method("Lorg/mortbay/util/QuotedStringTokenizer;","quoteIfNeeded",new String[]{ "Ljava/lang/StringBuffer;","Ljava/lang/String;"},"V"));
                code.visitLabel(L15);
                code.visitConstStmt(CONST_16,10, Integer.valueOf(61)); // int: 0x0000003d  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,10},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "C"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L16);
                code.visitJumpStmt(IF_EQZ,8,-1,L18);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,10);
                code.visitJumpStmt(IF_LEZ,10,-1,L18);
                code.visitLabel(L17);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,8},new Method("Lorg/mortbay/util/QuotedStringTokenizer;","quoteIfNeeded",new String[]{ "Ljava/lang/StringBuffer;","Ljava/lang/String;"},"V"));
                code.visitLabel(L18);
                code.visitJumpStmt(IF_LEZ,9,-1,L25);
                code.visitLabel(L19);
                code.visitConstStmt(CONST_STRING,10,";Version=");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,10},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L20);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,9},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "I"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L21);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 15},new Method("Ljavax/servlet/http/Cookie;","getComment",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L22);
                code.visitJumpStmt(IF_EQZ,1,-1,L25);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,10);
                code.visitJumpStmt(IF_LEZ,10,-1,L25);
                code.visitLabel(L23);
                code.visitConstStmt(CONST_STRING,10,";Comment=");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,10},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L24);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,1},new Method("Lorg/mortbay/util/QuotedStringTokenizer;","quoteIfNeeded",new String[]{ "Ljava/lang/StringBuffer;","Ljava/lang/String;"},"V"));
                code.visitLabel(L25);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 15},new Method("Ljavax/servlet/http/Cookie;","getPath",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitLabel(L26);
                code.visitJumpStmt(IF_EQZ,7,-1,L29);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,10);
                code.visitJumpStmt(IF_LEZ,10,-1,L29);
                code.visitLabel(L27);
                code.visitConstStmt(CONST_STRING,10,";Path=");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,10},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L28);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 7},new Method("Lorg/mortbay/util/URIUtil;","encodePath",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,10},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L29);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 15},new Method("Ljavax/servlet/http/Cookie;","getDomain",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L30);
                code.visitJumpStmt(IF_EQZ,2,-1,L33);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,10);
                code.visitJumpStmt(IF_LEZ,10,-1,L33);
                code.visitLabel(L31);
                code.visitConstStmt(CONST_STRING,10,";Domain=");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,10},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L32);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/lang/String;","toLowerCase",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,10},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L33);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 15},new Method("Ljavax/servlet/http/Cookie;","getMaxAge",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,10);
                code.visitStmt2R(INT_TO_LONG,3,10);
                code.visitLabel(L34);
                code.visitStmt3R(CMP_LONG,10,3,11);
                code.visitJumpStmt(IF_LTZ,10,-1,L48);
                code.visitLabel(L35);
                code.visitJumpStmt(IF_NEZ,9,-1,L5);
                code.visitLabel(L36);
                code.visitConstStmt(CONST_STRING,10,";Expires=");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,10},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L37);
                code.visitStmt3R(CMP_LONG,10,3,11);
                code.visitJumpStmt(IF_NEZ,10,-1,L3);
                code.visitLabel(L38);
                code.visitFieldStmt(SGET_OBJECT,10,-1,new Field("Lorg/mortbay/jetty/HttpFields;","__01Jan1970","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,10},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L39);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 15},new Method("Ljavax/servlet/http/Cookie;","getSecure",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,10);
                code.visitJumpStmt(IF_EQZ,10,-1,L41);
                code.visitLabel(L40);
                code.visitConstStmt(CONST_STRING,10,";Secure");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,10},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L41);
                code.visitTypeStmt(INSTANCE_OF,10,15,"Lorg/mortbay/jetty/HttpOnlyCookie;");
                code.visitJumpStmt(IF_EQZ,10,-1,L43);
                code.visitLabel(L42);
                code.visitConstStmt(CONST_STRING,10,";HttpOnly");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,10},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L43);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/StringBuffer;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitLabel(L44);
                code.visitStmt1R(MONITOR_EXIT,0);
                code.visitLabel(L1);
                code.visitFieldStmt(SGET_OBJECT,10,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","EXPIRES_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitFieldStmt(SGET_OBJECT,11,-1,new Field("Lorg/mortbay/jetty/HttpFields;","__01Jan1970_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 14,10,11},new Method("Lorg/mortbay/jetty/HttpFields;","put",new String[]{ "Lorg/mortbay/io/Buffer;","Lorg/mortbay/io/Buffer;"},"V"));
                code.visitLabel(L45);
                code.visitFieldStmt(SGET_OBJECT,10,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","SET_COOKIE_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitTypeStmt(NEW_INSTANCE,11,-1,"Lorg/mortbay/io/ByteArrayBuffer;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 11,6},new Method("Lorg/mortbay/io/ByteArrayBuffer;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 14,10,11},new Method("Lorg/mortbay/jetty/HttpFields;","add",new String[]{ "Lorg/mortbay/io/Buffer;","Lorg/mortbay/io/Buffer;"},"V"));
                code.visitLabel(L46);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Ljava/lang/System;","currentTimeMillis",new String[]{ },"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,10);
                code.visitConstStmt(CONST_WIDE_16,12,Long.valueOf(1000L)); // long: 0x00000000000003e8  double:0.000000
                code.visitStmt2R(MUL_LONG_2ADDR,12,3);
                code.visitStmt2R(ADD_LONG_2ADDR,10,12);
                code.visitConstStmt(CONST_4,12, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,10,11,12},new Method("Lorg/mortbay/jetty/HttpFields;","formatDate",new String[]{ "Ljava/lang/StringBuffer;","J","Z"},"Ljava/lang/String;"));
                code.visitJumpStmt(GOTO,-1,-1,L39);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,10);
                code.visitStmt1R(MONITOR_EXIT,0);
                code.visitLabel(L4);
                code.visitStmt1R(THROW,10);
                code.visitLabel(L5);
                code.visitConstStmt(CONST_STRING,10,";Max-Age=");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,10},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L47);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,3,4},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "J"},"Ljava/lang/StringBuffer;"));
                code.visitJumpStmt(GOTO,-1,-1,L39);
                code.visitLabel(L48);
                code.visitJumpStmt(IF_LEZ,9,-1,L39);
                code.visitLabel(L49);
                code.visitConstStmt(CONST_STRING,10,";Discard");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,10},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L6);
                code.visitJumpStmt(GOTO,-1,-1,L39);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m019_clear(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpFields;","clear",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1064,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(1065,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(1067,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(1068,L3);
                DexLabel L4=new DexLabel();
                ddv.visitStartLocal(1,L4,"i","I",null);
                DexLabel L5=new DexLabel();
                ddv.visitEndLocal(1,L5);
                ddv.visitStartLocal(2,L5,"i","I",null);
                DexLabel L6=new DexLabel();
                ddv.visitRestartLocal(1,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(1070,L7);
                ddv.visitEndLocal(2,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(1071,L8);
                ddv.visitStartLocal(0,L8,"field","Lorg/mortbay/jetty/HttpFields$Field;",null);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(1072,L9);
                ddv.visitRestartLocal(2,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(1074,L10);
                ddv.visitEndLocal(1,L10);
                ddv.visitEndLocal(0,L10);
                ddv.visitEndLocal(2,L10);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,3,5,new Field("Lorg/mortbay/jetty/HttpFields;","_revision","I"));
                code.visitStmt2R1N(ADD_INT_LIT8,3,3,1);
                code.visitFieldStmt(IPUT,3,5,new Field("Lorg/mortbay/jetty/HttpFields;","_revision","I"));
                code.visitLabel(L1);
                code.visitFieldStmt(IGET,3,5,new Field("Lorg/mortbay/jetty/HttpFields;","_revision","I"));
                code.visitConstStmt(CONST,4, Integer.valueOf(1000000)); // int: 0x000f4240  float:0.000000
                code.visitJumpStmt(IF_LE,3,4,L10);
                code.visitLabel(L2);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT,3,5,new Field("Lorg/mortbay/jetty/HttpFields;","_revision","I"));
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,3,5,new Field("Lorg/mortbay/jetty/HttpFields;","_fields","Ljava/util/ArrayList;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/util/ArrayList;","size",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitLabel(L4);
                code.visitStmt2R(MOVE,2,1);
                code.visitLabel(L5);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt3R(SUB_INT,1,2,3);
                code.visitLabel(L6);
                code.visitJumpStmt(IF_LEZ,2,-1,L10);
                code.visitLabel(L7);
                code.visitFieldStmt(IGET_OBJECT,3,5,new Field("Lorg/mortbay/jetty/HttpFields;","_fields","Ljava/util/ArrayList;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,1},new Method("Ljava/util/ArrayList;","get",new String[]{ "I"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Lorg/mortbay/jetty/HttpFields$Field;");
                code.visitLabel(L8);
                DexLabel L11=new DexLabel();
                code.visitJumpStmt(IF_EQZ,0,-1,L11);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/jetty/HttpFields$Field;","access$600",new String[]{ "Lorg/mortbay/jetty/HttpFields$Field;"},"V"));
                code.visitLabel(L11);
                code.visitStmt2R(MOVE,2,1);
                code.visitLabel(L9);
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitLabel(L10);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m020_containsKey(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpFields;","containsKey",new String[]{ "Ljava/lang/String;"},"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(320,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(321,L1);
                ddv.visitStartLocal(0,L1,"f","Lorg/mortbay/jetty/HttpFields$Field;",null);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3,4},new Method("Lorg/mortbay/jetty/HttpFields;","getField",new String[]{ "Ljava/lang/String;"},"Lorg/mortbay/jetty/HttpFields$Field;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L1);
                DexLabel L2=new DexLabel();
                code.visitJumpStmt(IF_EQZ,0,-1,L2);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/jetty/HttpFields$Field;","access$100",new String[]{ "Lorg/mortbay/jetty/HttpFields$Field;"},"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitFieldStmt(IGET,2,3,new Field("Lorg/mortbay/jetty/HttpFields;","_revision","I"));
                code.visitJumpStmt(IF_NE,1,2,L2);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                DexLabel L3=new DexLabel();
                code.visitLabel(L3);
                code.visitStmt1R(RETURN,1);
                code.visitLabel(L2);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m021_containsKey(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpFields;","containsKey",new String[]{ "Lorg/mortbay/io/Buffer;"},"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(313,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(314,L1);
                ddv.visitStartLocal(0,L1,"f","Lorg/mortbay/jetty/HttpFields$Field;",null);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3,4},new Method("Lorg/mortbay/jetty/HttpFields;","getField",new String[]{ "Lorg/mortbay/io/Buffer;"},"Lorg/mortbay/jetty/HttpFields$Field;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L1);
                DexLabel L2=new DexLabel();
                code.visitJumpStmt(IF_EQZ,0,-1,L2);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/jetty/HttpFields$Field;","access$100",new String[]{ "Lorg/mortbay/jetty/HttpFields$Field;"},"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitFieldStmt(IGET,2,3,new Field("Lorg/mortbay/jetty/HttpFields;","_revision","I"));
                code.visitJumpStmt(IF_NE,1,2,L2);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                DexLabel L3=new DexLabel();
                code.visitLabel(L3);
                code.visitStmt1R(RETURN,1);
                code.visitLabel(L2);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m022_destroy(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpFields;","destroy",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(1082,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(1084,L2);
                DexLabel L3=new DexLabel();
                ddv.visitStartLocal(1,L3,"i","I",null);
                DexLabel L4=new DexLabel();
                ddv.visitEndLocal(1,L4);
                ddv.visitStartLocal(2,L4,"i","I",null);
                DexLabel L5=new DexLabel();
                ddv.visitRestartLocal(1,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(1086,L6);
                ddv.visitEndLocal(2,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(1087,L7);
                ddv.visitStartLocal(0,L7,"field","Lorg/mortbay/jetty/HttpFields$Field;",null);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(1088,L8);
                ddv.visitRestartLocal(2,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(1090,L9);
                ddv.visitEndLocal(1,L9);
                ddv.visitEndLocal(0,L9);
                ddv.visitEndLocal(2,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(1091,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(1092,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(1093,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(1094,L13);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,3,5,new Field("Lorg/mortbay/jetty/HttpFields;","_fields","Ljava/util/ArrayList;"));
                code.visitJumpStmt(IF_EQZ,3,-1,L9);
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,3,5,new Field("Lorg/mortbay/jetty/HttpFields;","_fields","Ljava/util/ArrayList;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/util/ArrayList;","size",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitLabel(L3);
                code.visitStmt2R(MOVE,2,1);
                code.visitLabel(L4);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt3R(SUB_INT,1,2,3);
                code.visitLabel(L5);
                code.visitJumpStmt(IF_LEZ,2,-1,L9);
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,3,5,new Field("Lorg/mortbay/jetty/HttpFields;","_fields","Ljava/util/ArrayList;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,1},new Method("Ljava/util/ArrayList;","get",new String[]{ "I"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Lorg/mortbay/jetty/HttpFields$Field;");
                code.visitLabel(L7);
                DexLabel L14=new DexLabel();
                code.visitJumpStmt(IF_EQZ,0,-1,L14);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/jetty/HttpFields$Field;","access$900",new String[]{ "Lorg/mortbay/jetty/HttpFields$Field;"},"V"));
                code.visitLabel(L14);
                code.visitStmt2R(MOVE,2,1);
                code.visitLabel(L8);
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitLabel(L9);
                code.visitFieldStmt(IPUT_OBJECT,4,5,new Field("Lorg/mortbay/jetty/HttpFields;","_fields","Ljava/util/ArrayList;"));
                code.visitLabel(L10);
                code.visitFieldStmt(IPUT_OBJECT,4,5,new Field("Lorg/mortbay/jetty/HttpFields;","_dateBuffer","Ljava/lang/StringBuffer;"));
                code.visitLabel(L11);
                code.visitFieldStmt(IPUT_OBJECT,4,5,new Field("Lorg/mortbay/jetty/HttpFields;","_calendar","Ljava/util/Calendar;"));
                code.visitLabel(L12);
                code.visitFieldStmt(IPUT_OBJECT,4,5,new Field("Lorg/mortbay/jetty/HttpFields;","_dateReceive","[Ljava/text/SimpleDateFormat;"));
                code.visitLabel(L13);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m023_get(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpFields;","get",new String[]{ "Lorg/mortbay/io/Buffer;"},"Lorg/mortbay/io/Buffer;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(361,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(362,L1);
                ddv.visitStartLocal(0,L1,"field","Lorg/mortbay/jetty/HttpFields$Field;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(363,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(364,L3);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3,4},new Method("Lorg/mortbay/jetty/HttpFields;","getField",new String[]{ "Lorg/mortbay/io/Buffer;"},"Lorg/mortbay/jetty/HttpFields$Field;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L1);
                DexLabel L4=new DexLabel();
                code.visitJumpStmt(IF_EQZ,0,-1,L4);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/jetty/HttpFields$Field;","access$100",new String[]{ "Lorg/mortbay/jetty/HttpFields$Field;"},"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitFieldStmt(IGET,2,3,new Field("Lorg/mortbay/jetty/HttpFields;","_revision","I"));
                code.visitJumpStmt(IF_NE,1,2,L4);
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/jetty/HttpFields$Field;","access$300",new String[]{ "Lorg/mortbay/jetty/HttpFields$Field;"},"Lorg/mortbay/io/Buffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L3);
                code.visitStmt1R(RETURN_OBJECT,1);
                code.visitLabel(L4);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m024_getDateField(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpFields;","getDateField",new String[]{ "Ljava/lang/String;"},"J"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(13);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/lang/Exception;"});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                DexLabel L5=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L5},new String[]{ "Ljava/lang/Exception;"});
                DexLabel L6=new DexLabel();
                DexLabel L7=new DexLabel();
                DexLabel L8=new DexLabel();
                code.visitTryCatch(L6,L7,new DexLabel[]{L8},new String[]{ null});
                DexLabel L9=new DexLabel();
                DexLabel L10=new DexLabel();
                code.visitTryCatch(L7,L9,new DexLabel[]{L10,L8},new String[]{ "Ljava/lang/Exception;",null});
                DexLabel L11=new DexLabel();
                DexLabel L12=new DexLabel();
                code.visitTryCatch(L11,L12,new DexLabel[]{L8},new String[]{ null});
                DexLabel L13=new DexLabel();
                DexLabel L14=new DexLabel();
                DexLabel L15=new DexLabel();
                code.visitTryCatch(L13,L14,new DexLabel[]{L15,L8},new String[]{ "Ljava/lang/Exception;",null});
                DexLabel L16=new DexLabel();
                DexLabel L17=new DexLabel();
                code.visitTryCatch(L16,L17,new DexLabel[]{L8},new String[]{ null});
                DexLabel L18=new DexLabel();
                DexLabel L19=new DexLabel();
                code.visitTryCatch(L18,L19,new DexLabel[]{L8},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                DexLabel L20=new DexLabel();
                ddv.visitPrologue(L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(749,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(750,L22);
                ddv.visitStartLocal(1,L22,"field","Lorg/mortbay/jetty/HttpFields$Field;",null);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(821,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(752,L24);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(754,L25);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(755,L26);
                ddv.visitStartLocal(3,L26,"val","Ljava/lang/String;",null);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(759,L27);
                DexLabel L28=new DexLabel();
                ddv.visitStartLocal(2,L28,"i","I",null);
                DexLabel L29=new DexLabel();
                ddv.visitLineNumber(761,L29);
                ddv.visitLineNumber(765,L0);
                DexLabel L30=new DexLabel();
                ddv.visitLineNumber(766,L30);
                ddv.visitStartLocal(0,L30,"date","Ljava/util/Date;",null);
                ddv.visitLineNumber(768,L2);
                ddv.visitEndLocal(0,L2);
                DexLabel L31=new DexLabel();
                ddv.visitLineNumber(759,L31);
                DexLabel L32=new DexLabel();
                ddv.visitLineNumber(772,L32);
                DexLabel L33=new DexLabel();
                ddv.visitLineNumber(774,L33);
                DexLabel L34=new DexLabel();
                ddv.visitLineNumber(775,L34);
                ddv.visitLineNumber(779,L3);
                DexLabel L35=new DexLabel();
                ddv.visitLineNumber(780,L35);
                ddv.visitRestartLocal(0,L35);
                ddv.visitLineNumber(782,L5);
                ddv.visitEndLocal(0,L5);
                DexLabel L36=new DexLabel();
                ddv.visitLineNumber(775,L36);
                DexLabel L37=new DexLabel();
                ddv.visitLineNumber(790,L37);
                ddv.visitLineNumber(792,L6);
                DexLabel L38=new DexLabel();
                ddv.visitLineNumber(794,L38);
                DexLabel L39=new DexLabel();
                ddv.visitLineNumber(796,L39);
                DexLabel L40=new DexLabel();
                ddv.visitLineNumber(798,L40);
                DexLabel L41=new DexLabel();
                ddv.visitLineNumber(799,L41);
                DexLabel L42=new DexLabel();
                ddv.visitLineNumber(801,L42);
                ddv.visitLineNumber(806,L7);
                DexLabel L43=new DexLabel();
                ddv.visitLineNumber(807,L43);
                ddv.visitRestartLocal(0,L43);
                ddv.visitLineNumber(809,L10);
                ddv.visitEndLocal(0,L10);
                DexLabel L44=new DexLabel();
                ddv.visitLineNumber(792,L44);
                DexLabel L45=new DexLabel();
                ddv.visitLineNumber(813,L45);
                DexLabel L46=new DexLabel();
                ddv.visitLineNumber(815,L46);
                DexLabel L47=new DexLabel();
                ddv.visitLineNumber(816,L47);
                ddv.visitRestartLocal(3,L47);
                ddv.visitLineNumber(820,L13);
                DexLabel L48=new DexLabel();
                ddv.visitLineNumber(821,L48);
                ddv.visitRestartLocal(0,L48);
                ddv.visitLineNumber(823,L15);
                ddv.visitEndLocal(0,L15);
                DexLabel L49=new DexLabel();
                ddv.visitLineNumber(816,L49);
                DexLabel L50=new DexLabel();
                ddv.visitLineNumber(828,L50);
                ddv.visitLineNumber(831,L17);
                ddv.visitLineNumber(828,L8);
                code.visitLabel(L20);
                code.visitConstStmt(CONST_4,9, Integer.valueOf(4)); // int: 0x00000004  float:0.000000
                code.visitConstStmt(CONST_4,8, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitConstStmt(CONST_WIDE_16,6,Long.valueOf(-1L)); // long: 0xffffffffffffffff  double:NaN
                code.visitConstStmt(CONST_STRING,10," GMT");
                code.visitLabel(L21);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 11,12},new Method("Lorg/mortbay/jetty/HttpFields;","getField",new String[]{ "Ljava/lang/String;"},"Lorg/mortbay/jetty/HttpFields$Field;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L22);
                DexLabel L51=new DexLabel();
                code.visitJumpStmt(IF_EQZ,1,-1,L51);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1},new Method("Lorg/mortbay/jetty/HttpFields$Field;","access$100",new String[]{ "Lorg/mortbay/jetty/HttpFields$Field;"},"I"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitFieldStmt(IGET,5,11,new Field("Lorg/mortbay/jetty/HttpFields;","_revision","I"));
                code.visitJumpStmt(IF_EQ,4,5,L24);
                code.visitLabel(L51);
                code.visitStmt2R(MOVE_WIDE,4,6);
                code.visitLabel(L23);
                code.visitStmt1R(RETURN_WIDE,4);
                code.visitLabel(L24);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1},new Method("Lorg/mortbay/jetty/HttpFields$Field;","access$800",new String[]{ "Lorg/mortbay/jetty/HttpFields$Field;"},"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,4);
                code.visitStmt3R(CMP_LONG,4,4,6);
                code.visitJumpStmt(IF_EQZ,4,-1,L25);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1},new Method("Lorg/mortbay/jetty/HttpFields$Field;","access$800",new String[]{ "Lorg/mortbay/jetty/HttpFields$Field;"},"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,4);
                code.visitJumpStmt(GOTO,-1,-1,L23);
                code.visitLabel(L25);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1},new Method("Lorg/mortbay/jetty/HttpFields$Field;","access$300",new String[]{ "Lorg/mortbay/jetty/HttpFields$Field;"},"Lorg/mortbay/io/Buffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 4},new Method("Lorg/mortbay/io/BufferUtil;","to8859_1_String",new String[]{ "Lorg/mortbay/io/Buffer;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitConstStmt(CONST_4,5, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 4,5},new Method("Lorg/mortbay/jetty/HttpFields;","valueParameters",new String[]{ "Ljava/lang/String;","Ljava/util/Map;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitLabel(L26);
                code.visitJumpStmt(IF_NEZ,3,-1,L27);
                code.visitStmt2R(MOVE_WIDE,4,6);
                code.visitJumpStmt(GOTO,-1,-1,L23);
                code.visitLabel(L27);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L28);
                code.visitFieldStmt(SGET,4,-1,new Field("Lorg/mortbay/jetty/HttpFields;","__dateReceiveInit","I"));
                code.visitJumpStmt(IF_GE,2,4,L32);
                code.visitLabel(L29);
                code.visitFieldStmt(IGET_OBJECT,4,11,new Field("Lorg/mortbay/jetty/HttpFields;","_dateReceive","[Ljava/text/SimpleDateFormat;"));
                code.visitStmt3R(AGET_OBJECT,4,4,2);
                code.visitJumpStmt(IF_NEZ,4,-1,L0);
                code.visitFieldStmt(IGET_OBJECT,5,11,new Field("Lorg/mortbay/jetty/HttpFields;","_dateReceive","[Ljava/text/SimpleDateFormat;"));
                code.visitFieldStmt(SGET_OBJECT,4,-1,new Field("Lorg/mortbay/jetty/HttpFields;","__dateReceive","[Ljava/text/SimpleDateFormat;"));
                code.visitStmt3R(AGET_OBJECT,4,4,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/text/SimpleDateFormat;","clone",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitTypeStmt(CHECK_CAST,4,-1,"Ljava/text/SimpleDateFormat;");
                code.visitStmt3R(APUT_OBJECT,4,5,2);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,4,11,new Field("Lorg/mortbay/jetty/HttpFields;","_dateReceive","[Ljava/text/SimpleDateFormat;"));
                code.visitStmt3R(AGET_OBJECT,4,4,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,3},new Method("Ljava/text/SimpleDateFormat;","parseObject",new String[]{ "Ljava/lang/String;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Ljava/util/Date;");
                code.visitLabel(L30);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/util/Date;","getTime",new String[]{ },"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,4);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1,4,5},new Method("Lorg/mortbay/jetty/HttpFields$Field;","access$802",new String[]{ "Lorg/mortbay/jetty/HttpFields$Field;","J"},"J"));
                code.visitLabel(L1);
                code.visitStmt1R(MOVE_RESULT_WIDE,4);
                code.visitJumpStmt(GOTO,-1,-1,L23);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,4);
                code.visitLabel(L31);
                code.visitStmt2R1N(ADD_INT_LIT8,2,2,1);
                code.visitJumpStmt(GOTO,-1,-1,L28);
                code.visitLabel(L32);
                code.visitConstStmt(CONST_STRING,4," GMT");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,10},new Method("Ljava/lang/String;","endsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitJumpStmt(IF_EQZ,4,-1,L37);
                code.visitLabel(L33);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitStmt2R(SUB_INT_2ADDR,4,9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,8,4},new Method("Ljava/lang/String;","substring",new String[]{ "I","I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitLabel(L34);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                DexLabel L52=new DexLabel();
                code.visitLabel(L52);
                code.visitFieldStmt(SGET,4,-1,new Field("Lorg/mortbay/jetty/HttpFields;","__dateReceiveInit","I"));
                code.visitJumpStmt(IF_GE,2,4,L37);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,4,11,new Field("Lorg/mortbay/jetty/HttpFields;","_dateReceive","[Ljava/text/SimpleDateFormat;"));
                code.visitStmt3R(AGET_OBJECT,4,4,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,3},new Method("Ljava/text/SimpleDateFormat;","parseObject",new String[]{ "Ljava/lang/String;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Ljava/util/Date;");
                code.visitLabel(L35);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/util/Date;","getTime",new String[]{ },"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,4);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1,4,5},new Method("Lorg/mortbay/jetty/HttpFields$Field;","access$802",new String[]{ "Lorg/mortbay/jetty/HttpFields$Field;","J"},"J"));
                code.visitLabel(L4);
                code.visitStmt1R(MOVE_RESULT_WIDE,4);
                code.visitJumpStmt(GOTO,-1,-1,L23);
                code.visitLabel(L5);
                code.visitStmt1R(MOVE_EXCEPTION,4);
                code.visitLabel(L36);
                code.visitStmt2R1N(ADD_INT_LIT8,2,2,1);
                code.visitJumpStmt(GOTO,-1,-1,L52);
                code.visitLabel(L37);
                code.visitFieldStmt(SGET_OBJECT,5,-1,new Field("Lorg/mortbay/jetty/HttpFields;","__dateReceive","[Ljava/text/SimpleDateFormat;"));
                code.visitStmt1R(MONITOR_ENTER,5);
                code.visitLabel(L6);
                code.visitFieldStmt(SGET,2,-1,new Field("Lorg/mortbay/jetty/HttpFields;","__dateReceiveInit","I"));
                DexLabel L53=new DexLabel();
                code.visitLabel(L53);
                code.visitFieldStmt(IGET_OBJECT,4,11,new Field("Lorg/mortbay/jetty/HttpFields;","_dateReceive","[Ljava/text/SimpleDateFormat;"));
                code.visitStmt2R(ARRAY_LENGTH,4,4);
                code.visitJumpStmt(IF_GE,2,4,L45);
                code.visitLabel(L38);
                code.visitFieldStmt(IGET_OBJECT,4,11,new Field("Lorg/mortbay/jetty/HttpFields;","_dateReceive","[Ljava/text/SimpleDateFormat;"));
                code.visitStmt3R(AGET_OBJECT,4,4,2);
                code.visitJumpStmt(IF_NEZ,4,-1,L7);
                code.visitLabel(L39);
                code.visitFieldStmt(SGET_OBJECT,4,-1,new Field("Lorg/mortbay/jetty/HttpFields;","__dateReceive","[Ljava/text/SimpleDateFormat;"));
                code.visitStmt3R(AGET_OBJECT,4,4,2);
                code.visitJumpStmt(IF_NEZ,4,-1,L42);
                code.visitLabel(L40);
                code.visitFieldStmt(SGET_OBJECT,4,-1,new Field("Lorg/mortbay/jetty/HttpFields;","__dateReceive","[Ljava/text/SimpleDateFormat;"));
                code.visitTypeStmt(NEW_INSTANCE,6,-1,"Ljava/text/SimpleDateFormat;");
                code.visitFieldStmt(SGET_OBJECT,7,-1,new Field("Lorg/mortbay/jetty/HttpFields;","__dateReceiveFmt","[Ljava/lang/String;"));
                code.visitStmt3R(AGET_OBJECT,7,7,2);
                code.visitFieldStmt(SGET_OBJECT,8,-1,new Field("Ljava/util/Locale;","US","Ljava/util/Locale;"));
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 6,7,8},new Method("Ljava/text/SimpleDateFormat;","<init>",new String[]{ "Ljava/lang/String;","Ljava/util/Locale;"},"V"));
                code.visitStmt3R(APUT_OBJECT,6,4,2);
                code.visitLabel(L41);
                code.visitFieldStmt(SGET_OBJECT,4,-1,new Field("Lorg/mortbay/jetty/HttpFields;","__dateReceive","[Ljava/text/SimpleDateFormat;"));
                code.visitStmt3R(AGET_OBJECT,4,4,2);
                code.visitFieldStmt(SGET_OBJECT,6,-1,new Field("Lorg/mortbay/jetty/HttpFields;","__GMT","Ljava/util/TimeZone;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,6},new Method("Ljava/text/SimpleDateFormat;","setTimeZone",new String[]{ "Ljava/util/TimeZone;"},"V"));
                code.visitLabel(L42);
                code.visitFieldStmt(IGET_OBJECT,6,11,new Field("Lorg/mortbay/jetty/HttpFields;","_dateReceive","[Ljava/text/SimpleDateFormat;"));
                code.visitFieldStmt(SGET_OBJECT,4,-1,new Field("Lorg/mortbay/jetty/HttpFields;","__dateReceive","[Ljava/text/SimpleDateFormat;"));
                code.visitStmt3R(AGET_OBJECT,4,4,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/text/SimpleDateFormat;","clone",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitTypeStmt(CHECK_CAST,4,-1,"Ljava/text/SimpleDateFormat;");
                code.visitStmt3R(APUT_OBJECT,4,6,2);
                code.visitLabel(L7);
                code.visitFieldStmt(IGET_OBJECT,4,11,new Field("Lorg/mortbay/jetty/HttpFields;","_dateReceive","[Ljava/text/SimpleDateFormat;"));
                code.visitStmt3R(AGET_OBJECT,4,4,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,3},new Method("Ljava/text/SimpleDateFormat;","parseObject",new String[]{ "Ljava/lang/String;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Ljava/util/Date;");
                code.visitLabel(L43);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/util/Date;","getTime",new String[]{ },"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,6);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1,6,7},new Method("Lorg/mortbay/jetty/HttpFields$Field;","access$802",new String[]{ "Lorg/mortbay/jetty/HttpFields$Field;","J"},"J"));
                code.visitLabel(L9);
                code.visitStmt1R(MOVE_RESULT_WIDE,6);
                code.visitLabel(L11);
                code.visitStmt1R(MONITOR_EXIT,5);
                code.visitStmt2R(MOVE_WIDE,4,6);
                code.visitJumpStmt(GOTO_16,-1,-1,L23);
                code.visitLabel(L10);
                code.visitStmt1R(MOVE_EXCEPTION,4);
                code.visitLabel(L44);
                code.visitStmt2R1N(ADD_INT_LIT8,2,2,1);
                code.visitJumpStmt(GOTO,-1,-1,L53);
                code.visitLabel(L45);
                code.visitConstStmt(CONST_STRING,4," GMT");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/String;","endsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitJumpStmt(IF_EQZ,4,-1,L50);
                code.visitLabel(L46);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitStmt2R(SUB_INT_2ADDR,6,9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4,6},new Method("Ljava/lang/String;","substring",new String[]{ "I","I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitLabel(L47);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                DexLabel L54=new DexLabel();
                code.visitLabel(L54);
                code.visitFieldStmt(IGET_OBJECT,4,11,new Field("Lorg/mortbay/jetty/HttpFields;","_dateReceive","[Ljava/text/SimpleDateFormat;"));
                code.visitStmt2R(ARRAY_LENGTH,4,4);
                code.visitLabel(L12);
                code.visitJumpStmt(IF_GE,2,4,L50);
                code.visitLabel(L13);
                code.visitFieldStmt(IGET_OBJECT,4,11,new Field("Lorg/mortbay/jetty/HttpFields;","_dateReceive","[Ljava/text/SimpleDateFormat;"));
                code.visitStmt3R(AGET_OBJECT,4,4,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,3},new Method("Ljava/text/SimpleDateFormat;","parseObject",new String[]{ "Ljava/lang/String;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Ljava/util/Date;");
                code.visitLabel(L48);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/util/Date;","getTime",new String[]{ },"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,6);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1,6,7},new Method("Lorg/mortbay/jetty/HttpFields$Field;","access$802",new String[]{ "Lorg/mortbay/jetty/HttpFields$Field;","J"},"J"));
                code.visitLabel(L14);
                code.visitStmt1R(MOVE_RESULT_WIDE,6);
                code.visitLabel(L16);
                code.visitStmt1R(MONITOR_EXIT,5);
                code.visitStmt2R(MOVE_WIDE,4,6);
                code.visitJumpStmt(GOTO_16,-1,-1,L23);
                code.visitLabel(L15);
                code.visitStmt1R(MOVE_EXCEPTION,4);
                code.visitLabel(L49);
                code.visitStmt2R1N(ADD_INT_LIT8,2,2,1);
                code.visitJumpStmt(GOTO,-1,-1,L54);
                code.visitLabel(L50);
                code.visitStmt1R(MONITOR_EXIT,5);
                code.visitLabel(L17);
                code.visitTypeStmt(NEW_INSTANCE,4,-1,"Ljava/lang/IllegalArgumentException;");
                code.visitTypeStmt(NEW_INSTANCE,5,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 5},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,6,"Cannot convert date: ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4,5},new Method("Ljava/lang/IllegalArgumentException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,4);
                code.visitLabel(L8);
                code.visitStmt1R(MOVE_EXCEPTION,4);
                code.visitLabel(L18);
                code.visitStmt1R(MONITOR_EXIT,5);
                code.visitLabel(L19);
                code.visitStmt1R(THROW,4);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m025_getFieldNames(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpFields;","getFieldNames",new String[]{ },"Ljava/util/Enumeration;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(219,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(220,L1);
                ddv.visitStartLocal(0,L1,"revision","I",null);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,2,new Field("Lorg/mortbay/jetty/HttpFields;","_revision","I"));
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Lorg/mortbay/jetty/HttpFields$1;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,2,0},new Method("Lorg/mortbay/jetty/HttpFields$1;","<init>",new String[]{ "Lorg/mortbay/jetty/HttpFields;","I"},"V"));
                code.visitStmt1R(RETURN_OBJECT,1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m026_getFields(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpFields;","getFields",new String[]{ },"Ljava/util/Iterator;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(259,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(260,L1);
                ddv.visitStartLocal(0,L1,"revision","I",null);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,2,new Field("Lorg/mortbay/jetty/HttpFields;","_revision","I"));
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Lorg/mortbay/jetty/HttpFields$2;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,2,0},new Method("Lorg/mortbay/jetty/HttpFields$2;","<init>",new String[]{ "Lorg/mortbay/jetty/HttpFields;","I"},"V"));
                code.visitStmt1R(RETURN_OBJECT,1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m027_getLongField(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpFields;","getLongField",new String[]{ "Ljava/lang/String;"},"J"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/NumberFormatException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(719,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(720,L1);
                ddv.visitStartLocal(0,L1,"field","Lorg/mortbay/jetty/HttpFields$Field;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(722,L2);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3,4},new Method("Lorg/mortbay/jetty/HttpFields;","getField",new String[]{ "Ljava/lang/String;"},"Lorg/mortbay/jetty/HttpFields$Field;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L1);
                DexLabel L3=new DexLabel();
                code.visitJumpStmt(IF_EQZ,0,-1,L3);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/jetty/HttpFields$Field;","access$100",new String[]{ "Lorg/mortbay/jetty/HttpFields$Field;"},"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitFieldStmt(IGET,2,3,new Field("Lorg/mortbay/jetty/HttpFields;","_revision","I"));
                code.visitJumpStmt(IF_NE,1,2,L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/HttpFields$Field;","getLongValue",new String[]{ },"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,1);
                code.visitLabel(L2);
                code.visitStmt1R(RETURN_WIDE,1);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_WIDE_16,1,Long.valueOf(-1L)); // long: 0xffffffffffffffff  double:NaN
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m028_getLongField(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpFields;","getLongField",new String[]{ "Lorg/mortbay/io/Buffer;"},"J"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/NumberFormatException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(735,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(736,L1);
                ddv.visitStartLocal(0,L1,"field","Lorg/mortbay/jetty/HttpFields$Field;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(737,L2);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3,4},new Method("Lorg/mortbay/jetty/HttpFields;","getField",new String[]{ "Lorg/mortbay/io/Buffer;"},"Lorg/mortbay/jetty/HttpFields$Field;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L1);
                DexLabel L3=new DexLabel();
                code.visitJumpStmt(IF_EQZ,0,-1,L3);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/jetty/HttpFields$Field;","access$100",new String[]{ "Lorg/mortbay/jetty/HttpFields$Field;"},"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitFieldStmt(IGET,2,3,new Field("Lorg/mortbay/jetty/HttpFields;","_revision","I"));
                code.visitJumpStmt(IF_NE,1,2,L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/HttpFields$Field;","getLongValue",new String[]{ },"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,1);
                code.visitLabel(L2);
                code.visitStmt1R(RETURN_WIDE,1);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_WIDE_16,1,Long.valueOf(-1L)); // long: 0xffffffffffffffff  double:NaN
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m029_getStringField(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpFields;","getStringField",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(333,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(334,L1);
                ddv.visitStartLocal(0,L1,"field","Lorg/mortbay/jetty/HttpFields$Field;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(335,L2);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3,4},new Method("Lorg/mortbay/jetty/HttpFields;","getField",new String[]{ "Ljava/lang/String;"},"Lorg/mortbay/jetty/HttpFields$Field;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L1);
                DexLabel L3=new DexLabel();
                code.visitJumpStmt(IF_EQZ,0,-1,L3);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/jetty/HttpFields$Field;","access$100",new String[]{ "Lorg/mortbay/jetty/HttpFields$Field;"},"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitFieldStmt(IGET,2,3,new Field("Lorg/mortbay/jetty/HttpFields;","_revision","I"));
                code.visitJumpStmt(IF_NE,1,2,L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/HttpFields$Field;","getValue",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L2);
                code.visitStmt1R(RETURN_OBJECT,1);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m030_getStringField(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpFields;","getStringField",new String[]{ "Lorg/mortbay/io/Buffer;"},"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(347,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(348,L1);
                ddv.visitStartLocal(0,L1,"field","Lorg/mortbay/jetty/HttpFields$Field;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(349,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(350,L3);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3,4},new Method("Lorg/mortbay/jetty/HttpFields;","getField",new String[]{ "Lorg/mortbay/io/Buffer;"},"Lorg/mortbay/jetty/HttpFields$Field;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L1);
                DexLabel L4=new DexLabel();
                code.visitJumpStmt(IF_EQZ,0,-1,L4);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/jetty/HttpFields$Field;","access$100",new String[]{ "Lorg/mortbay/jetty/HttpFields$Field;"},"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitFieldStmt(IGET,2,3,new Field("Lorg/mortbay/jetty/HttpFields;","_revision","I"));
                code.visitJumpStmt(IF_NE,1,2,L4);
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/jetty/HttpFields$Field;","access$300",new String[]{ "Lorg/mortbay/jetty/HttpFields$Field;"},"Lorg/mortbay/io/Buffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1},new Method("Lorg/mortbay/io/BufferUtil;","to8859_1_String",new String[]{ "Lorg/mortbay/io/Buffer;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L3);
                code.visitStmt1R(RETURN_OBJECT,1);
                code.visitLabel(L4);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m031_getValues(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpFields;","getValues",new String[]{ "Ljava/lang/String;"},"Ljava/util/Enumeration;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(376,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(377,L1);
                ddv.visitStartLocal(0,L1,"field","Lorg/mortbay/jetty/HttpFields$Field;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(378,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(381,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(379,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(381,L5);
                ddv.visitStartLocal(1,L5,"revision","I",null);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3,4},new Method("Lorg/mortbay/jetty/HttpFields;","getField",new String[]{ "Ljava/lang/String;"},"Lorg/mortbay/jetty/HttpFields$Field;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L1);
                code.visitJumpStmt(IF_NEZ,0,-1,L4);
                code.visitLabel(L2);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L3);
                code.visitStmt1R(RETURN_OBJECT,2);
                code.visitLabel(L4);
                code.visitFieldStmt(IGET,1,3,new Field("Lorg/mortbay/jetty/HttpFields;","_revision","I"));
                code.visitLabel(L5);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Lorg/mortbay/jetty/HttpFields$3;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2,3,0,1},new Method("Lorg/mortbay/jetty/HttpFields$3;","<init>",new String[]{ "Lorg/mortbay/jetty/HttpFields;","Lorg/mortbay/jetty/HttpFields$Field;","I"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m032_getValues(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpFields;","getValues",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"Ljava/util/Enumeration;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                ddv.visitParameterName(1,"separators");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(453,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(454,L1);
                ddv.visitStartLocal(0,L1,"e","Ljava/util/Enumeration;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(455,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(456,L3);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Lorg/mortbay/jetty/HttpFields;","getValues",new String[]{ "Ljava/lang/String;"},"Ljava/util/Enumeration;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L1);
                DexLabel L4=new DexLabel();
                code.visitJumpStmt(IF_NEZ,0,-1,L4);
                code.visitLabel(L2);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L3);
                code.visitStmt1R(RETURN_OBJECT,1);
                code.visitLabel(L4);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Lorg/mortbay/jetty/HttpFields$5;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,2,0,4},new Method("Lorg/mortbay/jetty/HttpFields$5;","<init>",new String[]{ "Lorg/mortbay/jetty/HttpFields;","Ljava/util/Enumeration;","Ljava/lang/String;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m033_getValues(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpFields;","getValues",new String[]{ "Lorg/mortbay/io/Buffer;"},"Ljava/util/Enumeration;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(413,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(414,L1);
                ddv.visitStartLocal(0,L1,"field","Lorg/mortbay/jetty/HttpFields$Field;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(415,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(418,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(416,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(418,L5);
                ddv.visitStartLocal(1,L5,"revision","I",null);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3,4},new Method("Lorg/mortbay/jetty/HttpFields;","getField",new String[]{ "Lorg/mortbay/io/Buffer;"},"Lorg/mortbay/jetty/HttpFields$Field;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L1);
                code.visitJumpStmt(IF_NEZ,0,-1,L4);
                code.visitLabel(L2);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L3);
                code.visitStmt1R(RETURN_OBJECT,2);
                code.visitLabel(L4);
                code.visitFieldStmt(IGET,1,3,new Field("Lorg/mortbay/jetty/HttpFields;","_revision","I"));
                code.visitLabel(L5);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Lorg/mortbay/jetty/HttpFields$4;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2,3,0,1},new Method("Lorg/mortbay/jetty/HttpFields$4;","<init>",new String[]{ "Lorg/mortbay/jetty/HttpFields;","Lorg/mortbay/jetty/HttpFields$Field;","I"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m034_put(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpFields;","put",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                ddv.visitParameterName(1,"value");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(492,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(493,L1);
                ddv.visitStartLocal(0,L1,"n","Lorg/mortbay/io/Buffer;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(494,L2);
                ddv.visitStartLocal(1,L2,"v","Lorg/mortbay/io/Buffer;",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(495,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(496,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(497,L5);
                code.visitLabel(L0);
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","CACHE","Lorg/mortbay/jetty/HttpHeaders;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,5},new Method("Lorg/mortbay/jetty/HttpHeaders;","lookup",new String[]{ "Ljava/lang/String;"},"Lorg/mortbay/io/Buffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L2);
                code.visitJumpStmt(IF_EQZ,6,-1,L4);
                code.visitLabel(L3);
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/jetty/HttpHeaderValues;","CACHE","Lorg/mortbay/jetty/HttpHeaderValues;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,6},new Method("Lorg/mortbay/jetty/HttpHeaderValues;","lookup",new String[]{ "Ljava/lang/String;"},"Lorg/mortbay/io/Buffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L4);
                code.visitConstStmt(CONST_WIDE_16,2,Long.valueOf(-1L)); // long: 0xffffffffffffffff  double:NaN
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,0,1,2,3},new Method("Lorg/mortbay/jetty/HttpFields;","put",new String[]{ "Lorg/mortbay/io/Buffer;","Lorg/mortbay/io/Buffer;","J"},"V"));
                code.visitLabel(L5);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m035_put(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpFields;","put",new String[]{ "Ljava/lang/String;","Ljava/util/List;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(8);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                ddv.visitParameterName(1,"list");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(574,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(576,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(597,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(579,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(581,L4);
                ddv.visitStartLocal(1,L4,"n","Lorg/mortbay/io/Buffer;",null);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(582,L5);
                ddv.visitStartLocal(2,L5,"v","Ljava/lang/Object;",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(583,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(587,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(589,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(590,L9);
                ddv.visitStartLocal(0,L9,"iter","Ljava/util/Iterator;",null);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(591,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(593,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(594,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(585,L13);
                ddv.visitEndLocal(0,L13);
                code.visitLabel(L0);
                code.visitJumpStmt(IF_EQZ,7,-1,L1);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 7},new Method("Ljava/util/List;","size",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_NEZ,3,-1,L3);
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Lorg/mortbay/jetty/HttpFields;","remove",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L3);
                code.visitFieldStmt(SGET_OBJECT,3,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","CACHE","Lorg/mortbay/jetty/HttpHeaders;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,6},new Method("Lorg/mortbay/jetty/HttpHeaders;","lookup",new String[]{ "Ljava/lang/String;"},"Lorg/mortbay/io/Buffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L4);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 7,3},new Method("Ljava/util/List;","get",new String[]{ "I"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L5);
                code.visitJumpStmt(IF_EQZ,2,-1,L13);
                code.visitLabel(L6);
                code.visitFieldStmt(SGET_OBJECT,3,-1,new Field("Lorg/mortbay/jetty/HttpHeaderValues;","CACHE","Lorg/mortbay/jetty/HttpHeaderValues;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/lang/Object;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Lorg/mortbay/jetty/HttpHeaderValues;","lookup",new String[]{ "Ljava/lang/String;"},"Lorg/mortbay/io/Buffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,1,3},new Method("Lorg/mortbay/jetty/HttpFields;","put",new String[]{ "Lorg/mortbay/io/Buffer;","Lorg/mortbay/io/Buffer;"},"V"));
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 7},new Method("Ljava/util/List;","size",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitJumpStmt(IF_LE,3,4,L2);
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 7},new Method("Ljava/util/List;","iterator",new String[]{ },"Ljava/util/Iterator;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Ljava/util/Iterator;","next",new String[]{ },"Ljava/lang/Object;"));
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Ljava/util/Iterator;","hasNext",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_EQZ,3,-1,L2);
                code.visitLabel(L11);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Ljava/util/Iterator;","next",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L12);
                code.visitJumpStmt(IF_EQZ,2,-1,L10);
                code.visitFieldStmt(SGET_OBJECT,3,-1,new Field("Lorg/mortbay/jetty/HttpHeaderValues;","CACHE","Lorg/mortbay/jetty/HttpHeaderValues;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/lang/Object;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Lorg/mortbay/jetty/HttpHeaderValues;","lookup",new String[]{ "Ljava/lang/String;"},"Lorg/mortbay/io/Buffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,1,3},new Method("Lorg/mortbay/jetty/HttpFields;","put",new String[]{ "Lorg/mortbay/io/Buffer;","Lorg/mortbay/io/Buffer;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L10);
                code.visitLabel(L13);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,1},new Method("Lorg/mortbay/jetty/HttpFields;","remove",new String[]{ "Lorg/mortbay/io/Buffer;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L7);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m036_put(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpFields;","put",new String[]{ "Lorg/mortbay/io/Buffer;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"buffer");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1033,L0);
                DexLabel L1=new DexLabel();
                ddv.visitStartLocal(1,L1,"i","I",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(1035,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(1036,L3);
                ddv.visitStartLocal(0,L3,"field","Lorg/mortbay/jetty/HttpFields$Field;",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(1033,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(1038,L5);
                ddv.visitEndLocal(0,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(1039,L6);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,2,4,new Field("Lorg/mortbay/jetty/HttpFields;","_fields","Ljava/util/ArrayList;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/util/ArrayList;","size",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_GE,1,2,L5);
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,2,4,new Field("Lorg/mortbay/jetty/HttpFields;","_fields","Ljava/util/ArrayList;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,1},new Method("Ljava/util/ArrayList;","get",new String[]{ "I"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Lorg/mortbay/jetty/HttpFields$Field;");
                code.visitLabel(L3);
                code.visitJumpStmt(IF_EQZ,0,-1,L4);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/jetty/HttpFields$Field;","access$100",new String[]{ "Lorg/mortbay/jetty/HttpFields$Field;"},"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitFieldStmt(IGET,3,4,new Field("Lorg/mortbay/jetty/HttpFields;","_revision","I"));
                code.visitJumpStmt(IF_NE,2,3,L4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,5},new Method("Lorg/mortbay/jetty/HttpFields$Field;","put",new String[]{ "Lorg/mortbay/io/Buffer;"},"V"));
                code.visitLabel(L4);
                code.visitStmt2R1N(ADD_INT_LIT8,1,1,1);
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 5},new Method("Lorg/mortbay/io/BufferUtil;","putCRLF",new String[]{ "Lorg/mortbay/io/Buffer;"},"V"));
                code.visitLabel(L6);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m037_put(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpFields;","put",new String[]{ "Lorg/mortbay/io/Buffer;","Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                ddv.visitParameterName(1,"value");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(508,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(509,L1);
                ddv.visitStartLocal(0,L1,"v","Lorg/mortbay/io/Buffer;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(510,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(SGET_OBJECT,1,-1,new Field("Lorg/mortbay/jetty/HttpHeaderValues;","CACHE","Lorg/mortbay/jetty/HttpHeaderValues;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,5},new Method("Lorg/mortbay/jetty/HttpHeaderValues;","lookup",new String[]{ "Ljava/lang/String;"},"Lorg/mortbay/io/Buffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_WIDE_16,1,Long.valueOf(-1L)); // long: 0xffffffffffffffff  double:NaN
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4,0,1,2},new Method("Lorg/mortbay/jetty/HttpFields;","put",new String[]{ "Lorg/mortbay/io/Buffer;","Lorg/mortbay/io/Buffer;","J"},"V"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m038_put(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpFields;","put",new String[]{ "Lorg/mortbay/io/Buffer;","Lorg/mortbay/io/Buffer;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                ddv.visitParameterName(1,"value");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(521,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(522,L1);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_WIDE_16,0,Long.valueOf(-1L)); // long: 0xffffffffffffffff  double:NaN
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3,4,0,1},new Method("Lorg/mortbay/jetty/HttpFields;","put",new String[]{ "Lorg/mortbay/io/Buffer;","Lorg/mortbay/io/Buffer;","J"},"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m039_put(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpFields;","put",new String[]{ "Lorg/mortbay/io/Buffer;","Lorg/mortbay/io/Buffer;","J"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(12);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                ddv.visitParameterName(1,"value");
                ddv.visitParameterName(2,"numValue");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(534,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(536,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(563,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(540,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(542,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(545,L5);
                ddv.visitStartLocal(0,L5,"field","Lorg/mortbay/jetty/HttpFields$Field;",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(547,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(548,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(549,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(551,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(552,L10);
                DexLabel L11=new DexLabel();
                ddv.visitRestartLocal(0,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(559,L12);
                DexLabel L13=new DexLabel();
                ddv.visitEndLocal(0,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(560,L14);
                ddv.visitRestartLocal(0,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(561,L15);
                code.visitLabel(L0);
                code.visitJumpStmt(IF_NEZ,9,-1,L3);
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,8},new Method("Lorg/mortbay/jetty/HttpFields;","remove",new String[]{ "Lorg/mortbay/io/Buffer;"},"V"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L3);
                code.visitTypeStmt(INSTANCE_OF,1,8,"Lorg/mortbay/io/BufferCache$CachedBuffer;");
                code.visitJumpStmt(IF_NEZ,1,-1,L4);
                code.visitFieldStmt(SGET_OBJECT,1,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","CACHE","Lorg/mortbay/jetty/HttpHeaders;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,8},new Method("Lorg/mortbay/jetty/HttpHeaders;","lookup",new String[]{ "Lorg/mortbay/io/Buffer;"},"Lorg/mortbay/io/Buffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,1,7,new Field("Lorg/mortbay/jetty/HttpFields;","_bufferMap","Ljava/util/HashMap;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,8},new Method("Ljava/util/HashMap;","get",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Lorg/mortbay/jetty/HttpFields$Field;");
                code.visitLabel(L5);
                code.visitJumpStmt(IF_EQZ,0,-1,L12);
                code.visitLabel(L6);
                code.visitFieldStmt(IGET,1,7,new Field("Lorg/mortbay/jetty/HttpFields;","_revision","I"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,9,10,11,1},new Method("Lorg/mortbay/jetty/HttpFields$Field;","access$500",new String[]{ "Lorg/mortbay/jetty/HttpFields$Field;","Lorg/mortbay/io/Buffer;","J","I"},"V"));
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/jetty/HttpFields$Field;","access$400",new String[]{ "Lorg/mortbay/jetty/HttpFields$Field;"},"Lorg/mortbay/jetty/HttpFields$Field;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L8);
                code.visitJumpStmt(IF_EQZ,0,-1,L2);
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/jetty/HttpFields$Field;","access$600",new String[]{ "Lorg/mortbay/jetty/HttpFields$Field;"},"V"));
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/jetty/HttpFields$Field;","access$400",new String[]{ "Lorg/mortbay/jetty/HttpFields$Field;"},"Lorg/mortbay/jetty/HttpFields$Field;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L11);
                code.visitJumpStmt(GOTO,-1,-1,L8);
                code.visitLabel(L12);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/jetty/HttpFields$Field;");
                code.visitLabel(L13);
                code.visitFieldStmt(IGET,5,7,new Field("Lorg/mortbay/jetty/HttpFields;","_revision","I"));
                code.visitConstStmt(CONST_4,6, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt2R(MOVE_OBJECT,1,8);
                code.visitStmt2R(MOVE_OBJECT,2,9);
                code.visitStmt2R(MOVE_WIDE,3,10);
                code.visitMethodStmt(INVOKE_DIRECT_RANGE,new int[]{ 0,1,2,3,4,5,6},new Method("Lorg/mortbay/jetty/HttpFields$Field;","<init>",new String[]{ "Lorg/mortbay/io/Buffer;","Lorg/mortbay/io/Buffer;","J","I","Lorg/mortbay/jetty/HttpFields$1;"},"V"));
                code.visitLabel(L14);
                code.visitFieldStmt(IGET_OBJECT,1,7,new Field("Lorg/mortbay/jetty/HttpFields;","_fields","Ljava/util/ArrayList;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,0},new Method("Ljava/util/ArrayList;","add",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitLabel(L15);
                code.visitFieldStmt(IGET_OBJECT,1,7,new Field("Lorg/mortbay/jetty/HttpFields;","_bufferMap","Ljava/util/HashMap;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/HttpFields$Field;","getNameBuffer",new String[]{ },"Lorg/mortbay/io/Buffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2,0},new Method("Ljava/util/HashMap;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m040_putDateField(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpFields;","putDateField",new String[]{ "Ljava/lang/String;","J"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                ddv.visitParameterName(1,"date");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(918,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(919,L1);
                ddv.visitStartLocal(0,L1,"n","Lorg/mortbay/io/Buffer;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(920,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(SGET_OBJECT,1,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","CACHE","Lorg/mortbay/jetty/HttpHeaders;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,3},new Method("Lorg/mortbay/jetty/HttpHeaders;","lookup",new String[]{ "Ljava/lang/String;"},"Lorg/mortbay/io/Buffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,0,4,5},new Method("Lorg/mortbay/jetty/HttpFields;","putDateField",new String[]{ "Lorg/mortbay/io/Buffer;","J"},"V"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m041_putDateField(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpFields;","putDateField",new String[]{ "Lorg/mortbay/io/Buffer;","J"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(8);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                ddv.visitParameterName(1,"date");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(897,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(899,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(900,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(902,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(903,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(904,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(905,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(906,L8);
                ddv.visitStartLocal(0,L8,"v","Lorg/mortbay/io/Buffer;",null);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(907,L9);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/jetty/HttpFields;","_dateBuffer","Ljava/lang/StringBuffer;"));
                code.visitJumpStmt(IF_NEZ,1,-1,L4);
                code.visitLabel(L2);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/lang/StringBuffer;");
                code.visitConstStmt(CONST_16,2, Integer.valueOf(32)); // int: 0x00000020  float:0.000000
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,2},new Method("Ljava/lang/StringBuffer;","<init>",new String[]{ "I"},"V"));
                code.visitFieldStmt(IPUT_OBJECT,1,4,new Field("Lorg/mortbay/jetty/HttpFields;","_dateBuffer","Ljava/lang/StringBuffer;"));
                code.visitLabel(L3);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/util/GregorianCalendar;");
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/jetty/HttpFields;","__GMT","Ljava/util/TimeZone;"));
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,2},new Method("Ljava/util/GregorianCalendar;","<init>",new String[]{ "Ljava/util/TimeZone;"},"V"));
                code.visitFieldStmt(IPUT_OBJECT,1,4,new Field("Lorg/mortbay/jetty/HttpFields;","_calendar","Ljava/util/Calendar;"));
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/jetty/HttpFields;","_dateBuffer","Ljava/lang/StringBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,3},new Method("Ljava/lang/StringBuffer;","setLength",new String[]{ "I"},"V"));
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/jetty/HttpFields;","_calendar","Ljava/util/Calendar;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,6,7},new Method("Ljava/util/Calendar;","setTimeInMillis",new String[]{ "J"},"V"));
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/jetty/HttpFields;","_dateBuffer","Ljava/lang/StringBuffer;"));
                code.visitFieldStmt(IGET_OBJECT,2,4,new Field("Lorg/mortbay/jetty/HttpFields;","_calendar","Ljava/util/Calendar;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1,2,3},new Method("Lorg/mortbay/jetty/HttpFields;","formatDate",new String[]{ "Ljava/lang/StringBuffer;","Ljava/util/Calendar;","Z"},"V"));
                code.visitLabel(L7);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/io/ByteArrayBuffer;");
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/jetty/HttpFields;","_dateBuffer","Ljava/lang/StringBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/lang/StringBuffer;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Lorg/mortbay/io/ByteArrayBuffer;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5,0,6,7},new Method("Lorg/mortbay/jetty/HttpFields;","put",new String[]{ "Lorg/mortbay/io/Buffer;","Lorg/mortbay/io/Buffer;","J"},"V"));
                code.visitLabel(L9);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m042_putLongField(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpFields;","putLongField",new String[]{ "Ljava/lang/String;","J"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                ddv.visitParameterName(1,"value");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(856,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(857,L1);
                ddv.visitStartLocal(0,L1,"n","Lorg/mortbay/io/Buffer;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(858,L2);
                ddv.visitStartLocal(1,L2,"v","Lorg/mortbay/io/Buffer;",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(859,L3);
                code.visitLabel(L0);
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","CACHE","Lorg/mortbay/jetty/HttpHeaders;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,4},new Method("Lorg/mortbay/jetty/HttpHeaders;","lookup",new String[]{ "Ljava/lang/String;"},"Lorg/mortbay/io/Buffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 5,6},new Method("Lorg/mortbay/io/BufferUtil;","toBuffer",new String[]{ "J"},"Lorg/mortbay/io/Buffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,0,1,5,6},new Method("Lorg/mortbay/jetty/HttpFields;","put",new String[]{ "Lorg/mortbay/io/Buffer;","Lorg/mortbay/io/Buffer;","J"},"V"));
                code.visitLabel(L3);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m043_putLongField(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpFields;","putLongField",new String[]{ "Lorg/mortbay/io/Buffer;","J"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                ddv.visitParameterName(1,"value");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(843,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(844,L1);
                ddv.visitStartLocal(0,L1,"v","Lorg/mortbay/io/Buffer;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(845,L2);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3,4},new Method("Lorg/mortbay/io/BufferUtil;","toBuffer",new String[]{ "J"},"Lorg/mortbay/io/Buffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2,0,3,4},new Method("Lorg/mortbay/jetty/HttpFields;","put",new String[]{ "Lorg/mortbay/io/Buffer;","Lorg/mortbay/io/Buffer;","J"},"V"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m044_remove(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpFields;","remove",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(686,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(687,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","CACHE","Lorg/mortbay/jetty/HttpHeaders;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,2},new Method("Lorg/mortbay/jetty/HttpHeaders;","lookup",new String[]{ "Ljava/lang/String;"},"Lorg/mortbay/io/Buffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,0},new Method("Lorg/mortbay/jetty/HttpFields;","remove",new String[]{ "Lorg/mortbay/io/Buffer;"},"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m045_remove(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpFields;","remove",new String[]{ "Lorg/mortbay/io/Buffer;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(697,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(699,L1);
                ddv.visitStartLocal(0,L1,"field","Lorg/mortbay/jetty/HttpFields$Field;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(701,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(703,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(704,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(707,L5);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/HttpFields;","_bufferMap","Ljava/util/HashMap;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,3},new Method("Ljava/util/HashMap;","get",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Lorg/mortbay/jetty/HttpFields$Field;");
                code.visitLabel(L1);
                code.visitJumpStmt(IF_EQZ,0,-1,L5);
                code.visitLabel(L2);
                code.visitJumpStmt(IF_EQZ,0,-1,L5);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/jetty/HttpFields$Field;","access$600",new String[]{ "Lorg/mortbay/jetty/HttpFields$Field;"},"V"));
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/jetty/HttpFields$Field;","access$400",new String[]{ "Lorg/mortbay/jetty/HttpFields$Field;"},"Lorg/mortbay/jetty/HttpFields$Field;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L5);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m046_toString(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpFields;","toString",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/lang/Exception;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1046,L0);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(1047,L3);
                ddv.visitStartLocal(0,L3,"buffer","Lorg/mortbay/io/ByteArrayBuffer;",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(1048,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(1055,L5);
                ddv.visitEndLocal(0,L5);
                ddv.visitLineNumber(1050,L2);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(1052,L6);
                ddv.visitStartLocal(1,L6,"e","Ljava/lang/Exception;",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(1055,L7);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/io/ByteArrayBuffer;");
                code.visitConstStmt(CONST_16,2, Integer.valueOf(4096)); // int: 0x00001000  float:0.000000
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,2},new Method("Lorg/mortbay/io/ByteArrayBuffer;","<init>",new String[]{ "I"},"V"));
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,0},new Method("Lorg/mortbay/jetty/HttpFields;","put",new String[]{ "Lorg/mortbay/io/Buffer;"},"V"));
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/io/BufferUtil;","to8859_1_String",new String[]{ "Lorg/mortbay/io/Buffer;"},"Ljava/lang/String;"));
                code.visitLabel(L1);
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L5);
                code.visitStmt1R(RETURN_OBJECT,2);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,2);
                code.visitStmt2R(MOVE_OBJECT,1,2);
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/lang/Exception;","printStackTrace",new String[]{ },"V"));
                code.visitLabel(L7);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
