package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0163_org_mortbay_jetty_HttpFields_Field {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC|ACC_FINAL,"Lorg/mortbay/jetty/HttpFields$Field;","Ljava/lang/Object;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("HttpFields.java");
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/EnclosingClass;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("value", new DexType("Lorg/mortbay/jetty/HttpFields;"));
                av00.visitEnd();
            }
        }
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/InnerClass;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("accessFlags",  Integer.valueOf(25));
                av00.visit("name", "Field");
                av00.visitEnd();
            }
        }
        f000__name(cv);
        f001__next(cv);
        f002__numValue(cv);
        f003__prev(cv);
        f004__revision(cv);
        f005__stringValue(cv);
        f006__value(cv);
        m000__init_(cv);
        m001__init_(cv);
        m002_access$000(cv);
        m003_access$002(cv);
        m004_access$100(cv);
        m005_access$200(cv);
        m006_access$300(cv);
        m007_access$400(cv);
        m008_access$402(cv);
        m009_access$500(cv);
        m010_access$600(cv);
        m011_access$800(cv);
        m012_access$802(cv);
        m013_access$900(cv);
        m014_clear(cv);
        m015_destroy(cv);
        m016_reset(cv);
        m017_getIntValue(cv);
        m018_getLongValue(cv);
        m019_getName(cv);
        m020_getNameBuffer(cv);
        m021_getNameOrdinal(cv);
        m022_getValue(cv);
        m023_getValueBuffer(cv);
        m024_getValueOrdinal(cv);
        m025_put(cv);
        m026_toString(cv);
    }
    public static void f000__name(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/HttpFields$Field;","_name","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001__next(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/HttpFields$Field;","_next","Lorg/mortbay/jetty/HttpFields$Field;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002__numValue(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/HttpFields$Field;","_numValue","J"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003__prev(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/HttpFields$Field;","_prev","Lorg/mortbay/jetty/HttpFields$Field;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f004__revision(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/HttpFields$Field;","_revision","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f005__stringValue(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/HttpFields$Field;","_stringValue","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f006__value(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/HttpFields$Field;","_value","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PRIVATE|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/HttpFields$Field;","<init>",new String[]{ "Lorg/mortbay/io/Buffer;","Lorg/mortbay/io/Buffer;","J","I"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(8);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                ddv.visitParameterName(1,"value");
                ddv.visitParameterName(2,"numValue");
                ddv.visitParameterName(3,"revision");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(1283,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(1284,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(1285,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(1286,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(1287,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(1288,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(1289,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(1290,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(1291,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(1285,L10);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2},new Method("Ljava/lang/Object;","<init>",new String[]{ },"V"));
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3},new Method("Lorg/mortbay/io/Buffer;","asImmutableBuffer",new String[]{ },"Lorg/mortbay/io/Buffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/jetty/HttpFields$Field;","_name","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 4},new Method("Lorg/mortbay/io/Buffer;","isImmutable",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L10);
                code.visitStmt2R(MOVE_OBJECT,0,4);
                DexLabel L11=new DexLabel();
                code.visitLabel(L11);
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/jetty/HttpFields$Field;","_value","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L4);
                code.visitFieldStmt(IPUT_OBJECT,1,2,new Field("Lorg/mortbay/jetty/HttpFields$Field;","_next","Lorg/mortbay/jetty/HttpFields$Field;"));
                code.visitLabel(L5);
                code.visitFieldStmt(IPUT_OBJECT,1,2,new Field("Lorg/mortbay/jetty/HttpFields$Field;","_prev","Lorg/mortbay/jetty/HttpFields$Field;"));
                code.visitLabel(L6);
                code.visitFieldStmt(IPUT,7,2,new Field("Lorg/mortbay/jetty/HttpFields$Field;","_revision","I"));
                code.visitLabel(L7);
                code.visitFieldStmt(IPUT_WIDE,5,2,new Field("Lorg/mortbay/jetty/HttpFields$Field;","_numValue","J"));
                code.visitLabel(L8);
                code.visitFieldStmt(IPUT_OBJECT,1,2,new Field("Lorg/mortbay/jetty/HttpFields$Field;","_stringValue","Ljava/lang/String;"));
                code.visitLabel(L9);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L10);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/io/View;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,4},new Method("Lorg/mortbay/io/View;","<init>",new String[]{ "Lorg/mortbay/io/Buffer;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L11);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_SYNTHETIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/HttpFields$Field;","<init>",new String[]{ "Lorg/mortbay/io/Buffer;","Lorg/mortbay/io/Buffer;","J","I","Lorg/mortbay/jetty/HttpFields$1;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"x0");
                ddv.visitParameterName(1,"x1");
                ddv.visitParameterName(2,"x2");
                ddv.visitParameterName(3,"x3");
                ddv.visitParameterName(4,"x4");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1271,L0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT_RANGE,new int[]{ 0,1,2,3,4,5},new Method("Lorg/mortbay/jetty/HttpFields$Field;","<init>",new String[]{ "Lorg/mortbay/io/Buffer;","Lorg/mortbay/io/Buffer;","J","I"},"V"));
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_access$000(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_SYNTHETIC, new Method("Lorg/mortbay/jetty/HttpFields$Field;","access$000",new String[]{ "Lorg/mortbay/jetty/HttpFields$Field;"},"Lorg/mortbay/jetty/HttpFields$Field;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"x0");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1271,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/HttpFields$Field;","_prev","Lorg/mortbay/jetty/HttpFields$Field;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_access$002(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_SYNTHETIC, new Method("Lorg/mortbay/jetty/HttpFields$Field;","access$002",new String[]{ "Lorg/mortbay/jetty/HttpFields$Field;","Lorg/mortbay/jetty/HttpFields$Field;"},"Lorg/mortbay/jetty/HttpFields$Field;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"x0");
                ddv.visitParameterName(1,"x1");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1271,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/HttpFields$Field;","_prev","Lorg/mortbay/jetty/HttpFields$Field;"));
                code.visitStmt1R(RETURN_OBJECT,1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_access$100(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_SYNTHETIC, new Method("Lorg/mortbay/jetty/HttpFields$Field;","access$100",new String[]{ "Lorg/mortbay/jetty/HttpFields$Field;"},"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"x0");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1271,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,1,new Field("Lorg/mortbay/jetty/HttpFields$Field;","_revision","I"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_access$200(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_SYNTHETIC, new Method("Lorg/mortbay/jetty/HttpFields$Field;","access$200",new String[]{ "Lorg/mortbay/jetty/HttpFields$Field;"},"Lorg/mortbay/io/Buffer;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"x0");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1271,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/HttpFields$Field;","_name","Lorg/mortbay/io/Buffer;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_access$300(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_SYNTHETIC, new Method("Lorg/mortbay/jetty/HttpFields$Field;","access$300",new String[]{ "Lorg/mortbay/jetty/HttpFields$Field;"},"Lorg/mortbay/io/Buffer;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"x0");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1271,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/HttpFields$Field;","_value","Lorg/mortbay/io/Buffer;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m007_access$400(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_SYNTHETIC, new Method("Lorg/mortbay/jetty/HttpFields$Field;","access$400",new String[]{ "Lorg/mortbay/jetty/HttpFields$Field;"},"Lorg/mortbay/jetty/HttpFields$Field;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"x0");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1271,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/HttpFields$Field;","_next","Lorg/mortbay/jetty/HttpFields$Field;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m008_access$402(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_SYNTHETIC, new Method("Lorg/mortbay/jetty/HttpFields$Field;","access$402",new String[]{ "Lorg/mortbay/jetty/HttpFields$Field;","Lorg/mortbay/jetty/HttpFields$Field;"},"Lorg/mortbay/jetty/HttpFields$Field;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"x0");
                ddv.visitParameterName(1,"x1");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1271,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/HttpFields$Field;","_next","Lorg/mortbay/jetty/HttpFields$Field;"));
                code.visitStmt1R(RETURN_OBJECT,1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m009_access$500(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_SYNTHETIC, new Method("Lorg/mortbay/jetty/HttpFields$Field;","access$500",new String[]{ "Lorg/mortbay/jetty/HttpFields$Field;","Lorg/mortbay/io/Buffer;","J","I"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"x0");
                ddv.visitParameterName(1,"x1");
                ddv.visitParameterName(2,"x2");
                ddv.visitParameterName(3,"x3");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1271,L0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1,2,3,4},new Method("Lorg/mortbay/jetty/HttpFields$Field;","reset",new String[]{ "Lorg/mortbay/io/Buffer;","J","I"},"V"));
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m010_access$600(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_SYNTHETIC, new Method("Lorg/mortbay/jetty/HttpFields$Field;","access$600",new String[]{ "Lorg/mortbay/jetty/HttpFields$Field;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"x0");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1271,L0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Lorg/mortbay/jetty/HttpFields$Field;","clear",new String[]{ },"V"));
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m011_access$800(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_SYNTHETIC, new Method("Lorg/mortbay/jetty/HttpFields$Field;","access$800",new String[]{ "Lorg/mortbay/jetty/HttpFields$Field;"},"J"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"x0");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1271,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_WIDE,0,2,new Field("Lorg/mortbay/jetty/HttpFields$Field;","_numValue","J"));
                code.visitStmt1R(RETURN_WIDE,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m012_access$802(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_SYNTHETIC, new Method("Lorg/mortbay/jetty/HttpFields$Field;","access$802",new String[]{ "Lorg/mortbay/jetty/HttpFields$Field;","J"},"J"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"x0");
                ddv.visitParameterName(1,"x1");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1271,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_WIDE,1,0,new Field("Lorg/mortbay/jetty/HttpFields$Field;","_numValue","J"));
                code.visitStmt1R(RETURN_WIDE,1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m013_access$900(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_SYNTHETIC, new Method("Lorg/mortbay/jetty/HttpFields$Field;","access$900",new String[]{ "Lorg/mortbay/jetty/HttpFields$Field;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"x0");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1271,L0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Lorg/mortbay/jetty/HttpFields$Field;","destroy",new String[]{ },"V"));
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m014_clear(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PRIVATE, new Method("Lorg/mortbay/jetty/HttpFields$Field;","clear",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1296,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(1297,L1);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(-1)); // int: 0xffffffff  float:NaN
                code.visitFieldStmt(IPUT,0,1,new Field("Lorg/mortbay/jetty/HttpFields$Field;","_revision","I"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m015_destroy(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PRIVATE, new Method("Lorg/mortbay/jetty/HttpFields$Field;","destroy",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(1302,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(1303,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(1304,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(1305,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(1306,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(1307,L6);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/HttpFields$Field;","_name","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L2);
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/HttpFields$Field;","_value","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L3);
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/HttpFields$Field;","_next","Lorg/mortbay/jetty/HttpFields$Field;"));
                code.visitLabel(L4);
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/HttpFields$Field;","_prev","Lorg/mortbay/jetty/HttpFields$Field;"));
                code.visitLabel(L5);
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/HttpFields$Field;","_stringValue","Ljava/lang/String;"));
                code.visitLabel(L6);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m016_reset(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PRIVATE, new Method("Lorg/mortbay/jetty/HttpFields$Field;","reset",new String[]{ "Lorg/mortbay/io/Buffer;","J","I"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(10);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"value");
                ddv.visitParameterName(1,"numValue");
                ddv.visitParameterName(2,"revision");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(1316,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(1317,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(1319,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(1320,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(1321,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(1355,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(1319,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(1323,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(1325,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(1326,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(1327,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(1331,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(1332,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(1335,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(1338,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(1340,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(1341,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(1334,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(1344,L19);
                DexLabel L20=new DexLabel();
                ddv.visitStartLocal(0,L20,"i","I",null);
                DexLabel L21=new DexLabel();
                ddv.visitEndLocal(0,L21);
                ddv.visitStartLocal(1,L21,"i","I",null);
                DexLabel L22=new DexLabel();
                ddv.visitRestartLocal(0,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(1346,L23);
                ddv.visitEndLocal(1,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(1348,L24);
                DexLabel L25=new DexLabel();
                ddv.visitRestartLocal(1,L25);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitFieldStmt(IPUT,9,5,new Field("Lorg/mortbay/jetty/HttpFields$Field;","_revision","I"));
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/jetty/HttpFields$Field;","_value","Lorg/mortbay/io/Buffer;"));
                code.visitJumpStmt(IF_NEZ,2,-1,L8);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 6},new Method("Lorg/mortbay/io/Buffer;","isImmutable",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_EQZ,2,-1,L7);
                code.visitStmt2R(MOVE_OBJECT,2,6);
                DexLabel L26=new DexLabel();
                code.visitLabel(L26);
                code.visitFieldStmt(IPUT_OBJECT,2,5,new Field("Lorg/mortbay/jetty/HttpFields$Field;","_value","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L4);
                code.visitFieldStmt(IPUT_WIDE,7,5,new Field("Lorg/mortbay/jetty/HttpFields$Field;","_numValue","J"));
                code.visitLabel(L5);
                code.visitFieldStmt(IPUT_OBJECT,4,5,new Field("Lorg/mortbay/jetty/HttpFields$Field;","_stringValue","Ljava/lang/String;"));
                code.visitLabel(L6);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L7);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Lorg/mortbay/io/View;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2,6},new Method("Lorg/mortbay/io/View;","<init>",new String[]{ "Lorg/mortbay/io/Buffer;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L26);
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 6},new Method("Lorg/mortbay/io/Buffer;","isImmutable",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_EQZ,2,-1,L12);
                code.visitLabel(L9);
                code.visitFieldStmt(IPUT_OBJECT,6,5,new Field("Lorg/mortbay/jetty/HttpFields$Field;","_value","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L10);
                code.visitFieldStmt(IPUT_WIDE,7,5,new Field("Lorg/mortbay/jetty/HttpFields$Field;","_numValue","J"));
                code.visitLabel(L11);
                code.visitFieldStmt(IPUT_OBJECT,4,5,new Field("Lorg/mortbay/jetty/HttpFields$Field;","_stringValue","Ljava/lang/String;"));
                code.visitJumpStmt(GOTO,-1,-1,L6);
                code.visitLabel(L12);
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/jetty/HttpFields$Field;","_value","Lorg/mortbay/io/Buffer;"));
                code.visitTypeStmt(INSTANCE_OF,2,2,"Lorg/mortbay/io/View;");
                code.visitJumpStmt(IF_EQZ,2,-1,L18);
                code.visitLabel(L13);
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/jetty/HttpFields$Field;","_value","Lorg/mortbay/io/Buffer;"));
                code.visitTypeStmt(CHECK_CAST,2,-1,"Lorg/mortbay/io/View;");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,6},new Method("Lorg/mortbay/io/View;","update",new String[]{ "Lorg/mortbay/io/Buffer;"},"V"));
                code.visitLabel(L14);
                code.visitFieldStmt(IPUT_WIDE,7,5,new Field("Lorg/mortbay/jetty/HttpFields$Field;","_numValue","J"));
                code.visitLabel(L15);
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/jetty/HttpFields$Field;","_stringValue","Ljava/lang/String;"));
                code.visitJumpStmt(IF_EQZ,2,-1,L6);
                code.visitLabel(L16);
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/jetty/HttpFields$Field;","_stringValue","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 6},new Method("Lorg/mortbay/io/Buffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_EQ,2,3,L19);
                code.visitLabel(L17);
                code.visitFieldStmt(IPUT_OBJECT,4,5,new Field("Lorg/mortbay/jetty/HttpFields$Field;","_stringValue","Ljava/lang/String;"));
                code.visitJumpStmt(GOTO,-1,-1,L6);
                code.visitLabel(L18);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Lorg/mortbay/io/View;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2,6},new Method("Lorg/mortbay/io/View;","<init>",new String[]{ "Lorg/mortbay/io/Buffer;"},"V"));
                code.visitFieldStmt(IPUT_OBJECT,2,5,new Field("Lorg/mortbay/jetty/HttpFields$Field;","_value","Lorg/mortbay/io/Buffer;"));
                code.visitJumpStmt(GOTO,-1,-1,L14);
                code.visitLabel(L19);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 6},new Method("Lorg/mortbay/io/Buffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitLabel(L20);
                code.visitStmt2R(MOVE,1,0);
                code.visitLabel(L21);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt3R(SUB_INT,0,1,2);
                code.visitLabel(L22);
                code.visitJumpStmt(IF_LEZ,1,-1,L6);
                code.visitLabel(L23);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 6},new Method("Lorg/mortbay/io/Buffer;","getIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitStmt2R(ADD_INT_2ADDR,2,0);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 6,2},new Method("Lorg/mortbay/io/Buffer;","peek",new String[]{ "I"},"B"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitFieldStmt(IGET_OBJECT,3,5,new Field("Lorg/mortbay/jetty/HttpFields$Field;","_stringValue","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,0},new Method("Ljava/lang/String;","charAt",new String[]{ "I"},"C"));
                code.visitStmt1R(MOVE_RESULT,3);
                DexLabel L27=new DexLabel();
                code.visitJumpStmt(IF_EQ,2,3,L27);
                code.visitLabel(L24);
                code.visitFieldStmt(IPUT_OBJECT,4,5,new Field("Lorg/mortbay/jetty/HttpFields$Field;","_stringValue","Ljava/lang/String;"));
                code.visitJumpStmt(GOTO,-1,-1,L6);
                code.visitLabel(L27);
                code.visitStmt2R(MOVE,1,0);
                code.visitLabel(L25);
                code.visitJumpStmt(GOTO,-1,-1,L21);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m017_getIntValue(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpFields$Field;","getIntValue",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1452,L0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/HttpFields$Field;","getLongValue",new String[]{ },"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,0);
                code.visitStmt2R(LONG_TO_INT,0,0);
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m018_getLongValue(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpFields$Field;","getLongValue",new String[]{ },"J"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1458,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(1459,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_WIDE,0,4,new Field("Lorg/mortbay/jetty/HttpFields$Field;","_numValue","J"));
                code.visitConstStmt(CONST_WIDE_16,2,Long.valueOf(-1L)); // long: 0xffffffffffffffff  double:NaN
                code.visitStmt3R(CMP_LONG,0,0,2);
                code.visitJumpStmt(IF_NEZ,0,-1,L1);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/jetty/HttpFields$Field;","_value","Lorg/mortbay/io/Buffer;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/io/BufferUtil;","toLong",new String[]{ "Lorg/mortbay/io/Buffer;"},"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,0);
                code.visitFieldStmt(IPUT_WIDE,0,4,new Field("Lorg/mortbay/jetty/HttpFields$Field;","_numValue","J"));
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_WIDE,0,4,new Field("Lorg/mortbay/jetty/HttpFields$Field;","_numValue","J"));
                code.visitStmt1R(RETURN_WIDE,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m019_getName(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpFields$Field;","getName",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1414,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/HttpFields$Field;","_name","Lorg/mortbay/io/Buffer;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/io/BufferUtil;","to8859_1_String",new String[]{ "Lorg/mortbay/io/Buffer;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m020_getNameBuffer(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(0, new Method("Lorg/mortbay/jetty/HttpFields$Field;","getNameBuffer",new String[]{ },"Lorg/mortbay/io/Buffer;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1420,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/HttpFields$Field;","_name","Lorg/mortbay/io/Buffer;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m021_getNameOrdinal(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpFields$Field;","getNameOrdinal",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1426,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","CACHE","Lorg/mortbay/jetty/HttpHeaders;"));
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/HttpFields$Field;","_name","Lorg/mortbay/io/Buffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/HttpHeaders;","getOrdinal",new String[]{ "Lorg/mortbay/io/Buffer;"},"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m022_getValue(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpFields$Field;","getValue",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1432,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(1433,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(1434,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/HttpFields$Field;","_stringValue","Ljava/lang/String;"));
                code.visitJumpStmt(IF_NEZ,0,-1,L2);
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/HttpFields$Field;","_value","Lorg/mortbay/io/Buffer;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/io/BufferUtil;","to8859_1_String",new String[]{ "Lorg/mortbay/io/Buffer;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/HttpFields$Field;","_stringValue","Ljava/lang/String;"));
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/HttpFields$Field;","_stringValue","Ljava/lang/String;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m023_getValueBuffer(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpFields$Field;","getValueBuffer",new String[]{ },"Lorg/mortbay/io/Buffer;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1440,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/HttpFields$Field;","_value","Lorg/mortbay/io/Buffer;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m024_getValueOrdinal(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpFields$Field;","getValueOrdinal",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1446,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpHeaderValues;","CACHE","Lorg/mortbay/jetty/HttpHeaderValues;"));
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/HttpFields$Field;","_value","Lorg/mortbay/io/Buffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/HttpHeaderValues;","getOrdinal",new String[]{ "Lorg/mortbay/io/Buffer;"},"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m025_put(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpFields$Field;","put",new String[]{ "Lorg/mortbay/io/Buffer;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(11);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"buffer");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(1362,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(1363,L2);
                ddv.visitStartLocal(2,L2,"o","I",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(1364,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(1384,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(1385,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(1387,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(1388,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(1389,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(1408,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(1409,L10);
                DexLabel L11=new DexLabel();
                ddv.visitEndLocal(2,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(1362,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(1367,L13);
                ddv.visitRestartLocal(2,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(1368,L14);
                ddv.visitStartLocal(3,L14,"s","I",null);
                DexLabel L15=new DexLabel();
                ddv.visitStartLocal(1,L15,"e","I",null);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(1369,L16);
                ddv.visitEndLocal(3,L16);
                ddv.visitStartLocal(4,L16,"s","I",null);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(1371,L17);
                DexLabel L18=new DexLabel();
                ddv.visitRestartLocal(3,L18);
                DexLabel L19=new DexLabel();
                ddv.visitEndLocal(4,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(1372,L20);
                ddv.visitStartLocal(0,L20,"b","B",null);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(1379,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(1381,L22);
                ddv.visitRestartLocal(4,L22);
                DexLabel L23=new DexLabel();
                ddv.visitEndLocal(4,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(1377,L24);
                ddv.visitRestartLocal(4,L24);
                DexLabel L25=new DexLabel();
                ddv.visitEndLocal(1,L25);
                ddv.visitEndLocal(3,L25);
                ddv.visitEndLocal(0,L25);
                ddv.visitEndLocal(4,L25);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(1387,L26);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(1392,L27);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(1393,L28);
                ddv.visitRestartLocal(3,L28);
                DexLabel L29=new DexLabel();
                ddv.visitRestartLocal(1,L29);
                DexLabel L30=new DexLabel();
                ddv.visitLineNumber(1394,L30);
                ddv.visitEndLocal(3,L30);
                ddv.visitRestartLocal(4,L30);
                DexLabel L31=new DexLabel();
                ddv.visitLineNumber(1396,L31);
                DexLabel L32=new DexLabel();
                ddv.visitRestartLocal(3,L32);
                DexLabel L33=new DexLabel();
                ddv.visitEndLocal(4,L33);
                DexLabel L34=new DexLabel();
                ddv.visitLineNumber(1397,L34);
                ddv.visitRestartLocal(0,L34);
                DexLabel L35=new DexLabel();
                ddv.visitLineNumber(1403,L35);
                DexLabel L36=new DexLabel();
                ddv.visitLineNumber(1405,L36);
                ddv.visitRestartLocal(4,L36);
                DexLabel L37=new DexLabel();
                ddv.visitEndLocal(4,L37);
                DexLabel L38=new DexLabel();
                ddv.visitLineNumber(1401,L38);
                ddv.visitRestartLocal(4,L38);
                DexLabel L39=new DexLabel();
                ddv.visitLineNumber(1372,L39);
                DexLabel L40=new DexLabel();
                ddv.visitLineNumber(1397,L40);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,6, Integer.valueOf(-1)); // int: 0xffffffff  float:NaN
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,5,9,new Field("Lorg/mortbay/jetty/HttpFields$Field;","_name","Lorg/mortbay/io/Buffer;"));
                code.visitTypeStmt(INSTANCE_OF,5,5,"Lorg/mortbay/io/BufferCache$CachedBuffer;");
                code.visitJumpStmt(IF_EQZ,5,-1,L11);
                code.visitFieldStmt(IGET_OBJECT,5,9,new Field("Lorg/mortbay/jetty/HttpFields$Field;","_name","Lorg/mortbay/io/Buffer;"));
                code.visitTypeStmt(CHECK_CAST,5,-1,"Lorg/mortbay/io/BufferCache$CachedBuffer;");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/io/BufferCache$CachedBuffer;","getOrdinal",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitStmt2R(MOVE,2,5);
                code.visitLabel(L2);
                code.visitJumpStmt(IF_LTZ,2,-1,L13);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,5,9,new Field("Lorg/mortbay/jetty/HttpFields$Field;","_name","Lorg/mortbay/io/Buffer;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 10,5},new Method("Lorg/mortbay/io/Buffer;","put",new String[]{ "Lorg/mortbay/io/Buffer;"},"I"));
                code.visitLabel(L4);
                code.visitConstStmt(CONST_16,5, Integer.valueOf(58)); // int: 0x0000003a  float:0.000000
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 10,5},new Method("Lorg/mortbay/io/Buffer;","put",new String[]{ "B"},"V"));
                code.visitLabel(L5);
                code.visitConstStmt(CONST_16,5, Integer.valueOf(32)); // int: 0x00000020  float:0.000000
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 10,5},new Method("Lorg/mortbay/io/Buffer;","put",new String[]{ "B"},"V"));
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,5,9,new Field("Lorg/mortbay/jetty/HttpFields$Field;","_value","Lorg/mortbay/io/Buffer;"));
                code.visitTypeStmt(INSTANCE_OF,5,5,"Lorg/mortbay/io/BufferCache$CachedBuffer;");
                code.visitJumpStmt(IF_EQZ,5,-1,L25);
                code.visitFieldStmt(IGET_OBJECT,5,9,new Field("Lorg/mortbay/jetty/HttpFields$Field;","_value","Lorg/mortbay/io/Buffer;"));
                code.visitTypeStmt(CHECK_CAST,5,-1,"Lorg/mortbay/io/BufferCache$CachedBuffer;");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/io/BufferCache$CachedBuffer;","getOrdinal",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitStmt2R(MOVE,2,5);
                code.visitLabel(L7);
                code.visitJumpStmt(IF_GEZ,2,-1,L8);
                code.visitFieldStmt(IGET_WIDE,5,9,new Field("Lorg/mortbay/jetty/HttpFields$Field;","_numValue","J"));
                code.visitConstStmt(CONST_WIDE_16,7,Long.valueOf(0L)); // long: 0x0000000000000000  double:0.000000
                code.visitStmt3R(CMP_LONG,5,5,7);
                code.visitJumpStmt(IF_LTZ,5,-1,L27);
                code.visitLabel(L8);
                code.visitFieldStmt(IGET_OBJECT,5,9,new Field("Lorg/mortbay/jetty/HttpFields$Field;","_value","Lorg/mortbay/io/Buffer;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 10,5},new Method("Lorg/mortbay/io/Buffer;","put",new String[]{ "Lorg/mortbay/io/Buffer;"},"I"));
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 10},new Method("Lorg/mortbay/io/BufferUtil;","putCRLF",new String[]{ "Lorg/mortbay/io/Buffer;"},"V"));
                code.visitLabel(L10);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L11);
                code.visitStmt2R(MOVE,2,6);
                code.visitLabel(L12);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L13);
                code.visitFieldStmt(IGET_OBJECT,5,9,new Field("Lorg/mortbay/jetty/HttpFields$Field;","_name","Lorg/mortbay/io/Buffer;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 5},new Method("Lorg/mortbay/io/Buffer;","getIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitLabel(L14);
                code.visitFieldStmt(IGET_OBJECT,5,9,new Field("Lorg/mortbay/jetty/HttpFields$Field;","_name","Lorg/mortbay/io/Buffer;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 5},new Method("Lorg/mortbay/io/Buffer;","putIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitLabel(L15);
                code.visitStmt2R(MOVE,4,3);
                code.visitLabel(L16);
                code.visitJumpStmt(IF_GE,4,1,L4);
                code.visitLabel(L17);
                code.visitFieldStmt(IGET_OBJECT,5,9,new Field("Lorg/mortbay/jetty/HttpFields$Field;","_name","Lorg/mortbay/io/Buffer;"));
                code.visitStmt2R1N(ADD_INT_LIT8,3,4,1);
                code.visitLabel(L18);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 5,4},new Method("Lorg/mortbay/io/Buffer;","peek",new String[]{ "I"},"B"));
                code.visitLabel(L19);
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitLabel(L20);
                code.visitSparseSwitchStmt(SPARSE_SWITCH,0,new int[]{ 10,13,58},new DexLabel[]{L23,L23,L23});
                code.visitLabel(L21);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 10,0},new Method("Lorg/mortbay/io/Buffer;","put",new String[]{ "B"},"V"));
                code.visitStmt2R(MOVE,4,3);
                code.visitLabel(L22);
                code.visitJumpStmt(GOTO,-1,-1,L16);
                code.visitLabel(L23);
                code.visitStmt2R(MOVE,4,3);
                code.visitLabel(L24);
                code.visitJumpStmt(GOTO,-1,-1,L16);
                code.visitLabel(L25);
                code.visitStmt2R(MOVE,2,6);
                code.visitLabel(L26);
                code.visitJumpStmt(GOTO,-1,-1,L7);
                code.visitLabel(L27);
                code.visitFieldStmt(IGET_OBJECT,5,9,new Field("Lorg/mortbay/jetty/HttpFields$Field;","_value","Lorg/mortbay/io/Buffer;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 5},new Method("Lorg/mortbay/io/Buffer;","getIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitLabel(L28);
                code.visitFieldStmt(IGET_OBJECT,5,9,new Field("Lorg/mortbay/jetty/HttpFields$Field;","_value","Lorg/mortbay/io/Buffer;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 5},new Method("Lorg/mortbay/io/Buffer;","putIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitLabel(L29);
                code.visitStmt2R(MOVE,4,3);
                code.visitLabel(L30);
                code.visitJumpStmt(IF_GE,4,1,L9);
                code.visitLabel(L31);
                code.visitFieldStmt(IGET_OBJECT,5,9,new Field("Lorg/mortbay/jetty/HttpFields$Field;","_value","Lorg/mortbay/io/Buffer;"));
                code.visitStmt2R1N(ADD_INT_LIT8,3,4,1);
                code.visitLabel(L32);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 5,4},new Method("Lorg/mortbay/io/Buffer;","peek",new String[]{ "I"},"B"));
                code.visitLabel(L33);
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitLabel(L34);
                code.visitSparseSwitchStmt(PACKED_SWITCH,0,10,new DexLabel[]{L37,L35,L35,L37});
                code.visitLabel(L35);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 10,0},new Method("Lorg/mortbay/io/Buffer;","put",new String[]{ "B"},"V"));
                code.visitStmt2R(MOVE,4,3);
                code.visitLabel(L36);
                code.visitJumpStmt(GOTO,-1,-1,L30);
                code.visitLabel(L37);
                code.visitStmt2R(MOVE,4,3);
                code.visitLabel(L38);
                code.visitJumpStmt(GOTO,-1,-1,L30);
                code.visitLabel(L39);
                code.visitLabel(L40);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m026_toString(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpFields$Field;","toString",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(1465,L1);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_STRING,3,"=");
                code.visitConstStmt(CONST_STRING,2,"");
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,1,"[");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/jetty/HttpFields$Field;","_prev","Lorg/mortbay/jetty/HttpFields$Field;"));
                DexLabel L2=new DexLabel();
                code.visitJumpStmt(IF_NEZ,1,-1,L2);
                code.visitConstStmt(CONST_STRING,1,"");
                code.visitStmt2R(MOVE_OBJECT,1,2);
                DexLabel L3=new DexLabel();
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/jetty/HttpFields$Field;","getName",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitConstStmt(CONST_STRING,1,"=");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IGET,1,4,new Field("Lorg/mortbay/jetty/HttpFields$Field;","_revision","I"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "I"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitConstStmt(CONST_STRING,1,"=");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/jetty/HttpFields$Field;","_value","Lorg/mortbay/io/Buffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/jetty/HttpFields$Field;","_next","Lorg/mortbay/jetty/HttpFields$Field;"));
                DexLabel L4=new DexLabel();
                code.visitJumpStmt(IF_NEZ,1,-1,L4);
                code.visitConstStmt(CONST_STRING,1,"");
                code.visitStmt2R(MOVE_OBJECT,1,2);
                DexLabel L5=new DexLabel();
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitConstStmt(CONST_STRING,1,"]");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L2);
                code.visitConstStmt(CONST_STRING,1,"<-");
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitLabel(L4);
                code.visitConstStmt(CONST_STRING,1,"->");
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
