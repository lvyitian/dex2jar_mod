package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0359_org_mortbay_log_StdErrLog {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/log/StdErrLog;","Ljava/lang/Object;",new String[]{ "Lorg/mortbay/log/Logger;"});
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("StdErrLog.java");
        f000__dateCache(cv);
        f001_debug(cv);
        f002_name(cv);
        m000__clinit_(cv);
        m001__init_(cv);
        m002__init_(cv);
        m003_format(cv);
        m004_debug(cv);
        m005_debug(cv);
        m006_getLogger(cv);
        m007_info(cv);
        m008_isDebugEnabled(cv);
        m009_setDebugEnabled(cv);
        m010_toString(cv);
        m011_warn(cv);
        m012_warn(cv);
    }
    public static void f000__dateCache(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC, new Field("Lorg/mortbay/log/StdErrLog;","_dateCache","Lorg/mortbay/util/DateCache;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001_debug(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC, new Field("Lorg/mortbay/log/StdErrLog;","debug","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002_name(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/log/StdErrLog;","name","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__clinit_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/log/StdErrLog;","<clinit>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/lang/Exception;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(29,L3);
                ddv.visitLineNumber(36,L0);
                ddv.visitLineNumber(43,L1);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(29,L4);
                ddv.visitLineNumber(38,L2);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(40,L5);
                ddv.visitStartLocal(0,L5,"e","Ljava/lang/Exception;",null);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_STRING,1,"DEBUG");
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1,2},new Method("Ljava/lang/System;","getProperty",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitJumpStmt(IF_EQZ,1,-1,L4);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                DexLabel L6=new DexLabel();
                code.visitLabel(L6);
                code.visitFieldStmt(SPUT_BOOLEAN,1,-1,new Field("Lorg/mortbay/log/StdErrLog;","debug","Z"));
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Lorg/mortbay/util/DateCache;");
                code.visitConstStmt(CONST_STRING,2,"yyyy-MM-dd HH:mm:ss");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,2},new Method("Lorg/mortbay/util/DateCache;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitFieldStmt(SPUT_OBJECT,1,-1,new Field("Lorg/mortbay/log/StdErrLog;","_dateCache","Lorg/mortbay/util/DateCache;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L4);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L6);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitStmt2R(MOVE_OBJECT,0,1);
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/Exception;","printStackTrace",new String[]{ },"V"));
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/log/StdErrLog;","<init>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(47,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(48,L1);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,0},new Method("Lorg/mortbay/log/StdErrLog;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/log/StdErrLog;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(51,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(52,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(53,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(52,L3);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljava/lang/Object;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                DexLabel L4=new DexLabel();
                code.visitJumpStmt(IF_NEZ,2,-1,L4);
                code.visitConstStmt(CONST_STRING,0,"");
                DexLabel L5=new DexLabel();
                code.visitLabel(L5);
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/log/StdErrLog;","name","Ljava/lang/String;"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L4);
                code.visitStmt2R(MOVE_OBJECT,0,2);
                code.visitLabel(L3);
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_format(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PRIVATE, new Method("Lorg/mortbay/log/StdErrLog;","format",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(9);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"msg");
                ddv.visitParameterName(1,"arg0");
                ddv.visitParameterName(2,"arg1");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(111,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(112,L2);
                ddv.visitStartLocal(0,L2,"i0","I",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(114,L3);
                ddv.visitStartLocal(1,L3,"i1","I",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(115,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(116,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(117,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(118,L7);
                ddv.visitRestartLocal(6,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(112,L8);
                ddv.visitEndLocal(1,L8);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitConstStmt(CONST_STRING,3,"{}");
                code.visitLabel(L1);
                code.visitConstStmt(CONST_STRING,2,"{}");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,3},new Method("Ljava/lang/String;","indexOf",new String[]{ "Ljava/lang/String;"},"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitLabel(L2);
                code.visitJumpStmt(IF_GEZ,0,-1,L8);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(-1)); // int: 0xffffffff  float:NaN
                code.visitStmt2R(MOVE,1,2);
                code.visitLabel(L3);
                code.visitJumpStmt(IF_EQZ,8,-1,L5);
                code.visitJumpStmt(IF_LTZ,1,-1,L5);
                code.visitLabel(L4);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,4,1},new Method("Ljava/lang/String;","substring",new String[]{ "I","I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,8},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitStmt2R1N(ADD_INT_LIT8,3,1,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,3},new Method("Ljava/lang/String;","substring",new String[]{ "I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitLabel(L5);
                code.visitJumpStmt(IF_EQZ,7,-1,L7);
                code.visitJumpStmt(IF_LTZ,0,-1,L7);
                code.visitLabel(L6);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,4,0},new Method("Ljava/lang/String;","substring",new String[]{ "I","I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,7},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitStmt2R1N(ADD_INT_LIT8,3,0,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,3},new Method("Ljava/lang/String;","substring",new String[]{ "I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitLabel(L7);
                code.visitStmt1R(RETURN_OBJECT,6);
                code.visitLabel(L8);
                code.visitConstStmt(CONST_STRING,2,"{}");
                code.visitStmt2R1N(ADD_INT_LIT8,2,0,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,3,2},new Method("Ljava/lang/String;","indexOf",new String[]{ "Ljava/lang/String;","I"},"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitStmt2R(MOVE,1,2);
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_debug(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/log/StdErrLog;","debug",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;","Ljava/lang/Object;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(9);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"msg");
                ddv.visitParameterName(1,"arg0");
                ddv.visitParameterName(2,"arg1");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(85,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(87,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(88,L2);
                ddv.visitStartLocal(0,L2,"d","Ljava/lang/String;",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(89,L3);
                ddv.visitStartLocal(1,L3,"ms","I",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(91,L4);
                ddv.visitEndLocal(0,L4);
                ddv.visitEndLocal(1,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(89,L5);
                ddv.visitRestartLocal(0,L5);
                ddv.visitRestartLocal(1,L5);
                code.visitLabel(L0);
                code.visitFieldStmt(SGET_BOOLEAN,2,-1,new Field("Lorg/mortbay/log/StdErrLog;","debug","Z"));
                code.visitJumpStmt(IF_EQZ,2,-1,L4);
                code.visitLabel(L1);
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/log/StdErrLog;","_dateCache","Lorg/mortbay/util/DateCache;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/util/DateCache;","now",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L2);
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/log/StdErrLog;","_dateCache","Lorg/mortbay/util/DateCache;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/util/DateCache;","lastMs",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitLabel(L3);
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Ljava/lang/System;","err","Ljava/io/PrintStream;"));
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,0},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitConstStmt(CONST_16,4, Integer.valueOf(99)); // int: 0x00000063  float:0.000000
                code.visitJumpStmt(IF_LE,1,4,L5);
                code.visitConstStmt(CONST_STRING,4,".");
                DexLabel L6=new DexLabel();
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "I"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitConstStmt(CONST_STRING,4,":");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitFieldStmt(IGET_OBJECT,4,5,new Field("Lorg/mortbay/log/StdErrLog;","name","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitConstStmt(CONST_STRING,4,":DEBUG: ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 5,6,7,8},new Method("Lorg/mortbay/log/StdErrLog;","format",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/io/PrintStream;","println",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L4);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L5);
                code.visitConstStmt(CONST_16,4, Integer.valueOf(9)); // int: 0x00000009  float:0.000000
                DexLabel L7=new DexLabel();
                code.visitJumpStmt(IF_LE,1,4,L7);
                code.visitConstStmt(CONST_STRING,4,".0");
                code.visitJumpStmt(GOTO,-1,-1,L6);
                code.visitLabel(L7);
                code.visitConstStmt(CONST_STRING,4,".00");
                code.visitJumpStmt(GOTO,-1,-1,L6);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_debug(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/log/StdErrLog;","debug",new String[]{ "Ljava/lang/String;","Ljava/lang/Throwable;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(8);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"msg");
                ddv.visitParameterName(1,"th");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(74,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(76,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(77,L2);
                ddv.visitStartLocal(0,L2,"d","Ljava/lang/String;",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(78,L3);
                ddv.visitStartLocal(1,L3,"ms","I",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(79,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(81,L5);
                ddv.visitEndLocal(0,L5);
                ddv.visitEndLocal(1,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(78,L6);
                ddv.visitRestartLocal(0,L6);
                ddv.visitRestartLocal(1,L6);
                code.visitLabel(L0);
                code.visitFieldStmt(SGET_BOOLEAN,2,-1,new Field("Lorg/mortbay/log/StdErrLog;","debug","Z"));
                code.visitJumpStmt(IF_EQZ,2,-1,L5);
                code.visitLabel(L1);
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/log/StdErrLog;","_dateCache","Lorg/mortbay/util/DateCache;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/util/DateCache;","now",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L2);
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/log/StdErrLog;","_dateCache","Lorg/mortbay/util/DateCache;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/util/DateCache;","lastMs",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitLabel(L3);
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Ljava/lang/System;","err","Ljava/io/PrintStream;"));
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,0},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitConstStmt(CONST_16,4, Integer.valueOf(99)); // int: 0x00000063  float:0.000000
                code.visitJumpStmt(IF_LE,1,4,L6);
                code.visitConstStmt(CONST_STRING,4,".");
                DexLabel L7=new DexLabel();
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "I"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitConstStmt(CONST_STRING,4,":");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitFieldStmt(IGET_OBJECT,4,5,new Field("Lorg/mortbay/log/StdErrLog;","name","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitConstStmt(CONST_STRING,4,":DEBUG: ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,6},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/io/PrintStream;","println",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L4);
                code.visitJumpStmt(IF_EQZ,7,-1,L5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Ljava/lang/Throwable;","printStackTrace",new String[]{ },"V"));
                code.visitLabel(L5);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L6);
                code.visitConstStmt(CONST_16,4, Integer.valueOf(9)); // int: 0x00000009  float:0.000000
                DexLabel L8=new DexLabel();
                code.visitJumpStmt(IF_LE,1,4,L8);
                code.visitConstStmt(CONST_STRING,4,".0");
                code.visitJumpStmt(GOTO,-1,-1,L7);
                code.visitLabel(L8);
                code.visitConstStmt(CONST_STRING,4,".00");
                code.visitJumpStmt(GOTO,-1,-1,L7);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_getLogger(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/log/StdErrLog;","getLogger",new String[]{ "Ljava/lang/String;"},"Lorg/mortbay/log/Logger;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(123,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(126,L1);
                code.visitLabel(L0);
                DexLabel L2=new DexLabel();
                code.visitJumpStmt(IF_NEZ,2,-1,L2);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/log/StdErrLog;","name","Ljava/lang/String;"));
                DexLabel L3=new DexLabel();
                code.visitJumpStmt(IF_EQZ,0,-1,L3);
                code.visitLabel(L2);
                DexLabel L4=new DexLabel();
                code.visitJumpStmt(IF_EQZ,2,-1,L4);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/log/StdErrLog;","name","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,0},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L4);
                code.visitLabel(L3);
                code.visitStmt2R(MOVE_OBJECT,0,1);
                code.visitLabel(L1);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L4);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/log/StdErrLog;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,2},new Method("Lorg/mortbay/log/StdErrLog;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m007_info(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/log/StdErrLog;","info",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;","Ljava/lang/Object;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(9);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"msg");
                ddv.visitParameterName(1,"arg0");
                ddv.visitParameterName(2,"arg1");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(67,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(68,L1);
                ddv.visitStartLocal(0,L1,"d","Ljava/lang/String;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(69,L2);
                ddv.visitStartLocal(1,L2,"ms","I",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(70,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(69,L4);
                code.visitLabel(L0);
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/log/StdErrLog;","_dateCache","Lorg/mortbay/util/DateCache;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/util/DateCache;","now",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L1);
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/log/StdErrLog;","_dateCache","Lorg/mortbay/util/DateCache;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/util/DateCache;","lastMs",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitLabel(L2);
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Ljava/lang/System;","err","Ljava/io/PrintStream;"));
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,0},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitConstStmt(CONST_16,4, Integer.valueOf(99)); // int: 0x00000063  float:0.000000
                code.visitJumpStmt(IF_LE,1,4,L4);
                code.visitConstStmt(CONST_STRING,4,".");
                DexLabel L5=new DexLabel();
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "I"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitConstStmt(CONST_STRING,4,":");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitFieldStmt(IGET_OBJECT,4,5,new Field("Lorg/mortbay/log/StdErrLog;","name","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitConstStmt(CONST_STRING,4,":INFO:  ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 5,6,7,8},new Method("Lorg/mortbay/log/StdErrLog;","format",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/io/PrintStream;","println",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L3);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L4);
                code.visitConstStmt(CONST_16,4, Integer.valueOf(9)); // int: 0x00000009  float:0.000000
                DexLabel L6=new DexLabel();
                code.visitJumpStmt(IF_LE,1,4,L6);
                code.visitConstStmt(CONST_STRING,4,".0");
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitLabel(L6);
                code.visitConstStmt(CONST_STRING,4,".00");
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m008_isDebugEnabled(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/log/StdErrLog;","isDebugEnabled",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(57,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(SGET_BOOLEAN,0,-1,new Field("Lorg/mortbay/log/StdErrLog;","debug","Z"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m009_setDebugEnabled(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/log/StdErrLog;","setDebugEnabled",new String[]{ "Z"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"enabled");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(62,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(63,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(SPUT_BOOLEAN,1,-1,new Field("Lorg/mortbay/log/StdErrLog;","debug","Z"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m010_toString(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/log/StdErrLog;","toString",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(131,L0);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,1,"STDERR");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/log/StdErrLog;","name","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m011_warn(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/log/StdErrLog;","warn",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;","Ljava/lang/Object;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(9);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"msg");
                ddv.visitParameterName(1,"arg0");
                ddv.visitParameterName(2,"arg1");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(95,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(96,L1);
                ddv.visitStartLocal(0,L1,"d","Ljava/lang/String;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(97,L2);
                ddv.visitStartLocal(1,L2,"ms","I",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(98,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(97,L4);
                code.visitLabel(L0);
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/log/StdErrLog;","_dateCache","Lorg/mortbay/util/DateCache;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/util/DateCache;","now",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L1);
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/log/StdErrLog;","_dateCache","Lorg/mortbay/util/DateCache;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/util/DateCache;","lastMs",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitLabel(L2);
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Ljava/lang/System;","err","Ljava/io/PrintStream;"));
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,0},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitConstStmt(CONST_16,4, Integer.valueOf(99)); // int: 0x00000063  float:0.000000
                code.visitJumpStmt(IF_LE,1,4,L4);
                code.visitConstStmt(CONST_STRING,4,".");
                DexLabel L5=new DexLabel();
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "I"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitConstStmt(CONST_STRING,4,":");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitFieldStmt(IGET_OBJECT,4,5,new Field("Lorg/mortbay/log/StdErrLog;","name","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitConstStmt(CONST_STRING,4,":WARN:  ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 5,6,7,8},new Method("Lorg/mortbay/log/StdErrLog;","format",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/io/PrintStream;","println",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L3);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L4);
                code.visitConstStmt(CONST_16,4, Integer.valueOf(9)); // int: 0x00000009  float:0.000000
                DexLabel L6=new DexLabel();
                code.visitJumpStmt(IF_LE,1,4,L6);
                code.visitConstStmt(CONST_STRING,4,".0");
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitLabel(L6);
                code.visitConstStmt(CONST_STRING,4,".00");
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m012_warn(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/log/StdErrLog;","warn",new String[]{ "Ljava/lang/String;","Ljava/lang/Throwable;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(8);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"msg");
                ddv.visitParameterName(1,"th");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(102,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(103,L1);
                ddv.visitStartLocal(0,L1,"d","Ljava/lang/String;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(104,L2);
                ddv.visitStartLocal(1,L2,"ms","I",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(105,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(106,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(107,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(104,L6);
                code.visitLabel(L0);
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/log/StdErrLog;","_dateCache","Lorg/mortbay/util/DateCache;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/util/DateCache;","now",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L1);
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/log/StdErrLog;","_dateCache","Lorg/mortbay/util/DateCache;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/util/DateCache;","lastMs",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitLabel(L2);
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Ljava/lang/System;","err","Ljava/io/PrintStream;"));
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,0},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitConstStmt(CONST_16,4, Integer.valueOf(99)); // int: 0x00000063  float:0.000000
                code.visitJumpStmt(IF_LE,1,4,L6);
                code.visitConstStmt(CONST_STRING,4,".");
                DexLabel L7=new DexLabel();
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "I"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitConstStmt(CONST_STRING,4,":");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitFieldStmt(IGET_OBJECT,4,5,new Field("Lorg/mortbay/log/StdErrLog;","name","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitConstStmt(CONST_STRING,4,":WARN:  ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,6},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/io/PrintStream;","println",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L3);
                code.visitJumpStmt(IF_EQZ,7,-1,L5);
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Ljava/lang/Throwable;","printStackTrace",new String[]{ },"V"));
                code.visitLabel(L5);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L6);
                code.visitConstStmt(CONST_16,4, Integer.valueOf(9)); // int: 0x00000009  float:0.000000
                DexLabel L8=new DexLabel();
                code.visitJumpStmt(IF_LE,1,4,L8);
                code.visitConstStmt(CONST_STRING,4,".0");
                code.visitJumpStmt(GOTO,-1,-1,L7);
                code.visitLabel(L8);
                code.visitConstStmt(CONST_STRING,4,".00");
                code.visitJumpStmt(GOTO,-1,-1,L7);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
