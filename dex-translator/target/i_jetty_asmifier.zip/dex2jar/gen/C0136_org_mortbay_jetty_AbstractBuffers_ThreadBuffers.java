package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0136_org_mortbay_jetty_AbstractBuffers_ThreadBuffers {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/jetty/AbstractBuffers$ThreadBuffers;","Ljava/lang/Object;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("AbstractBuffers.java");
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/EnclosingClass;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("value", new DexType("Lorg/mortbay/jetty/AbstractBuffers;"));
                av00.visitEnd();
            }
        }
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/InnerClass;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("accessFlags",  Integer.valueOf(12));
                av00.visit("name", "ThreadBuffers");
                av00.visitEnd();
            }
        }
        f000__buffers(cv);
        m000__init_(cv);
    }
    public static void f000__buffers(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_FINAL, new Field("Lorg/mortbay/jetty/AbstractBuffers$ThreadBuffers;","_buffers","[[Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/AbstractBuffers$ThreadBuffers;","<init>",new String[]{ "I","I","I","I"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(8);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"headers");
                ddv.visitParameterName(1,"requests");
                ddv.visitParameterName(2,"responses");
                ddv.visitParameterName(3,"others");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(190,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(191,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(192,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(193,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(194,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(195,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(197,L6);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3},new Method("Ljava/lang/Object;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(4)); // int: 0x00000004  float:0.000000
                code.visitTypeStmt(NEW_ARRAY,0,0,"[[Lorg/mortbay/io/Buffer;");
                code.visitFieldStmt(IPUT_OBJECT,0,3,new Field("Lorg/mortbay/jetty/AbstractBuffers$ThreadBuffers;","_buffers","[[Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/jetty/AbstractBuffers$ThreadBuffers;","_buffers","[[Lorg/mortbay/io/Buffer;"));
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitTypeStmt(NEW_ARRAY,2,4,"[Lorg/mortbay/io/Buffer;");
                code.visitStmt3R(APUT_OBJECT,2,0,1);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/jetty/AbstractBuffers$ThreadBuffers;","_buffers","[[Lorg/mortbay/io/Buffer;"));
                code.visitConstStmt(CONST_4,1, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitTypeStmt(NEW_ARRAY,2,5,"[Lorg/mortbay/io/Buffer;");
                code.visitStmt3R(APUT_OBJECT,2,0,1);
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/jetty/AbstractBuffers$ThreadBuffers;","_buffers","[[Lorg/mortbay/io/Buffer;"));
                code.visitConstStmt(CONST_4,1, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitTypeStmt(NEW_ARRAY,2,6,"[Lorg/mortbay/io/Buffer;");
                code.visitStmt3R(APUT_OBJECT,2,0,1);
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/jetty/AbstractBuffers$ThreadBuffers;","_buffers","[[Lorg/mortbay/io/Buffer;"));
                code.visitConstStmt(CONST_4,1, Integer.valueOf(3)); // int: 0x00000003  float:0.000000
                code.visitTypeStmt(NEW_ARRAY,2,7,"[Lorg/mortbay/io/Buffer;");
                code.visitStmt3R(APUT_OBJECT,2,0,1);
                code.visitLabel(L6);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
