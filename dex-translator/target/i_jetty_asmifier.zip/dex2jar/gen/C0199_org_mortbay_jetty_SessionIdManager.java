package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0199_org_mortbay_jetty_SessionIdManager {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC|ACC_INTERFACE|ACC_ABSTRACT,"Lorg/mortbay/jetty/SessionIdManager;","Ljava/lang/Object;",new String[]{ "Lorg/mortbay/component/LifeCycle;"});
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("SessionIdManager.java");
        m000_addSession(cv);
        m001_getClusterId(cv);
        m002_getNodeId(cv);
        m003_getWorkerName(cv);
        m004_idInUse(cv);
        m005_invalidateAll(cv);
        m006_newSessionId(cv);
        m007_removeSession(cv);
    }
    public static void m000_addSession(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/jetty/SessionIdManager;","addSession",new String[]{ "Ljavax/servlet/http/HttpSession;"},"V"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m001_getClusterId(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/jetty/SessionIdManager;","getClusterId",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m002_getNodeId(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/jetty/SessionIdManager;","getNodeId",new String[]{ "Ljava/lang/String;","Ljavax/servlet/http/HttpServletRequest;"},"Ljava/lang/String;"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m003_getWorkerName(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/jetty/SessionIdManager;","getWorkerName",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m004_idInUse(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/jetty/SessionIdManager;","idInUse",new String[]{ "Ljava/lang/String;"},"Z"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m005_invalidateAll(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/jetty/SessionIdManager;","invalidateAll",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m006_newSessionId(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/jetty/SessionIdManager;","newSessionId",new String[]{ "Ljavax/servlet/http/HttpServletRequest;","J"},"Ljava/lang/String;"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m007_removeSession(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/jetty/SessionIdManager;","removeSession",new String[]{ "Ljavax/servlet/http/HttpSession;"},"V"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
}
