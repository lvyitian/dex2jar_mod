package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0460_org_mortbay_util_ajax_WaitingContinuation {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/util/ajax/WaitingContinuation;","Ljava/lang/Object;",new String[]{ "Lorg/mortbay/util/ajax/Continuation;"});
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("WaitingContinuation.java");
        f000__mutex(cv);
        f001__new(cv);
        f002__object(cv);
        f003__pending(cv);
        f004__resumed(cv);
        m000__init_(cv);
        m001__init_(cv);
        m002_getMutex(cv);
        m003_getObject(cv);
        m004_isNew(cv);
        m005_isPending(cv);
        m006_isResumed(cv);
        m007_reset(cv);
        m008_resume(cv);
        m009_setMutex(cv);
        m010_setObject(cv);
        m011_suspend(cv);
        m012_toString(cv);
    }
    public static void f000__mutex(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/util/ajax/WaitingContinuation;","_mutex","Ljava/lang/Object;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001__new(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/util/ajax/WaitingContinuation;","_new","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002__object(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/util/ajax/WaitingContinuation;","_object","Ljava/lang/Object;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003__pending(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/util/ajax/WaitingContinuation;","_pending","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f004__resumed(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/util/ajax/WaitingContinuation;","_resumed","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/util/ajax/WaitingContinuation;","<init>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(29,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(24,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(25,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(26,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(30,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(31,L6);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2},new Method("Ljava/lang/Object;","<init>",new String[]{ },"V"));
                code.visitLabel(L2);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitFieldStmt(IPUT_BOOLEAN,0,2,new Field("Lorg/mortbay/util/ajax/WaitingContinuation;","_new","Z"));
                code.visitLabel(L3);
                code.visitFieldStmt(IPUT_BOOLEAN,1,2,new Field("Lorg/mortbay/util/ajax/WaitingContinuation;","_resumed","Z"));
                code.visitLabel(L4);
                code.visitFieldStmt(IPUT_BOOLEAN,1,2,new Field("Lorg/mortbay/util/ajax/WaitingContinuation;","_pending","Z"));
                code.visitLabel(L5);
                code.visitFieldStmt(IPUT_OBJECT,2,2,new Field("Lorg/mortbay/util/ajax/WaitingContinuation;","_mutex","Ljava/lang/Object;"));
                code.visitLabel(L6);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/util/ajax/WaitingContinuation;","<init>",new String[]{ "Ljava/lang/Object;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"mutex");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(34,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(24,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(25,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(26,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(35,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(36,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(35,L7);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2},new Method("Ljava/lang/Object;","<init>",new String[]{ },"V"));
                code.visitLabel(L2);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitFieldStmt(IPUT_BOOLEAN,0,2,new Field("Lorg/mortbay/util/ajax/WaitingContinuation;","_new","Z"));
                code.visitLabel(L3);
                code.visitFieldStmt(IPUT_BOOLEAN,1,2,new Field("Lorg/mortbay/util/ajax/WaitingContinuation;","_resumed","Z"));
                code.visitLabel(L4);
                code.visitFieldStmt(IPUT_BOOLEAN,1,2,new Field("Lorg/mortbay/util/ajax/WaitingContinuation;","_pending","Z"));
                code.visitLabel(L5);
                DexLabel L8=new DexLabel();
                code.visitJumpStmt(IF_NEZ,3,-1,L8);
                code.visitStmt2R(MOVE_OBJECT,0,2);
                DexLabel L9=new DexLabel();
                code.visitLabel(L9);
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/util/ajax/WaitingContinuation;","_mutex","Ljava/lang/Object;"));
                code.visitLabel(L6);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L8);
                code.visitStmt2R(MOVE_OBJECT,0,3);
                code.visitLabel(L7);
                code.visitJumpStmt(GOTO,-1,-1,L9);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_getMutex(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/ajax/WaitingContinuation;","getMutex",new String[]{ },"Ljava/lang/Object;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(123,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/util/ajax/WaitingContinuation;","_mutex","Ljava/lang/Object;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_getObject(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/ajax/WaitingContinuation;","getObject",new String[]{ },"Ljava/lang/Object;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(113,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/util/ajax/WaitingContinuation;","_object","Ljava/lang/Object;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_isNew(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/ajax/WaitingContinuation;","isNew",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(59,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_BOOLEAN,0,1,new Field("Lorg/mortbay/util/ajax/WaitingContinuation;","_new","Z"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_isPending(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/ajax/WaitingContinuation;","isPending",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(97,L3);
                ddv.visitLineNumber(99,L0);
                ddv.visitLineNumber(100,L2);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/util/ajax/WaitingContinuation;","_mutex","Ljava/lang/Object;"));
                code.visitStmt1R(MONITOR_ENTER,0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_BOOLEAN,1,2,new Field("Lorg/mortbay/util/ajax/WaitingContinuation;","_pending","Z"));
                code.visitStmt1R(MONITOR_EXIT,0);
                code.visitStmt1R(RETURN,1);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitStmt1R(MONITOR_EXIT,0);
                code.visitLabel(L1);
                code.visitStmt1R(THROW,1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_isResumed(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/ajax/WaitingContinuation;","isResumed",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(105,L3);
                ddv.visitLineNumber(107,L0);
                ddv.visitLineNumber(108,L2);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/util/ajax/WaitingContinuation;","_mutex","Ljava/lang/Object;"));
                code.visitStmt1R(MONITOR_ENTER,0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_BOOLEAN,1,2,new Field("Lorg/mortbay/util/ajax/WaitingContinuation;","_resumed","Z"));
                code.visitStmt1R(MONITOR_EXIT,0);
                code.visitStmt1R(RETURN,1);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitStmt1R(MONITOR_EXIT,0);
                code.visitLabel(L1);
                code.visitStmt1R(THROW,1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m007_reset(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/ajax/WaitingContinuation;","reset",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(49,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(51,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(52,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(53,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(54,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(55,L8);
                ddv.visitLineNumber(54,L2);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/util/ajax/WaitingContinuation;","_mutex","Ljava/lang/Object;"));
                code.visitStmt1R(MONITOR_ENTER,0);
                code.visitLabel(L4);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_BOOLEAN,1,2,new Field("Lorg/mortbay/util/ajax/WaitingContinuation;","_resumed","Z"));
                code.visitLabel(L5);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_BOOLEAN,1,2,new Field("Lorg/mortbay/util/ajax/WaitingContinuation;","_pending","Z"));
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/util/ajax/WaitingContinuation;","_mutex","Ljava/lang/Object;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/lang/Object;","notify",new String[]{ },"V"));
                code.visitLabel(L7);
                code.visitStmt1R(MONITOR_EXIT,0);
                code.visitLabel(L8);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitStmt1R(MONITOR_EXIT,0);
                code.visitLabel(L1);
                code.visitStmt1R(THROW,1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m008_resume(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/ajax/WaitingContinuation;","resume",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(40,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(42,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(43,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(44,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(45,L7);
                ddv.visitLineNumber(44,L2);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/util/ajax/WaitingContinuation;","_mutex","Ljava/lang/Object;"));
                code.visitStmt1R(MONITOR_ENTER,0);
                code.visitLabel(L4);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_BOOLEAN,1,2,new Field("Lorg/mortbay/util/ajax/WaitingContinuation;","_resumed","Z"));
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/util/ajax/WaitingContinuation;","_mutex","Ljava/lang/Object;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/lang/Object;","notify",new String[]{ },"V"));
                code.visitLabel(L6);
                code.visitStmt1R(MONITOR_EXIT,0);
                code.visitLabel(L7);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitStmt1R(MONITOR_EXIT,0);
                code.visitLabel(L1);
                code.visitStmt1R(THROW,1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m009_setMutex(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/ajax/WaitingContinuation;","setMutex",new String[]{ "Ljava/lang/Object;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"mutex");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(128,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(129,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(130,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(131,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(130,L4);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_BOOLEAN,0,1,new Field("Lorg/mortbay/util/ajax/WaitingContinuation;","_pending","Z"));
                code.visitJumpStmt(IF_EQZ,0,-1,L2);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/util/ajax/WaitingContinuation;","_mutex","Ljava/lang/Object;"));
                code.visitJumpStmt(IF_EQ,2,0,L2);
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/IllegalStateException;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/IllegalStateException;","<init>",new String[]{ },"V"));
                code.visitStmt1R(THROW,0);
                code.visitLabel(L2);
                DexLabel L5=new DexLabel();
                code.visitJumpStmt(IF_NEZ,2,-1,L5);
                code.visitStmt2R(MOVE_OBJECT,0,1);
                DexLabel L6=new DexLabel();
                code.visitLabel(L6);
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/util/ajax/WaitingContinuation;","_mutex","Ljava/lang/Object;"));
                code.visitLabel(L3);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L5);
                code.visitStmt2R(MOVE_OBJECT,0,2);
                code.visitLabel(L4);
                code.visitJumpStmt(GOTO,-1,-1,L6);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m010_setObject(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/ajax/WaitingContinuation;","setObject",new String[]{ "Ljava/lang/Object;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"object");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(118,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(119,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/util/ajax/WaitingContinuation;","_object","Ljava/lang/Object;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m011_suspend(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/ajax/WaitingContinuation;","suspend",new String[]{ "J"},"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(9);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                DexLabel L5=new DexLabel();
                code.visitTryCatch(L1,L3,new DexLabel[]{L4,L5},new String[]{ "Ljava/lang/InterruptedException;",null});
                DexLabel L6=new DexLabel();
                code.visitTryCatch(L3,L6,new DexLabel[]{L2},new String[]{ null});
                DexLabel L7=new DexLabel();
                DexLabel L8=new DexLabel();
                code.visitTryCatch(L7,L8,new DexLabel[]{L4,L5},new String[]{ "Ljava/lang/InterruptedException;",null});
                DexLabel L9=new DexLabel();
                DexLabel L10=new DexLabel();
                code.visitTryCatch(L9,L10,new DexLabel[]{L5},new String[]{ null});
                DexLabel L11=new DexLabel();
                code.visitTryCatch(L10,L11,new DexLabel[]{L2},new String[]{ null});
                DexLabel L12=new DexLabel();
                DexLabel L13=new DexLabel();
                code.visitTryCatch(L12,L13,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"timeout");
                DexLabel L14=new DexLabel();
                ddv.visitPrologue(L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(64,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(66,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(67,L17);
                ddv.visitLineNumber(71,L1);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(73,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(74,L19);
                ddv.visitLineNumber(86,L3);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(87,L20);
                ddv.visitStartLocal(1,L20,"result","Z",null);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(88,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(91,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(75,L23);
                ddv.visitEndLocal(1,L23);
                ddv.visitLineNumber(76,L7);
                ddv.visitLineNumber(80,L4);
                ddv.visitLineNumber(82,L9);
                ddv.visitStartLocal(0,L9,"e","Ljava/lang/InterruptedException;",null);
                ddv.visitLineNumber(86,L10);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(87,L24);
                ddv.visitRestartLocal(1,L24);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(88,L25);
                ddv.visitLineNumber(92,L2);
                ddv.visitEndLocal(0,L2);
                ddv.visitEndLocal(1,L2);
                ddv.visitLineNumber(86,L5);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(87,L26);
                ddv.visitRestartLocal(1,L26);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(88,L27);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(86,L28);
                code.visitLabel(L14);
                code.visitConstStmt(CONST_WIDE_16,4,Long.valueOf(0L)); // long: 0x0000000000000000  double:0.000000
                code.visitLabel(L15);
                code.visitFieldStmt(IGET_OBJECT,2,6,new Field("Lorg/mortbay/util/ajax/WaitingContinuation;","_mutex","Ljava/lang/Object;"));
                code.visitStmt1R(MONITOR_ENTER,2);
                code.visitLabel(L16);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_BOOLEAN,3,6,new Field("Lorg/mortbay/util/ajax/WaitingContinuation;","_new","Z"));
                code.visitLabel(L17);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitFieldStmt(IPUT_BOOLEAN,3,6,new Field("Lorg/mortbay/util/ajax/WaitingContinuation;","_pending","Z"));
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_BOOLEAN,3,6,new Field("Lorg/mortbay/util/ajax/WaitingContinuation;","_resumed","Z"));
                code.visitJumpStmt(IF_NEZ,3,-1,L3);
                code.visitStmt3R(CMP_LONG,3,7,4);
                code.visitJumpStmt(IF_LTZ,3,-1,L3);
                code.visitLabel(L18);
                code.visitStmt3R(CMP_LONG,3,7,4);
                code.visitJumpStmt(IF_NEZ,3,-1,L23);
                code.visitLabel(L19);
                code.visitFieldStmt(IGET_OBJECT,3,6,new Field("Lorg/mortbay/util/ajax/WaitingContinuation;","_mutex","Ljava/lang/Object;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/lang/Object;","wait",new String[]{ },"V"));
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_BOOLEAN,1,6,new Field("Lorg/mortbay/util/ajax/WaitingContinuation;","_resumed","Z"));
                code.visitLabel(L20);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_BOOLEAN,3,6,new Field("Lorg/mortbay/util/ajax/WaitingContinuation;","_resumed","Z"));
                code.visitLabel(L21);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_BOOLEAN,3,6,new Field("Lorg/mortbay/util/ajax/WaitingContinuation;","_pending","Z"));
                code.visitLabel(L22);
                code.visitStmt1R(MONITOR_EXIT,2);
                code.visitLabel(L6);
                code.visitStmt1R(RETURN,1);
                code.visitLabel(L23);
                code.visitStmt3R(CMP_LONG,3,7,4);
                code.visitJumpStmt(IF_LEZ,3,-1,L3);
                code.visitLabel(L7);
                code.visitFieldStmt(IGET_OBJECT,3,6,new Field("Lorg/mortbay/util/ajax/WaitingContinuation;","_mutex","Ljava/lang/Object;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,7,8},new Method("Ljava/lang/Object;","wait",new String[]{ "J"},"V"));
                code.visitLabel(L8);
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitLabel(L4);
                code.visitStmt1R(MOVE_EXCEPTION,3);
                code.visitStmt2R(MOVE_OBJECT,0,3);
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/log/Log;","ignore",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitLabel(L10);
                code.visitFieldStmt(IGET_BOOLEAN,1,6,new Field("Lorg/mortbay/util/ajax/WaitingContinuation;","_resumed","Z"));
                code.visitLabel(L24);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_BOOLEAN,3,6,new Field("Lorg/mortbay/util/ajax/WaitingContinuation;","_resumed","Z"));
                code.visitLabel(L25);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_BOOLEAN,3,6,new Field("Lorg/mortbay/util/ajax/WaitingContinuation;","_pending","Z"));
                code.visitJumpStmt(GOTO,-1,-1,L22);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,3);
                code.visitStmt1R(MONITOR_EXIT,2);
                code.visitLabel(L11);
                code.visitStmt1R(THROW,3);
                code.visitLabel(L5);
                code.visitStmt1R(MOVE_EXCEPTION,3);
                code.visitLabel(L12);
                code.visitFieldStmt(IGET_BOOLEAN,1,6,new Field("Lorg/mortbay/util/ajax/WaitingContinuation;","_resumed","Z"));
                code.visitLabel(L26);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_BOOLEAN,4,6,new Field("Lorg/mortbay/util/ajax/WaitingContinuation;","_resumed","Z"));
                code.visitLabel(L27);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_BOOLEAN,4,6,new Field("Lorg/mortbay/util/ajax/WaitingContinuation;","_pending","Z"));
                code.visitLabel(L28);
                code.visitStmt1R(THROW,3);
                code.visitLabel(L13);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m012_toString(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/ajax/WaitingContinuation;","toString",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(135,L4);
                ddv.visitLineNumber(137,L0);
                ddv.visitLineNumber(141,L2);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_STRING,2,"");
                code.visitLabel(L4);
                code.visitStmt1R(MONITOR_ENTER,3);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,1,"WaitingContinuation@");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/lang/Object;","hashCode",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "I"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IGET_BOOLEAN,1,3,new Field("Lorg/mortbay/util/ajax/WaitingContinuation;","_new","Z"));
                DexLabel L5=new DexLabel();
                code.visitJumpStmt(IF_EQZ,1,-1,L5);
                code.visitConstStmt(CONST_STRING,1,",new");
                DexLabel L6=new DexLabel();
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IGET_BOOLEAN,1,3,new Field("Lorg/mortbay/util/ajax/WaitingContinuation;","_pending","Z"));
                DexLabel L7=new DexLabel();
                code.visitJumpStmt(IF_EQZ,1,-1,L7);
                code.visitConstStmt(CONST_STRING,1,",pending");
                DexLabel L8=new DexLabel();
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IGET_BOOLEAN,1,3,new Field("Lorg/mortbay/util/ajax/WaitingContinuation;","_resumed","Z"));
                DexLabel L9=new DexLabel();
                code.visitJumpStmt(IF_EQZ,1,-1,L9);
                code.visitConstStmt(CONST_STRING,1,",resumed");
                DexLabel L10=new DexLabel();
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt1R(MONITOR_EXIT,3);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L5);
                code.visitConstStmt(CONST_STRING,1,"");
                code.visitStmt2R(MOVE_OBJECT,1,2);
                code.visitJumpStmt(GOTO,-1,-1,L6);
                code.visitLabel(L7);
                code.visitConstStmt(CONST_STRING,1,"");
                code.visitStmt2R(MOVE_OBJECT,1,2);
                code.visitJumpStmt(GOTO,-1,-1,L8);
                code.visitLabel(L9);
                code.visitConstStmt(CONST_STRING,1,"");
                code.visitStmt2R(MOVE_OBJECT,1,2);
                code.visitJumpStmt(GOTO,-1,-1,L10);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,0);
                code.visitStmt1R(MONITOR_EXIT,3);
                code.visitLabel(L1);
                code.visitStmt1R(THROW,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
