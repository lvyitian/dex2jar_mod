package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0013_javax_servlet_ServletInputStream {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC|ACC_ABSTRACT,"Ljavax/servlet/ServletInputStream;","Ljava/io/InputStream;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("ServletInputStream.java");
        m000__init_(cv);
        m001_readLine(cv);
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED|ACC_CONSTRUCTOR, new Method("Ljavax/servlet/ServletInputStream;","<init>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(65,L0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/io/InputStream;","<init>",new String[]{ },"V"));
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001_readLine(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Ljavax/servlet/ServletInputStream;","readLine",new String[]{ "[B","I","I"},"I"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(9);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"b");
                ddv.visitParameterName(1,"off");
                ddv.visitParameterName(2,"len");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(99,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(100,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(111,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(102,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(104,L5);
                ddv.visitStartLocal(1,L5,"count","I",null);
                DexLabel L6=new DexLabel();
                ddv.visitStartLocal(0,L6,"c","I",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(105,L7);
                DexLabel L8=new DexLabel();
                ddv.visitStartLocal(2,L8,"off","I",null);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(106,L9);
                ddv.visitEndLocal(7,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(107,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(111,L11);
                ddv.visitEndLocal(2,L11);
                ddv.visitRestartLocal(7,L11);
                DexLabel L12=new DexLabel();
                ddv.visitEndLocal(7,L12);
                ddv.visitRestartLocal(2,L12);
                DexLabel L13=new DexLabel();
                ddv.visitRestartLocal(7,L13);
                DexLabel L14=new DexLabel();
                ddv.visitEndLocal(7,L14);
                DexLabel L15=new DexLabel();
                ddv.visitRestartLocal(7,L15);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(-1)); // int: 0xffffffff  float:NaN
                code.visitLabel(L1);
                code.visitJumpStmt(IF_GTZ,8,-1,L4);
                code.visitLabel(L2);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L3);
                code.visitStmt1R(RETURN,3);
                code.visitLabel(L4);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljavax/servlet/ServletInputStream;","read",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitLabel(L6);
                code.visitJumpStmt(IF_EQ,0,4,L11);
                code.visitLabel(L7);
                code.visitStmt2R1N(ADD_INT_LIT8,2,7,1);
                code.visitLabel(L8);
                code.visitStmt2R(INT_TO_BYTE,3,0);
                code.visitStmt3R(APUT_BYTE,3,6,7);
                code.visitLabel(L9);
                code.visitStmt2R1N(ADD_INT_LIT8,1,1,1);
                code.visitLabel(L10);
                code.visitConstStmt(CONST_16,3, Integer.valueOf(10)); // int: 0x0000000a  float:0.000000
                code.visitJumpStmt(IF_EQ,0,3,L14);
                code.visitJumpStmt(IF_NE,1,8,L12);
                code.visitStmt2R(MOVE,7,2);
                code.visitLabel(L11);
                DexLabel L16=new DexLabel();
                code.visitJumpStmt(IF_LEZ,1,-1,L16);
                code.visitStmt2R(MOVE,3,1);
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitLabel(L16);
                code.visitStmt2R(MOVE,3,4);
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitLabel(L12);
                code.visitStmt2R(MOVE,7,2);
                code.visitLabel(L13);
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitLabel(L14);
                code.visitStmt2R(MOVE,7,2);
                code.visitLabel(L15);
                code.visitJumpStmt(GOTO,-1,-1,L11);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
