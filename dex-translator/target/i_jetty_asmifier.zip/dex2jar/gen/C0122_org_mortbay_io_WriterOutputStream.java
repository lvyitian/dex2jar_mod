package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0122_org_mortbay_io_WriterOutputStream {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/io/WriterOutputStream;","Ljava/io/OutputStream;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("WriterOutputStream.java");
        f000__buf(cv);
        f001__encoding(cv);
        f002__writer(cv);
        m000__init_(cv);
        m001__init_(cv);
        m002_close(cv);
        m003_flush(cv);
        m004_write(cv);
        m005_write(cv);
        m006_write(cv);
    }
    public static void f000__buf(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/io/WriterOutputStream;","_buf","[B"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001__encoding(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/io/WriterOutputStream;","_encoding","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002__writer(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/io/WriterOutputStream;","_writer","Ljava/io/Writer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/io/WriterOutputStream;","<init>",new String[]{ "Ljava/io/Writer;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"writer");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(44,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(33,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(45,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(46,L3);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljava/io/OutputStream;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitTypeStmt(NEW_ARRAY,0,0,"[B");
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/io/WriterOutputStream;","_buf","[B"));
                code.visitLabel(L2);
                code.visitFieldStmt(IPUT_OBJECT,2,1,new Field("Lorg/mortbay/io/WriterOutputStream;","_writer","Ljava/io/Writer;"));
                code.visitLabel(L3);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/io/WriterOutputStream;","<init>",new String[]{ "Ljava/io/Writer;","Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"writer");
                ddv.visitParameterName(1,"encoding");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(37,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(33,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(38,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(39,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(40,L4);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljava/io/OutputStream;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitTypeStmt(NEW_ARRAY,0,0,"[B");
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/io/WriterOutputStream;","_buf","[B"));
                code.visitLabel(L2);
                code.visitFieldStmt(IPUT_OBJECT,2,1,new Field("Lorg/mortbay/io/WriterOutputStream;","_writer","Ljava/io/Writer;"));
                code.visitLabel(L3);
                code.visitFieldStmt(IPUT_OBJECT,3,1,new Field("Lorg/mortbay/io/WriterOutputStream;","_encoding","Ljava/lang/String;"));
                code.visitLabel(L4);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_close(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/WriterOutputStream;","close",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(52,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(53,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(54,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(55,L4);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/io/WriterOutputStream;","_writer","Ljava/io/Writer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/io/Writer;","close",new String[]{ },"V"));
                code.visitLabel(L2);
                code.visitFieldStmt(IPUT_OBJECT,1,2,new Field("Lorg/mortbay/io/WriterOutputStream;","_writer","Ljava/io/Writer;"));
                code.visitLabel(L3);
                code.visitFieldStmt(IPUT_OBJECT,1,2,new Field("Lorg/mortbay/io/WriterOutputStream;","_encoding","Ljava/lang/String;"));
                code.visitLabel(L4);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_flush(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/WriterOutputStream;","flush",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(61,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(62,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/io/WriterOutputStream;","_writer","Ljava/io/Writer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/io/Writer;","flush",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_write(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/WriterOutputStream;","write",new String[]{ "I"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"b");
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(88,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(89,L4);
                ddv.visitLineNumber(90,L1);
                ddv.visitLineNumber(88,L2);
                code.visitLabel(L3);
                code.visitStmt1R(MONITOR_ENTER,3);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/io/WriterOutputStream;","_buf","[B"));
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt2R(INT_TO_BYTE,2,4);
                code.visitStmt3R(APUT_BYTE,2,0,1);
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/io/WriterOutputStream;","_buf","[B"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,0},new Method("Lorg/mortbay/io/WriterOutputStream;","write",new String[]{ "[B"},"V"));
                code.visitLabel(L1);
                code.visitStmt1R(MONITOR_EXIT,3);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,0);
                code.visitStmt1R(MONITOR_EXIT,3);
                code.visitStmt1R(THROW,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_write(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/WriterOutputStream;","write",new String[]{ "[B"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"b");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(68,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(69,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(72,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(71,L3);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/io/WriterOutputStream;","_encoding","Ljava/lang/String;"));
                code.visitJumpStmt(IF_NEZ,0,-1,L3);
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/io/WriterOutputStream;","_writer","Ljava/io/Writer;"));
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/lang/String;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,4},new Method("Ljava/lang/String;","<init>",new String[]{ "[B"},"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/io/Writer;","write",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/io/WriterOutputStream;","_writer","Ljava/io/Writer;"));
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/lang/String;");
                code.visitFieldStmt(IGET_OBJECT,2,3,new Field("Lorg/mortbay/io/WriterOutputStream;","_encoding","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,4,2},new Method("Ljava/lang/String;","<init>",new String[]{ "[B","Ljava/lang/String;"},"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/io/Writer;","write",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_write(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/WriterOutputStream;","write",new String[]{ "[B","I","I"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"b");
                ddv.visitParameterName(1,"off");
                ddv.visitParameterName(2,"len");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(78,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(79,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(82,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(81,L3);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/io/WriterOutputStream;","_encoding","Ljava/lang/String;"));
                code.visitJumpStmt(IF_NEZ,0,-1,L3);
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/io/WriterOutputStream;","_writer","Ljava/io/Writer;"));
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/lang/String;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,4,5,6},new Method("Ljava/lang/String;","<init>",new String[]{ "[B","I","I"},"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/io/Writer;","write",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/io/WriterOutputStream;","_writer","Ljava/io/Writer;"));
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/lang/String;");
                code.visitFieldStmt(IGET_OBJECT,2,3,new Field("Lorg/mortbay/io/WriterOutputStream;","_encoding","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,4,5,6,2},new Method("Ljava/lang/String;","<init>",new String[]{ "[B","I","I","Ljava/lang/String;"},"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/io/Writer;","write",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
