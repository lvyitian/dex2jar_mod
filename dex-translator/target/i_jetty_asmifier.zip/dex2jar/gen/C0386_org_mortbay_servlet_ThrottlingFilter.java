package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0386_org_mortbay_servlet_ThrottlingFilter {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/servlet/ThrottlingFilter;","Ljava/lang/Object;",new String[]{ "Ljavax/servlet/Filter;"});
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("ThrottlingFilter.java");
        f000__current(cv);
        f001__lock(cv);
        f002__maximum(cv);
        f003__queue(cv);
        f004__queueSize(cv);
        f005__queueTimeout(cv);
        m000__init_(cv);
        m001_acceptRequest(cv);
        m002_dropFromQueue(cv);
        m003_getContinuation(cv);
        m004_getIntegerParameter(cv);
        m005_popQueue(cv);
        m006_queueRequest(cv);
        m007_releaseRequest(cv);
        m008_destroy(cv);
        m009_doFilter(cv);
        m010_doFilter(cv);
        m011_init(cv);
        m012_rejectRequest(cv);
    }
    public static void f000__current(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/servlet/ThrottlingFilter;","_current","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001__lock(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_FINAL, new Field("Lorg/mortbay/servlet/ThrottlingFilter;","_lock","Ljava/lang/Object;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002__maximum(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/servlet/ThrottlingFilter;","_maximum","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003__queue(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_FINAL, new Field("Lorg/mortbay/servlet/ThrottlingFilter;","_queue","Ljava/util/List;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f004__queueSize(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/servlet/ThrottlingFilter;","_queueSize","J"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f005__queueTimeout(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/servlet/ThrottlingFilter;","_queueTimeout","J"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/servlet/ThrottlingFilter;","<init>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(92,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(93,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(94,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(95,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(96,L4);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljava/lang/Object;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT,0,1,new Field("Lorg/mortbay/servlet/ThrottlingFilter;","_current","I"));
                code.visitLabel(L2);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/Object;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/Object;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/servlet/ThrottlingFilter;","_lock","Ljava/lang/Object;"));
                code.visitLabel(L3);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/util/LinkedList;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/util/LinkedList;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/servlet/ThrottlingFilter;","_queue","Ljava/util/List;"));
                code.visitLabel(L4);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001_acceptRequest(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PRIVATE, new Method("Lorg/mortbay/servlet/ThrottlingFilter;","acceptRequest",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(216,L3);
                ddv.visitLineNumber(218,L0);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(220,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(221,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(224,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(223,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(224,L8);
                ddv.visitLineNumber(223,L2);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/servlet/ThrottlingFilter;","_lock","Ljava/lang/Object;"));
                code.visitStmt1R(MONITOR_ENTER,0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,1,3,new Field("Lorg/mortbay/servlet/ThrottlingFilter;","_current","I"));
                code.visitFieldStmt(IGET,2,3,new Field("Lorg/mortbay/servlet/ThrottlingFilter;","_maximum","I"));
                code.visitJumpStmt(IF_GE,1,2,L7);
                code.visitLabel(L4);
                code.visitFieldStmt(IGET,1,3,new Field("Lorg/mortbay/servlet/ThrottlingFilter;","_current","I"));
                code.visitStmt2R1N(ADD_INT_LIT8,1,1,1);
                code.visitFieldStmt(IPUT,1,3,new Field("Lorg/mortbay/servlet/ThrottlingFilter;","_current","I"));
                code.visitLabel(L5);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt1R(MONITOR_EXIT,0);
                code.visitStmt2R(MOVE,0,1);
                code.visitLabel(L6);
                code.visitStmt1R(RETURN,0);
                code.visitLabel(L7);
                code.visitStmt1R(MONITOR_EXIT,0);
                code.visitLabel(L8);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L6);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitStmt1R(MONITOR_EXIT,0);
                code.visitLabel(L1);
                code.visitStmt1R(THROW,1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_dropFromQueue(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PRIVATE, new Method("Lorg/mortbay/servlet/ThrottlingFilter;","dropFromQueue",new String[]{ "Lorg/mortbay/util/ajax/Continuation;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"continuation");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(181,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(182,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(183,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/servlet/ThrottlingFilter;","_queue","Ljava/util/List;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,2},new Method("Ljava/util/List;","remove",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2},new Method("Lorg/mortbay/util/ajax/Continuation;","reset",new String[]{ },"V"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_getContinuation(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PRIVATE, new Method("Lorg/mortbay/servlet/ThrottlingFilter;","getContinuation",new String[]{ "Ljavax/servlet/ServletRequest;"},"Lorg/mortbay/util/ajax/Continuation;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"request");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(249,L0);
                DexLabel L1=new DexLabel();
                ddv.visitEndLocal(1,L1);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_STRING,0,"org.mortbay.jetty.ajax.Continuation");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2,0},new Method("Ljavax/servlet/ServletRequest;","getAttribute",new String[]{ "Ljava/lang/String;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L1);
                code.visitTypeStmt(CHECK_CAST,1,-1,"Lorg/mortbay/util/ajax/Continuation;");
                code.visitStmt1R(RETURN_OBJECT,1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_getIntegerParameter(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PRIVATE, new Method("Lorg/mortbay/servlet/ThrottlingFilter;","getIntegerParameter",new String[]{ "Ljavax/servlet/FilterConfig;","Ljava/lang/String;","I"},"I"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljavax/servlet/ServletException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(9);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/lang/NumberFormatException;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"filterConfig");
                ddv.visitParameterName(1,"name");
                ddv.visitParameterName(2,"defaultValue");
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(116,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(117,L4);
                ddv.visitStartLocal(1,L4,"value","Ljava/lang/String;",null);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(123,L5);
                ddv.visitLineNumber(125,L2);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(127,L6);
                ddv.visitStartLocal(0,L6,"e","Ljava/lang/NumberFormatException;",null);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 6,7},new Method("Ljavax/servlet/FilterConfig;","getInitParameter",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L4);
                code.visitJumpStmt(IF_NEZ,1,-1,L0);
                code.visitStmt2R(MOVE,2,8);
                code.visitLabel(L5);
                code.visitStmt1R(RETURN,2);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1},new Method("Ljava/lang/Integer;","parseInt",new String[]{ "Ljava/lang/String;"},"I"));
                code.visitLabel(L1);
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,0);
                code.visitLabel(L6);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Ljavax/servlet/ServletException;");
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,4,"Parameter ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,7},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitConstStmt(CONST_STRING,4," must be a number (was ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitConstStmt(CONST_STRING,4," instead)");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2,3},new Method("Ljavax/servlet/ServletException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_popQueue(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PRIVATE, new Method("Lorg/mortbay/servlet/ThrottlingFilter;","popQueue",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L5=new DexLabel();
                ddv.visitPrologue(L5);
                ddv.visitLineNumber(194,L5);
                ddv.visitLineNumber(196,L0);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(198,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(204,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(200,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(201,L9);
                ddv.visitStartLocal(0,L9,"continuation","Lorg/mortbay/util/ajax/Continuation;",null);
                ddv.visitLineNumber(202,L1);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(203,L10);
                ddv.visitLineNumber(201,L2);
                ddv.visitEndLocal(0,L2);
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/servlet/ThrottlingFilter;","_queue","Ljava/util/List;"));
                code.visitStmt1R(MONITOR_ENTER,1);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,2,4,new Field("Lorg/mortbay/servlet/ThrottlingFilter;","_queue","Ljava/util/List;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2},new Method("Ljava/util/List;","isEmpty",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_EQZ,2,-1,L8);
                code.visitLabel(L6);
                code.visitStmt1R(MONITOR_EXIT,1);
                code.visitLabel(L7);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L8);
                code.visitFieldStmt(IGET_OBJECT,2,4,new Field("Lorg/mortbay/servlet/ThrottlingFilter;","_queue","Ljava/util/List;"));
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2,3},new Method("Ljava/util/List;","remove",new String[]{ "I"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Lorg/mortbay/util/ajax/Continuation;");
                code.visitLabel(L9);
                code.visitStmt1R(MONITOR_EXIT,1);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_STRING,1,"Resuming continuation {}");
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1,0,2},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Lorg/mortbay/util/ajax/Continuation;","resume",new String[]{ },"V"));
                code.visitJumpStmt(GOTO,-1,-1,L7);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,2);
                code.visitLabel(L3);
                code.visitStmt1R(MONITOR_EXIT,1);
                code.visitLabel(L4);
                code.visitStmt1R(THROW,2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_queueRequest(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PRIVATE, new Method("Lorg/mortbay/servlet/ThrottlingFilter;","queueRequest",new String[]{ "Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;","Lorg/mortbay/util/ajax/Continuation;"},"Z"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visit(null, new DexType("Ljavax/servlet/ServletException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(10);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"request");
                ddv.visitParameterName(1,"response");
                ddv.visitParameterName(2,"continuation");
                DexLabel L5=new DexLabel();
                ddv.visitPrologue(L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(230,L6);
                ddv.visitLineNumber(232,L0);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(234,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(235,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(244,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(238,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(239,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(240,L12);
                ddv.visitLineNumber(242,L1);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(243,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(244,L14);
                ddv.visitLineNumber(240,L2);
                code.visitLabel(L5);
                code.visitConstStmt(CONST_4,5, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,0,6,new Field("Lorg/mortbay/servlet/ThrottlingFilter;","_queue","Ljava/util/List;"));
                code.visitStmt1R(MONITOR_ENTER,0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,1,6,new Field("Lorg/mortbay/servlet/ThrottlingFilter;","_queue","Ljava/util/List;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Ljava/util/List;","size",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitStmt2R(INT_TO_LONG,1,1);
                code.visitFieldStmt(IGET_WIDE,3,6,new Field("Lorg/mortbay/servlet/ThrottlingFilter;","_queueSize","J"));
                code.visitStmt3R(CMP_LONG,1,1,3);
                code.visitJumpStmt(IF_LTZ,1,-1,L10);
                code.visitLabel(L7);
                code.visitConstStmt(CONST_STRING,1,"Queue is full, rejecting request {}");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 7},new Method("Ljavax/servlet/http/HttpServletRequest;","getRequestURI",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1,2,3},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L8);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt1R(MONITOR_EXIT,0);
                code.visitStmt2R(MOVE,0,1);
                code.visitLabel(L9);
                code.visitStmt1R(RETURN,0);
                code.visitLabel(L10);
                code.visitConstStmt(CONST_STRING,1,"Queuing request {} / {}");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 7},new Method("Ljavax/servlet/http/HttpServletRequest;","getRequestURI",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1,2,9},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L11);
                code.visitFieldStmt(IGET_OBJECT,1,6,new Field("Lorg/mortbay/servlet/ThrottlingFilter;","_queue","Ljava/util/List;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1,9},new Method("Ljava/util/List;","add",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitLabel(L12);
                code.visitStmt1R(MONITOR_EXIT,0);
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_WIDE,0,6,new Field("Lorg/mortbay/servlet/ThrottlingFilter;","_queueTimeout","J"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 9,0,1},new Method("Lorg/mortbay/util/ajax/Continuation;","suspend",new String[]{ "J"},"Z"));
                code.visitLabel(L13);
                code.visitConstStmt(CONST_STRING,0,"Resuming blocking continuation for request {}");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 7},new Method("Ljavax/servlet/http/HttpServletRequest;","getRequestURI",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,1,5},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L14);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L9);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitLabel(L3);
                code.visitStmt1R(MONITOR_EXIT,0);
                code.visitLabel(L4);
                code.visitStmt1R(THROW,1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m007_releaseRequest(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PRIVATE, new Method("Lorg/mortbay/servlet/ThrottlingFilter;","releaseRequest",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(208,L3);
                ddv.visitLineNumber(210,L0);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(211,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(212,L5);
                ddv.visitLineNumber(211,L2);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/servlet/ThrottlingFilter;","_lock","Ljava/lang/Object;"));
                code.visitStmt1R(MONITOR_ENTER,0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,1,3,new Field("Lorg/mortbay/servlet/ThrottlingFilter;","_current","I"));
                code.visitConstStmt(CONST_4,2, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt2R(SUB_INT_2ADDR,1,2);
                code.visitFieldStmt(IPUT,1,3,new Field("Lorg/mortbay/servlet/ThrottlingFilter;","_current","I"));
                code.visitLabel(L4);
                code.visitStmt1R(MONITOR_EXIT,0);
                code.visitLabel(L5);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitStmt1R(MONITOR_EXIT,0);
                code.visitLabel(L1);
                code.visitStmt1R(THROW,1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m008_destroy(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/servlet/ThrottlingFilter;","destroy",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(254,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(255,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/servlet/ThrottlingFilter;","_queue","Ljava/util/List;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Ljava/util/List;","clear",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m009_doFilter(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/servlet/ThrottlingFilter;","doFilter",new String[]{ "Ljavax/servlet/ServletRequest;","Ljavax/servlet/ServletResponse;","Ljavax/servlet/FilterChain;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visit(null, new DexType("Ljavax/servlet/ServletException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"request");
                ddv.visitParameterName(1,"response");
                ddv.visitParameterName(2,"chain");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(134,L0);
                DexLabel L1=new DexLabel();
                ddv.visitEndLocal(1,L1);
                DexLabel L2=new DexLabel();
                ddv.visitEndLocal(2,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(135,L3);
                code.visitLabel(L0);
                code.visitTypeStmt(CHECK_CAST,1,-1,"Ljavax/servlet/http/HttpServletRequest;");
                code.visitLabel(L1);
                code.visitTypeStmt(CHECK_CAST,2,-1,"Ljavax/servlet/http/HttpServletResponse;");
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2,3},new Method("Lorg/mortbay/servlet/ThrottlingFilter;","doFilter",new String[]{ "Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;","Ljavax/servlet/FilterChain;"},"V"));
                code.visitLabel(L3);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m010_doFilter(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/servlet/ThrottlingFilter;","doFilter",new String[]{ "Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;","Ljavax/servlet/FilterChain;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visit(null, new DexType("Ljavax/servlet/ServletException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(8);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"request");
                ddv.visitParameterName(1,"response");
                ddv.visitParameterName(2,"chain");
                DexLabel L5=new DexLabel();
                ddv.visitPrologue(L5);
                ddv.visitLineNumber(140,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(142,L6);
                ddv.visitStartLocal(1,L6,"continuation","Lorg/mortbay/util/ajax/Continuation;",null);
                ddv.visitLineNumber(146,L0);
                ddv.visitStartLocal(0,L0,"accepted","Z",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(147,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(150,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(152,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(153,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(154,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(163,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(164,L13);
                ddv.visitLineNumber(170,L1);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(172,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(173,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(177,L16);
                ddv.visitLineNumber(157,L3);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(159,L17);
                DexLabel L18=new DexLabel();
                ddv.visitRestartLocal(0,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(166,L19);
                ddv.visitLineNumber(170,L2);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(172,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(173,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(170,L22);
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4,5},new Method("Lorg/mortbay/servlet/ThrottlingFilter;","getContinuation",new String[]{ "Ljavax/servlet/ServletRequest;"},"Lorg/mortbay/util/ajax/Continuation;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L6);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4},new Method("Lorg/mortbay/servlet/ThrottlingFilter;","acceptRequest",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitLabel(L7);
                code.visitJumpStmt(IF_NEZ,0,-1,L12);
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Lorg/mortbay/util/ajax/Continuation;","isPending",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_EQZ,2,-1,L3);
                code.visitLabel(L9);
                code.visitConstStmt(CONST_STRING,2,"Request {} / {} was already queued, rejecting");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 5},new Method("Ljavax/servlet/http/HttpServletRequest;","getRequestURI",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2,3,1},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4,1},new Method("Lorg/mortbay/servlet/ThrottlingFilter;","dropFromQueue",new String[]{ "Lorg/mortbay/util/ajax/Continuation;"},"V"));
                code.visitLabel(L11);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Lorg/mortbay/util/ajax/Continuation;","reset",new String[]{ },"V"));
                code.visitLabel(L12);
                code.visitJumpStmt(IF_EQZ,0,-1,L19);
                code.visitLabel(L13);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 7,5,6},new Method("Ljavax/servlet/FilterChain;","doFilter",new String[]{ "Ljavax/servlet/ServletRequest;","Ljavax/servlet/ServletResponse;"},"V"));
                code.visitLabel(L1);
                code.visitJumpStmt(IF_EQZ,0,-1,L16);
                code.visitLabel(L14);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4},new Method("Lorg/mortbay/servlet/ThrottlingFilter;","releaseRequest",new String[]{ },"V"));
                code.visitLabel(L15);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4},new Method("Lorg/mortbay/servlet/ThrottlingFilter;","popQueue",new String[]{ },"V"));
                code.visitLabel(L16);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4,5,6,1},new Method("Lorg/mortbay/servlet/ThrottlingFilter;","queueRequest",new String[]{ "Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;","Lorg/mortbay/util/ajax/Continuation;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_EQZ,2,-1,L12);
                code.visitLabel(L17);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4},new Method("Lorg/mortbay/servlet/ThrottlingFilter;","acceptRequest",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitLabel(L18);
                code.visitJumpStmt(GOTO,-1,-1,L12);
                code.visitLabel(L19);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5,6},new Method("Lorg/mortbay/servlet/ThrottlingFilter;","rejectRequest",new String[]{ "Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;"},"V"));
                code.visitLabel(L4);
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,2);
                code.visitJumpStmt(IF_EQZ,0,-1,L22);
                code.visitLabel(L20);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4},new Method("Lorg/mortbay/servlet/ThrottlingFilter;","releaseRequest",new String[]{ },"V"));
                code.visitLabel(L21);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4},new Method("Lorg/mortbay/servlet/ThrottlingFilter;","popQueue",new String[]{ },"V"));
                code.visitLabel(L22);
                code.visitStmt1R(THROW,2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m011_init(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/servlet/ThrottlingFilter;","init",new String[]{ "Ljavax/servlet/FilterConfig;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljavax/servlet/ServletException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"filterConfig");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(101,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(102,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(103,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(105,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(107,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(110,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(111,L7);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitConstStmt(CONST_STRING,0,"maximum");
                code.visitConstStmt(CONST_16,1, Integer.valueOf(10)); // int: 0x0000000a  float:0.000000
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 5,6,0,1},new Method("Lorg/mortbay/servlet/ThrottlingFilter;","getIntegerParameter",new String[]{ "Ljavax/servlet/FilterConfig;","Ljava/lang/String;","I"},"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitFieldStmt(IPUT,0,5,new Field("Lorg/mortbay/servlet/ThrottlingFilter;","_maximum","I"));
                code.visitLabel(L2);
                code.visitConstStmt(CONST_STRING,0,"block");
                code.visitConstStmt(CONST_16,1, Integer.valueOf(5000)); // int: 0x00001388  float:0.000000
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 5,6,0,1},new Method("Lorg/mortbay/servlet/ThrottlingFilter;","getIntegerParameter",new String[]{ "Ljavax/servlet/FilterConfig;","Ljava/lang/String;","I"},"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitStmt2R(INT_TO_LONG,0,0);
                code.visitFieldStmt(IPUT_WIDE,0,5,new Field("Lorg/mortbay/servlet/ThrottlingFilter;","_queueTimeout","J"));
                code.visitLabel(L3);
                code.visitConstStmt(CONST_STRING,0,"queue");
                code.visitConstStmt(CONST_16,1, Integer.valueOf(500)); // int: 0x000001f4  float:0.000000
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 5,6,0,1},new Method("Lorg/mortbay/servlet/ThrottlingFilter;","getIntegerParameter",new String[]{ "Ljavax/servlet/FilterConfig;","Ljava/lang/String;","I"},"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitStmt2R(INT_TO_LONG,0,0);
                code.visitFieldStmt(IPUT_WIDE,0,5,new Field("Lorg/mortbay/servlet/ThrottlingFilter;","_queueSize","J"));
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_WIDE,0,5,new Field("Lorg/mortbay/servlet/ThrottlingFilter;","_queueTimeout","J"));
                code.visitConstStmt(CONST_WIDE_16,2,Long.valueOf(-1L)); // long: 0xffffffffffffffff  double:NaN
                code.visitStmt3R(CMP_LONG,0,0,2);
                code.visitJumpStmt(IF_NEZ,0,-1,L6);
                code.visitLabel(L5);
                code.visitConstStmt(CONST_WIDE_32,0,Long.valueOf(2147483647L)); // long: 0x000000007fffffff  double:0.000000
                code.visitFieldStmt(IPUT_WIDE,0,5,new Field("Lorg/mortbay/servlet/ThrottlingFilter;","_queueTimeout","J"));
                code.visitLabel(L6);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,1,"Config{maximum:");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IGET,1,5,new Field("Lorg/mortbay/servlet/ThrottlingFilter;","_maximum","I"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "I"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitConstStmt(CONST_STRING,1,", block:");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IGET_WIDE,1,5,new Field("Lorg/mortbay/servlet/ThrottlingFilter;","_queueTimeout","J"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "J"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitConstStmt(CONST_STRING,1,", queue:");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IGET_WIDE,1,5,new Field("Lorg/mortbay/servlet/ThrottlingFilter;","_queueSize","J"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "J"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitConstStmt(CONST_STRING,1,"}");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,4,4},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L7);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m012_rejectRequest(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/servlet/ThrottlingFilter;","rejectRequest",new String[]{ "Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"request");
                ddv.visitParameterName(1,"response");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(187,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(189,L1);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_16,0, Integer.valueOf(503)); // int: 0x000001f7  float:0.000000
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,2,"Too many active connections to resource ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 4},new Method("Ljavax/servlet/http/HttpServletRequest;","getRequestURI",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 5,0,1},new Method("Ljavax/servlet/http/HttpServletResponse;","sendError",new String[]{ "I","Ljava/lang/String;"},"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
