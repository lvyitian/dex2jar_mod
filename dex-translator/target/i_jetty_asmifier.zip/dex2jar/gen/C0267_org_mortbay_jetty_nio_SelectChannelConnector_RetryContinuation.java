package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0267_org_mortbay_jetty_nio_SelectChannelConnector_RetryContinuation {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/jetty/nio/SelectChannelConnector$RetryContinuation;","Lorg/mortbay/thread/Timeout$Task;",new String[]{ "Lorg/mortbay/util/ajax/Continuation;","Ljava/lang/Runnable;"});
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("SelectChannelConnector.java");
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/EnclosingClass;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("value", new DexType("Lorg/mortbay/jetty/nio/SelectChannelConnector;"));
                av00.visitEnd();
            }
        }
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/InnerClass;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("accessFlags",  Integer.valueOf(9));
                av00.visit("name", "RetryContinuation");
                av00.visitEnd();
            }
        }
        f000__endPoint(cv);
        f001__new(cv);
        f002__object(cv);
        f003__parked(cv);
        f004__pending(cv);
        f005__resumed(cv);
        f006__retry(cv);
        f007__timeout(cv);
        m000__init_(cv);
        m001_expire(cv);
        m002_getObject(cv);
        m003_getTimeout(cv);
        m004_isNew(cv);
        m005_isPending(cv);
        m006_isResumed(cv);
        m007_reset(cv);
        m008_resume(cv);
        m009_run(cv);
        m010_setObject(cv);
        m011_suspend(cv);
        m012_toString(cv);
        m013_undispatch(cv);
    }
    public static void f000__endPoint(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/jetty/nio/SelectChannelConnector$RetryContinuation;","_endPoint","Lorg/mortbay/io/nio/SelectChannelEndPoint;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001__new(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/jetty/nio/SelectChannelConnector$RetryContinuation;","_new","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002__object(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/jetty/nio/SelectChannelConnector$RetryContinuation;","_object","Ljava/lang/Object;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003__parked(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/jetty/nio/SelectChannelConnector$RetryContinuation;","_parked","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f004__pending(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/jetty/nio/SelectChannelConnector$RetryContinuation;","_pending","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f005__resumed(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/jetty/nio/SelectChannelConnector$RetryContinuation;","_resumed","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f006__retry(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/jetty/nio/SelectChannelConnector$RetryContinuation;","_retry","Lorg/mortbay/jetty/RetryRequest;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f007__timeout(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/jetty/nio/SelectChannelConnector$RetryContinuation;","_timeout","J"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/nio/SelectChannelConnector$RetryContinuation;","<init>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(393,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(395,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(396,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(398,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(399,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(400,L6);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2},new Method("Lorg/mortbay/thread/Timeout$Task;","<init>",new String[]{ },"V"));
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/jetty/HttpConnection;","getCurrentConnection",new String[]{ },"Lorg/mortbay/jetty/HttpConnection;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/HttpConnection;","getEndPoint",new String[]{ },"Lorg/mortbay/io/EndPoint;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Lorg/mortbay/io/nio/SelectChannelEndPoint;");
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/jetty/nio/SelectChannelConnector$RetryContinuation;","_endPoint","Lorg/mortbay/io/nio/SelectChannelEndPoint;"));
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitFieldStmt(IPUT_BOOLEAN,0,2,new Field("Lorg/mortbay/jetty/nio/SelectChannelConnector$RetryContinuation;","_new","Z"));
                code.visitLabel(L4);
                code.visitFieldStmt(IPUT_BOOLEAN,1,2,new Field("Lorg/mortbay/jetty/nio/SelectChannelConnector$RetryContinuation;","_pending","Z"));
                code.visitLabel(L5);
                code.visitFieldStmt(IPUT_BOOLEAN,1,2,new Field("Lorg/mortbay/jetty/nio/SelectChannelConnector$RetryContinuation;","_resumed","Z"));
                code.visitLabel(L6);
                code.visitFieldStmt(IPUT_BOOLEAN,1,2,new Field("Lorg/mortbay/jetty/nio/SelectChannelConnector$RetryContinuation;","_parked","Z"));
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001_expire(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/nio/SelectChannelConnector$RetryContinuation;","expire",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L5=new DexLabel();
                ddv.visitPrologue(L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(508,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(509,L7);
                ddv.visitStartLocal(0,L7,"redispatch","Z",null);
                ddv.visitLineNumber(511,L0);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(512,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(513,L9);
                ddv.visitLineNumber(514,L1);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(516,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(517,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(518,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(520,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(511,L14);
                ddv.visitLineNumber(513,L2);
                code.visitLabel(L5);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L6);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L7);
                code.visitStmt1R(MONITOR_ENTER,3);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_BOOLEAN,1,3,new Field("Lorg/mortbay/jetty/nio/SelectChannelConnector$RetryContinuation;","_parked","Z"));
                DexLabel L15=new DexLabel();
                code.visitJumpStmt(IF_EQZ,1,-1,L15);
                code.visitFieldStmt(IGET_BOOLEAN,1,3,new Field("Lorg/mortbay/jetty/nio/SelectChannelConnector$RetryContinuation;","_pending","Z"));
                code.visitJumpStmt(IF_EQZ,1,-1,L15);
                code.visitFieldStmt(IGET_BOOLEAN,1,3,new Field("Lorg/mortbay/jetty/nio/SelectChannelConnector$RetryContinuation;","_resumed","Z"));
                code.visitJumpStmt(IF_NEZ,1,-1,L15);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt2R(MOVE,0,1);
                code.visitLabel(L8);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_BOOLEAN,1,3,new Field("Lorg/mortbay/jetty/nio/SelectChannelConnector$RetryContinuation;","_parked","Z"));
                code.visitLabel(L9);
                code.visitStmt1R(MONITOR_EXIT,3);
                code.visitLabel(L1);
                code.visitJumpStmt(IF_EQZ,0,-1,L13);
                code.visitLabel(L10);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/jetty/nio/SelectChannelConnector$RetryContinuation;","_endPoint","Lorg/mortbay/io/nio/SelectChannelEndPoint;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/io/nio/SelectChannelEndPoint;","scheduleIdle",new String[]{ },"V"));
                code.visitLabel(L11);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/jetty/nio/SelectChannelConnector$RetryContinuation;","_endPoint","Lorg/mortbay/io/nio/SelectChannelEndPoint;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/io/nio/SelectChannelEndPoint;","getSelectSet",new String[]{ },"Lorg/mortbay/io/nio/SelectorManager$SelectSet;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,3},new Method("Lorg/mortbay/io/nio/SelectorManager$SelectSet;","addChange",new String[]{ "Ljava/lang/Object;"},"V"));
                code.visitLabel(L12);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/jetty/nio/SelectChannelConnector$RetryContinuation;","_endPoint","Lorg/mortbay/io/nio/SelectChannelEndPoint;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/io/nio/SelectChannelEndPoint;","getSelectSet",new String[]{ },"Lorg/mortbay/io/nio/SelectorManager$SelectSet;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/io/nio/SelectorManager$SelectSet;","wakeup",new String[]{ },"V"));
                code.visitLabel(L13);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L15);
                code.visitStmt2R(MOVE,0,2);
                code.visitLabel(L14);
                code.visitJumpStmt(GOTO,-1,-1,L8);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitLabel(L3);
                code.visitStmt1R(MONITOR_EXIT,3);
                code.visitLabel(L4);
                code.visitStmt1R(THROW,1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_getObject(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/nio/SelectChannelConnector$RetryContinuation;","getObject",new String[]{ },"Ljava/lang/Object;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(407,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/nio/SelectChannelConnector$RetryContinuation;","_object","Ljava/lang/Object;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_getTimeout(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/nio/SelectChannelConnector$RetryContinuation;","getTimeout",new String[]{ },"J"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(412,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_WIDE,0,2,new Field("Lorg/mortbay/jetty/nio/SelectChannelConnector$RetryContinuation;","_timeout","J"));
                code.visitStmt1R(RETURN_WIDE,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_isNew(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/nio/SelectChannelConnector$RetryContinuation;","isNew",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(417,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_BOOLEAN,0,1,new Field("Lorg/mortbay/jetty/nio/SelectChannelConnector$RetryContinuation;","_new","Z"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_isPending(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/nio/SelectChannelConnector$RetryContinuation;","isPending",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(422,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_BOOLEAN,0,1,new Field("Lorg/mortbay/jetty/nio/SelectChannelConnector$RetryContinuation;","_pending","Z"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_isResumed(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/nio/SelectChannelConnector$RetryContinuation;","isResumed",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(427,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_BOOLEAN,0,1,new Field("Lorg/mortbay/jetty/nio/SelectChannelConnector$RetryContinuation;","_resumed","Z"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m007_reset(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/nio/SelectChannelConnector$RetryContinuation;","reset",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                DexLabel L5=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L5},new String[]{ null});
                DexLabel L6=new DexLabel();
                DexLabel L7=new DexLabel();
                code.visitTryCatch(L6,L7,new DexLabel[]{L2},new String[]{ null});
                DexLabel L8=new DexLabel();
                DexLabel L9=new DexLabel();
                code.visitTryCatch(L8,L9,new DexLabel[]{L5},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L10=new DexLabel();
                ddv.visitPrologue(L10);
                ddv.visitLineNumber(432,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(434,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(435,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(436,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(437,L14);
                ddv.visitLineNumber(439,L1);
                ddv.visitLineNumber(441,L3);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(442,L15);
                ddv.visitLineNumber(443,L4);
                ddv.visitLineNumber(437,L2);
                ddv.visitLineNumber(442,L5);
                code.visitLabel(L10);
                code.visitStmt1R(MONITOR_ENTER,2);
                code.visitLabel(L11);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_BOOLEAN,0,2,new Field("Lorg/mortbay/jetty/nio/SelectChannelConnector$RetryContinuation;","_resumed","Z"));
                code.visitLabel(L12);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_BOOLEAN,0,2,new Field("Lorg/mortbay/jetty/nio/SelectChannelConnector$RetryContinuation;","_pending","Z"));
                code.visitLabel(L13);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_BOOLEAN,0,2,new Field("Lorg/mortbay/jetty/nio/SelectChannelConnector$RetryContinuation;","_parked","Z"));
                code.visitLabel(L14);
                code.visitStmt1R(MONITOR_EXIT,2);
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/nio/SelectChannelConnector$RetryContinuation;","_endPoint","Lorg/mortbay/io/nio/SelectChannelEndPoint;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/io/nio/SelectChannelEndPoint;","getSelectSet",new String[]{ },"Lorg/mortbay/io/nio/SelectorManager$SelectSet;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt1R(MONITOR_ENTER,0);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/nio/SelectChannelConnector$RetryContinuation;","cancel",new String[]{ },"V"));
                code.visitLabel(L15);
                code.visitStmt1R(MONITOR_EXIT,0);
                code.visitLabel(L4);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,0);
                code.visitLabel(L6);
                code.visitStmt1R(MONITOR_EXIT,2);
                code.visitLabel(L7);
                code.visitStmt1R(THROW,0);
                code.visitLabel(L5);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitLabel(L8);
                code.visitStmt1R(MONITOR_EXIT,0);
                code.visitLabel(L9);
                code.visitStmt1R(THROW,1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m008_resume(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/nio/SelectChannelConnector$RetryContinuation;","resume",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                DexLabel L5=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L5},new String[]{ null});
                DexLabel L6=new DexLabel();
                DexLabel L7=new DexLabel();
                code.visitTryCatch(L6,L7,new DexLabel[]{L2},new String[]{ null});
                DexLabel L8=new DexLabel();
                DexLabel L9=new DexLabel();
                code.visitTryCatch(L8,L9,new DexLabel[]{L5},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L10=new DexLabel();
                ddv.visitPrologue(L10);
                ddv.visitLineNumber(480,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(481,L11);
                ddv.visitStartLocal(0,L11,"redispatch","Z",null);
                ddv.visitLineNumber(483,L0);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(485,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(486,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(487,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(489,L15);
                ddv.visitLineNumber(491,L1);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(493,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(495,L17);
                ddv.visitStartLocal(1,L17,"selectSet","Lorg/mortbay/io/nio/SelectorManager$SelectSet;",null);
                ddv.visitLineNumber(497,L3);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(498,L18);
                ddv.visitLineNumber(500,L4);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(501,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(502,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(504,L21);
                ddv.visitEndLocal(1,L21);
                ddv.visitLineNumber(489,L2);
                ddv.visitLineNumber(498,L5);
                ddv.visitRestartLocal(1,L5);
                code.visitLabel(L10);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L11);
                code.visitStmt1R(MONITOR_ENTER,3);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_BOOLEAN,2,3,new Field("Lorg/mortbay/jetty/nio/SelectChannelConnector$RetryContinuation;","_pending","Z"));
                code.visitJumpStmt(IF_EQZ,2,-1,L15);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/jetty/nio/SelectChannelConnector$RetryContinuation;","isExpired",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_NEZ,2,-1,L15);
                code.visitLabel(L12);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitFieldStmt(IPUT_BOOLEAN,2,3,new Field("Lorg/mortbay/jetty/nio/SelectChannelConnector$RetryContinuation;","_resumed","Z"));
                code.visitLabel(L13);
                code.visitFieldStmt(IGET_BOOLEAN,0,3,new Field("Lorg/mortbay/jetty/nio/SelectChannelConnector$RetryContinuation;","_parked","Z"));
                code.visitLabel(L14);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_BOOLEAN,2,3,new Field("Lorg/mortbay/jetty/nio/SelectChannelConnector$RetryContinuation;","_parked","Z"));
                code.visitLabel(L15);
                code.visitStmt1R(MONITOR_EXIT,3);
                code.visitLabel(L1);
                code.visitJumpStmt(IF_EQZ,0,-1,L21);
                code.visitLabel(L16);
                code.visitFieldStmt(IGET_OBJECT,2,3,new Field("Lorg/mortbay/jetty/nio/SelectChannelConnector$RetryContinuation;","_endPoint","Lorg/mortbay/io/nio/SelectChannelEndPoint;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/io/nio/SelectChannelEndPoint;","getSelectSet",new String[]{ },"Lorg/mortbay/io/nio/SelectorManager$SelectSet;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L17);
                code.visitStmt1R(MONITOR_ENTER,1);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/jetty/nio/SelectChannelConnector$RetryContinuation;","cancel",new String[]{ },"V"));
                code.visitLabel(L18);
                code.visitStmt1R(MONITOR_EXIT,1);
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,2,3,new Field("Lorg/mortbay/jetty/nio/SelectChannelConnector$RetryContinuation;","_endPoint","Lorg/mortbay/io/nio/SelectChannelEndPoint;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/io/nio/SelectChannelEndPoint;","scheduleIdle",new String[]{ },"V"));
                code.visitLabel(L19);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,3},new Method("Lorg/mortbay/io/nio/SelectorManager$SelectSet;","addChange",new String[]{ "Ljava/lang/Object;"},"V"));
                code.visitLabel(L20);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/io/nio/SelectorManager$SelectSet;","wakeup",new String[]{ },"V"));
                code.visitLabel(L21);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,2);
                code.visitLabel(L6);
                code.visitStmt1R(MONITOR_EXIT,3);
                code.visitLabel(L7);
                code.visitStmt1R(THROW,2);
                code.visitLabel(L5);
                code.visitStmt1R(MOVE_EXCEPTION,2);
                code.visitLabel(L8);
                code.visitStmt1R(MONITOR_EXIT,1);
                code.visitLabel(L9);
                code.visitStmt1R(THROW,2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m009_run(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/nio/SelectChannelConnector$RetryContinuation;","run",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(525,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(526,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/nio/SelectChannelConnector$RetryContinuation;","_endPoint","Lorg/mortbay/io/nio/SelectChannelEndPoint;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/io/nio/SelectChannelEndPoint;","run",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m010_setObject(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/nio/SelectChannelConnector$RetryContinuation;","setObject",new String[]{ "Ljava/lang/Object;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"object");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(558,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(559,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/nio/SelectChannelConnector$RetryContinuation;","_object","Ljava/lang/Object;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m011_suspend(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/nio/SelectChannelConnector$RetryContinuation;","suspend",new String[]{ "J"},"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L2},new String[]{ null});
                DexLabel L5=new DexLabel();
                DexLabel L6=new DexLabel();
                DexLabel L7=new DexLabel();
                code.visitTryCatch(L5,L6,new DexLabel[]{L7},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"timeout");
                DexLabel L8=new DexLabel();
                ddv.visitPrologue(L8);
                ddv.visitLineNumber(447,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(448,L9);
                ddv.visitStartLocal(0,L9,"resumed","Z",null);
                ddv.visitLineNumber(450,L0);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(451,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(452,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(453,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(455,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(456,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(457,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(458,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(459,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(460,L18);
                ddv.visitLineNumber(468,L2);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(465,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(466,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(467,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(468,L22);
                ddv.visitLineNumber(470,L4);
                ddv.visitLineNumber(472,L5);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(473,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(475,L24);
                ddv.visitLineNumber(473,L7);
                code.visitLabel(L8);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L9);
                code.visitStmt1R(MONITOR_ENTER,3);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_BOOLEAN,0,3,new Field("Lorg/mortbay/jetty/nio/SelectChannelConnector$RetryContinuation;","_resumed","Z"));
                code.visitLabel(L10);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_BOOLEAN,1,3,new Field("Lorg/mortbay/jetty/nio/SelectChannelConnector$RetryContinuation;","_resumed","Z"));
                code.visitLabel(L11);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_BOOLEAN,1,3,new Field("Lorg/mortbay/jetty/nio/SelectChannelConnector$RetryContinuation;","_new","Z"));
                code.visitLabel(L12);
                code.visitFieldStmt(IGET_BOOLEAN,1,3,new Field("Lorg/mortbay/jetty/nio/SelectChannelConnector$RetryContinuation;","_pending","Z"));
                code.visitJumpStmt(IF_NEZ,1,-1,L19);
                code.visitJumpStmt(IF_NEZ,0,-1,L19);
                code.visitConstStmt(CONST_WIDE_16,1,Long.valueOf(0L)); // long: 0x0000000000000000  double:0.000000
                code.visitStmt3R(CMP_LONG,1,4,1);
                code.visitJumpStmt(IF_LTZ,1,-1,L19);
                code.visitLabel(L13);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitFieldStmt(IPUT_BOOLEAN,1,3,new Field("Lorg/mortbay/jetty/nio/SelectChannelConnector$RetryContinuation;","_pending","Z"));
                code.visitLabel(L14);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_BOOLEAN,1,3,new Field("Lorg/mortbay/jetty/nio/SelectChannelConnector$RetryContinuation;","_parked","Z"));
                code.visitLabel(L15);
                code.visitFieldStmt(IPUT_WIDE,4,3,new Field("Lorg/mortbay/jetty/nio/SelectChannelConnector$RetryContinuation;","_timeout","J"));
                code.visitLabel(L16);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/jetty/nio/SelectChannelConnector$RetryContinuation;","_retry","Lorg/mortbay/jetty/RetryRequest;"));
                code.visitJumpStmt(IF_NEZ,1,-1,L18);
                code.visitLabel(L17);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Lorg/mortbay/jetty/RetryRequest;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Lorg/mortbay/jetty/RetryRequest;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,1,3,new Field("Lorg/mortbay/jetty/nio/SelectChannelConnector$RetryContinuation;","_retry","Lorg/mortbay/jetty/RetryRequest;"));
                code.visitLabel(L18);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/jetty/nio/SelectChannelConnector$RetryContinuation;","_retry","Lorg/mortbay/jetty/RetryRequest;"));
                code.visitStmt1R(THROW,1);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitStmt1R(MONITOR_EXIT,3);
                code.visitLabel(L1);
                code.visitStmt1R(THROW,1);
                code.visitLabel(L19);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L3);
                code.visitFieldStmt(IPUT_BOOLEAN,1,3,new Field("Lorg/mortbay/jetty/nio/SelectChannelConnector$RetryContinuation;","_resumed","Z"));
                code.visitLabel(L20);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_BOOLEAN,1,3,new Field("Lorg/mortbay/jetty/nio/SelectChannelConnector$RetryContinuation;","_pending","Z"));
                code.visitLabel(L21);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_BOOLEAN,1,3,new Field("Lorg/mortbay/jetty/nio/SelectChannelConnector$RetryContinuation;","_parked","Z"));
                code.visitLabel(L22);
                code.visitStmt1R(MONITOR_EXIT,3);
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/jetty/nio/SelectChannelConnector$RetryContinuation;","_endPoint","Lorg/mortbay/io/nio/SelectChannelEndPoint;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/io/nio/SelectChannelEndPoint;","getSelectSet",new String[]{ },"Lorg/mortbay/io/nio/SelectorManager$SelectSet;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitStmt1R(MONITOR_ENTER,1);
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/jetty/nio/SelectChannelConnector$RetryContinuation;","cancel",new String[]{ },"V"));
                code.visitLabel(L23);
                code.visitStmt1R(MONITOR_EXIT,1);
                code.visitLabel(L24);
                code.visitStmt1R(RETURN,0);
                code.visitLabel(L7);
                code.visitStmt1R(MOVE_EXCEPTION,2);
                code.visitStmt1R(MONITOR_EXIT,1);
                code.visitLabel(L6);
                code.visitStmt1R(THROW,2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m012_toString(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/nio/SelectChannelConnector$RetryContinuation;","toString",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(563,L4);
                ddv.visitLineNumber(565,L0);
                ddv.visitLineNumber(571,L2);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_STRING,2,"");
                code.visitLabel(L4);
                code.visitStmt1R(MONITOR_ENTER,3);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,1,"RetryContinuation@");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/lang/Object;","hashCode",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "I"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IGET_BOOLEAN,1,3,new Field("Lorg/mortbay/jetty/nio/SelectChannelConnector$RetryContinuation;","_new","Z"));
                DexLabel L5=new DexLabel();
                code.visitJumpStmt(IF_EQZ,1,-1,L5);
                code.visitConstStmt(CONST_STRING,1,",new");
                DexLabel L6=new DexLabel();
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IGET_BOOLEAN,1,3,new Field("Lorg/mortbay/jetty/nio/SelectChannelConnector$RetryContinuation;","_pending","Z"));
                DexLabel L7=new DexLabel();
                code.visitJumpStmt(IF_EQZ,1,-1,L7);
                code.visitConstStmt(CONST_STRING,1,",pending");
                DexLabel L8=new DexLabel();
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IGET_BOOLEAN,1,3,new Field("Lorg/mortbay/jetty/nio/SelectChannelConnector$RetryContinuation;","_resumed","Z"));
                DexLabel L9=new DexLabel();
                code.visitJumpStmt(IF_EQZ,1,-1,L9);
                code.visitConstStmt(CONST_STRING,1,",resumed");
                DexLabel L10=new DexLabel();
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/jetty/nio/SelectChannelConnector$RetryContinuation;","isExpired",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,1);
                DexLabel L11=new DexLabel();
                code.visitJumpStmt(IF_EQZ,1,-1,L11);
                code.visitConstStmt(CONST_STRING,1,",expired");
                DexLabel L12=new DexLabel();
                code.visitLabel(L12);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IGET_BOOLEAN,1,3,new Field("Lorg/mortbay/jetty/nio/SelectChannelConnector$RetryContinuation;","_parked","Z"));
                DexLabel L13=new DexLabel();
                code.visitJumpStmt(IF_EQZ,1,-1,L13);
                code.visitConstStmt(CONST_STRING,1,",parked");
                DexLabel L14=new DexLabel();
                code.visitLabel(L14);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt1R(MONITOR_EXIT,3);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L5);
                code.visitConstStmt(CONST_STRING,1,"");
                code.visitStmt2R(MOVE_OBJECT,1,2);
                code.visitJumpStmt(GOTO,-1,-1,L6);
                code.visitLabel(L7);
                code.visitConstStmt(CONST_STRING,1,"");
                code.visitStmt2R(MOVE_OBJECT,1,2);
                code.visitJumpStmt(GOTO,-1,-1,L8);
                code.visitLabel(L9);
                code.visitConstStmt(CONST_STRING,1,"");
                code.visitStmt2R(MOVE_OBJECT,1,2);
                code.visitJumpStmt(GOTO,-1,-1,L10);
                code.visitLabel(L11);
                code.visitConstStmt(CONST_STRING,1,"");
                code.visitStmt2R(MOVE_OBJECT,1,2);
                code.visitJumpStmt(GOTO,-1,-1,L12);
                code.visitLabel(L13);
                code.visitConstStmt(CONST_STRING,1,"");
                code.visitStmt2R(MOVE_OBJECT,1,2);
                code.visitJumpStmt(GOTO,-1,-1,L14);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,0);
                code.visitStmt1R(MONITOR_EXIT,3);
                code.visitLabel(L1);
                code.visitStmt1R(THROW,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m013_undispatch(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/nio/SelectChannelConnector$RetryContinuation;","undispatch",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L5=new DexLabel();
                ddv.visitPrologue(L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(533,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(535,L7);
                ddv.visitStartLocal(0,L7,"redispatch","Z",null);
                ddv.visitLineNumber(537,L0);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(538,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(553,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(540,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(541,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(542,L12);
                ddv.visitLineNumber(544,L1);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(546,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(547,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(552,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(553,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(540,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(541,L18);
                ddv.visitLineNumber(542,L2);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(549,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(550,L20);
                code.visitLabel(L5);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitConstStmt(CONST_4,5, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L6);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L7);
                code.visitStmt1R(MONITOR_ENTER,6);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_BOOLEAN,1,6,new Field("Lorg/mortbay/jetty/nio/SelectChannelConnector$RetryContinuation;","_pending","Z"));
                code.visitJumpStmt(IF_NEZ,1,-1,L10);
                code.visitLabel(L8);
                code.visitStmt1R(MONITOR_EXIT,6);
                code.visitStmt2R(MOVE,1,2);
                code.visitLabel(L9);
                code.visitStmt1R(RETURN,1);
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/nio/SelectChannelConnector$RetryContinuation;","isExpired",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,1);
                DexLabel L21=new DexLabel();
                code.visitJumpStmt(IF_NEZ,1,-1,L21);
                code.visitFieldStmt(IGET_BOOLEAN,1,6,new Field("Lorg/mortbay/jetty/nio/SelectChannelConnector$RetryContinuation;","_resumed","Z"));
                DexLabel L22=new DexLabel();
                code.visitJumpStmt(IF_EQZ,1,-1,L22);
                code.visitLabel(L21);
                code.visitStmt2R(MOVE,0,2);
                code.visitLabel(L11);
                DexLabel L23=new DexLabel();
                code.visitJumpStmt(IF_NEZ,0,-1,L23);
                code.visitStmt2R(MOVE,1,2);
                DexLabel L24=new DexLabel();
                code.visitLabel(L24);
                code.visitFieldStmt(IPUT_BOOLEAN,1,6,new Field("Lorg/mortbay/jetty/nio/SelectChannelConnector$RetryContinuation;","_parked","Z"));
                code.visitLabel(L12);
                code.visitStmt1R(MONITOR_EXIT,6);
                code.visitLabel(L1);
                code.visitJumpStmt(IF_EQZ,0,-1,L19);
                code.visitLabel(L13);
                code.visitFieldStmt(IGET_OBJECT,1,6,new Field("Lorg/mortbay/jetty/nio/SelectChannelConnector$RetryContinuation;","_endPoint","Lorg/mortbay/io/nio/SelectChannelEndPoint;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/io/nio/SelectChannelEndPoint;","scheduleIdle",new String[]{ },"V"));
                code.visitLabel(L14);
                code.visitFieldStmt(IGET_OBJECT,1,6,new Field("Lorg/mortbay/jetty/nio/SelectChannelConnector$RetryContinuation;","_endPoint","Lorg/mortbay/io/nio/SelectChannelEndPoint;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/io/nio/SelectChannelEndPoint;","getSelectSet",new String[]{ },"Lorg/mortbay/io/nio/SelectorManager$SelectSet;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,6},new Method("Lorg/mortbay/io/nio/SelectorManager$SelectSet;","addChange",new String[]{ "Ljava/lang/Object;"},"V"));
                code.visitLabel(L15);
                code.visitFieldStmt(IGET_OBJECT,1,6,new Field("Lorg/mortbay/jetty/nio/SelectChannelConnector$RetryContinuation;","_endPoint","Lorg/mortbay/io/nio/SelectChannelEndPoint;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/io/nio/SelectChannelEndPoint;","getSelectSet",new String[]{ },"Lorg/mortbay/io/nio/SelectorManager$SelectSet;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/io/nio/SelectorManager$SelectSet;","wakeup",new String[]{ },"V"));
                code.visitStmt2R(MOVE,1,5);
                code.visitLabel(L16);
                code.visitJumpStmt(GOTO,-1,-1,L9);
                code.visitLabel(L22);
                code.visitStmt2R(MOVE,0,5);
                code.visitLabel(L17);
                code.visitJumpStmt(GOTO,-1,-1,L11);
                code.visitLabel(L23);
                code.visitStmt2R(MOVE,1,5);
                code.visitLabel(L18);
                code.visitJumpStmt(GOTO,-1,-1,L24);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitLabel(L3);
                code.visitStmt1R(MONITOR_EXIT,6);
                code.visitLabel(L4);
                code.visitStmt1R(THROW,1);
                code.visitLabel(L19);
                code.visitFieldStmt(IGET_WIDE,1,6,new Field("Lorg/mortbay/jetty/nio/SelectChannelConnector$RetryContinuation;","_timeout","J"));
                code.visitConstStmt(CONST_WIDE_16,3,Long.valueOf(0L)); // long: 0x0000000000000000  double:0.000000
                code.visitStmt3R(CMP_LONG,1,1,3);
                code.visitJumpStmt(IF_LEZ,1,-1,L15);
                code.visitLabel(L20);
                code.visitFieldStmt(IGET_OBJECT,1,6,new Field("Lorg/mortbay/jetty/nio/SelectChannelConnector$RetryContinuation;","_endPoint","Lorg/mortbay/io/nio/SelectChannelEndPoint;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/io/nio/SelectChannelEndPoint;","getSelectSet",new String[]{ },"Lorg/mortbay/io/nio/SelectorManager$SelectSet;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitFieldStmt(IGET_WIDE,2,6,new Field("Lorg/mortbay/jetty/nio/SelectChannelConnector$RetryContinuation;","_timeout","J"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,6,2,3},new Method("Lorg/mortbay/io/nio/SelectorManager$SelectSet;","scheduleTimeout",new String[]{ "Lorg/mortbay/thread/Timeout$Task;","J"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L15);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
