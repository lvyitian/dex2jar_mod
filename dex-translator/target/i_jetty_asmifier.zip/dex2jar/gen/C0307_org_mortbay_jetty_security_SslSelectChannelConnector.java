package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0307_org_mortbay_jetty_security_SslSelectChannelConnector {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/jetty/security/SslSelectChannelConnector;","Lorg/mortbay/jetty/nio/SelectChannelConnector;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("SslSelectChannelConnector.java");
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/MemberClasses;", Visibility.SYSTEM);
            if(av00 != null) {
                {
                    DexAnnotationVisitor av01 = av00.visitArray("value");
                    if(av01 != null) {
                        av01.visit(null, new DexType("Lorg/mortbay/jetty/security/SslSelectChannelConnector$CachedInfo;"));
                        av01.visitEnd();
                    }
                }
                av00.visitEnd();
            }
        }
        f000_CACHED_INFO_ATTR(cv);
        f001_DEFAULT_KEYSTORE(cv);
        f002_KEYPASSWORD_PROPERTY(cv);
        f003_PASSWORD_PROPERTY(cv);
        f004__algorithm(cv);
        f005__applicationBufferSize(cv);
        f006__applicationBuffers(cv);
        f007__context(cv);
        f008__excludeCipherSuites(cv);
        f009__keyPassword(cv);
        f010__keystore(cv);
        f011__keystoreType(cv);
        f012__needClientAuth(cv);
        f013__packetBufferSize(cv);
        f014__packetBuffers(cv);
        f015__password(cv);
        f016__protocol(cv);
        f017__provider(cv);
        f018__secureRandomAlgorithm(cv);
        f019__sslKeyManagerFactoryAlgorithm(cv);
        f020__sslTrustManagerFactoryAlgorithm(cv);
        f021__trustPassword(cv);
        f022__truststore(cv);
        f023__truststoreType(cv);
        f024__wantClientAuth(cv);
        m000__clinit_(cv);
        m001__init_(cv);
        m002_getCertChain(cv);
        m003_createSSLContext(cv);
        m004_createSSLEngine(cv);
        m005_customize(cv);
        m006_doStart(cv);
        m007_getAlgorithm(cv);
        m008_getBuffer(cv);
        m009_getCipherSuites(cv);
        m010_getExcludeCipherSuites(cv);
        m011_getKeystore(cv);
        m012_getKeystoreType(cv);
        m013_getNeedClientAuth(cv);
        m014_getProtocol(cv);
        m015_getProvider(cv);
        m016_getSecureRandomAlgorithm(cv);
        m017_getSslKeyManagerFactoryAlgorithm(cv);
        m018_getSslTrustManagerFactoryAlgorithm(cv);
        m019_getTruststore(cv);
        m020_getTruststoreType(cv);
        m021_getWantClientAuth(cv);
        m022_isConfidential(cv);
        m023_isIntegral(cv);
        m024_newConnection(cv);
        m025_newEndPoint(cv);
        m026_returnBuffer(cv);
        m027_setAlgorithm(cv);
        m028_setCipherSuites(cv);
        m029_setExcludeCipherSuites(cv);
        m030_setKeyPassword(cv);
        m031_setKeystore(cv);
        m032_setKeystoreType(cv);
        m033_setNeedClientAuth(cv);
        m034_setPassword(cv);
        m035_setProtocol(cv);
        m036_setProvider(cv);
        m037_setSecureRandomAlgorithm(cv);
        m038_setSslKeyManagerFactoryAlgorithm(cv);
        m039_setSslTrustManagerFactoryAlgorithm(cv);
        m040_setTrustPassword(cv);
        m041_setTruststore(cv);
        m042_setTruststoreType(cv);
        m043_setWantClientAuth(cv);
    }
    public static void f000_CACHED_INFO_ATTR(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","CACHED_INFO_ATTR","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001_DEFAULT_KEYSTORE(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","DEFAULT_KEYSTORE","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002_KEYPASSWORD_PROPERTY(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","KEYPASSWORD_PROPERTY","Ljava/lang/String;"), "jetty.ssl.keypassword");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003_PASSWORD_PROPERTY(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","PASSWORD_PROPERTY","Ljava/lang/String;"), "jetty.ssl.password");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f004__algorithm(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","_algorithm","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f005__applicationBufferSize(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","_applicationBufferSize","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f006__applicationBuffers(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","_applicationBuffers","Ljava/util/concurrent/ConcurrentLinkedQueue;"), null);
        if(fv != null) {
            if(fv!=null){
                DexAnnotationVisitor av00 = fv.visitAnnotation("Ldalvik/annotation/Signature;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, "Ljava/util/concurrent/ConcurrentLinkedQueue");
                            av01.visit(null, "<");
                            av01.visit(null, "Lorg/mortbay/io/Buffer;");
                            av01.visit(null, ">;");
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            fv.visitEnd();
        }
    }
    public static void f007__context(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","_context","Ljavax/net/ssl/SSLContext;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f008__excludeCipherSuites(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","_excludeCipherSuites","[Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f009__keyPassword(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_TRANSIENT, new Field("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","_keyPassword","Lorg/mortbay/jetty/security/Password;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f010__keystore(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","_keystore","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f011__keystoreType(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","_keystoreType","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f012__needClientAuth(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","_needClientAuth","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f013__packetBufferSize(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","_packetBufferSize","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f014__packetBuffers(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","_packetBuffers","Ljava/util/concurrent/ConcurrentLinkedQueue;"), null);
        if(fv != null) {
            if(fv!=null){
                DexAnnotationVisitor av00 = fv.visitAnnotation("Ldalvik/annotation/Signature;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, "Ljava/util/concurrent/ConcurrentLinkedQueue");
                            av01.visit(null, "<");
                            av01.visit(null, "Lorg/mortbay/io/Buffer;");
                            av01.visit(null, ">;");
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            fv.visitEnd();
        }
    }
    public static void f015__password(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_TRANSIENT, new Field("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","_password","Lorg/mortbay/jetty/security/Password;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f016__protocol(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","_protocol","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f017__provider(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","_provider","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f018__secureRandomAlgorithm(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","_secureRandomAlgorithm","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f019__sslKeyManagerFactoryAlgorithm(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","_sslKeyManagerFactoryAlgorithm","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f020__sslTrustManagerFactoryAlgorithm(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","_sslTrustManagerFactoryAlgorithm","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f021__trustPassword(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_TRANSIENT, new Field("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","_trustPassword","Lorg/mortbay/jetty/security/Password;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f022__truststore(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","_truststore","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f023__truststoreType(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","_truststoreType","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f024__wantClientAuth(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","_wantClientAuth","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__clinit_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","<clinit>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(73,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(76,L1);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_CLASS,0,new DexType("Lorg/mortbay/jetty/security/SslSelectChannelConnector$CachedInfo;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/Class;","getName",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","CACHED_INFO_ATTR","Ljava/lang/String;"));
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,1,"user.home");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1},new Method("Ljava/lang/System;","getProperty",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(SGET_OBJECT,1,-1,new Field("Ljava/io/File;","separator","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitConstStmt(CONST_STRING,1,".keystore");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","DEFAULT_KEYSTORE","Ljava/lang/String;"));
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","<init>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(283,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(85,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(88,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(89,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(92,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(93,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(98,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(99,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(102,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(106,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(111,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(116,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(117,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(289,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(102,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(106,L16);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitConstStmt(CONST_STRING,5,"ssl.TrustManagerFactory.algorithm");
                code.visitConstStmt(CONST_STRING,4,"ssl.KeyManagerFactory.algorithm");
                code.visitConstStmt(CONST_STRING,3,"JKS");
                code.visitConstStmt(CONST_STRING,1,"SunX509");
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 6},new Method("Lorg/mortbay/jetty/nio/SelectChannelConnector;","<init>",new String[]{ },"V"));
                code.visitLabel(L2);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_OBJECT,0,6,new Field("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","_excludeCipherSuites","[Ljava/lang/String;"));
                code.visitLabel(L3);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","DEFAULT_KEYSTORE","Ljava/lang/String;"));
                code.visitFieldStmt(IPUT_OBJECT,0,6,new Field("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","_keystore","Ljava/lang/String;"));
                code.visitLabel(L4);
                code.visitConstStmt(CONST_STRING,0,"JKS");
                code.visitFieldStmt(IPUT_OBJECT,3,6,new Field("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","_keystoreType","Ljava/lang/String;"));
                code.visitLabel(L5);
                code.visitFieldStmt(IPUT_BOOLEAN,2,6,new Field("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","_needClientAuth","Z"));
                code.visitLabel(L6);
                code.visitFieldStmt(IPUT_BOOLEAN,2,6,new Field("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","_wantClientAuth","Z"));
                code.visitLabel(L7);
                code.visitConstStmt(CONST_STRING,0,"TLS");
                code.visitFieldStmt(IPUT_OBJECT,0,6,new Field("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","_protocol","Ljava/lang/String;"));
                code.visitLabel(L8);
                code.visitConstStmt(CONST_STRING,0,"SunX509");
                code.visitFieldStmt(IPUT_OBJECT,1,6,new Field("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","_algorithm","Ljava/lang/String;"));
                code.visitLabel(L9);
                code.visitConstStmt(CONST_STRING,0,"ssl.KeyManagerFactory.algorithm");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 4},new Method("Ljava/security/Security;","getProperty",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitJumpStmt(IF_NEZ,0,-1,L15);
                code.visitConstStmt(CONST_STRING,0,"SunX509");
                code.visitStmt2R(MOVE_OBJECT,0,1);
                DexLabel L17=new DexLabel();
                code.visitLabel(L17);
                code.visitFieldStmt(IPUT_OBJECT,0,6,new Field("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","_sslKeyManagerFactoryAlgorithm","Ljava/lang/String;"));
                code.visitLabel(L10);
                code.visitConstStmt(CONST_STRING,0,"ssl.TrustManagerFactory.algorithm");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 5},new Method("Ljava/security/Security;","getProperty",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitJumpStmt(IF_NEZ,0,-1,L16);
                code.visitConstStmt(CONST_STRING,0,"SunX509");
                code.visitStmt2R(MOVE_OBJECT,0,1);
                DexLabel L18=new DexLabel();
                code.visitLabel(L18);
                code.visitFieldStmt(IPUT_OBJECT,0,6,new Field("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","_sslTrustManagerFactoryAlgorithm","Ljava/lang/String;"));
                code.visitLabel(L11);
                code.visitConstStmt(CONST_STRING,0,"JKS");
                code.visitFieldStmt(IPUT_OBJECT,3,6,new Field("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","_truststoreType","Ljava/lang/String;"));
                code.visitLabel(L12);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/util/concurrent/ConcurrentLinkedQueue;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/util/concurrent/ConcurrentLinkedQueue;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,6,new Field("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","_packetBuffers","Ljava/util/concurrent/ConcurrentLinkedQueue;"));
                code.visitLabel(L13);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/util/concurrent/ConcurrentLinkedQueue;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/util/concurrent/ConcurrentLinkedQueue;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,6,new Field("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","_applicationBuffers","Ljava/util/concurrent/ConcurrentLinkedQueue;"));
                code.visitLabel(L14);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L15);
                code.visitConstStmt(CONST_STRING,0,"ssl.KeyManagerFactory.algorithm");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 4},new Method("Ljava/security/Security;","getProperty",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitJumpStmt(GOTO,-1,-1,L17);
                code.visitLabel(L16);
                code.visitConstStmt(CONST_STRING,0,"ssl.TrustManagerFactory.algorithm");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 5},new Method("Ljava/security/Security;","getProperty",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitJumpStmt(GOTO,-1,-1,L18);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_getCertChain(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PRIVATE|ACC_STATIC, new Method("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","getCertChain",new String[]{ "Ljavax/net/ssl/SSLSession;"},"[Ljava/security/cert/X509Certificate;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(11);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                DexLabel L3=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2,L3},new String[]{ "Ljavax/net/ssl/SSLPeerUnverifiedException;","Ljava/lang/Exception;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"sslSession");
                DexLabel L4=new DexLabel();
                ddv.visitPrologue(L4);
                ddv.visitLineNumber(187,L0);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(188,L5);
                ddv.visitStartLocal(5,L5,"javaxCerts","[Ljavax/security/cert/X509Certificate;",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(212,L6);
                ddv.visitEndLocal(10,L6);
                ddv.visitEndLocal(5,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(191,L7);
                ddv.visitRestartLocal(5,L7);
                ddv.visitRestartLocal(10,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(192,L8);
                ddv.visitStartLocal(6,L8,"length","I",null);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(194,L9);
                ddv.visitStartLocal(4,L9,"javaCerts","[Ljava/security/cert/X509Certificate;",null);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(195,L10);
                ddv.visitStartLocal(1,L10,"cf","Ljava/security/cert/CertificateFactory;",null);
                DexLabel L11=new DexLabel();
                ddv.visitEndLocal(10,L11);
                ddv.visitStartLocal(3,L11,"i","I",null);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(197,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(198,L13);
                ddv.visitStartLocal(0,L13,"bytes","[B",null);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(199,L14);
                ddv.visitStartLocal(7,L14,"stream","Ljava/io/ByteArrayInputStream;",null);
                ddv.visitLineNumber(195,L1);
                DexLabel L15=new DexLabel();
                ddv.visitEndLocal(0,L15);
                ddv.visitEndLocal(7,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(202,L16);
                ddv.visitLineNumber(204,L2);
                ddv.visitEndLocal(5,L2);
                ddv.visitEndLocal(6,L2);
                ddv.visitEndLocal(4,L2);
                ddv.visitEndLocal(1,L2);
                ddv.visitEndLocal(3,L2);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(206,L17);
                ddv.visitStartLocal(2,L17,"e","Ljavax/net/ssl/SSLPeerUnverifiedException;",null);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(207,L18);
                ddv.visitLineNumber(209,L3);
                ddv.visitEndLocal(2,L3);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(211,L19);
                ddv.visitStartLocal(2,L19,"e","Ljava/lang/Exception;",null);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(212,L20);
                code.visitLabel(L4);
                code.visitConstStmt(CONST_4,9, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 10},new Method("Ljavax/net/ssl/SSLSession;","getPeerCertificateChain",new String[]{ },"[Ljavax/security/cert/X509Certificate;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitLabel(L5);
                DexLabel L21=new DexLabel();
                code.visitJumpStmt(IF_EQZ,5,-1,L21);
                code.visitStmt2R(ARRAY_LENGTH,8,5);
                code.visitJumpStmt(IF_NEZ,8,-1,L7);
                code.visitLabel(L21);
                code.visitStmt2R(MOVE_OBJECT,8,9);
                code.visitLabel(L6);
                code.visitStmt1R(RETURN_OBJECT,8);
                code.visitLabel(L7);
                code.visitStmt2R(ARRAY_LENGTH,6,5);
                code.visitLabel(L8);
                code.visitTypeStmt(NEW_ARRAY,4,6,"[Ljava/security/cert/X509Certificate;");
                code.visitLabel(L9);
                code.visitConstStmt(CONST_STRING,8,"X.509");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 8},new Method("Ljava/security/cert/CertificateFactory;","getInstance",new String[]{ "Ljava/lang/String;"},"Ljava/security/cert/CertificateFactory;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L10);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L11);
                code.visitJumpStmt(IF_GE,3,6,L15);
                code.visitLabel(L12);
                code.visitStmt3R(AGET_OBJECT,8,5,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Ljavax/security/cert/X509Certificate;","getEncoded",new String[]{ },"[B"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L13);
                code.visitTypeStmt(NEW_INSTANCE,7,-1,"Ljava/io/ByteArrayInputStream;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 7,0},new Method("Ljava/io/ByteArrayInputStream;","<init>",new String[]{ "[B"},"V"));
                code.visitLabel(L14);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,7},new Method("Ljava/security/cert/CertificateFactory;","generateCertificate",new String[]{ "Ljava/io/InputStream;"},"Ljava/security/cert/Certificate;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,10);
                code.visitTypeStmt(CHECK_CAST,10,-1,"Ljava/security/cert/X509Certificate;");
                code.visitStmt3R(APUT_OBJECT,10,4,3);
                code.visitLabel(L1);
                code.visitStmt2R1N(ADD_INT_LIT8,3,3,1);
                code.visitJumpStmt(GOTO,-1,-1,L11);
                code.visitLabel(L15);
                code.visitStmt2R(MOVE_OBJECT,8,4);
                code.visitLabel(L16);
                code.visitJumpStmt(GOTO,-1,-1,L6);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,8);
                code.visitStmt2R(MOVE_OBJECT,2,8);
                code.visitLabel(L17);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2},new Method("Lorg/mortbay/log/Log;","ignore",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitStmt2R(MOVE_OBJECT,8,9);
                code.visitLabel(L18);
                code.visitJumpStmt(GOTO,-1,-1,L6);
                code.visitLabel(L3);
                code.visitStmt1R(MOVE_EXCEPTION,8);
                code.visitStmt2R(MOVE_OBJECT,2,8);
                code.visitLabel(L19);
                code.visitConstStmt(CONST_STRING,8,"EXCEPTION ");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 8,2},new Method("Lorg/mortbay/log/Log;","warn",new String[]{ "Ljava/lang/String;","Ljava/lang/Throwable;"},"V"));
                code.visitStmt2R(MOVE_OBJECT,8,9);
                code.visitLabel(L20);
                code.visitJumpStmt(GOTO,-1,-1,L6);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_createSSLContext(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","createSSLContext",new String[]{ },"Ljavax/net/ssl/SSLContext;"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/Exception;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(13);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                DexLabel L5=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L5},new String[]{ null});
                DexLabel L6=new DexLabel();
                DexLabel L7=new DexLabel();
                code.visitTryCatch(L6,L7,new DexLabel[]{L2},new String[]{ null});
                DexLabel L8=new DexLabel();
                DexLabel L9=new DexLabel();
                code.visitTryCatch(L8,L9,new DexLabel[]{L5},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L10=new DexLabel();
                ddv.visitPrologue(L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(589,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(591,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(592,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(595,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(597,L15);
                ddv.visitStartLocal(4,L15,"keystoreInputStream","Ljava/io/InputStream;",null);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(598,L16);
                ddv.visitStartLocal(2,L16,"keyManagers","[Ljavax/net/ssl/KeyManager;",null);
                ddv.visitLineNumber(601,L0);
                ddv.visitStartLocal(3,L0,"keyStore","Ljava/security/KeyStore;",null);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(603,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(604,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(605,L19);
                ddv.visitLineNumber(610,L1);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(611,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(614,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(615,L22);
                ddv.visitStartLocal(1,L22,"keyManagerFactory","Ljavax/net/ssl/KeyManagerFactory;",null);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(616,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(619,L24);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(620,L25);
                ddv.visitStartLocal(7,L25,"trustManagers","[Ljavax/net/ssl/TrustManager;",null);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(621,L26);
                ddv.visitStartLocal(9,L26,"truststoreInputStream","Ljava/io/InputStream;",null);
                ddv.visitLineNumber(624,L3);
                ddv.visitStartLocal(8,L3,"trustStore","Ljava/security/KeyStore;",null);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(626,L27);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(627,L28);
                DexLabel L29=new DexLabel();
                ddv.visitLineNumber(628,L29);
                ddv.visitLineNumber(633,L4);
                DexLabel L30=new DexLabel();
                ddv.visitLineNumber(634,L30);
                DexLabel L31=new DexLabel();
                ddv.visitLineNumber(638,L31);
                DexLabel L32=new DexLabel();
                ddv.visitLineNumber(639,L32);
                ddv.visitStartLocal(6,L32,"trustManagerFactory","Ljavax/net/ssl/TrustManagerFactory;",null);
                DexLabel L33=new DexLabel();
                ddv.visitLineNumber(640,L33);
                DexLabel L34=new DexLabel();
                ddv.visitLineNumber(642,L34);
                DexLabel L35=new DexLabel();
                ddv.visitLineNumber(643,L35);
                ddv.visitStartLocal(5,L35,"secureRandom","Ljava/security/SecureRandom;",null);
                DexLabel L36=new DexLabel();
                ddv.visitLineNumber(644,L36);
                ddv.visitStartLocal(0,L36,"context","Ljavax/net/ssl/SSLContext;",null);
                DexLabel L37=new DexLabel();
                ddv.visitLineNumber(645,L37);
                ddv.visitLineNumber(605,L6);
                ddv.visitEndLocal(1,L6);
                ddv.visitEndLocal(9,L6);
                ddv.visitEndLocal(8,L6);
                ddv.visitEndLocal(6,L6);
                ddv.visitEndLocal(7,L6);
                ddv.visitEndLocal(5,L6);
                ddv.visitEndLocal(0,L6);
                ddv.visitLineNumber(610,L2);
                DexLabel L38=new DexLabel();
                ddv.visitLineNumber(611,L38);
                DexLabel L39=new DexLabel();
                ddv.visitLineNumber(610,L39);
                DexLabel L40=new DexLabel();
                ddv.visitLineNumber(615,L40);
                ddv.visitRestartLocal(1,L40);
                ddv.visitLineNumber(628,L8);
                ddv.visitRestartLocal(7,L8);
                ddv.visitRestartLocal(8,L8);
                ddv.visitRestartLocal(9,L8);
                ddv.visitLineNumber(633,L5);
                DexLabel L41=new DexLabel();
                ddv.visitLineNumber(634,L41);
                DexLabel L42=new DexLabel();
                ddv.visitLineNumber(633,L42);
                DexLabel L43=new DexLabel();
                ddv.visitLineNumber(642,L43);
                ddv.visitRestartLocal(6,L43);
                DexLabel L44=new DexLabel();
                ddv.visitLineNumber(643,L44);
                ddv.visitRestartLocal(5,L44);
                code.visitLabel(L10);
                code.visitConstStmt(CONST_4,11, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L11);
                code.visitFieldStmt(IGET_OBJECT,10,12,new Field("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","_truststore","Ljava/lang/String;"));
                code.visitJumpStmt(IF_NEZ,10,-1,L14);
                code.visitLabel(L12);
                code.visitFieldStmt(IGET_OBJECT,10,12,new Field("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","_keystore","Ljava/lang/String;"));
                code.visitFieldStmt(IPUT_OBJECT,10,12,new Field("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","_truststore","Ljava/lang/String;"));
                code.visitLabel(L13);
                code.visitFieldStmt(IGET_OBJECT,10,12,new Field("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","_keystoreType","Ljava/lang/String;"));
                code.visitFieldStmt(IPUT_OBJECT,10,12,new Field("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","_truststoreType","Ljava/lang/String;"));
                code.visitLabel(L14);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L15);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L16);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,10,12,new Field("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","_keystore","Ljava/lang/String;"));
                code.visitJumpStmt(IF_EQZ,10,-1,L1);
                code.visitLabel(L17);
                code.visitFieldStmt(IGET_OBJECT,10,12,new Field("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","_keystore","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 10},new Method("Lorg/mortbay/resource/Resource;","newResource",new String[]{ "Ljava/lang/String;"},"Lorg/mortbay/resource/Resource;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Lorg/mortbay/resource/Resource;","getInputStream",new String[]{ },"Ljava/io/InputStream;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitLabel(L18);
                code.visitFieldStmt(IGET_OBJECT,10,12,new Field("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","_keystoreType","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 10},new Method("Ljava/security/KeyStore;","getInstance",new String[]{ "Ljava/lang/String;"},"Ljava/security/KeyStore;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitLabel(L19);
                code.visitFieldStmt(IGET_OBJECT,10,12,new Field("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","_password","Lorg/mortbay/jetty/security/Password;"));
                code.visitJumpStmt(IF_NEZ,10,-1,L6);
                code.visitStmt2R(MOVE_OBJECT,10,11);
                DexLabel L45=new DexLabel();
                code.visitLabel(L45);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4,10},new Method("Ljava/security/KeyStore;","load",new String[]{ "Ljava/io/InputStream;","[C"},"V"));
                code.visitLabel(L1);
                code.visitJumpStmt(IF_EQZ,4,-1,L21);
                code.visitLabel(L20);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/io/InputStream;","close",new String[]{ },"V"));
                code.visitLabel(L21);
                code.visitFieldStmt(IGET_OBJECT,10,12,new Field("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","_sslKeyManagerFactoryAlgorithm","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 10},new Method("Ljavax/net/ssl/KeyManagerFactory;","getInstance",new String[]{ "Ljava/lang/String;"},"Ljavax/net/ssl/KeyManagerFactory;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L22);
                code.visitFieldStmt(IGET_OBJECT,10,12,new Field("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","_keyPassword","Lorg/mortbay/jetty/security/Password;"));
                DexLabel L46=new DexLabel();
                code.visitJumpStmt(IF_NEZ,10,-1,L46);
                code.visitFieldStmt(IGET_OBJECT,10,12,new Field("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","_password","Lorg/mortbay/jetty/security/Password;"));
                code.visitJumpStmt(IF_NEZ,10,-1,L40);
                code.visitStmt2R(MOVE_OBJECT,10,11);
                DexLabel L47=new DexLabel();
                code.visitLabel(L47);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,3,10},new Method("Ljavax/net/ssl/KeyManagerFactory;","init",new String[]{ "Ljava/security/KeyStore;","[C"},"V"));
                code.visitLabel(L23);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljavax/net/ssl/KeyManagerFactory;","getKeyManagers",new String[]{ },"[Ljavax/net/ssl/KeyManager;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L24);
                code.visitConstStmt(CONST_4,7, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L25);
                code.visitConstStmt(CONST_4,9, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L26);
                code.visitConstStmt(CONST_4,8, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,10,12,new Field("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","_truststore","Ljava/lang/String;"));
                code.visitJumpStmt(IF_EQZ,10,-1,L4);
                code.visitLabel(L27);
                code.visitFieldStmt(IGET_OBJECT,10,12,new Field("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","_truststore","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 10},new Method("Lorg/mortbay/resource/Resource;","newResource",new String[]{ "Ljava/lang/String;"},"Lorg/mortbay/resource/Resource;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Lorg/mortbay/resource/Resource;","getInputStream",new String[]{ },"Ljava/io/InputStream;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitLabel(L28);
                code.visitFieldStmt(IGET_OBJECT,10,12,new Field("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","_truststoreType","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 10},new Method("Ljava/security/KeyStore;","getInstance",new String[]{ "Ljava/lang/String;"},"Ljava/security/KeyStore;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitLabel(L29);
                code.visitFieldStmt(IGET_OBJECT,10,12,new Field("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","_trustPassword","Lorg/mortbay/jetty/security/Password;"));
                code.visitJumpStmt(IF_NEZ,10,-1,L8);
                code.visitStmt2R(MOVE_OBJECT,10,11);
                DexLabel L48=new DexLabel();
                code.visitLabel(L48);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,9,10},new Method("Ljava/security/KeyStore;","load",new String[]{ "Ljava/io/InputStream;","[C"},"V"));
                code.visitLabel(L4);
                code.visitJumpStmt(IF_EQZ,9,-1,L31);
                code.visitLabel(L30);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9},new Method("Ljava/io/InputStream;","close",new String[]{ },"V"));
                code.visitLabel(L31);
                code.visitFieldStmt(IGET_OBJECT,10,12,new Field("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","_sslTrustManagerFactoryAlgorithm","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 10},new Method("Ljavax/net/ssl/TrustManagerFactory;","getInstance",new String[]{ "Ljava/lang/String;"},"Ljavax/net/ssl/TrustManagerFactory;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitLabel(L32);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,8},new Method("Ljavax/net/ssl/TrustManagerFactory;","init",new String[]{ "Ljava/security/KeyStore;"},"V"));
                code.visitLabel(L33);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljavax/net/ssl/TrustManagerFactory;","getTrustManagers",new String[]{ },"[Ljavax/net/ssl/TrustManager;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitLabel(L34);
                code.visitFieldStmt(IGET_OBJECT,10,12,new Field("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","_secureRandomAlgorithm","Ljava/lang/String;"));
                code.visitJumpStmt(IF_NEZ,10,-1,L43);
                code.visitStmt2R(MOVE_OBJECT,5,11);
                code.visitLabel(L35);
                code.visitFieldStmt(IGET_OBJECT,10,12,new Field("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","_provider","Ljava/lang/String;"));
                code.visitJumpStmt(IF_NEZ,10,-1,L44);
                code.visitFieldStmt(IGET_OBJECT,10,12,new Field("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","_protocol","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 10},new Method("Ljavax/net/ssl/SSLContext;","getInstance",new String[]{ "Ljava/lang/String;"},"Ljavax/net/ssl/SSLContext;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,10);
                code.visitStmt2R(MOVE_OBJECT,0,10);
                code.visitLabel(L36);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,2,7,5},new Method("Ljavax/net/ssl/SSLContext;","init",new String[]{ "[Ljavax/net/ssl/KeyManager;","[Ljavax/net/ssl/TrustManager;","Ljava/security/SecureRandom;"},"V"));
                code.visitLabel(L37);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,10,12,new Field("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","_password","Lorg/mortbay/jetty/security/Password;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Lorg/mortbay/jetty/security/Password;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Ljava/lang/String;","toCharArray",new String[]{ },"[C"));
                code.visitLabel(L7);
                code.visitStmt1R(MOVE_RESULT_OBJECT,10);
                code.visitJumpStmt(GOTO,-1,-1,L45);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,10);
                code.visitJumpStmt(IF_EQZ,4,-1,L39);
                code.visitLabel(L38);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/io/InputStream;","close",new String[]{ },"V"));
                code.visitLabel(L39);
                code.visitStmt1R(THROW,10);
                code.visitLabel(L40);
                code.visitFieldStmt(IGET_OBJECT,10,12,new Field("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","_password","Lorg/mortbay/jetty/security/Password;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Lorg/mortbay/jetty/security/Password;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Ljava/lang/String;","toCharArray",new String[]{ },"[C"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,10);
                code.visitJumpStmt(GOTO,-1,-1,L47);
                code.visitLabel(L46);
                code.visitFieldStmt(IGET_OBJECT,10,12,new Field("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","_keyPassword","Lorg/mortbay/jetty/security/Password;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Lorg/mortbay/jetty/security/Password;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Ljava/lang/String;","toCharArray",new String[]{ },"[C"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,10);
                code.visitJumpStmt(GOTO,-1,-1,L47);
                code.visitLabel(L8);
                code.visitFieldStmt(IGET_OBJECT,10,12,new Field("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","_trustPassword","Lorg/mortbay/jetty/security/Password;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Lorg/mortbay/jetty/security/Password;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Ljava/lang/String;","toCharArray",new String[]{ },"[C"));
                code.visitLabel(L9);
                code.visitStmt1R(MOVE_RESULT_OBJECT,10);
                code.visitJumpStmt(GOTO,-1,-1,L48);
                code.visitLabel(L5);
                code.visitStmt1R(MOVE_EXCEPTION,10);
                code.visitJumpStmt(IF_EQZ,9,-1,L42);
                code.visitLabel(L41);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9},new Method("Ljava/io/InputStream;","close",new String[]{ },"V"));
                code.visitLabel(L42);
                code.visitStmt1R(THROW,10);
                code.visitLabel(L43);
                code.visitFieldStmt(IGET_OBJECT,10,12,new Field("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","_secureRandomAlgorithm","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 10},new Method("Ljava/security/SecureRandom;","getInstance",new String[]{ "Ljava/lang/String;"},"Ljava/security/SecureRandom;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,10);
                code.visitStmt2R(MOVE_OBJECT,5,10);
                code.visitJumpStmt(GOTO,-1,-1,L35);
                code.visitLabel(L44);
                code.visitFieldStmt(IGET_OBJECT,10,12,new Field("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","_protocol","Ljava/lang/String;"));
                code.visitFieldStmt(IGET_OBJECT,11,12,new Field("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","_provider","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 10,11},new Method("Ljavax/net/ssl/SSLContext;","getInstance",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"Ljavax/net/ssl/SSLContext;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,10);
                code.visitStmt2R(MOVE_OBJECT,0,10);
                code.visitJumpStmt(GOTO,-1,-1,L36);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_createSSLEngine(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","createSSLEngine",new String[]{ },"Ljavax/net/ssl/SSLEngine;"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(9);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/lang/Exception;"});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L2},new String[]{ "Ljava/lang/Exception;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L5=new DexLabel();
                ddv.visitPrologue(L5);
                ddv.visitLineNumber(533,L5);
                ddv.visitLineNumber(536,L0);
                ddv.visitStartLocal(4,L0,"engine","Ljavax/net/ssl/SSLEngine;",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(537,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(539,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(540,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(541,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(542,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(544,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(546,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(547,L13);
                ddv.visitStartLocal(5,L13,"excludedCSList","Ljava/util/List;","Ljava/util/List<Ljava/lang/String;>;");
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(548,L14);
                ddv.visitStartLocal(3,L14,"enabledCipherSuites","[Ljava/lang/String;",null);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(550,L15);
                ddv.visitStartLocal(2,L15,"enabledCSList","Ljava/util/List;","Ljava/util/List<Ljava/lang/String;>;");
                DexLabel L16=new DexLabel();
                ddv.visitStartLocal(6,L16,"i$","Ljava/util/Iterator;",null);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(552,L17);
                ddv.visitStartLocal(0,L17,"cipherName","Ljava/lang/String;",null);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(554,L18);
                ddv.visitLineNumber(563,L2);
                ddv.visitEndLocal(5,L2);
                ddv.visitEndLocal(3,L2);
                ddv.visitEndLocal(2,L2);
                ddv.visitEndLocal(6,L2);
                ddv.visitEndLocal(0,L2);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(565,L19);
                ddv.visitStartLocal(1,L19,"e","Ljava/lang/Exception;",null);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(566,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(567,L21);
                ddv.visitLineNumber(557,L3);
                ddv.visitEndLocal(1,L3);
                ddv.visitRestartLocal(2,L3);
                ddv.visitRestartLocal(3,L3);
                ddv.visitRestartLocal(5,L3);
                ddv.visitRestartLocal(6,L3);
                DexLabel L22=new DexLabel();
                ddv.visitEndLocal(3,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(559,L23);
                ddv.visitRestartLocal(3,L23);
                ddv.visitLineNumber(569,L4);
                ddv.visitEndLocal(2,L4);
                ddv.visitEndLocal(5,L4);
                ddv.visitEndLocal(6,L4);
                ddv.visitEndLocal(3,L4);
                code.visitLabel(L5);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,7,8,new Field("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","_context","Ljavax/net/ssl/SSLContext;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Ljavax/net/ssl/SSLContext;","createSSLEngine",new String[]{ },"Ljavax/net/ssl/SSLEngine;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitLabel(L6);
                code.visitConstStmt(CONST_4,7, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,7},new Method("Ljavax/net/ssl/SSLEngine;","setUseClientMode",new String[]{ "Z"},"V"));
                code.visitLabel(L7);
                code.visitFieldStmt(IGET_BOOLEAN,7,8,new Field("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","_wantClientAuth","Z"));
                code.visitJumpStmt(IF_EQZ,7,-1,L9);
                code.visitLabel(L8);
                code.visitFieldStmt(IGET_BOOLEAN,7,8,new Field("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","_wantClientAuth","Z"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,7},new Method("Ljavax/net/ssl/SSLEngine;","setWantClientAuth",new String[]{ "Z"},"V"));
                code.visitLabel(L9);
                code.visitFieldStmt(IGET_BOOLEAN,7,8,new Field("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","_needClientAuth","Z"));
                code.visitJumpStmt(IF_EQZ,7,-1,L11);
                code.visitLabel(L10);
                code.visitFieldStmt(IGET_BOOLEAN,7,8,new Field("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","_needClientAuth","Z"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,7},new Method("Ljavax/net/ssl/SSLEngine;","setNeedClientAuth",new String[]{ "Z"},"V"));
                code.visitLabel(L11);
                code.visitFieldStmt(IGET_OBJECT,7,8,new Field("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","_excludeCipherSuites","[Ljava/lang/String;"));
                code.visitJumpStmt(IF_EQZ,7,-1,L4);
                code.visitFieldStmt(IGET_OBJECT,7,8,new Field("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","_excludeCipherSuites","[Ljava/lang/String;"));
                code.visitStmt2R(ARRAY_LENGTH,7,7);
                code.visitJumpStmt(IF_LEZ,7,-1,L4);
                code.visitLabel(L12);
                code.visitFieldStmt(IGET_OBJECT,7,8,new Field("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","_excludeCipherSuites","[Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 7},new Method("Ljava/util/Arrays;","asList",new String[]{ "[Ljava/lang/Object;"},"Ljava/util/List;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitLabel(L13);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljavax/net/ssl/SSLEngine;","getEnabledCipherSuites",new String[]{ },"[Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitLabel(L14);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Ljava/util/ArrayList;");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3},new Method("Ljava/util/Arrays;","asList",new String[]{ "[Ljava/lang/Object;"},"Ljava/util/List;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2,7},new Method("Ljava/util/ArrayList;","<init>",new String[]{ "Ljava/util/Collection;"},"V"));
                code.visitLabel(L15);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 5},new Method("Ljava/util/List;","iterator",new String[]{ },"Ljava/util/Iterator;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitLabel(L16);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 6},new Method("Ljava/util/Iterator;","hasNext",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitJumpStmt(IF_EQZ,7,-1,L3);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 6},new Method("Ljava/util/Iterator;","next",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Ljava/lang/String;");
                code.visitLabel(L17);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2,0},new Method("Ljava/util/List;","contains",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitJumpStmt(IF_EQZ,7,-1,L16);
                code.visitLabel(L18);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2,0},new Method("Ljava/util/List;","remove",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitLabel(L1);
                code.visitJumpStmt(GOTO,-1,-1,L16);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,7);
                code.visitStmt2R(MOVE_OBJECT,1,7);
                code.visitLabel(L19);
                code.visitConstStmt(CONST_STRING,7,"Error creating sslEngine -- closing this connector");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 7,1},new Method("Lorg/mortbay/log/Log;","warn",new String[]{ "Ljava/lang/String;","Ljava/lang/Throwable;"},"V"));
                code.visitLabel(L20);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","close",new String[]{ },"V"));
                code.visitLabel(L21);
                code.visitTypeStmt(NEW_INSTANCE,7,-1,"Ljava/lang/IllegalStateException;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 7,1},new Method("Ljava/lang/IllegalStateException;","<init>",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitStmt1R(THROW,7);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2},new Method("Ljava/util/List;","size",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitTypeStmt(NEW_ARRAY,7,7,"[Ljava/lang/String;");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2,7},new Method("Ljava/util/List;","toArray",new String[]{ "[Ljava/lang/Object;"},"[Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitLabel(L22);
                code.visitTypeStmt(CHECK_CAST,3,-1,"[Ljava/lang/String;");
                code.visitLabel(L23);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,3},new Method("Ljavax/net/ssl/SSLEngine;","setEnabledCipherSuites",new String[]{ "[Ljava/lang/String;"},"V"));
                code.visitLabel(L4);
                code.visitStmt1R(RETURN_OBJECT,4);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_customize(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","customize",new String[]{ "Lorg/mortbay/io/EndPoint;","Lorg/mortbay/jetty/Request;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(13);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/lang/Exception;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"endpoint");
                ddv.visitParameterName(1,"request");
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(242,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(243,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(245,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(246,L6);
                ddv.visitStartLocal(7,L6,"sslHttpChannelEndpoint","Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;",null);
                ddv.visitLineNumber(250,L0);
                ddv.visitStartLocal(6,L0,"sslEngine","Ljavax/net/ssl/SSLEngine;",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(251,L7);
                ddv.visitStartLocal(8,L7,"sslSession","Ljavax/net/ssl/SSLSession;",null);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(255,L8);
                ddv.visitStartLocal(3,L8,"cipherSuite","Ljava/lang/String;",null);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(256,L9);
                ddv.visitStartLocal(1,L9,"cachedInfo","Lorg/mortbay/jetty/security/SslSelectChannelConnector$CachedInfo;",null);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(258,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(259,L11);
                ddv.visitStartLocal(5,L11,"keySize","Ljava/lang/Integer;",null);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(269,L12);
                ddv.visitStartLocal(2,L12,"certs","[Ljava/security/cert/X509Certificate;",null);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(270,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(272,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(273,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(279,L16);
                ddv.visitEndLocal(8,L16);
                ddv.visitEndLocal(3,L16);
                ddv.visitEndLocal(1,L16);
                ddv.visitEndLocal(5,L16);
                ddv.visitEndLocal(2,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(263,L17);
                ddv.visitRestartLocal(1,L17);
                ddv.visitRestartLocal(3,L17);
                ddv.visitRestartLocal(8,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(264,L18);
                ddv.visitRestartLocal(5,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(265,L19);
                ddv.visitRestartLocal(2,L19);
                DexLabel L20=new DexLabel();
                ddv.visitEndLocal(1,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(266,L21);
                ddv.visitRestartLocal(1,L21);
                ddv.visitLineNumber(275,L2);
                ddv.visitEndLocal(3,L2);
                ddv.visitEndLocal(8,L2);
                ddv.visitEndLocal(5,L2);
                ddv.visitEndLocal(2,L2);
                ddv.visitEndLocal(1,L2);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(277,L22);
                ddv.visitStartLocal(4,L22,"e","Ljava/lang/Exception;",null);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 10,11,12},new Method("Lorg/mortbay/jetty/nio/SelectChannelConnector;","customize",new String[]{ "Lorg/mortbay/io/EndPoint;","Lorg/mortbay/jetty/Request;"},"V"));
                code.visitLabel(L4);
                code.visitConstStmt(CONST_STRING,9,"https");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12,9},new Method("Lorg/mortbay/jetty/Request;","setScheme",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L5);
                code.visitStmt2R(MOVE_OBJECT,0,11);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;");
                code.visitStmt2R(MOVE_OBJECT,7,0);
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","getSSLEngine",new String[]{ },"Ljavax/net/ssl/SSLEngine;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljavax/net/ssl/SSLEngine;","getSession",new String[]{ },"Ljavax/net/ssl/SSLSession;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 8},new Method("Ljavax/net/ssl/SSLSession;","getCipherSuite",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitLabel(L8);
                code.visitFieldStmt(SGET_OBJECT,9,-1,new Field("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","CACHED_INFO_ATTR","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 8,9},new Method("Ljavax/net/ssl/SSLSession;","getValue",new String[]{ "Ljava/lang/String;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitTypeStmt(CHECK_CAST,1,-1,"Lorg/mortbay/jetty/security/SslSelectChannelConnector$CachedInfo;");
                code.visitLabel(L9);
                code.visitJumpStmt(IF_EQZ,1,-1,L17);
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/jetty/security/SslSelectChannelConnector$CachedInfo;","getKeySize",new String[]{ },"Ljava/lang/Integer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitLabel(L11);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/jetty/security/SslSelectChannelConnector$CachedInfo;","getCerts",new String[]{ },"[Ljava/security/cert/X509Certificate;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L12);
                code.visitJumpStmt(IF_EQZ,2,-1,L14);
                code.visitLabel(L13);
                code.visitConstStmt(CONST_STRING,9,"javax.servlet.request.X509Certificate");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12,9,2},new Method("Lorg/mortbay/jetty/Request;","setAttribute",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L14);
                code.visitConstStmt(CONST_STRING,9,"javax.servlet.request.cipher_suite");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12,9,3},new Method("Lorg/mortbay/jetty/Request;","setAttribute",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L15);
                code.visitConstStmt(CONST_STRING,9,"javax.servlet.request.key_size");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12,9,5},new Method("Lorg/mortbay/jetty/Request;","setAttribute",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L16);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L17);
                code.visitTypeStmt(NEW_INSTANCE,5,-1,"Ljava/lang/Integer;");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3},new Method("Lorg/mortbay/jetty/security/ServletSSL;","deduceKeyLength",new String[]{ "Ljava/lang/String;"},"I"));
                code.visitStmt1R(MOVE_RESULT,9);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 5,9},new Method("Ljava/lang/Integer;","<init>",new String[]{ "I"},"V"));
                code.visitLabel(L18);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 8},new Method("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","getCertChain",new String[]{ "Ljavax/net/ssl/SSLSession;"},"[Ljava/security/cert/X509Certificate;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L19);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Lorg/mortbay/jetty/security/SslSelectChannelConnector$CachedInfo;");
                code.visitLabel(L20);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,10,5,2},new Method("Lorg/mortbay/jetty/security/SslSelectChannelConnector$CachedInfo;","<init>",new String[]{ "Lorg/mortbay/jetty/security/SslSelectChannelConnector;","Ljava/lang/Integer;","[Ljava/security/cert/X509Certificate;"},"V"));
                code.visitLabel(L21);
                code.visitFieldStmt(SGET_OBJECT,9,-1,new Field("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","CACHED_INFO_ATTR","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 8,9,1},new Method("Ljavax/net/ssl/SSLSession;","putValue",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L1);
                code.visitJumpStmt(GOTO,-1,-1,L12);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,9);
                code.visitStmt2R(MOVE_OBJECT,4,9);
                code.visitLabel(L22);
                code.visitConstStmt(CONST_STRING,9,"EXCEPTION ");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 9,4},new Method("Lorg/mortbay/log/Log;","warn",new String[]{ "Ljava/lang/String;","Ljava/lang/Throwable;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L16);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_doStart(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","doStart",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/Exception;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(575,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(577,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(578,L2);
                ddv.visitStartLocal(0,L2,"engine","Ljavax/net/ssl/SSLEngine;",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(580,L3);
                ddv.visitStartLocal(1,L3,"ssl_session","Ljavax/net/ssl/SSLSession;",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(581,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(582,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(584,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(585,L7);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","createSSLContext",new String[]{ },"Ljavax/net/ssl/SSLContext;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitFieldStmt(IPUT_OBJECT,2,3,new Field("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","_context","Ljavax/net/ssl/SSLContext;"));
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","createSSLEngine",new String[]{ },"Ljavax/net/ssl/SSLEngine;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljavax/net/ssl/SSLEngine;","getSession",new String[]{ },"Ljavax/net/ssl/SSLSession;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Ljavax/net/ssl/SSLSession;","getApplicationBufferSize",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,2},new Method("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","setHeaderBufferSize",new String[]{ "I"},"V"));
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Ljavax/net/ssl/SSLSession;","getApplicationBufferSize",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,2},new Method("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","setRequestBufferSize",new String[]{ "I"},"V"));
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Ljavax/net/ssl/SSLSession;","getApplicationBufferSize",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,2},new Method("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","setResponseBufferSize",new String[]{ "I"},"V"));
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 3},new Method("Lorg/mortbay/jetty/nio/SelectChannelConnector;","doStart",new String[]{ },"V"));
                code.visitLabel(L7);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m007_getAlgorithm(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","getAlgorithm",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(343,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","_algorithm","Ljava/lang/String;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m008_getBuffer(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","getBuffer",new String[]{ "I"},"Lorg/mortbay/io/Buffer;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"size");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(126,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(128,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(129,L2);
                ddv.visitStartLocal(0,L2,"buffer","Lorg/mortbay/io/Buffer;",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(130,L3);
                DexLabel L4=new DexLabel();
                ddv.visitEndLocal(0,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(143,L5);
                ddv.visitRestartLocal(0,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(132,L6);
                ddv.visitEndLocal(0,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(134,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(135,L8);
                ddv.visitRestartLocal(0,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(136,L9);
                DexLabel L10=new DexLabel();
                ddv.visitRestartLocal(0,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(141,L11);
                ddv.visitEndLocal(0,L11);
                DexLabel L12=new DexLabel();
                ddv.visitRestartLocal(0,L12);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,1,2,new Field("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","_applicationBufferSize","I"));
                code.visitJumpStmt(IF_NE,3,1,L6);
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","_applicationBuffers","Ljava/util/concurrent/ConcurrentLinkedQueue;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/util/concurrent/ConcurrentLinkedQueue;","poll",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Lorg/mortbay/io/Buffer;");
                code.visitLabel(L2);
                code.visitJumpStmt(IF_NEZ,0,-1,L5);
                code.visitLabel(L3);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/io/nio/IndirectNIOBuffer;");
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,3},new Method("Lorg/mortbay/io/nio/IndirectNIOBuffer;","<init>",new String[]{ "I"},"V"));
                code.visitLabel(L5);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L6);
                code.visitFieldStmt(IGET,1,2,new Field("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","_packetBufferSize","I"));
                code.visitJumpStmt(IF_NE,3,1,L11);
                code.visitLabel(L7);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","_packetBuffers","Ljava/util/concurrent/ConcurrentLinkedQueue;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/util/concurrent/ConcurrentLinkedQueue;","poll",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Lorg/mortbay/io/Buffer;");
                code.visitLabel(L8);
                code.visitJumpStmt(IF_NEZ,0,-1,L5);
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","getUseDirectBuffers",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,1);
                DexLabel L13=new DexLabel();
                code.visitJumpStmt(IF_EQZ,1,-1,L13);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Lorg/mortbay/io/nio/DirectNIOBuffer;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,3},new Method("Lorg/mortbay/io/nio/DirectNIOBuffer;","<init>",new String[]{ "I"},"V"));
                code.visitStmt2R(MOVE_OBJECT,0,1);
                code.visitLabel(L10);
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitLabel(L13);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Lorg/mortbay/io/nio/IndirectNIOBuffer;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,3},new Method("Lorg/mortbay/io/nio/IndirectNIOBuffer;","<init>",new String[]{ "I"},"V"));
                code.visitStmt2R(MOVE_OBJECT,0,1);
                code.visitJumpStmt(GOTO,-1,-1,L10);
                code.visitLabel(L11);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 2,3},new Method("Lorg/mortbay/jetty/nio/SelectChannelConnector;","getBuffer",new String[]{ "I"},"Lorg/mortbay/io/Buffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L12);
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m009_getCipherSuites(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","getCipherSuites",new String[]{ },"[Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(298,L0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","getExcludeCipherSuites",new String[]{ },"[Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m010_getExcludeCipherSuites(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","getExcludeCipherSuites",new String[]{ },"[Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(303,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","_excludeCipherSuites","[Ljava/lang/String;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m011_getKeystore(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","getKeystore",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(373,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","_keystore","Ljava/lang/String;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m012_getKeystoreType(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","getKeystoreType",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(379,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","_keystoreType","Ljava/lang/String;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m013_getNeedClientAuth(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","getNeedClientAuth",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(385,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_BOOLEAN,0,1,new Field("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","_needClientAuth","Z"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m014_getProtocol(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","getProtocol",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(355,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","_protocol","Ljava/lang/String;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m015_getProvider(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","getProvider",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(420,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","_provider","Ljava/lang/String;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m016_getSecureRandomAlgorithm(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","getSecureRandomAlgorithm",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(425,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","_secureRandomAlgorithm","Ljava/lang/String;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m017_getSslKeyManagerFactoryAlgorithm(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","getSslKeyManagerFactoryAlgorithm",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(431,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","_sslKeyManagerFactoryAlgorithm","Ljava/lang/String;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m018_getSslTrustManagerFactoryAlgorithm(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","getSslTrustManagerFactoryAlgorithm",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(437,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","_sslTrustManagerFactoryAlgorithm","Ljava/lang/String;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m019_getTruststore(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","getTruststore",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(443,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","_truststore","Ljava/lang/String;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m020_getTruststoreType(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","getTruststoreType",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(449,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","_truststoreType","Ljava/lang/String;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m021_getWantClientAuth(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","getWantClientAuth",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(391,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_BOOLEAN,0,1,new Field("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","_wantClientAuth","Z"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m022_isConfidential(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","isConfidential",new String[]{ "Lorg/mortbay/jetty/Request;"},"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"request");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(497,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(498,L1);
                ddv.visitStartLocal(0,L1,"confidentialPort","I",null);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","getConfidentialPort",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitLabel(L1);
                DexLabel L2=new DexLabel();
                code.visitJumpStmt(IF_EQZ,0,-1,L2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/jetty/Request;","getServerPort",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                DexLabel L3=new DexLabel();
                code.visitJumpStmt(IF_NE,0,1,L3);
                code.visitLabel(L2);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                DexLabel L4=new DexLabel();
                code.visitLabel(L4);
                code.visitStmt1R(RETURN,1);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m023_isIntegral(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","isIntegral",new String[]{ "Lorg/mortbay/jetty/Request;"},"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"request");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(512,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(513,L1);
                ddv.visitStartLocal(0,L1,"integralPort","I",null);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","getIntegralPort",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitLabel(L1);
                DexLabel L2=new DexLabel();
                code.visitJumpStmt(IF_EQZ,0,-1,L2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/jetty/Request;","getServerPort",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                DexLabel L3=new DexLabel();
                code.visitJumpStmt(IF_NE,0,1,L3);
                code.visitLabel(L2);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                DexLabel L4=new DexLabel();
                code.visitLabel(L4);
                code.visitStmt1R(RETURN,1);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m024_newConnection(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","newConnection",new String[]{ "Ljava/nio/channels/SocketChannel;","Lorg/mortbay/io/nio/SelectChannelEndPoint;"},"Lorg/mortbay/io/Connection;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"channel");
                ddv.visitParameterName(1,"endpoint");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(525,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(526,L1);
                ddv.visitStartLocal(0,L1,"connection","Lorg/mortbay/jetty/HttpConnection;",null);
                DexLabel L2=new DexLabel();
                ddv.visitEndLocal(2,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(527,L3);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 2,3,4},new Method("Lorg/mortbay/jetty/nio/SelectChannelConnector;","newConnection",new String[]{ "Ljava/nio/channels/SocketChannel;","Lorg/mortbay/io/nio/SelectChannelEndPoint;"},"Lorg/mortbay/io/Connection;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Lorg/mortbay/jetty/HttpConnection;");
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/HttpConnection;","getParser",new String[]{ },"Lorg/mortbay/jetty/Parser;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L2);
                code.visitTypeStmt(CHECK_CAST,2,-1,"Lorg/mortbay/jetty/HttpParser;");
                code.visitConstStmt(CONST_4,1, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,1},new Method("Lorg/mortbay/jetty/HttpParser;","setForceContentBuffer",new String[]{ "Z"},"V"));
                code.visitLabel(L3);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m025_newEndPoint(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","newEndPoint",new String[]{ "Ljava/nio/channels/SocketChannel;","Lorg/mortbay/io/nio/SelectorManager$SelectSet;","Ljava/nio/channels/SelectionKey;"},"Lorg/mortbay/io/nio/SelectChannelEndPoint;"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(10);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"channel");
                ddv.visitParameterName(1,"selectSet");
                ddv.visitParameterName(2,"key");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(519,L0);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","createSSLEngine",new String[]{ },"Ljavax/net/ssl/SSLEngine;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitStmt2R(MOVE_OBJECT,1,6);
                code.visitStmt2R(MOVE_OBJECT,2,7);
                code.visitStmt2R(MOVE_OBJECT,3,8);
                code.visitStmt2R(MOVE_OBJECT,4,9);
                code.visitMethodStmt(INVOKE_DIRECT_RANGE,new int[]{ 0,1,2,3,4,5},new Method("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","<init>",new String[]{ "Lorg/mortbay/io/Buffers;","Ljava/nio/channels/SocketChannel;","Lorg/mortbay/io/nio/SelectorManager$SelectSet;","Ljava/nio/channels/SelectionKey;","Ljavax/net/ssl/SSLEngine;"},"V"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m026_returnBuffer(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","returnBuffer",new String[]{ "Lorg/mortbay/io/Buffer;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"buffer");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(153,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(154,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(155,L2);
                ddv.visitStartLocal(2,L2,"size","I",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(156,L3);
                ddv.visitStartLocal(1,L3,"bbuf","Ljava/nio/ByteBuffer;",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(157,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(159,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(160,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(165,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(161,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(162,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(164,L10);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 5},new Method("Lorg/mortbay/io/Buffer;","clear",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 5},new Method("Lorg/mortbay/io/Buffer;","capacity",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitLabel(L2);
                code.visitStmt2R(MOVE_OBJECT,0,5);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Lorg/mortbay/io/nio/NIOBuffer;");
                code.visitStmt2R(MOVE_OBJECT,3,0);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3},new Method("Lorg/mortbay/io/nio/NIOBuffer;","getByteBuffer",new String[]{ },"Ljava/nio/ByteBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,3},new Method("Ljava/nio/ByteBuffer;","position",new String[]{ "I"},"Ljava/nio/Buffer;"));
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/nio/ByteBuffer;","limit",new String[]{ "I"},"Ljava/nio/Buffer;"));
                code.visitLabel(L5);
                code.visitFieldStmt(IGET,3,4,new Field("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","_applicationBufferSize","I"));
                code.visitJumpStmt(IF_NE,2,3,L8);
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,3,4,new Field("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","_applicationBuffers","Ljava/util/concurrent/ConcurrentLinkedQueue;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,5},new Method("Ljava/util/concurrent/ConcurrentLinkedQueue;","add",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitLabel(L7);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L8);
                code.visitFieldStmt(IGET,3,4,new Field("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","_packetBufferSize","I"));
                code.visitJumpStmt(IF_NE,2,3,L10);
                code.visitLabel(L9);
                code.visitFieldStmt(IGET_OBJECT,3,4,new Field("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","_packetBuffers","Ljava/util/concurrent/ConcurrentLinkedQueue;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,5},new Method("Ljava/util/concurrent/ConcurrentLinkedQueue;","add",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitJumpStmt(GOTO,-1,-1,L7);
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 4,5},new Method("Lorg/mortbay/jetty/nio/SelectChannelConnector;","returnBuffer",new String[]{ "Lorg/mortbay/io/Buffer;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L7);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m027_setAlgorithm(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","setAlgorithm",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"algorithm");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(349,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(350,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","_algorithm","Ljava/lang/String;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m028_setCipherSuites(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","setCipherSuites",new String[]{ "[Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"cipherSuites");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(314,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(315,L1);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","setExcludeCipherSuites",new String[]{ "[Ljava/lang/String;"},"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m029_setExcludeCipherSuites(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","setExcludeCipherSuites",new String[]{ "[Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"cipherSuites");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(319,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(320,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","_excludeCipherSuites","[Ljava/lang/String;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m030_setKeyPassword(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","setKeyPassword",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"password");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(337,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(338,L1);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_STRING,0,"jetty.ssl.keypassword");
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,3,1},new Method("Lorg/mortbay/jetty/security/Password;","getPassword",new String[]{ "Ljava/lang/String;","Ljava/lang/String;","Ljava/lang/String;"},"Lorg/mortbay/jetty/security/Password;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","_keyPassword","Lorg/mortbay/jetty/security/Password;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m031_setKeystore(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","setKeystore",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"keystore");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(367,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(368,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","_keystore","Ljava/lang/String;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m032_setKeystoreType(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","setKeystoreType",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"keystoreType");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(414,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(415,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","_keystoreType","Ljava/lang/String;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m033_setNeedClientAuth(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","setNeedClientAuth",new String[]{ "Z"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"needClientAuth");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(403,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(404,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_BOOLEAN,1,0,new Field("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","_needClientAuth","Z"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m034_setPassword(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","setPassword",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"password");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(325,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(326,L1);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_STRING,0,"jetty.ssl.password");
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,3,1},new Method("Lorg/mortbay/jetty/security/Password;","getPassword",new String[]{ "Ljava/lang/String;","Ljava/lang/String;","Ljava/lang/String;"},"Lorg/mortbay/jetty/security/Password;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","_password","Lorg/mortbay/jetty/security/Password;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m035_setProtocol(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","setProtocol",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"protocol");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(361,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(362,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","_protocol","Ljava/lang/String;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m036_setProvider(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","setProvider",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"_provider");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(455,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(456,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","_provider","Ljava/lang/String;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m037_setSecureRandomAlgorithm(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","setSecureRandomAlgorithm",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"algorithm");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(461,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(462,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","_secureRandomAlgorithm","Ljava/lang/String;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m038_setSslKeyManagerFactoryAlgorithm(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","setSslKeyManagerFactoryAlgorithm",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"algorithm");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(467,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(468,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","_sslKeyManagerFactoryAlgorithm","Ljava/lang/String;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m039_setSslTrustManagerFactoryAlgorithm(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","setSslTrustManagerFactoryAlgorithm",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"algorithm");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(473,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(474,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","_sslTrustManagerFactoryAlgorithm","Ljava/lang/String;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m040_setTrustPassword(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","setTrustPassword",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"password");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(331,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(332,L1);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_STRING,0,"jetty.ssl.password");
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,3,1},new Method("Lorg/mortbay/jetty/security/Password;","getPassword",new String[]{ "Ljava/lang/String;","Ljava/lang/String;","Ljava/lang/String;"},"Lorg/mortbay/jetty/security/Password;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","_trustPassword","Lorg/mortbay/jetty/security/Password;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m041_setTruststore(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","setTruststore",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"truststore");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(478,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(479,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","_truststore","Ljava/lang/String;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m042_setTruststoreType(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","setTruststoreType",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"truststoreType");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(483,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(484,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","_truststoreType","Ljava/lang/String;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m043_setWantClientAuth(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","setWantClientAuth",new String[]{ "Z"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"wantClientAuth");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(408,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(409,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_BOOLEAN,1,0,new Field("Lorg/mortbay/jetty/security/SslSelectChannelConnector;","_wantClientAuth","Z"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
