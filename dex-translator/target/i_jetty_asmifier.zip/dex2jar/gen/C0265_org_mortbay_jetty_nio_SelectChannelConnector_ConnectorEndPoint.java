package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0265_org_mortbay_jetty_nio_SelectChannelConnector_ConnectorEndPoint {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/jetty/nio/SelectChannelConnector$ConnectorEndPoint;","Lorg/mortbay/io/nio/SelectChannelEndPoint;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("SelectChannelConnector.java");
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/EnclosingClass;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("value", new DexType("Lorg/mortbay/jetty/nio/SelectChannelConnector;"));
                av00.visitEnd();
            }
        }
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/InnerClass;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("accessFlags",  Integer.valueOf(9));
                av00.visit("name", "ConnectorEndPoint");
                av00.visitEnd();
            }
        }
        m000__init_(cv);
        m001_close(cv);
        m002_undispatch(cv);
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/nio/SelectChannelConnector$ConnectorEndPoint;","<init>",new String[]{ "Ljava/nio/channels/SocketChannel;","Lorg/mortbay/io/nio/SelectorManager$SelectSet;","Ljava/nio/channels/SelectionKey;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"channel");
                ddv.visitParameterName(1,"selectSet");
                ddv.visitParameterName(2,"key");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(348,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(349,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(350,L2);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1,2,3},new Method("Lorg/mortbay/io/nio/SelectChannelEndPoint;","<init>",new String[]{ "Ljava/nio/channels/SocketChannel;","Lorg/mortbay/io/nio/SelectorManager$SelectSet;","Ljava/nio/channels/SelectionKey;"},"V"));
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/nio/SelectChannelConnector$ConnectorEndPoint;","scheduleIdle",new String[]{ },"V"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001_close(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/nio/SelectChannelConnector$ConnectorEndPoint;","close",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(354,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(355,L1);
                ddv.visitStartLocal(0,L1,"con","Lorg/mortbay/io/Connection;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(357,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(358,L3);
                ddv.visitStartLocal(1,L3,"continuation","Lorg/mortbay/jetty/nio/SelectChannelConnector$RetryContinuation;",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(359,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(362,L5);
                ddv.visitEndLocal(1,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(363,L6);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/jetty/nio/SelectChannelConnector$ConnectorEndPoint;","getConnection",new String[]{ },"Lorg/mortbay/io/Connection;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L1);
                code.visitTypeStmt(INSTANCE_OF,2,0,"Lorg/mortbay/jetty/HttpConnection;");
                code.visitJumpStmt(IF_EQZ,2,-1,L5);
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/jetty/nio/SelectChannelConnector$ConnectorEndPoint;","getConnection",new String[]{ },"Lorg/mortbay/io/Connection;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitTypeStmt(CHECK_CAST,2,-1,"Lorg/mortbay/jetty/HttpConnection;");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/HttpConnection;","getRequest",new String[]{ },"Lorg/mortbay/jetty/Request;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/Request;","getContinuation",new String[]{ },"Lorg/mortbay/util/ajax/Continuation;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitTypeStmt(CHECK_CAST,1,-1,"Lorg/mortbay/jetty/nio/SelectChannelConnector$RetryContinuation;");
                code.visitLabel(L3);
                code.visitJumpStmt(IF_EQZ,1,-1,L5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/jetty/nio/SelectChannelConnector$RetryContinuation;","isPending",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_EQZ,2,-1,L5);
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/jetty/nio/SelectChannelConnector$RetryContinuation;","reset",new String[]{ },"V"));
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 3},new Method("Lorg/mortbay/io/nio/SelectChannelEndPoint;","close",new String[]{ },"V"));
                code.visitLabel(L6);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_undispatch(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/nio/SelectChannelConnector$ConnectorEndPoint;","undispatch",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(368,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(369,L1);
                ddv.visitStartLocal(0,L1,"con","Lorg/mortbay/io/Connection;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(371,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(373,L3);
                ddv.visitStartLocal(1,L3,"continuation","Lorg/mortbay/jetty/nio/SelectChannelConnector$RetryContinuation;",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(376,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(377,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(378,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(387,L7);
                ddv.visitEndLocal(1,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(382,L8);
                ddv.visitRestartLocal(1,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(386,L9);
                ddv.visitEndLocal(1,L9);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/jetty/nio/SelectChannelConnector$ConnectorEndPoint;","getConnection",new String[]{ },"Lorg/mortbay/io/Connection;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L1);
                code.visitTypeStmt(INSTANCE_OF,2,0,"Lorg/mortbay/jetty/HttpConnection;");
                code.visitJumpStmt(IF_EQZ,2,-1,L9);
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/jetty/nio/SelectChannelConnector$ConnectorEndPoint;","getConnection",new String[]{ },"Lorg/mortbay/io/Connection;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitTypeStmt(CHECK_CAST,2,-1,"Lorg/mortbay/jetty/HttpConnection;");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/HttpConnection;","getRequest",new String[]{ },"Lorg/mortbay/jetty/Request;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/Request;","getContinuation",new String[]{ },"Lorg/mortbay/util/ajax/Continuation;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitTypeStmt(CHECK_CAST,1,-1,"Lorg/mortbay/jetty/nio/SelectChannelConnector$RetryContinuation;");
                code.visitLabel(L3);
                code.visitJumpStmt(IF_EQZ,1,-1,L8);
                code.visitLabel(L4);
                code.visitConstStmt(CONST_STRING,2,"continuation {}");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2,1},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/jetty/nio/SelectChannelConnector$RetryContinuation;","undispatch",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_EQZ,2,-1,L7);
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 3},new Method("Lorg/mortbay/io/nio/SelectChannelEndPoint;","undispatch",new String[]{ },"V"));
                code.visitLabel(L7);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 3},new Method("Lorg/mortbay/io/nio/SelectChannelEndPoint;","undispatch",new String[]{ },"V"));
                code.visitJumpStmt(GOTO,-1,-1,L7);
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 3},new Method("Lorg/mortbay/io/nio/SelectChannelEndPoint;","undispatch",new String[]{ },"V"));
                code.visitJumpStmt(GOTO,-1,-1,L7);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
