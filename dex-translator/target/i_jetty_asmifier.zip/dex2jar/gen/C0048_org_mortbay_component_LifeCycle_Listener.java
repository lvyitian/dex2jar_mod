package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0048_org_mortbay_component_LifeCycle_Listener {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC|ACC_INTERFACE|ACC_ABSTRACT,"Lorg/mortbay/component/LifeCycle$Listener;","Ljava/lang/Object;",new String[]{ "Ljava/util/EventListener;"});
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("LifeCycle.java");
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/EnclosingClass;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("value", new DexType("Lorg/mortbay/component/LifeCycle;"));
                av00.visitEnd();
            }
        }
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/InnerClass;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("accessFlags",  Integer.valueOf(1545));
                av00.visit("name", "Listener");
                av00.visitEnd();
            }
        }
        m000_lifeCycleFailure(cv);
        m001_lifeCycleStarted(cv);
        m002_lifeCycleStarting(cv);
        m003_lifeCycleStopped(cv);
        m004_lifeCycleStopping(cv);
    }
    public static void m000_lifeCycleFailure(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/component/LifeCycle$Listener;","lifeCycleFailure",new String[]{ "Lorg/mortbay/component/LifeCycle;","Ljava/lang/Throwable;"},"V"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m001_lifeCycleStarted(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/component/LifeCycle$Listener;","lifeCycleStarted",new String[]{ "Lorg/mortbay/component/LifeCycle;"},"V"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m002_lifeCycleStarting(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/component/LifeCycle$Listener;","lifeCycleStarting",new String[]{ "Lorg/mortbay/component/LifeCycle;"},"V"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m003_lifeCycleStopped(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/component/LifeCycle$Listener;","lifeCycleStopped",new String[]{ "Lorg/mortbay/component/LifeCycle;"},"V"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m004_lifeCycleStopping(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/component/LifeCycle$Listener;","lifeCycleStopping",new String[]{ "Lorg/mortbay/component/LifeCycle;"},"V"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
}
