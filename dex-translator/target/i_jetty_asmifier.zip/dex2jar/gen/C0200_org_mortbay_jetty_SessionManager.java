package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0200_org_mortbay_jetty_SessionManager {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC|ACC_INTERFACE|ACC_ABSTRACT,"Lorg/mortbay/jetty/SessionManager;","Ljava/lang/Object;",new String[]{ "Lorg/mortbay/component/LifeCycle;"});
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("SessionManager.java");
        f000___DefaultSessionCookie(cv);
        f001___DefaultSessionDomain(cv);
        f002___DefaultSessionURL(cv);
        f003___MaxAgeProperty(cv);
        f004___SessionCookieProperty(cv);
        f005___SessionDomainProperty(cv);
        f006___SessionPathProperty(cv);
        f007___SessionURLProperty(cv);
        m000__clinit_(cv);
        m001_access(cv);
        m002_addEventListener(cv);
        m003_clearEventListeners(cv);
        m004_complete(cv);
        m005_getClusterId(cv);
        m006_getHttpOnly(cv);
        m007_getHttpSession(cv);
        m008_getIdManager(cv);
        m009_getMaxCookieAge(cv);
        m010_getMaxInactiveInterval(cv);
        m011_getMetaManager(cv);
        m012_getNodeId(cv);
        m013_getSecureCookies(cv);
        m014_getSessionCookie(cv);
        m015_getSessionCookie(cv);
        m016_getSessionDomain(cv);
        m017_getSessionPath(cv);
        m018_getSessionURL(cv);
        m019_getSessionURLPrefix(cv);
        m020_isUsingCookies(cv);
        m021_isValid(cv);
        m022_newHttpSession(cv);
        m023_removeEventListener(cv);
        m024_setIdManager(cv);
        m025_setMaxCookieAge(cv);
        m026_setMaxInactiveInterval(cv);
        m027_setSessionCookie(cv);
        m028_setSessionDomain(cv);
        m029_setSessionHandler(cv);
        m030_setSessionPath(cv);
        m031_setSessionURL(cv);
    }
    public static void f000___DefaultSessionCookie(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/SessionManager;","__DefaultSessionCookie","Ljava/lang/String;"), "JSESSIONID");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001___DefaultSessionDomain(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/SessionManager;","__DefaultSessionDomain","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002___DefaultSessionURL(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/SessionManager;","__DefaultSessionURL","Ljava/lang/String;"), "jsessionid");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003___MaxAgeProperty(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/SessionManager;","__MaxAgeProperty","Ljava/lang/String;"), "org.mortbay.jetty.servlet.MaxAge");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f004___SessionCookieProperty(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/SessionManager;","__SessionCookieProperty","Ljava/lang/String;"), "org.mortbay.jetty.servlet.SessionCookie");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f005___SessionDomainProperty(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/SessionManager;","__SessionDomainProperty","Ljava/lang/String;"), "org.mortbay.jetty.servlet.SessionDomain");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f006___SessionPathProperty(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/SessionManager;","__SessionPathProperty","Ljava/lang/String;"), "org.mortbay.jetty.servlet.SessionPath");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f007___SessionURLProperty(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/SessionManager;","__SessionURLProperty","Ljava/lang/String;"), "org.mortbay.jetty.servlet.SessionURL");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__clinit_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/SessionManager;","<clinit>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(64,L0);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/SessionManager;","__DefaultSessionDomain","Ljava/lang/String;"));
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001_access(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/jetty/SessionManager;","access",new String[]{ "Ljavax/servlet/http/HttpSession;","Z"},"Ljavax/servlet/http/Cookie;"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m002_addEventListener(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/jetty/SessionManager;","addEventListener",new String[]{ "Ljava/util/EventListener;"},"V"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m003_clearEventListeners(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/jetty/SessionManager;","clearEventListeners",new String[]{ },"V"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m004_complete(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/jetty/SessionManager;","complete",new String[]{ "Ljavax/servlet/http/HttpSession;"},"V"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m005_getClusterId(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/jetty/SessionManager;","getClusterId",new String[]{ "Ljavax/servlet/http/HttpSession;"},"Ljava/lang/String;"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m006_getHttpOnly(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/jetty/SessionManager;","getHttpOnly",new String[]{ },"Z"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m007_getHttpSession(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/jetty/SessionManager;","getHttpSession",new String[]{ "Ljava/lang/String;"},"Ljavax/servlet/http/HttpSession;"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m008_getIdManager(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/jetty/SessionManager;","getIdManager",new String[]{ },"Lorg/mortbay/jetty/SessionIdManager;"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m009_getMaxCookieAge(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/jetty/SessionManager;","getMaxCookieAge",new String[]{ },"I"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m010_getMaxInactiveInterval(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/jetty/SessionManager;","getMaxInactiveInterval",new String[]{ },"I"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m011_getMetaManager(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/jetty/SessionManager;","getMetaManager",new String[]{ },"Lorg/mortbay/jetty/SessionIdManager;"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m012_getNodeId(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/jetty/SessionManager;","getNodeId",new String[]{ "Ljavax/servlet/http/HttpSession;"},"Ljava/lang/String;"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m013_getSecureCookies(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/jetty/SessionManager;","getSecureCookies",new String[]{ },"Z"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m014_getSessionCookie(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/jetty/SessionManager;","getSessionCookie",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m015_getSessionCookie(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/jetty/SessionManager;","getSessionCookie",new String[]{ "Ljavax/servlet/http/HttpSession;","Ljava/lang/String;","Z"},"Ljavax/servlet/http/Cookie;"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m016_getSessionDomain(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/jetty/SessionManager;","getSessionDomain",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m017_getSessionPath(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/jetty/SessionManager;","getSessionPath",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m018_getSessionURL(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/jetty/SessionManager;","getSessionURL",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m019_getSessionURLPrefix(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/jetty/SessionManager;","getSessionURLPrefix",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m020_isUsingCookies(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/jetty/SessionManager;","isUsingCookies",new String[]{ },"Z"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m021_isValid(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/jetty/SessionManager;","isValid",new String[]{ "Ljavax/servlet/http/HttpSession;"},"Z"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m022_newHttpSession(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/jetty/SessionManager;","newHttpSession",new String[]{ "Ljavax/servlet/http/HttpServletRequest;"},"Ljavax/servlet/http/HttpSession;"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m023_removeEventListener(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/jetty/SessionManager;","removeEventListener",new String[]{ "Ljava/util/EventListener;"},"V"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m024_setIdManager(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/jetty/SessionManager;","setIdManager",new String[]{ "Lorg/mortbay/jetty/SessionIdManager;"},"V"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m025_setMaxCookieAge(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/jetty/SessionManager;","setMaxCookieAge",new String[]{ "I"},"V"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m026_setMaxInactiveInterval(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/jetty/SessionManager;","setMaxInactiveInterval",new String[]{ "I"},"V"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m027_setSessionCookie(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/jetty/SessionManager;","setSessionCookie",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m028_setSessionDomain(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/jetty/SessionManager;","setSessionDomain",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m029_setSessionHandler(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/jetty/SessionManager;","setSessionHandler",new String[]{ "Lorg/mortbay/jetty/servlet/SessionHandler;"},"V"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m030_setSessionPath(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/jetty/SessionManager;","setSessionPath",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m031_setSessionURL(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/jetty/SessionManager;","setSessionURL",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
}
