package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0155_org_mortbay_jetty_HttpConnection {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/jetty/HttpConnection;","Ljava/lang/Object;",new String[]{ "Lorg/mortbay/io/Connection;"});
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("HttpConnection.java");
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/MemberClasses;", Visibility.SYSTEM);
            if(av00 != null) {
                {
                    DexAnnotationVisitor av01 = av00.visitArray("value");
                    if(av01 != null) {
                        av01.visit(null, new DexType("Lorg/mortbay/jetty/HttpConnection$OutputWriter;"));
                        av01.visit(null, new DexType("Lorg/mortbay/jetty/HttpConnection$Output;"));
                        av01.visit(null, new DexType("Lorg/mortbay/jetty/HttpConnection$RequestHandler;"));
                        av01.visitEnd();
                    }
                }
                av00.visitEnd();
            }
        }
        f000_UNKNOWN(cv);
        f001___currentConnection(cv);
        f002__associatedObject(cv);
        f003__connector(cv);
        f004__delayedHandling(cv);
        f005__destroy(cv);
        f006__endp(cv);
        f007__expect(cv);
        f008__generator(cv);
        f009__handling(cv);
        f010__head(cv);
        f011__host(cv);
        f012__in(cv);
        f013__include(cv);
        f014__out(cv);
        f015__parser(cv);
        f016__printWriter(cv);
        f017__request(cv);
        f018__requestFields(cv);
        f019__requests(cv);
        f020__response(cv);
        f021__responseFields(cv);
        f022__server(cv);
        f023__timeStamp(cv);
        f024__uri(cv);
        f025__version(cv);
        f026__writer(cv);
        m000__clinit_(cv);
        m001__init_(cv);
        m002__init_(cv);
        m003_access$100(cv);
        m004_access$102(cv);
        m005_access$200(cv);
        m006_access$202(cv);
        m007_access$300(cv);
        m008_access$400(cv);
        m009_access$402(cv);
        m010_access$500(cv);
        m011_access$502(cv);
        m012_access$600(cv);
        m013_access$602(cv);
        m014_access$708(cv);
        m015_getCurrentConnection(cv);
        m016_setCurrentConnection(cv);
        m017_commitResponse(cv);
        m018_completeResponse(cv);
        m019_destroy(cv);
        m020_flushResponse(cv);
        m021_getAssociatedObject(cv);
        m022_getConnector(cv);
        m023_getEndPoint(cv);
        m024_getGenerator(cv);
        m025_getInputStream(cv);
        m026_getOutputStream(cv);
        m027_getParser(cv);
        m028_getPrintWriter(cv);
        m029_getRequest(cv);
        m030_getRequestFields(cv);
        m031_getRequests(cv);
        m032_getResolveNames(cv);
        m033_getResponse(cv);
        m034_getResponseFields(cv);
        m035_getTimeStamp(cv);
        m036_handle(cv);
        m037_handleRequest(cv);
        m038_include(cv);
        m039_included(cv);
        m040_isConfidential(cv);
        m041_isIdle(cv);
        m042_isIncluding(cv);
        m043_isIntegral(cv);
        m044_isResponseCommitted(cv);
        m045_reset(cv);
        m046_setAssociatedObject(cv);
    }
    public static void f000_UNKNOWN(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC, new Field("Lorg/mortbay/jetty/HttpConnection;","UNKNOWN","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001___currentConnection(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC, new Field("Lorg/mortbay/jetty/HttpConnection;","__currentConnection","Ljava/lang/ThreadLocal;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002__associatedObject(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/HttpConnection;","_associatedObject","Ljava/lang/Object;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003__connector(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpConnection;","_connector","Lorg/mortbay/jetty/Connector;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f004__delayedHandling(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_TRANSIENT, new Field("Lorg/mortbay/jetty/HttpConnection;","_delayedHandling","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f005__destroy(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/HttpConnection;","_destroy","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f006__endp(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpConnection;","_endp","Lorg/mortbay/io/EndPoint;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f007__expect(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_TRANSIENT, new Field("Lorg/mortbay/jetty/HttpConnection;","_expect","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f008__generator(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpConnection;","_generator","Lorg/mortbay/jetty/Generator;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f009__handling(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/HttpConnection;","_handling","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f010__head(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_TRANSIENT, new Field("Lorg/mortbay/jetty/HttpConnection;","_head","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f011__host(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_TRANSIENT, new Field("Lorg/mortbay/jetty/HttpConnection;","_host","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f012__in(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/jetty/HttpConnection;","_in","Ljavax/servlet/ServletInputStream;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f013__include(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/jetty/HttpConnection;","_include","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f014__out(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/jetty/HttpConnection;","_out","Lorg/mortbay/jetty/HttpConnection$Output;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f015__parser(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpConnection;","_parser","Lorg/mortbay/jetty/Parser;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f016__printWriter(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/jetty/HttpConnection;","_printWriter","Ljava/io/PrintWriter;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f017__request(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpConnection;","_request","Lorg/mortbay/jetty/Request;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f018__requestFields(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpConnection;","_requestFields","Lorg/mortbay/jetty/HttpFields;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f019__requests(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/HttpConnection;","_requests","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f020__response(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpConnection;","_response","Lorg/mortbay/jetty/Response;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f021__responseFields(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpConnection;","_responseFields","Lorg/mortbay/jetty/HttpFields;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f022__server(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpConnection;","_server","Lorg/mortbay/jetty/Server;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f023__timeStamp(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/HttpConnection;","_timeStamp","J"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f024__uri(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpConnection;","_uri","Lorg/mortbay/jetty/HttpURI;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f025__version(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_TRANSIENT, new Field("Lorg/mortbay/jetty/HttpConnection;","_version","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f026__writer(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/jetty/HttpConnection;","_writer","Lorg/mortbay/jetty/HttpConnection$OutputWriter;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__clinit_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/HttpConnection;","<clinit>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(59,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(60,L1);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(-2)); // int: 0xfffffffe  float:NaN
                code.visitFieldStmt(SPUT,0,-1,new Field("Lorg/mortbay/jetty/HttpConnection;","UNKNOWN","I"));
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/ThreadLocal;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/ThreadLocal;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpConnection;","__currentConnection","Ljava/lang/ThreadLocal;"));
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/HttpConnection;","<init>",new String[]{ "Lorg/mortbay/jetty/Connector;","Lorg/mortbay/io/EndPoint;","Lorg/mortbay/jetty/Server;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(10);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"connector");
                ddv.visitParameterName(1,"endpoint");
                ddv.visitParameterName(2,"server");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(112,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(62,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(88,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(89,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(90,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(91,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(92,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(113,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(114,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(115,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(116,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(117,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(118,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(119,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(120,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(121,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(122,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(123,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(124,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(113,L20);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 6},new Method("Ljava/lang/Object;","<init>",new String[]{ },"V"));
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Ljava/lang/System;","currentTimeMillis",new String[]{ },"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,0);
                code.visitFieldStmt(IPUT_WIDE,0,6,new Field("Lorg/mortbay/jetty/HttpConnection;","_timeStamp","J"));
                code.visitLabel(L3);
                code.visitFieldStmt(SGET,0,-1,new Field("Lorg/mortbay/jetty/HttpConnection;","UNKNOWN","I"));
                code.visitFieldStmt(IPUT,0,6,new Field("Lorg/mortbay/jetty/HttpConnection;","_expect","I"));
                code.visitLabel(L4);
                code.visitFieldStmt(SGET,0,-1,new Field("Lorg/mortbay/jetty/HttpConnection;","UNKNOWN","I"));
                code.visitFieldStmt(IPUT,0,6,new Field("Lorg/mortbay/jetty/HttpConnection;","_version","I"));
                code.visitLabel(L5);
                code.visitFieldStmt(IPUT_BOOLEAN,2,6,new Field("Lorg/mortbay/jetty/HttpConnection;","_head","Z"));
                code.visitLabel(L6);
                code.visitFieldStmt(IPUT_BOOLEAN,2,6,new Field("Lorg/mortbay/jetty/HttpConnection;","_host","Z"));
                code.visitLabel(L7);
                code.visitFieldStmt(IPUT_BOOLEAN,2,6,new Field("Lorg/mortbay/jetty/HttpConnection;","_delayedHandling","Z"));
                code.visitLabel(L8);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/util/URIUtil;","__CHARSET","Ljava/lang/String;"));
                code.visitConstStmt(CONST_STRING,1,"UTF-8");
                code.visitJumpStmt(IF_NE,0,1,L20);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/jetty/HttpURI;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Lorg/mortbay/jetty/HttpURI;","<init>",new String[]{ },"V"));
                DexLabel L21=new DexLabel();
                code.visitLabel(L21);
                code.visitFieldStmt(IPUT_OBJECT,0,6,new Field("Lorg/mortbay/jetty/HttpConnection;","_uri","Lorg/mortbay/jetty/HttpURI;"));
                code.visitLabel(L9);
                code.visitFieldStmt(IPUT_OBJECT,7,6,new Field("Lorg/mortbay/jetty/HttpConnection;","_connector","Lorg/mortbay/jetty/Connector;"));
                code.visitLabel(L10);
                code.visitFieldStmt(IPUT_OBJECT,8,6,new Field("Lorg/mortbay/jetty/HttpConnection;","_endp","Lorg/mortbay/io/EndPoint;"));
                code.visitLabel(L11);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/jetty/HttpParser;");
                code.visitFieldStmt(IGET_OBJECT,1,6,new Field("Lorg/mortbay/jetty/HttpConnection;","_connector","Lorg/mortbay/jetty/Connector;"));
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Lorg/mortbay/jetty/HttpConnection$RequestHandler;");
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3,6,2},new Method("Lorg/mortbay/jetty/HttpConnection$RequestHandler;","<init>",new String[]{ "Lorg/mortbay/jetty/HttpConnection;","Lorg/mortbay/jetty/HttpConnection$1;"},"V"));
                code.visitFieldStmt(IGET_OBJECT,2,6,new Field("Lorg/mortbay/jetty/HttpConnection;","_connector","Lorg/mortbay/jetty/Connector;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2},new Method("Lorg/mortbay/jetty/Connector;","getHeaderBufferSize",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitFieldStmt(IGET_OBJECT,2,6,new Field("Lorg/mortbay/jetty/HttpConnection;","_connector","Lorg/mortbay/jetty/Connector;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2},new Method("Lorg/mortbay/jetty/Connector;","getRequestBufferSize",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitStmt2R(MOVE_OBJECT,2,8);
                code.visitMethodStmt(INVOKE_DIRECT_RANGE,new int[]{ 0,1,2,3,4,5},new Method("Lorg/mortbay/jetty/HttpParser;","<init>",new String[]{ "Lorg/mortbay/io/Buffers;","Lorg/mortbay/io/EndPoint;","Lorg/mortbay/jetty/HttpParser$EventHandler;","I","I"},"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,6,new Field("Lorg/mortbay/jetty/HttpConnection;","_parser","Lorg/mortbay/jetty/Parser;"));
                code.visitLabel(L12);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/jetty/HttpFields;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Lorg/mortbay/jetty/HttpFields;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,6,new Field("Lorg/mortbay/jetty/HttpConnection;","_requestFields","Lorg/mortbay/jetty/HttpFields;"));
                code.visitLabel(L13);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/jetty/HttpFields;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Lorg/mortbay/jetty/HttpFields;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,6,new Field("Lorg/mortbay/jetty/HttpConnection;","_responseFields","Lorg/mortbay/jetty/HttpFields;"));
                code.visitLabel(L14);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/jetty/Request;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,6},new Method("Lorg/mortbay/jetty/Request;","<init>",new String[]{ "Lorg/mortbay/jetty/HttpConnection;"},"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,6,new Field("Lorg/mortbay/jetty/HttpConnection;","_request","Lorg/mortbay/jetty/Request;"));
                code.visitLabel(L15);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/jetty/Response;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,6},new Method("Lorg/mortbay/jetty/Response;","<init>",new String[]{ "Lorg/mortbay/jetty/HttpConnection;"},"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,6,new Field("Lorg/mortbay/jetty/HttpConnection;","_response","Lorg/mortbay/jetty/Response;"));
                code.visitLabel(L16);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/jetty/HttpGenerator;");
                code.visitFieldStmt(IGET_OBJECT,1,6,new Field("Lorg/mortbay/jetty/HttpConnection;","_connector","Lorg/mortbay/jetty/Connector;"));
                code.visitFieldStmt(IGET_OBJECT,2,6,new Field("Lorg/mortbay/jetty/HttpConnection;","_endp","Lorg/mortbay/io/EndPoint;"));
                code.visitFieldStmt(IGET_OBJECT,3,6,new Field("Lorg/mortbay/jetty/HttpConnection;","_connector","Lorg/mortbay/jetty/Connector;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3},new Method("Lorg/mortbay/jetty/Connector;","getHeaderBufferSize",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitFieldStmt(IGET_OBJECT,4,6,new Field("Lorg/mortbay/jetty/HttpConnection;","_connector","Lorg/mortbay/jetty/Connector;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 4},new Method("Lorg/mortbay/jetty/Connector;","getResponseBufferSize",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1,2,3,4},new Method("Lorg/mortbay/jetty/HttpGenerator;","<init>",new String[]{ "Lorg/mortbay/io/Buffers;","Lorg/mortbay/io/EndPoint;","I","I"},"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,6,new Field("Lorg/mortbay/jetty/HttpConnection;","_generator","Lorg/mortbay/jetty/Generator;"));
                code.visitLabel(L17);
                code.visitFieldStmt(IGET_OBJECT,0,6,new Field("Lorg/mortbay/jetty/HttpConnection;","_generator","Lorg/mortbay/jetty/Generator;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9},new Method("Lorg/mortbay/jetty/Server;","getSendServerVersion",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/Generator;","setSendServerVersion",new String[]{ "Z"},"V"));
                code.visitLabel(L18);
                code.visitFieldStmt(IPUT_OBJECT,9,6,new Field("Lorg/mortbay/jetty/HttpConnection;","_server","Lorg/mortbay/jetty/Server;"));
                code.visitLabel(L19);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L20);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/jetty/EncodedHttpURI;");
                code.visitFieldStmt(SGET_OBJECT,1,-1,new Field("Lorg/mortbay/util/URIUtil;","__CHARSET","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/EncodedHttpURI;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L21);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/HttpConnection;","<init>",new String[]{ "Lorg/mortbay/jetty/Connector;","Lorg/mortbay/io/EndPoint;","Lorg/mortbay/jetty/Server;","Lorg/mortbay/jetty/Parser;","Lorg/mortbay/jetty/Generator;","Lorg/mortbay/jetty/Request;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(10);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"connector");
                ddv.visitParameterName(1,"endpoint");
                ddv.visitParameterName(2,"server");
                ddv.visitParameterName(3,"parser");
                ddv.visitParameterName(4,"generator");
                ddv.visitParameterName(5,"request");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(128,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(62,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(88,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(89,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(90,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(91,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(92,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(129,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(130,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(131,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(132,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(133,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(134,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(135,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(136,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(137,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(138,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(139,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(140,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(129,L20);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3},new Method("Ljava/lang/Object;","<init>",new String[]{ },"V"));
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Ljava/lang/System;","currentTimeMillis",new String[]{ },"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,0);
                code.visitFieldStmt(IPUT_WIDE,0,3,new Field("Lorg/mortbay/jetty/HttpConnection;","_timeStamp","J"));
                code.visitLabel(L3);
                code.visitFieldStmt(SGET,0,-1,new Field("Lorg/mortbay/jetty/HttpConnection;","UNKNOWN","I"));
                code.visitFieldStmt(IPUT,0,3,new Field("Lorg/mortbay/jetty/HttpConnection;","_expect","I"));
                code.visitLabel(L4);
                code.visitFieldStmt(SGET,0,-1,new Field("Lorg/mortbay/jetty/HttpConnection;","UNKNOWN","I"));
                code.visitFieldStmt(IPUT,0,3,new Field("Lorg/mortbay/jetty/HttpConnection;","_version","I"));
                code.visitLabel(L5);
                code.visitFieldStmt(IPUT_BOOLEAN,2,3,new Field("Lorg/mortbay/jetty/HttpConnection;","_head","Z"));
                code.visitLabel(L6);
                code.visitFieldStmt(IPUT_BOOLEAN,2,3,new Field("Lorg/mortbay/jetty/HttpConnection;","_host","Z"));
                code.visitLabel(L7);
                code.visitFieldStmt(IPUT_BOOLEAN,2,3,new Field("Lorg/mortbay/jetty/HttpConnection;","_delayedHandling","Z"));
                code.visitLabel(L8);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/util/URIUtil;","__CHARSET","Ljava/lang/String;"));
                code.visitConstStmt(CONST_STRING,1,"UTF-8");
                code.visitJumpStmt(IF_NE,0,1,L20);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/jetty/HttpURI;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Lorg/mortbay/jetty/HttpURI;","<init>",new String[]{ },"V"));
                DexLabel L21=new DexLabel();
                code.visitLabel(L21);
                code.visitFieldStmt(IPUT_OBJECT,0,3,new Field("Lorg/mortbay/jetty/HttpConnection;","_uri","Lorg/mortbay/jetty/HttpURI;"));
                code.visitLabel(L9);
                code.visitFieldStmt(IPUT_OBJECT,4,3,new Field("Lorg/mortbay/jetty/HttpConnection;","_connector","Lorg/mortbay/jetty/Connector;"));
                code.visitLabel(L10);
                code.visitFieldStmt(IPUT_OBJECT,5,3,new Field("Lorg/mortbay/jetty/HttpConnection;","_endp","Lorg/mortbay/io/EndPoint;"));
                code.visitLabel(L11);
                code.visitFieldStmt(IPUT_OBJECT,7,3,new Field("Lorg/mortbay/jetty/HttpConnection;","_parser","Lorg/mortbay/jetty/Parser;"));
                code.visitLabel(L12);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/jetty/HttpFields;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Lorg/mortbay/jetty/HttpFields;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,3,new Field("Lorg/mortbay/jetty/HttpConnection;","_requestFields","Lorg/mortbay/jetty/HttpFields;"));
                code.visitLabel(L13);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/jetty/HttpFields;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Lorg/mortbay/jetty/HttpFields;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,3,new Field("Lorg/mortbay/jetty/HttpConnection;","_responseFields","Lorg/mortbay/jetty/HttpFields;"));
                code.visitLabel(L14);
                code.visitFieldStmt(IPUT_OBJECT,9,3,new Field("Lorg/mortbay/jetty/HttpConnection;","_request","Lorg/mortbay/jetty/Request;"));
                code.visitLabel(L15);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/jetty/Response;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,3},new Method("Lorg/mortbay/jetty/Response;","<init>",new String[]{ "Lorg/mortbay/jetty/HttpConnection;"},"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,3,new Field("Lorg/mortbay/jetty/HttpConnection;","_response","Lorg/mortbay/jetty/Response;"));
                code.visitLabel(L16);
                code.visitFieldStmt(IPUT_OBJECT,8,3,new Field("Lorg/mortbay/jetty/HttpConnection;","_generator","Lorg/mortbay/jetty/Generator;"));
                code.visitLabel(L17);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/jetty/HttpConnection;","_generator","Lorg/mortbay/jetty/Generator;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/Server;","getSendServerVersion",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/Generator;","setSendServerVersion",new String[]{ "Z"},"V"));
                code.visitLabel(L18);
                code.visitFieldStmt(IPUT_OBJECT,6,3,new Field("Lorg/mortbay/jetty/HttpConnection;","_server","Lorg/mortbay/jetty/Server;"));
                code.visitLabel(L19);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L20);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/jetty/EncodedHttpURI;");
                code.visitFieldStmt(SGET_OBJECT,1,-1,new Field("Lorg/mortbay/util/URIUtil;","__CHARSET","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/EncodedHttpURI;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L21);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_access$100(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_SYNTHETIC, new Method("Lorg/mortbay/jetty/HttpConnection;","access$100",new String[]{ "Lorg/mortbay/jetty/HttpConnection;"},"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"x0");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(57,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_BOOLEAN,0,1,new Field("Lorg/mortbay/jetty/HttpConnection;","_host","Z"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_access$102(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_SYNTHETIC, new Method("Lorg/mortbay/jetty/HttpConnection;","access$102",new String[]{ "Lorg/mortbay/jetty/HttpConnection;","Z"},"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"x0");
                ddv.visitParameterName(1,"x1");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(57,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_BOOLEAN,1,0,new Field("Lorg/mortbay/jetty/HttpConnection;","_host","Z"));
                code.visitStmt1R(RETURN,1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_access$200(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_SYNTHETIC, new Method("Lorg/mortbay/jetty/HttpConnection;","access$200",new String[]{ "Lorg/mortbay/jetty/HttpConnection;"},"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"x0");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(57,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,1,new Field("Lorg/mortbay/jetty/HttpConnection;","_expect","I"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_access$202(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_SYNTHETIC, new Method("Lorg/mortbay/jetty/HttpConnection;","access$202",new String[]{ "Lorg/mortbay/jetty/HttpConnection;","I"},"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"x0");
                ddv.visitParameterName(1,"x1");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(57,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT,1,0,new Field("Lorg/mortbay/jetty/HttpConnection;","_expect","I"));
                code.visitStmt1R(RETURN,1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m007_access$300(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_SYNTHETIC, new Method("Lorg/mortbay/jetty/HttpConnection;","access$300",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(57,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(SGET,0,-1,new Field("Lorg/mortbay/jetty/HttpConnection;","UNKNOWN","I"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m008_access$400(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_SYNTHETIC, new Method("Lorg/mortbay/jetty/HttpConnection;","access$400",new String[]{ "Lorg/mortbay/jetty/HttpConnection;"},"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"x0");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(57,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_BOOLEAN,0,1,new Field("Lorg/mortbay/jetty/HttpConnection;","_delayedHandling","Z"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m009_access$402(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_SYNTHETIC, new Method("Lorg/mortbay/jetty/HttpConnection;","access$402",new String[]{ "Lorg/mortbay/jetty/HttpConnection;","Z"},"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"x0");
                ddv.visitParameterName(1,"x1");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(57,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_BOOLEAN,1,0,new Field("Lorg/mortbay/jetty/HttpConnection;","_delayedHandling","Z"));
                code.visitStmt1R(RETURN,1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m010_access$500(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_SYNTHETIC, new Method("Lorg/mortbay/jetty/HttpConnection;","access$500",new String[]{ "Lorg/mortbay/jetty/HttpConnection;"},"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"x0");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(57,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,1,new Field("Lorg/mortbay/jetty/HttpConnection;","_version","I"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m011_access$502(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_SYNTHETIC, new Method("Lorg/mortbay/jetty/HttpConnection;","access$502",new String[]{ "Lorg/mortbay/jetty/HttpConnection;","I"},"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"x0");
                ddv.visitParameterName(1,"x1");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(57,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT,1,0,new Field("Lorg/mortbay/jetty/HttpConnection;","_version","I"));
                code.visitStmt1R(RETURN,1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m012_access$600(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_SYNTHETIC, new Method("Lorg/mortbay/jetty/HttpConnection;","access$600",new String[]{ "Lorg/mortbay/jetty/HttpConnection;"},"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"x0");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(57,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_BOOLEAN,0,1,new Field("Lorg/mortbay/jetty/HttpConnection;","_head","Z"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m013_access$602(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_SYNTHETIC, new Method("Lorg/mortbay/jetty/HttpConnection;","access$602",new String[]{ "Lorg/mortbay/jetty/HttpConnection;","Z"},"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"x0");
                ddv.visitParameterName(1,"x1");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(57,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_BOOLEAN,1,0,new Field("Lorg/mortbay/jetty/HttpConnection;","_head","Z"));
                code.visitStmt1R(RETURN,1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m014_access$708(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_SYNTHETIC, new Method("Lorg/mortbay/jetty/HttpConnection;","access$708",new String[]{ "Lorg/mortbay/jetty/HttpConnection;"},"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"x0");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(57,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,2,new Field("Lorg/mortbay/jetty/HttpConnection;","_requests","I"));
                code.visitStmt2R1N(ADD_INT_LIT8,1,0,1);
                code.visitFieldStmt(IPUT,1,2,new Field("Lorg/mortbay/jetty/HttpConnection;","_requests","I"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m015_getCurrentConnection(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/jetty/HttpConnection;","getCurrentConnection",new String[]{ },"Lorg/mortbay/jetty/HttpConnection;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(97,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpConnection;","__currentConnection","Ljava/lang/ThreadLocal;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/ThreadLocal;","get",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Lorg/mortbay/jetty/HttpConnection;");
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m016_setCurrentConnection(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED|ACC_STATIC, new Method("Lorg/mortbay/jetty/HttpConnection;","setCurrentConnection",new String[]{ "Lorg/mortbay/jetty/HttpConnection;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"connection");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(103,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(104,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpConnection;","__currentConnection","Ljava/lang/ThreadLocal;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/ThreadLocal;","set",new String[]{ "Ljava/lang/Object;"},"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m017_commitResponse(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpConnection;","commitResponse",new String[]{ "Z"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"last");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(608,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(610,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(611,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(613,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(614,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(615,L5);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/jetty/HttpConnection;","_generator","Lorg/mortbay/jetty/Generator;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Lorg/mortbay/jetty/Generator;","isCommitted",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_NEZ,0,-1,L3);
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/jetty/HttpConnection;","_generator","Lorg/mortbay/jetty/Generator;"));
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/jetty/HttpConnection;","_response","Lorg/mortbay/jetty/Response;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/jetty/Response;","getStatus",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitFieldStmt(IGET_OBJECT,2,3,new Field("Lorg/mortbay/jetty/HttpConnection;","_response","Lorg/mortbay/jetty/Response;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/Response;","getReason",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1,2},new Method("Lorg/mortbay/jetty/Generator;","setResponse",new String[]{ "I","Ljava/lang/String;"},"V"));
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/jetty/HttpConnection;","_generator","Lorg/mortbay/jetty/Generator;"));
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/jetty/HttpConnection;","_responseFields","Lorg/mortbay/jetty/HttpFields;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1,4},new Method("Lorg/mortbay/jetty/Generator;","completeHeader",new String[]{ "Lorg/mortbay/jetty/HttpFields;","Z"},"V"));
                code.visitLabel(L3);
                code.visitJumpStmt(IF_EQZ,4,-1,L5);
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/jetty/HttpConnection;","_generator","Lorg/mortbay/jetty/Generator;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Lorg/mortbay/jetty/Generator;","complete",new String[]{ },"V"));
                code.visitLabel(L5);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m018_completeResponse(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpConnection;","completeResponse",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(620,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(622,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(623,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(626,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(627,L4);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/jetty/HttpConnection;","_generator","Lorg/mortbay/jetty/Generator;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Lorg/mortbay/jetty/Generator;","isCommitted",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_NEZ,0,-1,L3);
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/jetty/HttpConnection;","_generator","Lorg/mortbay/jetty/Generator;"));
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/jetty/HttpConnection;","_response","Lorg/mortbay/jetty/Response;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/jetty/Response;","getStatus",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitFieldStmt(IGET_OBJECT,2,3,new Field("Lorg/mortbay/jetty/HttpConnection;","_response","Lorg/mortbay/jetty/Response;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/Response;","getReason",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1,2},new Method("Lorg/mortbay/jetty/Generator;","setResponse",new String[]{ "I","Ljava/lang/String;"},"V"));
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/jetty/HttpConnection;","_generator","Lorg/mortbay/jetty/Generator;"));
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/jetty/HttpConnection;","_responseFields","Lorg/mortbay/jetty/HttpFields;"));
                code.visitConstStmt(CONST_4,2, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1,2},new Method("Lorg/mortbay/jetty/Generator;","completeHeader",new String[]{ "Lorg/mortbay/jetty/HttpFields;","Z"},"V"));
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/jetty/HttpConnection;","_generator","Lorg/mortbay/jetty/Generator;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Lorg/mortbay/jetty/Generator;","complete",new String[]{ },"V"));
                code.visitLabel(L4);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m019_destroy(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpConnection;","destroy",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(145,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(147,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(148,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(150,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(151,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(153,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(154,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(156,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(157,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(159,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(160,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(163,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(164,L15);
                ddv.visitLineNumber(163,L2);
                code.visitLabel(L3);
                code.visitStmt1R(MONITOR_ENTER,2);
                code.visitLabel(L4);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_BOOLEAN,0,2,new Field("Lorg/mortbay/jetty/HttpConnection;","_destroy","Z"));
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_BOOLEAN,0,2,new Field("Lorg/mortbay/jetty/HttpConnection;","_handling","Z"));
                code.visitJumpStmt(IF_NEZ,0,-1,L14);
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/HttpConnection;","_parser","Lorg/mortbay/jetty/Parser;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L8);
                code.visitLabel(L7);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/HttpConnection;","_parser","Lorg/mortbay/jetty/Parser;"));
                code.visitConstStmt(CONST_4,1, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/Parser;","reset",new String[]{ "Z"},"V"));
                code.visitLabel(L8);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/HttpConnection;","_generator","Lorg/mortbay/jetty/Generator;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L10);
                code.visitLabel(L9);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/HttpConnection;","_generator","Lorg/mortbay/jetty/Generator;"));
                code.visitConstStmt(CONST_4,1, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/Generator;","reset",new String[]{ "Z"},"V"));
                code.visitLabel(L10);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/HttpConnection;","_requestFields","Lorg/mortbay/jetty/HttpFields;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L12);
                code.visitLabel(L11);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/HttpConnection;","_requestFields","Lorg/mortbay/jetty/HttpFields;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/HttpFields;","destroy",new String[]{ },"V"));
                code.visitLabel(L12);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/HttpConnection;","_responseFields","Lorg/mortbay/jetty/HttpFields;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L14);
                code.visitLabel(L13);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/HttpConnection;","_responseFields","Lorg/mortbay/jetty/HttpFields;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/HttpFields;","destroy",new String[]{ },"V"));
                code.visitLabel(L14);
                code.visitStmt1R(MONITOR_EXIT,2);
                code.visitLabel(L15);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,0);
                code.visitStmt1R(MONITOR_EXIT,2);
                code.visitLabel(L1);
                code.visitStmt1R(THROW,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m020_flushResponse(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpConnection;","flushResponse",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/io/IOException;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(634,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(635,L4);
                ddv.visitLineNumber(641,L1);
                ddv.visitLineNumber(637,L2);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(639,L5);
                ddv.visitStartLocal(0,L5,"e","Ljava/io/IOException;",null);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,1},new Method("Lorg/mortbay/jetty/HttpConnection;","commitResponse",new String[]{ "Z"},"V"));
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/HttpConnection;","_generator","Lorg/mortbay/jetty/Generator;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Lorg/mortbay/jetty/Generator;","flush",new String[]{ },"J"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitStmt2R(MOVE_OBJECT,0,1);
                code.visitLabel(L5);
                code.visitTypeStmt(INSTANCE_OF,1,0,"Lorg/mortbay/jetty/EofException;");
                DexLabel L6=new DexLabel();
                code.visitJumpStmt(IF_EQZ,1,-1,L6);
                code.visitStmt2R(MOVE_OBJECT,1,0);
                DexLabel L7=new DexLabel();
                code.visitLabel(L7);
                code.visitStmt1R(THROW,1);
                code.visitLabel(L6);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Lorg/mortbay/jetty/EofException;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,0},new Method("Lorg/mortbay/jetty/EofException;","<init>",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L7);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m021_getAssociatedObject(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpConnection;","getAssociatedObject",new String[]{ },"Ljava/lang/Object;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(199,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/HttpConnection;","_associatedObject","Ljava/lang/Object;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m022_getConnector(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpConnection;","getConnector",new String[]{ },"Lorg/mortbay/jetty/Connector;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(218,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/HttpConnection;","_connector","Lorg/mortbay/jetty/Connector;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m023_getEndPoint(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpConnection;","getEndPoint",new String[]{ },"Lorg/mortbay/io/EndPoint;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(274,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/HttpConnection;","_endp","Lorg/mortbay/io/EndPoint;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m024_getGenerator(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpConnection;","getGenerator",new String[]{ },"Lorg/mortbay/jetty/Generator;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(646,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/HttpConnection;","_generator","Lorg/mortbay/jetty/Generator;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m025_getInputStream(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpConnection;","getInputStream",new String[]{ },"Ljavax/servlet/ServletInputStream;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(311,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(312,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(313,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/jetty/HttpConnection;","_in","Ljavax/servlet/ServletInputStream;"));
                code.visitJumpStmt(IF_NEZ,0,-1,L2);
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Lorg/mortbay/jetty/HttpParser$Input;");
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/jetty/HttpConnection;","_parser","Lorg/mortbay/jetty/Parser;"));
                code.visitTypeStmt(CHECK_CAST,0,-1,"Lorg/mortbay/jetty/HttpParser;");
                code.visitFieldStmt(IGET_OBJECT,2,4,new Field("Lorg/mortbay/jetty/HttpConnection;","_connector","Lorg/mortbay/jetty/Connector;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2},new Method("Lorg/mortbay/jetty/Connector;","getMaxIdleTime",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitStmt2R(INT_TO_LONG,2,2);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,0,2,3},new Method("Lorg/mortbay/jetty/HttpParser$Input;","<init>",new String[]{ "Lorg/mortbay/jetty/HttpParser;","J"},"V"));
                code.visitFieldStmt(IPUT_OBJECT,1,4,new Field("Lorg/mortbay/jetty/HttpConnection;","_in","Ljavax/servlet/ServletInputStream;"));
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/jetty/HttpConnection;","_in","Ljavax/servlet/ServletInputStream;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m026_getOutputStream(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpConnection;","getOutputStream",new String[]{ },"Ljavax/servlet/ServletOutputStream;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(323,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(324,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(325,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/HttpConnection;","_out","Lorg/mortbay/jetty/HttpConnection$Output;"));
                code.visitJumpStmt(IF_NEZ,0,-1,L2);
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/jetty/HttpConnection$Output;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/HttpConnection$Output;","<init>",new String[]{ "Lorg/mortbay/jetty/HttpConnection;"},"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/HttpConnection;","_out","Lorg/mortbay/jetty/HttpConnection$Output;"));
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/HttpConnection;","_out","Lorg/mortbay/jetty/HttpConnection$Output;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m027_getParser(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpConnection;","getParser",new String[]{ },"Lorg/mortbay/jetty/Parser;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(172,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/HttpConnection;","_parser","Lorg/mortbay/jetty/Parser;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m028_getPrintWriter(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpConnection;","getPrintWriter",new String[]{ "Ljava/lang/String;"},"Ljava/io/PrintWriter;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"encoding");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(335,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(336,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(338,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(339,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(360,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(361,L5);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/HttpConnection;","getOutputStream",new String[]{ },"Ljavax/servlet/ServletOutputStream;"));
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/HttpConnection;","_writer","Lorg/mortbay/jetty/HttpConnection$OutputWriter;"));
                code.visitJumpStmt(IF_NEZ,0,-1,L4);
                code.visitLabel(L2);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/jetty/HttpConnection$OutputWriter;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,2},new Method("Lorg/mortbay/jetty/HttpConnection$OutputWriter;","<init>",new String[]{ "Lorg/mortbay/jetty/HttpConnection;"},"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/jetty/HttpConnection;","_writer","Lorg/mortbay/jetty/HttpConnection$OutputWriter;"));
                code.visitLabel(L3);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/jetty/HttpConnection$1;");
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/HttpConnection;","_writer","Lorg/mortbay/jetty/HttpConnection$OutputWriter;"));
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,2,1},new Method("Lorg/mortbay/jetty/HttpConnection$1;","<init>",new String[]{ "Lorg/mortbay/jetty/HttpConnection;","Ljava/io/Writer;"},"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/jetty/HttpConnection;","_printWriter","Ljava/io/PrintWriter;"));
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/HttpConnection;","_writer","Lorg/mortbay/jetty/HttpConnection$OutputWriter;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,3},new Method("Lorg/mortbay/jetty/HttpConnection$OutputWriter;","setCharacterEncoding",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/HttpConnection;","_printWriter","Ljava/io/PrintWriter;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m029_getRequest(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpConnection;","getRequest",new String[]{ },"Lorg/mortbay/jetty/Request;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(292,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/HttpConnection;","_request","Lorg/mortbay/jetty/Request;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m030_getRequestFields(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpConnection;","getRequestFields",new String[]{ },"Lorg/mortbay/jetty/HttpFields;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(227,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/HttpConnection;","_requestFields","Lorg/mortbay/jetty/HttpFields;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m031_getRequests(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpConnection;","getRequests",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(181,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,1,new Field("Lorg/mortbay/jetty/HttpConnection;","_requests","I"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m032_getResolveNames(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpConnection;","getResolveNames",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(283,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/HttpConnection;","_connector","Lorg/mortbay/jetty/Connector;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Lorg/mortbay/jetty/Connector;","getResolveNames",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m033_getResponse(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpConnection;","getResponse",new String[]{ },"Lorg/mortbay/jetty/Response;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(301,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/HttpConnection;","_response","Lorg/mortbay/jetty/Response;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m034_getResponseFields(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpConnection;","getResponseFields",new String[]{ },"Lorg/mortbay/jetty/HttpFields;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(236,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/HttpConnection;","_responseFields","Lorg/mortbay/jetty/HttpFields;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m035_getTimeStamp(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpConnection;","getTimeStamp",new String[]{ },"J"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(190,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_WIDE,0,2,new Field("Lorg/mortbay/jetty/HttpConnection;","_timeStamp","J"));
                code.visitStmt1R(RETURN_WIDE,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m036_handle(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpConnection;","handle",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(15);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                DexLabel L3=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2,L3},new String[]{ "Lorg/mortbay/jetty/HttpException;",null});
                DexLabel L4=new DexLabel();
                DexLabel L5=new DexLabel();
                code.visitTryCatch(L1,L4,new DexLabel[]{L5},new String[]{ null});
                code.visitTryCatch(L4,L2,new DexLabel[]{L2,L3},new String[]{ "Lorg/mortbay/jetty/HttpException;",null});
                DexLabel L6=new DexLabel();
                code.visitTryCatch(L6,L3,new DexLabel[]{L3},new String[]{ null});
                DexLabel L7=new DexLabel();
                DexLabel L8=new DexLabel();
                DexLabel L9=new DexLabel();
                code.visitTryCatch(L7,L8,new DexLabel[]{L9},new String[]{ null});
                DexLabel L10=new DexLabel();
                DexLabel L11=new DexLabel();
                code.visitTryCatch(L10,L11,new DexLabel[]{L5},new String[]{ null});
                DexLabel L12=new DexLabel();
                code.visitTryCatch(L11,L12,new DexLabel[]{L2,L3},new String[]{ "Lorg/mortbay/jetty/HttpException;",null});
                DexLabel L13=new DexLabel();
                DexLabel L14=new DexLabel();
                DexLabel L15=new DexLabel();
                code.visitTryCatch(L13,L14,new DexLabel[]{L15},new String[]{ null});
                DexLabel L16=new DexLabel();
                DexLabel L17=new DexLabel();
                code.visitTryCatch(L16,L17,new DexLabel[]{L2,L3},new String[]{ "Lorg/mortbay/jetty/HttpException;",null});
                DexLabel L18=new DexLabel();
                DexLabel L19=new DexLabel();
                DexLabel L20=new DexLabel();
                code.visitTryCatch(L18,L19,new DexLabel[]{L20},new String[]{ null});
                DexLabel L21=new DexLabel();
                DexLabel L22=new DexLabel();
                code.visitTryCatch(L21,L22,new DexLabel[]{L9},new String[]{ null});
                DexLabel L23=new DexLabel();
                DexLabel L24=new DexLabel();
                code.visitTryCatch(L23,L24,new DexLabel[]{L9},new String[]{ null});
                DexLabel L25=new DexLabel();
                DexLabel L26=new DexLabel();
                code.visitTryCatch(L25,L26,new DexLabel[]{L15},new String[]{ null});
                DexLabel L27=new DexLabel();
                DexLabel L28=new DexLabel();
                code.visitTryCatch(L27,L28,new DexLabel[]{L20},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L29=new DexLabel();
                ddv.visitPrologue(L29);
                ddv.visitLineNumber(374,L29);
                DexLabel L30=new DexLabel();
                ddv.visitLineNumber(375,L30);
                ddv.visitStartLocal(4,L30,"more_in_buffer","Z",null);
                DexLabel L31=new DexLabel();
                ddv.visitLineNumber(377,L31);
                ddv.visitStartLocal(5,L31,"no_progress","I",null);
                ddv.visitLineNumber(381,L0);
                ddv.visitLineNumber(383,L1);
                DexLabel L32=new DexLabel();
                ddv.visitLineNumber(384,L32);
                ddv.visitLineNumber(387,L5);
                ddv.visitLineNumber(435,L2);
                ddv.visitLineNumber(437,L6);
                ddv.visitStartLocal(1,L6,"e","Lorg/mortbay/jetty/HttpException;",null);
                DexLabel L33=new DexLabel();
                ddv.visitLineNumber(439,L33);
                DexLabel L34=new DexLabel();
                ddv.visitLineNumber(440,L34);
                DexLabel L35=new DexLabel();
                ddv.visitLineNumber(441,L35);
                DexLabel L36=new DexLabel();
                ddv.visitLineNumber(443,L36);
                DexLabel L37=new DexLabel();
                ddv.visitLineNumber(445,L37);
                DexLabel L38=new DexLabel();
                ddv.visitLineNumber(446,L38);
                DexLabel L39=new DexLabel();
                ddv.visitLineNumber(447,L39);
                ddv.visitLineNumber(451,L3);
                ddv.visitEndLocal(1,L3);
                DexLabel L40=new DexLabel();
                ddv.visitLineNumber(453,L40);
                DexLabel L41=new DexLabel();
                ddv.visitLineNumber(455,L41);
                DexLabel L42=new DexLabel();
                ddv.visitLineNumber(457,L42);
                DexLabel L43=new DexLabel();
                ddv.visitLineNumber(459,L43);
                DexLabel L44=new DexLabel();
                ddv.visitLineNumber(461,L44);
                DexLabel L45=new DexLabel();
                ddv.visitLineNumber(462,L45);
                ddv.visitLineNumber(490,L8);
                ddv.visitEndLocal(14,L8);
                DexLabel L46=new DexLabel();
                ddv.visitLineNumber(386,L46);
                ddv.visitRestartLocal(14,L46);
                DexLabel L47=new DexLabel();
                ddv.visitLineNumber(387,L47);
                ddv.visitLineNumber(389,L11);
                DexLabel L48=new DexLabel();
                ddv.visitLineNumber(390,L48);
                DexLabel L49=new DexLabel();
                ddv.visitLineNumber(392,L49);
                ddv.visitStartLocal(2,L49,"io","J",null);
                DexLabel L50=new DexLabel();
                ddv.visitLineNumber(393,L50);
                ddv.visitStartLocal(0,L50,"continuation","Lorg/mortbay/util/ajax/Continuation;",null);
                DexLabel L51=new DexLabel();
                ddv.visitLineNumber(395,L51);
                DexLabel L52=new DexLabel();
                ddv.visitLineNumber(396,L52);
                DexLabel L53=new DexLabel();
                ddv.visitLineNumber(397,L53);
                DexLabel L54=new DexLabel();
                ddv.visitLineNumber(398,L54);
                ddv.visitLineNumber(451,L12);
                DexLabel L55=new DexLabel();
                ddv.visitLineNumber(453,L55);
                DexLabel L56=new DexLabel();
                ddv.visitLineNumber(455,L56);
                ddv.visitRestartLocal(4,L56);
                DexLabel L57=new DexLabel();
                ddv.visitLineNumber(457,L57);
                DexLabel L58=new DexLabel();
                ddv.visitLineNumber(459,L58);
                DexLabel L59=new DexLabel();
                ddv.visitLineNumber(461,L59);
                DexLabel L60=new DexLabel();
                ddv.visitLineNumber(462,L60);
                ddv.visitLineNumber(464,L15);
                ddv.visitLineNumber(403,L16);
                DexLabel L61=new DexLabel();
                ddv.visitLineNumber(404,L61);
                DexLabel L62=new DexLabel();
                ddv.visitLineNumber(411,L62);
                DexLabel L63=new DexLabel();
                ddv.visitLineNumber(413,L63);
                DexLabel L64=new DexLabel();
                ddv.visitLineNumber(414,L64);
                ddv.visitStartLocal(7,L64,"written","J",null);
                DexLabel L65=new DexLabel();
                ddv.visitLineNumber(415,L65);
                DexLabel L66=new DexLabel();
                ddv.visitLineNumber(422,L66);
                ddv.visitEndLocal(7,L66);
                DexLabel L67=new DexLabel();
                ddv.visitLineNumber(424,L67);
                DexLabel L68=new DexLabel();
                ddv.visitLineNumber(425,L68);
                DexLabel L69=new DexLabel();
                ddv.visitLineNumber(426,L69);
                DexLabel L70=new DexLabel();
                ddv.visitLineNumber(429,L70);
                ddv.visitEndLocal(5,L70);
                ddv.visitStartLocal(6,L70,"no_progress","I",null);
                DexLabel L71=new DexLabel();
                ddv.visitLineNumber(430,L71);
                DexLabel L72=new DexLabel();
                ddv.visitRestartLocal(5,L72);
                DexLabel L73=new DexLabel();
                ddv.visitLineNumber(417,L73);
                ddv.visitEndLocal(6,L73);
                ddv.visitRestartLocal(7,L73);
                DexLabel L74=new DexLabel();
                ddv.visitLineNumber(418,L74);
                DexLabel L75=new DexLabel();
                ddv.visitLineNumber(431,L75);
                ddv.visitEndLocal(5,L75);
                ddv.visitEndLocal(7,L75);
                ddv.visitRestartLocal(6,L75);
                DexLabel L76=new DexLabel();
                ddv.visitRestartLocal(5,L76);
                DexLabel L77=new DexLabel();
                ddv.visitLineNumber(451,L77);
                ddv.visitEndLocal(6,L77);
                DexLabel L78=new DexLabel();
                ddv.visitLineNumber(453,L78);
                DexLabel L79=new DexLabel();
                ddv.visitLineNumber(455,L79);
                ddv.visitRestartLocal(4,L79);
                DexLabel L80=new DexLabel();
                ddv.visitLineNumber(457,L80);
                DexLabel L81=new DexLabel();
                ddv.visitLineNumber(459,L81);
                DexLabel L82=new DexLabel();
                ddv.visitLineNumber(461,L82);
                DexLabel L83=new DexLabel();
                ddv.visitLineNumber(462,L83);
                ddv.visitLineNumber(464,L20);
                DexLabel L84=new DexLabel();
                ddv.visitLineNumber(483,L84);
                ddv.visitEndLocal(2,L84);
                DexLabel L85=new DexLabel();
                ddv.visitLineNumber(487,L85);
                DexLabel L86=new DexLabel();
                ddv.visitEndLocal(14,L86);
                DexLabel L87=new DexLabel();
                ddv.visitLineNumber(451,L87);
                ddv.visitLineNumber(464,L9);
                ddv.visitEndLocal(0,L9);
                ddv.visitRestartLocal(14,L9);
                DexLabel L88=new DexLabel();
                ddv.visitLineNumber(453,L88);
                ddv.visitLineNumber(464,L23);
                ddv.visitLineNumber(466,L24);
                DexLabel L89=new DexLabel();
                ddv.visitLineNumber(468,L89);
                DexLabel L90=new DexLabel();
                ddv.visitLineNumber(470,L90);
                DexLabel L91=new DexLabel();
                ddv.visitLineNumber(471,L91);
                DexLabel L92=new DexLabel();
                ddv.visitLineNumber(474,L92);
                DexLabel L93=new DexLabel();
                ddv.visitLineNumber(475,L93);
                DexLabel L94=new DexLabel();
                ddv.visitLineNumber(478,L94);
                DexLabel L95=new DexLabel();
                ddv.visitLineNumber(479,L95);
                ddv.visitRestartLocal(0,L95);
                DexLabel L96=new DexLabel();
                ddv.visitLineNumber(474,L96);
                ddv.visitEndLocal(0,L96);
                DexLabel L97=new DexLabel();
                ddv.visitLineNumber(453,L97);
                ddv.visitRestartLocal(0,L97);
                ddv.visitRestartLocal(2,L97);
                ddv.visitLineNumber(464,L25);
                ddv.visitLineNumber(466,L26);
                DexLabel L98=new DexLabel();
                ddv.visitLineNumber(468,L98);
                DexLabel L99=new DexLabel();
                ddv.visitLineNumber(470,L99);
                DexLabel L100=new DexLabel();
                ddv.visitLineNumber(471,L100);
                DexLabel L101=new DexLabel();
                ddv.visitLineNumber(474,L101);
                DexLabel L102=new DexLabel();
                ddv.visitLineNumber(475,L102);
                DexLabel L103=new DexLabel();
                ddv.visitLineNumber(478,L103);
                DexLabel L104=new DexLabel();
                ddv.visitLineNumber(479,L104);
                ddv.visitRestartLocal(0,L104);
                DexLabel L105=new DexLabel();
                ddv.visitLineNumber(483,L105);
                DexLabel L106=new DexLabel();
                ddv.visitLineNumber(487,L106);
                DexLabel L107=new DexLabel();
                ddv.visitEndLocal(0,L107);
                DexLabel L108=new DexLabel();
                ddv.visitLineNumber(474,L108);
                ddv.visitRestartLocal(0,L108);
                DexLabel L109=new DexLabel();
                ddv.visitLineNumber(453,L109);
                ddv.visitLineNumber(464,L27);
                ddv.visitLineNumber(466,L28);
                DexLabel L110=new DexLabel();
                ddv.visitLineNumber(468,L110);
                DexLabel L111=new DexLabel();
                ddv.visitLineNumber(470,L111);
                DexLabel L112=new DexLabel();
                ddv.visitLineNumber(471,L112);
                DexLabel L113=new DexLabel();
                ddv.visitLineNumber(474,L113);
                DexLabel L114=new DexLabel();
                ddv.visitLineNumber(475,L114);
                DexLabel L115=new DexLabel();
                ddv.visitLineNumber(478,L115);
                DexLabel L116=new DexLabel();
                ddv.visitLineNumber(479,L116);
                ddv.visitRestartLocal(0,L116);
                DexLabel L117=new DexLabel();
                ddv.visitLineNumber(483,L117);
                DexLabel L118=new DexLabel();
                ddv.visitLineNumber(487,L118);
                DexLabel L119=new DexLabel();
                ddv.visitEndLocal(14,L119);
                DexLabel L120=new DexLabel();
                ddv.visitLineNumber(474,L120);
                ddv.visitRestartLocal(14,L120);
                DexLabel L121=new DexLabel();
                ddv.visitRestartLocal(6,L121);
                code.visitLabel(L29);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L30);
                code.visitConstStmt(CONST_4,5, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L31);
                code.visitJumpStmt(IF_EQZ,4,-1,L8);
                code.visitLabel(L0);
                code.visitStmt1R(MONITOR_ENTER,14);
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_BOOLEAN,9,14,new Field("Lorg/mortbay/jetty/HttpConnection;","_handling","Z"));
                code.visitJumpStmt(IF_EQZ,9,-1,L46);
                code.visitLabel(L32);
                code.visitTypeStmt(NEW_INSTANCE,9,-1,"Ljava/lang/IllegalStateException;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 9},new Method("Ljava/lang/IllegalStateException;","<init>",new String[]{ },"V"));
                code.visitStmt1R(THROW,9);
                code.visitLabel(L5);
                code.visitStmt1R(MOVE_EXCEPTION,9);
                code.visitStmt1R(MONITOR_EXIT,14);
                code.visitLabel(L4);
                code.visitStmt1R(THROW,9);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,9);
                code.visitStmt2R(MOVE_OBJECT,1,9);
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/log/Log;","isDebugEnabled",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,9);
                code.visitJumpStmt(IF_EQZ,9,-1,L36);
                code.visitLabel(L33);
                code.visitTypeStmt(NEW_INSTANCE,9,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 9},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,10,"uri=");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9,10},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitFieldStmt(IGET_OBJECT,10,14,new Field("Lorg/mortbay/jetty/HttpConnection;","_uri","Lorg/mortbay/jetty/HttpURI;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9,10},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 9},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L34);
                code.visitTypeStmt(NEW_INSTANCE,9,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 9},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,10,"fields=");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9,10},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitFieldStmt(IGET_OBJECT,10,14,new Field("Lorg/mortbay/jetty/HttpConnection;","_requestFields","Lorg/mortbay/jetty/HttpFields;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9,10},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 9},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L35);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitLabel(L36);
                code.visitFieldStmt(IGET_OBJECT,9,14,new Field("Lorg/mortbay/jetty/HttpConnection;","_generator","Lorg/mortbay/jetty/Generator;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/jetty/HttpException;","getStatus",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/jetty/HttpException;","getReason",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,11);
                code.visitConstStmt(CONST_4,12, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitConstStmt(CONST_4,13, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 9,10,11,12,13},new Method("Lorg/mortbay/jetty/Generator;","sendError",new String[]{ "I","Ljava/lang/String;","Ljava/lang/String;","Z"},"V"));
                code.visitLabel(L37);
                code.visitFieldStmt(IGET_OBJECT,9,14,new Field("Lorg/mortbay/jetty/HttpConnection;","_parser","Lorg/mortbay/jetty/Parser;"));
                code.visitConstStmt(CONST_4,10, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 9,10},new Method("Lorg/mortbay/jetty/Parser;","reset",new String[]{ "Z"},"V"));
                code.visitLabel(L38);
                code.visitFieldStmt(IGET_OBJECT,9,14,new Field("Lorg/mortbay/jetty/HttpConnection;","_endp","Lorg/mortbay/io/EndPoint;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 9},new Method("Lorg/mortbay/io/EndPoint;","close",new String[]{ },"V"));
                code.visitLabel(L39);
                code.visitStmt1R(THROW,1);
                code.visitLabel(L3);
                code.visitStmt1R(MOVE_EXCEPTION,9);
                code.visitConstStmt(CONST_4,10, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 10},new Method("Lorg/mortbay/jetty/HttpConnection;","setCurrentConnection",new String[]{ "Lorg/mortbay/jetty/HttpConnection;"},"V"));
                code.visitLabel(L40);
                code.visitFieldStmt(IGET_OBJECT,10,14,new Field("Lorg/mortbay/jetty/HttpConnection;","_parser","Lorg/mortbay/jetty/Parser;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 10},new Method("Lorg/mortbay/jetty/Parser;","isMoreInBuffer",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,10);
                DexLabel L122=new DexLabel();
                code.visitJumpStmt(IF_NEZ,10,-1,L122);
                code.visitFieldStmt(IGET_OBJECT,10,14,new Field("Lorg/mortbay/jetty/HttpConnection;","_endp","Lorg/mortbay/io/EndPoint;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 10},new Method("Lorg/mortbay/io/EndPoint;","isBufferingInput",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,10);
                code.visitJumpStmt(IF_EQZ,10,-1,L88);
                code.visitLabel(L122);
                code.visitConstStmt(CONST_4,10, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt2R(MOVE,4,10);
                code.visitLabel(L41);
                code.visitStmt1R(MONITOR_ENTER,14);
                code.visitLabel(L42);
                code.visitConstStmt(CONST_4,10, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L7);
                code.visitFieldStmt(IPUT_BOOLEAN,10,14,new Field("Lorg/mortbay/jetty/HttpConnection;","_handling","Z"));
                code.visitLabel(L43);
                code.visitFieldStmt(IGET_BOOLEAN,10,14,new Field("Lorg/mortbay/jetty/HttpConnection;","_destroy","Z"));
                code.visitJumpStmt(IF_EQZ,10,-1,L23);
                code.visitLabel(L44);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 14},new Method("Lorg/mortbay/jetty/HttpConnection;","destroy",new String[]{ },"V"));
                code.visitLabel(L45);
                code.visitStmt1R(MONITOR_EXIT,14);
                code.visitLabel(L8);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L46);
                code.visitConstStmt(CONST_4,9, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L10);
                code.visitFieldStmt(IPUT_BOOLEAN,9,14,new Field("Lorg/mortbay/jetty/HttpConnection;","_handling","Z"));
                code.visitLabel(L47);
                code.visitStmt1R(MONITOR_EXIT,14);
                code.visitLabel(L11);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 14},new Method("Lorg/mortbay/jetty/HttpConnection;","setCurrentConnection",new String[]{ "Lorg/mortbay/jetty/HttpConnection;"},"V"));
                code.visitLabel(L48);
                code.visitConstStmt(CONST_WIDE_16,2,Long.valueOf(0L)); // long: 0x0000000000000000  double:0.000000
                code.visitLabel(L49);
                code.visitFieldStmt(IGET_OBJECT,9,14,new Field("Lorg/mortbay/jetty/HttpConnection;","_request","Lorg/mortbay/jetty/Request;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9},new Method("Lorg/mortbay/jetty/Request;","getContinuation",new String[]{ },"Lorg/mortbay/util/ajax/Continuation;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L50);
                code.visitJumpStmt(IF_EQZ,0,-1,L16);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Lorg/mortbay/util/ajax/Continuation;","isPending",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,9);
                code.visitJumpStmt(IF_EQZ,9,-1,L16);
                code.visitLabel(L51);
                code.visitConstStmt(CONST_STRING,9,"resume continuation {}");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 9,0},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L52);
                code.visitFieldStmt(IGET_OBJECT,9,14,new Field("Lorg/mortbay/jetty/HttpConnection;","_request","Lorg/mortbay/jetty/Request;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9},new Method("Lorg/mortbay/jetty/Request;","getMethod",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitJumpStmt(IF_NEZ,9,-1,L54);
                code.visitLabel(L53);
                code.visitTypeStmt(NEW_INSTANCE,9,-1,"Ljava/lang/IllegalStateException;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 9},new Method("Ljava/lang/IllegalStateException;","<init>",new String[]{ },"V"));
                code.visitStmt1R(THROW,9);
                code.visitLabel(L54);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 14},new Method("Lorg/mortbay/jetty/HttpConnection;","handleRequest",new String[]{ },"V"));
                code.visitLabel(L12);
                code.visitConstStmt(CONST_4,9, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 9},new Method("Lorg/mortbay/jetty/HttpConnection;","setCurrentConnection",new String[]{ "Lorg/mortbay/jetty/HttpConnection;"},"V"));
                code.visitLabel(L55);
                code.visitFieldStmt(IGET_OBJECT,9,14,new Field("Lorg/mortbay/jetty/HttpConnection;","_parser","Lorg/mortbay/jetty/Parser;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 9},new Method("Lorg/mortbay/jetty/Parser;","isMoreInBuffer",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,9);
                DexLabel L123=new DexLabel();
                code.visitJumpStmt(IF_NEZ,9,-1,L123);
                code.visitFieldStmt(IGET_OBJECT,9,14,new Field("Lorg/mortbay/jetty/HttpConnection;","_endp","Lorg/mortbay/io/EndPoint;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 9},new Method("Lorg/mortbay/io/EndPoint;","isBufferingInput",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,9);
                code.visitJumpStmt(IF_EQZ,9,-1,L97);
                code.visitLabel(L123);
                code.visitConstStmt(CONST_4,9, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt2R(MOVE,4,9);
                code.visitLabel(L56);
                code.visitStmt1R(MONITOR_ENTER,14);
                code.visitLabel(L57);
                code.visitConstStmt(CONST_4,9, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L13);
                code.visitFieldStmt(IPUT_BOOLEAN,9,14,new Field("Lorg/mortbay/jetty/HttpConnection;","_handling","Z"));
                code.visitLabel(L58);
                code.visitFieldStmt(IGET_BOOLEAN,9,14,new Field("Lorg/mortbay/jetty/HttpConnection;","_destroy","Z"));
                code.visitJumpStmt(IF_EQZ,9,-1,L25);
                code.visitLabel(L59);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 14},new Method("Lorg/mortbay/jetty/HttpConnection;","destroy",new String[]{ },"V"));
                code.visitLabel(L60);
                code.visitStmt1R(MONITOR_EXIT,14);
                code.visitJumpStmt(GOTO,-1,-1,L8);
                code.visitLabel(L15);
                code.visitStmt1R(MOVE_EXCEPTION,9);
                code.visitStmt1R(MONITOR_EXIT,14);
                code.visitLabel(L14);
                code.visitStmt1R(THROW,9);
                code.visitLabel(L16);
                code.visitFieldStmt(IGET_OBJECT,9,14,new Field("Lorg/mortbay/jetty/HttpConnection;","_parser","Lorg/mortbay/jetty/Parser;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 9},new Method("Lorg/mortbay/jetty/Parser;","isComplete",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,9);
                code.visitJumpStmt(IF_NEZ,9,-1,L62);
                code.visitLabel(L61);
                code.visitFieldStmt(IGET_OBJECT,9,14,new Field("Lorg/mortbay/jetty/HttpConnection;","_parser","Lorg/mortbay/jetty/Parser;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 9},new Method("Lorg/mortbay/jetty/Parser;","parseAvailable",new String[]{ },"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,2);
                code.visitLabel(L62);
                code.visitFieldStmt(IGET_OBJECT,9,14,new Field("Lorg/mortbay/jetty/HttpConnection;","_generator","Lorg/mortbay/jetty/Generator;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 9},new Method("Lorg/mortbay/jetty/Generator;","isCommitted",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,9);
                code.visitJumpStmt(IF_EQZ,9,-1,L66);
                code.visitFieldStmt(IGET_OBJECT,9,14,new Field("Lorg/mortbay/jetty/HttpConnection;","_generator","Lorg/mortbay/jetty/Generator;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 9},new Method("Lorg/mortbay/jetty/Generator;","isComplete",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,9);
                code.visitJumpStmt(IF_NEZ,9,-1,L66);
                code.visitLabel(L63);
                code.visitFieldStmt(IGET_OBJECT,9,14,new Field("Lorg/mortbay/jetty/HttpConnection;","_generator","Lorg/mortbay/jetty/Generator;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 9},new Method("Lorg/mortbay/jetty/Generator;","flush",new String[]{ },"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,7);
                code.visitLabel(L64);
                code.visitStmt2R(ADD_LONG_2ADDR,2,7);
                code.visitLabel(L65);
                code.visitConstStmt(CONST_WIDE_16,9,Long.valueOf(0L)); // long: 0x0000000000000000  double:0.000000
                code.visitStmt3R(CMP_LONG,9,7,9);
                code.visitJumpStmt(IF_GTZ,9,-1,L73);
                code.visitLabel(L66);
                code.visitFieldStmt(IGET_OBJECT,9,14,new Field("Lorg/mortbay/jetty/HttpConnection;","_endp","Lorg/mortbay/io/EndPoint;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 9},new Method("Lorg/mortbay/io/EndPoint;","isBufferingOutput",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,9);
                DexLabel L124=new DexLabel();
                code.visitJumpStmt(IF_EQZ,9,-1,L124);
                code.visitLabel(L67);
                code.visitFieldStmt(IGET_OBJECT,9,14,new Field("Lorg/mortbay/jetty/HttpConnection;","_endp","Lorg/mortbay/io/EndPoint;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 9},new Method("Lorg/mortbay/io/EndPoint;","flush",new String[]{ },"V"));
                code.visitLabel(L68);
                code.visitFieldStmt(IGET_OBJECT,9,14,new Field("Lorg/mortbay/jetty/HttpConnection;","_endp","Lorg/mortbay/io/EndPoint;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 9},new Method("Lorg/mortbay/io/EndPoint;","isBufferingOutput",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,9);
                code.visitJumpStmt(IF_NEZ,9,-1,L124);
                code.visitLabel(L69);
                code.visitConstStmt(CONST_4,5, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt2R(MOVE,6,5);
                code.visitLabel(L70);
                code.visitConstStmt(CONST_WIDE_16,9,Long.valueOf(0L)); // long: 0x0000000000000000  double:0.000000
                code.visitStmt3R(CMP_LONG,9,2,9);
                code.visitJumpStmt(IF_LEZ,9,-1,L75);
                code.visitLabel(L71);
                code.visitConstStmt(CONST_4,5, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L72);
                code.visitJumpStmt(GOTO,-1,-1,L12);
                code.visitLabel(L73);
                code.visitFieldStmt(IGET_OBJECT,9,14,new Field("Lorg/mortbay/jetty/HttpConnection;","_endp","Lorg/mortbay/io/EndPoint;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 9},new Method("Lorg/mortbay/io/EndPoint;","isBufferingOutput",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,9);
                code.visitJumpStmt(IF_EQZ,9,-1,L62);
                code.visitLabel(L74);
                code.visitFieldStmt(IGET_OBJECT,9,14,new Field("Lorg/mortbay/jetty/HttpConnection;","_endp","Lorg/mortbay/io/EndPoint;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 9},new Method("Lorg/mortbay/io/EndPoint;","flush",new String[]{ },"V"));
                code.visitLabel(L17);
                code.visitJumpStmt(GOTO,-1,-1,L62);
                code.visitLabel(L75);
                code.visitStmt2R1N(ADD_INT_LIT8,5,6,1);
                code.visitLabel(L76);
                code.visitConstStmt(CONST_4,9, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitJumpStmt(IF_LT,6,9,L12);
                code.visitLabel(L77);
                code.visitConstStmt(CONST_4,9, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 9},new Method("Lorg/mortbay/jetty/HttpConnection;","setCurrentConnection",new String[]{ "Lorg/mortbay/jetty/HttpConnection;"},"V"));
                code.visitLabel(L78);
                code.visitFieldStmt(IGET_OBJECT,9,14,new Field("Lorg/mortbay/jetty/HttpConnection;","_parser","Lorg/mortbay/jetty/Parser;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 9},new Method("Lorg/mortbay/jetty/Parser;","isMoreInBuffer",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,9);
                DexLabel L125=new DexLabel();
                code.visitJumpStmt(IF_NEZ,9,-1,L125);
                code.visitFieldStmt(IGET_OBJECT,9,14,new Field("Lorg/mortbay/jetty/HttpConnection;","_endp","Lorg/mortbay/io/EndPoint;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 9},new Method("Lorg/mortbay/io/EndPoint;","isBufferingInput",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,9);
                code.visitJumpStmt(IF_EQZ,9,-1,L109);
                code.visitLabel(L125);
                code.visitConstStmt(CONST_4,9, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt2R(MOVE,4,9);
                code.visitLabel(L79);
                code.visitStmt1R(MONITOR_ENTER,14);
                code.visitLabel(L80);
                code.visitConstStmt(CONST_4,9, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L18);
                code.visitFieldStmt(IPUT_BOOLEAN,9,14,new Field("Lorg/mortbay/jetty/HttpConnection;","_handling","Z"));
                code.visitLabel(L81);
                code.visitFieldStmt(IGET_BOOLEAN,9,14,new Field("Lorg/mortbay/jetty/HttpConnection;","_destroy","Z"));
                code.visitJumpStmt(IF_EQZ,9,-1,L27);
                code.visitLabel(L82);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 14},new Method("Lorg/mortbay/jetty/HttpConnection;","destroy",new String[]{ },"V"));
                code.visitLabel(L83);
                code.visitStmt1R(MONITOR_EXIT,14);
                code.visitJumpStmt(GOTO_16,-1,-1,L8);
                code.visitLabel(L20);
                code.visitStmt1R(MOVE_EXCEPTION,9);
                code.visitStmt1R(MONITOR_EXIT,14);
                code.visitLabel(L19);
                code.visitStmt1R(THROW,9);
                code.visitLabel(L84);
                code.visitFieldStmt(IGET_OBJECT,10,14,new Field("Lorg/mortbay/jetty/HttpConnection;","_generator","Lorg/mortbay/jetty/Generator;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 10},new Method("Lorg/mortbay/jetty/Generator;","isCommitted",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,10);
                code.visitJumpStmt(IF_EQZ,10,-1,L87);
                code.visitFieldStmt(IGET_OBJECT,10,14,new Field("Lorg/mortbay/jetty/HttpConnection;","_generator","Lorg/mortbay/jetty/Generator;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 10},new Method("Lorg/mortbay/jetty/Generator;","isComplete",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,10);
                code.visitJumpStmt(IF_NEZ,10,-1,L87);
                code.visitFieldStmt(IGET_OBJECT,10,14,new Field("Lorg/mortbay/jetty/HttpConnection;","_endp","Lorg/mortbay/io/EndPoint;"));
                code.visitTypeStmt(INSTANCE_OF,10,10,"Lorg/mortbay/io/nio/SelectChannelEndPoint;");
                code.visitJumpStmt(IF_EQZ,10,-1,L87);
                code.visitLabel(L85);
                code.visitFieldStmt(IGET_OBJECT,14,14,new Field("Lorg/mortbay/jetty/HttpConnection;","_endp","Lorg/mortbay/io/EndPoint;"));
                code.visitLabel(L86);
                code.visitTypeStmt(CHECK_CAST,14,-1,"Lorg/mortbay/io/nio/SelectChannelEndPoint;");
                code.visitConstStmt(CONST_4,10, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 14,10},new Method("Lorg/mortbay/io/nio/SelectChannelEndPoint;","setWritable",new String[]{ "Z"},"V"));
                code.visitLabel(L87);
                code.visitStmt1R(THROW,9);
                code.visitLabel(L9);
                code.visitStmt1R(MOVE_EXCEPTION,9);
                code.visitLabel(L21);
                code.visitStmt1R(MONITOR_EXIT,14);
                code.visitLabel(L22);
                code.visitStmt1R(THROW,9);
                code.visitLabel(L88);
                code.visitConstStmt(CONST_4,10, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt2R(MOVE,4,10);
                code.visitJumpStmt(GOTO_16,-1,-1,L41);
                code.visitLabel(L23);
                code.visitStmt1R(MONITOR_EXIT,14);
                code.visitLabel(L24);
                code.visitFieldStmt(IGET_OBJECT,10,14,new Field("Lorg/mortbay/jetty/HttpConnection;","_parser","Lorg/mortbay/jetty/Parser;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 10},new Method("Lorg/mortbay/jetty/Parser;","isComplete",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,10);
                code.visitJumpStmt(IF_EQZ,10,-1,L94);
                code.visitFieldStmt(IGET_OBJECT,10,14,new Field("Lorg/mortbay/jetty/HttpConnection;","_generator","Lorg/mortbay/jetty/Generator;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 10},new Method("Lorg/mortbay/jetty/Generator;","isComplete",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,10);
                code.visitJumpStmt(IF_EQZ,10,-1,L94);
                code.visitFieldStmt(IGET_OBJECT,10,14,new Field("Lorg/mortbay/jetty/HttpConnection;","_endp","Lorg/mortbay/io/EndPoint;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 10},new Method("Lorg/mortbay/io/EndPoint;","isBufferingOutput",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,10);
                code.visitJumpStmt(IF_NEZ,10,-1,L94);
                code.visitLabel(L89);
                code.visitFieldStmt(IGET_OBJECT,10,14,new Field("Lorg/mortbay/jetty/HttpConnection;","_generator","Lorg/mortbay/jetty/Generator;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 10},new Method("Lorg/mortbay/jetty/Generator;","isPersistent",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,10);
                code.visitJumpStmt(IF_NEZ,10,-1,L92);
                code.visitLabel(L90);
                code.visitFieldStmt(IGET_OBJECT,10,14,new Field("Lorg/mortbay/jetty/HttpConnection;","_parser","Lorg/mortbay/jetty/Parser;"));
                code.visitConstStmt(CONST_4,11, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 10,11},new Method("Lorg/mortbay/jetty/Parser;","reset",new String[]{ "Z"},"V"));
                code.visitLabel(L91);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L92);
                code.visitJumpStmt(IF_NEZ,4,-1,L96);
                code.visitConstStmt(CONST_4,10, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                DexLabel L126=new DexLabel();
                code.visitLabel(L126);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 14,10},new Method("Lorg/mortbay/jetty/HttpConnection;","reset",new String[]{ "Z"},"V"));
                code.visitLabel(L93);
                code.visitConstStmt(CONST_4,5, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L94);
                code.visitFieldStmt(IGET_OBJECT,10,14,new Field("Lorg/mortbay/jetty/HttpConnection;","_request","Lorg/mortbay/jetty/Request;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Lorg/mortbay/jetty/Request;","getContinuation",new String[]{ },"Lorg/mortbay/util/ajax/Continuation;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L95);
                code.visitJumpStmt(IF_EQZ,0,-1,L84);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Lorg/mortbay/util/ajax/Continuation;","isPending",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,10);
                code.visitJumpStmt(IF_EQZ,10,-1,L84);
                code.visitJumpStmt(GOTO_16,-1,-1,L8);
                code.visitLabel(L96);
                code.visitConstStmt(CONST_4,10, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L126);
                code.visitLabel(L97);
                code.visitConstStmt(CONST_4,9, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt2R(MOVE,4,9);
                code.visitJumpStmt(GOTO_16,-1,-1,L56);
                code.visitLabel(L25);
                code.visitStmt1R(MONITOR_EXIT,14);
                code.visitLabel(L26);
                code.visitFieldStmt(IGET_OBJECT,9,14,new Field("Lorg/mortbay/jetty/HttpConnection;","_parser","Lorg/mortbay/jetty/Parser;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 9},new Method("Lorg/mortbay/jetty/Parser;","isComplete",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,9);
                code.visitJumpStmt(IF_EQZ,9,-1,L103);
                code.visitFieldStmt(IGET_OBJECT,9,14,new Field("Lorg/mortbay/jetty/HttpConnection;","_generator","Lorg/mortbay/jetty/Generator;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 9},new Method("Lorg/mortbay/jetty/Generator;","isComplete",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,9);
                code.visitJumpStmt(IF_EQZ,9,-1,L103);
                code.visitFieldStmt(IGET_OBJECT,9,14,new Field("Lorg/mortbay/jetty/HttpConnection;","_endp","Lorg/mortbay/io/EndPoint;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 9},new Method("Lorg/mortbay/io/EndPoint;","isBufferingOutput",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,9);
                code.visitJumpStmt(IF_NEZ,9,-1,L103);
                code.visitLabel(L98);
                code.visitFieldStmt(IGET_OBJECT,9,14,new Field("Lorg/mortbay/jetty/HttpConnection;","_generator","Lorg/mortbay/jetty/Generator;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 9},new Method("Lorg/mortbay/jetty/Generator;","isPersistent",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,9);
                code.visitJumpStmt(IF_NEZ,9,-1,L101);
                code.visitLabel(L99);
                code.visitFieldStmt(IGET_OBJECT,9,14,new Field("Lorg/mortbay/jetty/HttpConnection;","_parser","Lorg/mortbay/jetty/Parser;"));
                code.visitConstStmt(CONST_4,10, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 9,10},new Method("Lorg/mortbay/jetty/Parser;","reset",new String[]{ "Z"},"V"));
                code.visitLabel(L100);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L101);
                code.visitJumpStmt(IF_NEZ,4,-1,L108);
                code.visitConstStmt(CONST_4,9, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                DexLabel L127=new DexLabel();
                code.visitLabel(L127);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 14,9},new Method("Lorg/mortbay/jetty/HttpConnection;","reset",new String[]{ "Z"},"V"));
                code.visitLabel(L102);
                code.visitConstStmt(CONST_4,5, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L103);
                code.visitFieldStmt(IGET_OBJECT,9,14,new Field("Lorg/mortbay/jetty/HttpConnection;","_request","Lorg/mortbay/jetty/Request;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9},new Method("Lorg/mortbay/jetty/Request;","getContinuation",new String[]{ },"Lorg/mortbay/util/ajax/Continuation;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L104);
                code.visitJumpStmt(IF_EQZ,0,-1,L105);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Lorg/mortbay/util/ajax/Continuation;","isPending",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,9);
                code.visitJumpStmt(IF_NEZ,9,-1,L8);
                code.visitLabel(L105);
                code.visitFieldStmt(IGET_OBJECT,9,14,new Field("Lorg/mortbay/jetty/HttpConnection;","_generator","Lorg/mortbay/jetty/Generator;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 9},new Method("Lorg/mortbay/jetty/Generator;","isCommitted",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,9);
                code.visitJumpStmt(IF_EQZ,9,-1,L31);
                code.visitFieldStmt(IGET_OBJECT,9,14,new Field("Lorg/mortbay/jetty/HttpConnection;","_generator","Lorg/mortbay/jetty/Generator;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 9},new Method("Lorg/mortbay/jetty/Generator;","isComplete",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,9);
                code.visitJumpStmt(IF_NEZ,9,-1,L31);
                code.visitFieldStmt(IGET_OBJECT,9,14,new Field("Lorg/mortbay/jetty/HttpConnection;","_endp","Lorg/mortbay/io/EndPoint;"));
                code.visitTypeStmt(INSTANCE_OF,9,9,"Lorg/mortbay/io/nio/SelectChannelEndPoint;");
                code.visitJumpStmt(IF_EQZ,9,-1,L31);
                code.visitLabel(L106);
                code.visitFieldStmt(IGET_OBJECT,0,14,new Field("Lorg/mortbay/jetty/HttpConnection;","_endp","Lorg/mortbay/io/EndPoint;"));
                code.visitLabel(L107);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Lorg/mortbay/io/nio/SelectChannelEndPoint;");
                code.visitConstStmt(CONST_4,9, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,9},new Method("Lorg/mortbay/io/nio/SelectChannelEndPoint;","setWritable",new String[]{ "Z"},"V"));
                code.visitJumpStmt(GOTO_16,-1,-1,L31);
                code.visitLabel(L108);
                code.visitConstStmt(CONST_4,9, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L127);
                code.visitLabel(L109);
                code.visitConstStmt(CONST_4,9, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt2R(MOVE,4,9);
                code.visitJumpStmt(GOTO_16,-1,-1,L79);
                code.visitLabel(L27);
                code.visitStmt1R(MONITOR_EXIT,14);
                code.visitLabel(L28);
                code.visitFieldStmt(IGET_OBJECT,9,14,new Field("Lorg/mortbay/jetty/HttpConnection;","_parser","Lorg/mortbay/jetty/Parser;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 9},new Method("Lorg/mortbay/jetty/Parser;","isComplete",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,9);
                code.visitJumpStmt(IF_EQZ,9,-1,L115);
                code.visitFieldStmt(IGET_OBJECT,9,14,new Field("Lorg/mortbay/jetty/HttpConnection;","_generator","Lorg/mortbay/jetty/Generator;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 9},new Method("Lorg/mortbay/jetty/Generator;","isComplete",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,9);
                code.visitJumpStmt(IF_EQZ,9,-1,L115);
                code.visitFieldStmt(IGET_OBJECT,9,14,new Field("Lorg/mortbay/jetty/HttpConnection;","_endp","Lorg/mortbay/io/EndPoint;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 9},new Method("Lorg/mortbay/io/EndPoint;","isBufferingOutput",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,9);
                code.visitJumpStmt(IF_NEZ,9,-1,L115);
                code.visitLabel(L110);
                code.visitFieldStmt(IGET_OBJECT,9,14,new Field("Lorg/mortbay/jetty/HttpConnection;","_generator","Lorg/mortbay/jetty/Generator;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 9},new Method("Lorg/mortbay/jetty/Generator;","isPersistent",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,9);
                code.visitJumpStmt(IF_NEZ,9,-1,L113);
                code.visitLabel(L111);
                code.visitFieldStmt(IGET_OBJECT,9,14,new Field("Lorg/mortbay/jetty/HttpConnection;","_parser","Lorg/mortbay/jetty/Parser;"));
                code.visitConstStmt(CONST_4,10, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 9,10},new Method("Lorg/mortbay/jetty/Parser;","reset",new String[]{ "Z"},"V"));
                code.visitLabel(L112);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L113);
                code.visitJumpStmt(IF_NEZ,4,-1,L120);
                code.visitConstStmt(CONST_4,9, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                DexLabel L128=new DexLabel();
                code.visitLabel(L128);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 14,9},new Method("Lorg/mortbay/jetty/HttpConnection;","reset",new String[]{ "Z"},"V"));
                code.visitLabel(L114);
                code.visitConstStmt(CONST_4,5, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L115);
                code.visitFieldStmt(IGET_OBJECT,9,14,new Field("Lorg/mortbay/jetty/HttpConnection;","_request","Lorg/mortbay/jetty/Request;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9},new Method("Lorg/mortbay/jetty/Request;","getContinuation",new String[]{ },"Lorg/mortbay/util/ajax/Continuation;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L116);
                code.visitJumpStmt(IF_EQZ,0,-1,L117);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Lorg/mortbay/util/ajax/Continuation;","isPending",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,9);
                code.visitJumpStmt(IF_NEZ,9,-1,L8);
                code.visitLabel(L117);
                code.visitFieldStmt(IGET_OBJECT,9,14,new Field("Lorg/mortbay/jetty/HttpConnection;","_generator","Lorg/mortbay/jetty/Generator;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 9},new Method("Lorg/mortbay/jetty/Generator;","isCommitted",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,9);
                code.visitJumpStmt(IF_EQZ,9,-1,L8);
                code.visitFieldStmt(IGET_OBJECT,9,14,new Field("Lorg/mortbay/jetty/HttpConnection;","_generator","Lorg/mortbay/jetty/Generator;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 9},new Method("Lorg/mortbay/jetty/Generator;","isComplete",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,9);
                code.visitJumpStmt(IF_NEZ,9,-1,L8);
                code.visitFieldStmt(IGET_OBJECT,9,14,new Field("Lorg/mortbay/jetty/HttpConnection;","_endp","Lorg/mortbay/io/EndPoint;"));
                code.visitTypeStmt(INSTANCE_OF,9,9,"Lorg/mortbay/io/nio/SelectChannelEndPoint;");
                code.visitJumpStmt(IF_EQZ,9,-1,L8);
                code.visitLabel(L118);
                code.visitFieldStmt(IGET_OBJECT,14,14,new Field("Lorg/mortbay/jetty/HttpConnection;","_endp","Lorg/mortbay/io/EndPoint;"));
                code.visitLabel(L119);
                code.visitTypeStmt(CHECK_CAST,14,-1,"Lorg/mortbay/io/nio/SelectChannelEndPoint;");
                code.visitConstStmt(CONST_4,9, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 14,9},new Method("Lorg/mortbay/io/nio/SelectChannelEndPoint;","setWritable",new String[]{ "Z"},"V"));
                code.visitJumpStmt(GOTO_16,-1,-1,L8);
                code.visitLabel(L120);
                code.visitConstStmt(CONST_4,9, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L128);
                code.visitLabel(L124);
                code.visitStmt2R(MOVE,6,5);
                code.visitLabel(L121);
                code.visitJumpStmt(GOTO_16,-1,-1,L70);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m037_handleRequest(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/HttpConnection;","handleRequest",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(14);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                DexLabel L5=new DexLabel();
                DexLabel L6=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L1,L2,L3,L4,L5,L6},new String[]{ "Lorg/mortbay/jetty/RetryRequest;","Lorg/mortbay/jetty/EofException;","Lorg/mortbay/jetty/HttpException;","Ljava/lang/Exception;","Ljava/lang/Error;",null});
                DexLabel L7=new DexLabel();
                DexLabel L8=new DexLabel();
                code.visitTryCatch(L7,L8,new DexLabel[]{L6},new String[]{ null});
                DexLabel L9=new DexLabel();
                DexLabel L10=new DexLabel();
                code.visitTryCatch(L9,L10,new DexLabel[]{L1,L2,L3,L4,L5,L6},new String[]{ "Lorg/mortbay/jetty/RetryRequest;","Lorg/mortbay/jetty/EofException;","Lorg/mortbay/jetty/HttpException;","Ljava/lang/Exception;","Ljava/lang/Error;",null});
                DexLabel L11=new DexLabel();
                DexLabel L12=new DexLabel();
                code.visitTryCatch(L11,L12,new DexLabel[]{L6},new String[]{ null});
                DexLabel L13=new DexLabel();
                DexLabel L14=new DexLabel();
                code.visitTryCatch(L13,L14,new DexLabel[]{L6},new String[]{ null});
                DexLabel L15=new DexLabel();
                DexLabel L16=new DexLabel();
                code.visitTryCatch(L15,L16,new DexLabel[]{L6},new String[]{ null});
                DexLabel L17=new DexLabel();
                DexLabel L18=new DexLabel();
                code.visitTryCatch(L17,L18,new DexLabel[]{L6},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L19=new DexLabel();
                ddv.visitPrologue(L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(511,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(513,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(514,L22);
                ddv.visitStartLocal(4,L22,"retrying","Z",null);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(515,L23);
                ddv.visitStartLocal(1,L23,"error","Z",null);
                ddv.visitLineNumber(519,L0);
                ddv.visitStartLocal(5,L0,"threadName","Ljava/lang/String;",null);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(520,L24);
                ddv.visitStartLocal(2,L24,"info","Ljava/lang/String;",null);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(521,L25);
                ddv.visitLineNumber(537,L1);
                ddv.visitEndLocal(2,L1);
                ddv.visitLineNumber(539,L7);
                ddv.visitStartLocal(3,L7,"r","Lorg/mortbay/jetty/RetryRequest;",null);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(540,L26);
                ddv.visitLineNumber(541,L8);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(571,L27);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(572,L28);
                DexLabel L29=new DexLabel();
                ddv.visitLineNumber(574,L29);
                DexLabel L30=new DexLabel();
                ddv.visitLineNumber(576,L30);
                DexLabel L31=new DexLabel();
                ddv.visitLineNumber(578,L31);
                DexLabel L32=new DexLabel();
                ddv.visitLineNumber(579,L32);
                DexLabel L33=new DexLabel();
                ddv.visitLineNumber(582,L33);
                DexLabel L34=new DexLabel();
                ddv.visitLineNumber(584,L34);
                DexLabel L35=new DexLabel();
                ddv.visitLineNumber(585,L35);
                DexLabel L36=new DexLabel();
                ddv.visitLineNumber(587,L36);
                DexLabel L37=new DexLabel();
                ddv.visitLineNumber(588,L37);
                DexLabel L38=new DexLabel();
                ddv.visitEndLocal(3,L38);
                DexLabel L39=new DexLabel();
                ddv.visitLineNumber(603,L39);
                ddv.visitEndLocal(4,L39);
                ddv.visitEndLocal(1,L39);
                ddv.visitEndLocal(5,L39);
                ddv.visitLineNumber(522,L9);
                ddv.visitRestartLocal(1,L9);
                ddv.visitRestartLocal(2,L9);
                ddv.visitRestartLocal(4,L9);
                ddv.visitRestartLocal(5,L9);
                DexLabel L40=new DexLabel();
                ddv.visitLineNumber(524,L40);
                DexLabel L41=new DexLabel();
                ddv.visitLineNumber(525,L41);
                DexLabel L42=new DexLabel();
                ddv.visitLineNumber(527,L42);
                DexLabel L43=new DexLabel();
                ddv.visitLineNumber(529,L43);
                DexLabel L44=new DexLabel();
                ddv.visitLineNumber(530,L44);
                ddv.visitRestartLocal(5,L44);
                DexLabel L45=new DexLabel();
                ddv.visitLineNumber(533,L45);
                DexLabel L46=new DexLabel();
                ddv.visitLineNumber(535,L46);
                ddv.visitLineNumber(571,L10);
                DexLabel L47=new DexLabel();
                ddv.visitLineNumber(572,L47);
                DexLabel L48=new DexLabel();
                ddv.visitLineNumber(574,L48);
                DexLabel L49=new DexLabel();
                ddv.visitLineNumber(576,L49);
                DexLabel L50=new DexLabel();
                ddv.visitLineNumber(578,L50);
                DexLabel L51=new DexLabel();
                ddv.visitLineNumber(579,L51);
                DexLabel L52=new DexLabel();
                ddv.visitLineNumber(582,L52);
                DexLabel L53=new DexLabel();
                ddv.visitLineNumber(584,L53);
                DexLabel L54=new DexLabel();
                ddv.visitLineNumber(585,L54);
                DexLabel L55=new DexLabel();
                ddv.visitLineNumber(587,L55);
                DexLabel L56=new DexLabel();
                ddv.visitLineNumber(588,L56);
                ddv.visitLineNumber(543,L2);
                ddv.visitEndLocal(2,L2);
                ddv.visitLineNumber(545,L11);
                ddv.visitStartLocal(0,L11,"e","Lorg/mortbay/jetty/EofException;",null);
                ddv.visitLineNumber(546,L12);
                DexLabel L57=new DexLabel();
                ddv.visitLineNumber(571,L57);
                DexLabel L58=new DexLabel();
                ddv.visitLineNumber(572,L58);
                DexLabel L59=new DexLabel();
                ddv.visitLineNumber(574,L59);
                DexLabel L60=new DexLabel();
                ddv.visitLineNumber(576,L60);
                DexLabel L61=new DexLabel();
                ddv.visitLineNumber(578,L61);
                DexLabel L62=new DexLabel();
                ddv.visitLineNumber(579,L62);
                DexLabel L63=new DexLabel();
                ddv.visitLineNumber(582,L63);
                DexLabel L64=new DexLabel();
                ddv.visitLineNumber(584,L64);
                DexLabel L65=new DexLabel();
                ddv.visitLineNumber(585,L65);
                DexLabel L66=new DexLabel();
                ddv.visitLineNumber(587,L66);
                DexLabel L67=new DexLabel();
                ddv.visitLineNumber(588,L67);
                ddv.visitLineNumber(548,L3);
                ddv.visitEndLocal(0,L3);
                ddv.visitLineNumber(550,L13);
                ddv.visitStartLocal(0,L13,"e","Lorg/mortbay/jetty/HttpException;",null);
                DexLabel L68=new DexLabel();
                ddv.visitLineNumber(551,L68);
                DexLabel L69=new DexLabel();
                ddv.visitLineNumber(552,L69);
                ddv.visitLineNumber(553,L14);
                DexLabel L70=new DexLabel();
                ddv.visitLineNumber(571,L70);
                DexLabel L71=new DexLabel();
                ddv.visitLineNumber(572,L71);
                DexLabel L72=new DexLabel();
                ddv.visitLineNumber(574,L72);
                DexLabel L73=new DexLabel();
                ddv.visitLineNumber(576,L73);
                DexLabel L74=new DexLabel();
                ddv.visitLineNumber(578,L74);
                DexLabel L75=new DexLabel();
                ddv.visitLineNumber(579,L75);
                DexLabel L76=new DexLabel();
                ddv.visitLineNumber(582,L76);
                DexLabel L77=new DexLabel();
                ddv.visitLineNumber(584,L77);
                DexLabel L78=new DexLabel();
                ddv.visitLineNumber(585,L78);
                DexLabel L79=new DexLabel();
                ddv.visitLineNumber(587,L79);
                DexLabel L80=new DexLabel();
                ddv.visitLineNumber(588,L80);
                ddv.visitLineNumber(555,L4);
                ddv.visitEndLocal(0,L4);
                ddv.visitLineNumber(557,L15);
                ddv.visitStartLocal(0,L15,"e","Ljava/lang/Exception;",null);
                DexLabel L81=new DexLabel();
                ddv.visitLineNumber(558,L81);
                DexLabel L82=new DexLabel();
                ddv.visitLineNumber(559,L82);
                ddv.visitLineNumber(560,L16);
                DexLabel L83=new DexLabel();
                ddv.visitLineNumber(571,L83);
                DexLabel L84=new DexLabel();
                ddv.visitLineNumber(572,L84);
                DexLabel L85=new DexLabel();
                ddv.visitLineNumber(574,L85);
                DexLabel L86=new DexLabel();
                ddv.visitLineNumber(576,L86);
                DexLabel L87=new DexLabel();
                ddv.visitLineNumber(578,L87);
                DexLabel L88=new DexLabel();
                ddv.visitLineNumber(579,L88);
                DexLabel L89=new DexLabel();
                ddv.visitLineNumber(582,L89);
                DexLabel L90=new DexLabel();
                ddv.visitLineNumber(584,L90);
                DexLabel L91=new DexLabel();
                ddv.visitLineNumber(585,L91);
                DexLabel L92=new DexLabel();
                ddv.visitLineNumber(587,L92);
                DexLabel L93=new DexLabel();
                ddv.visitLineNumber(588,L93);
                ddv.visitLineNumber(562,L5);
                ddv.visitEndLocal(0,L5);
                ddv.visitLineNumber(564,L17);
                ddv.visitStartLocal(0,L17,"e","Ljava/lang/Error;",null);
                DexLabel L94=new DexLabel();
                ddv.visitLineNumber(565,L94);
                DexLabel L95=new DexLabel();
                ddv.visitLineNumber(566,L95);
                ddv.visitLineNumber(567,L18);
                DexLabel L96=new DexLabel();
                ddv.visitLineNumber(571,L96);
                DexLabel L97=new DexLabel();
                ddv.visitLineNumber(572,L97);
                DexLabel L98=new DexLabel();
                ddv.visitLineNumber(574,L98);
                DexLabel L99=new DexLabel();
                ddv.visitLineNumber(576,L99);
                DexLabel L100=new DexLabel();
                ddv.visitLineNumber(578,L100);
                DexLabel L101=new DexLabel();
                ddv.visitLineNumber(579,L101);
                DexLabel L102=new DexLabel();
                ddv.visitLineNumber(582,L102);
                DexLabel L103=new DexLabel();
                ddv.visitLineNumber(584,L103);
                DexLabel L104=new DexLabel();
                ddv.visitLineNumber(585,L104);
                DexLabel L105=new DexLabel();
                ddv.visitLineNumber(587,L105);
                DexLabel L106=new DexLabel();
                ddv.visitLineNumber(588,L106);
                ddv.visitLineNumber(571,L6);
                ddv.visitEndLocal(0,L6);
                DexLabel L107=new DexLabel();
                ddv.visitLineNumber(572,L107);
                DexLabel L108=new DexLabel();
                ddv.visitLineNumber(574,L108);
                DexLabel L109=new DexLabel();
                ddv.visitLineNumber(576,L109);
                DexLabel L110=new DexLabel();
                ddv.visitLineNumber(578,L110);
                DexLabel L111=new DexLabel();
                ddv.visitLineNumber(579,L111);
                DexLabel L112=new DexLabel();
                ddv.visitLineNumber(582,L112);
                DexLabel L113=new DexLabel();
                ddv.visitLineNumber(584,L113);
                DexLabel L114=new DexLabel();
                ddv.visitLineNumber(585,L114);
                DexLabel L115=new DexLabel();
                ddv.visitLineNumber(587,L115);
                DexLabel L116=new DexLabel();
                ddv.visitLineNumber(588,L116);
                DexLabel L117=new DexLabel();
                ddv.visitLineNumber(571,L117);
                DexLabel L118=new DexLabel();
                ddv.visitLineNumber(598,L118);
                DexLabel L119=new DexLabel();
                ddv.visitLineNumber(591,L119);
                DexLabel L120=new DexLabel();
                ddv.visitLineNumber(592,L120);
                DexLabel L121=new DexLabel();
                ddv.visitLineNumber(593,L121);
                DexLabel L122=new DexLabel();
                ddv.visitLineNumber(598,L122);
                ddv.visitRestartLocal(3,L122);
                DexLabel L123=new DexLabel();
                ddv.visitEndLocal(3,L123);
                DexLabel L124=new DexLabel();
                ddv.visitLineNumber(591,L124);
                ddv.visitRestartLocal(3,L124);
                DexLabel L125=new DexLabel();
                ddv.visitLineNumber(592,L125);
                DexLabel L126=new DexLabel();
                ddv.visitLineNumber(593,L126);
                DexLabel L127=new DexLabel();
                ddv.visitEndLocal(3,L127);
                DexLabel L128=new DexLabel();
                ddv.visitLineNumber(598,L128);
                ddv.visitStartLocal(0,L128,"e","Lorg/mortbay/jetty/EofException;",null);
                DexLabel L129=new DexLabel();
                ddv.visitLineNumber(591,L129);
                DexLabel L130=new DexLabel();
                ddv.visitLineNumber(592,L130);
                DexLabel L131=new DexLabel();
                ddv.visitLineNumber(593,L131);
                DexLabel L132=new DexLabel();
                ddv.visitLineNumber(598,L132);
                ddv.visitStartLocal(0,L132,"e","Lorg/mortbay/jetty/HttpException;",null);
                DexLabel L133=new DexLabel();
                ddv.visitLineNumber(591,L133);
                DexLabel L134=new DexLabel();
                ddv.visitLineNumber(592,L134);
                DexLabel L135=new DexLabel();
                ddv.visitLineNumber(593,L135);
                DexLabel L136=new DexLabel();
                ddv.visitLineNumber(598,L136);
                ddv.visitStartLocal(0,L136,"e","Ljava/lang/Exception;",null);
                DexLabel L137=new DexLabel();
                ddv.visitLineNumber(591,L137);
                DexLabel L138=new DexLabel();
                ddv.visitLineNumber(592,L138);
                DexLabel L139=new DexLabel();
                ddv.visitLineNumber(593,L139);
                DexLabel L140=new DexLabel();
                ddv.visitLineNumber(598,L140);
                ddv.visitStartLocal(0,L140,"e","Ljava/lang/Error;",null);
                DexLabel L141=new DexLabel();
                ddv.visitLineNumber(591,L141);
                DexLabel L142=new DexLabel();
                ddv.visitLineNumber(592,L142);
                DexLabel L143=new DexLabel();
                ddv.visitLineNumber(593,L143);
                DexLabel L144=new DexLabel();
                ddv.visitLineNumber(598,L144);
                ddv.visitEndLocal(0,L144);
                ddv.visitRestartLocal(2,L144);
                DexLabel L145=new DexLabel();
                ddv.visitLineNumber(591,L145);
                DexLabel L146=new DexLabel();
                ddv.visitLineNumber(592,L146);
                DexLabel L147=new DexLabel();
                ddv.visitLineNumber(593,L147);
                code.visitLabel(L19);
                code.visitConstStmt(CONST_16,11, Integer.valueOf(404)); // int: 0x00000194  float:0.000000
                code.visitConstStmt(CONST_STRING,12,"continuation still pending {}");
                code.visitLabel(L20);
                code.visitFieldStmt(IGET_OBJECT,6,13,new Field("Lorg/mortbay/jetty/HttpConnection;","_server","Lorg/mortbay/jetty/Server;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/Server;","isRunning",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitJumpStmt(IF_EQZ,6,-1,L39);
                code.visitLabel(L21);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L22);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L23);
                code.visitConstStmt(CONST_4,5, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,6,13,new Field("Lorg/mortbay/jetty/HttpConnection;","_uri","Lorg/mortbay/jetty/HttpURI;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/HttpURI;","getDecodedPath",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 6},new Method("Lorg/mortbay/util/URIUtil;","canonicalPath",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L24);
                code.visitJumpStmt(IF_NEZ,2,-1,L9);
                code.visitLabel(L25);
                code.visitTypeStmt(NEW_INSTANCE,6,-1,"Lorg/mortbay/jetty/HttpException;");
                code.visitConstStmt(CONST_16,7, Integer.valueOf(400)); // int: 0x00000190  float:0.000000
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 6,7},new Method("Lorg/mortbay/jetty/HttpException;","<init>",new String[]{ "I"},"V"));
                code.visitStmt1R(THROW,6);
                code.visitLabel(L1);
                code.visitStmt1R(MOVE_EXCEPTION,6);
                code.visitStmt2R(MOVE_OBJECT,3,6);
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/log/Log;","isDebugEnabled",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitJumpStmt(IF_EQZ,6,-1,L8);
                code.visitLabel(L26);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3},new Method("Lorg/mortbay/log/Log;","ignore",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitLabel(L8);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L27);
                code.visitJumpStmt(IF_EQZ,5,-1,L29);
                code.visitLabel(L28);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Ljava/lang/Thread;","currentThread",new String[]{ },"Ljava/lang/Thread;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,5},new Method("Ljava/lang/Thread;","setName",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L29);
                code.visitJumpStmt(IF_NEZ,4,-1,L39);
                code.visitLabel(L30);
                code.visitFieldStmt(IGET_OBJECT,6,13,new Field("Lorg/mortbay/jetty/HttpConnection;","_request","Lorg/mortbay/jetty/Request;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/Request;","getContinuation",new String[]{ },"Lorg/mortbay/util/ajax/Continuation;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitJumpStmt(IF_EQZ,6,-1,L33);
                code.visitLabel(L31);
                code.visitConstStmt(CONST_STRING,6,"continuation still pending {}");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 12},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L32);
                code.visitFieldStmt(IGET_OBJECT,6,13,new Field("Lorg/mortbay/jetty/HttpConnection;","_request","Lorg/mortbay/jetty/Request;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/Request;","getContinuation",new String[]{ },"Lorg/mortbay/util/ajax/Continuation;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 6},new Method("Lorg/mortbay/util/ajax/Continuation;","reset",new String[]{ },"V"));
                code.visitLabel(L33);
                code.visitFieldStmt(IGET_OBJECT,6,13,new Field("Lorg/mortbay/jetty/HttpConnection;","_endp","Lorg/mortbay/io/EndPoint;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 6},new Method("Lorg/mortbay/io/EndPoint;","isOpen",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitJumpStmt(IF_EQZ,6,-1,L122);
                code.visitLabel(L34);
                code.visitFieldStmt(IGET_OBJECT,6,13,new Field("Lorg/mortbay/jetty/HttpConnection;","_generator","Lorg/mortbay/jetty/Generator;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 6},new Method("Lorg/mortbay/jetty/Generator;","isPersistent",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitJumpStmt(IF_EQZ,6,-1,L36);
                code.visitLabel(L35);
                code.visitFieldStmt(IGET_OBJECT,6,13,new Field("Lorg/mortbay/jetty/HttpConnection;","_connector","Lorg/mortbay/jetty/Connector;"));
                code.visitFieldStmt(IGET_OBJECT,7,13,new Field("Lorg/mortbay/jetty/HttpConnection;","_endp","Lorg/mortbay/io/EndPoint;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 6,7},new Method("Lorg/mortbay/jetty/Connector;","persist",new String[]{ "Lorg/mortbay/io/EndPoint;"},"V"));
                code.visitLabel(L36);
                code.visitJumpStmt(IF_EQZ,1,-1,L124);
                code.visitLabel(L37);
                code.visitFieldStmt(IGET_OBJECT,6,13,new Field("Lorg/mortbay/jetty/HttpConnection;","_endp","Lorg/mortbay/io/EndPoint;"));
                code.visitLabel(L38);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 6},new Method("Lorg/mortbay/io/EndPoint;","close",new String[]{ },"V"));
                code.visitLabel(L39);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L9);
                code.visitFieldStmt(IGET_OBJECT,6,13,new Field("Lorg/mortbay/jetty/HttpConnection;","_request","Lorg/mortbay/jetty/Request;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,2},new Method("Lorg/mortbay/jetty/Request;","setPathInfo",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L40);
                code.visitFieldStmt(IGET_OBJECT,6,13,new Field("Lorg/mortbay/jetty/HttpConnection;","_out","Lorg/mortbay/jetty/HttpConnection$Output;"));
                code.visitJumpStmt(IF_EQZ,6,-1,L42);
                code.visitLabel(L41);
                code.visitFieldStmt(IGET_OBJECT,6,13,new Field("Lorg/mortbay/jetty/HttpConnection;","_out","Lorg/mortbay/jetty/HttpConnection$Output;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/HttpConnection$Output;","reopen",new String[]{ },"V"));
                code.visitLabel(L42);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/log/Log;","isDebugEnabled",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitJumpStmt(IF_EQZ,6,-1,L45);
                code.visitLabel(L43);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Ljava/lang/Thread;","currentThread",new String[]{ },"Ljava/lang/Thread;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/lang/Thread;","getName",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitLabel(L44);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Ljava/lang/Thread;","currentThread",new String[]{ },"Ljava/lang/Thread;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitTypeStmt(NEW_INSTANCE,7,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 7},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitConstStmt(CONST_STRING,8," - ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,8},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitFieldStmt(IGET_OBJECT,8,13,new Field("Lorg/mortbay/jetty/HttpConnection;","_uri","Lorg/mortbay/jetty/HttpURI;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,8},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,7},new Method("Ljava/lang/Thread;","setName",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L45);
                code.visitFieldStmt(IGET_OBJECT,6,13,new Field("Lorg/mortbay/jetty/HttpConnection;","_connector","Lorg/mortbay/jetty/Connector;"));
                code.visitFieldStmt(IGET_OBJECT,7,13,new Field("Lorg/mortbay/jetty/HttpConnection;","_endp","Lorg/mortbay/io/EndPoint;"));
                code.visitFieldStmt(IGET_OBJECT,8,13,new Field("Lorg/mortbay/jetty/HttpConnection;","_request","Lorg/mortbay/jetty/Request;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 6,7,8},new Method("Lorg/mortbay/jetty/Connector;","customize",new String[]{ "Lorg/mortbay/io/EndPoint;","Lorg/mortbay/jetty/Request;"},"V"));
                code.visitLabel(L46);
                code.visitFieldStmt(IGET_OBJECT,6,13,new Field("Lorg/mortbay/jetty/HttpConnection;","_server","Lorg/mortbay/jetty/Server;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,13},new Method("Lorg/mortbay/jetty/Server;","handle",new String[]{ "Lorg/mortbay/jetty/HttpConnection;"},"V"));
                code.visitLabel(L10);
                code.visitJumpStmt(IF_EQZ,5,-1,L48);
                code.visitLabel(L47);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Ljava/lang/Thread;","currentThread",new String[]{ },"Ljava/lang/Thread;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,5},new Method("Ljava/lang/Thread;","setName",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L48);
                code.visitJumpStmt(IF_NEZ,4,-1,L39);
                code.visitLabel(L49);
                code.visitFieldStmt(IGET_OBJECT,6,13,new Field("Lorg/mortbay/jetty/HttpConnection;","_request","Lorg/mortbay/jetty/Request;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/Request;","getContinuation",new String[]{ },"Lorg/mortbay/util/ajax/Continuation;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitJumpStmt(IF_EQZ,6,-1,L52);
                code.visitLabel(L50);
                code.visitConstStmt(CONST_STRING,6,"continuation still pending {}");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 12},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L51);
                code.visitFieldStmt(IGET_OBJECT,6,13,new Field("Lorg/mortbay/jetty/HttpConnection;","_request","Lorg/mortbay/jetty/Request;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/Request;","getContinuation",new String[]{ },"Lorg/mortbay/util/ajax/Continuation;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 6},new Method("Lorg/mortbay/util/ajax/Continuation;","reset",new String[]{ },"V"));
                code.visitLabel(L52);
                code.visitFieldStmt(IGET_OBJECT,6,13,new Field("Lorg/mortbay/jetty/HttpConnection;","_endp","Lorg/mortbay/io/EndPoint;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 6},new Method("Lorg/mortbay/io/EndPoint;","isOpen",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitJumpStmt(IF_EQZ,6,-1,L144);
                code.visitLabel(L53);
                code.visitFieldStmt(IGET_OBJECT,6,13,new Field("Lorg/mortbay/jetty/HttpConnection;","_generator","Lorg/mortbay/jetty/Generator;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 6},new Method("Lorg/mortbay/jetty/Generator;","isPersistent",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitJumpStmt(IF_EQZ,6,-1,L55);
                code.visitLabel(L54);
                code.visitFieldStmt(IGET_OBJECT,6,13,new Field("Lorg/mortbay/jetty/HttpConnection;","_connector","Lorg/mortbay/jetty/Connector;"));
                code.visitFieldStmt(IGET_OBJECT,7,13,new Field("Lorg/mortbay/jetty/HttpConnection;","_endp","Lorg/mortbay/io/EndPoint;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 6,7},new Method("Lorg/mortbay/jetty/Connector;","persist",new String[]{ "Lorg/mortbay/io/EndPoint;"},"V"));
                code.visitLabel(L55);
                code.visitJumpStmt(IF_EQZ,1,-1,L145);
                code.visitLabel(L56);
                code.visitFieldStmt(IGET_OBJECT,6,13,new Field("Lorg/mortbay/jetty/HttpConnection;","_endp","Lorg/mortbay/io/EndPoint;"));
                code.visitJumpStmt(GOTO_16,-1,-1,L38);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,6);
                code.visitStmt2R(MOVE_OBJECT,0,6);
                code.visitLabel(L11);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/log/Log;","ignore",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitLabel(L12);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L57);
                code.visitJumpStmt(IF_EQZ,5,-1,L59);
                code.visitLabel(L58);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Ljava/lang/Thread;","currentThread",new String[]{ },"Ljava/lang/Thread;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,5},new Method("Ljava/lang/Thread;","setName",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L59);
                code.visitJumpStmt(IF_NEZ,4,-1,L39);
                code.visitLabel(L60);
                code.visitFieldStmt(IGET_OBJECT,6,13,new Field("Lorg/mortbay/jetty/HttpConnection;","_request","Lorg/mortbay/jetty/Request;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/Request;","getContinuation",new String[]{ },"Lorg/mortbay/util/ajax/Continuation;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitJumpStmt(IF_EQZ,6,-1,L63);
                code.visitLabel(L61);
                code.visitConstStmt(CONST_STRING,6,"continuation still pending {}");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 12},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L62);
                code.visitFieldStmt(IGET_OBJECT,6,13,new Field("Lorg/mortbay/jetty/HttpConnection;","_request","Lorg/mortbay/jetty/Request;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/Request;","getContinuation",new String[]{ },"Lorg/mortbay/util/ajax/Continuation;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 6},new Method("Lorg/mortbay/util/ajax/Continuation;","reset",new String[]{ },"V"));
                code.visitLabel(L63);
                code.visitFieldStmt(IGET_OBJECT,6,13,new Field("Lorg/mortbay/jetty/HttpConnection;","_endp","Lorg/mortbay/io/EndPoint;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 6},new Method("Lorg/mortbay/io/EndPoint;","isOpen",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitJumpStmt(IF_EQZ,6,-1,L128);
                code.visitLabel(L64);
                code.visitFieldStmt(IGET_OBJECT,6,13,new Field("Lorg/mortbay/jetty/HttpConnection;","_generator","Lorg/mortbay/jetty/Generator;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 6},new Method("Lorg/mortbay/jetty/Generator;","isPersistent",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitJumpStmt(IF_EQZ,6,-1,L66);
                code.visitLabel(L65);
                code.visitFieldStmt(IGET_OBJECT,6,13,new Field("Lorg/mortbay/jetty/HttpConnection;","_connector","Lorg/mortbay/jetty/Connector;"));
                code.visitFieldStmt(IGET_OBJECT,7,13,new Field("Lorg/mortbay/jetty/HttpConnection;","_endp","Lorg/mortbay/io/EndPoint;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 6,7},new Method("Lorg/mortbay/jetty/Connector;","persist",new String[]{ "Lorg/mortbay/io/EndPoint;"},"V"));
                code.visitLabel(L66);
                code.visitJumpStmt(IF_EQZ,1,-1,L129);
                code.visitLabel(L67);
                code.visitFieldStmt(IGET_OBJECT,6,13,new Field("Lorg/mortbay/jetty/HttpConnection;","_endp","Lorg/mortbay/io/EndPoint;"));
                code.visitJumpStmt(GOTO_16,-1,-1,L38);
                code.visitLabel(L3);
                code.visitStmt1R(MOVE_EXCEPTION,6);
                code.visitStmt2R(MOVE_OBJECT,0,6);
                code.visitLabel(L13);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitLabel(L68);
                code.visitFieldStmt(IGET_OBJECT,6,13,new Field("Lorg/mortbay/jetty/HttpConnection;","_request","Lorg/mortbay/jetty/Request;"));
                code.visitConstStmt(CONST_4,7, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,7},new Method("Lorg/mortbay/jetty/Request;","setHandled",new String[]{ "Z"},"V"));
                code.visitLabel(L69);
                code.visitFieldStmt(IGET_OBJECT,6,13,new Field("Lorg/mortbay/jetty/HttpConnection;","_response","Lorg/mortbay/jetty/Response;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/HttpException;","getStatus",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/HttpException;","getReason",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,7,8},new Method("Lorg/mortbay/jetty/Response;","sendError",new String[]{ "I","Ljava/lang/String;"},"V"));
                code.visitLabel(L14);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L70);
                code.visitJumpStmt(IF_EQZ,5,-1,L72);
                code.visitLabel(L71);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Ljava/lang/Thread;","currentThread",new String[]{ },"Ljava/lang/Thread;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,5},new Method("Ljava/lang/Thread;","setName",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L72);
                code.visitJumpStmt(IF_NEZ,4,-1,L39);
                code.visitLabel(L73);
                code.visitFieldStmt(IGET_OBJECT,6,13,new Field("Lorg/mortbay/jetty/HttpConnection;","_request","Lorg/mortbay/jetty/Request;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/Request;","getContinuation",new String[]{ },"Lorg/mortbay/util/ajax/Continuation;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitJumpStmt(IF_EQZ,6,-1,L76);
                code.visitLabel(L74);
                code.visitConstStmt(CONST_STRING,6,"continuation still pending {}");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 12},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L75);
                code.visitFieldStmt(IGET_OBJECT,6,13,new Field("Lorg/mortbay/jetty/HttpConnection;","_request","Lorg/mortbay/jetty/Request;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/Request;","getContinuation",new String[]{ },"Lorg/mortbay/util/ajax/Continuation;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 6},new Method("Lorg/mortbay/util/ajax/Continuation;","reset",new String[]{ },"V"));
                code.visitLabel(L76);
                code.visitFieldStmt(IGET_OBJECT,6,13,new Field("Lorg/mortbay/jetty/HttpConnection;","_endp","Lorg/mortbay/io/EndPoint;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 6},new Method("Lorg/mortbay/io/EndPoint;","isOpen",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitJumpStmt(IF_EQZ,6,-1,L132);
                code.visitLabel(L77);
                code.visitFieldStmt(IGET_OBJECT,6,13,new Field("Lorg/mortbay/jetty/HttpConnection;","_generator","Lorg/mortbay/jetty/Generator;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 6},new Method("Lorg/mortbay/jetty/Generator;","isPersistent",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitJumpStmt(IF_EQZ,6,-1,L79);
                code.visitLabel(L78);
                code.visitFieldStmt(IGET_OBJECT,6,13,new Field("Lorg/mortbay/jetty/HttpConnection;","_connector","Lorg/mortbay/jetty/Connector;"));
                code.visitFieldStmt(IGET_OBJECT,7,13,new Field("Lorg/mortbay/jetty/HttpConnection;","_endp","Lorg/mortbay/io/EndPoint;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 6,7},new Method("Lorg/mortbay/jetty/Connector;","persist",new String[]{ "Lorg/mortbay/io/EndPoint;"},"V"));
                code.visitLabel(L79);
                code.visitJumpStmt(IF_EQZ,1,-1,L133);
                code.visitLabel(L80);
                code.visitFieldStmt(IGET_OBJECT,6,13,new Field("Lorg/mortbay/jetty/HttpConnection;","_endp","Lorg/mortbay/io/EndPoint;"));
                code.visitJumpStmt(GOTO_16,-1,-1,L38);
                code.visitLabel(L4);
                code.visitStmt1R(MOVE_EXCEPTION,6);
                code.visitStmt2R(MOVE_OBJECT,0,6);
                code.visitLabel(L15);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/log/Log;","warn",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitLabel(L81);
                code.visitFieldStmt(IGET_OBJECT,6,13,new Field("Lorg/mortbay/jetty/HttpConnection;","_request","Lorg/mortbay/jetty/Request;"));
                code.visitConstStmt(CONST_4,7, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,7},new Method("Lorg/mortbay/jetty/Request;","setHandled",new String[]{ "Z"},"V"));
                code.visitLabel(L82);
                code.visitFieldStmt(IGET_OBJECT,6,13,new Field("Lorg/mortbay/jetty/HttpConnection;","_generator","Lorg/mortbay/jetty/Generator;"));
                code.visitConstStmt(CONST_16,7, Integer.valueOf(500)); // int: 0x000001f4  float:0.000000
                code.visitConstStmt(CONST_4,8, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitConstStmt(CONST_4,9, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitConstStmt(CONST_4,10, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 6,7,8,9,10},new Method("Lorg/mortbay/jetty/Generator;","sendError",new String[]{ "I","Ljava/lang/String;","Ljava/lang/String;","Z"},"V"));
                code.visitLabel(L16);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L83);
                code.visitJumpStmt(IF_EQZ,5,-1,L85);
                code.visitLabel(L84);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Ljava/lang/Thread;","currentThread",new String[]{ },"Ljava/lang/Thread;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,5},new Method("Ljava/lang/Thread;","setName",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L85);
                code.visitJumpStmt(IF_NEZ,4,-1,L39);
                code.visitLabel(L86);
                code.visitFieldStmt(IGET_OBJECT,6,13,new Field("Lorg/mortbay/jetty/HttpConnection;","_request","Lorg/mortbay/jetty/Request;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/Request;","getContinuation",new String[]{ },"Lorg/mortbay/util/ajax/Continuation;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitJumpStmt(IF_EQZ,6,-1,L89);
                code.visitLabel(L87);
                code.visitConstStmt(CONST_STRING,6,"continuation still pending {}");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 12},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L88);
                code.visitFieldStmt(IGET_OBJECT,6,13,new Field("Lorg/mortbay/jetty/HttpConnection;","_request","Lorg/mortbay/jetty/Request;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/Request;","getContinuation",new String[]{ },"Lorg/mortbay/util/ajax/Continuation;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 6},new Method("Lorg/mortbay/util/ajax/Continuation;","reset",new String[]{ },"V"));
                code.visitLabel(L89);
                code.visitFieldStmt(IGET_OBJECT,6,13,new Field("Lorg/mortbay/jetty/HttpConnection;","_endp","Lorg/mortbay/io/EndPoint;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 6},new Method("Lorg/mortbay/io/EndPoint;","isOpen",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitJumpStmt(IF_EQZ,6,-1,L136);
                code.visitLabel(L90);
                code.visitFieldStmt(IGET_OBJECT,6,13,new Field("Lorg/mortbay/jetty/HttpConnection;","_generator","Lorg/mortbay/jetty/Generator;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 6},new Method("Lorg/mortbay/jetty/Generator;","isPersistent",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitJumpStmt(IF_EQZ,6,-1,L92);
                code.visitLabel(L91);
                code.visitFieldStmt(IGET_OBJECT,6,13,new Field("Lorg/mortbay/jetty/HttpConnection;","_connector","Lorg/mortbay/jetty/Connector;"));
                code.visitFieldStmt(IGET_OBJECT,7,13,new Field("Lorg/mortbay/jetty/HttpConnection;","_endp","Lorg/mortbay/io/EndPoint;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 6,7},new Method("Lorg/mortbay/jetty/Connector;","persist",new String[]{ "Lorg/mortbay/io/EndPoint;"},"V"));
                code.visitLabel(L92);
                code.visitJumpStmt(IF_EQZ,1,-1,L137);
                code.visitLabel(L93);
                code.visitFieldStmt(IGET_OBJECT,6,13,new Field("Lorg/mortbay/jetty/HttpConnection;","_endp","Lorg/mortbay/io/EndPoint;"));
                code.visitJumpStmt(GOTO_16,-1,-1,L38);
                code.visitLabel(L5);
                code.visitStmt1R(MOVE_EXCEPTION,6);
                code.visitStmt2R(MOVE_OBJECT,0,6);
                code.visitLabel(L17);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/log/Log;","warn",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitLabel(L94);
                code.visitFieldStmt(IGET_OBJECT,6,13,new Field("Lorg/mortbay/jetty/HttpConnection;","_request","Lorg/mortbay/jetty/Request;"));
                code.visitConstStmt(CONST_4,7, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,7},new Method("Lorg/mortbay/jetty/Request;","setHandled",new String[]{ "Z"},"V"));
                code.visitLabel(L95);
                code.visitFieldStmt(IGET_OBJECT,6,13,new Field("Lorg/mortbay/jetty/HttpConnection;","_generator","Lorg/mortbay/jetty/Generator;"));
                code.visitConstStmt(CONST_16,7, Integer.valueOf(500)); // int: 0x000001f4  float:0.000000
                code.visitConstStmt(CONST_4,8, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitConstStmt(CONST_4,9, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitConstStmt(CONST_4,10, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 6,7,8,9,10},new Method("Lorg/mortbay/jetty/Generator;","sendError",new String[]{ "I","Ljava/lang/String;","Ljava/lang/String;","Z"},"V"));
                code.visitLabel(L18);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L96);
                code.visitJumpStmt(IF_EQZ,5,-1,L98);
                code.visitLabel(L97);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Ljava/lang/Thread;","currentThread",new String[]{ },"Ljava/lang/Thread;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,5},new Method("Ljava/lang/Thread;","setName",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L98);
                code.visitJumpStmt(IF_NEZ,4,-1,L39);
                code.visitLabel(L99);
                code.visitFieldStmt(IGET_OBJECT,6,13,new Field("Lorg/mortbay/jetty/HttpConnection;","_request","Lorg/mortbay/jetty/Request;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/Request;","getContinuation",new String[]{ },"Lorg/mortbay/util/ajax/Continuation;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitJumpStmt(IF_EQZ,6,-1,L102);
                code.visitLabel(L100);
                code.visitConstStmt(CONST_STRING,6,"continuation still pending {}");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 12},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L101);
                code.visitFieldStmt(IGET_OBJECT,6,13,new Field("Lorg/mortbay/jetty/HttpConnection;","_request","Lorg/mortbay/jetty/Request;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/Request;","getContinuation",new String[]{ },"Lorg/mortbay/util/ajax/Continuation;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 6},new Method("Lorg/mortbay/util/ajax/Continuation;","reset",new String[]{ },"V"));
                code.visitLabel(L102);
                code.visitFieldStmt(IGET_OBJECT,6,13,new Field("Lorg/mortbay/jetty/HttpConnection;","_endp","Lorg/mortbay/io/EndPoint;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 6},new Method("Lorg/mortbay/io/EndPoint;","isOpen",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitJumpStmt(IF_EQZ,6,-1,L140);
                code.visitLabel(L103);
                code.visitFieldStmt(IGET_OBJECT,6,13,new Field("Lorg/mortbay/jetty/HttpConnection;","_generator","Lorg/mortbay/jetty/Generator;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 6},new Method("Lorg/mortbay/jetty/Generator;","isPersistent",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitJumpStmt(IF_EQZ,6,-1,L105);
                code.visitLabel(L104);
                code.visitFieldStmt(IGET_OBJECT,6,13,new Field("Lorg/mortbay/jetty/HttpConnection;","_connector","Lorg/mortbay/jetty/Connector;"));
                code.visitFieldStmt(IGET_OBJECT,7,13,new Field("Lorg/mortbay/jetty/HttpConnection;","_endp","Lorg/mortbay/io/EndPoint;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 6,7},new Method("Lorg/mortbay/jetty/Connector;","persist",new String[]{ "Lorg/mortbay/io/EndPoint;"},"V"));
                code.visitLabel(L105);
                code.visitJumpStmt(IF_EQZ,1,-1,L141);
                code.visitLabel(L106);
                code.visitFieldStmt(IGET_OBJECT,6,13,new Field("Lorg/mortbay/jetty/HttpConnection;","_endp","Lorg/mortbay/io/EndPoint;"));
                code.visitJumpStmt(GOTO_16,-1,-1,L38);
                code.visitLabel(L6);
                code.visitStmt1R(MOVE_EXCEPTION,6);
                code.visitJumpStmt(IF_EQZ,5,-1,L108);
                code.visitLabel(L107);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Ljava/lang/Thread;","currentThread",new String[]{ },"Ljava/lang/Thread;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,5},new Method("Ljava/lang/Thread;","setName",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L108);
                code.visitJumpStmt(IF_NEZ,4,-1,L117);
                code.visitLabel(L109);
                code.visitFieldStmt(IGET_OBJECT,7,13,new Field("Lorg/mortbay/jetty/HttpConnection;","_request","Lorg/mortbay/jetty/Request;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Lorg/mortbay/jetty/Request;","getContinuation",new String[]{ },"Lorg/mortbay/util/ajax/Continuation;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitJumpStmt(IF_EQZ,7,-1,L112);
                code.visitLabel(L110);
                code.visitConstStmt(CONST_STRING,7,"continuation still pending {}");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 12},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L111);
                code.visitFieldStmt(IGET_OBJECT,7,13,new Field("Lorg/mortbay/jetty/HttpConnection;","_request","Lorg/mortbay/jetty/Request;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Lorg/mortbay/jetty/Request;","getContinuation",new String[]{ },"Lorg/mortbay/util/ajax/Continuation;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 7},new Method("Lorg/mortbay/util/ajax/Continuation;","reset",new String[]{ },"V"));
                code.visitLabel(L112);
                code.visitFieldStmt(IGET_OBJECT,7,13,new Field("Lorg/mortbay/jetty/HttpConnection;","_endp","Lorg/mortbay/io/EndPoint;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 7},new Method("Lorg/mortbay/io/EndPoint;","isOpen",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitJumpStmt(IF_EQZ,7,-1,L118);
                code.visitLabel(L113);
                code.visitFieldStmt(IGET_OBJECT,7,13,new Field("Lorg/mortbay/jetty/HttpConnection;","_generator","Lorg/mortbay/jetty/Generator;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 7},new Method("Lorg/mortbay/jetty/Generator;","isPersistent",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitJumpStmt(IF_EQZ,7,-1,L115);
                code.visitLabel(L114);
                code.visitFieldStmt(IGET_OBJECT,7,13,new Field("Lorg/mortbay/jetty/HttpConnection;","_connector","Lorg/mortbay/jetty/Connector;"));
                code.visitFieldStmt(IGET_OBJECT,8,13,new Field("Lorg/mortbay/jetty/HttpConnection;","_endp","Lorg/mortbay/io/EndPoint;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 7,8},new Method("Lorg/mortbay/jetty/Connector;","persist",new String[]{ "Lorg/mortbay/io/EndPoint;"},"V"));
                code.visitLabel(L115);
                code.visitJumpStmt(IF_EQZ,1,-1,L119);
                code.visitLabel(L116);
                code.visitFieldStmt(IGET_OBJECT,7,13,new Field("Lorg/mortbay/jetty/HttpConnection;","_endp","Lorg/mortbay/io/EndPoint;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 7},new Method("Lorg/mortbay/io/EndPoint;","close",new String[]{ },"V"));
                code.visitLabel(L117);
                code.visitStmt1R(THROW,6);
                code.visitLabel(L118);
                code.visitFieldStmt(IGET_OBJECT,7,13,new Field("Lorg/mortbay/jetty/HttpConnection;","_response","Lorg/mortbay/jetty/Response;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Lorg/mortbay/jetty/Response;","complete",new String[]{ },"V"));
                code.visitJumpStmt(GOTO,-1,-1,L117);
                code.visitLabel(L119);
                code.visitFieldStmt(IGET_OBJECT,7,13,new Field("Lorg/mortbay/jetty/HttpConnection;","_response","Lorg/mortbay/jetty/Response;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Lorg/mortbay/jetty/Response;","isCommitted",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitJumpStmt(IF_NEZ,7,-1,L121);
                code.visitFieldStmt(IGET_OBJECT,7,13,new Field("Lorg/mortbay/jetty/HttpConnection;","_request","Lorg/mortbay/jetty/Request;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Lorg/mortbay/jetty/Request;","isHandled",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitJumpStmt(IF_NEZ,7,-1,L121);
                code.visitLabel(L120);
                code.visitFieldStmt(IGET_OBJECT,7,13,new Field("Lorg/mortbay/jetty/HttpConnection;","_response","Lorg/mortbay/jetty/Response;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,11},new Method("Lorg/mortbay/jetty/Response;","sendError",new String[]{ "I"},"V"));
                code.visitLabel(L121);
                code.visitFieldStmt(IGET_OBJECT,7,13,new Field("Lorg/mortbay/jetty/HttpConnection;","_response","Lorg/mortbay/jetty/Response;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Lorg/mortbay/jetty/Response;","complete",new String[]{ },"V"));
                code.visitJumpStmt(GOTO,-1,-1,L117);
                code.visitLabel(L122);
                code.visitFieldStmt(IGET_OBJECT,6,13,new Field("Lorg/mortbay/jetty/HttpConnection;","_response","Lorg/mortbay/jetty/Response;"));
                code.visitLabel(L123);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/Response;","complete",new String[]{ },"V"));
                code.visitJumpStmt(GOTO_16,-1,-1,L39);
                code.visitLabel(L124);
                code.visitFieldStmt(IGET_OBJECT,6,13,new Field("Lorg/mortbay/jetty/HttpConnection;","_response","Lorg/mortbay/jetty/Response;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/Response;","isCommitted",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitJumpStmt(IF_NEZ,6,-1,L126);
                code.visitFieldStmt(IGET_OBJECT,6,13,new Field("Lorg/mortbay/jetty/HttpConnection;","_request","Lorg/mortbay/jetty/Request;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/Request;","isHandled",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitJumpStmt(IF_NEZ,6,-1,L126);
                code.visitLabel(L125);
                code.visitFieldStmt(IGET_OBJECT,6,13,new Field("Lorg/mortbay/jetty/HttpConnection;","_response","Lorg/mortbay/jetty/Response;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,11},new Method("Lorg/mortbay/jetty/Response;","sendError",new String[]{ "I"},"V"));
                code.visitLabel(L126);
                code.visitFieldStmt(IGET_OBJECT,6,13,new Field("Lorg/mortbay/jetty/HttpConnection;","_response","Lorg/mortbay/jetty/Response;"));
                code.visitLabel(L127);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/Response;","complete",new String[]{ },"V"));
                code.visitJumpStmt(GOTO_16,-1,-1,L39);
                code.visitLabel(L128);
                code.visitFieldStmt(IGET_OBJECT,6,13,new Field("Lorg/mortbay/jetty/HttpConnection;","_response","Lorg/mortbay/jetty/Response;"));
                code.visitJumpStmt(GOTO,-1,-1,L123);
                code.visitLabel(L129);
                code.visitFieldStmt(IGET_OBJECT,6,13,new Field("Lorg/mortbay/jetty/HttpConnection;","_response","Lorg/mortbay/jetty/Response;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/Response;","isCommitted",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitJumpStmt(IF_NEZ,6,-1,L131);
                code.visitFieldStmt(IGET_OBJECT,6,13,new Field("Lorg/mortbay/jetty/HttpConnection;","_request","Lorg/mortbay/jetty/Request;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/Request;","isHandled",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitJumpStmt(IF_NEZ,6,-1,L131);
                code.visitLabel(L130);
                code.visitFieldStmt(IGET_OBJECT,6,13,new Field("Lorg/mortbay/jetty/HttpConnection;","_response","Lorg/mortbay/jetty/Response;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,11},new Method("Lorg/mortbay/jetty/Response;","sendError",new String[]{ "I"},"V"));
                code.visitLabel(L131);
                code.visitFieldStmt(IGET_OBJECT,6,13,new Field("Lorg/mortbay/jetty/HttpConnection;","_response","Lorg/mortbay/jetty/Response;"));
                code.visitJumpStmt(GOTO,-1,-1,L127);
                code.visitLabel(L132);
                code.visitFieldStmt(IGET_OBJECT,6,13,new Field("Lorg/mortbay/jetty/HttpConnection;","_response","Lorg/mortbay/jetty/Response;"));
                code.visitJumpStmt(GOTO,-1,-1,L123);
                code.visitLabel(L133);
                code.visitFieldStmt(IGET_OBJECT,6,13,new Field("Lorg/mortbay/jetty/HttpConnection;","_response","Lorg/mortbay/jetty/Response;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/Response;","isCommitted",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitJumpStmt(IF_NEZ,6,-1,L135);
                code.visitFieldStmt(IGET_OBJECT,6,13,new Field("Lorg/mortbay/jetty/HttpConnection;","_request","Lorg/mortbay/jetty/Request;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/Request;","isHandled",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitJumpStmt(IF_NEZ,6,-1,L135);
                code.visitLabel(L134);
                code.visitFieldStmt(IGET_OBJECT,6,13,new Field("Lorg/mortbay/jetty/HttpConnection;","_response","Lorg/mortbay/jetty/Response;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,11},new Method("Lorg/mortbay/jetty/Response;","sendError",new String[]{ "I"},"V"));
                code.visitLabel(L135);
                code.visitFieldStmt(IGET_OBJECT,6,13,new Field("Lorg/mortbay/jetty/HttpConnection;","_response","Lorg/mortbay/jetty/Response;"));
                code.visitJumpStmt(GOTO,-1,-1,L127);
                code.visitLabel(L136);
                code.visitFieldStmt(IGET_OBJECT,6,13,new Field("Lorg/mortbay/jetty/HttpConnection;","_response","Lorg/mortbay/jetty/Response;"));
                code.visitJumpStmt(GOTO,-1,-1,L123);
                code.visitLabel(L137);
                code.visitFieldStmt(IGET_OBJECT,6,13,new Field("Lorg/mortbay/jetty/HttpConnection;","_response","Lorg/mortbay/jetty/Response;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/Response;","isCommitted",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitJumpStmt(IF_NEZ,6,-1,L139);
                code.visitFieldStmt(IGET_OBJECT,6,13,new Field("Lorg/mortbay/jetty/HttpConnection;","_request","Lorg/mortbay/jetty/Request;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/Request;","isHandled",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitJumpStmt(IF_NEZ,6,-1,L139);
                code.visitLabel(L138);
                code.visitFieldStmt(IGET_OBJECT,6,13,new Field("Lorg/mortbay/jetty/HttpConnection;","_response","Lorg/mortbay/jetty/Response;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,11},new Method("Lorg/mortbay/jetty/Response;","sendError",new String[]{ "I"},"V"));
                code.visitLabel(L139);
                code.visitFieldStmt(IGET_OBJECT,6,13,new Field("Lorg/mortbay/jetty/HttpConnection;","_response","Lorg/mortbay/jetty/Response;"));
                code.visitJumpStmt(GOTO,-1,-1,L127);
                code.visitLabel(L140);
                code.visitFieldStmt(IGET_OBJECT,6,13,new Field("Lorg/mortbay/jetty/HttpConnection;","_response","Lorg/mortbay/jetty/Response;"));
                code.visitJumpStmt(GOTO,-1,-1,L123);
                code.visitLabel(L141);
                code.visitFieldStmt(IGET_OBJECT,6,13,new Field("Lorg/mortbay/jetty/HttpConnection;","_response","Lorg/mortbay/jetty/Response;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/Response;","isCommitted",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitJumpStmt(IF_NEZ,6,-1,L143);
                code.visitFieldStmt(IGET_OBJECT,6,13,new Field("Lorg/mortbay/jetty/HttpConnection;","_request","Lorg/mortbay/jetty/Request;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/Request;","isHandled",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitJumpStmt(IF_NEZ,6,-1,L143);
                code.visitLabel(L142);
                code.visitFieldStmt(IGET_OBJECT,6,13,new Field("Lorg/mortbay/jetty/HttpConnection;","_response","Lorg/mortbay/jetty/Response;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,11},new Method("Lorg/mortbay/jetty/Response;","sendError",new String[]{ "I"},"V"));
                code.visitLabel(L143);
                code.visitFieldStmt(IGET_OBJECT,6,13,new Field("Lorg/mortbay/jetty/HttpConnection;","_response","Lorg/mortbay/jetty/Response;"));
                code.visitJumpStmt(GOTO,-1,-1,L127);
                code.visitLabel(L144);
                code.visitFieldStmt(IGET_OBJECT,6,13,new Field("Lorg/mortbay/jetty/HttpConnection;","_response","Lorg/mortbay/jetty/Response;"));
                code.visitJumpStmt(GOTO_16,-1,-1,L123);
                code.visitLabel(L145);
                code.visitFieldStmt(IGET_OBJECT,6,13,new Field("Lorg/mortbay/jetty/HttpConnection;","_response","Lorg/mortbay/jetty/Response;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/Response;","isCommitted",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitJumpStmt(IF_NEZ,6,-1,L147);
                code.visitFieldStmt(IGET_OBJECT,6,13,new Field("Lorg/mortbay/jetty/HttpConnection;","_request","Lorg/mortbay/jetty/Request;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/Request;","isHandled",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitJumpStmt(IF_NEZ,6,-1,L147);
                code.visitLabel(L146);
                code.visitFieldStmt(IGET_OBJECT,6,13,new Field("Lorg/mortbay/jetty/HttpConnection;","_response","Lorg/mortbay/jetty/Response;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,11},new Method("Lorg/mortbay/jetty/Response;","sendError",new String[]{ "I"},"V"));
                code.visitLabel(L147);
                code.visitFieldStmt(IGET_OBJECT,6,13,new Field("Lorg/mortbay/jetty/HttpConnection;","_response","Lorg/mortbay/jetty/Response;"));
                code.visitJumpStmt(GOTO_16,-1,-1,L127);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m038_include(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpConnection;","include",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(658,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(659,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,1,new Field("Lorg/mortbay/jetty/HttpConnection;","_include","I"));
                code.visitStmt2R1N(ADD_INT_LIT8,0,0,1);
                code.visitFieldStmt(IPUT,0,1,new Field("Lorg/mortbay/jetty/HttpConnection;","_include","I"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m039_included(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpConnection;","included",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(664,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(665,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(666,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(667,L3);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,2,new Field("Lorg/mortbay/jetty/HttpConnection;","_include","I"));
                code.visitConstStmt(CONST_4,1, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt2R(SUB_INT_2ADDR,0,1);
                code.visitFieldStmt(IPUT,0,2,new Field("Lorg/mortbay/jetty/HttpConnection;","_include","I"));
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/HttpConnection;","_out","Lorg/mortbay/jetty/HttpConnection$Output;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L3);
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/HttpConnection;","_out","Lorg/mortbay/jetty/HttpConnection$Output;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/HttpConnection$Output;","reopen",new String[]{ },"V"));
                code.visitLabel(L3);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m040_isConfidential(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpConnection;","isConfidential",new String[]{ "Lorg/mortbay/jetty/Request;"},"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"request");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(247,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(248,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(249,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/HttpConnection;","_connector","Lorg/mortbay/jetty/Connector;"));
                DexLabel L3=new DexLabel();
                code.visitJumpStmt(IF_EQZ,0,-1,L3);
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/HttpConnection;","_connector","Lorg/mortbay/jetty/Connector;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,2},new Method("Lorg/mortbay/jetty/Connector;","isConfidential",new String[]{ "Lorg/mortbay/jetty/Request;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitLabel(L2);
                code.visitStmt1R(RETURN,0);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m041_isIdle(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpConnection;","isIdle",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(672,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/HttpConnection;","_generator","Lorg/mortbay/jetty/Generator;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Lorg/mortbay/jetty/Generator;","isIdle",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                DexLabel L1=new DexLabel();
                code.visitJumpStmt(IF_EQZ,0,-1,L1);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/HttpConnection;","_parser","Lorg/mortbay/jetty/Parser;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Lorg/mortbay/jetty/Parser;","isIdle",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                DexLabel L2=new DexLabel();
                code.visitJumpStmt(IF_NEZ,0,-1,L2);
                code.visitFieldStmt(IGET_BOOLEAN,0,1,new Field("Lorg/mortbay/jetty/HttpConnection;","_delayedHandling","Z"));
                code.visitJumpStmt(IF_EQZ,0,-1,L1);
                code.visitLabel(L2);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                DexLabel L3=new DexLabel();
                code.visitLabel(L3);
                code.visitStmt1R(RETURN,0);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m042_isIncluding(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpConnection;","isIncluding",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(652,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,1,new Field("Lorg/mortbay/jetty/HttpConnection;","_include","I"));
                DexLabel L1=new DexLabel();
                code.visitJumpStmt(IF_LEZ,0,-1,L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                DexLabel L2=new DexLabel();
                code.visitLabel(L2);
                code.visitStmt1R(RETURN,0);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m043_isIntegral(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpConnection;","isIntegral",new String[]{ "Lorg/mortbay/jetty/Request;"},"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"request");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(263,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(264,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(265,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/HttpConnection;","_connector","Lorg/mortbay/jetty/Connector;"));
                DexLabel L3=new DexLabel();
                code.visitJumpStmt(IF_EQZ,0,-1,L3);
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/HttpConnection;","_connector","Lorg/mortbay/jetty/Connector;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,2},new Method("Lorg/mortbay/jetty/Connector;","isIntegral",new String[]{ "Lorg/mortbay/jetty/Request;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitLabel(L2);
                code.visitStmt1R(RETURN,0);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m044_isResponseCommitted(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpConnection;","isResponseCommitted",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(367,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/HttpConnection;","_generator","Lorg/mortbay/jetty/Generator;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Lorg/mortbay/jetty/Generator;","isCommitted",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m045_reset(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpConnection;","reset",new String[]{ "Z"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"returnBuffers");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(495,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(497,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(498,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(500,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(502,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(503,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(505,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(506,L7);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/HttpConnection;","_parser","Lorg/mortbay/jetty/Parser;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,2},new Method("Lorg/mortbay/jetty/Parser;","reset",new String[]{ "Z"},"V"));
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/HttpConnection;","_requestFields","Lorg/mortbay/jetty/HttpFields;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/HttpFields;","clear",new String[]{ },"V"));
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/HttpConnection;","_request","Lorg/mortbay/jetty/Request;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/Request;","recycle",new String[]{ },"V"));
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/HttpConnection;","_generator","Lorg/mortbay/jetty/Generator;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,2},new Method("Lorg/mortbay/jetty/Generator;","reset",new String[]{ "Z"},"V"));
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/HttpConnection;","_responseFields","Lorg/mortbay/jetty/HttpFields;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/HttpFields;","clear",new String[]{ },"V"));
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/HttpConnection;","_response","Lorg/mortbay/jetty/Response;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/Response;","recycle",new String[]{ },"V"));
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/HttpConnection;","_uri","Lorg/mortbay/jetty/HttpURI;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/HttpURI;","clear",new String[]{ },"V"));
                code.visitLabel(L7);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m046_setAssociatedObject(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpConnection;","setAssociatedObject",new String[]{ "Ljava/lang/Object;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"associatedObject");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(209,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(210,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/HttpConnection;","_associatedObject","Ljava/lang/Object;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
