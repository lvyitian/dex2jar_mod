package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0029_javax_servlet_http_HttpServletResponse {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC|ACC_INTERFACE|ACC_ABSTRACT,"Ljavax/servlet/http/HttpServletResponse;","Ljava/lang/Object;",new String[]{ "Ljavax/servlet/ServletResponse;"});
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("HttpServletResponse.java");
        f000_SC_ACCEPTED(cv);
        f001_SC_BAD_GATEWAY(cv);
        f002_SC_BAD_REQUEST(cv);
        f003_SC_CONFLICT(cv);
        f004_SC_CONTINUE(cv);
        f005_SC_CREATED(cv);
        f006_SC_EXPECTATION_FAILED(cv);
        f007_SC_FORBIDDEN(cv);
        f008_SC_FOUND(cv);
        f009_SC_GATEWAY_TIMEOUT(cv);
        f010_SC_GONE(cv);
        f011_SC_HTTP_VERSION_NOT_SUPPORTED(cv);
        f012_SC_INTERNAL_SERVER_ERROR(cv);
        f013_SC_LENGTH_REQUIRED(cv);
        f014_SC_METHOD_NOT_ALLOWED(cv);
        f015_SC_MOVED_PERMANENTLY(cv);
        f016_SC_MOVED_TEMPORARILY(cv);
        f017_SC_MULTIPLE_CHOICES(cv);
        f018_SC_NON_AUTHORITATIVE_INFORMATION(cv);
        f019_SC_NOT_ACCEPTABLE(cv);
        f020_SC_NOT_FOUND(cv);
        f021_SC_NOT_IMPLEMENTED(cv);
        f022_SC_NOT_MODIFIED(cv);
        f023_SC_NO_CONTENT(cv);
        f024_SC_OK(cv);
        f025_SC_PARTIAL_CONTENT(cv);
        f026_SC_PAYMENT_REQUIRED(cv);
        f027_SC_PRECONDITION_FAILED(cv);
        f028_SC_PROXY_AUTHENTICATION_REQUIRED(cv);
        f029_SC_REQUESTED_RANGE_NOT_SATISFIABLE(cv);
        f030_SC_REQUEST_ENTITY_TOO_LARGE(cv);
        f031_SC_REQUEST_TIMEOUT(cv);
        f032_SC_REQUEST_URI_TOO_LONG(cv);
        f033_SC_RESET_CONTENT(cv);
        f034_SC_SEE_OTHER(cv);
        f035_SC_SERVICE_UNAVAILABLE(cv);
        f036_SC_SWITCHING_PROTOCOLS(cv);
        f037_SC_TEMPORARY_REDIRECT(cv);
        f038_SC_UNAUTHORIZED(cv);
        f039_SC_UNSUPPORTED_MEDIA_TYPE(cv);
        f040_SC_USE_PROXY(cv);
        m000_addCookie(cv);
        m001_addDateHeader(cv);
        m002_addHeader(cv);
        m003_addIntHeader(cv);
        m004_containsHeader(cv);
        m005_encodeRedirectURL(cv);
        m006_encodeRedirectUrl(cv);
        m007_encodeURL(cv);
        m008_encodeUrl(cv);
        m009_sendError(cv);
        m010_sendError(cv);
        m011_sendRedirect(cv);
        m012_setDateHeader(cv);
        m013_setHeader(cv);
        m014_setIntHeader(cv);
        m015_setStatus(cv);
        m016_setStatus(cv);
    }
    public static void f000_SC_ACCEPTED(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Ljavax/servlet/http/HttpServletResponse;","SC_ACCEPTED","I"),  Integer.valueOf(202));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001_SC_BAD_GATEWAY(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Ljavax/servlet/http/HttpServletResponse;","SC_BAD_GATEWAY","I"),  Integer.valueOf(502));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002_SC_BAD_REQUEST(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Ljavax/servlet/http/HttpServletResponse;","SC_BAD_REQUEST","I"),  Integer.valueOf(400));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003_SC_CONFLICT(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Ljavax/servlet/http/HttpServletResponse;","SC_CONFLICT","I"),  Integer.valueOf(409));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f004_SC_CONTINUE(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Ljavax/servlet/http/HttpServletResponse;","SC_CONTINUE","I"),  Integer.valueOf(100));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f005_SC_CREATED(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Ljavax/servlet/http/HttpServletResponse;","SC_CREATED","I"),  Integer.valueOf(201));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f006_SC_EXPECTATION_FAILED(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Ljavax/servlet/http/HttpServletResponse;","SC_EXPECTATION_FAILED","I"),  Integer.valueOf(417));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f007_SC_FORBIDDEN(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Ljavax/servlet/http/HttpServletResponse;","SC_FORBIDDEN","I"),  Integer.valueOf(403));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f008_SC_FOUND(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Ljavax/servlet/http/HttpServletResponse;","SC_FOUND","I"),  Integer.valueOf(302));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f009_SC_GATEWAY_TIMEOUT(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Ljavax/servlet/http/HttpServletResponse;","SC_GATEWAY_TIMEOUT","I"),  Integer.valueOf(504));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f010_SC_GONE(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Ljavax/servlet/http/HttpServletResponse;","SC_GONE","I"),  Integer.valueOf(410));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f011_SC_HTTP_VERSION_NOT_SUPPORTED(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Ljavax/servlet/http/HttpServletResponse;","SC_HTTP_VERSION_NOT_SUPPORTED","I"),  Integer.valueOf(505));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f012_SC_INTERNAL_SERVER_ERROR(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Ljavax/servlet/http/HttpServletResponse;","SC_INTERNAL_SERVER_ERROR","I"),  Integer.valueOf(500));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f013_SC_LENGTH_REQUIRED(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Ljavax/servlet/http/HttpServletResponse;","SC_LENGTH_REQUIRED","I"),  Integer.valueOf(411));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f014_SC_METHOD_NOT_ALLOWED(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Ljavax/servlet/http/HttpServletResponse;","SC_METHOD_NOT_ALLOWED","I"),  Integer.valueOf(405));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f015_SC_MOVED_PERMANENTLY(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Ljavax/servlet/http/HttpServletResponse;","SC_MOVED_PERMANENTLY","I"),  Integer.valueOf(301));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f016_SC_MOVED_TEMPORARILY(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Ljavax/servlet/http/HttpServletResponse;","SC_MOVED_TEMPORARILY","I"),  Integer.valueOf(302));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f017_SC_MULTIPLE_CHOICES(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Ljavax/servlet/http/HttpServletResponse;","SC_MULTIPLE_CHOICES","I"),  Integer.valueOf(300));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f018_SC_NON_AUTHORITATIVE_INFORMATION(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Ljavax/servlet/http/HttpServletResponse;","SC_NON_AUTHORITATIVE_INFORMATION","I"),  Integer.valueOf(203));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f019_SC_NOT_ACCEPTABLE(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Ljavax/servlet/http/HttpServletResponse;","SC_NOT_ACCEPTABLE","I"),  Integer.valueOf(406));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f020_SC_NOT_FOUND(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Ljavax/servlet/http/HttpServletResponse;","SC_NOT_FOUND","I"),  Integer.valueOf(404));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f021_SC_NOT_IMPLEMENTED(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Ljavax/servlet/http/HttpServletResponse;","SC_NOT_IMPLEMENTED","I"),  Integer.valueOf(501));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f022_SC_NOT_MODIFIED(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Ljavax/servlet/http/HttpServletResponse;","SC_NOT_MODIFIED","I"),  Integer.valueOf(304));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f023_SC_NO_CONTENT(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Ljavax/servlet/http/HttpServletResponse;","SC_NO_CONTENT","I"),  Integer.valueOf(204));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f024_SC_OK(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Ljavax/servlet/http/HttpServletResponse;","SC_OK","I"),  Integer.valueOf(200));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f025_SC_PARTIAL_CONTENT(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Ljavax/servlet/http/HttpServletResponse;","SC_PARTIAL_CONTENT","I"),  Integer.valueOf(206));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f026_SC_PAYMENT_REQUIRED(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Ljavax/servlet/http/HttpServletResponse;","SC_PAYMENT_REQUIRED","I"),  Integer.valueOf(402));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f027_SC_PRECONDITION_FAILED(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Ljavax/servlet/http/HttpServletResponse;","SC_PRECONDITION_FAILED","I"),  Integer.valueOf(412));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f028_SC_PROXY_AUTHENTICATION_REQUIRED(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Ljavax/servlet/http/HttpServletResponse;","SC_PROXY_AUTHENTICATION_REQUIRED","I"),  Integer.valueOf(407));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f029_SC_REQUESTED_RANGE_NOT_SATISFIABLE(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Ljavax/servlet/http/HttpServletResponse;","SC_REQUESTED_RANGE_NOT_SATISFIABLE","I"),  Integer.valueOf(416));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f030_SC_REQUEST_ENTITY_TOO_LARGE(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Ljavax/servlet/http/HttpServletResponse;","SC_REQUEST_ENTITY_TOO_LARGE","I"),  Integer.valueOf(413));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f031_SC_REQUEST_TIMEOUT(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Ljavax/servlet/http/HttpServletResponse;","SC_REQUEST_TIMEOUT","I"),  Integer.valueOf(408));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f032_SC_REQUEST_URI_TOO_LONG(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Ljavax/servlet/http/HttpServletResponse;","SC_REQUEST_URI_TOO_LONG","I"),  Integer.valueOf(414));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f033_SC_RESET_CONTENT(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Ljavax/servlet/http/HttpServletResponse;","SC_RESET_CONTENT","I"),  Integer.valueOf(205));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f034_SC_SEE_OTHER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Ljavax/servlet/http/HttpServletResponse;","SC_SEE_OTHER","I"),  Integer.valueOf(303));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f035_SC_SERVICE_UNAVAILABLE(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Ljavax/servlet/http/HttpServletResponse;","SC_SERVICE_UNAVAILABLE","I"),  Integer.valueOf(503));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f036_SC_SWITCHING_PROTOCOLS(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Ljavax/servlet/http/HttpServletResponse;","SC_SWITCHING_PROTOCOLS","I"),  Integer.valueOf(101));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f037_SC_TEMPORARY_REDIRECT(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Ljavax/servlet/http/HttpServletResponse;","SC_TEMPORARY_REDIRECT","I"),  Integer.valueOf(307));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f038_SC_UNAUTHORIZED(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Ljavax/servlet/http/HttpServletResponse;","SC_UNAUTHORIZED","I"),  Integer.valueOf(401));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f039_SC_UNSUPPORTED_MEDIA_TYPE(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Ljavax/servlet/http/HttpServletResponse;","SC_UNSUPPORTED_MEDIA_TYPE","I"),  Integer.valueOf(415));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f040_SC_USE_PROXY(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Ljavax/servlet/http/HttpServletResponse;","SC_USE_PROXY","I"),  Integer.valueOf(305));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000_addCookie(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Ljavax/servlet/http/HttpServletResponse;","addCookie",new String[]{ "Ljavax/servlet/http/Cookie;"},"V"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m001_addDateHeader(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Ljavax/servlet/http/HttpServletResponse;","addDateHeader",new String[]{ "Ljava/lang/String;","J"},"V"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m002_addHeader(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Ljavax/servlet/http/HttpServletResponse;","addHeader",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"V"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m003_addIntHeader(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Ljavax/servlet/http/HttpServletResponse;","addIntHeader",new String[]{ "Ljava/lang/String;","I"},"V"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m004_containsHeader(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Ljavax/servlet/http/HttpServletResponse;","containsHeader",new String[]{ "Ljava/lang/String;"},"Z"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m005_encodeRedirectURL(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Ljavax/servlet/http/HttpServletResponse;","encodeRedirectURL",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m006_encodeRedirectUrl(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Ljavax/servlet/http/HttpServletResponse;","encodeRedirectUrl",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m007_encodeURL(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Ljavax/servlet/http/HttpServletResponse;","encodeURL",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m008_encodeUrl(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Ljavax/servlet/http/HttpServletResponse;","encodeUrl",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m009_sendError(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Ljavax/servlet/http/HttpServletResponse;","sendError",new String[]{ "I"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            mv.visitEnd();
        }
    }
    public static void m010_sendError(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Ljavax/servlet/http/HttpServletResponse;","sendError",new String[]{ "I","Ljava/lang/String;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            mv.visitEnd();
        }
    }
    public static void m011_sendRedirect(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Ljavax/servlet/http/HttpServletResponse;","sendRedirect",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            mv.visitEnd();
        }
    }
    public static void m012_setDateHeader(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Ljavax/servlet/http/HttpServletResponse;","setDateHeader",new String[]{ "Ljava/lang/String;","J"},"V"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m013_setHeader(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Ljavax/servlet/http/HttpServletResponse;","setHeader",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"V"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m014_setIntHeader(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Ljavax/servlet/http/HttpServletResponse;","setIntHeader",new String[]{ "Ljava/lang/String;","I"},"V"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m015_setStatus(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Ljavax/servlet/http/HttpServletResponse;","setStatus",new String[]{ "I"},"V"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m016_setStatus(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Ljavax/servlet/http/HttpServletResponse;","setStatus",new String[]{ "I","Ljava/lang/String;"},"V"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
}
