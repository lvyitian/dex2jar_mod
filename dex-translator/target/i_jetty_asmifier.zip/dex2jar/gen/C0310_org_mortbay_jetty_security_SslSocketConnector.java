package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0310_org_mortbay_jetty_security_SslSocketConnector {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/jetty/security/SslSocketConnector;","Lorg/mortbay/jetty/bio/SocketConnector;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("SslSocketConnector.java");
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/MemberClasses;", Visibility.SYSTEM);
            if(av00 != null) {
                {
                    DexAnnotationVisitor av01 = av00.visitArray("value");
                    if(av01 != null) {
                        av01.visit(null, new DexType("Lorg/mortbay/jetty/security/SslSocketConnector$SslConnection;"));
                        av01.visit(null, new DexType("Lorg/mortbay/jetty/security/SslSocketConnector$CachedInfo;"));
                        av01.visitEnd();
                    }
                }
                av00.visitEnd();
            }
        }
        f000_CACHED_INFO_ATTR(cv);
        f001_DEFAULT_KEYSTORE(cv);
        f002_KEYPASSWORD_PROPERTY(cv);
        f003_PASSWORD_PROPERTY(cv);
        f004__excludeCipherSuites(cv);
        f005__handshakeTimeout(cv);
        f006__keyPassword(cv);
        f007__keystore(cv);
        f008__keystoreType(cv);
        f009__needClientAuth(cv);
        f010__password(cv);
        f011__protocol(cv);
        f012__provider(cv);
        f013__secureRandomAlgorithm(cv);
        f014__sslKeyManagerFactoryAlgorithm(cv);
        f015__sslTrustManagerFactoryAlgorithm(cv);
        f016__trustPassword(cv);
        f017__truststore(cv);
        f018__truststoreType(cv);
        f019__wantClientAuth(cv);
        m000__clinit_(cv);
        m001__init_(cv);
        m002_getCertChain(cv);
        m003_accept(cv);
        m004_configure(cv);
        m005_createFactory(cv);
        m006_customize(cv);
        m007_getExcludeCipherSuites(cv);
        m008_getHandshakeTimeout(cv);
        m009_getKeystore(cv);
        m010_getKeystoreType(cv);
        m011_getNeedClientAuth(cv);
        m012_getProtocol(cv);
        m013_getProvider(cv);
        m014_getSecureRandomAlgorithm(cv);
        m015_getSslKeyManagerFactoryAlgorithm(cv);
        m016_getSslTrustManagerFactoryAlgorithm(cv);
        m017_getTruststore(cv);
        m018_getTruststoreType(cv);
        m019_getWantClientAuth(cv);
        m020_isConfidential(cv);
        m021_isIntegral(cv);
        m022_newServerSocket(cv);
        m023_setExcludeCipherSuites(cv);
        m024_setHandshakeTimeout(cv);
        m025_setKeyPassword(cv);
        m026_setKeystore(cv);
        m027_setKeystoreType(cv);
        m028_setNeedClientAuth(cv);
        m029_setPassword(cv);
        m030_setProtocol(cv);
        m031_setProvider(cv);
        m032_setSecureRandomAlgorithm(cv);
        m033_setSslKeyManagerFactoryAlgorithm(cv);
        m034_setSslTrustManagerFactoryAlgorithm(cv);
        m035_setTrustPassword(cv);
        m036_setTruststore(cv);
        m037_setTruststoreType(cv);
        m038_setWantClientAuth(cv);
    }
    public static void f000_CACHED_INFO_ATTR(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/security/SslSocketConnector;","CACHED_INFO_ATTR","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001_DEFAULT_KEYSTORE(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/security/SslSocketConnector;","DEFAULT_KEYSTORE","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002_KEYPASSWORD_PROPERTY(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/security/SslSocketConnector;","KEYPASSWORD_PROPERTY","Ljava/lang/String;"), "jetty.ssl.keypassword");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003_PASSWORD_PROPERTY(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/security/SslSocketConnector;","PASSWORD_PROPERTY","Ljava/lang/String;"), "jetty.ssl.password");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f004__excludeCipherSuites(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/security/SslSocketConnector;","_excludeCipherSuites","[Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f005__handshakeTimeout(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/security/SslSocketConnector;","_handshakeTimeout","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f006__keyPassword(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_TRANSIENT, new Field("Lorg/mortbay/jetty/security/SslSocketConnector;","_keyPassword","Lorg/mortbay/jetty/security/Password;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f007__keystore(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/security/SslSocketConnector;","_keystore","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f008__keystoreType(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/security/SslSocketConnector;","_keystoreType","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f009__needClientAuth(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/security/SslSocketConnector;","_needClientAuth","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f010__password(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_TRANSIENT, new Field("Lorg/mortbay/jetty/security/SslSocketConnector;","_password","Lorg/mortbay/jetty/security/Password;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f011__protocol(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/security/SslSocketConnector;","_protocol","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f012__provider(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/security/SslSocketConnector;","_provider","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f013__secureRandomAlgorithm(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/security/SslSocketConnector;","_secureRandomAlgorithm","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f014__sslKeyManagerFactoryAlgorithm(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/security/SslSocketConnector;","_sslKeyManagerFactoryAlgorithm","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f015__sslTrustManagerFactoryAlgorithm(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/security/SslSocketConnector;","_sslTrustManagerFactoryAlgorithm","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f016__trustPassword(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_TRANSIENT, new Field("Lorg/mortbay/jetty/security/SslSocketConnector;","_trustPassword","Lorg/mortbay/jetty/security/Password;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f017__truststore(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/security/SslSocketConnector;","_truststore","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f018__truststoreType(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/security/SslSocketConnector;","_truststoreType","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f019__wantClientAuth(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/security/SslSocketConnector;","_wantClientAuth","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__clinit_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/security/SslSocketConnector;","<clinit>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(74,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(77,L1);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_CLASS,0,new DexType("Lorg/mortbay/jetty/security/SslSocketConnector$CachedInfo;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/Class;","getName",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/security/SslSocketConnector;","CACHED_INFO_ATTR","Ljava/lang/String;"));
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,1,"user.home");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1},new Method("Ljava/lang/System;","getProperty",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(SGET_OBJECT,1,-1,new Field("Ljava/io/File;","separator","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitConstStmt(CONST_STRING,1,".keystore");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/security/SslSocketConnector;","DEFAULT_KEYSTORE","Ljava/lang/String;"));
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/security/SslSocketConnector;","<init>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(162,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(131,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(134,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(135,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(138,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(142,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(145,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(146,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(149,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(152,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(153,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(163,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(145,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(146,L14);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitConstStmt(CONST_STRING,5,"ssl.TrustManagerFactory.algorithm");
                code.visitConstStmt(CONST_STRING,4,"ssl.KeyManagerFactory.algorithm");
                code.visitConstStmt(CONST_STRING,3,"SunX509");
                code.visitConstStmt(CONST_STRING,2,"JKS");
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 6},new Method("Lorg/mortbay/jetty/bio/SocketConnector;","<init>",new String[]{ },"V"));
                code.visitLabel(L2);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_OBJECT,0,6,new Field("Lorg/mortbay/jetty/security/SslSocketConnector;","_excludeCipherSuites","[Ljava/lang/String;"));
                code.visitLabel(L3);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/security/SslSocketConnector;","DEFAULT_KEYSTORE","Ljava/lang/String;"));
                code.visitFieldStmt(IPUT_OBJECT,0,6,new Field("Lorg/mortbay/jetty/security/SslSocketConnector;","_keystore","Ljava/lang/String;"));
                code.visitLabel(L4);
                code.visitConstStmt(CONST_STRING,0,"JKS");
                code.visitFieldStmt(IPUT_OBJECT,2,6,new Field("Lorg/mortbay/jetty/security/SslSocketConnector;","_keystoreType","Ljava/lang/String;"));
                code.visitLabel(L5);
                code.visitFieldStmt(IPUT_BOOLEAN,1,6,new Field("Lorg/mortbay/jetty/security/SslSocketConnector;","_needClientAuth","Z"));
                code.visitLabel(L6);
                code.visitConstStmt(CONST_STRING,0,"TLS");
                code.visitFieldStmt(IPUT_OBJECT,0,6,new Field("Lorg/mortbay/jetty/security/SslSocketConnector;","_protocol","Ljava/lang/String;"));
                code.visitLabel(L7);
                code.visitConstStmt(CONST_STRING,0,"ssl.KeyManagerFactory.algorithm");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 4},new Method("Ljava/security/Security;","getProperty",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitJumpStmt(IF_NEZ,0,-1,L13);
                code.visitConstStmt(CONST_STRING,0,"SunX509");
                code.visitStmt2R(MOVE_OBJECT,0,3);
                DexLabel L15=new DexLabel();
                code.visitLabel(L15);
                code.visitFieldStmt(IPUT_OBJECT,0,6,new Field("Lorg/mortbay/jetty/security/SslSocketConnector;","_sslKeyManagerFactoryAlgorithm","Ljava/lang/String;"));
                code.visitLabel(L8);
                code.visitConstStmt(CONST_STRING,0,"ssl.TrustManagerFactory.algorithm");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 5},new Method("Ljava/security/Security;","getProperty",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitJumpStmt(IF_NEZ,0,-1,L14);
                code.visitConstStmt(CONST_STRING,0,"SunX509");
                code.visitStmt2R(MOVE_OBJECT,0,3);
                DexLabel L16=new DexLabel();
                code.visitLabel(L16);
                code.visitFieldStmt(IPUT_OBJECT,0,6,new Field("Lorg/mortbay/jetty/security/SslSocketConnector;","_sslTrustManagerFactoryAlgorithm","Ljava/lang/String;"));
                code.visitLabel(L9);
                code.visitConstStmt(CONST_STRING,0,"JKS");
                code.visitFieldStmt(IPUT_OBJECT,2,6,new Field("Lorg/mortbay/jetty/security/SslSocketConnector;","_truststoreType","Ljava/lang/String;"));
                code.visitLabel(L10);
                code.visitFieldStmt(IPUT_BOOLEAN,1,6,new Field("Lorg/mortbay/jetty/security/SslSocketConnector;","_wantClientAuth","Z"));
                code.visitLabel(L11);
                code.visitFieldStmt(IPUT,1,6,new Field("Lorg/mortbay/jetty/security/SslSocketConnector;","_handshakeTimeout","I"));
                code.visitLabel(L12);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L13);
                code.visitConstStmt(CONST_STRING,0,"ssl.KeyManagerFactory.algorithm");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 4},new Method("Ljava/security/Security;","getProperty",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitJumpStmt(GOTO,-1,-1,L15);
                code.visitLabel(L14);
                code.visitConstStmt(CONST_STRING,0,"ssl.TrustManagerFactory.algorithm");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 5},new Method("Ljava/security/Security;","getProperty",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitJumpStmt(GOTO,-1,-1,L16);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_getCertChain(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PRIVATE|ACC_STATIC, new Method("Lorg/mortbay/jetty/security/SslSocketConnector;","getCertChain",new String[]{ "Ljavax/net/ssl/SSLSession;"},"[Ljava/security/cert/X509Certificate;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(12);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                DexLabel L3=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2,L3},new String[]{ "Ljavax/net/ssl/SSLPeerUnverifiedException;","Ljava/lang/Exception;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"sslSession");
                DexLabel L4=new DexLabel();
                ddv.visitPrologue(L4);
                ddv.visitLineNumber(101,L0);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(102,L5);
                ddv.visitStartLocal(5,L5,"javaxCerts","[Ljavax/security/cert/X509Certificate;",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(125,L6);
                ddv.visitEndLocal(11,L6);
                ddv.visitEndLocal(5,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(105,L7);
                ddv.visitRestartLocal(5,L7);
                ddv.visitRestartLocal(11,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(106,L8);
                ddv.visitStartLocal(6,L8,"length","I",null);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(108,L9);
                ddv.visitStartLocal(4,L9,"javaCerts","[Ljava/security/cert/X509Certificate;",null);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(109,L10);
                ddv.visitStartLocal(1,L10,"cf","Ljava/security/cert/CertificateFactory;",null);
                DexLabel L11=new DexLabel();
                ddv.visitEndLocal(11,L11);
                ddv.visitStartLocal(3,L11,"i","I",null);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(111,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(112,L13);
                ddv.visitStartLocal(0,L13,"bytes","[B",null);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(113,L14);
                ddv.visitStartLocal(8,L14,"stream","Ljava/io/ByteArrayInputStream;",null);
                ddv.visitLineNumber(109,L1);
                DexLabel L15=new DexLabel();
                ddv.visitEndLocal(0,L15);
                ddv.visitEndLocal(8,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(116,L16);
                ddv.visitLineNumber(118,L2);
                ddv.visitEndLocal(5,L2);
                ddv.visitEndLocal(6,L2);
                ddv.visitEndLocal(4,L2);
                ddv.visitEndLocal(1,L2);
                ddv.visitEndLocal(3,L2);
                DexLabel L17=new DexLabel();
                ddv.visitStartLocal(7,L17,"pue","Ljavax/net/ssl/SSLPeerUnverifiedException;",null);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(120,L18);
                ddv.visitLineNumber(122,L3);
                ddv.visitEndLocal(7,L3);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(124,L19);
                ddv.visitStartLocal(2,L19,"e","Ljava/lang/Exception;",null);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(125,L20);
                code.visitLabel(L4);
                code.visitConstStmt(CONST_4,10, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 11},new Method("Ljavax/net/ssl/SSLSession;","getPeerCertificateChain",new String[]{ },"[Ljavax/security/cert/X509Certificate;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitLabel(L5);
                DexLabel L21=new DexLabel();
                code.visitJumpStmt(IF_EQZ,5,-1,L21);
                code.visitStmt2R(ARRAY_LENGTH,9,5);
                code.visitJumpStmt(IF_NEZ,9,-1,L7);
                code.visitLabel(L21);
                code.visitStmt2R(MOVE_OBJECT,9,10);
                code.visitLabel(L6);
                code.visitStmt1R(RETURN_OBJECT,9);
                code.visitLabel(L7);
                code.visitStmt2R(ARRAY_LENGTH,6,5);
                code.visitLabel(L8);
                code.visitTypeStmt(NEW_ARRAY,4,6,"[Ljava/security/cert/X509Certificate;");
                code.visitLabel(L9);
                code.visitConstStmt(CONST_STRING,9,"X.509");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 9},new Method("Ljava/security/cert/CertificateFactory;","getInstance",new String[]{ "Ljava/lang/String;"},"Ljava/security/cert/CertificateFactory;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L10);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L11);
                code.visitJumpStmt(IF_GE,3,6,L15);
                code.visitLabel(L12);
                code.visitStmt3R(AGET_OBJECT,9,5,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9},new Method("Ljavax/security/cert/X509Certificate;","getEncoded",new String[]{ },"[B"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L13);
                code.visitTypeStmt(NEW_INSTANCE,8,-1,"Ljava/io/ByteArrayInputStream;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 8,0},new Method("Ljava/io/ByteArrayInputStream;","<init>",new String[]{ "[B"},"V"));
                code.visitLabel(L14);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,8},new Method("Ljava/security/cert/CertificateFactory;","generateCertificate",new String[]{ "Ljava/io/InputStream;"},"Ljava/security/cert/Certificate;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,11);
                code.visitTypeStmt(CHECK_CAST,11,-1,"Ljava/security/cert/X509Certificate;");
                code.visitStmt3R(APUT_OBJECT,11,4,3);
                code.visitLabel(L1);
                code.visitStmt2R1N(ADD_INT_LIT8,3,3,1);
                code.visitJumpStmt(GOTO,-1,-1,L11);
                code.visitLabel(L15);
                code.visitStmt2R(MOVE_OBJECT,9,4);
                code.visitLabel(L16);
                code.visitJumpStmt(GOTO,-1,-1,L6);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,9);
                code.visitStmt2R(MOVE_OBJECT,7,9);
                code.visitLabel(L17);
                code.visitStmt2R(MOVE_OBJECT,9,10);
                code.visitLabel(L18);
                code.visitJumpStmt(GOTO,-1,-1,L6);
                code.visitLabel(L3);
                code.visitStmt1R(MOVE_EXCEPTION,9);
                code.visitStmt2R(MOVE_OBJECT,2,9);
                code.visitLabel(L19);
                code.visitConstStmt(CONST_STRING,9,"EXCEPTION ");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 9,2},new Method("Lorg/mortbay/log/Log;","warn",new String[]{ "Ljava/lang/String;","Ljava/lang/Throwable;"},"V"));
                code.visitStmt2R(MOVE_OBJECT,9,10);
                code.visitLabel(L20);
                code.visitJumpStmt(GOTO,-1,-1,L6);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_accept(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/SslSocketConnector;","accept",new String[]{ "I"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visit(null, new DexType("Ljava/lang/InterruptedException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(8);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljavax/net/ssl/SSLException;"});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                DexLabel L5=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L5},new String[]{ "Ljava/lang/Exception;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"acceptorID");
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(172,L0);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(173,L6);
                ddv.visitStartLocal(3,L6,"socket","Ljava/net/Socket;",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(175,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(176,L8);
                ddv.visitStartLocal(0,L8,"connection","Lorg/mortbay/jetty/bio/SocketConnector$Connection;",null);
                ddv.visitLineNumber(191,L1);
                ddv.visitEndLocal(3,L1);
                ddv.visitEndLocal(0,L1);
                ddv.visitLineNumber(178,L2);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(180,L9);
                ddv.visitStartLocal(1,L9,"e","Ljavax/net/ssl/SSLException;",null);
                ddv.visitLineNumber(183,L3);
                ddv.visitLineNumber(185,L5);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(187,L10);
                ddv.visitStartLocal(2,L10,"e2","Ljava/lang/Exception;",null);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(188,L11);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,4,6,new Field("Lorg/mortbay/jetty/security/SslSocketConnector;","_serverSocket","Ljava/net/ServerSocket;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/net/ServerSocket;","accept",new String[]{ },"Ljava/net/Socket;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,3},new Method("Lorg/mortbay/jetty/security/SslSocketConnector;","configure",new String[]{ "Ljava/net/Socket;"},"V"));
                code.visitLabel(L7);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/jetty/security/SslSocketConnector$SslConnection;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,6,3},new Method("Lorg/mortbay/jetty/security/SslSocketConnector$SslConnection;","<init>",new String[]{ "Lorg/mortbay/jetty/security/SslSocketConnector;","Ljava/net/Socket;"},"V"));
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/bio/SocketConnector$Connection;","dispatch",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,4);
                code.visitStmt2R(MOVE_OBJECT,1,4);
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1},new Method("Lorg/mortbay/log/Log;","warn",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/security/SslSocketConnector;","stop",new String[]{ },"V"));
                code.visitLabel(L4);
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitLabel(L5);
                code.visitStmt1R(MOVE_EXCEPTION,2);
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2},new Method("Lorg/mortbay/log/Log;","warn",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitLabel(L11);
                code.visitTypeStmt(NEW_INSTANCE,4,-1,"Ljava/lang/IllegalStateException;");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/lang/Exception;","getMessage",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4,5},new Method("Ljava/lang/IllegalStateException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,4);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_configure(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/security/SslSocketConnector;","configure",new String[]{ "Ljava/net/Socket;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"socket");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(197,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(198,L1);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/bio/SocketConnector;","configure",new String[]{ "Ljava/net/Socket;"},"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_createFactory(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/security/SslSocketConnector;","createFactory",new String[]{ },"Ljavax/net/ssl/SSLServerSocketFactory;"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/Exception;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(13);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(204,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(206,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(207,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(210,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(211,L5);
                ddv.visitStartLocal(2,L5,"keyManagers","[Ljavax/net/ssl/KeyManager;",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(212,L6);
                ddv.visitStartLocal(4,L6,"keystoreInputStream","Ljava/io/InputStream;",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(213,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(214,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(215,L9);
                ddv.visitStartLocal(3,L9,"keyStore","Ljava/security/KeyStore;",null);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(217,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(218,L11);
                ddv.visitStartLocal(1,L11,"keyManagerFactory","Ljavax/net/ssl/KeyManagerFactory;",null);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(219,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(221,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(222,L14);
                ddv.visitStartLocal(7,L14,"trustManagers","[Ljavax/net/ssl/TrustManager;",null);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(223,L15);
                ddv.visitStartLocal(9,L15,"truststoreInputStream","Ljava/io/InputStream;",null);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(224,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(225,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(226,L18);
                ddv.visitStartLocal(8,L18,"trustStore","Ljava/security/KeyStore;",null);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(228,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(229,L20);
                ddv.visitStartLocal(6,L20,"trustManagerFactory","Ljavax/net/ssl/TrustManagerFactory;",null);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(230,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(233,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(235,L23);
                ddv.visitStartLocal(5,L23,"secureRandom","Ljava/security/SecureRandom;",null);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(237,L24);
                ddv.visitStartLocal(0,L24,"context","Ljavax/net/ssl/SSLContext;",null);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(239,L25);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(215,L26);
                ddv.visitEndLocal(1,L26);
                ddv.visitEndLocal(9,L26);
                ddv.visitEndLocal(8,L26);
                ddv.visitEndLocal(6,L26);
                ddv.visitEndLocal(7,L26);
                ddv.visitEndLocal(5,L26);
                ddv.visitEndLocal(0,L26);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(218,L27);
                ddv.visitRestartLocal(1,L27);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(226,L28);
                ddv.visitRestartLocal(7,L28);
                ddv.visitRestartLocal(8,L28);
                ddv.visitRestartLocal(9,L28);
                DexLabel L29=new DexLabel();
                ddv.visitLineNumber(233,L29);
                ddv.visitRestartLocal(6,L29);
                DexLabel L30=new DexLabel();
                ddv.visitLineNumber(235,L30);
                ddv.visitRestartLocal(5,L30);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,11, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,10,12,new Field("Lorg/mortbay/jetty/security/SslSocketConnector;","_truststore","Ljava/lang/String;"));
                code.visitJumpStmt(IF_NEZ,10,-1,L4);
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,10,12,new Field("Lorg/mortbay/jetty/security/SslSocketConnector;","_keystore","Ljava/lang/String;"));
                code.visitFieldStmt(IPUT_OBJECT,10,12,new Field("Lorg/mortbay/jetty/security/SslSocketConnector;","_truststore","Ljava/lang/String;"));
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,10,12,new Field("Lorg/mortbay/jetty/security/SslSocketConnector;","_keystoreType","Ljava/lang/String;"));
                code.visitFieldStmt(IPUT_OBJECT,10,12,new Field("Lorg/mortbay/jetty/security/SslSocketConnector;","_truststoreType","Ljava/lang/String;"));
                code.visitLabel(L4);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L5);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,10,12,new Field("Lorg/mortbay/jetty/security/SslSocketConnector;","_keystore","Ljava/lang/String;"));
                code.visitJumpStmt(IF_EQZ,10,-1,L8);
                code.visitLabel(L7);
                code.visitFieldStmt(IGET_OBJECT,10,12,new Field("Lorg/mortbay/jetty/security/SslSocketConnector;","_keystore","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 10},new Method("Lorg/mortbay/resource/Resource;","newResource",new String[]{ "Ljava/lang/String;"},"Lorg/mortbay/resource/Resource;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Lorg/mortbay/resource/Resource;","getInputStream",new String[]{ },"Ljava/io/InputStream;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitLabel(L8);
                code.visitFieldStmt(IGET_OBJECT,10,12,new Field("Lorg/mortbay/jetty/security/SslSocketConnector;","_keystoreType","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 10},new Method("Ljava/security/KeyStore;","getInstance",new String[]{ "Ljava/lang/String;"},"Ljava/security/KeyStore;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitLabel(L9);
                code.visitFieldStmt(IGET_OBJECT,10,12,new Field("Lorg/mortbay/jetty/security/SslSocketConnector;","_password","Lorg/mortbay/jetty/security/Password;"));
                code.visitJumpStmt(IF_NEZ,10,-1,L26);
                code.visitStmt2R(MOVE_OBJECT,10,11);
                DexLabel L31=new DexLabel();
                code.visitLabel(L31);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4,10},new Method("Ljava/security/KeyStore;","load",new String[]{ "Ljava/io/InputStream;","[C"},"V"));
                code.visitLabel(L10);
                code.visitFieldStmt(IGET_OBJECT,10,12,new Field("Lorg/mortbay/jetty/security/SslSocketConnector;","_sslKeyManagerFactoryAlgorithm","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 10},new Method("Ljavax/net/ssl/KeyManagerFactory;","getInstance",new String[]{ "Ljava/lang/String;"},"Ljavax/net/ssl/KeyManagerFactory;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L11);
                code.visitFieldStmt(IGET_OBJECT,10,12,new Field("Lorg/mortbay/jetty/security/SslSocketConnector;","_keyPassword","Lorg/mortbay/jetty/security/Password;"));
                code.visitJumpStmt(IF_NEZ,10,-1,L27);
                code.visitStmt2R(MOVE_OBJECT,10,11);
                DexLabel L32=new DexLabel();
                code.visitLabel(L32);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,3,10},new Method("Ljavax/net/ssl/KeyManagerFactory;","init",new String[]{ "Ljava/security/KeyStore;","[C"},"V"));
                code.visitLabel(L12);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljavax/net/ssl/KeyManagerFactory;","getKeyManagers",new String[]{ },"[Ljavax/net/ssl/KeyManager;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L13);
                code.visitConstStmt(CONST_4,7, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L14);
                code.visitConstStmt(CONST_4,9, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L15);
                code.visitFieldStmt(IGET_OBJECT,10,12,new Field("Lorg/mortbay/jetty/security/SslSocketConnector;","_truststore","Ljava/lang/String;"));
                code.visitJumpStmt(IF_EQZ,10,-1,L17);
                code.visitLabel(L16);
                code.visitFieldStmt(IGET_OBJECT,10,12,new Field("Lorg/mortbay/jetty/security/SslSocketConnector;","_truststore","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 10},new Method("Lorg/mortbay/resource/Resource;","newResource",new String[]{ "Ljava/lang/String;"},"Lorg/mortbay/resource/Resource;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Lorg/mortbay/resource/Resource;","getInputStream",new String[]{ },"Ljava/io/InputStream;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitLabel(L17);
                code.visitFieldStmt(IGET_OBJECT,10,12,new Field("Lorg/mortbay/jetty/security/SslSocketConnector;","_truststoreType","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 10},new Method("Ljava/security/KeyStore;","getInstance",new String[]{ "Ljava/lang/String;"},"Ljava/security/KeyStore;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitLabel(L18);
                code.visitFieldStmt(IGET_OBJECT,10,12,new Field("Lorg/mortbay/jetty/security/SslSocketConnector;","_trustPassword","Lorg/mortbay/jetty/security/Password;"));
                code.visitJumpStmt(IF_NEZ,10,-1,L28);
                code.visitStmt2R(MOVE_OBJECT,10,11);
                DexLabel L33=new DexLabel();
                code.visitLabel(L33);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,9,10},new Method("Ljava/security/KeyStore;","load",new String[]{ "Ljava/io/InputStream;","[C"},"V"));
                code.visitLabel(L19);
                code.visitFieldStmt(IGET_OBJECT,10,12,new Field("Lorg/mortbay/jetty/security/SslSocketConnector;","_sslTrustManagerFactoryAlgorithm","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 10},new Method("Ljavax/net/ssl/TrustManagerFactory;","getInstance",new String[]{ "Ljava/lang/String;"},"Ljavax/net/ssl/TrustManagerFactory;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitLabel(L20);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,8},new Method("Ljavax/net/ssl/TrustManagerFactory;","init",new String[]{ "Ljava/security/KeyStore;"},"V"));
                code.visitLabel(L21);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljavax/net/ssl/TrustManagerFactory;","getTrustManagers",new String[]{ },"[Ljavax/net/ssl/TrustManager;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitLabel(L22);
                code.visitFieldStmt(IGET_OBJECT,10,12,new Field("Lorg/mortbay/jetty/security/SslSocketConnector;","_secureRandomAlgorithm","Ljava/lang/String;"));
                code.visitJumpStmt(IF_NEZ,10,-1,L29);
                code.visitStmt2R(MOVE_OBJECT,5,11);
                code.visitLabel(L23);
                code.visitFieldStmt(IGET_OBJECT,10,12,new Field("Lorg/mortbay/jetty/security/SslSocketConnector;","_provider","Ljava/lang/String;"));
                code.visitJumpStmt(IF_NEZ,10,-1,L30);
                code.visitFieldStmt(IGET_OBJECT,10,12,new Field("Lorg/mortbay/jetty/security/SslSocketConnector;","_protocol","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 10},new Method("Ljavax/net/ssl/SSLContext;","getInstance",new String[]{ "Ljava/lang/String;"},"Ljavax/net/ssl/SSLContext;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,10);
                code.visitStmt2R(MOVE_OBJECT,0,10);
                code.visitLabel(L24);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,2,7,5},new Method("Ljavax/net/ssl/SSLContext;","init",new String[]{ "[Ljavax/net/ssl/KeyManager;","[Ljavax/net/ssl/TrustManager;","Ljava/security/SecureRandom;"},"V"));
                code.visitLabel(L25);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljavax/net/ssl/SSLContext;","getServerSocketFactory",new String[]{ },"Ljavax/net/ssl/SSLServerSocketFactory;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,10);
                code.visitStmt1R(RETURN_OBJECT,10);
                code.visitLabel(L26);
                code.visitFieldStmt(IGET_OBJECT,10,12,new Field("Lorg/mortbay/jetty/security/SslSocketConnector;","_password","Lorg/mortbay/jetty/security/Password;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Lorg/mortbay/jetty/security/Password;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Ljava/lang/String;","toCharArray",new String[]{ },"[C"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,10);
                code.visitJumpStmt(GOTO,-1,-1,L31);
                code.visitLabel(L27);
                code.visitFieldStmt(IGET_OBJECT,10,12,new Field("Lorg/mortbay/jetty/security/SslSocketConnector;","_keyPassword","Lorg/mortbay/jetty/security/Password;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Lorg/mortbay/jetty/security/Password;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Ljava/lang/String;","toCharArray",new String[]{ },"[C"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,10);
                code.visitJumpStmt(GOTO,-1,-1,L32);
                code.visitLabel(L28);
                code.visitFieldStmt(IGET_OBJECT,10,12,new Field("Lorg/mortbay/jetty/security/SslSocketConnector;","_trustPassword","Lorg/mortbay/jetty/security/Password;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Lorg/mortbay/jetty/security/Password;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Ljava/lang/String;","toCharArray",new String[]{ },"[C"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,10);
                code.visitJumpStmt(GOTO,-1,-1,L33);
                code.visitLabel(L29);
                code.visitFieldStmt(IGET_OBJECT,10,12,new Field("Lorg/mortbay/jetty/security/SslSocketConnector;","_secureRandomAlgorithm","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 10},new Method("Ljava/security/SecureRandom;","getInstance",new String[]{ "Ljava/lang/String;"},"Ljava/security/SecureRandom;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,10);
                code.visitStmt2R(MOVE_OBJECT,5,10);
                code.visitJumpStmt(GOTO,-1,-1,L23);
                code.visitLabel(L30);
                code.visitFieldStmt(IGET_OBJECT,10,12,new Field("Lorg/mortbay/jetty/security/SslSocketConnector;","_protocol","Ljava/lang/String;"));
                code.visitFieldStmt(IGET_OBJECT,11,12,new Field("Lorg/mortbay/jetty/security/SslSocketConnector;","_provider","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 10,11},new Method("Ljavax/net/ssl/SSLContext;","getInstance",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"Ljavax/net/ssl/SSLContext;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,10);
                code.visitStmt2R(MOVE_OBJECT,0,10);
                code.visitJumpStmt(GOTO,-1,-1,L24);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_customize(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/SslSocketConnector;","customize",new String[]{ "Lorg/mortbay/io/EndPoint;","Lorg/mortbay/jetty/Request;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(14);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/lang/Exception;"});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L2},new String[]{ "Ljava/lang/Exception;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"endpoint");
                ddv.visitParameterName(1,"request");
                DexLabel L5=new DexLabel();
                ddv.visitPrologue(L5);
                ddv.visitLineNumber(264,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(265,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(267,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(268,L8);
                ddv.visitStartLocal(6,L8,"socket_end_point","Lorg/mortbay/io/bio/SocketEndPoint;",null);
                ddv.visitLineNumber(272,L0);
                ddv.visitStartLocal(8,L0,"sslSocket","Ljavax/net/ssl/SSLSocket;",null);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(273,L9);
                ddv.visitStartLocal(7,L9,"sslSession","Ljavax/net/ssl/SSLSession;",null);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(277,L10);
                ddv.visitStartLocal(3,L10,"cipherSuite","Ljava/lang/String;",null);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(278,L11);
                ddv.visitStartLocal(1,L11,"cachedInfo","Lorg/mortbay/jetty/security/SslSocketConnector$CachedInfo;",null);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(280,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(281,L13);
                ddv.visitStartLocal(5,L13,"keySize","Ljava/lang/Integer;",null);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(291,L14);
                ddv.visitStartLocal(2,L14,"certs","[Ljava/security/cert/X509Certificate;",null);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(292,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(296,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(297,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(303,L18);
                ddv.visitEndLocal(7,L18);
                ddv.visitEndLocal(3,L18);
                ddv.visitEndLocal(1,L18);
                ddv.visitEndLocal(5,L18);
                ddv.visitEndLocal(2,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(285,L19);
                ddv.visitRestartLocal(1,L19);
                ddv.visitRestartLocal(3,L19);
                ddv.visitRestartLocal(7,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(286,L20);
                ddv.visitRestartLocal(5,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(287,L21);
                ddv.visitRestartLocal(2,L21);
                DexLabel L22=new DexLabel();
                ddv.visitEndLocal(1,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(288,L23);
                ddv.visitRestartLocal(1,L23);
                ddv.visitLineNumber(299,L2);
                ddv.visitEndLocal(3,L2);
                ddv.visitEndLocal(7,L2);
                ddv.visitEndLocal(5,L2);
                ddv.visitEndLocal(2,L2);
                ddv.visitEndLocal(1,L2);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(301,L24);
                ddv.visitStartLocal(4,L24,"e","Ljava/lang/Exception;",null);
                ddv.visitLineNumber(293,L3);
                ddv.visitEndLocal(4,L3);
                ddv.visitRestartLocal(1,L3);
                ddv.visitRestartLocal(2,L3);
                ddv.visitRestartLocal(3,L3);
                ddv.visitRestartLocal(5,L3);
                ddv.visitRestartLocal(7,L3);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(294,L25);
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 11,12,13},new Method("Lorg/mortbay/jetty/bio/SocketConnector;","customize",new String[]{ "Lorg/mortbay/io/EndPoint;","Lorg/mortbay/jetty/Request;"},"V"));
                code.visitLabel(L6);
                code.visitConstStmt(CONST_STRING,9,"https");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13,9},new Method("Lorg/mortbay/jetty/Request;","setScheme",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L7);
                code.visitStmt2R(MOVE_OBJECT,0,12);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Lorg/mortbay/io/bio/SocketEndPoint;");
                code.visitStmt2R(MOVE_OBJECT,6,0);
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/io/bio/SocketEndPoint;","getTransport",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitTypeStmt(CHECK_CAST,8,-1,"Ljavax/net/ssl/SSLSocket;");
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Ljavax/net/ssl/SSLSocket;","getSession",new String[]{ },"Ljavax/net/ssl/SSLSession;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 7},new Method("Ljavax/net/ssl/SSLSession;","getCipherSuite",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitLabel(L10);
                code.visitFieldStmt(SGET_OBJECT,9,-1,new Field("Lorg/mortbay/jetty/security/SslSocketConnector;","CACHED_INFO_ATTR","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 7,9},new Method("Ljavax/net/ssl/SSLSession;","getValue",new String[]{ "Ljava/lang/String;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitTypeStmt(CHECK_CAST,1,-1,"Lorg/mortbay/jetty/security/SslSocketConnector$CachedInfo;");
                code.visitLabel(L11);
                code.visitJumpStmt(IF_EQZ,1,-1,L19);
                code.visitLabel(L12);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/jetty/security/SslSocketConnector$CachedInfo;","getKeySize",new String[]{ },"Ljava/lang/Integer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitLabel(L13);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/jetty/security/SslSocketConnector$CachedInfo;","getCerts",new String[]{ },"[Ljava/security/cert/X509Certificate;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L14);
                code.visitJumpStmt(IF_EQZ,2,-1,L3);
                code.visitLabel(L15);
                code.visitConstStmt(CONST_STRING,9,"javax.servlet.request.X509Certificate");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13,9,2},new Method("Lorg/mortbay/jetty/Request;","setAttribute",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L16);
                code.visitConstStmt(CONST_STRING,9,"javax.servlet.request.cipher_suite");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13,9,3},new Method("Lorg/mortbay/jetty/Request;","setAttribute",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L17);
                code.visitConstStmt(CONST_STRING,9,"javax.servlet.request.key_size");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13,9,5},new Method("Lorg/mortbay/jetty/Request;","setAttribute",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L18);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L19);
                code.visitTypeStmt(NEW_INSTANCE,5,-1,"Ljava/lang/Integer;");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3},new Method("Lorg/mortbay/jetty/security/ServletSSL;","deduceKeyLength",new String[]{ "Ljava/lang/String;"},"I"));
                code.visitStmt1R(MOVE_RESULT,9);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 5,9},new Method("Ljava/lang/Integer;","<init>",new String[]{ "I"},"V"));
                code.visitLabel(L20);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 7},new Method("Lorg/mortbay/jetty/security/SslSocketConnector;","getCertChain",new String[]{ "Ljavax/net/ssl/SSLSession;"},"[Ljava/security/cert/X509Certificate;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L21);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Lorg/mortbay/jetty/security/SslSocketConnector$CachedInfo;");
                code.visitLabel(L22);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,11,5,2},new Method("Lorg/mortbay/jetty/security/SslSocketConnector$CachedInfo;","<init>",new String[]{ "Lorg/mortbay/jetty/security/SslSocketConnector;","Ljava/lang/Integer;","[Ljava/security/cert/X509Certificate;"},"V"));
                code.visitLabel(L23);
                code.visitFieldStmt(SGET_OBJECT,9,-1,new Field("Lorg/mortbay/jetty/security/SslSocketConnector;","CACHED_INFO_ATTR","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 7,9,1},new Method("Ljavax/net/ssl/SSLSession;","putValue",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L1);
                code.visitJumpStmt(GOTO,-1,-1,L14);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,9);
                code.visitStmt2R(MOVE_OBJECT,4,9);
                code.visitLabel(L24);
                code.visitConstStmt(CONST_STRING,9,"EXCEPTION ");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 9,4},new Method("Lorg/mortbay/log/Log;","warn",new String[]{ "Ljava/lang/String;","Ljava/lang/Throwable;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L18);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_BOOLEAN,9,11,new Field("Lorg/mortbay/jetty/security/SslSocketConnector;","_needClientAuth","Z"));
                code.visitJumpStmt(IF_EQZ,9,-1,L16);
                code.visitLabel(L25);
                code.visitTypeStmt(NEW_INSTANCE,9,-1,"Ljava/lang/IllegalStateException;");
                code.visitConstStmt(CONST_STRING,10,"no client auth");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 9,10},new Method("Ljava/lang/IllegalStateException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,9);
                code.visitLabel(L4);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m007_getExcludeCipherSuites(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/SslSocketConnector;","getExcludeCipherSuites",new String[]{ },"[Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(307,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/security/SslSocketConnector;","_excludeCipherSuites","[Ljava/lang/String;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m008_getHandshakeTimeout(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/SslSocketConnector;","getHandshakeTimeout",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(586,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,1,new Field("Lorg/mortbay/jetty/security/SslSocketConnector;","_handshakeTimeout","I"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m009_getKeystore(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/SslSocketConnector;","getKeystore",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(313,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/security/SslSocketConnector;","_keystore","Ljava/lang/String;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m010_getKeystoreType(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/SslSocketConnector;","getKeystoreType",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(319,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/security/SslSocketConnector;","_keystoreType","Ljava/lang/String;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m011_getNeedClientAuth(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/SslSocketConnector;","getNeedClientAuth",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(325,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_BOOLEAN,0,1,new Field("Lorg/mortbay/jetty/security/SslSocketConnector;","_needClientAuth","Z"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m012_getProtocol(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/SslSocketConnector;","getProtocol",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(331,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/security/SslSocketConnector;","_protocol","Ljava/lang/String;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m013_getProvider(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/SslSocketConnector;","getProvider",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(336,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/security/SslSocketConnector;","_provider","Ljava/lang/String;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m014_getSecureRandomAlgorithm(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/SslSocketConnector;","getSecureRandomAlgorithm",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(342,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/security/SslSocketConnector;","_secureRandomAlgorithm","Ljava/lang/String;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m015_getSslKeyManagerFactoryAlgorithm(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/SslSocketConnector;","getSslKeyManagerFactoryAlgorithm",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(348,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/security/SslSocketConnector;","_sslKeyManagerFactoryAlgorithm","Ljava/lang/String;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m016_getSslTrustManagerFactoryAlgorithm(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/SslSocketConnector;","getSslTrustManagerFactoryAlgorithm",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(354,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/security/SslSocketConnector;","_sslTrustManagerFactoryAlgorithm","Ljava/lang/String;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m017_getTruststore(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/SslSocketConnector;","getTruststore",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(360,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/security/SslSocketConnector;","_truststore","Ljava/lang/String;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m018_getTruststoreType(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/SslSocketConnector;","getTruststoreType",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(366,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/security/SslSocketConnector;","_truststoreType","Ljava/lang/String;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m019_getWantClientAuth(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/SslSocketConnector;","getWantClientAuth",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(372,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_BOOLEAN,0,1,new Field("Lorg/mortbay/jetty/security/SslSocketConnector;","_wantClientAuth","Z"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m020_isConfidential(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/SslSocketConnector;","isConfidential",new String[]{ "Lorg/mortbay/jetty/Request;"},"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"request");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(385,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(386,L1);
                ddv.visitStartLocal(0,L1,"confidentialPort","I",null);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/security/SslSocketConnector;","getConfidentialPort",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitLabel(L1);
                DexLabel L2=new DexLabel();
                code.visitJumpStmt(IF_EQZ,0,-1,L2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/jetty/Request;","getServerPort",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                DexLabel L3=new DexLabel();
                code.visitJumpStmt(IF_NE,0,1,L3);
                code.visitLabel(L2);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                DexLabel L4=new DexLabel();
                code.visitLabel(L4);
                code.visitStmt1R(RETURN,1);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m021_isIntegral(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/SslSocketConnector;","isIntegral",new String[]{ "Lorg/mortbay/jetty/Request;"},"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"request");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(399,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(400,L1);
                ddv.visitStartLocal(0,L1,"integralPort","I",null);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/security/SslSocketConnector;","getIntegralPort",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitLabel(L1);
                DexLabel L2=new DexLabel();
                code.visitJumpStmt(IF_EQZ,0,-1,L2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/jetty/Request;","getServerPort",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                DexLabel L3=new DexLabel();
                code.visitJumpStmt(IF_NE,0,1,L3);
                code.visitLabel(L2);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                DexLabel L4=new DexLabel();
                code.visitLabel(L4);
                code.visitStmt1R(RETURN,1);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m022_newServerSocket(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/security/SslSocketConnector;","newServerSocket",new String[]{ "Ljava/lang/String;","I","I"},"Ljava/net/ServerSocket;"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(16);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                DexLabel L3=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2,L3},new String[]{ "Ljava/io/IOException;","Ljava/lang/Exception;"});
                DexLabel L4=new DexLabel();
                DexLabel L5=new DexLabel();
                code.visitTryCatch(L4,L5,new DexLabel[]{L2,L3},new String[]{ "Ljava/io/IOException;","Ljava/lang/Exception;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"host");
                ddv.visitParameterName(1,"port");
                ddv.visitParameterName(2,"backlog");
                DexLabel L6=new DexLabel();
                ddv.visitPrologue(L6);
                ddv.visitLineNumber(418,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(419,L7);
                ddv.visitStartLocal(7,L7,"factory","Ljavax/net/ssl/SSLServerSocketFactory;",null);
                ddv.visitLineNumber(423,L0);
                ddv.visitStartLocal(8,L0,"socket","Ljavax/net/ssl/SSLServerSocket;",null);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(425,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(429,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(430,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(431,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(432,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(434,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(436,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(437,L15);
                ddv.visitStartLocal(6,L15,"excludedCSList","Ljava/util/List;",null);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(438,L16);
                ddv.visitStartLocal(4,L16,"enabledCipherSuites","[Ljava/lang/String;",null);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(439,L17);
                ddv.visitStartLocal(3,L17,"enabledCSList","Ljava/util/List;",null);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(441,L18);
                ddv.visitStartLocal(5,L18,"exIter","Ljava/util/Iterator;",null);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(443,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(444,L20);
                ddv.visitStartLocal(1,L20,"cipherName","Ljava/lang/String;",null);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(446,L21);
                ddv.visitLineNumber(455,L2);
                ddv.visitEndLocal(12,L2);
                ddv.visitEndLocal(6,L2);
                ddv.visitEndLocal(4,L2);
                ddv.visitEndLocal(3,L2);
                ddv.visitEndLocal(5,L2);
                ddv.visitEndLocal(1,L2);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(457,L22);
                ddv.visitStartLocal(2,L22,"e","Ljava/io/IOException;",null);
                ddv.visitLineNumber(425,L4);
                ddv.visitEndLocal(2,L4);
                ddv.visitRestartLocal(12,L4);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(449,L23);
                ddv.visitRestartLocal(3,L23);
                ddv.visitRestartLocal(4,L23);
                ddv.visitRestartLocal(5,L23);
                ddv.visitRestartLocal(6,L23);
                DexLabel L24=new DexLabel();
                ddv.visitEndLocal(12,L24);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(451,L25);
                ddv.visitRestartLocal(4,L25);
                ddv.visitLineNumber(464,L5);
                ddv.visitEndLocal(3,L5);
                ddv.visitEndLocal(5,L5);
                ddv.visitEndLocal(6,L5);
                ddv.visitEndLocal(4,L5);
                ddv.visitLineNumber(459,L3);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(461,L26);
                ddv.visitStartLocal(2,L26,"e","Ljava/lang/Exception;",null);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(462,L27);
                code.visitLabel(L6);
                code.visitConstStmt(CONST_4,7, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L7);
                code.visitConstStmt(CONST_4,8, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12},new Method("Lorg/mortbay/jetty/security/SslSocketConnector;","createFactory",new String[]{ },"Ljavax/net/ssl/SSLServerSocketFactory;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitLabel(L8);
                code.visitJumpStmt(IF_NEZ,13,-1,L4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,14,15},new Method("Ljavax/net/ssl/SSLServerSocketFactory;","createServerSocket",new String[]{ "I","I"},"Ljava/net/ServerSocket;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                DexLabel L28=new DexLabel();
                code.visitLabel(L28);
                code.visitStmt2R(MOVE_OBJECT,0,9);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Ljavax/net/ssl/SSLServerSocket;");
                code.visitStmt2R(MOVE_OBJECT,8,0);
                code.visitLabel(L9);
                code.visitFieldStmt(IGET_BOOLEAN,9,12,new Field("Lorg/mortbay/jetty/security/SslSocketConnector;","_wantClientAuth","Z"));
                code.visitJumpStmt(IF_EQZ,9,-1,L11);
                code.visitLabel(L10);
                code.visitFieldStmt(IGET_BOOLEAN,9,12,new Field("Lorg/mortbay/jetty/security/SslSocketConnector;","_wantClientAuth","Z"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,9},new Method("Ljavax/net/ssl/SSLServerSocket;","setWantClientAuth",new String[]{ "Z"},"V"));
                code.visitLabel(L11);
                code.visitFieldStmt(IGET_BOOLEAN,9,12,new Field("Lorg/mortbay/jetty/security/SslSocketConnector;","_needClientAuth","Z"));
                code.visitJumpStmt(IF_EQZ,9,-1,L13);
                code.visitLabel(L12);
                code.visitFieldStmt(IGET_BOOLEAN,9,12,new Field("Lorg/mortbay/jetty/security/SslSocketConnector;","_needClientAuth","Z"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,9},new Method("Ljavax/net/ssl/SSLServerSocket;","setNeedClientAuth",new String[]{ "Z"},"V"));
                code.visitLabel(L13);
                code.visitFieldStmt(IGET_OBJECT,9,12,new Field("Lorg/mortbay/jetty/security/SslSocketConnector;","_excludeCipherSuites","[Ljava/lang/String;"));
                code.visitJumpStmt(IF_EQZ,9,-1,L5);
                code.visitFieldStmt(IGET_OBJECT,9,12,new Field("Lorg/mortbay/jetty/security/SslSocketConnector;","_excludeCipherSuites","[Ljava/lang/String;"));
                code.visitStmt2R(ARRAY_LENGTH,9,9);
                code.visitJumpStmt(IF_LEZ,9,-1,L5);
                code.visitLabel(L14);
                code.visitFieldStmt(IGET_OBJECT,9,12,new Field("Lorg/mortbay/jetty/security/SslSocketConnector;","_excludeCipherSuites","[Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 9},new Method("Ljava/util/Arrays;","asList",new String[]{ "[Ljava/lang/Object;"},"Ljava/util/List;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitLabel(L15);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Ljavax/net/ssl/SSLServerSocket;","getEnabledCipherSuites",new String[]{ },"[Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitLabel(L16);
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Ljava/util/ArrayList;");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 4},new Method("Ljava/util/Arrays;","asList",new String[]{ "[Ljava/lang/Object;"},"Ljava/util/List;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3,9},new Method("Ljava/util/ArrayList;","<init>",new String[]{ "Ljava/util/Collection;"},"V"));
                code.visitLabel(L17);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 6},new Method("Ljava/util/List;","iterator",new String[]{ },"Ljava/util/Iterator;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitLabel(L18);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 5},new Method("Ljava/util/Iterator;","hasNext",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,9);
                code.visitJumpStmt(IF_EQZ,9,-1,L23);
                code.visitLabel(L19);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 5},new Method("Ljava/util/Iterator;","next",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitTypeStmt(CHECK_CAST,1,-1,"Ljava/lang/String;");
                code.visitLabel(L20);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3,1},new Method("Ljava/util/List;","contains",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,9);
                code.visitJumpStmt(IF_EQZ,9,-1,L18);
                code.visitLabel(L21);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3,1},new Method("Ljava/util/List;","remove",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitLabel(L1);
                code.visitJumpStmt(GOTO,-1,-1,L18);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,9);
                code.visitStmt2R(MOVE_OBJECT,2,9);
                code.visitLabel(L22);
                code.visitStmt1R(THROW,2);
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 13},new Method("Ljava/net/InetAddress;","getByName",new String[]{ "Ljava/lang/String;"},"Ljava/net/InetAddress;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,14,15,9},new Method("Ljavax/net/ssl/SSLServerSocketFactory;","createServerSocket",new String[]{ "I","I","Ljava/net/InetAddress;"},"Ljava/net/ServerSocket;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitJumpStmt(GOTO,-1,-1,L28);
                code.visitLabel(L23);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3},new Method("Ljava/util/List;","size",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,9);
                code.visitTypeStmt(NEW_ARRAY,9,9,"[Ljava/lang/String;");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3,9},new Method("Ljava/util/List;","toArray",new String[]{ "[Ljava/lang/Object;"},"[Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,12);
                code.visitLabel(L24);
                code.visitTypeStmt(CHECK_CAST,12,-1,"[Ljava/lang/String;");
                code.visitStmt2R(MOVE_OBJECT,0,12);
                code.visitTypeStmt(CHECK_CAST,0,-1,"[Ljava/lang/String;");
                code.visitStmt2R(MOVE_OBJECT,4,0);
                code.visitLabel(L25);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,4},new Method("Ljavax/net/ssl/SSLServerSocket;","setEnabledCipherSuites",new String[]{ "[Ljava/lang/String;"},"V"));
                code.visitLabel(L5);
                code.visitStmt1R(RETURN_OBJECT,8);
                code.visitLabel(L3);
                code.visitStmt1R(MOVE_EXCEPTION,9);
                code.visitStmt2R(MOVE_OBJECT,2,9);
                code.visitLabel(L26);
                code.visitConstStmt(CONST_STRING,9,"EXCEPTION ");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 9,2},new Method("Lorg/mortbay/log/Log;","warn",new String[]{ "Ljava/lang/String;","Ljava/lang/Throwable;"},"V"));
                code.visitLabel(L27);
                code.visitTypeStmt(NEW_INSTANCE,9,-1,"Ljava/io/IOException;");
                code.visitTypeStmt(NEW_INSTANCE,10,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 10},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,11,"Could not create JsseListener: ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10,11},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/lang/Exception;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,11);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10,11},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,10);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 9,10},new Method("Ljava/io/IOException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,9);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m023_setExcludeCipherSuites(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/SslSocketConnector;","setExcludeCipherSuites",new String[]{ "[Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"cipherSuites");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(472,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(473,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/security/SslSocketConnector;","_excludeCipherSuites","[Ljava/lang/String;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m024_setHandshakeTimeout(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/SslSocketConnector;","setHandshakeTimeout",new String[]{ "I"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"msec");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(580,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(581,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT,1,0,new Field("Lorg/mortbay/jetty/security/SslSocketConnector;","_handshakeTimeout","I"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m025_setKeyPassword(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/SslSocketConnector;","setKeyPassword",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"password");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(478,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(479,L1);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_STRING,0,"jetty.ssl.keypassword");
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,3,1},new Method("Lorg/mortbay/jetty/security/Password;","getPassword",new String[]{ "Ljava/lang/String;","Ljava/lang/String;","Ljava/lang/String;"},"Lorg/mortbay/jetty/security/Password;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/jetty/security/SslSocketConnector;","_keyPassword","Lorg/mortbay/jetty/security/Password;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m026_setKeystore(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/SslSocketConnector;","setKeystore",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"keystore");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(487,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(488,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/security/SslSocketConnector;","_keystore","Ljava/lang/String;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m027_setKeystoreType(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/SslSocketConnector;","setKeystoreType",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"keystoreType");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(493,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(494,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/security/SslSocketConnector;","_keystoreType","Ljava/lang/String;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m028_setNeedClientAuth(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/SslSocketConnector;","setNeedClientAuth",new String[]{ "Z"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"needClientAuth");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(504,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(505,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_BOOLEAN,1,0,new Field("Lorg/mortbay/jetty/security/SslSocketConnector;","_needClientAuth","Z"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m029_setPassword(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/SslSocketConnector;","setPassword",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"password");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(510,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(511,L1);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_STRING,0,"jetty.ssl.password");
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,3,1},new Method("Lorg/mortbay/jetty/security/Password;","getPassword",new String[]{ "Ljava/lang/String;","Ljava/lang/String;","Ljava/lang/String;"},"Lorg/mortbay/jetty/security/Password;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/jetty/security/SslSocketConnector;","_password","Lorg/mortbay/jetty/security/Password;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m030_setProtocol(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/SslSocketConnector;","setProtocol",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"protocol");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(522,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(523,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/security/SslSocketConnector;","_protocol","Ljava/lang/String;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m031_setProvider(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/SslSocketConnector;","setProvider",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"_provider");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(527,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(528,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/security/SslSocketConnector;","_provider","Ljava/lang/String;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m032_setSecureRandomAlgorithm(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/SslSocketConnector;","setSecureRandomAlgorithm",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"algorithm");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(533,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(534,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/security/SslSocketConnector;","_secureRandomAlgorithm","Ljava/lang/String;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m033_setSslKeyManagerFactoryAlgorithm(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/SslSocketConnector;","setSslKeyManagerFactoryAlgorithm",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"algorithm");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(539,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(540,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/security/SslSocketConnector;","_sslKeyManagerFactoryAlgorithm","Ljava/lang/String;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m034_setSslTrustManagerFactoryAlgorithm(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/SslSocketConnector;","setSslTrustManagerFactoryAlgorithm",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"algorithm");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(545,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(546,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/security/SslSocketConnector;","_sslTrustManagerFactoryAlgorithm","Ljava/lang/String;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m035_setTrustPassword(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/SslSocketConnector;","setTrustPassword",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"password");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(516,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(517,L1);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_STRING,0,"jetty.ssl.password");
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,3,1},new Method("Lorg/mortbay/jetty/security/Password;","getPassword",new String[]{ "Ljava/lang/String;","Ljava/lang/String;","Ljava/lang/String;"},"Lorg/mortbay/jetty/security/Password;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/jetty/security/SslSocketConnector;","_trustPassword","Lorg/mortbay/jetty/security/Password;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m036_setTruststore(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/SslSocketConnector;","setTruststore",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"truststore");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(551,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(552,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/security/SslSocketConnector;","_truststore","Ljava/lang/String;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m037_setTruststoreType(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/SslSocketConnector;","setTruststoreType",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"truststoreType");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(557,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(558,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/security/SslSocketConnector;","_truststoreType","Ljava/lang/String;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m038_setWantClientAuth(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/SslSocketConnector;","setWantClientAuth",new String[]{ "Z"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"wantClientAuth");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(570,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(571,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_BOOLEAN,1,0,new Field("Lorg/mortbay/jetty/security/SslSocketConnector;","_wantClientAuth","Z"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
