package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0011_javax_servlet_ServletContextListener {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC|ACC_INTERFACE|ACC_ABSTRACT,"Ljavax/servlet/ServletContextListener;","Ljava/lang/Object;",new String[]{ "Ljava/util/EventListener;"});
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("ServletContextListener.java");
        m000_contextDestroyed(cv);
        m001_contextInitialized(cv);
    }
    public static void m000_contextDestroyed(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Ljavax/servlet/ServletContextListener;","contextDestroyed",new String[]{ "Ljavax/servlet/ServletContextEvent;"},"V"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m001_contextInitialized(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Ljavax/servlet/ServletContextListener;","contextInitialized",new String[]{ "Ljavax/servlet/ServletContextEvent;"},"V"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
}
