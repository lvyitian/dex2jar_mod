package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0223_org_mortbay_jetty_client_SocketConnector {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(0,"Lorg/mortbay/jetty/client/SocketConnector;","Lorg/mortbay/component/AbstractLifeCycle;",new String[]{ "Lorg/mortbay/jetty/client/HttpClient$Connector;"});
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("SocketConnector.java");
        f000__httpClient(cv);
        m000__init_(cv);
        m001_startConnection(cv);
    }
    public static void f000__httpClient(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_FINAL, new Field("Lorg/mortbay/jetty/client/SocketConnector;","_httpClient","Lorg/mortbay/jetty/client/HttpClient;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/client/SocketConnector;","<init>",new String[]{ "Lorg/mortbay/jetty/client/HttpClient;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"httpClient");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(39,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(40,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(41,L2);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Lorg/mortbay/component/AbstractLifeCycle;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/client/SocketConnector;","_httpClient","Lorg/mortbay/jetty/client/HttpClient;"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001_startConnection(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/client/SocketConnector;","startConnection",new String[]{ "Lorg/mortbay/jetty/client/HttpDestination;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(10);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"destination");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(45,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(47,L1);
                ddv.visitStartLocal(3,L1,"socket","Ljava/net/Socket;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(49,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(50,L3);
                ddv.visitStartLocal(4,L3,"sslContext","Ljavax/net/ssl/SSLContext;",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(58,L4);
                ddv.visitEndLocal(4,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(59,L5);
                ddv.visitStartLocal(0,L5,"address","Lorg/mortbay/jetty/client/Address;",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(61,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(63,L7);
                ddv.visitStartLocal(2,L7,"endpoint","Lorg/mortbay/io/EndPoint;",null);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(64,L8);
                ddv.visitStartLocal(1,L8,"connection","Lorg/mortbay/jetty/client/HttpConnection;",null);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(65,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(66,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(87,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(54,L12);
                ddv.visitEndLocal(0,L12);
                ddv.visitEndLocal(2,L12);
                ddv.visitEndLocal(1,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(55,L13);
                DexLabel L14=new DexLabel();
                ddv.visitRestartLocal(3,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(58,L15);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9},new Method("Lorg/mortbay/jetty/client/HttpDestination;","isSecure",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitJumpStmt(IF_EQZ,5,-1,L12);
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,5,8,new Field("Lorg/mortbay/jetty/client/SocketConnector;","_httpClient","Lorg/mortbay/jetty/client/HttpClient;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/jetty/client/HttpClient;","getSSLContext",new String[]{ },"Ljavax/net/ssl/SSLContext;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljavax/net/ssl/SSLContext;","getSocketFactory",new String[]{ },"Ljavax/net/ssl/SSLSocketFactory;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljavax/net/ssl/SSLSocketFactory;","createSocket",new String[]{ },"Ljava/net/Socket;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9},new Method("Lorg/mortbay/jetty/client/HttpDestination;","isProxied",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitJumpStmt(IF_EQZ,5,-1,L15);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9},new Method("Lorg/mortbay/jetty/client/HttpDestination;","getProxy",new String[]{ },"Lorg/mortbay/jetty/client/Address;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitStmt2R(MOVE_OBJECT,0,5);
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/client/Address;","toSocketAddress",new String[]{ },"Ljava/net/InetSocketAddress;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,5},new Method("Ljava/net/Socket;","connect",new String[]{ "Ljava/net/SocketAddress;"},"V"));
                code.visitLabel(L6);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Lorg/mortbay/io/bio/SocketEndPoint;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2,3},new Method("Lorg/mortbay/io/bio/SocketEndPoint;","<init>",new String[]{ "Ljava/net/Socket;"},"V"));
                code.visitLabel(L7);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Lorg/mortbay/jetty/client/HttpConnection;");
                code.visitFieldStmt(IGET_OBJECT,5,8,new Field("Lorg/mortbay/jetty/client/SocketConnector;","_httpClient","Lorg/mortbay/jetty/client/HttpClient;"));
                code.visitFieldStmt(IGET_OBJECT,6,8,new Field("Lorg/mortbay/jetty/client/SocketConnector;","_httpClient","Lorg/mortbay/jetty/client/HttpClient;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/client/HttpClient;","getHeaderBufferSize",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitFieldStmt(IGET_OBJECT,7,8,new Field("Lorg/mortbay/jetty/client/SocketConnector;","_httpClient","Lorg/mortbay/jetty/client/HttpClient;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Lorg/mortbay/jetty/client/HttpClient;","getRequestBufferSize",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,5,2,6,7},new Method("Lorg/mortbay/jetty/client/HttpConnection;","<init>",new String[]{ "Lorg/mortbay/io/Buffers;","Lorg/mortbay/io/EndPoint;","I","I"},"V"));
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,9},new Method("Lorg/mortbay/jetty/client/HttpConnection;","setDestination",new String[]{ "Lorg/mortbay/jetty/client/HttpDestination;"},"V"));
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9,1},new Method("Lorg/mortbay/jetty/client/HttpDestination;","onNewConnection",new String[]{ "Lorg/mortbay/jetty/client/HttpConnection;"},"V"));
                code.visitLabel(L10);
                code.visitFieldStmt(IGET_OBJECT,5,8,new Field("Lorg/mortbay/jetty/client/SocketConnector;","_httpClient","Lorg/mortbay/jetty/client/HttpClient;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/jetty/client/HttpClient;","getThreadPool",new String[]{ },"Lorg/mortbay/thread/ThreadPool;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitTypeStmt(NEW_INSTANCE,6,-1,"Lorg/mortbay/jetty/client/SocketConnector$1;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 6,8,1,9},new Method("Lorg/mortbay/jetty/client/SocketConnector$1;","<init>",new String[]{ "Lorg/mortbay/jetty/client/SocketConnector;","Lorg/mortbay/jetty/client/HttpConnection;","Lorg/mortbay/jetty/client/HttpDestination;"},"V"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 5,6},new Method("Lorg/mortbay/thread/ThreadPool;","dispatch",new String[]{ "Ljava/lang/Runnable;"},"Z"));
                code.visitLabel(L11);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L12);
                code.visitConstStmt(CONST_STRING,5,"Using Regular Socket");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 5},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L13);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Ljavax/net/SocketFactory;","getDefault",new String[]{ },"Ljavax/net/SocketFactory;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljavax/net/SocketFactory;","createSocket",new String[]{ },"Ljava/net/Socket;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitLabel(L14);
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitLabel(L15);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9},new Method("Lorg/mortbay/jetty/client/HttpDestination;","getAddress",new String[]{ },"Lorg/mortbay/jetty/client/Address;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitStmt2R(MOVE_OBJECT,0,5);
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
