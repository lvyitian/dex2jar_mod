package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0388_org_mortbay_servlet_jetty_IncludableGzipFilter_IncludableGzipStream {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/servlet/jetty/IncludableGzipFilter$IncludableGzipStream;","Lorg/mortbay/servlet/GzipFilter$GzipStream;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("IncludableGzipFilter.java");
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/EnclosingClass;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("value", new DexType("Lorg/mortbay/servlet/jetty/IncludableGzipFilter;"));
                av00.visitEnd();
            }
        }
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/InnerClass;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("accessFlags",  Integer.valueOf(1));
                av00.visit("name", "IncludableGzipStream");
                av00.visitEnd();
            }
        }
        f000_this$0(cv);
        m000__init_(cv);
        m001_setContentEncodingGzip(cv);
    }
    public static void f000_this$0(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_FINAL|ACC_SYNTHETIC, new Field("Lorg/mortbay/servlet/jetty/IncludableGzipFilter$IncludableGzipStream;","this$0","Lorg/mortbay/servlet/jetty/IncludableGzipFilter;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/servlet/jetty/IncludableGzipFilter$IncludableGzipStream;","<init>",new String[]{ "Lorg/mortbay/servlet/jetty/IncludableGzipFilter;","Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;","J","I","I"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(15);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(1,"request");
                ddv.visitParameterName(2,"response");
                ddv.visitParameterName(3,"contentLength");
                ddv.visitParameterName(4,"bufferSize");
                ddv.visitParameterName(5,"minGzipSize");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(61,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(62,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(63,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,8,7,new Field("Lorg/mortbay/servlet/jetty/IncludableGzipFilter$IncludableGzipStream;","this$0","Lorg/mortbay/servlet/jetty/IncludableGzipFilter;"));
                code.visitStmt2R(MOVE_OBJECT,0,7);
                code.visitStmt2R(MOVE_OBJECT,1,9);
                code.visitStmt2R(MOVE_OBJECT,2,10);
                code.visitStmt2R(MOVE_WIDE,3,11);
                code.visitStmt2R(MOVE,5,13);
                code.visitStmt2R(MOVE,6,14);
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_DIRECT_RANGE,new int[]{ 0,1,2,3,4,5,6},new Method("Lorg/mortbay/servlet/GzipFilter$GzipStream;","<init>",new String[]{ "Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;","J","I","I"},"V"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001_setContentEncodingGzip(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/servlet/jetty/IncludableGzipFilter$IncludableGzipStream;","setContentEncodingGzip",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(67,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(68,L1);
                ddv.visitStartLocal(0,L1,"connection","Lorg/mortbay/jetty/HttpConnection;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(69,L2);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/jetty/HttpConnection;","getCurrentConnection",new String[]{ },"Lorg/mortbay/jetty/HttpConnection;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/HttpConnection;","getResponseFields",new String[]{ },"Lorg/mortbay/jetty/HttpFields;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitConstStmt(CONST_STRING,2,"Content-Encoding");
                code.visitConstStmt(CONST_STRING,3,"gzip");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2,3},new Method("Lorg/mortbay/jetty/HttpFields;","put",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"V"));
                code.visitLabel(L2);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt1R(RETURN,1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
