package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0174_org_mortbay_jetty_HttpStatus {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/jetty/HttpStatus;","Ljava/lang/Object;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("HttpStatus.java");
        f000_Accepted(cv);
        f001_Accepted_BUFFER(cv);
        f002_Bad_Gateway(cv);
        f003_Bad_Gateway_BUFFER(cv);
        f004_Bad_Request(cv);
        f005_Bad_Request_BUFFER(cv);
        f006_CACHE(cv);
        f007_Conflict(cv);
        f008_Conflict_BUFFER(cv);
        f009_Continue(cv);
        f010_Continue_BUFFER(cv);
        f011_Created(cv);
        f012_Created_BUFFER(cv);
        f013_Expectation_Failed(cv);
        f014_Expectation_Failed_BUFFER(cv);
        f015_Failed_Dependency(cv);
        f016_Failed_Dependency_BUFFER(cv);
        f017_Forbidden(cv);
        f018_Forbidden_BUFFER(cv);
        f019_Found(cv);
        f020_Found_BUFFER(cv);
        f021_Gateway_Timeout(cv);
        f022_Gateway_Timeout_BUFFER(cv);
        f023_Gone(cv);
        f024_Gone_BUFFER(cv);
        f025_HTTP_Version_Not_Supported(cv);
        f026_HTTP_Version_Not_Supported_BUFFER(cv);
        f027_Insufficient_Storage(cv);
        f028_Insufficient_Storage_BUFFER(cv);
        f029_Internal_Server_Error(cv);
        f030_Internal_Server_Error_BUFFER(cv);
        f031_Length_Required(cv);
        f032_Length_Required_BUFFER(cv);
        f033_Locked(cv);
        f034_Locked_BUFFER(cv);
        f035_Method_Not_Allowed(cv);
        f036_Method_Not_Allowed_BUFFER(cv);
        f037_Moved_Permanently(cv);
        f038_Moved_Permanently_BUFFER(cv);
        f039_Moved_Temporarily(cv);
        f040_Moved_Temporarily_BUFFER(cv);
        f041_Multi_Status(cv);
        f042_Multi_Status_BUFFER(cv);
        f043_Multiple_Choices(cv);
        f044_Multiple_Choices_BUFFER(cv);
        f045_No_Content(cv);
        f046_No_Content_BUFFER(cv);
        f047_Non_Authoritative_Information(cv);
        f048_Non_Authoritative_Information_BUFFER(cv);
        f049_Not_Acceptable(cv);
        f050_Not_Acceptable_BUFFER(cv);
        f051_Not_Found(cv);
        f052_Not_Found_BUFFER(cv);
        f053_Not_Implemented(cv);
        f054_Not_Implemented_BUFFER(cv);
        f055_Not_Modified(cv);
        f056_Not_Modified_BUFFER(cv);
        f057_OK(cv);
        f058_OK_BUFFER(cv);
        f059_ORDINAL_100_Continue(cv);
        f060_ORDINAL_101_Switching_Protocols(cv);
        f061_ORDINAL_102_Processing(cv);
        f062_ORDINAL_200_OK(cv);
        f063_ORDINAL_201_Created(cv);
        f064_ORDINAL_202_Accepted(cv);
        f065_ORDINAL_203_Non_Authoritative_Information(cv);
        f066_ORDINAL_204_No_Content(cv);
        f067_ORDINAL_205_Reset_Content(cv);
        f068_ORDINAL_206_Partial_Content(cv);
        f069_ORDINAL_207_Multi_Status(cv);
        f070_ORDINAL_300_Multiple_Choices(cv);
        f071_ORDINAL_301_Moved_Permanently(cv);
        f072_ORDINAL_302_Found(cv);
        f073_ORDINAL_302_Moved_Temporarily(cv);
        f074_ORDINAL_303_See_Other(cv);
        f075_ORDINAL_304_Not_Modified(cv);
        f076_ORDINAL_305_Use_Proxy(cv);
        f077_ORDINAL_400_Bad_Request(cv);
        f078_ORDINAL_401_Unauthorized(cv);
        f079_ORDINAL_402_Payment_Required(cv);
        f080_ORDINAL_403_Forbidden(cv);
        f081_ORDINAL_404_Not_Found(cv);
        f082_ORDINAL_405_Method_Not_Allowed(cv);
        f083_ORDINAL_406_Not_Acceptable(cv);
        f084_ORDINAL_407_Proxy_Authentication_Required(cv);
        f085_ORDINAL_408_Request_Timeout(cv);
        f086_ORDINAL_409_Conflict(cv);
        f087_ORDINAL_410_Gone(cv);
        f088_ORDINAL_411_Length_Required(cv);
        f089_ORDINAL_412_Precondition_Failed(cv);
        f090_ORDINAL_413_Request_Entity_Too_Large(cv);
        f091_ORDINAL_414_Request_URI_Too_Large(cv);
        f092_ORDINAL_415_Unsupported_Media_Type(cv);
        f093_ORDINAL_416_Requested_Range_Not_Satisfiable(cv);
        f094_ORDINAL_417_Expectation_Failed(cv);
        f095_ORDINAL_422_Unprocessable_Entity(cv);
        f096_ORDINAL_423_Locked(cv);
        f097_ORDINAL_424_Failed_Dependency(cv);
        f098_ORDINAL_500_Internal_Server_Error(cv);
        f099_ORDINAL_501_Not_Implemented(cv);
        f100_ORDINAL_502_Bad_Gateway(cv);
        f101_ORDINAL_503_Service_Unavailable(cv);
        f102_ORDINAL_504_Gateway_Timeout(cv);
        f103_ORDINAL_505_HTTP_Version_Not_Supported(cv);
        f104_ORDINAL_507_Insufficient_Storage(cv);
        f105_ORDINAL_999_Unknown(cv);
        f106_Partial_Content(cv);
        f107_Partial_Content_BUFFER(cv);
        f108_Payment_Required(cv);
        f109_Payment_Required_BUFFER(cv);
        f110_Precondition_Failed(cv);
        f111_Precondition_Failed_BUFFER(cv);
        f112_Processing(cv);
        f113_Processing_BUFFER(cv);
        f114_Proxy_Authentication_Required(cv);
        f115_Proxy_Authentication_Required_BUFFER(cv);
        f116_Request_Entity_Too_Large(cv);
        f117_Request_Entity_Too_Large_BUFFER(cv);
        f118_Request_Timeout(cv);
        f119_Request_Timeout_BUFFER(cv);
        f120_Request_URI_Too_Large(cv);
        f121_Request_URI_Too_Large_BUFFER(cv);
        f122_Requested_Range_Not_Satisfiable(cv);
        f123_Requested_Range_Not_Satisfiable_BUFFER(cv);
        f124_Reset_Content(cv);
        f125_Reset_Content_BUFFER(cv);
        f126_See_Other(cv);
        f127_See_Other_BUFFER(cv);
        f128_Service_Unavailable(cv);
        f129_Service_Unavailable_BUFFER(cv);
        f130_Switching_Protocols(cv);
        f131_Switching_Protocols_BUFFER(cv);
        f132_Unauthorized(cv);
        f133_Unauthorized_BUFFER(cv);
        f134_Unknown(cv);
        f135_Unknown_BUFFER(cv);
        f136_Unprocessable_Entity(cv);
        f137_Unprocessable_Entity_BUFFER(cv);
        f138_Unsupported_Media_Type(cv);
        f139_Unsupported_Media_Type_BUFFER(cv);
        f140_Use_Proxy(cv);
        f141_Use_Proxy_BUFFER(cv);
        f142___responseLine(cv);
        m000__clinit_(cv);
        m001__init_(cv);
        m002_getResponseLine(cv);
    }
    public static void f000_Accepted(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","Accepted","Ljava/lang/String;"), "Accepted");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001_Accepted_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","Accepted_BUFFER","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002_Bad_Gateway(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","Bad_Gateway","Ljava/lang/String;"), "Bad Gateway");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003_Bad_Gateway_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","Bad_Gateway_BUFFER","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f004_Bad_Request(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","Bad_Request","Ljava/lang/String;"), "Bad Request");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f005_Bad_Request_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","Bad_Request_BUFFER","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f006_CACHE(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","CACHE","Lorg/mortbay/io/BufferCache;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f007_Conflict(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","Conflict","Ljava/lang/String;"), "Conflict");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f008_Conflict_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","Conflict_BUFFER","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f009_Continue(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","Continue","Ljava/lang/String;"), "Continue");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f010_Continue_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","Continue_BUFFER","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f011_Created(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","Created","Ljava/lang/String;"), "Created");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f012_Created_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","Created_BUFFER","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f013_Expectation_Failed(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","Expectation_Failed","Ljava/lang/String;"), "Expectation Failed");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f014_Expectation_Failed_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","Expectation_Failed_BUFFER","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f015_Failed_Dependency(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","Failed_Dependency","Ljava/lang/String;"), "Failed Dependency");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f016_Failed_Dependency_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","Failed_Dependency_BUFFER","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f017_Forbidden(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","Forbidden","Ljava/lang/String;"), "Forbidden");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f018_Forbidden_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","Forbidden_BUFFER","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f019_Found(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","Found","Ljava/lang/String;"), "Found");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f020_Found_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","Found_BUFFER","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f021_Gateway_Timeout(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","Gateway_Timeout","Ljava/lang/String;"), "Gateway Timeout");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f022_Gateway_Timeout_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","Gateway_Timeout_BUFFER","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f023_Gone(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","Gone","Ljava/lang/String;"), "Gone");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f024_Gone_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","Gone_BUFFER","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f025_HTTP_Version_Not_Supported(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","HTTP_Version_Not_Supported","Ljava/lang/String;"), "HTTP Version Not Supported");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f026_HTTP_Version_Not_Supported_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","HTTP_Version_Not_Supported_BUFFER","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f027_Insufficient_Storage(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","Insufficient_Storage","Ljava/lang/String;"), "Insufficient Storage");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f028_Insufficient_Storage_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","Insufficient_Storage_BUFFER","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f029_Internal_Server_Error(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","Internal_Server_Error","Ljava/lang/String;"), "Internal Server Error");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f030_Internal_Server_Error_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","Internal_Server_Error_BUFFER","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f031_Length_Required(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","Length_Required","Ljava/lang/String;"), "Length Required");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f032_Length_Required_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","Length_Required_BUFFER","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f033_Locked(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","Locked","Ljava/lang/String;"), "Locked");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f034_Locked_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","Locked_BUFFER","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f035_Method_Not_Allowed(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","Method_Not_Allowed","Ljava/lang/String;"), "Method Not Allowed");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f036_Method_Not_Allowed_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","Method_Not_Allowed_BUFFER","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f037_Moved_Permanently(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","Moved_Permanently","Ljava/lang/String;"), "Moved Permanently");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f038_Moved_Permanently_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","Moved_Permanently_BUFFER","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f039_Moved_Temporarily(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","Moved_Temporarily","Ljava/lang/String;"), "Moved Temporarily");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f040_Moved_Temporarily_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","Moved_Temporarily_BUFFER","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f041_Multi_Status(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","Multi_Status","Ljava/lang/String;"), "Multi Status");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f042_Multi_Status_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","Multi_Status_BUFFER","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f043_Multiple_Choices(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","Multiple_Choices","Ljava/lang/String;"), "Multiple Choices");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f044_Multiple_Choices_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","Multiple_Choices_BUFFER","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f045_No_Content(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","No_Content","Ljava/lang/String;"), "No Content");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f046_No_Content_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","No_Content_BUFFER","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f047_Non_Authoritative_Information(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","Non_Authoritative_Information","Ljava/lang/String;"), "Non Authoritative Information");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f048_Non_Authoritative_Information_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","Non_Authoritative_Information_BUFFER","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f049_Not_Acceptable(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","Not_Acceptable","Ljava/lang/String;"), "Not Acceptable");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f050_Not_Acceptable_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","Not_Acceptable_BUFFER","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f051_Not_Found(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","Not_Found","Ljava/lang/String;"), "Not Found");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f052_Not_Found_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","Not_Found_BUFFER","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f053_Not_Implemented(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","Not_Implemented","Ljava/lang/String;"), "Not Implemented");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f054_Not_Implemented_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","Not_Implemented_BUFFER","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f055_Not_Modified(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","Not_Modified","Ljava/lang/String;"), "Not Modified");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f056_Not_Modified_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","Not_Modified_BUFFER","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f057_OK(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","OK","Ljava/lang/String;"), "OK");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f058_OK_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","OK_BUFFER","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f059_ORDINAL_100_Continue(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","ORDINAL_100_Continue","I"),  Integer.valueOf(100));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f060_ORDINAL_101_Switching_Protocols(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","ORDINAL_101_Switching_Protocols","I"),  Integer.valueOf(101));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f061_ORDINAL_102_Processing(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","ORDINAL_102_Processing","I"),  Integer.valueOf(102));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f062_ORDINAL_200_OK(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","ORDINAL_200_OK","I"),  Integer.valueOf(200));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f063_ORDINAL_201_Created(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","ORDINAL_201_Created","I"),  Integer.valueOf(201));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f064_ORDINAL_202_Accepted(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","ORDINAL_202_Accepted","I"),  Integer.valueOf(202));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f065_ORDINAL_203_Non_Authoritative_Information(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","ORDINAL_203_Non_Authoritative_Information","I"),  Integer.valueOf(203));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f066_ORDINAL_204_No_Content(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","ORDINAL_204_No_Content","I"),  Integer.valueOf(204));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f067_ORDINAL_205_Reset_Content(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","ORDINAL_205_Reset_Content","I"),  Integer.valueOf(205));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f068_ORDINAL_206_Partial_Content(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","ORDINAL_206_Partial_Content","I"),  Integer.valueOf(206));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f069_ORDINAL_207_Multi_Status(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","ORDINAL_207_Multi_Status","I"),  Integer.valueOf(207));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f070_ORDINAL_300_Multiple_Choices(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","ORDINAL_300_Multiple_Choices","I"),  Integer.valueOf(300));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f071_ORDINAL_301_Moved_Permanently(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","ORDINAL_301_Moved_Permanently","I"),  Integer.valueOf(301));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f072_ORDINAL_302_Found(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","ORDINAL_302_Found","I"),  Integer.valueOf(302));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f073_ORDINAL_302_Moved_Temporarily(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","ORDINAL_302_Moved_Temporarily","I"),  Integer.valueOf(302));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f074_ORDINAL_303_See_Other(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","ORDINAL_303_See_Other","I"),  Integer.valueOf(303));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f075_ORDINAL_304_Not_Modified(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","ORDINAL_304_Not_Modified","I"),  Integer.valueOf(304));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f076_ORDINAL_305_Use_Proxy(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","ORDINAL_305_Use_Proxy","I"),  Integer.valueOf(305));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f077_ORDINAL_400_Bad_Request(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","ORDINAL_400_Bad_Request","I"),  Integer.valueOf(400));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f078_ORDINAL_401_Unauthorized(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","ORDINAL_401_Unauthorized","I"),  Integer.valueOf(401));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f079_ORDINAL_402_Payment_Required(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","ORDINAL_402_Payment_Required","I"),  Integer.valueOf(402));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f080_ORDINAL_403_Forbidden(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","ORDINAL_403_Forbidden","I"),  Integer.valueOf(403));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f081_ORDINAL_404_Not_Found(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","ORDINAL_404_Not_Found","I"),  Integer.valueOf(404));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f082_ORDINAL_405_Method_Not_Allowed(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","ORDINAL_405_Method_Not_Allowed","I"),  Integer.valueOf(405));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f083_ORDINAL_406_Not_Acceptable(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","ORDINAL_406_Not_Acceptable","I"),  Integer.valueOf(406));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f084_ORDINAL_407_Proxy_Authentication_Required(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","ORDINAL_407_Proxy_Authentication_Required","I"),  Integer.valueOf(407));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f085_ORDINAL_408_Request_Timeout(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","ORDINAL_408_Request_Timeout","I"),  Integer.valueOf(408));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f086_ORDINAL_409_Conflict(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","ORDINAL_409_Conflict","I"),  Integer.valueOf(409));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f087_ORDINAL_410_Gone(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","ORDINAL_410_Gone","I"),  Integer.valueOf(410));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f088_ORDINAL_411_Length_Required(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","ORDINAL_411_Length_Required","I"),  Integer.valueOf(411));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f089_ORDINAL_412_Precondition_Failed(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","ORDINAL_412_Precondition_Failed","I"),  Integer.valueOf(412));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f090_ORDINAL_413_Request_Entity_Too_Large(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","ORDINAL_413_Request_Entity_Too_Large","I"),  Integer.valueOf(413));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f091_ORDINAL_414_Request_URI_Too_Large(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","ORDINAL_414_Request_URI_Too_Large","I"),  Integer.valueOf(414));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f092_ORDINAL_415_Unsupported_Media_Type(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","ORDINAL_415_Unsupported_Media_Type","I"),  Integer.valueOf(415));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f093_ORDINAL_416_Requested_Range_Not_Satisfiable(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","ORDINAL_416_Requested_Range_Not_Satisfiable","I"),  Integer.valueOf(416));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f094_ORDINAL_417_Expectation_Failed(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","ORDINAL_417_Expectation_Failed","I"),  Integer.valueOf(417));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f095_ORDINAL_422_Unprocessable_Entity(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","ORDINAL_422_Unprocessable_Entity","I"),  Integer.valueOf(422));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f096_ORDINAL_423_Locked(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","ORDINAL_423_Locked","I"),  Integer.valueOf(423));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f097_ORDINAL_424_Failed_Dependency(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","ORDINAL_424_Failed_Dependency","I"),  Integer.valueOf(424));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f098_ORDINAL_500_Internal_Server_Error(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","ORDINAL_500_Internal_Server_Error","I"),  Integer.valueOf(500));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f099_ORDINAL_501_Not_Implemented(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","ORDINAL_501_Not_Implemented","I"),  Integer.valueOf(501));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f100_ORDINAL_502_Bad_Gateway(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","ORDINAL_502_Bad_Gateway","I"),  Integer.valueOf(502));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f101_ORDINAL_503_Service_Unavailable(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","ORDINAL_503_Service_Unavailable","I"),  Integer.valueOf(503));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f102_ORDINAL_504_Gateway_Timeout(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","ORDINAL_504_Gateway_Timeout","I"),  Integer.valueOf(504));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f103_ORDINAL_505_HTTP_Version_Not_Supported(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","ORDINAL_505_HTTP_Version_Not_Supported","I"),  Integer.valueOf(505));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f104_ORDINAL_507_Insufficient_Storage(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","ORDINAL_507_Insufficient_Storage","I"),  Integer.valueOf(507));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f105_ORDINAL_999_Unknown(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","ORDINAL_999_Unknown","I"),  Integer.valueOf(999));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f106_Partial_Content(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","Partial_Content","Ljava/lang/String;"), "Partial Content");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f107_Partial_Content_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","Partial_Content_BUFFER","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f108_Payment_Required(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","Payment_Required","Ljava/lang/String;"), "Payment Required");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f109_Payment_Required_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","Payment_Required_BUFFER","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f110_Precondition_Failed(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","Precondition_Failed","Ljava/lang/String;"), "Precondition Failed");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f111_Precondition_Failed_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","Precondition_Failed_BUFFER","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f112_Processing(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","Processing","Ljava/lang/String;"), "Processing");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f113_Processing_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","Processing_BUFFER","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f114_Proxy_Authentication_Required(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","Proxy_Authentication_Required","Ljava/lang/String;"), "Proxy Authentication Required");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f115_Proxy_Authentication_Required_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","Proxy_Authentication_Required_BUFFER","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f116_Request_Entity_Too_Large(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","Request_Entity_Too_Large","Ljava/lang/String;"), "Request Entity Too Large");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f117_Request_Entity_Too_Large_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","Request_Entity_Too_Large_BUFFER","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f118_Request_Timeout(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","Request_Timeout","Ljava/lang/String;"), "Request Timeout");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f119_Request_Timeout_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","Request_Timeout_BUFFER","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f120_Request_URI_Too_Large(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","Request_URI_Too_Large","Ljava/lang/String;"), "Request URI Too Large");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f121_Request_URI_Too_Large_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","Request_URI_Too_Large_BUFFER","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f122_Requested_Range_Not_Satisfiable(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","Requested_Range_Not_Satisfiable","Ljava/lang/String;"), "Requested Range Not Satisfiable");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f123_Requested_Range_Not_Satisfiable_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","Requested_Range_Not_Satisfiable_BUFFER","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f124_Reset_Content(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","Reset_Content","Ljava/lang/String;"), "Reset Content");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f125_Reset_Content_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","Reset_Content_BUFFER","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f126_See_Other(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","See_Other","Ljava/lang/String;"), "See Other");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f127_See_Other_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","See_Other_BUFFER","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f128_Service_Unavailable(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","Service_Unavailable","Ljava/lang/String;"), "Service Unavailable");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f129_Service_Unavailable_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","Service_Unavailable_BUFFER","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f130_Switching_Protocols(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","Switching_Protocols","Ljava/lang/String;"), "Switching Protocols");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f131_Switching_Protocols_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","Switching_Protocols_BUFFER","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f132_Unauthorized(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","Unauthorized","Ljava/lang/String;"), "Unauthorized");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f133_Unauthorized_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","Unauthorized_BUFFER","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f134_Unknown(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","Unknown","Ljava/lang/String;"), "Unknown");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f135_Unknown_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","Unknown_BUFFER","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f136_Unprocessable_Entity(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","Unprocessable_Entity","Ljava/lang/String;"), "Unprocessable Entity");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f137_Unprocessable_Entity_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","Unprocessable_Entity_BUFFER","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f138_Unsupported_Media_Type(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","Unsupported_Media_Type","Ljava/lang/String;"), "Unsupported Media Type");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f139_Unsupported_Media_Type_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","Unsupported_Media_Type_BUFFER","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f140_Use_Proxy(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","Use_Proxy","Ljava/lang/String;"), "Use Proxy");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f141_Use_Proxy_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpStatus;","Use_Proxy_BUFFER","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f142___responseLine(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC, new Field("Lorg/mortbay/jetty/HttpStatus;","__responseLine","[Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__clinit_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/HttpStatus;","<clinit>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(10);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(124,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(127,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(128,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(129,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(130,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(131,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(132,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(133,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(134,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(135,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(136,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(137,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(138,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(139,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(140,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(141,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(142,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(143,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(144,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(145,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(146,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(147,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(148,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(149,L24);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(150,L25);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(151,L26);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(152,L27);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(153,L28);
                DexLabel L29=new DexLabel();
                ddv.visitLineNumber(154,L29);
                DexLabel L30=new DexLabel();
                ddv.visitLineNumber(155,L30);
                DexLabel L31=new DexLabel();
                ddv.visitLineNumber(156,L31);
                DexLabel L32=new DexLabel();
                ddv.visitLineNumber(157,L32);
                DexLabel L33=new DexLabel();
                ddv.visitLineNumber(158,L33);
                DexLabel L34=new DexLabel();
                ddv.visitLineNumber(159,L34);
                DexLabel L35=new DexLabel();
                ddv.visitLineNumber(160,L35);
                DexLabel L36=new DexLabel();
                ddv.visitLineNumber(161,L36);
                DexLabel L37=new DexLabel();
                ddv.visitLineNumber(162,L37);
                DexLabel L38=new DexLabel();
                ddv.visitLineNumber(163,L38);
                DexLabel L39=new DexLabel();
                ddv.visitLineNumber(164,L39);
                DexLabel L40=new DexLabel();
                ddv.visitLineNumber(165,L40);
                DexLabel L41=new DexLabel();
                ddv.visitLineNumber(166,L41);
                DexLabel L42=new DexLabel();
                ddv.visitLineNumber(167,L42);
                DexLabel L43=new DexLabel();
                ddv.visitLineNumber(168,L43);
                DexLabel L44=new DexLabel();
                ddv.visitLineNumber(169,L44);
                DexLabel L45=new DexLabel();
                ddv.visitLineNumber(170,L45);
                DexLabel L46=new DexLabel();
                ddv.visitLineNumber(171,L46);
                DexLabel L47=new DexLabel();
                ddv.visitLineNumber(172,L47);
                DexLabel L48=new DexLabel();
                ddv.visitLineNumber(173,L48);
                DexLabel L49=new DexLabel();
                ddv.visitLineNumber(177,L49);
                DexLabel L50=new DexLabel();
                ddv.visitLineNumber(180,L50);
                DexLabel L51=new DexLabel();
                ddv.visitLineNumber(182,L51);
                ddv.visitStartLocal(3,L51,"versionLength","I",null);
                DexLabel L52=new DexLabel();
                ddv.visitStartLocal(1,L52,"i","I",null);
                DexLabel L53=new DexLabel();
                ddv.visitLineNumber(184,L53);
                DexLabel L54=new DexLabel();
                ddv.visitLineNumber(185,L54);
                ddv.visitStartLocal(2,L54,"reason","Lorg/mortbay/io/Buffer;",null);
                DexLabel L55=new DexLabel();
                ddv.visitLineNumber(182,L55);
                DexLabel L56=new DexLabel();
                ddv.visitLineNumber(188,L56);
                DexLabel L57=new DexLabel();
                ddv.visitLineNumber(189,L57);
                ddv.visitStartLocal(0,L57,"bytes","[B",null);
                DexLabel L58=new DexLabel();
                ddv.visitLineNumber(190,L58);
                DexLabel L59=new DexLabel();
                ddv.visitLineNumber(191,L59);
                DexLabel L60=new DexLabel();
                ddv.visitLineNumber(192,L60);
                DexLabel L61=new DexLabel();
                ddv.visitLineNumber(193,L61);
                DexLabel L62=new DexLabel();
                ddv.visitLineNumber(194,L62);
                DexLabel L63=new DexLabel();
                ddv.visitLineNumber(195,L63);
                DexLabel L64=new DexLabel();
                ddv.visitLineNumber(196,L64);
                DexLabel L65=new DexLabel();
                ddv.visitLineNumber(197,L65);
                DexLabel L66=new DexLabel();
                ddv.visitLineNumber(198,L66);
                DexLabel L67=new DexLabel();
                ddv.visitLineNumber(200,L67);
                ddv.visitEndLocal(2,L67);
                ddv.visitEndLocal(0,L67);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_16,9, Integer.valueOf(302)); // int: 0x0000012e  float:0.000000
                code.visitConstStmt(CONST_16,8, Integer.valueOf(32)); // int: 0x00000020  float:0.000000
                code.visitConstStmt(CONST_4,7, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,4,-1,"Lorg/mortbay/io/BufferCache;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4},new Method("Lorg/mortbay/io/BufferCache;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(SPUT_OBJECT,4,-1,new Field("Lorg/mortbay/jetty/HttpStatus;","CACHE","Lorg/mortbay/io/BufferCache;"));
                code.visitLabel(L2);
                code.visitFieldStmt(SGET_OBJECT,4,-1,new Field("Lorg/mortbay/jetty/HttpStatus;","CACHE","Lorg/mortbay/io/BufferCache;"));
                code.visitConstStmt(CONST_STRING,5,"Continue");
                code.visitConstStmt(CONST_16,6, Integer.valueOf(100)); // int: 0x00000064  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5,6},new Method("Lorg/mortbay/io/BufferCache;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitFieldStmt(SPUT_OBJECT,4,-1,new Field("Lorg/mortbay/jetty/HttpStatus;","Continue_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L3);
                code.visitFieldStmt(SGET_OBJECT,4,-1,new Field("Lorg/mortbay/jetty/HttpStatus;","CACHE","Lorg/mortbay/io/BufferCache;"));
                code.visitConstStmt(CONST_STRING,5,"Switching Protocols");
                code.visitConstStmt(CONST_16,6, Integer.valueOf(101)); // int: 0x00000065  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5,6},new Method("Lorg/mortbay/io/BufferCache;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitFieldStmt(SPUT_OBJECT,4,-1,new Field("Lorg/mortbay/jetty/HttpStatus;","Switching_Protocols_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L4);
                code.visitFieldStmt(SGET_OBJECT,4,-1,new Field("Lorg/mortbay/jetty/HttpStatus;","CACHE","Lorg/mortbay/io/BufferCache;"));
                code.visitConstStmt(CONST_STRING,5,"Processing");
                code.visitConstStmt(CONST_16,6, Integer.valueOf(102)); // int: 0x00000066  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5,6},new Method("Lorg/mortbay/io/BufferCache;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitFieldStmt(SPUT_OBJECT,4,-1,new Field("Lorg/mortbay/jetty/HttpStatus;","Processing_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L5);
                code.visitFieldStmt(SGET_OBJECT,4,-1,new Field("Lorg/mortbay/jetty/HttpStatus;","CACHE","Lorg/mortbay/io/BufferCache;"));
                code.visitConstStmt(CONST_STRING,5,"OK");
                code.visitConstStmt(CONST_16,6, Integer.valueOf(200)); // int: 0x000000c8  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5,6},new Method("Lorg/mortbay/io/BufferCache;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitFieldStmt(SPUT_OBJECT,4,-1,new Field("Lorg/mortbay/jetty/HttpStatus;","OK_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L6);
                code.visitFieldStmt(SGET_OBJECT,4,-1,new Field("Lorg/mortbay/jetty/HttpStatus;","CACHE","Lorg/mortbay/io/BufferCache;"));
                code.visitConstStmt(CONST_STRING,5,"Created");
                code.visitConstStmt(CONST_16,6, Integer.valueOf(201)); // int: 0x000000c9  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5,6},new Method("Lorg/mortbay/io/BufferCache;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitFieldStmt(SPUT_OBJECT,4,-1,new Field("Lorg/mortbay/jetty/HttpStatus;","Created_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L7);
                code.visitFieldStmt(SGET_OBJECT,4,-1,new Field("Lorg/mortbay/jetty/HttpStatus;","CACHE","Lorg/mortbay/io/BufferCache;"));
                code.visitConstStmt(CONST_STRING,5,"Accepted");
                code.visitConstStmt(CONST_16,6, Integer.valueOf(202)); // int: 0x000000ca  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5,6},new Method("Lorg/mortbay/io/BufferCache;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitFieldStmt(SPUT_OBJECT,4,-1,new Field("Lorg/mortbay/jetty/HttpStatus;","Accepted_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L8);
                code.visitFieldStmt(SGET_OBJECT,4,-1,new Field("Lorg/mortbay/jetty/HttpStatus;","CACHE","Lorg/mortbay/io/BufferCache;"));
                code.visitConstStmt(CONST_STRING,5,"Non Authoritative Information");
                code.visitConstStmt(CONST_16,6, Integer.valueOf(203)); // int: 0x000000cb  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5,6},new Method("Lorg/mortbay/io/BufferCache;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitFieldStmt(SPUT_OBJECT,4,-1,new Field("Lorg/mortbay/jetty/HttpStatus;","Non_Authoritative_Information_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L9);
                code.visitFieldStmt(SGET_OBJECT,4,-1,new Field("Lorg/mortbay/jetty/HttpStatus;","CACHE","Lorg/mortbay/io/BufferCache;"));
                code.visitConstStmt(CONST_STRING,5,"No Content");
                code.visitConstStmt(CONST_16,6, Integer.valueOf(204)); // int: 0x000000cc  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5,6},new Method("Lorg/mortbay/io/BufferCache;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitFieldStmt(SPUT_OBJECT,4,-1,new Field("Lorg/mortbay/jetty/HttpStatus;","No_Content_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L10);
                code.visitFieldStmt(SGET_OBJECT,4,-1,new Field("Lorg/mortbay/jetty/HttpStatus;","CACHE","Lorg/mortbay/io/BufferCache;"));
                code.visitConstStmt(CONST_STRING,5,"Reset Content");
                code.visitConstStmt(CONST_16,6, Integer.valueOf(205)); // int: 0x000000cd  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5,6},new Method("Lorg/mortbay/io/BufferCache;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitFieldStmt(SPUT_OBJECT,4,-1,new Field("Lorg/mortbay/jetty/HttpStatus;","Reset_Content_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L11);
                code.visitFieldStmt(SGET_OBJECT,4,-1,new Field("Lorg/mortbay/jetty/HttpStatus;","CACHE","Lorg/mortbay/io/BufferCache;"));
                code.visitConstStmt(CONST_STRING,5,"Partial Content");
                code.visitConstStmt(CONST_16,6, Integer.valueOf(206)); // int: 0x000000ce  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5,6},new Method("Lorg/mortbay/io/BufferCache;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitFieldStmt(SPUT_OBJECT,4,-1,new Field("Lorg/mortbay/jetty/HttpStatus;","Partial_Content_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L12);
                code.visitFieldStmt(SGET_OBJECT,4,-1,new Field("Lorg/mortbay/jetty/HttpStatus;","CACHE","Lorg/mortbay/io/BufferCache;"));
                code.visitConstStmt(CONST_STRING,5,"Multi Status");
                code.visitConstStmt(CONST_16,6, Integer.valueOf(207)); // int: 0x000000cf  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5,6},new Method("Lorg/mortbay/io/BufferCache;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitFieldStmt(SPUT_OBJECT,4,-1,new Field("Lorg/mortbay/jetty/HttpStatus;","Multi_Status_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L13);
                code.visitFieldStmt(SGET_OBJECT,4,-1,new Field("Lorg/mortbay/jetty/HttpStatus;","CACHE","Lorg/mortbay/io/BufferCache;"));
                code.visitConstStmt(CONST_STRING,5,"Multiple Choices");
                code.visitConstStmt(CONST_16,6, Integer.valueOf(300)); // int: 0x0000012c  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5,6},new Method("Lorg/mortbay/io/BufferCache;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitFieldStmt(SPUT_OBJECT,4,-1,new Field("Lorg/mortbay/jetty/HttpStatus;","Multiple_Choices_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L14);
                code.visitFieldStmt(SGET_OBJECT,4,-1,new Field("Lorg/mortbay/jetty/HttpStatus;","CACHE","Lorg/mortbay/io/BufferCache;"));
                code.visitConstStmt(CONST_STRING,5,"Moved Permanently");
                code.visitConstStmt(CONST_16,6, Integer.valueOf(301)); // int: 0x0000012d  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5,6},new Method("Lorg/mortbay/io/BufferCache;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitFieldStmt(SPUT_OBJECT,4,-1,new Field("Lorg/mortbay/jetty/HttpStatus;","Moved_Permanently_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L15);
                code.visitFieldStmt(SGET_OBJECT,4,-1,new Field("Lorg/mortbay/jetty/HttpStatus;","CACHE","Lorg/mortbay/io/BufferCache;"));
                code.visitConstStmt(CONST_STRING,5,"Moved Temporarily");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5,9},new Method("Lorg/mortbay/io/BufferCache;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitFieldStmt(SPUT_OBJECT,4,-1,new Field("Lorg/mortbay/jetty/HttpStatus;","Moved_Temporarily_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L16);
                code.visitFieldStmt(SGET_OBJECT,4,-1,new Field("Lorg/mortbay/jetty/HttpStatus;","CACHE","Lorg/mortbay/io/BufferCache;"));
                code.visitConstStmt(CONST_STRING,5,"Found");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5,9},new Method("Lorg/mortbay/io/BufferCache;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitFieldStmt(SPUT_OBJECT,4,-1,new Field("Lorg/mortbay/jetty/HttpStatus;","Found_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L17);
                code.visitFieldStmt(SGET_OBJECT,4,-1,new Field("Lorg/mortbay/jetty/HttpStatus;","CACHE","Lorg/mortbay/io/BufferCache;"));
                code.visitConstStmt(CONST_STRING,5,"See Other");
                code.visitConstStmt(CONST_16,6, Integer.valueOf(303)); // int: 0x0000012f  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5,6},new Method("Lorg/mortbay/io/BufferCache;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitFieldStmt(SPUT_OBJECT,4,-1,new Field("Lorg/mortbay/jetty/HttpStatus;","See_Other_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L18);
                code.visitFieldStmt(SGET_OBJECT,4,-1,new Field("Lorg/mortbay/jetty/HttpStatus;","CACHE","Lorg/mortbay/io/BufferCache;"));
                code.visitConstStmt(CONST_STRING,5,"Not Modified");
                code.visitConstStmt(CONST_16,6, Integer.valueOf(304)); // int: 0x00000130  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5,6},new Method("Lorg/mortbay/io/BufferCache;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitFieldStmt(SPUT_OBJECT,4,-1,new Field("Lorg/mortbay/jetty/HttpStatus;","Not_Modified_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L19);
                code.visitFieldStmt(SGET_OBJECT,4,-1,new Field("Lorg/mortbay/jetty/HttpStatus;","CACHE","Lorg/mortbay/io/BufferCache;"));
                code.visitConstStmt(CONST_STRING,5,"Use Proxy");
                code.visitConstStmt(CONST_16,6, Integer.valueOf(305)); // int: 0x00000131  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5,6},new Method("Lorg/mortbay/io/BufferCache;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitFieldStmt(SPUT_OBJECT,4,-1,new Field("Lorg/mortbay/jetty/HttpStatus;","Use_Proxy_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L20);
                code.visitFieldStmt(SGET_OBJECT,4,-1,new Field("Lorg/mortbay/jetty/HttpStatus;","CACHE","Lorg/mortbay/io/BufferCache;"));
                code.visitConstStmt(CONST_STRING,5,"Bad Request");
                code.visitConstStmt(CONST_16,6, Integer.valueOf(400)); // int: 0x00000190  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5,6},new Method("Lorg/mortbay/io/BufferCache;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitFieldStmt(SPUT_OBJECT,4,-1,new Field("Lorg/mortbay/jetty/HttpStatus;","Bad_Request_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L21);
                code.visitFieldStmt(SGET_OBJECT,4,-1,new Field("Lorg/mortbay/jetty/HttpStatus;","CACHE","Lorg/mortbay/io/BufferCache;"));
                code.visitConstStmt(CONST_STRING,5,"Unauthorized");
                code.visitConstStmt(CONST_16,6, Integer.valueOf(401)); // int: 0x00000191  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5,6},new Method("Lorg/mortbay/io/BufferCache;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitFieldStmt(SPUT_OBJECT,4,-1,new Field("Lorg/mortbay/jetty/HttpStatus;","Unauthorized_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L22);
                code.visitFieldStmt(SGET_OBJECT,4,-1,new Field("Lorg/mortbay/jetty/HttpStatus;","CACHE","Lorg/mortbay/io/BufferCache;"));
                code.visitConstStmt(CONST_STRING,5,"Payment Required");
                code.visitConstStmt(CONST_16,6, Integer.valueOf(402)); // int: 0x00000192  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5,6},new Method("Lorg/mortbay/io/BufferCache;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitFieldStmt(SPUT_OBJECT,4,-1,new Field("Lorg/mortbay/jetty/HttpStatus;","Payment_Required_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L23);
                code.visitFieldStmt(SGET_OBJECT,4,-1,new Field("Lorg/mortbay/jetty/HttpStatus;","CACHE","Lorg/mortbay/io/BufferCache;"));
                code.visitConstStmt(CONST_STRING,5,"Forbidden");
                code.visitConstStmt(CONST_16,6, Integer.valueOf(403)); // int: 0x00000193  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5,6},new Method("Lorg/mortbay/io/BufferCache;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitFieldStmt(SPUT_OBJECT,4,-1,new Field("Lorg/mortbay/jetty/HttpStatus;","Forbidden_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L24);
                code.visitFieldStmt(SGET_OBJECT,4,-1,new Field("Lorg/mortbay/jetty/HttpStatus;","CACHE","Lorg/mortbay/io/BufferCache;"));
                code.visitConstStmt(CONST_STRING,5,"Not Found");
                code.visitConstStmt(CONST_16,6, Integer.valueOf(404)); // int: 0x00000194  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5,6},new Method("Lorg/mortbay/io/BufferCache;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitFieldStmt(SPUT_OBJECT,4,-1,new Field("Lorg/mortbay/jetty/HttpStatus;","Not_Found_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L25);
                code.visitFieldStmt(SGET_OBJECT,4,-1,new Field("Lorg/mortbay/jetty/HttpStatus;","CACHE","Lorg/mortbay/io/BufferCache;"));
                code.visitConstStmt(CONST_STRING,5,"Method Not Allowed");
                code.visitConstStmt(CONST_16,6, Integer.valueOf(405)); // int: 0x00000195  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5,6},new Method("Lorg/mortbay/io/BufferCache;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitFieldStmt(SPUT_OBJECT,4,-1,new Field("Lorg/mortbay/jetty/HttpStatus;","Method_Not_Allowed_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L26);
                code.visitFieldStmt(SGET_OBJECT,4,-1,new Field("Lorg/mortbay/jetty/HttpStatus;","CACHE","Lorg/mortbay/io/BufferCache;"));
                code.visitConstStmt(CONST_STRING,5,"Not Acceptable");
                code.visitConstStmt(CONST_16,6, Integer.valueOf(406)); // int: 0x00000196  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5,6},new Method("Lorg/mortbay/io/BufferCache;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitFieldStmt(SPUT_OBJECT,4,-1,new Field("Lorg/mortbay/jetty/HttpStatus;","Not_Acceptable_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L27);
                code.visitFieldStmt(SGET_OBJECT,4,-1,new Field("Lorg/mortbay/jetty/HttpStatus;","CACHE","Lorg/mortbay/io/BufferCache;"));
                code.visitConstStmt(CONST_STRING,5,"Proxy Authentication Required");
                code.visitConstStmt(CONST_16,6, Integer.valueOf(407)); // int: 0x00000197  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5,6},new Method("Lorg/mortbay/io/BufferCache;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitFieldStmt(SPUT_OBJECT,4,-1,new Field("Lorg/mortbay/jetty/HttpStatus;","Proxy_Authentication_Required_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L28);
                code.visitFieldStmt(SGET_OBJECT,4,-1,new Field("Lorg/mortbay/jetty/HttpStatus;","CACHE","Lorg/mortbay/io/BufferCache;"));
                code.visitConstStmt(CONST_STRING,5,"Request Timeout");
                code.visitConstStmt(CONST_16,6, Integer.valueOf(408)); // int: 0x00000198  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5,6},new Method("Lorg/mortbay/io/BufferCache;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitFieldStmt(SPUT_OBJECT,4,-1,new Field("Lorg/mortbay/jetty/HttpStatus;","Request_Timeout_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L29);
                code.visitFieldStmt(SGET_OBJECT,4,-1,new Field("Lorg/mortbay/jetty/HttpStatus;","CACHE","Lorg/mortbay/io/BufferCache;"));
                code.visitConstStmt(CONST_STRING,5,"Conflict");
                code.visitConstStmt(CONST_16,6, Integer.valueOf(409)); // int: 0x00000199  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5,6},new Method("Lorg/mortbay/io/BufferCache;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitFieldStmt(SPUT_OBJECT,4,-1,new Field("Lorg/mortbay/jetty/HttpStatus;","Conflict_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L30);
                code.visitFieldStmt(SGET_OBJECT,4,-1,new Field("Lorg/mortbay/jetty/HttpStatus;","CACHE","Lorg/mortbay/io/BufferCache;"));
                code.visitConstStmt(CONST_STRING,5,"Gone");
                code.visitConstStmt(CONST_16,6, Integer.valueOf(410)); // int: 0x0000019a  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5,6},new Method("Lorg/mortbay/io/BufferCache;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitFieldStmt(SPUT_OBJECT,4,-1,new Field("Lorg/mortbay/jetty/HttpStatus;","Gone_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L31);
                code.visitFieldStmt(SGET_OBJECT,4,-1,new Field("Lorg/mortbay/jetty/HttpStatus;","CACHE","Lorg/mortbay/io/BufferCache;"));
                code.visitConstStmt(CONST_STRING,5,"Length Required");
                code.visitConstStmt(CONST_16,6, Integer.valueOf(411)); // int: 0x0000019b  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5,6},new Method("Lorg/mortbay/io/BufferCache;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitFieldStmt(SPUT_OBJECT,4,-1,new Field("Lorg/mortbay/jetty/HttpStatus;","Length_Required_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L32);
                code.visitFieldStmt(SGET_OBJECT,4,-1,new Field("Lorg/mortbay/jetty/HttpStatus;","CACHE","Lorg/mortbay/io/BufferCache;"));
                code.visitConstStmt(CONST_STRING,5,"Precondition Failed");
                code.visitConstStmt(CONST_16,6, Integer.valueOf(412)); // int: 0x0000019c  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5,6},new Method("Lorg/mortbay/io/BufferCache;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitFieldStmt(SPUT_OBJECT,4,-1,new Field("Lorg/mortbay/jetty/HttpStatus;","Precondition_Failed_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L33);
                code.visitFieldStmt(SGET_OBJECT,4,-1,new Field("Lorg/mortbay/jetty/HttpStatus;","CACHE","Lorg/mortbay/io/BufferCache;"));
                code.visitConstStmt(CONST_STRING,5,"Request Entity Too Large");
                code.visitConstStmt(CONST_16,6, Integer.valueOf(413)); // int: 0x0000019d  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5,6},new Method("Lorg/mortbay/io/BufferCache;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitFieldStmt(SPUT_OBJECT,4,-1,new Field("Lorg/mortbay/jetty/HttpStatus;","Request_Entity_Too_Large_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L34);
                code.visitFieldStmt(SGET_OBJECT,4,-1,new Field("Lorg/mortbay/jetty/HttpStatus;","CACHE","Lorg/mortbay/io/BufferCache;"));
                code.visitConstStmt(CONST_STRING,5,"Request URI Too Large");
                code.visitConstStmt(CONST_16,6, Integer.valueOf(414)); // int: 0x0000019e  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5,6},new Method("Lorg/mortbay/io/BufferCache;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitFieldStmt(SPUT_OBJECT,4,-1,new Field("Lorg/mortbay/jetty/HttpStatus;","Request_URI_Too_Large_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L35);
                code.visitFieldStmt(SGET_OBJECT,4,-1,new Field("Lorg/mortbay/jetty/HttpStatus;","CACHE","Lorg/mortbay/io/BufferCache;"));
                code.visitConstStmt(CONST_STRING,5,"Unsupported Media Type");
                code.visitConstStmt(CONST_16,6, Integer.valueOf(415)); // int: 0x0000019f  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5,6},new Method("Lorg/mortbay/io/BufferCache;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitFieldStmt(SPUT_OBJECT,4,-1,new Field("Lorg/mortbay/jetty/HttpStatus;","Unsupported_Media_Type_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L36);
                code.visitFieldStmt(SGET_OBJECT,4,-1,new Field("Lorg/mortbay/jetty/HttpStatus;","CACHE","Lorg/mortbay/io/BufferCache;"));
                code.visitConstStmt(CONST_STRING,5,"Requested Range Not Satisfiable");
                code.visitConstStmt(CONST_16,6, Integer.valueOf(416)); // int: 0x000001a0  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5,6},new Method("Lorg/mortbay/io/BufferCache;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitFieldStmt(SPUT_OBJECT,4,-1,new Field("Lorg/mortbay/jetty/HttpStatus;","Requested_Range_Not_Satisfiable_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L37);
                code.visitFieldStmt(SGET_OBJECT,4,-1,new Field("Lorg/mortbay/jetty/HttpStatus;","CACHE","Lorg/mortbay/io/BufferCache;"));
                code.visitConstStmt(CONST_STRING,5,"Expectation Failed");
                code.visitConstStmt(CONST_16,6, Integer.valueOf(417)); // int: 0x000001a1  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5,6},new Method("Lorg/mortbay/io/BufferCache;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitFieldStmt(SPUT_OBJECT,4,-1,new Field("Lorg/mortbay/jetty/HttpStatus;","Expectation_Failed_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L38);
                code.visitFieldStmt(SGET_OBJECT,4,-1,new Field("Lorg/mortbay/jetty/HttpStatus;","CACHE","Lorg/mortbay/io/BufferCache;"));
                code.visitConstStmt(CONST_STRING,5,"Unprocessable Entity");
                code.visitConstStmt(CONST_16,6, Integer.valueOf(422)); // int: 0x000001a6  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5,6},new Method("Lorg/mortbay/io/BufferCache;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitFieldStmt(SPUT_OBJECT,4,-1,new Field("Lorg/mortbay/jetty/HttpStatus;","Unprocessable_Entity_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L39);
                code.visitFieldStmt(SGET_OBJECT,4,-1,new Field("Lorg/mortbay/jetty/HttpStatus;","CACHE","Lorg/mortbay/io/BufferCache;"));
                code.visitConstStmt(CONST_STRING,5,"Locked");
                code.visitConstStmt(CONST_16,6, Integer.valueOf(423)); // int: 0x000001a7  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5,6},new Method("Lorg/mortbay/io/BufferCache;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitFieldStmt(SPUT_OBJECT,4,-1,new Field("Lorg/mortbay/jetty/HttpStatus;","Locked_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L40);
                code.visitFieldStmt(SGET_OBJECT,4,-1,new Field("Lorg/mortbay/jetty/HttpStatus;","CACHE","Lorg/mortbay/io/BufferCache;"));
                code.visitConstStmt(CONST_STRING,5,"Failed Dependency");
                code.visitConstStmt(CONST_16,6, Integer.valueOf(424)); // int: 0x000001a8  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5,6},new Method("Lorg/mortbay/io/BufferCache;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitFieldStmt(SPUT_OBJECT,4,-1,new Field("Lorg/mortbay/jetty/HttpStatus;","Failed_Dependency_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L41);
                code.visitFieldStmt(SGET_OBJECT,4,-1,new Field("Lorg/mortbay/jetty/HttpStatus;","CACHE","Lorg/mortbay/io/BufferCache;"));
                code.visitConstStmt(CONST_STRING,5,"Internal Server Error");
                code.visitConstStmt(CONST_16,6, Integer.valueOf(500)); // int: 0x000001f4  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5,6},new Method("Lorg/mortbay/io/BufferCache;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitFieldStmt(SPUT_OBJECT,4,-1,new Field("Lorg/mortbay/jetty/HttpStatus;","Internal_Server_Error_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L42);
                code.visitFieldStmt(SGET_OBJECT,4,-1,new Field("Lorg/mortbay/jetty/HttpStatus;","CACHE","Lorg/mortbay/io/BufferCache;"));
                code.visitConstStmt(CONST_STRING,5,"Not Implemented");
                code.visitConstStmt(CONST_16,6, Integer.valueOf(501)); // int: 0x000001f5  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5,6},new Method("Lorg/mortbay/io/BufferCache;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitFieldStmt(SPUT_OBJECT,4,-1,new Field("Lorg/mortbay/jetty/HttpStatus;","Not_Implemented_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L43);
                code.visitFieldStmt(SGET_OBJECT,4,-1,new Field("Lorg/mortbay/jetty/HttpStatus;","CACHE","Lorg/mortbay/io/BufferCache;"));
                code.visitConstStmt(CONST_STRING,5,"Bad Gateway");
                code.visitConstStmt(CONST_16,6, Integer.valueOf(502)); // int: 0x000001f6  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5,6},new Method("Lorg/mortbay/io/BufferCache;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitFieldStmt(SPUT_OBJECT,4,-1,new Field("Lorg/mortbay/jetty/HttpStatus;","Bad_Gateway_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L44);
                code.visitFieldStmt(SGET_OBJECT,4,-1,new Field("Lorg/mortbay/jetty/HttpStatus;","CACHE","Lorg/mortbay/io/BufferCache;"));
                code.visitConstStmt(CONST_STRING,5,"Service Unavailable");
                code.visitConstStmt(CONST_16,6, Integer.valueOf(503)); // int: 0x000001f7  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5,6},new Method("Lorg/mortbay/io/BufferCache;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitFieldStmt(SPUT_OBJECT,4,-1,new Field("Lorg/mortbay/jetty/HttpStatus;","Service_Unavailable_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L45);
                code.visitFieldStmt(SGET_OBJECT,4,-1,new Field("Lorg/mortbay/jetty/HttpStatus;","CACHE","Lorg/mortbay/io/BufferCache;"));
                code.visitConstStmt(CONST_STRING,5,"Gateway Timeout");
                code.visitConstStmt(CONST_16,6, Integer.valueOf(504)); // int: 0x000001f8  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5,6},new Method("Lorg/mortbay/io/BufferCache;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitFieldStmt(SPUT_OBJECT,4,-1,new Field("Lorg/mortbay/jetty/HttpStatus;","Gateway_Timeout_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L46);
                code.visitFieldStmt(SGET_OBJECT,4,-1,new Field("Lorg/mortbay/jetty/HttpStatus;","CACHE","Lorg/mortbay/io/BufferCache;"));
                code.visitConstStmt(CONST_STRING,5,"HTTP Version Not Supported");
                code.visitConstStmt(CONST_16,6, Integer.valueOf(505)); // int: 0x000001f9  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5,6},new Method("Lorg/mortbay/io/BufferCache;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitFieldStmt(SPUT_OBJECT,4,-1,new Field("Lorg/mortbay/jetty/HttpStatus;","HTTP_Version_Not_Supported_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L47);
                code.visitFieldStmt(SGET_OBJECT,4,-1,new Field("Lorg/mortbay/jetty/HttpStatus;","CACHE","Lorg/mortbay/io/BufferCache;"));
                code.visitConstStmt(CONST_STRING,5,"Insufficient Storage");
                code.visitConstStmt(CONST_16,6, Integer.valueOf(507)); // int: 0x000001fb  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5,6},new Method("Lorg/mortbay/io/BufferCache;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitFieldStmt(SPUT_OBJECT,4,-1,new Field("Lorg/mortbay/jetty/HttpStatus;","Insufficient_Storage_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L48);
                code.visitFieldStmt(SGET_OBJECT,4,-1,new Field("Lorg/mortbay/jetty/HttpStatus;","CACHE","Lorg/mortbay/io/BufferCache;"));
                code.visitConstStmt(CONST_STRING,5,"Unknown");
                code.visitConstStmt(CONST_16,6, Integer.valueOf(999)); // int: 0x000003e7  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5,6},new Method("Lorg/mortbay/io/BufferCache;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitFieldStmt(SPUT_OBJECT,4,-1,new Field("Lorg/mortbay/jetty/HttpStatus;","Unknown_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L49);
                code.visitConstStmt(CONST_16,4, Integer.valueOf(600)); // int: 0x00000258  float:0.000000
                code.visitTypeStmt(NEW_ARRAY,4,4,"[Lorg/mortbay/io/Buffer;");
                code.visitFieldStmt(SPUT_OBJECT,4,-1,new Field("Lorg/mortbay/jetty/HttpStatus;","__responseLine","[Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L50);
                code.visitFieldStmt(SGET_OBJECT,4,-1,new Field("Lorg/mortbay/jetty/HttpVersions;","HTTP_1_1_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 4},new Method("Lorg/mortbay/io/Buffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitLabel(L51);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L52);
                code.visitFieldStmt(SGET_OBJECT,4,-1,new Field("Lorg/mortbay/jetty/HttpStatus;","__responseLine","[Lorg/mortbay/io/Buffer;"));
                code.visitStmt2R(ARRAY_LENGTH,4,4);
                code.visitJumpStmt(IF_GE,1,4,L67);
                code.visitLabel(L53);
                code.visitFieldStmt(SGET_OBJECT,4,-1,new Field("Lorg/mortbay/jetty/HttpStatus;","CACHE","Lorg/mortbay/io/BufferCache;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,1},new Method("Lorg/mortbay/io/BufferCache;","get",new String[]{ "I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L54);
                code.visitJumpStmt(IF_NEZ,2,-1,L56);
                code.visitLabel(L55);
                code.visitStmt2R1N(ADD_INT_LIT8,1,1,1);
                code.visitJumpStmt(GOTO,-1,-1,L52);
                code.visitLabel(L56);
                code.visitStmt2R1N(ADD_INT_LIT8,4,3,5);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2},new Method("Lorg/mortbay/io/Buffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitStmt2R(ADD_INT_2ADDR,4,5);
                code.visitStmt2R1N(ADD_INT_LIT8,4,4,2);
                code.visitTypeStmt(NEW_ARRAY,0,4,"[B");
                code.visitLabel(L57);
                code.visitFieldStmt(SGET_OBJECT,4,-1,new Field("Lorg/mortbay/jetty/HttpVersions;","HTTP_1_1_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 4,7,0,7,3},new Method("Lorg/mortbay/io/Buffer;","peek",new String[]{ "I","[B","I","I"},"I"));
                code.visitLabel(L58);
                code.visitStmt2R1N(ADD_INT_LIT8,4,3,0);
                code.visitStmt3R(APUT_BYTE,8,0,4);
                code.visitLabel(L59);
                code.visitStmt2R1N(ADD_INT_LIT8,4,3,1);
                code.visitStmt2R1N(DIV_INT_LIT8,5,1,100);
                code.visitStmt2R1N(ADD_INT_LIT8,5,5,48);
                code.visitStmt2R(INT_TO_BYTE,5,5);
                code.visitStmt3R(APUT_BYTE,5,0,4);
                code.visitLabel(L60);
                code.visitStmt2R1N(ADD_INT_LIT8,4,3,2);
                code.visitStmt2R1N(REM_INT_LIT8,5,1,100);
                code.visitStmt2R1N(DIV_INT_LIT8,5,5,10);
                code.visitStmt2R1N(ADD_INT_LIT8,5,5,48);
                code.visitStmt2R(INT_TO_BYTE,5,5);
                code.visitStmt3R(APUT_BYTE,5,0,4);
                code.visitLabel(L61);
                code.visitStmt2R1N(ADD_INT_LIT8,4,3,3);
                code.visitStmt2R1N(REM_INT_LIT8,5,1,10);
                code.visitStmt2R1N(ADD_INT_LIT8,5,5,48);
                code.visitStmt2R(INT_TO_BYTE,5,5);
                code.visitStmt3R(APUT_BYTE,5,0,4);
                code.visitLabel(L62);
                code.visitStmt2R1N(ADD_INT_LIT8,4,3,4);
                code.visitStmt3R(APUT_BYTE,8,0,4);
                code.visitLabel(L63);
                code.visitStmt2R1N(ADD_INT_LIT8,4,3,5);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2},new Method("Lorg/mortbay/io/Buffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2,7,0,4,5},new Method("Lorg/mortbay/io/Buffer;","peek",new String[]{ "I","[B","I","I"},"I"));
                code.visitLabel(L64);
                code.visitStmt2R1N(ADD_INT_LIT8,4,3,5);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2},new Method("Lorg/mortbay/io/Buffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitStmt2R(ADD_INT_2ADDR,4,5);
                code.visitConstStmt(CONST_16,5, Integer.valueOf(13)); // int: 0x0000000d  float:0.000000
                code.visitStmt3R(APUT_BYTE,5,0,4);
                code.visitLabel(L65);
                code.visitStmt2R1N(ADD_INT_LIT8,4,3,6);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2},new Method("Lorg/mortbay/io/Buffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitStmt2R(ADD_INT_2ADDR,4,5);
                code.visitConstStmt(CONST_16,5, Integer.valueOf(10)); // int: 0x0000000a  float:0.000000
                code.visitStmt3R(APUT_BYTE,5,0,4);
                code.visitLabel(L66);
                code.visitFieldStmt(SGET_OBJECT,4,-1,new Field("Lorg/mortbay/jetty/HttpStatus;","__responseLine","[Lorg/mortbay/io/Buffer;"));
                code.visitTypeStmt(NEW_INSTANCE,5,-1,"Lorg/mortbay/io/ByteArrayBuffer;");
                code.visitStmt2R(ARRAY_LENGTH,6,0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 5,0,7,6,7},new Method("Lorg/mortbay/io/ByteArrayBuffer;","<init>",new String[]{ "[B","I","I","I"},"V"));
                code.visitStmt3R(APUT_OBJECT,5,4,1);
                code.visitJumpStmt(GOTO,-1,-1,L55);
                code.visitLabel(L67);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/HttpStatus;","<init>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(25,L0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/Object;","<init>",new String[]{ },"V"));
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_getResponseLine(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/jetty/HttpStatus;","getResponseLine",new String[]{ "I"},"Lorg/mortbay/io/Buffer;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"status");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(209,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(210,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(211,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpStatus;","__responseLine","[Lorg/mortbay/io/Buffer;"));
                code.visitStmt2R(ARRAY_LENGTH,0,0);
                DexLabel L3=new DexLabel();
                code.visitJumpStmt(IF_LT,1,0,L3);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L2);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L3);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpStatus;","__responseLine","[Lorg/mortbay/io/Buffer;"));
                code.visitStmt3R(AGET_OBJECT,0,0,1);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
