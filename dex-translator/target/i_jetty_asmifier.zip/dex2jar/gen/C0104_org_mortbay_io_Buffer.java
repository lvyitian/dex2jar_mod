package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0104_org_mortbay_io_Buffer {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC|ACC_INTERFACE|ACC_ABSTRACT,"Lorg/mortbay/io/Buffer;","Ljava/lang/Object;",new String[]{ "Ljava/lang/Cloneable;"});
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("Buffer.java");
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/MemberClasses;", Visibility.SYSTEM);
            if(av00 != null) {
                {
                    DexAnnotationVisitor av01 = av00.visitArray("value");
                    if(av01 != null) {
                        av01.visit(null, new DexType("Lorg/mortbay/io/Buffer$CaseInsensitve;"));
                        av01.visitEnd();
                    }
                }
                av00.visitEnd();
            }
        }
        f000_IMMUTABLE(cv);
        f001_NON_VOLATILE(cv);
        f002_READONLY(cv);
        f003_READWRITE(cv);
        f004_VOLATILE(cv);
        m000_array(cv);
        m001_asArray(cv);
        m002_asImmutableBuffer(cv);
        m003_asMutableBuffer(cv);
        m004_asNonVolatileBuffer(cv);
        m005_asReadOnlyBuffer(cv);
        m006_buffer(cv);
        m007_capacity(cv);
        m008_clear(cv);
        m009_compact(cv);
        m010_equalsIgnoreCase(cv);
        m011_get(cv);
        m012_get(cv);
        m013_get(cv);
        m014_getIndex(cv);
        m015_hasContent(cv);
        m016_isImmutable(cv);
        m017_isReadOnly(cv);
        m018_isVolatile(cv);
        m019_length(cv);
        m020_mark(cv);
        m021_mark(cv);
        m022_markIndex(cv);
        m023_peek(cv);
        m024_peek(cv);
        m025_peek(cv);
        m026_peek(cv);
        m027_poke(cv);
        m028_poke(cv);
        m029_poke(cv);
        m030_put(cv);
        m031_put(cv);
        m032_put(cv);
        m033_put(cv);
        m034_putIndex(cv);
        m035_readFrom(cv);
        m036_reset(cv);
        m037_setGetIndex(cv);
        m038_setMarkIndex(cv);
        m039_setPutIndex(cv);
        m040_skip(cv);
        m041_slice(cv);
        m042_sliceFromMark(cv);
        m043_sliceFromMark(cv);
        m044_space(cv);
        m045_toDetailString(cv);
        m046_writeTo(cv);
    }
    public static void f000_IMMUTABLE(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/io/Buffer;","IMMUTABLE","I"),  Integer.valueOf(0));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001_NON_VOLATILE(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/io/Buffer;","NON_VOLATILE","Z"), Boolean.valueOf(false));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002_READONLY(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/io/Buffer;","READONLY","I"),  Integer.valueOf(1));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003_READWRITE(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/io/Buffer;","READWRITE","I"),  Integer.valueOf(2));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f004_VOLATILE(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/io/Buffer;","VOLATILE","Z"), Boolean.valueOf(true));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000_array(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/io/Buffer;","array",new String[]{ },"[B"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m001_asArray(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/io/Buffer;","asArray",new String[]{ },"[B"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m002_asImmutableBuffer(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/io/Buffer;","asImmutableBuffer",new String[]{ },"Lorg/mortbay/io/Buffer;"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m003_asMutableBuffer(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/io/Buffer;","asMutableBuffer",new String[]{ },"Lorg/mortbay/io/Buffer;"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m004_asNonVolatileBuffer(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/io/Buffer;","asNonVolatileBuffer",new String[]{ },"Lorg/mortbay/io/Buffer;"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m005_asReadOnlyBuffer(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/io/Buffer;","asReadOnlyBuffer",new String[]{ },"Lorg/mortbay/io/Buffer;"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m006_buffer(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/io/Buffer;","buffer",new String[]{ },"Lorg/mortbay/io/Buffer;"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m007_capacity(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/io/Buffer;","capacity",new String[]{ },"I"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m008_clear(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/io/Buffer;","clear",new String[]{ },"V"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m009_compact(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/io/Buffer;","compact",new String[]{ },"V"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m010_equalsIgnoreCase(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/io/Buffer;","equalsIgnoreCase",new String[]{ "Lorg/mortbay/io/Buffer;"},"Z"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m011_get(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/io/Buffer;","get",new String[]{ },"B"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m012_get(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/io/Buffer;","get",new String[]{ "[B","I","I"},"I"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m013_get(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/io/Buffer;","get",new String[]{ "I"},"Lorg/mortbay/io/Buffer;"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m014_getIndex(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/io/Buffer;","getIndex",new String[]{ },"I"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m015_hasContent(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/io/Buffer;","hasContent",new String[]{ },"Z"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m016_isImmutable(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/io/Buffer;","isImmutable",new String[]{ },"Z"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m017_isReadOnly(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/io/Buffer;","isReadOnly",new String[]{ },"Z"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m018_isVolatile(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/io/Buffer;","isVolatile",new String[]{ },"Z"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m019_length(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/io/Buffer;","length",new String[]{ },"I"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m020_mark(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/io/Buffer;","mark",new String[]{ },"V"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m021_mark(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/io/Buffer;","mark",new String[]{ "I"},"V"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m022_markIndex(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/io/Buffer;","markIndex",new String[]{ },"I"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m023_peek(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/io/Buffer;","peek",new String[]{ },"B"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m024_peek(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/io/Buffer;","peek",new String[]{ "I"},"B"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m025_peek(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/io/Buffer;","peek",new String[]{ "I","[B","I","I"},"I"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m026_peek(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/io/Buffer;","peek",new String[]{ "I","I"},"Lorg/mortbay/io/Buffer;"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m027_poke(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/io/Buffer;","poke",new String[]{ "I","Lorg/mortbay/io/Buffer;"},"I"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m028_poke(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/io/Buffer;","poke",new String[]{ "I","[B","I","I"},"I"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m029_poke(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/io/Buffer;","poke",new String[]{ "I","B"},"V"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m030_put(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/io/Buffer;","put",new String[]{ "Lorg/mortbay/io/Buffer;"},"I"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m031_put(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/io/Buffer;","put",new String[]{ "[B"},"I"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m032_put(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/io/Buffer;","put",new String[]{ "[B","I","I"},"I"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m033_put(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/io/Buffer;","put",new String[]{ "B"},"V"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m034_putIndex(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/io/Buffer;","putIndex",new String[]{ },"I"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m035_readFrom(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/io/Buffer;","readFrom",new String[]{ "Ljava/io/InputStream;","I"},"I"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            mv.visitEnd();
        }
    }
    public static void m036_reset(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/io/Buffer;","reset",new String[]{ },"V"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m037_setGetIndex(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/io/Buffer;","setGetIndex",new String[]{ "I"},"V"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m038_setMarkIndex(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/io/Buffer;","setMarkIndex",new String[]{ "I"},"V"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m039_setPutIndex(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/io/Buffer;","setPutIndex",new String[]{ "I"},"V"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m040_skip(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/io/Buffer;","skip",new String[]{ "I"},"I"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m041_slice(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/io/Buffer;","slice",new String[]{ },"Lorg/mortbay/io/Buffer;"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m042_sliceFromMark(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/io/Buffer;","sliceFromMark",new String[]{ },"Lorg/mortbay/io/Buffer;"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m043_sliceFromMark(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/io/Buffer;","sliceFromMark",new String[]{ "I"},"Lorg/mortbay/io/Buffer;"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m044_space(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/io/Buffer;","space",new String[]{ },"I"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m045_toDetailString(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/io/Buffer;","toDetailString",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m046_writeTo(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/io/Buffer;","writeTo",new String[]{ "Ljava/io/OutputStream;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            mv.visitEnd();
        }
    }
}
