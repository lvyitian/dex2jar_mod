package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0449_org_mortbay_util_ajax_JSONDateConvertor {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/util/ajax/JSONDateConvertor;","Ljava/lang/Object;",new String[]{ "Lorg/mortbay/util/ajax/JSON$Convertor;"});
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("JSONDateConvertor.java");
        f000__dateCache(cv);
        f001__format(cv);
        f002__fromJSON(cv);
        m000__init_(cv);
        m001__init_(cv);
        m002__init_(cv);
        m003__init_(cv);
        m004_fromJSON(cv);
        m005_toJSON(cv);
    }
    public static void f000__dateCache(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/util/ajax/JSONDateConvertor;","_dateCache","Lorg/mortbay/util/DateCache;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001__format(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/util/ajax/JSONDateConvertor;","_format","Ljava/text/SimpleDateFormat;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002__fromJSON(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/util/ajax/JSONDateConvertor;","_fromJSON","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/util/ajax/JSONDateConvertor;","<init>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(43,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(44,L1);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,0},new Method("Lorg/mortbay/util/ajax/JSONDateConvertor;","<init>",new String[]{ "Z"},"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/util/ajax/JSONDateConvertor;","<init>",new String[]{ "Ljava/lang/String;","Ljava/util/TimeZone;","Z"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"format");
                ddv.visitParameterName(1,"zone");
                ddv.visitParameterName(2,"fromJSON");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(52,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(53,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(54,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(55,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(56,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(57,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(58,L6);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljava/lang/Object;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/util/DateCache;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,2},new Method("Lorg/mortbay/util/DateCache;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/util/ajax/JSONDateConvertor;","_dateCache","Lorg/mortbay/util/DateCache;"));
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/util/ajax/JSONDateConvertor;","_dateCache","Lorg/mortbay/util/DateCache;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,3},new Method("Lorg/mortbay/util/DateCache;","setTimeZone",new String[]{ "Ljava/util/TimeZone;"},"V"));
                code.visitLabel(L3);
                code.visitFieldStmt(IPUT_BOOLEAN,4,1,new Field("Lorg/mortbay/util/ajax/JSONDateConvertor;","_fromJSON","Z"));
                code.visitLabel(L4);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/text/SimpleDateFormat;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,2},new Method("Ljava/text/SimpleDateFormat;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/util/ajax/JSONDateConvertor;","_format","Ljava/text/SimpleDateFormat;"));
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/util/ajax/JSONDateConvertor;","_format","Ljava/text/SimpleDateFormat;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,3},new Method("Ljava/text/SimpleDateFormat;","setTimeZone",new String[]{ "Ljava/util/TimeZone;"},"V"));
                code.visitLabel(L6);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/util/ajax/JSONDateConvertor;","<init>",new String[]{ "Ljava/lang/String;","Ljava/util/TimeZone;","Z","Ljava/util/Locale;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"format");
                ddv.visitParameterName(1,"zone");
                ddv.visitParameterName(2,"fromJSON");
                ddv.visitParameterName(3,"locale");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(61,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(62,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(63,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(64,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(65,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(66,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(67,L6);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2},new Method("Ljava/lang/Object;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/util/DateCache;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,3,6},new Method("Lorg/mortbay/util/DateCache;","<init>",new String[]{ "Ljava/lang/String;","Ljava/util/Locale;"},"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/util/ajax/JSONDateConvertor;","_dateCache","Lorg/mortbay/util/DateCache;"));
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/util/ajax/JSONDateConvertor;","_dateCache","Lorg/mortbay/util/DateCache;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,4},new Method("Lorg/mortbay/util/DateCache;","setTimeZone",new String[]{ "Ljava/util/TimeZone;"},"V"));
                code.visitLabel(L3);
                code.visitFieldStmt(IPUT_BOOLEAN,5,2,new Field("Lorg/mortbay/util/ajax/JSONDateConvertor;","_fromJSON","Z"));
                code.visitLabel(L4);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/text/SimpleDateFormat;");
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/text/DateFormatSymbols;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,6},new Method("Ljava/text/DateFormatSymbols;","<init>",new String[]{ "Ljava/util/Locale;"},"V"));
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,3,1},new Method("Ljava/text/SimpleDateFormat;","<init>",new String[]{ "Ljava/lang/String;","Ljava/text/DateFormatSymbols;"},"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/util/ajax/JSONDateConvertor;","_format","Ljava/text/SimpleDateFormat;"));
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/util/ajax/JSONDateConvertor;","_format","Ljava/text/SimpleDateFormat;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,4},new Method("Ljava/text/SimpleDateFormat;","setTimeZone",new String[]{ "Ljava/util/TimeZone;"},"V"));
                code.visitLabel(L6);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/util/ajax/JSONDateConvertor;","<init>",new String[]{ "Z"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"fromJSON");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(48,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(49,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/util/DateCache;","DEFAULT_FORMAT","Ljava/lang/String;"));
                code.visitConstStmt(CONST_STRING,1,"GMT");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1},new Method("Ljava/util/TimeZone;","getTimeZone",new String[]{ "Ljava/lang/String;"},"Ljava/util/TimeZone;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2,0,1,3},new Method("Lorg/mortbay/util/ajax/JSONDateConvertor;","<init>",new String[]{ "Ljava/lang/String;","Ljava/util/TimeZone;","Z"},"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_fromJSON(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/ajax/JSONDateConvertor;","fromJSON",new String[]{ "Ljava/util/Map;"},"Ljava/lang/Object;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/lang/Exception;"});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                code.visitTryCatch(L1,L3,new DexLabel[]{L4},new String[]{ null});
                code.visitTryCatch(L3,L2,new DexLabel[]{L2},new String[]{ "Ljava/lang/Exception;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"map");
                DexLabel L5=new DexLabel();
                ddv.visitPrologue(L5);
                ddv.visitLineNumber(71,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(72,L6);
                ddv.visitLineNumber(75,L0);
                ddv.visitLineNumber(77,L1);
                DexLabel L7=new DexLabel();
                ddv.visitEndLocal(4,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(84,L8);
                ddv.visitLineNumber(78,L4);
                ddv.visitLineNumber(80,L2);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(82,L9);
                ddv.visitStartLocal(0,L9,"e","Ljava/lang/Exception;",null);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(84,L10);
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_BOOLEAN,1,4,new Field("Lorg/mortbay/util/ajax/JSONDateConvertor;","_fromJSON","Z"));
                code.visitJumpStmt(IF_NEZ,1,-1,L0);
                code.visitLabel(L6);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/lang/UnsupportedOperationException;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljava/lang/UnsupportedOperationException;","<init>",new String[]{ },"V"));
                code.visitStmt1R(THROW,1);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/util/ajax/JSONDateConvertor;","_format","Ljava/text/SimpleDateFormat;"));
                code.visitStmt1R(MONITOR_ENTER,1);
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,2,4,new Field("Lorg/mortbay/util/ajax/JSONDateConvertor;","_format","Ljava/text/SimpleDateFormat;"));
                code.visitConstStmt(CONST_STRING,3,"value");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 5,3},new Method("Ljava/util/Map;","get",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitLabel(L7);
                code.visitTypeStmt(CHECK_CAST,4,-1,"Ljava/lang/String;");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,4},new Method("Ljava/text/SimpleDateFormat;","parseObject",new String[]{ "Ljava/lang/String;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitStmt1R(MONITOR_EXIT,1);
                code.visitStmt2R(MOVE_OBJECT,1,2);
                code.visitLabel(L8);
                code.visitStmt1R(RETURN_OBJECT,1);
                code.visitLabel(L4);
                code.visitStmt1R(MOVE_EXCEPTION,2);
                code.visitStmt1R(MONITOR_EXIT,1);
                code.visitLabel(L3);
                code.visitStmt1R(THROW,2);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitStmt2R(MOVE_OBJECT,0,1);
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/log/Log;","warn",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitLabel(L10);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L8);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_toJSON(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/ajax/JSONDateConvertor;","toJSON",new String[]{ "Ljava/lang/Object;","Lorg/mortbay/util/ajax/JSON$Output;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"obj");
                ddv.visitParameterName(1,"out");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(89,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(90,L1);
                ddv.visitStartLocal(1,L1,"date","Ljava/lang/String;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(92,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(93,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(99,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(97,L5);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,3,4,new Field("Lorg/mortbay/util/ajax/JSONDateConvertor;","_dateCache","Lorg/mortbay/util/DateCache;"));
                code.visitStmt2R(MOVE_OBJECT,0,5);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Ljava/util/Date;");
                code.visitStmt2R(MOVE_OBJECT,2,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,2},new Method("Lorg/mortbay/util/DateCache;","format",new String[]{ "Ljava/util/Date;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_BOOLEAN,2,4,new Field("Lorg/mortbay/util/ajax/JSONDateConvertor;","_fromJSON","Z"));
                code.visitJumpStmt(IF_EQZ,2,-1,L5);
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/lang/Object;","getClass",new String[]{ },"Ljava/lang/Class;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 6,2},new Method("Lorg/mortbay/util/ajax/JSON$Output;","addClass",new String[]{ "Ljava/lang/Class;"},"V"));
                code.visitLabel(L3);
                code.visitConstStmt(CONST_STRING,2,"value");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 6,2,1},new Method("Lorg/mortbay/util/ajax/JSON$Output;","add",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L4);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 6,1},new Method("Lorg/mortbay/util/ajax/JSON$Output;","add",new String[]{ "Ljava/lang/Object;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
