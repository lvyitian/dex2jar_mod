package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0166_org_mortbay_jetty_HttpHeaderValues {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/jetty/HttpHeaderValues;","Lorg/mortbay/io/BufferCache;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("HttpHeaderValues.java");
        f000_BYTES(cv);
        f001_BYTES_BUFFER(cv);
        f002_BYTES_ORDINAL(cv);
        f003_CACHE(cv);
        f004_CHUNKED(cv);
        f005_CHUNKED_BUFFER(cv);
        f006_CHUNKED_ORDINAL(cv);
        f007_CLOSE(cv);
        f008_CLOSE_BUFFER(cv);
        f009_CLOSE_ORDINAL(cv);
        f010_CONTINUE(cv);
        f011_CONTINUE_BUFFER(cv);
        f012_CONTINUE_ORDINAL(cv);
        f013_GZIP(cv);
        f014_GZIP_BUFFER(cv);
        f015_GZIP_ORDINAL(cv);
        f016_IDENTITY(cv);
        f017_IDENTITY_BUFFER(cv);
        f018_IDENTITY_ORDINAL(cv);
        f019_KEEP_ALIVE(cv);
        f020_KEEP_ALIVE_BUFFER(cv);
        f021_KEEP_ALIVE_ORDINAL(cv);
        f022_NO_CACHE(cv);
        f023_NO_CACHE_BUFFER(cv);
        f024_NO_CACHE_ORDINAL(cv);
        f025_PROCESSING(cv);
        f026_PROCESSING_BUFFER(cv);
        f027_PROCESSING_ORDINAL(cv);
        f028_TE(cv);
        f029_TE_BUFFER(cv);
        f030_TE_ORDINAL(cv);
        m000__clinit_(cv);
        m001__init_(cv);
    }
    public static void f000_BYTES(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaderValues;","BYTES","Ljava/lang/String;"), "bytes");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001_BYTES_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaderValues;","BYTES_BUFFER","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002_BYTES_ORDINAL(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaderValues;","BYTES_ORDINAL","I"),  Integer.valueOf(9));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003_CACHE(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaderValues;","CACHE","Lorg/mortbay/jetty/HttpHeaderValues;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f004_CHUNKED(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaderValues;","CHUNKED","Ljava/lang/String;"), "chunked");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f005_CHUNKED_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaderValues;","CHUNKED_BUFFER","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f006_CHUNKED_ORDINAL(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaderValues;","CHUNKED_ORDINAL","I"),  Integer.valueOf(2));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f007_CLOSE(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaderValues;","CLOSE","Ljava/lang/String;"), "close");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f008_CLOSE_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaderValues;","CLOSE_BUFFER","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f009_CLOSE_ORDINAL(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaderValues;","CLOSE_ORDINAL","I"),  Integer.valueOf(1));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f010_CONTINUE(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaderValues;","CONTINUE","Ljava/lang/String;"), "100-continue");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f011_CONTINUE_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaderValues;","CONTINUE_BUFFER","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f012_CONTINUE_ORDINAL(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaderValues;","CONTINUE_ORDINAL","I"),  Integer.valueOf(6));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f013_GZIP(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaderValues;","GZIP","Ljava/lang/String;"), "gzip");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f014_GZIP_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaderValues;","GZIP_BUFFER","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f015_GZIP_ORDINAL(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaderValues;","GZIP_ORDINAL","I"),  Integer.valueOf(3));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f016_IDENTITY(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaderValues;","IDENTITY","Ljava/lang/String;"), "identity");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f017_IDENTITY_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaderValues;","IDENTITY_BUFFER","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f018_IDENTITY_ORDINAL(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaderValues;","IDENTITY_ORDINAL","I"),  Integer.valueOf(4));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f019_KEEP_ALIVE(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaderValues;","KEEP_ALIVE","Ljava/lang/String;"), "keep-alive");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f020_KEEP_ALIVE_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaderValues;","KEEP_ALIVE_BUFFER","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f021_KEEP_ALIVE_ORDINAL(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaderValues;","KEEP_ALIVE_ORDINAL","I"),  Integer.valueOf(5));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f022_NO_CACHE(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaderValues;","NO_CACHE","Ljava/lang/String;"), "no-cache");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f023_NO_CACHE_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaderValues;","NO_CACHE_BUFFER","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f024_NO_CACHE_ORDINAL(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaderValues;","NO_CACHE_ORDINAL","I"),  Integer.valueOf(10));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f025_PROCESSING(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaderValues;","PROCESSING","Ljava/lang/String;"), "102-processing");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f026_PROCESSING_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaderValues;","PROCESSING_BUFFER","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f027_PROCESSING_ORDINAL(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaderValues;","PROCESSING_ORDINAL","I"),  Integer.valueOf(7));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f028_TE(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaderValues;","TE","Ljava/lang/String;"), "TE");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f029_TE_BUFFER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaderValues;","TE_BUFFER","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f030_TE_ORDINAL(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpHeaderValues;","TE_ORDINAL","I"),  Integer.valueOf(8));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__clinit_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/HttpHeaderValues;","<clinit>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(10);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/lang/Exception;"});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                DexLabel L5=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L5},new String[]{ "Ljava/lang/Exception;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L6=new DexLabel();
                ddv.visitPrologue(L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(60,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(63,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(64,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(65,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(66,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(67,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(68,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(69,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(70,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(71,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(72,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(76,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(77,L19);
                ddv.visitStartLocal(2,L19,"index","I",null);
                DexLabel L20=new DexLabel();
                ddv.visitStartLocal(3,L20,"index","I",null);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(78,L21);
                ddv.visitEndLocal(2,L21);
                DexLabel L22=new DexLabel();
                ddv.visitRestartLocal(2,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(79,L23);
                ddv.visitEndLocal(3,L23);
                DexLabel L24=new DexLabel();
                ddv.visitRestartLocal(3,L24);
                ddv.visitLineNumber(83,L0);
                ddv.visitEndLocal(2,L0);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(84,L25);
                ddv.visitStartLocal(5,L25,"ua","Ljava/io/InputStream;",null);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(86,L26);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(87,L27);
                ddv.visitStartLocal(1,L27,"in","Ljava/io/LineNumberReader;",null);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(88,L28);
                ddv.visitStartLocal(4,L28,"line","Ljava/lang/String;",null);
                DexLabel L29=new DexLabel();
                ddv.visitLineNumber(90,L29);
                ddv.visitRestartLocal(2,L3);
                DexLabel L30=new DexLabel();
                ddv.visitLineNumber(91,L30);
                ddv.visitEndLocal(3,L30);
                DexLabel L31=new DexLabel();
                ddv.visitRestartLocal(3,L31);
                ddv.visitLineNumber(95,L2);
                ddv.visitEndLocal(5,L2);
                ddv.visitEndLocal(1,L2);
                ddv.visitEndLocal(2,L2);
                ddv.visitEndLocal(4,L2);
                DexLabel L32=new DexLabel();
                ddv.visitLineNumber(97,L32);
                ddv.visitEndLocal(3,L32);
                ddv.visitRestartLocal(2,L32);
                ddv.visitStartLocal(0,L32,"e","Ljava/lang/Exception;",null);
                DexLabel L33=new DexLabel();
                ddv.visitLineNumber(98,L33);
                DexLabel L34=new DexLabel();
                ddv.visitLineNumber(100,L34);
                ddv.visitEndLocal(0,L34);
                ddv.visitLineNumber(95,L5);
                ddv.visitRestartLocal(1,L5);
                ddv.visitRestartLocal(4,L5);
                ddv.visitRestartLocal(5,L5);
                DexLabel L35=new DexLabel();
                ddv.visitEndLocal(2,L35);
                ddv.visitEndLocal(1,L35);
                ddv.visitEndLocal(4,L35);
                ddv.visitRestartLocal(3,L35);
                DexLabel L36=new DexLabel();
                ddv.visitRestartLocal(2,L36);
                code.visitLabel(L6);
                code.visitConstStmt(CONST_STRING,9,"gzip");
                code.visitLabel(L7);
                code.visitTypeStmt(NEW_INSTANCE,6,-1,"Lorg/mortbay/jetty/HttpHeaderValues;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 6},new Method("Lorg/mortbay/jetty/HttpHeaderValues;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(SPUT_OBJECT,6,-1,new Field("Lorg/mortbay/jetty/HttpHeaderValues;","CACHE","Lorg/mortbay/jetty/HttpHeaderValues;"));
                code.visitLabel(L8);
                code.visitFieldStmt(SGET_OBJECT,6,-1,new Field("Lorg/mortbay/jetty/HttpHeaderValues;","CACHE","Lorg/mortbay/jetty/HttpHeaderValues;"));
                code.visitConstStmt(CONST_STRING,7,"close");
                code.visitConstStmt(CONST_4,8, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,7,8},new Method("Lorg/mortbay/jetty/HttpHeaderValues;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitFieldStmt(SPUT_OBJECT,6,-1,new Field("Lorg/mortbay/jetty/HttpHeaderValues;","CLOSE_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L9);
                code.visitFieldStmt(SGET_OBJECT,6,-1,new Field("Lorg/mortbay/jetty/HttpHeaderValues;","CACHE","Lorg/mortbay/jetty/HttpHeaderValues;"));
                code.visitConstStmt(CONST_STRING,7,"chunked");
                code.visitConstStmt(CONST_4,8, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,7,8},new Method("Lorg/mortbay/jetty/HttpHeaderValues;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitFieldStmt(SPUT_OBJECT,6,-1,new Field("Lorg/mortbay/jetty/HttpHeaderValues;","CHUNKED_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L10);
                code.visitFieldStmt(SGET_OBJECT,6,-1,new Field("Lorg/mortbay/jetty/HttpHeaderValues;","CACHE","Lorg/mortbay/jetty/HttpHeaderValues;"));
                code.visitConstStmt(CONST_STRING,7,"gzip");
                code.visitConstStmt(CONST_4,7, Integer.valueOf(3)); // int: 0x00000003  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,9,7},new Method("Lorg/mortbay/jetty/HttpHeaderValues;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitFieldStmt(SPUT_OBJECT,6,-1,new Field("Lorg/mortbay/jetty/HttpHeaderValues;","GZIP_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L11);
                code.visitFieldStmt(SGET_OBJECT,6,-1,new Field("Lorg/mortbay/jetty/HttpHeaderValues;","CACHE","Lorg/mortbay/jetty/HttpHeaderValues;"));
                code.visitConstStmt(CONST_STRING,7,"identity");
                code.visitConstStmt(CONST_4,8, Integer.valueOf(4)); // int: 0x00000004  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,7,8},new Method("Lorg/mortbay/jetty/HttpHeaderValues;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitFieldStmt(SPUT_OBJECT,6,-1,new Field("Lorg/mortbay/jetty/HttpHeaderValues;","IDENTITY_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L12);
                code.visitFieldStmt(SGET_OBJECT,6,-1,new Field("Lorg/mortbay/jetty/HttpHeaderValues;","CACHE","Lorg/mortbay/jetty/HttpHeaderValues;"));
                code.visitConstStmt(CONST_STRING,7,"keep-alive");
                code.visitConstStmt(CONST_4,8, Integer.valueOf(5)); // int: 0x00000005  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,7,8},new Method("Lorg/mortbay/jetty/HttpHeaderValues;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitFieldStmt(SPUT_OBJECT,6,-1,new Field("Lorg/mortbay/jetty/HttpHeaderValues;","KEEP_ALIVE_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L13);
                code.visitFieldStmt(SGET_OBJECT,6,-1,new Field("Lorg/mortbay/jetty/HttpHeaderValues;","CACHE","Lorg/mortbay/jetty/HttpHeaderValues;"));
                code.visitConstStmt(CONST_STRING,7,"100-continue");
                code.visitConstStmt(CONST_4,8, Integer.valueOf(6)); // int: 0x00000006  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,7,8},new Method("Lorg/mortbay/jetty/HttpHeaderValues;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitFieldStmt(SPUT_OBJECT,6,-1,new Field("Lorg/mortbay/jetty/HttpHeaderValues;","CONTINUE_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L14);
                code.visitFieldStmt(SGET_OBJECT,6,-1,new Field("Lorg/mortbay/jetty/HttpHeaderValues;","CACHE","Lorg/mortbay/jetty/HttpHeaderValues;"));
                code.visitConstStmt(CONST_STRING,7,"102-processing");
                code.visitConstStmt(CONST_4,8, Integer.valueOf(7)); // int: 0x00000007  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,7,8},new Method("Lorg/mortbay/jetty/HttpHeaderValues;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitFieldStmt(SPUT_OBJECT,6,-1,new Field("Lorg/mortbay/jetty/HttpHeaderValues;","PROCESSING_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L15);
                code.visitFieldStmt(SGET_OBJECT,6,-1,new Field("Lorg/mortbay/jetty/HttpHeaderValues;","CACHE","Lorg/mortbay/jetty/HttpHeaderValues;"));
                code.visitConstStmt(CONST_STRING,7,"TE");
                code.visitConstStmt(CONST_16,8, Integer.valueOf(8)); // int: 0x00000008  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,7,8},new Method("Lorg/mortbay/jetty/HttpHeaderValues;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitFieldStmt(SPUT_OBJECT,6,-1,new Field("Lorg/mortbay/jetty/HttpHeaderValues;","TE_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L16);
                code.visitFieldStmt(SGET_OBJECT,6,-1,new Field("Lorg/mortbay/jetty/HttpHeaderValues;","CACHE","Lorg/mortbay/jetty/HttpHeaderValues;"));
                code.visitConstStmt(CONST_STRING,7,"bytes");
                code.visitConstStmt(CONST_16,8, Integer.valueOf(9)); // int: 0x00000009  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,7,8},new Method("Lorg/mortbay/jetty/HttpHeaderValues;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitFieldStmt(SPUT_OBJECT,6,-1,new Field("Lorg/mortbay/jetty/HttpHeaderValues;","BYTES_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L17);
                code.visitFieldStmt(SGET_OBJECT,6,-1,new Field("Lorg/mortbay/jetty/HttpHeaderValues;","CACHE","Lorg/mortbay/jetty/HttpHeaderValues;"));
                code.visitConstStmt(CONST_STRING,7,"no-cache");
                code.visitConstStmt(CONST_16,8, Integer.valueOf(10)); // int: 0x0000000a  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,7,8},new Method("Lorg/mortbay/jetty/HttpHeaderValues;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitFieldStmt(SPUT_OBJECT,6,-1,new Field("Lorg/mortbay/jetty/HttpHeaderValues;","NO_CACHE_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L18);
                code.visitConstStmt(CONST_16,2, Integer.valueOf(100)); // int: 0x00000064  float:0.000000
                code.visitLabel(L19);
                code.visitFieldStmt(SGET_OBJECT,6,-1,new Field("Lorg/mortbay/jetty/HttpHeaderValues;","CACHE","Lorg/mortbay/jetty/HttpHeaderValues;"));
                code.visitConstStmt(CONST_STRING,7,"gzip");
                code.visitStmt2R1N(ADD_INT_LIT8,3,2,1);
                code.visitLabel(L20);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,9,2},new Method("Lorg/mortbay/jetty/HttpHeaderValues;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitLabel(L21);
                code.visitFieldStmt(SGET_OBJECT,6,-1,new Field("Lorg/mortbay/jetty/HttpHeaderValues;","CACHE","Lorg/mortbay/jetty/HttpHeaderValues;"));
                code.visitConstStmt(CONST_STRING,7,"gzip,deflate");
                code.visitStmt2R1N(ADD_INT_LIT8,2,3,1);
                code.visitLabel(L22);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,7,3},new Method("Lorg/mortbay/jetty/HttpHeaderValues;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitLabel(L23);
                code.visitFieldStmt(SGET_OBJECT,6,-1,new Field("Lorg/mortbay/jetty/HttpHeaderValues;","CACHE","Lorg/mortbay/jetty/HttpHeaderValues;"));
                code.visitConstStmt(CONST_STRING,7,"deflate");
                code.visitStmt2R1N(ADD_INT_LIT8,3,2,1);
                code.visitLabel(L24);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,7,2},new Method("Lorg/mortbay/jetty/HttpHeaderValues;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitLabel(L0);
                code.visitConstStmt(CONST_CLASS,6,new DexType("Lorg/mortbay/jetty/HttpHeaderValues;"));
                code.visitConstStmt(CONST_STRING,7,"/org/mortbay/jetty/useragents");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,7},new Method("Ljava/lang/Class;","getResourceAsStream",new String[]{ "Ljava/lang/String;"},"Ljava/io/InputStream;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitLabel(L25);
                code.visitJumpStmt(IF_EQZ,5,-1,L35);
                code.visitLabel(L26);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/io/LineNumberReader;");
                code.visitTypeStmt(NEW_INSTANCE,6,-1,"Ljava/io/InputStreamReader;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 6,5},new Method("Ljava/io/InputStreamReader;","<init>",new String[]{ "Ljava/io/InputStream;"},"V"));
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,6},new Method("Ljava/io/LineNumberReader;","<init>",new String[]{ "Ljava/io/Reader;"},"V"));
                code.visitLabel(L27);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/io/LineNumberReader;","readLine",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitLabel(L28);
                code.visitJumpStmt(IF_EQZ,4,-1,L35);
                code.visitLabel(L29);
                code.visitFieldStmt(SGET_OBJECT,6,-1,new Field("Lorg/mortbay/jetty/HttpHeaderValues;","CACHE","Lorg/mortbay/jetty/HttpHeaderValues;"));
                code.visitLabel(L1);
                code.visitStmt2R1N(ADD_INT_LIT8,2,3,1);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,4,3},new Method("Lorg/mortbay/jetty/HttpHeaderValues;","add",new String[]{ "Ljava/lang/String;","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitLabel(L30);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/io/LineNumberReader;","readLine",new String[]{ },"Ljava/lang/String;"));
                code.visitLabel(L4);
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitStmt2R(MOVE,3,2);
                code.visitLabel(L31);
                code.visitJumpStmt(GOTO,-1,-1,L28);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,6);
                code.visitStmt2R(MOVE_OBJECT,0,6);
                code.visitStmt2R(MOVE,2,3);
                code.visitLabel(L32);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/Exception;","printStackTrace",new String[]{ },"V"));
                code.visitLabel(L33);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/log/Log;","ignore",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitLabel(L34);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L5);
                code.visitStmt1R(MOVE_EXCEPTION,6);
                code.visitStmt2R(MOVE_OBJECT,0,6);
                code.visitJumpStmt(GOTO,-1,-1,L32);
                code.visitLabel(L35);
                code.visitStmt2R(MOVE,2,3);
                code.visitLabel(L36);
                code.visitJumpStmt(GOTO,-1,-1,L34);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/HttpHeaderValues;","<init>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(34,L0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Lorg/mortbay/io/BufferCache;","<init>",new String[]{ },"V"));
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
