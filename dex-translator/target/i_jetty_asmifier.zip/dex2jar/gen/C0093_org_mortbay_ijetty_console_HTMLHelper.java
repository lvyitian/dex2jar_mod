package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0093_org_mortbay_ijetty_console_HTMLHelper {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/ijetty/console/HTMLHelper;","Ljava/lang/Object;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("HTMLHelper.java");
        f000__navBarItems(cv);
        f001__navBarLabels(cv);
        f002__phrases(cv);
        m000__clinit_(cv);
        m001__init_(cv);
        m002_doFooter(cv);
        m003_doHeader(cv);
        m004_doHeader(cv);
        m005_doMenuBar(cv);
        m006_formatTable(cv);
        m007_getRowStyle(cv);
    }
    public static void f000__navBarItems(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC, new Field("Lorg/mortbay/ijetty/console/HTMLHelper;","_navBarItems","[Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001__navBarLabels(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC, new Field("Lorg/mortbay/ijetty/console/HTMLHelper;","_navBarLabels","[Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002__phrases(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC, new Field("Lorg/mortbay/ijetty/console/HTMLHelper;","_phrases","[Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__clinit_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/ijetty/console/HTMLHelper;","<clinit>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(30,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(31,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(32,L3);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,6, Integer.valueOf(4)); // int: 0x00000004  float:0.000000
                code.visitConstStmt(CONST_4,5, Integer.valueOf(3)); // int: 0x00000003  float:0.000000
                code.visitConstStmt(CONST_4,4, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitConstStmt(CONST_4,3, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(5)); // int: 0x00000005  float:0.000000
                code.visitTypeStmt(NEW_ARRAY,0,0,"[Ljava/lang/String;");
                code.visitConstStmt(CONST_STRING,1,"Contacts");
                code.visitStmt3R(APUT_OBJECT,1,0,2);
                code.visitConstStmt(CONST_STRING,1,"System Settings");
                code.visitStmt3R(APUT_OBJECT,1,0,3);
                code.visitConstStmt(CONST_STRING,1,"Call Logs");
                code.visitStmt3R(APUT_OBJECT,1,0,4);
                code.visitConstStmt(CONST_STRING,1,"Network");
                code.visitStmt3R(APUT_OBJECT,1,0,5);
                code.visitConstStmt(CONST_STRING,1,"Media");
                code.visitStmt3R(APUT_OBJECT,1,0,6);
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/ijetty/console/HTMLHelper;","_navBarLabels","[Ljava/lang/String;"));
                code.visitLabel(L2);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(5)); // int: 0x00000005  float:0.000000
                code.visitTypeStmt(NEW_ARRAY,0,0,"[Ljava/lang/String;");
                code.visitConstStmt(CONST_STRING,1,"/console/contacts/index.html");
                code.visitStmt3R(APUT_OBJECT,1,0,2);
                code.visitConstStmt(CONST_STRING,1,"/console/settings/");
                code.visitStmt3R(APUT_OBJECT,1,0,3);
                code.visitConstStmt(CONST_STRING,1,"/console/calls/");
                code.visitStmt3R(APUT_OBJECT,1,0,4);
                code.visitConstStmt(CONST_STRING,1,"/console/network/");
                code.visitStmt3R(APUT_OBJECT,1,0,5);
                code.visitConstStmt(CONST_STRING,1,"/console/media/");
                code.visitStmt3R(APUT_OBJECT,1,0,6);
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/ijetty/console/HTMLHelper;","_navBarItems","[Ljava/lang/String;"));
                code.visitLabel(L3);
                code.visitConstStmt(CONST_16,0, Integer.valueOf(9)); // int: 0x00000009  float:0.000000
                code.visitTypeStmt(NEW_ARRAY,0,0,"[Ljava/lang/String;");
                code.visitConstStmt(CONST_STRING,1,"Now with 100% more awesome.");
                code.visitStmt3R(APUT_OBJECT,1,0,2);
                code.visitConstStmt(CONST_STRING,1,"Better than cake before dinner!");
                code.visitStmt3R(APUT_OBJECT,1,0,3);
                code.visitConstStmt(CONST_STRING,1,"Chuck Norris approves.");
                code.visitStmt3R(APUT_OBJECT,1,0,4);
                code.visitConstStmt(CONST_STRING,1,"werkin teh intarwebz sinse 1841");
                code.visitStmt3R(APUT_OBJECT,1,0,5);
                code.visitConstStmt(CONST_STRING,1,"It\'s lemon-y fresh!");
                code.visitStmt3R(APUT_OBJECT,1,0,6);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(5)); // int: 0x00000005  float:0.000000
                code.visitConstStmt(CONST_STRING,2,"More amazing than a potato.");
                code.visitStmt3R(APUT_OBJECT,2,0,1);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(6)); // int: 0x00000006  float:0.000000
                code.visitConstStmt(CONST_STRING,2,"All the cool kids are doing it!");
                code.visitStmt3R(APUT_OBJECT,2,0,1);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(7)); // int: 0x00000007  float:0.000000
                code.visitConstStmt(CONST_STRING,2,"Open sauce, eh?");
                code.visitStmt3R(APUT_OBJECT,2,0,1);
                code.visitConstStmt(CONST_16,1, Integer.valueOf(8)); // int: 0x00000008  float:0.000000
                code.visitConstStmt(CONST_STRING,2,"<code>Nothing happens.</code>");
                code.visitStmt3R(APUT_OBJECT,2,0,1);
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/ijetty/console/HTMLHelper;","_phrases","[Ljava/lang/String;"));
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/ijetty/console/HTMLHelper;","<init>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(28,L0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/Object;","<init>",new String[]{ },"V"));
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_doFooter(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/ijetty/console/HTMLHelper;","doFooter",new String[]{ "Ljava/io/PrintWriter;","Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljavax/servlet/ServletException;"));
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(8);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"writer");
                ddv.visitParameterName(1,"request");
                ddv.visitParameterName(2,"response");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(66,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(68,L2);
                ddv.visitStartLocal(0,L2,"generator","Ljava/util/Random;",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(69,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(70,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(71,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(72,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(73,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(74,L8);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_STRING,4,"    </div>");
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/util/Random;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/util/Random;","<init>",new String[]{ },"V"));
                code.visitLabel(L2);
                code.visitConstStmt(CONST_STRING,1,"    </div>");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,4},new Method("Ljava/io/PrintWriter;","println",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L3);
                code.visitConstStmt(CONST_STRING,1,"    <div id=\'footer\'>");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,1},new Method("Ljava/io/PrintWriter;","println",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L4);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,2,"        Served up by Jetty.<br />");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/ijetty/console/HTMLHelper;","_phrases","[Ljava/lang/String;"));
                code.visitFieldStmt(SGET_OBJECT,3,-1,new Field("Lorg/mortbay/ijetty/console/HTMLHelper;","_phrases","[Ljava/lang/String;"));
                code.visitStmt2R(ARRAY_LENGTH,3,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,3},new Method("Ljava/util/Random;","nextInt",new String[]{ "I"},"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitStmt3R(AGET_OBJECT,2,2,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,1},new Method("Ljava/io/PrintWriter;","println",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L5);
                code.visitConstStmt(CONST_STRING,1,"    </div>");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,4},new Method("Ljava/io/PrintWriter;","println",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L6);
                code.visitConstStmt(CONST_STRING,1,"</body>");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,1},new Method("Ljava/io/PrintWriter;","println",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L7);
                code.visitConstStmt(CONST_STRING,1,"</html>");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,1},new Method("Ljava/io/PrintWriter;","println",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L8);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_doHeader(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/ijetty/console/HTMLHelper;","doHeader",new String[]{ "Ljava/io/PrintWriter;","Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljavax/servlet/ServletException;"));
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"writer");
                ddv.visitParameterName(1,"request");
                ddv.visitParameterName(2,"response");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(36,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(37,L1);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitTypeStmt(NEW_ARRAY,0,0,"[Ljava/lang/String;");
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitConstStmt(CONST_STRING,2,"/console/jquery.js");
                code.visitStmt3R(APUT_OBJECT,2,0,1);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitConstStmt(CONST_STRING,2,"/console/jquery.tablesorter.min.js");
                code.visitStmt3R(APUT_OBJECT,2,0,1);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3,4,5,0},new Method("Lorg/mortbay/ijetty/console/HTMLHelper;","doHeader",new String[]{ "Ljava/io/PrintWriter;","Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;","[Ljava/lang/String;"},"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_doHeader(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/ijetty/console/HTMLHelper;","doHeader",new String[]{ "Ljava/io/PrintWriter;","Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;","[Ljava/lang/String;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljavax/servlet/ServletException;"));
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(10);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"writer");
                ddv.visitParameterName(1,"request");
                ddv.visitParameterName(2,"response");
                ddv.visitParameterName(3,"scripts");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(41,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(42,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(43,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(44,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(45,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(46,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(48,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(50,L7);
                DexLabel L8=new DexLabel();
                ddv.visitStartLocal(0,L8,"arr$","[Ljava/lang/String;",null);
                DexLabel L9=new DexLabel();
                ddv.visitStartLocal(2,L9,"len$","I",null);
                DexLabel L10=new DexLabel();
                ddv.visitStartLocal(1,L10,"i$","I",null);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(52,L11);
                ddv.visitStartLocal(3,L11,"script","Ljava/lang/String;",null);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(50,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(57,L13);
                ddv.visitEndLocal(3,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(60,L14);
                ddv.visitEndLocal(0,L14);
                ddv.visitEndLocal(2,L14);
                ddv.visitEndLocal(1,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(61,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(62,L16);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_STRING,4,"<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Strict//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd\">");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,4},new Method("Ljava/io/PrintWriter;","println",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L1);
                code.visitConstStmt(CONST_STRING,4,"<html xmlns=\'http://www.w3.org/1999/xhtml\' xml:lang=\'en\' lang=\'en\'>");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,4},new Method("Ljava/io/PrintWriter;","println",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L2);
                code.visitConstStmt(CONST_STRING,4,"<head>");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,4},new Method("Ljava/io/PrintWriter;","println",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L3);
                code.visitConstStmt(CONST_STRING,4,"    <title>i-jetty Console</title>");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,4},new Method("Ljava/io/PrintWriter;","println",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L4);
                code.visitConstStmt(CONST_STRING,4,"    <link rel=\'stylesheet\' type=\'text/css\' media=\'screen\' href=\'/console/console.css\' />");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,4},new Method("Ljava/io/PrintWriter;","println",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L5);
                code.visitConstStmt(CONST_STRING,4,"    <meta name=\'viewport\' content=\'width=device-width,minimum-scale=1.0,maximum-scale=1.0\'/>");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,4},new Method("Ljava/io/PrintWriter;","println",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L6);
                code.visitJumpStmt(IF_EQZ,9,-1,L14);
                code.visitLabel(L7);
                code.visitStmt2R(MOVE_OBJECT,0,9);
                code.visitLabel(L8);
                code.visitStmt2R(ARRAY_LENGTH,2,0);
                code.visitLabel(L9);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L10);
                code.visitJumpStmt(IF_GE,1,2,L13);
                code.visitStmt3R(AGET_OBJECT,3,0,1);
                code.visitLabel(L11);
                code.visitTypeStmt(NEW_INSTANCE,4,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,5,"    <script src=\"");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitConstStmt(CONST_STRING,5,"\"></script>");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,4},new Method("Ljava/io/PrintWriter;","println",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L12);
                code.visitStmt2R1N(ADD_INT_LIT8,1,1,1);
                code.visitJumpStmt(GOTO,-1,-1,L10);
                code.visitLabel(L13);
                code.visitConstStmt(CONST_STRING,4,"    <script>$(document).ready(function() { $(\'table\').tablesorter(); });</script>");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,4},new Method("Ljava/io/PrintWriter;","println",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L14);
                code.visitConstStmt(CONST_STRING,4,"</head>");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,4},new Method("Ljava/io/PrintWriter;","println",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L15);
                code.visitConstStmt(CONST_STRING,4,"<body>");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,4},new Method("Ljava/io/PrintWriter;","println",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L16);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_doMenuBar(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/ijetty/console/HTMLHelper;","doMenuBar",new String[]{ "Ljava/io/PrintWriter;","Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljavax/servlet/ServletException;"));
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(9);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"writer");
                ddv.visitParameterName(1,"request");
                ddv.visitParameterName(2,"response");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(78,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(79,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(81,L3);
                ddv.visitStartLocal(1,L3,"path","Ljava/lang/String;",null);
                DexLabel L4=new DexLabel();
                ddv.visitStartLocal(0,L4,"i","I",null);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(83,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(85,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(86,L7);
                ddv.visitStartLocal(2,L7,"splitPath","[Ljava/lang/String;",null);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(87,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(91,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(81,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(89,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(93,L12);
                ddv.visitEndLocal(2,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(94,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(95,L14);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_STRING,5,"<a href=\'");
                code.visitLabel(L1);
                code.visitConstStmt(CONST_STRING,3,"    <div id=\'navigation\'><ul>");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,3},new Method("Ljava/io/PrintWriter;","println",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 7},new Method("Ljavax/servlet/http/HttpServletRequest;","getServletPath",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L4);
                code.visitFieldStmt(SGET_OBJECT,3,-1,new Field("Lorg/mortbay/ijetty/console/HTMLHelper;","_navBarItems","[Ljava/lang/String;"));
                code.visitStmt2R(ARRAY_LENGTH,3,3);
                code.visitJumpStmt(IF_GE,0,3,L12);
                code.visitLabel(L5);
                code.visitConstStmt(CONST_STRING,3,"        <li>");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,3},new Method("Ljava/io/PrintWriter;","print",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L6);
                code.visitFieldStmt(SGET_OBJECT,3,-1,new Field("Lorg/mortbay/ijetty/console/HTMLHelper;","_navBarItems","[Ljava/lang/String;"));
                code.visitStmt3R(AGET_OBJECT,3,3,0);
                code.visitConstStmt(CONST_STRING,4,"/");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/String;","split",new String[]{ "Ljava/lang/String;"},"[Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L7);
                code.visitStmt2R(ARRAY_LENGTH,3,2);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt2R(SUB_INT_2ADDR,3,4);
                code.visitStmt3R(AGET_OBJECT,3,2,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,3},new Method("Ljava/lang/String;","endsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_EQZ,3,-1,L11);
                code.visitLabel(L8);
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,4,"<a href=\'");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitFieldStmt(SGET_OBJECT,4,-1,new Field("Lorg/mortbay/ijetty/console/HTMLHelper;","_navBarItems","[Ljava/lang/String;"));
                code.visitStmt3R(AGET_OBJECT,4,4,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitConstStmt(CONST_STRING,4,"\'><strong>");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitFieldStmt(SGET_OBJECT,4,-1,new Field("Lorg/mortbay/ijetty/console/HTMLHelper;","_navBarLabels","[Ljava/lang/String;"));
                code.visitStmt3R(AGET_OBJECT,4,4,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitConstStmt(CONST_STRING,4,"</strong></a>");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,3},new Method("Ljava/io/PrintWriter;","print",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L9);
                code.visitConstStmt(CONST_STRING,3,"</li>");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,3},new Method("Ljava/io/PrintWriter;","println",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L10);
                code.visitStmt2R1N(ADD_INT_LIT8,0,0,1);
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitLabel(L11);
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,4,"<a href=\'");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitFieldStmt(SGET_OBJECT,4,-1,new Field("Lorg/mortbay/ijetty/console/HTMLHelper;","_navBarItems","[Ljava/lang/String;"));
                code.visitStmt3R(AGET_OBJECT,4,4,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitConstStmt(CONST_STRING,4,"\'>");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitFieldStmt(SGET_OBJECT,4,-1,new Field("Lorg/mortbay/ijetty/console/HTMLHelper;","_navBarLabels","[Ljava/lang/String;"));
                code.visitStmt3R(AGET_OBJECT,4,4,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitConstStmt(CONST_STRING,4,"</a>");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,3},new Method("Ljava/io/PrintWriter;","print",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L9);
                code.visitLabel(L12);
                code.visitConstStmt(CONST_STRING,3,"    </ul></div>");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,3},new Method("Ljava/io/PrintWriter;","println",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L13);
                code.visitConstStmt(CONST_STRING,3,"    <div id=\'page\'>");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,3},new Method("Ljava/io/PrintWriter;","println",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L14);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_formatTable(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/ijetty/console/HTMLHelper;","formatTable",new String[]{ "[Ljava/lang/String;","Landroid/database/Cursor;","Ljava/io/PrintWriter;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(11);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"colNames");
                ddv.visitParameterName(1,"cursor");
                ddv.visitParameterName(2,"writer");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(100,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(102,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(103,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(104,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(105,L5);
                DexLabel L6=new DexLabel();
                ddv.visitStartLocal(1,L6,"i","I",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(106,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(105,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(107,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(108,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(109,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(110,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(111,L13);
                ddv.visitStartLocal(2,L13,"row","I",null);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(113,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(114,L15);
                ddv.visitStartLocal(0,L15,"classExtra","Ljava/lang/String;",null);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(115,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(117,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(118,L18);
                ddv.visitStartLocal(3,L18,"val","Ljava/lang/String;",null);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(115,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(118,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(120,L21);
                ddv.visitEndLocal(3,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(121,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(122,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(123,L24);
                ddv.visitEndLocal(0,L24);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(124,L25);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(127,L26);
                ddv.visitEndLocal(1,L26);
                ddv.visitEndLocal(2,L26);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_STRING,7,"<tr>");
                code.visitConstStmt(CONST_STRING,6,"</tr>");
                code.visitLabel(L1);
                code.visitJumpStmt(IF_EQZ,8,-1,L26);
                code.visitJumpStmt(IF_EQZ,9,-1,L26);
                code.visitJumpStmt(IF_EQZ,10,-1,L26);
                code.visitLabel(L2);
                code.visitConstStmt(CONST_STRING,4,"<table>");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10,4},new Method("Ljava/io/PrintWriter;","println",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L3);
                code.visitConstStmt(CONST_STRING,4,"<thead>");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10,4},new Method("Ljava/io/PrintWriter;","println",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L4);
                code.visitConstStmt(CONST_STRING,4,"<tr>");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10,7},new Method("Ljava/io/PrintWriter;","println",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L5);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L6);
                code.visitStmt2R(ARRAY_LENGTH,4,8);
                code.visitJumpStmt(IF_GE,1,4,L9);
                code.visitLabel(L7);
                code.visitTypeStmt(NEW_INSTANCE,4,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,5,"    <th>");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitStmt3R(AGET_OBJECT,5,8,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitConstStmt(CONST_STRING,5,"</th>");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10,4},new Method("Ljava/io/PrintWriter;","println",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L8);
                code.visitStmt2R1N(ADD_INT_LIT8,1,1,1);
                code.visitJumpStmt(GOTO,-1,-1,L6);
                code.visitLabel(L9);
                code.visitConstStmt(CONST_STRING,4,"</tr>");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10,6},new Method("Ljava/io/PrintWriter;","println",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L10);
                code.visitConstStmt(CONST_STRING,4,"</thead>");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10,4},new Method("Ljava/io/PrintWriter;","println",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L11);
                code.visitConstStmt(CONST_STRING,4,"<tbody>");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10,4},new Method("Ljava/io/PrintWriter;","println",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L12);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L13);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 9},new Method("Landroid/database/Cursor;","moveToNext",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitJumpStmt(IF_EQZ,4,-1,L24);
                code.visitLabel(L14);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2},new Method("Lorg/mortbay/ijetty/console/HTMLHelper;","getRowStyle",new String[]{ "I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L15);
                code.visitConstStmt(CONST_STRING,4,"<tr>");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10,7},new Method("Ljava/io/PrintWriter;","println",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L16);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                DexLabel L27=new DexLabel();
                code.visitLabel(L27);
                code.visitStmt2R(ARRAY_LENGTH,4,8);
                code.visitJumpStmt(IF_GE,1,4,L21);
                code.visitLabel(L17);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 9,1},new Method("Landroid/database/Cursor;","getString",new String[]{ "I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitLabel(L18);
                code.visitTypeStmt(NEW_INSTANCE,4,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,5,"<td");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,0},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitConstStmt(CONST_STRING,5,">");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                DexLabel L28=new DexLabel();
                code.visitJumpStmt(IF_NEZ,3,-1,L28);
                code.visitConstStmt(CONST_STRING,5,"&nbsp;");
                DexLabel L29=new DexLabel();
                code.visitLabel(L29);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitConstStmt(CONST_STRING,5,"</td>");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10,4},new Method("Ljava/io/PrintWriter;","println",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L19);
                code.visitStmt2R1N(ADD_INT_LIT8,1,1,1);
                code.visitJumpStmt(GOTO,-1,-1,L27);
                code.visitLabel(L28);
                code.visitStmt2R(MOVE_OBJECT,5,3);
                code.visitLabel(L20);
                code.visitJumpStmt(GOTO,-1,-1,L29);
                code.visitLabel(L21);
                code.visitConstStmt(CONST_STRING,4,"</tr>");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10,6},new Method("Ljava/io/PrintWriter;","println",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L22);
                code.visitStmt2R1N(ADD_INT_LIT8,2,2,1);
                code.visitLabel(L23);
                code.visitJumpStmt(GOTO,-1,-1,L13);
                code.visitLabel(L24);
                code.visitConstStmt(CONST_STRING,4,"</tbody>");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10,4},new Method("Ljava/io/PrintWriter;","println",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L25);
                code.visitConstStmt(CONST_STRING,4,"</table>");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10,4},new Method("Ljava/io/PrintWriter;","println",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L26);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m007_getRowStyle(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/ijetty/console/HTMLHelper;","getRowStyle",new String[]{ "I"},"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"row");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(131,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(132,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(134,L2);
                code.visitLabel(L0);
                code.visitStmt2R1N(REM_INT_LIT8,0,1,2);
                DexLabel L3=new DexLabel();
                code.visitJumpStmt(IF_NEZ,0,-1,L3);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_STRING,0,"");
                code.visitLabel(L2);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_STRING,0," class=\'odd\'");
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
