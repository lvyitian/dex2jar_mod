package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0259_org_mortbay_jetty_nio_AbstractNIOConnector {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC|ACC_ABSTRACT,"Lorg/mortbay/jetty/nio/AbstractNIOConnector;","Lorg/mortbay/jetty/AbstractConnector;",new String[]{ "Lorg/mortbay/jetty/nio/NIOConnector;"});
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("AbstractNIOConnector.java");
        f000__useDirectBuffers(cv);
        m000__init_(cv);
        m001_getUseDirectBuffers(cv);
        m002_newBuffer(cv);
        m003_setUseDirectBuffers(cv);
    }
    public static void f000__useDirectBuffers(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/nio/AbstractNIOConnector;","_useDirectBuffers","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/nio/AbstractNIOConnector;","<init>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(31,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(33,L1);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Lorg/mortbay/jetty/AbstractConnector;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitFieldStmt(IPUT_BOOLEAN,0,1,new Field("Lorg/mortbay/jetty/nio/AbstractNIOConnector;","_useDirectBuffers","Z"));
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001_getUseDirectBuffers(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/nio/AbstractNIOConnector;","getUseDirectBuffers",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(38,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_BOOLEAN,0,1,new Field("Lorg/mortbay/jetty/nio/AbstractNIOConnector;","_useDirectBuffers","Z"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_newBuffer(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/nio/AbstractNIOConnector;","newBuffer",new String[]{ "I"},"Lorg/mortbay/io/Buffer;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"size");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(67,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(68,L1);
                ddv.visitStartLocal(0,L1,"buf","Lorg/mortbay/io/Buffer;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(69,L2);
                DexLabel L3=new DexLabel();
                ddv.visitEndLocal(0,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(74,L4);
                ddv.visitRestartLocal(0,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(71,L5);
                DexLabel L6=new DexLabel();
                ddv.visitRestartLocal(0,L6);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/nio/AbstractNIOConnector;","getHeaderBufferSize",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_NE,3,1,L5);
                code.visitLabel(L2);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/io/nio/IndirectNIOBuffer;");
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,3},new Method("Lorg/mortbay/io/nio/IndirectNIOBuffer;","<init>",new String[]{ "I"},"V"));
                code.visitLabel(L4);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_BOOLEAN,1,2,new Field("Lorg/mortbay/jetty/nio/AbstractNIOConnector;","_useDirectBuffers","Z"));
                DexLabel L7=new DexLabel();
                code.visitJumpStmt(IF_EQZ,1,-1,L7);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Lorg/mortbay/io/nio/DirectNIOBuffer;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,3},new Method("Lorg/mortbay/io/nio/DirectNIOBuffer;","<init>",new String[]{ "I"},"V"));
                code.visitStmt2R(MOVE_OBJECT,0,1);
                code.visitLabel(L6);
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitLabel(L7);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Lorg/mortbay/io/nio/IndirectNIOBuffer;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,3},new Method("Lorg/mortbay/io/nio/IndirectNIOBuffer;","<init>",new String[]{ "I"},"V"));
                code.visitStmt2R(MOVE_OBJECT,0,1);
                code.visitJumpStmt(GOTO,-1,-1,L6);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_setUseDirectBuffers(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/nio/AbstractNIOConnector;","setUseDirectBuffers",new String[]{ "Z"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"direct");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(48,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(49,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_BOOLEAN,1,0,new Field("Lorg/mortbay/jetty/nio/AbstractNIOConnector;","_useDirectBuffers","Z"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
