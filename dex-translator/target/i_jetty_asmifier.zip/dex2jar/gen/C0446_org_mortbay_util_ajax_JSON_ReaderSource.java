package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0446_org_mortbay_util_ajax_JSON_ReaderSource {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/util/ajax/JSON$ReaderSource;","Ljava/lang/Object;",new String[]{ "Lorg/mortbay/util/ajax/JSON$Source;"});
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("JSON.java");
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/EnclosingClass;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("value", new DexType("Lorg/mortbay/util/ajax/JSON;"));
                av00.visitEnd();
            }
        }
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/InnerClass;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("accessFlags",  Integer.valueOf(9));
                av00.visit("name", "ReaderSource");
                av00.visitEnd();
            }
        }
        f000__next(cv);
        f001__reader(cv);
        f002_scratch(cv);
        m000__init_(cv);
        m001_getNext(cv);
        m002_hasNext(cv);
        m003_next(cv);
        m004_peek(cv);
        m005_scratchBuffer(cv);
        m006_setReader(cv);
    }
    public static void f000__next(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/util/ajax/JSON$ReaderSource;","_next","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001__reader(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/util/ajax/JSON$ReaderSource;","_reader","Ljava/io/Reader;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002_scratch(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/util/ajax/JSON$ReaderSource;","scratch","[C"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/util/ajax/JSON$ReaderSource;","<init>",new String[]{ "Ljava/io/Reader;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"r");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1225,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(1221,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(1226,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(1227,L3);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljava/lang/Object;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(-1)); // int: 0xffffffff  float:NaN
                code.visitFieldStmt(IPUT,0,1,new Field("Lorg/mortbay/util/ajax/JSON$ReaderSource;","_next","I"));
                code.visitLabel(L2);
                code.visitFieldStmt(IPUT_OBJECT,2,1,new Field("Lorg/mortbay/util/ajax/JSON$ReaderSource;","_reader","Ljava/io/Reader;"));
                code.visitLabel(L3);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001_getNext(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PRIVATE, new Method("Lorg/mortbay/util/ajax/JSON$ReaderSource;","getNext",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/io/IOException;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(1262,L3);
                ddv.visitLineNumber(1266,L0);
                ddv.visitLineNumber(1273,L1);
                ddv.visitLineNumber(1268,L2);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(1270,L4);
                ddv.visitStartLocal(0,L4,"e","Ljava/io/IOException;",null);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET,1,2,new Field("Lorg/mortbay/util/ajax/JSON$ReaderSource;","_next","I"));
                code.visitJumpStmt(IF_GEZ,1,-1,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/util/ajax/JSON$ReaderSource;","_reader","Ljava/io/Reader;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/io/Reader;","read",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitFieldStmt(IPUT,1,2,new Field("Lorg/mortbay/util/ajax/JSON$ReaderSource;","_next","I"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitStmt2R(MOVE_OBJECT,0,1);
                code.visitLabel(L4);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/lang/RuntimeException;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,0},new Method("Ljava/lang/RuntimeException;","<init>",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitStmt1R(THROW,1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_hasNext(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/ajax/JSON$ReaderSource;","hasNext",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1237,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(1238,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(1240,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(1241,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(1243,L4);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Lorg/mortbay/util/ajax/JSON$ReaderSource;","getNext",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitFieldStmt(IGET,0,1,new Field("Lorg/mortbay/util/ajax/JSON$ReaderSource;","_next","I"));
                DexLabel L5=new DexLabel();
                code.visitJumpStmt(IF_GEZ,0,-1,L5);
                code.visitLabel(L2);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/util/ajax/JSON$ReaderSource;","scratch","[C"));
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L4);
                code.visitStmt1R(RETURN,0);
                code.visitLabel(L5);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_next(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/ajax/JSON$ReaderSource;","next",new String[]{ },"C"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1248,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(1249,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(1250,L2);
                ddv.visitStartLocal(0,L2,"c","C",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(1251,L3);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2},new Method("Lorg/mortbay/util/ajax/JSON$ReaderSource;","getNext",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitFieldStmt(IGET,1,2,new Field("Lorg/mortbay/util/ajax/JSON$ReaderSource;","_next","I"));
                code.visitStmt2R(INT_TO_CHAR,0,1);
                code.visitLabel(L2);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(-1)); // int: 0xffffffff  float:NaN
                code.visitFieldStmt(IPUT,1,2,new Field("Lorg/mortbay/util/ajax/JSON$ReaderSource;","_next","I"));
                code.visitLabel(L3);
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_peek(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/ajax/JSON$ReaderSource;","peek",new String[]{ },"C"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1256,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(1257,L1);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Lorg/mortbay/util/ajax/JSON$ReaderSource;","getNext",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitFieldStmt(IGET,0,1,new Field("Lorg/mortbay/util/ajax/JSON$ReaderSource;","_next","I"));
                code.visitStmt2R(INT_TO_CHAR,0,0);
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_scratchBuffer(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/ajax/JSON$ReaderSource;","scratchBuffer",new String[]{ },"[C"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1277,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(1278,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(1279,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/util/ajax/JSON$ReaderSource;","scratch","[C"));
                code.visitJumpStmt(IF_NEZ,0,-1,L2);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_16,0, Integer.valueOf(1024)); // int: 0x00000400  float:0.000000
                code.visitTypeStmt(NEW_ARRAY,0,0,"[C");
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/util/ajax/JSON$ReaderSource;","scratch","[C"));
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/util/ajax/JSON$ReaderSource;","scratch","[C"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_setReader(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/ajax/JSON$ReaderSource;","setReader",new String[]{ "Ljava/io/Reader;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"reader");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1231,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(1232,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(1233,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,2,1,new Field("Lorg/mortbay/util/ajax/JSON$ReaderSource;","_reader","Ljava/io/Reader;"));
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(-1)); // int: 0xffffffff  float:NaN
                code.visitFieldStmt(IPUT,0,1,new Field("Lorg/mortbay/util/ajax/JSON$ReaderSource;","_next","I"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
