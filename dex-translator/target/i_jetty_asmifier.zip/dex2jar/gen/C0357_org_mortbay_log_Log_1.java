package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0357_org_mortbay_log_Log_1 {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(0,"Lorg/mortbay/log/Log$1;","Ljava/lang/Object;",new String[]{ "Ljava/security/PrivilegedAction;"});
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("Log.java");
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/EnclosingClass;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("value", new DexType("Lorg/mortbay/log/Log;"));
                av00.visitEnd();
            }
        }
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/InnerClass;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("accessFlags",  Integer.valueOf(8));
                av00.visit("name", null);
                av00.visitEnd();
            }
        }
        m000__init_(cv);
        m001_run(cv);
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_CONSTRUCTOR, new Method("Lorg/mortbay/log/Log$1;","<init>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(55,L0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/Object;","<init>",new String[]{ },"V"));
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001_run(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/log/Log$1;","run",new String[]{ },"Ljava/lang/Object;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(57,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(58,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(59,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(60,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(58,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(59,L6);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitConstStmt(CONST_4,2, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L1);
                code.visitConstStmt(CONST_STRING,0,"org.mortbay.log.class");
                code.visitConstStmt(CONST_STRING,1,"org.mortbay.log.Slf4jLog");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,1},new Method("Ljava/lang/System;","getProperty",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/log/Log;","__logClass","Ljava/lang/String;"));
                code.visitLabel(L2);
                code.visitConstStmt(CONST_STRING,0,"VERBOSE");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,4},new Method("Ljava/lang/System;","getProperty",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                DexLabel L7=new DexLabel();
                code.visitJumpStmt(IF_EQZ,0,-1,L7);
                code.visitStmt2R(MOVE,0,2);
                DexLabel L8=new DexLabel();
                code.visitLabel(L8);
                code.visitFieldStmt(SPUT_BOOLEAN,0,-1,new Field("Lorg/mortbay/log/Log;","__verbose","Z"));
                code.visitLabel(L3);
                code.visitConstStmt(CONST_STRING,0,"IGNORED");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,4},new Method("Ljava/lang/System;","getProperty",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                DexLabel L9=new DexLabel();
                code.visitJumpStmt(IF_EQZ,0,-1,L9);
                code.visitStmt2R(MOVE,0,2);
                DexLabel L10=new DexLabel();
                code.visitLabel(L10);
                code.visitFieldStmt(SPUT_BOOLEAN,0,-1,new Field("Lorg/mortbay/log/Log;","__ignored","Z"));
                code.visitLabel(L4);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/Boolean;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,2},new Method("Ljava/lang/Boolean;","<init>",new String[]{ "Z"},"V"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L7);
                code.visitStmt2R(MOVE,0,3);
                code.visitLabel(L5);
                code.visitJumpStmt(GOTO,-1,-1,L8);
                code.visitLabel(L9);
                code.visitStmt2R(MOVE,0,3);
                code.visitLabel(L6);
                code.visitJumpStmt(GOTO,-1,-1,L10);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
