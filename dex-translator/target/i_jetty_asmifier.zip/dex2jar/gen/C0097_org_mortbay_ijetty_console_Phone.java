package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0097_org_mortbay_ijetty_console_Phone {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/ijetty/console/Phone;","Ljava/lang/Object;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("Phone.java");
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/MemberClasses;", Visibility.SYSTEM);
            if(av00 != null) {
                {
                    DexAnnotationVisitor av01 = av00.visitArray("value");
                    if(av01 != null) {
                        av01.visit(null, new DexType("Lorg/mortbay/ijetty/console/Phone$PhoneCollection;"));
                        av01.visitEnd();
                    }
                }
                av00.visitEnd();
            }
        }
        f000_phonesProjection(cv);
        m000__clinit_(cv);
        m001__init_(cv);
        m002_access$000(cv);
        m003_addPhone(cv);
        m004_cursorToPhoneValues(cv);
        m005_deletePhone(cv);
        m006_getPhones(cv);
        m007_savePhone(cv);
    }
    public static void f000_phonesProjection(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/ijetty/console/Phone;","phonesProjection","[Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__clinit_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/ijetty/console/Phone;","<clinit>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(30,L0);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(5)); // int: 0x00000005  float:0.000000
                code.visitTypeStmt(NEW_ARRAY,0,0,"[Ljava/lang/String;");
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitConstStmt(CONST_STRING,2,"_id");
                code.visitStmt3R(APUT_OBJECT,2,0,1);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitConstStmt(CONST_STRING,2,"label");
                code.visitStmt3R(APUT_OBJECT,2,0,1);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitConstStmt(CONST_STRING,2,"number");
                code.visitStmt3R(APUT_OBJECT,2,0,1);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(3)); // int: 0x00000003  float:0.000000
                code.visitConstStmt(CONST_STRING,2,"number_key");
                code.visitStmt3R(APUT_OBJECT,2,0,1);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(4)); // int: 0x00000004  float:0.000000
                code.visitConstStmt(CONST_STRING,2,"type");
                code.visitStmt3R(APUT_OBJECT,2,0,1);
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/ijetty/console/Phone;","phonesProjection","[Ljava/lang/String;"));
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/ijetty/console/Phone;","<init>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(27,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(40,L1);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/Object;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_access$000(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_SYNTHETIC, new Method("Lorg/mortbay/ijetty/console/Phone;","access$000",new String[]{ "Landroid/database/Cursor;"},"Landroid/content/ContentValues;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"x0");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(27,L0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1},new Method("Lorg/mortbay/ijetty/console/Phone;","cursorToPhoneValues",new String[]{ "Landroid/database/Cursor;"},"Landroid/content/ContentValues;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_addPhone(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/ijetty/console/Phone;","addPhone",new String[]{ "Landroid/content/ContentResolver;","Landroid/content/ContentValues;","Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"resolver");
                ddv.visitParameterName(1,"phone");
                ddv.visitParameterName(2,"userId");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(77,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(78,L1);
                ddv.visitStartLocal(0,L1,"peopleUri","Landroid/net/Uri;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(79,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(SGET_OBJECT,1,-1,new Field("Landroid/provider/Contacts$People;","CONTENT_URI","Landroid/net/Uri;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1,4},new Method("Landroid/net/Uri;","withAppendedPath",new String[]{ "Landroid/net/Uri;","Ljava/lang/String;"},"Landroid/net/Uri;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_STRING,1,"phones");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,1},new Method("Landroid/net/Uri;","withAppendedPath",new String[]{ "Landroid/net/Uri;","Ljava/lang/String;"},"Landroid/net/Uri;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,1,3},new Method("Landroid/content/ContentResolver;","insert",new String[]{ "Landroid/net/Uri;","Landroid/content/ContentValues;"},"Landroid/net/Uri;"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_cursorToPhoneValues(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PRIVATE|ACC_STATIC, new Method("Lorg/mortbay/ijetty/console/Phone;","cursorToPhoneValues",new String[]{ "Landroid/database/Cursor;"},"Landroid/content/ContentValues;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(9);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"cursor");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(96,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(97,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(113,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(99,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(101,L5);
                ddv.visitStartLocal(2,L5,"values","Landroid/content/ContentValues;",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(102,L6);
                ddv.visitStartLocal(1,L6,"val","Ljava/lang/String;",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(104,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(105,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(107,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(108,L10);
                ddv.visitRestartLocal(1,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(110,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(111,L12);
                ddv.visitStartLocal(0,L12,"intVal","Ljava/lang/Integer;",null);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(113,L13);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_STRING,7,"type");
                code.visitConstStmt(CONST_STRING,6,"number");
                code.visitConstStmt(CONST_STRING,5,"label");
                code.visitConstStmt(CONST_STRING,4,"_id");
                code.visitLabel(L1);
                code.visitJumpStmt(IF_NEZ,8,-1,L4);
                code.visitLabel(L2);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L3);
                code.visitStmt1R(RETURN_OBJECT,3);
                code.visitLabel(L4);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Landroid/content/ContentValues;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2},new Method("Landroid/content/ContentValues;","<init>",new String[]{ },"V"));
                code.visitLabel(L5);
                code.visitConstStmt(CONST_STRING,3,"_id");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 8,4},new Method("Landroid/database/Cursor;","getColumnIndex",new String[]{ "Ljava/lang/String;"},"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 8,3},new Method("Landroid/database/Cursor;","getString",new String[]{ "I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L6);
                code.visitConstStmt(CONST_STRING,3,"_id");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,4,1},new Method("Landroid/content/ContentValues;","put",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"V"));
                code.visitLabel(L7);
                code.visitConstStmt(CONST_STRING,3,"label");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 8,5},new Method("Landroid/database/Cursor;","getColumnIndex",new String[]{ "Ljava/lang/String;"},"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 8,3},new Method("Landroid/database/Cursor;","getString",new String[]{ "I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L8);
                code.visitConstStmt(CONST_STRING,3,"label");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,5,1},new Method("Landroid/content/ContentValues;","put",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"V"));
                code.visitLabel(L9);
                code.visitConstStmt(CONST_STRING,3,"number");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 8,6},new Method("Landroid/database/Cursor;","getColumnIndex",new String[]{ "Ljava/lang/String;"},"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 8,3},new Method("Landroid/database/Cursor;","getString",new String[]{ "I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L10);
                code.visitConstStmt(CONST_STRING,3,"number");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,6,1},new Method("Landroid/content/ContentValues;","put",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"V"));
                code.visitLabel(L11);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/Integer;");
                code.visitConstStmt(CONST_STRING,3,"type");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 8,7},new Method("Landroid/database/Cursor;","getColumnIndex",new String[]{ "Ljava/lang/String;"},"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 8,3},new Method("Landroid/database/Cursor;","getInt",new String[]{ "I"},"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,3},new Method("Ljava/lang/Integer;","<init>",new String[]{ "I"},"V"));
                code.visitLabel(L12);
                code.visitConstStmt(CONST_STRING,3,"type");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,7,0},new Method("Landroid/content/ContentValues;","put",new String[]{ "Ljava/lang/String;","Ljava/lang/Integer;"},"V"));
                code.visitStmt2R(MOVE_OBJECT,3,2);
                code.visitLabel(L13);
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_deletePhone(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/ijetty/console/Phone;","deletePhone",new String[]{ "Landroid/content/ContentResolver;","Ljava/lang/String;","Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"resolver");
                ddv.visitParameterName(1,"phoneId");
                ddv.visitParameterName(2,"userId");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(84,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(85,L2);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Landroid/provider/Contacts$Phones;","CONTENT_URI","Landroid/net/Uri;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,3},new Method("Landroid/net/Uri;","withAppendedPath",new String[]{ "Landroid/net/Uri;","Ljava/lang/String;"},"Landroid/net/Uri;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,0,1,1},new Method("Landroid/content/ContentResolver;","delete",new String[]{ "Landroid/net/Uri;","Ljava/lang/String;","[Ljava/lang/String;"},"I"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_getPhones(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/ijetty/console/Phone;","getPhones",new String[]{ "Landroid/content/ContentResolver;","Ljava/lang/String;"},"Lorg/mortbay/ijetty/console/Phone$PhoneCollection;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(9);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"resolver");
                ddv.visitParameterName(1,"userId");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(65,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(66,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(69,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(68,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(69,L4);
                ddv.visitStartLocal(4,L4,"whereArgs","[Ljava/lang/String;",null);
                code.visitLabel(L0);
                code.visitJumpStmt(IF_NEZ,8,-1,L3);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L2);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitTypeStmt(NEW_ARRAY,4,0,"[Ljava/lang/String;");
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt3R(APUT_OBJECT,8,4,0);
                code.visitLabel(L4);
                code.visitTypeStmt(NEW_INSTANCE,6,-1,"Lorg/mortbay/ijetty/console/Phone$PhoneCollection;");
                code.visitFieldStmt(SGET_OBJECT,1,-1,new Field("Landroid/provider/Contacts$Phones;","CONTENT_URI","Landroid/net/Uri;"));
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/ijetty/console/Phone;","phonesProjection","[Ljava/lang/String;"));
                code.visitConstStmt(CONST_STRING,3,"people._id = ?");
                code.visitConstStmt(CONST_STRING,5,"type ASC");
                code.visitStmt2R(MOVE_OBJECT,0,7);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 0,1,2,3,4,5},new Method("Landroid/content/ContentResolver;","query",new String[]{ "Landroid/net/Uri;","[Ljava/lang/String;","Ljava/lang/String;","[Ljava/lang/String;","Ljava/lang/String;"},"Landroid/database/Cursor;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 6,0},new Method("Lorg/mortbay/ijetty/console/Phone$PhoneCollection;","<init>",new String[]{ "Landroid/database/Cursor;"},"V"));
                code.visitStmt2R(MOVE_OBJECT,0,6);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m007_savePhone(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/ijetty/console/Phone;","savePhone",new String[]{ "Landroid/content/ContentResolver;","Landroid/content/ContentValues;","Ljava/lang/String;","Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"resolver");
                ddv.visitParameterName(1,"phone");
                ddv.visitParameterName(2,"phoneId");
                ddv.visitParameterName(3,"userId");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(89,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(90,L2);
                ddv.visitStartLocal(0,L2,"uri","Landroid/net/Uri;",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(91,L3);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitFieldStmt(SGET_OBJECT,1,-1,new Field("Landroid/provider/Contacts$Phones;","CONTENT_URI","Landroid/net/Uri;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1,5},new Method("Landroid/net/Uri;","withAppendedPath",new String[]{ "Landroid/net/Uri;","Ljava/lang/String;"},"Landroid/net/Uri;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,0,4,2,2},new Method("Landroid/content/ContentResolver;","update",new String[]{ "Landroid/net/Uri;","Landroid/content/ContentValues;","Ljava/lang/String;","[Ljava/lang/String;"},"I"));
                code.visitLabel(L3);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
