package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0324_org_mortbay_jetty_servlet_Dispatcher_ForwardAttributes {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(0,"Lorg/mortbay/jetty/servlet/Dispatcher$ForwardAttributes;","Ljava/lang/Object;",new String[]{ "Lorg/mortbay/util/Attributes;"});
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("Dispatcher.java");
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/EnclosingClass;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("value", new DexType("Lorg/mortbay/jetty/servlet/Dispatcher;"));
                av00.visitEnd();
            }
        }
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/InnerClass;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("accessFlags",  Integer.valueOf(2));
                av00.visit("name", "ForwardAttributes");
                av00.visitEnd();
            }
        }
        f000__attr(cv);
        f001__contextPath(cv);
        f002__pathInfo(cv);
        f003__query(cv);
        f004__requestURI(cv);
        f005__servletPath(cv);
        f006_this$0(cv);
        m000__init_(cv);
        m001_clearAttributes(cv);
        m002_getAttribute(cv);
        m003_getAttributeNames(cv);
        m004_removeAttribute(cv);
        m005_setAttribute(cv);
        m006_toString(cv);
    }
    public static void f000__attr(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/jetty/servlet/Dispatcher$ForwardAttributes;","_attr","Lorg/mortbay/util/Attributes;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001__contextPath(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/jetty/servlet/Dispatcher$ForwardAttributes;","_contextPath","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002__pathInfo(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/jetty/servlet/Dispatcher$ForwardAttributes;","_pathInfo","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003__query(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/jetty/servlet/Dispatcher$ForwardAttributes;","_query","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f004__requestURI(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/jetty/servlet/Dispatcher$ForwardAttributes;","_requestURI","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f005__servletPath(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/jetty/servlet/Dispatcher$ForwardAttributes;","_servletPath","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f006_this$0(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_FINAL|ACC_SYNTHETIC, new Field("Lorg/mortbay/jetty/servlet/Dispatcher$ForwardAttributes;","this$0","Lorg/mortbay/jetty/servlet/Dispatcher;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/servlet/Dispatcher$ForwardAttributes;","<init>",new String[]{ "Lorg/mortbay/jetty/servlet/Dispatcher;","Lorg/mortbay/util/Attributes;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(1,"attributes");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(375,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(376,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(377,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/servlet/Dispatcher$ForwardAttributes;","this$0","Lorg/mortbay/jetty/servlet/Dispatcher;"));
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/Object;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitFieldStmt(IPUT_OBJECT,2,0,new Field("Lorg/mortbay/jetty/servlet/Dispatcher$ForwardAttributes;","_attr","Lorg/mortbay/util/Attributes;"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001_clearAttributes(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/Dispatcher$ForwardAttributes;","clearAttributes",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(462,L0);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/IllegalStateException;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/IllegalStateException;","<init>",new String[]{ },"V"));
                code.visitStmt1R(THROW,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_getAttribute(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/Dispatcher$ForwardAttributes;","getAttribute",new String[]{ "Ljava/lang/String;"},"Ljava/lang/Object;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"key");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(382,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(384,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(397,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(385,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(386,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(387,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(388,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(391,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(392,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(394,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(395,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(397,L11);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/servlet/Dispatcher$ForwardAttributes;","this$0","Lorg/mortbay/jetty/servlet/Dispatcher;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/jetty/servlet/Dispatcher;","access$000",new String[]{ "Lorg/mortbay/jetty/servlet/Dispatcher;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitJumpStmt(IF_NEZ,0,-1,L7);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_STRING,0,"javax.servlet.forward.path_info");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,0},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L3);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/servlet/Dispatcher$ForwardAttributes;","_pathInfo","Ljava/lang/String;"));
                code.visitLabel(L2);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_STRING,0,"javax.servlet.forward.request_uri");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,0},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L4);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/servlet/Dispatcher$ForwardAttributes;","_requestURI","Ljava/lang/String;"));
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L4);
                code.visitConstStmt(CONST_STRING,0,"javax.servlet.forward.servlet_path");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,0},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L5);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/servlet/Dispatcher$ForwardAttributes;","_servletPath","Ljava/lang/String;"));
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L5);
                code.visitConstStmt(CONST_STRING,0,"javax.servlet.forward.context_path");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,0},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L6);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/servlet/Dispatcher$ForwardAttributes;","_contextPath","Ljava/lang/String;"));
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L6);
                code.visitConstStmt(CONST_STRING,0,"javax.servlet.forward.query_string");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,0},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L7);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/servlet/Dispatcher$ForwardAttributes;","_query","Ljava/lang/String;"));
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L7);
                code.visitConstStmt(CONST_STRING,0,"javax.servlet.include.");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,0},new Method("Ljava/lang/String;","startsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_NEZ,0,-1,L8);
                code.visitConstStmt(CONST_STRING,0,"org.mortbay.jetty.included");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,0},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L9);
                code.visitLabel(L8);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L9);
                code.visitConstStmt(CONST_STRING,0,"org.mortbay.jetty.forwarded");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,0},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L11);
                code.visitLabel(L10);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Ljava/lang/Boolean;","TRUE","Ljava/lang/Boolean;"));
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L11);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/servlet/Dispatcher$ForwardAttributes;","_attr","Lorg/mortbay/util/Attributes;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,2},new Method("Lorg/mortbay/util/Attributes;","getAttribute",new String[]{ "Ljava/lang/String;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_getAttributeNames(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/Dispatcher$ForwardAttributes;","getAttributeNames",new String[]{ },"Ljava/util/Enumeration;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(403,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(404,L2);
                ddv.visitStartLocal(2,L2,"set","Ljava/util/HashSet;",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(405,L3);
                ddv.visitStartLocal(0,L3,"e","Ljava/util/Enumeration;",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(407,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(408,L5);
                ddv.visitStartLocal(1,L5,"name","Ljava/lang/String;",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(410,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(413,L7);
                ddv.visitEndLocal(1,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(415,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(416,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(419,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(420,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(421,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(422,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(423,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(428,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(418,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(425,L17);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_STRING,5,"javax.servlet.forward.query_string");
                code.visitConstStmt(CONST_STRING,4,"javax.servlet.forward.path_info");
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Ljava/util/HashSet;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2},new Method("Ljava/util/HashSet;","<init>",new String[]{ },"V"));
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,3,6,new Field("Lorg/mortbay/jetty/servlet/Dispatcher$ForwardAttributes;","_attr","Lorg/mortbay/util/Attributes;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3},new Method("Lorg/mortbay/util/Attributes;","getAttributeNames",new String[]{ },"Ljava/util/Enumeration;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Ljava/util/Enumeration;","hasMoreElements",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_EQZ,3,-1,L7);
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Ljava/util/Enumeration;","nextElement",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitTypeStmt(CHECK_CAST,1,-1,"Ljava/lang/String;");
                code.visitLabel(L5);
                code.visitConstStmt(CONST_STRING,3,"javax.servlet.include.");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,3},new Method("Ljava/lang/String;","startsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_NEZ,3,-1,L3);
                code.visitConstStmt(CONST_STRING,3,"javax.servlet.forward.");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,3},new Method("Ljava/lang/String;","startsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_NEZ,3,-1,L3);
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,1},new Method("Ljava/util/HashSet;","add",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitLabel(L7);
                code.visitFieldStmt(IGET_OBJECT,3,6,new Field("Lorg/mortbay/jetty/servlet/Dispatcher$ForwardAttributes;","this$0","Lorg/mortbay/jetty/servlet/Dispatcher;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3},new Method("Lorg/mortbay/jetty/servlet/Dispatcher;","access$000",new String[]{ "Lorg/mortbay/jetty/servlet/Dispatcher;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitJumpStmt(IF_NEZ,3,-1,L15);
                code.visitLabel(L8);
                code.visitFieldStmt(IGET_OBJECT,3,6,new Field("Lorg/mortbay/jetty/servlet/Dispatcher$ForwardAttributes;","_pathInfo","Ljava/lang/String;"));
                code.visitJumpStmt(IF_EQZ,3,-1,L16);
                code.visitLabel(L9);
                code.visitConstStmt(CONST_STRING,3,"javax.servlet.forward.path_info");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,4},new Method("Ljava/util/HashSet;","add",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitLabel(L10);
                code.visitConstStmt(CONST_STRING,3,"javax.servlet.forward.request_uri");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/util/HashSet;","add",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitLabel(L11);
                code.visitConstStmt(CONST_STRING,3,"javax.servlet.forward.servlet_path");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/util/HashSet;","add",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitLabel(L12);
                code.visitConstStmt(CONST_STRING,3,"javax.servlet.forward.context_path");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/util/HashSet;","add",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitLabel(L13);
                code.visitFieldStmt(IGET_OBJECT,3,6,new Field("Lorg/mortbay/jetty/servlet/Dispatcher$ForwardAttributes;","_query","Ljava/lang/String;"));
                code.visitJumpStmt(IF_EQZ,3,-1,L17);
                code.visitLabel(L14);
                code.visitConstStmt(CONST_STRING,3,"javax.servlet.forward.query_string");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,5},new Method("Ljava/util/HashSet;","add",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitLabel(L15);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2},new Method("Ljava/util/Collections;","enumeration",new String[]{ "Ljava/util/Collection;"},"Ljava/util/Enumeration;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitStmt1R(RETURN_OBJECT,3);
                code.visitLabel(L16);
                code.visitConstStmt(CONST_STRING,3,"javax.servlet.forward.path_info");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,4},new Method("Ljava/util/HashSet;","remove",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitJumpStmt(GOTO,-1,-1,L10);
                code.visitLabel(L17);
                code.visitConstStmt(CONST_STRING,3,"javax.servlet.forward.query_string");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,5},new Method("Ljava/util/HashSet;","remove",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitJumpStmt(GOTO,-1,-1,L15);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_removeAttribute(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/Dispatcher$ForwardAttributes;","removeAttribute",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(468,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(469,L1);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2,0},new Method("Lorg/mortbay/jetty/servlet/Dispatcher$ForwardAttributes;","setAttribute",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_setAttribute(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/Dispatcher$ForwardAttributes;","setAttribute",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"key");
                ddv.visitParameterName(1,"value");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(434,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(436,L1);
                DexLabel L2=new DexLabel();
                ddv.visitEndLocal(3,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(451,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(437,L4);
                ddv.visitRestartLocal(3,L4);
                DexLabel L5=new DexLabel();
                ddv.visitEndLocal(3,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(438,L6);
                ddv.visitRestartLocal(3,L6);
                DexLabel L7=new DexLabel();
                ddv.visitEndLocal(3,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(439,L8);
                ddv.visitRestartLocal(3,L8);
                DexLabel L9=new DexLabel();
                ddv.visitEndLocal(3,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(440,L10);
                ddv.visitRestartLocal(3,L10);
                DexLabel L11=new DexLabel();
                ddv.visitEndLocal(3,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(442,L12);
                ddv.visitRestartLocal(3,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(443,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(445,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(447,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(448,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(450,L17);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/servlet/Dispatcher$ForwardAttributes;","this$0","Lorg/mortbay/jetty/servlet/Dispatcher;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/jetty/servlet/Dispatcher;","access$000",new String[]{ "Lorg/mortbay/jetty/servlet/Dispatcher;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitJumpStmt(IF_NEZ,0,-1,L15);
                code.visitConstStmt(CONST_STRING,0,"javax.servlet.");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,0},new Method("Ljava/lang/String;","startsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L15);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_STRING,0,"javax.servlet.forward.path_info");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,0},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L4);
                code.visitTypeStmt(CHECK_CAST,3,-1,"Ljava/lang/String;");
                code.visitLabel(L2);
                code.visitFieldStmt(IPUT_OBJECT,3,1,new Field("Lorg/mortbay/jetty/servlet/Dispatcher$ForwardAttributes;","_pathInfo","Ljava/lang/String;"));
                code.visitLabel(L3);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L4);
                code.visitConstStmt(CONST_STRING,0,"javax.servlet.forward.request_uri");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,0},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L6);
                code.visitTypeStmt(CHECK_CAST,3,-1,"Ljava/lang/String;");
                code.visitLabel(L5);
                code.visitFieldStmt(IPUT_OBJECT,3,1,new Field("Lorg/mortbay/jetty/servlet/Dispatcher$ForwardAttributes;","_requestURI","Ljava/lang/String;"));
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitLabel(L6);
                code.visitConstStmt(CONST_STRING,0,"javax.servlet.forward.servlet_path");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,0},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L8);
                code.visitTypeStmt(CHECK_CAST,3,-1,"Ljava/lang/String;");
                code.visitLabel(L7);
                code.visitFieldStmt(IPUT_OBJECT,3,1,new Field("Lorg/mortbay/jetty/servlet/Dispatcher$ForwardAttributes;","_servletPath","Ljava/lang/String;"));
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitLabel(L8);
                code.visitConstStmt(CONST_STRING,0,"javax.servlet.forward.context_path");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,0},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L10);
                code.visitTypeStmt(CHECK_CAST,3,-1,"Ljava/lang/String;");
                code.visitLabel(L9);
                code.visitFieldStmt(IPUT_OBJECT,3,1,new Field("Lorg/mortbay/jetty/servlet/Dispatcher$ForwardAttributes;","_contextPath","Ljava/lang/String;"));
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitLabel(L10);
                code.visitConstStmt(CONST_STRING,0,"javax.servlet.forward.query_string");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,0},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L12);
                code.visitTypeStmt(CHECK_CAST,3,-1,"Ljava/lang/String;");
                code.visitLabel(L11);
                code.visitFieldStmt(IPUT_OBJECT,3,1,new Field("Lorg/mortbay/jetty/servlet/Dispatcher$ForwardAttributes;","_query","Ljava/lang/String;"));
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitLabel(L12);
                code.visitJumpStmt(IF_NEZ,3,-1,L14);
                code.visitLabel(L13);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/servlet/Dispatcher$ForwardAttributes;","_attr","Lorg/mortbay/util/Attributes;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,2},new Method("Lorg/mortbay/util/Attributes;","removeAttribute",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitLabel(L14);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/servlet/Dispatcher$ForwardAttributes;","_attr","Lorg/mortbay/util/Attributes;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,2,3},new Method("Lorg/mortbay/util/Attributes;","setAttribute",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitLabel(L15);
                code.visitJumpStmt(IF_NEZ,3,-1,L17);
                code.visitLabel(L16);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/servlet/Dispatcher$ForwardAttributes;","_attr","Lorg/mortbay/util/Attributes;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,2},new Method("Lorg/mortbay/util/Attributes;","removeAttribute",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitLabel(L17);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/servlet/Dispatcher$ForwardAttributes;","_attr","Lorg/mortbay/util/Attributes;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,2,3},new Method("Lorg/mortbay/util/Attributes;","setAttribute",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_toString(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/Dispatcher$ForwardAttributes;","toString",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(456,L0);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,1,"FORWARD+");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/servlet/Dispatcher$ForwardAttributes;","_attr","Lorg/mortbay/util/Attributes;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/lang/Object;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
