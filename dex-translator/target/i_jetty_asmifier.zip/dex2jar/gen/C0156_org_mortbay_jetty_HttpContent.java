package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0156_org_mortbay_jetty_HttpContent {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC|ACC_INTERFACE|ACC_ABSTRACT,"Lorg/mortbay/jetty/HttpContent;","Ljava/lang/Object;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("HttpContent.java");
        m000_getBuffer(cv);
        m001_getContentLength(cv);
        m002_getContentType(cv);
        m003_getInputStream(cv);
        m004_getLastModified(cv);
        m005_getResource(cv);
        m006_release(cv);
    }
    public static void m000_getBuffer(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/jetty/HttpContent;","getBuffer",new String[]{ },"Lorg/mortbay/io/Buffer;"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m001_getContentLength(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/jetty/HttpContent;","getContentLength",new String[]{ },"J"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m002_getContentType(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/jetty/HttpContent;","getContentType",new String[]{ },"Lorg/mortbay/io/Buffer;"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m003_getInputStream(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/jetty/HttpContent;","getInputStream",new String[]{ },"Ljava/io/InputStream;"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            mv.visitEnd();
        }
    }
    public static void m004_getLastModified(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/jetty/HttpContent;","getLastModified",new String[]{ },"Lorg/mortbay/io/Buffer;"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m005_getResource(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/jetty/HttpContent;","getResource",new String[]{ },"Lorg/mortbay/resource/Resource;"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m006_release(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/jetty/HttpContent;","release",new String[]{ },"V"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
}
