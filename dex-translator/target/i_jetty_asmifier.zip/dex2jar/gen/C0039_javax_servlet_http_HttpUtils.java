package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0039_javax_servlet_http_HttpUtils {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Ljavax/servlet/http/HttpUtils;","Ljava/lang/Object;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("HttpUtils.java");
        f000_LSTRING_FILE(cv);
        f001_lStrings(cv);
        m000__clinit_(cv);
        m001__init_(cv);
        m002_getRequestURL(cv);
        m003_parseName(cv);
        m004_parsePostData(cv);
        m005_parseQueryString(cv);
    }
    public static void f000_LSTRING_FILE(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC|ACC_FINAL, new Field("Ljavax/servlet/http/HttpUtils;","LSTRING_FILE","Ljava/lang/String;"), "/javax/servlet/http/LocalStrings.properties");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001_lStrings(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC, new Field("Ljavax/servlet/http/HttpUtils;","lStrings","Ljava/util/ResourceBundle;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__clinit_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_CONSTRUCTOR, new Method("Ljavax/servlet/http/HttpUtils;","<clinit>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/lang/Exception;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(56,L0);
                ddv.visitLineNumber(62,L1);
                ddv.visitLineNumber(58,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(60,L3);
                ddv.visitStartLocal(0,L3,"e","Ljava/lang/Exception;",null);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/util/PropertyResourceBundle;");
                code.visitConstStmt(CONST_CLASS,2,new DexType("Ljavax/servlet/http/HttpUtils;"));
                code.visitConstStmt(CONST_STRING,3,"/javax/servlet/http/LocalStrings.properties");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/Class;","getResourceAsStream",new String[]{ "Ljava/lang/String;"},"Ljava/io/InputStream;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,2},new Method("Ljava/util/PropertyResourceBundle;","<init>",new String[]{ "Ljava/io/InputStream;"},"V"));
                code.visitFieldStmt(SPUT_OBJECT,1,-1,new Field("Ljavax/servlet/http/HttpUtils;","lStrings","Ljava/util/ResourceBundle;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitStmt2R(MOVE_OBJECT,0,1);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/Exception;","printStackTrace",new String[]{ },"V"));
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Ljavax/servlet/http/HttpUtils;","<init>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(72,L0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/Object;","<init>",new String[]{ },"V"));
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_getRequestURL(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Ljavax/servlet/http/HttpUtils;","getRequestURL",new String[]{ "Ljavax/servlet/http/HttpServletRequest;"},"Ljava/lang/StringBuffer;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"req");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(304,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(305,L1);
                ddv.visitStartLocal(2,L1,"url","Ljava/lang/StringBuffer;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(306,L2);
                ddv.visitStartLocal(1,L2,"scheme","Ljava/lang/String;",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(307,L3);
                ddv.visitStartLocal(0,L3,"port","I",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(312,L4);
                ddv.visitStartLocal(3,L4,"urlPath","Ljava/lang/String;",null);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(313,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(314,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(315,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(317,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(318,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(324,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(325,L11);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Ljava/lang/StringBuffer;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2},new Method("Ljava/lang/StringBuffer;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 5},new Method("Ljavax/servlet/http/HttpServletRequest;","getScheme",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 5},new Method("Ljavax/servlet/http/HttpServletRequest;","getServerPort",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 5},new Method("Ljavax/servlet/http/HttpServletRequest;","getRequestURI",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,1},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L5);
                code.visitConstStmt(CONST_STRING,4,"://");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,4},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 5},new Method("Ljavax/servlet/http/HttpServletRequest;","getServerName",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,4},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L7);
                code.visitConstStmt(CONST_STRING,4,"http");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,4},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,4);
                DexLabel L12=new DexLabel();
                code.visitJumpStmt(IF_EQZ,4,-1,L12);
                code.visitConstStmt(CONST_16,4, Integer.valueOf(80)); // int: 0x00000050  float:0.000000
                code.visitJumpStmt(IF_NE,0,4,L8);
                code.visitLabel(L12);
                code.visitConstStmt(CONST_STRING,4,"https");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,4},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitJumpStmt(IF_EQZ,4,-1,L10);
                code.visitConstStmt(CONST_16,4, Integer.valueOf(443)); // int: 0x000001bb  float:0.000000
                code.visitJumpStmt(IF_EQ,0,4,L10);
                code.visitLabel(L8);
                code.visitConstStmt(CONST_16,4, Integer.valueOf(58)); // int: 0x0000003a  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,4},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "C"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 5},new Method("Ljavax/servlet/http/HttpServletRequest;","getServerPort",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,4},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "I"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L11);
                code.visitStmt1R(RETURN_OBJECT,2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_parseName(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PRIVATE|ACC_STATIC, new Method("Ljavax/servlet/http/HttpUtils;","parseName",new String[]{ "Ljava/lang/String;","Ljava/lang/StringBuffer;"},"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(8);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                DexLabel L3=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2,L3},new String[]{ "Ljava/lang/NumberFormatException;","Ljava/lang/StringIndexOutOfBoundsException;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"s");
                ddv.visitParameterName(1,"sb");
                DexLabel L4=new DexLabel();
                ddv.visitPrologue(L4);
                ddv.visitLineNumber(245,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(246,L5);
                DexLabel L6=new DexLabel();
                ddv.visitStartLocal(2,L6,"i","I",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(247,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(248,L8);
                ddv.visitStartLocal(0,L8,"c","C",null);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(270,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(246,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(250,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(254,L12);
                ddv.visitLineNumber(256,L1);
                ddv.visitLineNumber(257,L2);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(260,L13);
                ddv.visitStartLocal(1,L13,"e","Ljava/lang/NumberFormatException;",null);
                ddv.visitLineNumber(261,L3);
                ddv.visitEndLocal(1,L3);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(262,L14);
                ddv.visitStartLocal(1,L14,"e","Ljava/lang/StringIndexOutOfBoundsException;",null);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(263,L15);
                ddv.visitStartLocal(3,L15,"rest","Ljava/lang/String;",null);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(264,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(265,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(274,L18);
                ddv.visitEndLocal(0,L18);
                ddv.visitEndLocal(1,L18);
                ddv.visitEndLocal(3,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(248,L19);
                code.visitLabel(L4);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,4},new Method("Ljava/lang/StringBuffer;","setLength",new String[]{ "I"},"V"));
                code.visitLabel(L5);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitJumpStmt(IF_GE,2,4,L18);
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,2},new Method("Ljava/lang/String;","charAt",new String[]{ "I"},"C"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitLabel(L8);
                code.visitSparseSwitchStmt(SPARSE_SWITCH,0,new int[]{ 37,43},new DexLabel[]{L12,L11});
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,0},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "C"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L10);
                code.visitStmt2R1N(ADD_INT_LIT8,2,2,1);
                code.visitJumpStmt(GOTO,-1,-1,L6);
                code.visitLabel(L11);
                code.visitConstStmt(CONST_16,4, Integer.valueOf(32)); // int: 0x00000020  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,4},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "C"},"Ljava/lang/StringBuffer;"));
                code.visitJumpStmt(GOTO,-1,-1,L10);
                code.visitLabel(L12);
                code.visitStmt2R1N(ADD_INT_LIT8,4,2,1);
                code.visitStmt2R1N(ADD_INT_LIT8,5,2,3);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,4,5},new Method("Ljava/lang/String;","substring",new String[]{ "I","I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitConstStmt(CONST_16,5, Integer.valueOf(16)); // int: 0x00000010  float:0.000000
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 4,5},new Method("Ljava/lang/Integer;","parseInt",new String[]{ "Ljava/lang/String;","I"},"I"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitStmt2R(INT_TO_CHAR,4,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,4},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "C"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L1);
                code.visitStmt2R1N(ADD_INT_LIT8,2,2,2);
                code.visitJumpStmt(GOTO,-1,-1,L10);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,4);
                code.visitStmt2R(MOVE_OBJECT,1,4);
                code.visitLabel(L13);
                code.visitTypeStmt(NEW_INSTANCE,4,-1,"Ljava/lang/IllegalArgumentException;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4},new Method("Ljava/lang/IllegalArgumentException;","<init>",new String[]{ },"V"));
                code.visitStmt1R(THROW,4);
                code.visitLabel(L3);
                code.visitStmt1R(MOVE_EXCEPTION,4);
                code.visitStmt2R(MOVE_OBJECT,1,4);
                code.visitLabel(L14);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,2},new Method("Ljava/lang/String;","substring",new String[]{ "I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitLabel(L15);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,3},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L16);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitConstStmt(CONST_4,5, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitJumpStmt(IF_NE,4,5,L10);
                code.visitLabel(L17);
                code.visitStmt2R1N(ADD_INT_LIT8,2,2,1);
                code.visitJumpStmt(GOTO,-1,-1,L10);
                code.visitLabel(L18);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Ljava/lang/StringBuffer;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitStmt1R(RETURN_OBJECT,4);
                code.visitLabel(L19);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_parsePostData(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Ljavax/servlet/http/HttpUtils;","parsePostData",new String[]{ "I","Ljavax/servlet/ServletInputStream;"},"Ljava/util/Hashtable;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(10);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L1},new String[]{ "Ljava/io/IOException;"});
                DexLabel L2=new DexLabel();
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                code.visitTryCatch(L2,L3,new DexLabel[]{L4},new String[]{ "Ljava/io/UnsupportedEncodingException;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"len");
                ddv.visitParameterName(1,"in");
                DexLabel L5=new DexLabel();
                ddv.visitPrologue(L5);
                ddv.visitLineNumber(195,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(196,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(229,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(198,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(199,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(205,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(207,L11);
                ddv.visitStartLocal(5,L11,"postedBytes","[B",null);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(210,L12);
                ddv.visitStartLocal(3,L12,"offset","I",null);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(211,L13);
                ddv.visitStartLocal(1,L13,"inputLen","I",null);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(212,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(213,L15);
                ddv.visitStartLocal(2,L15,"msg","Ljava/lang/String;",null);
                ddv.visitLineNumber(218,L1);
                ddv.visitEndLocal(1,L1);
                ddv.visitEndLocal(2,L1);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(219,L16);
                ddv.visitStartLocal(0,L16,"e","Ljava/io/IOException;",null);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(215,L17);
                ddv.visitEndLocal(0,L17);
                ddv.visitRestartLocal(1,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(216,L18);
                ddv.visitLineNumber(228,L2);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(229,L19);
                ddv.visitStartLocal(4,L19,"postedBody","Ljava/lang/String;",null);
                ddv.visitLineNumber(230,L4);
                ddv.visitEndLocal(4,L4);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(233,L20);
                ddv.visitStartLocal(0,L20,"e","Ljava/io/UnsupportedEncodingException;",null);
                code.visitLabel(L5);
                code.visitJumpStmt(IF_GTZ,8,-1,L8);
                code.visitLabel(L6);
                code.visitTypeStmt(NEW_INSTANCE,6,-1,"Ljava/util/Hashtable;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 6},new Method("Ljava/util/Hashtable;","<init>",new String[]{ },"V"));
                code.visitLabel(L7);
                code.visitStmt1R(RETURN_OBJECT,6);
                code.visitLabel(L8);
                code.visitJumpStmt(IF_NEZ,9,-1,L10);
                code.visitLabel(L9);
                code.visitTypeStmt(NEW_INSTANCE,6,-1,"Ljava/lang/IllegalArgumentException;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 6},new Method("Ljava/lang/IllegalArgumentException;","<init>",new String[]{ },"V"));
                code.visitStmt1R(THROW,6);
                code.visitLabel(L10);
                code.visitTypeStmt(NEW_ARRAY,5,8,"[B");
                code.visitLabel(L11);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L12);
                code.visitStmt3R(SUB_INT,6,8,3);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9,5,3,6},new Method("Ljavax/servlet/ServletInputStream;","read",new String[]{ "[B","I","I"},"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitLabel(L13);
                code.visitJumpStmt(IF_GTZ,1,-1,L17);
                code.visitLabel(L14);
                code.visitFieldStmt(SGET_OBJECT,6,-1,new Field("Ljavax/servlet/http/HttpUtils;","lStrings","Ljava/util/ResourceBundle;"));
                code.visitConstStmt(CONST_STRING,7,"err.io.short_read");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,7},new Method("Ljava/util/ResourceBundle;","getString",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L15);
                code.visitTypeStmt(NEW_INSTANCE,6,-1,"Ljava/lang/IllegalArgumentException;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 6,2},new Method("Ljava/lang/IllegalArgumentException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,6);
                code.visitLabel(L1);
                code.visitStmt1R(MOVE_EXCEPTION,6);
                code.visitStmt2R(MOVE_OBJECT,0,6);
                code.visitLabel(L16);
                code.visitTypeStmt(NEW_INSTANCE,6,-1,"Ljava/lang/IllegalArgumentException;");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/io/IOException;","getMessage",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 6,7},new Method("Ljava/lang/IllegalArgumentException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,6);
                code.visitLabel(L17);
                code.visitStmt2R(ADD_INT_2ADDR,3,1);
                code.visitLabel(L18);
                code.visitStmt3R(SUB_INT,6,8,3);
                code.visitJumpStmt(IF_GTZ,6,-1,L12);
                code.visitLabel(L2);
                code.visitTypeStmt(NEW_INSTANCE,4,-1,"Ljava/lang/String;");
                code.visitConstStmt(CONST_4,6, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitConstStmt(CONST_STRING,7,"8859_1");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4,5,6,8,7},new Method("Ljava/lang/String;","<init>",new String[]{ "[B","I","I","Ljava/lang/String;"},"V"));
                code.visitLabel(L19);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 4},new Method("Ljavax/servlet/http/HttpUtils;","parseQueryString",new String[]{ "Ljava/lang/String;"},"Ljava/util/Hashtable;"));
                code.visitLabel(L3);
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitJumpStmt(GOTO,-1,-1,L7);
                code.visitLabel(L4);
                code.visitStmt1R(MOVE_EXCEPTION,6);
                code.visitStmt2R(MOVE_OBJECT,0,6);
                code.visitLabel(L20);
                code.visitTypeStmt(NEW_INSTANCE,6,-1,"Ljava/lang/IllegalArgumentException;");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/io/UnsupportedEncodingException;","getMessage",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 6,7},new Method("Ljava/lang/IllegalArgumentException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,6);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_parseQueryString(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Ljavax/servlet/http/HttpUtils;","parseQueryString",new String[]{ "Ljava/lang/String;"},"Ljava/util/Hashtable;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(15);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"s");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(112,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(114,L2);
                ddv.visitStartLocal(10,L2,"valArray","[Ljava/lang/String;",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(115,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(117,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(118,L5);
                ddv.visitStartLocal(1,L5,"ht","Ljava/util/Hashtable;",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(119,L6);
                ddv.visitStartLocal(7,L6,"sb","Ljava/lang/StringBuffer;",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(120,L7);
                ddv.visitEndLocal(14,L7);
                ddv.visitStartLocal(8,L7,"st","Ljava/util/StringTokenizer;",null);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(121,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(122,L9);
                ddv.visitStartLocal(5,L9,"pair","Ljava/lang/String;",null);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(123,L10);
                ddv.visitStartLocal(6,L10,"pos","I",null);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(126,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(128,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(129,L13);
                ddv.visitStartLocal(3,L13,"key","Ljava/lang/String;",null);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(130,L14);
                ddv.visitStartLocal(9,L14,"val","Ljava/lang/String;",null);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(131,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(132,L16);
                ddv.visitStartLocal(4,L16,"oldVals","[Ljava/lang/String;",null);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(133,L17);
                DexLabel L18=new DexLabel();
                ddv.visitStartLocal(2,L18,"i","I",null);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(134,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(133,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(135,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(140,L22);
                ddv.visitEndLocal(4,L22);
                ddv.visitEndLocal(2,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(137,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(138,L24);
                ddv.visitRestartLocal(10,L24);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(142,L25);
                ddv.visitEndLocal(5,L25);
                ddv.visitEndLocal(6,L25);
                ddv.visitEndLocal(3,L25);
                ddv.visitEndLocal(9,L25);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,13, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,10, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L2);
                code.visitJumpStmt(IF_NEZ,14,-1,L4);
                code.visitLabel(L3);
                code.visitTypeStmt(NEW_INSTANCE,11,-1,"Ljava/lang/IllegalArgumentException;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 11},new Method("Ljava/lang/IllegalArgumentException;","<init>",new String[]{ },"V"));
                code.visitStmt1R(THROW,11);
                code.visitLabel(L4);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/util/Hashtable;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljava/util/Hashtable;","<init>",new String[]{ },"V"));
                code.visitLabel(L5);
                code.visitTypeStmt(NEW_INSTANCE,7,-1,"Ljava/lang/StringBuffer;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 7},new Method("Ljava/lang/StringBuffer;","<init>",new String[]{ },"V"));
                code.visitLabel(L6);
                code.visitTypeStmt(NEW_INSTANCE,8,-1,"Ljava/util/StringTokenizer;");
                code.visitConstStmt(CONST_STRING,11,"&");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 8,14,11},new Method("Ljava/util/StringTokenizer;","<init>",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"V"));
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Ljava/util/StringTokenizer;","hasMoreTokens",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,11);
                code.visitJumpStmt(IF_EQZ,11,-1,L25);
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Ljava/util/StringTokenizer;","nextToken",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitLabel(L9);
                code.visitConstStmt(CONST_16,11, Integer.valueOf(61)); // int: 0x0000003d  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,11},new Method("Ljava/lang/String;","indexOf",new String[]{ "I"},"I"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitLabel(L10);
                code.visitConstStmt(CONST_4,11, Integer.valueOf(-1)); // int: 0xffffffff  float:NaN
                code.visitJumpStmt(IF_NE,6,11,L12);
                code.visitLabel(L11);
                code.visitTypeStmt(NEW_INSTANCE,11,-1,"Ljava/lang/IllegalArgumentException;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 11},new Method("Ljava/lang/IllegalArgumentException;","<init>",new String[]{ },"V"));
                code.visitStmt1R(THROW,11);
                code.visitLabel(L12);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,13,6},new Method("Ljava/lang/String;","substring",new String[]{ "I","I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,11);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 11,7},new Method("Ljavax/servlet/http/HttpUtils;","parseName",new String[]{ "Ljava/lang/String;","Ljava/lang/StringBuffer;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitLabel(L13);
                code.visitStmt2R1N(ADD_INT_LIT8,11,6,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,12);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,11,12},new Method("Ljava/lang/String;","substring",new String[]{ "I","I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,11);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 11,7},new Method("Ljavax/servlet/http/HttpUtils;","parseName",new String[]{ "Ljava/lang/String;","Ljava/lang/StringBuffer;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitLabel(L14);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,3},new Method("Ljava/util/Hashtable;","containsKey",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,11);
                code.visitJumpStmt(IF_EQZ,11,-1,L23);
                code.visitLabel(L15);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,3},new Method("Ljava/util/Hashtable;","get",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,14);
                code.visitTypeStmt(CHECK_CAST,14,-1,"[Ljava/lang/String;");
                code.visitStmt2R(MOVE_OBJECT,0,14);
                code.visitTypeStmt(CHECK_CAST,0,-1,"[Ljava/lang/String;");
                code.visitStmt2R(MOVE_OBJECT,4,0);
                code.visitLabel(L16);
                code.visitStmt2R(ARRAY_LENGTH,11,4);
                code.visitStmt2R1N(ADD_INT_LIT8,11,11,1);
                code.visitTypeStmt(NEW_ARRAY,10,11,"[Ljava/lang/String;");
                code.visitLabel(L17);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L18);
                code.visitStmt2R(ARRAY_LENGTH,11,4);
                code.visitJumpStmt(IF_GE,2,11,L21);
                code.visitLabel(L19);
                code.visitStmt3R(AGET_OBJECT,11,4,2);
                code.visitStmt3R(APUT_OBJECT,11,10,2);
                code.visitLabel(L20);
                code.visitStmt2R1N(ADD_INT_LIT8,2,2,1);
                code.visitJumpStmt(GOTO,-1,-1,L18);
                code.visitLabel(L21);
                code.visitStmt2R(ARRAY_LENGTH,11,4);
                code.visitStmt3R(APUT_OBJECT,9,10,11);
                code.visitLabel(L22);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,3,10},new Method("Ljava/util/Hashtable;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitJumpStmt(GOTO,-1,-1,L7);
                code.visitLabel(L23);
                code.visitConstStmt(CONST_4,11, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitTypeStmt(NEW_ARRAY,10,11,"[Ljava/lang/String;");
                code.visitLabel(L24);
                code.visitStmt3R(APUT_OBJECT,9,10,13);
                code.visitJumpStmt(GOTO,-1,-1,L22);
                code.visitLabel(L25);
                code.visitStmt1R(RETURN_OBJECT,1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
