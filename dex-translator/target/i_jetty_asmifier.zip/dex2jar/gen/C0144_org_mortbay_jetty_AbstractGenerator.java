package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0144_org_mortbay_jetty_AbstractGenerator {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC|ACC_ABSTRACT,"Lorg/mortbay/jetty/AbstractGenerator;","Ljava/lang/Object;",new String[]{ "Lorg/mortbay/jetty/Generator;"});
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("AbstractGenerator.java");
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/MemberClasses;", Visibility.SYSTEM);
            if(av00 != null) {
                {
                    DexAnnotationVisitor av01 = av00.visitArray("value");
                    if(av01 != null) {
                        av01.visit(null, new DexType("Lorg/mortbay/jetty/AbstractGenerator$OutputWriter;"));
                        av01.visit(null, new DexType("Lorg/mortbay/jetty/AbstractGenerator$Output;"));
                        av01.visitEnd();
                    }
                }
                av00.visitEnd();
            }
        }
        f000_MAX_OUTPUT_CHARS(cv);
        f001_NO_BYTES(cv);
        f002_STATE_CONTENT(cv);
        f003_STATE_END(cv);
        f004_STATE_FLUSHING(cv);
        f005_STATE_HEADER(cv);
        f006___reasons(cv);
        f007__buffer(cv);
        f008__buffers(cv);
        f009__close(cv);
        f010__content(cv);
        f011__contentBufferSize(cv);
        f012__contentLength(cv);
        f013__contentWritten(cv);
        f014__endp(cv);
        f015__head(cv);
        f016__header(cv);
        f017__headerBufferSize(cv);
        f018__last(cv);
        f019__method(cv);
        f020__noContent(cv);
        f021__reason(cv);
        f022__sendServerVersion(cv);
        f023__state(cv);
        f024__status(cv);
        f025__uri(cv);
        f026__version(cv);
        m000__clinit_(cv);
        m001__init_(cv);
        m002_access$000(cv);
        m003_access$100(cv);
        m004_getReason(cv);
        m005_getReasonBuffer(cv);
        m006_complete(cv);
        m007_completeHeader(cv);
        m008_completeUncheckedAddContent(cv);
        m009_flush(cv);
        m010_getContentBufferSize(cv);
        m011_getContentWritten(cv);
        m012_getSendServerVersion(cv);
        m013_getState(cv);
        m014_getUncheckedBuffer(cv);
        m015_getVersion(cv);
        m016_increaseContentBufferSize(cv);
        m017_isBufferFull(cv);
        m018_isCommitted(cv);
        m019_isComplete(cv);
        m020_isContentWritten(cv);
        m021_isHead(cv);
        m022_isIdle(cv);
        m023_isPersistent(cv);
        m024_isState(cv);
        m025_prepareUncheckedAddContent(cv);
        m026_reset(cv);
        m027_resetBuffer(cv);
        m028_sendError(cv);
        m029_setContentLength(cv);
        m030_setHead(cv);
        m031_setPersistent(cv);
        m032_setRequest(cv);
        m033_setResponse(cv);
        m034_setSendServerVersion(cv);
        m035_setVersion(cv);
        m036_uncheckedAddContent(cv);
    }
    public static void f000_MAX_OUTPUT_CHARS(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC, new Field("Lorg/mortbay/jetty/AbstractGenerator;","MAX_OUTPUT_CHARS","I"),  Integer.valueOf(0));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001_NO_BYTES(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC, new Field("Lorg/mortbay/jetty/AbstractGenerator;","NO_BYTES","[B"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002_STATE_CONTENT(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/AbstractGenerator;","STATE_CONTENT","I"),  Integer.valueOf(2));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003_STATE_END(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/AbstractGenerator;","STATE_END","I"),  Integer.valueOf(4));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f004_STATE_FLUSHING(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/AbstractGenerator;","STATE_FLUSHING","I"),  Integer.valueOf(3));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f005_STATE_HEADER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/AbstractGenerator;","STATE_HEADER","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f006___reasons(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC, new Field("Lorg/mortbay/jetty/AbstractGenerator;","__reasons","[Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f007__buffer(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/jetty/AbstractGenerator;","_buffer","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f008__buffers(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/jetty/AbstractGenerator;","_buffers","Lorg/mortbay/io/Buffers;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f009__close(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/jetty/AbstractGenerator;","_close","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f010__content(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/jetty/AbstractGenerator;","_content","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f011__contentBufferSize(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/jetty/AbstractGenerator;","_contentBufferSize","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f012__contentLength(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/jetty/AbstractGenerator;","_contentLength","J"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f013__contentWritten(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/jetty/AbstractGenerator;","_contentWritten","J"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f014__endp(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/jetty/AbstractGenerator;","_endp","Lorg/mortbay/io/EndPoint;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f015__head(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/jetty/AbstractGenerator;","_head","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f016__header(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/jetty/AbstractGenerator;","_header","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f017__headerBufferSize(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/jetty/AbstractGenerator;","_headerBufferSize","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f018__last(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/jetty/AbstractGenerator;","_last","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f019__method(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/jetty/AbstractGenerator;","_method","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f020__noContent(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/jetty/AbstractGenerator;","_noContent","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f021__reason(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/jetty/AbstractGenerator;","_reason","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f022__sendServerVersion(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/AbstractGenerator;","_sendServerVersion","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f023__state(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/jetty/AbstractGenerator;","_state","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f024__status(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/jetty/AbstractGenerator;","_status","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f025__uri(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/jetty/AbstractGenerator;","_uri","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f026__version(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/jetty/AbstractGenerator;","_version","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__clinit_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/AbstractGenerator;","<clinit>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/lang/IllegalAccessException;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(56,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(57,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(59,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(62,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(63,L7);
                ddv.visitStartLocal(1,L7,"fields","[Ljava/lang/reflect/Field;",null);
                DexLabel L8=new DexLabel();
                ddv.visitStartLocal(2,L8,"i","I",null);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(65,L9);
                ddv.visitLineNumber(70,L0);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(71,L10);
                ddv.visitStartLocal(0,L10,"code","I",null);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(72,L11);
                ddv.visitLineNumber(63,L1);
                ddv.visitEndLocal(0,L1);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(78,L12);
                ddv.visitLineNumber(74,L2);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitTypeStmt(NEW_ARRAY,3,3,"[B");
                code.visitFieldStmt(SPUT_OBJECT,3,-1,new Field("Lorg/mortbay/jetty/AbstractGenerator;","NO_BYTES","[B"));
                code.visitLabel(L4);
                code.visitConstStmt(CONST_16,3, Integer.valueOf(512)); // int: 0x00000200  float:0.000000
                code.visitFieldStmt(SPUT,3,-1,new Field("Lorg/mortbay/jetty/AbstractGenerator;","MAX_OUTPUT_CHARS","I"));
                code.visitLabel(L5);
                code.visitConstStmt(CONST_16,3, Integer.valueOf(505)); // int: 0x000001f9  float:0.000000
                code.visitTypeStmt(NEW_ARRAY,3,3,"[Lorg/mortbay/io/Buffer;");
                code.visitFieldStmt(SPUT_OBJECT,3,-1,new Field("Lorg/mortbay/jetty/AbstractGenerator;","__reasons","[Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L6);
                code.visitConstStmt(CONST_CLASS,3,new DexType("Ljavax/servlet/http/HttpServletResponse;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/lang/Class;","getDeclaredFields",new String[]{ },"[Ljava/lang/reflect/Field;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L7);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L8);
                code.visitStmt2R(ARRAY_LENGTH,3,1);
                code.visitJumpStmt(IF_GE,2,3,L12);
                code.visitLabel(L9);
                code.visitStmt3R(AGET_OBJECT,3,1,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/lang/reflect/Field;","getModifiers",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitStmt2R1N(AND_INT_LIT8,3,3,8);
                code.visitJumpStmt(IF_EQZ,3,-1,L1);
                code.visitStmt3R(AGET_OBJECT,3,1,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/lang/reflect/Field;","getName",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitConstStmt(CONST_STRING,4,"SC_");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/String;","startsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_EQZ,3,-1,L1);
                code.visitLabel(L0);
                code.visitStmt3R(AGET_OBJECT,3,1,2);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/reflect/Field;","getInt",new String[]{ "Ljava/lang/Object;"},"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitLabel(L10);
                code.visitFieldStmt(SGET_OBJECT,3,-1,new Field("Lorg/mortbay/jetty/AbstractGenerator;","__reasons","[Lorg/mortbay/io/Buffer;"));
                code.visitStmt2R(ARRAY_LENGTH,3,3);
                code.visitJumpStmt(IF_GE,0,3,L1);
                code.visitLabel(L11);
                code.visitFieldStmt(SGET_OBJECT,3,-1,new Field("Lorg/mortbay/jetty/AbstractGenerator;","__reasons","[Lorg/mortbay/io/Buffer;"));
                code.visitTypeStmt(NEW_INSTANCE,4,-1,"Lorg/mortbay/io/ByteArrayBuffer;");
                code.visitStmt3R(AGET_OBJECT,5,1,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/lang/reflect/Field;","getName",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitConstStmt(CONST_4,6, Integer.valueOf(3)); // int: 0x00000003  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Ljava/lang/String;","substring",new String[]{ "I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4,5},new Method("Lorg/mortbay/io/ByteArrayBuffer;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt3R(APUT_OBJECT,4,3,0);
                code.visitLabel(L1);
                code.visitStmt2R1N(ADD_INT_LIT8,2,2,1);
                code.visitJumpStmt(GOTO,-1,-1,L8);
                code.visitLabel(L12);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,3);
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/AbstractGenerator;","<init>",new String[]{ "Lorg/mortbay/io/Buffers;","Lorg/mortbay/io/EndPoint;","I","I"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(8);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"buffers");
                ddv.visitParameterName(1,"io");
                ddv.visitParameterName(2,"headerBufferSize");
                ddv.visitParameterName(3,"contentBufferSize");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(130,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(93,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(95,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(96,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(101,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(102,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(103,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(104,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(105,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(106,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(131,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(132,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(133,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(134,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(135,L15);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3},new Method("Ljava/lang/Object;","<init>",new String[]{ },"V"));
                code.visitLabel(L2);
                code.visitFieldStmt(IPUT,2,3,new Field("Lorg/mortbay/jetty/AbstractGenerator;","_state","I"));
                code.visitLabel(L3);
                code.visitFieldStmt(IPUT,2,3,new Field("Lorg/mortbay/jetty/AbstractGenerator;","_status","I"));
                code.visitLabel(L4);
                code.visitConstStmt(CONST_16,0, Integer.valueOf(11)); // int: 0x0000000b  float:0.000000
                code.visitFieldStmt(IPUT,0,3,new Field("Lorg/mortbay/jetty/AbstractGenerator;","_version","I"));
                code.visitLabel(L5);
                code.visitConstStmt(CONST_WIDE_16,0,Long.valueOf(0L)); // long: 0x0000000000000000  double:0.000000
                code.visitFieldStmt(IPUT_WIDE,0,3,new Field("Lorg/mortbay/jetty/AbstractGenerator;","_contentWritten","J"));
                code.visitLabel(L6);
                code.visitConstStmt(CONST_WIDE_16,0,Long.valueOf(-3L)); // long: 0xfffffffffffffffd  double:NaN
                code.visitFieldStmt(IPUT_WIDE,0,3,new Field("Lorg/mortbay/jetty/AbstractGenerator;","_contentLength","J"));
                code.visitLabel(L7);
                code.visitFieldStmt(IPUT_BOOLEAN,2,3,new Field("Lorg/mortbay/jetty/AbstractGenerator;","_last","Z"));
                code.visitLabel(L8);
                code.visitFieldStmt(IPUT_BOOLEAN,2,3,new Field("Lorg/mortbay/jetty/AbstractGenerator;","_head","Z"));
                code.visitLabel(L9);
                code.visitFieldStmt(IPUT_BOOLEAN,2,3,new Field("Lorg/mortbay/jetty/AbstractGenerator;","_noContent","Z"));
                code.visitLabel(L10);
                code.visitFieldStmt(IPUT_BOOLEAN,2,3,new Field("Lorg/mortbay/jetty/AbstractGenerator;","_close","Z"));
                code.visitLabel(L11);
                code.visitFieldStmt(IPUT_OBJECT,4,3,new Field("Lorg/mortbay/jetty/AbstractGenerator;","_buffers","Lorg/mortbay/io/Buffers;"));
                code.visitLabel(L12);
                code.visitFieldStmt(IPUT_OBJECT,5,3,new Field("Lorg/mortbay/jetty/AbstractGenerator;","_endp","Lorg/mortbay/io/EndPoint;"));
                code.visitLabel(L13);
                code.visitFieldStmt(IPUT,6,3,new Field("Lorg/mortbay/jetty/AbstractGenerator;","_headerBufferSize","I"));
                code.visitLabel(L14);
                code.visitFieldStmt(IPUT,7,3,new Field("Lorg/mortbay/jetty/AbstractGenerator;","_contentBufferSize","I"));
                code.visitLabel(L15);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_access$000(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_SYNTHETIC, new Method("Lorg/mortbay/jetty/AbstractGenerator;","access$000",new String[]{ },"[B"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(48,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/AbstractGenerator;","NO_BYTES","[B"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_access$100(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_SYNTHETIC, new Method("Lorg/mortbay/jetty/AbstractGenerator;","access$100",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(48,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(SGET,0,-1,new Field("Lorg/mortbay/jetty/AbstractGenerator;","MAX_OUTPUT_CHARS","I"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_getReason(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/jetty/AbstractGenerator;","getReason",new String[]{ "I"},"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"code");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(88,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(89,L1);
                ddv.visitStartLocal(0,L1,"reason","Lorg/mortbay/io/Buffer;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(88,L2);
                ddv.visitEndLocal(0,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(89,L3);
                ddv.visitRestartLocal(0,L3);
                code.visitLabel(L0);
                code.visitFieldStmt(SGET_OBJECT,1,-1,new Field("Lorg/mortbay/jetty/AbstractGenerator;","__reasons","[Lorg/mortbay/io/Buffer;"));
                code.visitStmt2R(ARRAY_LENGTH,1,1);
                code.visitJumpStmt(IF_GE,2,1,L2);
                code.visitFieldStmt(SGET_OBJECT,1,-1,new Field("Lorg/mortbay/jetty/AbstractGenerator;","__reasons","[Lorg/mortbay/io/Buffer;"));
                code.visitStmt3R(AGET_OBJECT,1,1,2);
                code.visitStmt2R(MOVE_OBJECT,0,1);
                code.visitLabel(L1);
                code.visitJumpStmt(IF_NEZ,0,-1,L3);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2},new Method("Lorg/mortbay/util/TypeUtil;","toString",new String[]{ "I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                DexLabel L4=new DexLabel();
                code.visitLabel(L4);
                code.visitStmt1R(RETURN_OBJECT,1);
                code.visitLabel(L2);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt2R(MOVE_OBJECT,0,1);
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/Object;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_getReasonBuffer(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED|ACC_STATIC, new Method("Lorg/mortbay/jetty/AbstractGenerator;","getReasonBuffer",new String[]{ "I"},"Lorg/mortbay/io/Buffer;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"code");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(82,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(83,L2);
                ddv.visitStartLocal(0,L2,"reason","Lorg/mortbay/io/Buffer;",null);
                DexLabel L3=new DexLabel();
                ddv.visitEndLocal(0,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(82,L4);
                DexLabel L5=new DexLabel();
                ddv.visitRestartLocal(0,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(83,L6);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitFieldStmt(SGET_OBJECT,1,-1,new Field("Lorg/mortbay/jetty/AbstractGenerator;","__reasons","[Lorg/mortbay/io/Buffer;"));
                code.visitStmt2R(ARRAY_LENGTH,1,1);
                code.visitJumpStmt(IF_GE,3,1,L3);
                code.visitFieldStmt(SGET_OBJECT,1,-1,new Field("Lorg/mortbay/jetty/AbstractGenerator;","__reasons","[Lorg/mortbay/io/Buffer;"));
                code.visitStmt3R(AGET_OBJECT,1,1,3);
                code.visitStmt2R(MOVE_OBJECT,0,1);
                code.visitLabel(L2);
                code.visitJumpStmt(IF_NEZ,0,-1,L5);
                code.visitStmt2R(MOVE_OBJECT,1,2);
                DexLabel L7=new DexLabel();
                code.visitLabel(L7);
                code.visitStmt1R(RETURN_OBJECT,1);
                code.visitLabel(L3);
                code.visitStmt2R(MOVE_OBJECT,0,2);
                code.visitLabel(L4);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L5);
                code.visitStmt2R(MOVE_OBJECT,1,0);
                code.visitLabel(L6);
                code.visitJumpStmt(GOTO,-1,-1,L7);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_complete(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/AbstractGenerator;","complete",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(433,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(435,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(438,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(440,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(441,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(442,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(444,L6);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,4,new Field("Lorg/mortbay/jetty/AbstractGenerator;","_state","I"));
                code.visitJumpStmt(IF_NEZ,0,-1,L2);
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/IllegalStateException;");
                code.visitConstStmt(CONST_STRING,1,"State==HEADER");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Ljava/lang/IllegalStateException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,0);
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_WIDE,0,4,new Field("Lorg/mortbay/jetty/AbstractGenerator;","_contentLength","J"));
                code.visitConstStmt(CONST_WIDE_16,2,Long.valueOf(0L)); // long: 0x0000000000000000  double:0.000000
                code.visitStmt3R(CMP_LONG,0,0,2);
                code.visitJumpStmt(IF_LTZ,0,-1,L6);
                code.visitFieldStmt(IGET_WIDE,0,4,new Field("Lorg/mortbay/jetty/AbstractGenerator;","_contentLength","J"));
                code.visitFieldStmt(IGET_WIDE,2,4,new Field("Lorg/mortbay/jetty/AbstractGenerator;","_contentWritten","J"));
                code.visitStmt3R(CMP_LONG,0,0,2);
                code.visitJumpStmt(IF_EQZ,0,-1,L6);
                code.visitFieldStmt(IGET_BOOLEAN,0,4,new Field("Lorg/mortbay/jetty/AbstractGenerator;","_head","Z"));
                code.visitJumpStmt(IF_NEZ,0,-1,L6);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/log/Log;","isDebugEnabled",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L5);
                code.visitLabel(L4);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,1,"ContentLength written==");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IGET_WIDE,1,4,new Field("Lorg/mortbay/jetty/AbstractGenerator;","_contentWritten","J"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "J"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitConstStmt(CONST_STRING,1," != contentLength==");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IGET_WIDE,1,4,new Field("Lorg/mortbay/jetty/AbstractGenerator;","_contentLength","J"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "J"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L5);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitFieldStmt(IPUT_BOOLEAN,0,4,new Field("Lorg/mortbay/jetty/AbstractGenerator;","_close","Z"));
                code.visitLabel(L6);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m007_completeHeader(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/jetty/AbstractGenerator;","completeHeader",new String[]{ "Lorg/mortbay/jetty/HttpFields;","Z"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            mv.visitEnd();
        }
    }
    public static void m008_completeUncheckedAddContent(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(0, new Method("Lorg/mortbay/jetty/AbstractGenerator;","completeUncheckedAddContent",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(389,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(391,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(392,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(401,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(397,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(398,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(399,L6);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_BOOLEAN,0,4,new Field("Lorg/mortbay/jetty/AbstractGenerator;","_noContent","Z"));
                code.visitJumpStmt(IF_EQZ,0,-1,L4);
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/jetty/AbstractGenerator;","_buffer","Lorg/mortbay/io/Buffer;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L3);
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/jetty/AbstractGenerator;","_buffer","Lorg/mortbay/io/Buffer;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Lorg/mortbay/io/Buffer;","clear",new String[]{ },"V"));
                code.visitLabel(L3);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_WIDE,0,4,new Field("Lorg/mortbay/jetty/AbstractGenerator;","_contentWritten","J"));
                code.visitFieldStmt(IGET_OBJECT,2,4,new Field("Lorg/mortbay/jetty/AbstractGenerator;","_buffer","Lorg/mortbay/io/Buffer;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2},new Method("Lorg/mortbay/io/Buffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitStmt2R(INT_TO_LONG,2,2);
                code.visitStmt2R(ADD_LONG_2ADDR,0,2);
                code.visitFieldStmt(IPUT_WIDE,0,4,new Field("Lorg/mortbay/jetty/AbstractGenerator;","_contentWritten","J"));
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_BOOLEAN,0,4,new Field("Lorg/mortbay/jetty/AbstractGenerator;","_head","Z"));
                code.visitJumpStmt(IF_EQZ,0,-1,L3);
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/jetty/AbstractGenerator;","_buffer","Lorg/mortbay/io/Buffer;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Lorg/mortbay/io/Buffer;","clear",new String[]{ },"V"));
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m009_flush(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/jetty/AbstractGenerator;","flush",new String[]{ },"J"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            mv.visitEnd();
        }
    }
    public static void m010_getContentBufferSize(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/AbstractGenerator;","getContentBufferSize",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(199,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,1,new Field("Lorg/mortbay/jetty/AbstractGenerator;","_contentBufferSize","I"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m011_getContentWritten(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/AbstractGenerator;","getContentWritten",new String[]{ },"J"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(480,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_WIDE,0,2,new Field("Lorg/mortbay/jetty/AbstractGenerator;","_contentWritten","J"));
                code.visitStmt1R(RETURN_WIDE,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m012_getSendServerVersion(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/AbstractGenerator;","getSendServerVersion",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(230,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_BOOLEAN,0,1,new Field("Lorg/mortbay/jetty/AbstractGenerator;","_sendServerVersion","Z"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m013_getState(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/AbstractGenerator;","getState",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(242,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,1,new Field("Lorg/mortbay/jetty/AbstractGenerator;","_state","I"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m014_getUncheckedBuffer(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/AbstractGenerator;","getUncheckedBuffer",new String[]{ },"Lorg/mortbay/io/Buffer;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(224,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/AbstractGenerator;","_buffer","Lorg/mortbay/io/Buffer;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m015_getVersion(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/AbstractGenerator;","getVersion",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(328,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,1,new Field("Lorg/mortbay/jetty/AbstractGenerator;","_version","I"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m016_increaseContentBufferSize(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/AbstractGenerator;","increaseContentBufferSize",new String[]{ "I"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"contentBufferSize");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(208,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(210,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(211,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(213,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(214,L4);
                ddv.visitStartLocal(0,L4,"nb","Lorg/mortbay/io/Buffer;",null);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(215,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(216,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(219,L7);
                ddv.visitEndLocal(0,L7);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,1,3,new Field("Lorg/mortbay/jetty/AbstractGenerator;","_contentBufferSize","I"));
                code.visitJumpStmt(IF_LE,4,1,L7);
                code.visitLabel(L1);
                code.visitFieldStmt(IPUT,4,3,new Field("Lorg/mortbay/jetty/AbstractGenerator;","_contentBufferSize","I"));
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/jetty/AbstractGenerator;","_buffer","Lorg/mortbay/io/Buffer;"));
                code.visitJumpStmt(IF_EQZ,1,-1,L7);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/jetty/AbstractGenerator;","_buffers","Lorg/mortbay/io/Buffers;"));
                code.visitFieldStmt(IGET,2,3,new Field("Lorg/mortbay/jetty/AbstractGenerator;","_contentBufferSize","I"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1,2},new Method("Lorg/mortbay/io/Buffers;","getBuffer",new String[]{ "I"},"Lorg/mortbay/io/Buffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/jetty/AbstractGenerator;","_buffer","Lorg/mortbay/io/Buffer;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1},new Method("Lorg/mortbay/io/Buffer;","put",new String[]{ "Lorg/mortbay/io/Buffer;"},"I"));
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/jetty/AbstractGenerator;","_buffers","Lorg/mortbay/io/Buffers;"));
                code.visitFieldStmt(IGET_OBJECT,2,3,new Field("Lorg/mortbay/jetty/AbstractGenerator;","_buffer","Lorg/mortbay/io/Buffer;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1,2},new Method("Lorg/mortbay/io/Buffers;","returnBuffer",new String[]{ "Lorg/mortbay/io/Buffer;"},"V"));
                code.visitLabel(L6);
                code.visitFieldStmt(IPUT_OBJECT,0,3,new Field("Lorg/mortbay/jetty/AbstractGenerator;","_buffer","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L7);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m017_isBufferFull(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/AbstractGenerator;","isBufferFull",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(406,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(408,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(409,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(410,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(413,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(410,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(413,L7);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/jetty/AbstractGenerator;","_buffer","Lorg/mortbay/io/Buffer;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L7);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/jetty/AbstractGenerator;","_buffer","Lorg/mortbay/io/Buffer;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Lorg/mortbay/io/Buffer;","space",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_NEZ,0,-1,L7);
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/jetty/AbstractGenerator;","_buffer","Lorg/mortbay/io/Buffer;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Lorg/mortbay/io/Buffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_NEZ,0,-1,L4);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/jetty/AbstractGenerator;","_buffer","Lorg/mortbay/io/Buffer;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Lorg/mortbay/io/Buffer;","isImmutable",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_NEZ,0,-1,L4);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/jetty/AbstractGenerator;","_buffer","Lorg/mortbay/io/Buffer;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Lorg/mortbay/io/Buffer;","compact",new String[]{ },"V"));
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/jetty/AbstractGenerator;","_buffer","Lorg/mortbay/io/Buffer;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Lorg/mortbay/io/Buffer;","space",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                DexLabel L8=new DexLabel();
                code.visitJumpStmt(IF_NEZ,0,-1,L8);
                code.visitStmt2R(MOVE,0,2);
                code.visitLabel(L5);
                code.visitStmt1R(RETURN,0);
                code.visitLabel(L8);
                code.visitStmt2R(MOVE,0,1);
                code.visitLabel(L6);
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitLabel(L7);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/jetty/AbstractGenerator;","_content","Lorg/mortbay/io/Buffer;"));
                DexLabel L9=new DexLabel();
                code.visitJumpStmt(IF_EQZ,0,-1,L9);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/jetty/AbstractGenerator;","_content","Lorg/mortbay/io/Buffer;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Lorg/mortbay/io/Buffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_LEZ,0,-1,L9);
                code.visitStmt2R(MOVE,0,2);
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitLabel(L9);
                code.visitStmt2R(MOVE,0,1);
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m018_isCommitted(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/AbstractGenerator;","isCommitted",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(266,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,1,new Field("Lorg/mortbay/jetty/AbstractGenerator;","_state","I"));
                DexLabel L1=new DexLabel();
                code.visitJumpStmt(IF_EQZ,0,-1,L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                DexLabel L2=new DexLabel();
                code.visitLabel(L2);
                code.visitStmt1R(RETURN,0);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m019_isComplete(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/AbstractGenerator;","isComplete",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(254,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,2,new Field("Lorg/mortbay/jetty/AbstractGenerator;","_state","I"));
                code.visitConstStmt(CONST_4,1, Integer.valueOf(4)); // int: 0x00000004  float:0.000000
                DexLabel L1=new DexLabel();
                code.visitJumpStmt(IF_NE,0,1,L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                DexLabel L2=new DexLabel();
                code.visitLabel(L2);
                code.visitStmt1R(RETURN,0);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m020_isContentWritten(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/AbstractGenerator;","isContentWritten",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(419,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_WIDE,0,4,new Field("Lorg/mortbay/jetty/AbstractGenerator;","_contentLength","J"));
                code.visitConstStmt(CONST_WIDE_16,2,Long.valueOf(0L)); // long: 0x0000000000000000  double:0.000000
                code.visitStmt3R(CMP_LONG,0,0,2);
                DexLabel L1=new DexLabel();
                code.visitJumpStmt(IF_LTZ,0,-1,L1);
                code.visitFieldStmt(IGET_WIDE,0,4,new Field("Lorg/mortbay/jetty/AbstractGenerator;","_contentWritten","J"));
                code.visitFieldStmt(IGET_WIDE,2,4,new Field("Lorg/mortbay/jetty/AbstractGenerator;","_contentLength","J"));
                code.visitStmt3R(CMP_LONG,0,0,2);
                code.visitJumpStmt(IF_LTZ,0,-1,L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                DexLabel L2=new DexLabel();
                code.visitLabel(L2);
                code.visitStmt1R(RETURN,0);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m021_isHead(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/AbstractGenerator;","isHead",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(275,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_BOOLEAN,0,1,new Field("Lorg/mortbay/jetty/AbstractGenerator;","_head","Z"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m022_isIdle(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/AbstractGenerator;","isIdle",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(260,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,1,new Field("Lorg/mortbay/jetty/AbstractGenerator;","_state","I"));
                DexLabel L1=new DexLabel();
                code.visitJumpStmt(IF_NEZ,0,-1,L1);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/AbstractGenerator;","_method","Lorg/mortbay/io/Buffer;"));
                code.visitJumpStmt(IF_NEZ,0,-1,L1);
                code.visitFieldStmt(IGET,0,1,new Field("Lorg/mortbay/jetty/AbstractGenerator;","_status","I"));
                code.visitJumpStmt(IF_NEZ,0,-1,L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                DexLabel L2=new DexLabel();
                code.visitLabel(L2);
                code.visitStmt1R(RETURN,0);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m023_isPersistent(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/AbstractGenerator;","isPersistent",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(303,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_BOOLEAN,0,1,new Field("Lorg/mortbay/jetty/AbstractGenerator;","_close","Z"));
                DexLabel L1=new DexLabel();
                code.visitJumpStmt(IF_NEZ,0,-1,L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                DexLabel L2=new DexLabel();
                code.visitLabel(L2);
                code.visitStmt1R(RETURN,0);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m024_isState(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/AbstractGenerator;","isState",new String[]{ "I"},"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"state");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(248,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,1,new Field("Lorg/mortbay/jetty/AbstractGenerator;","_state","I"));
                DexLabel L1=new DexLabel();
                code.visitJumpStmt(IF_NE,0,2,L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                DexLabel L2=new DexLabel();
                code.visitLabel(L2);
                code.visitStmt1R(RETURN,0);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m025_prepareUncheckedAddContent(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED|ACC_ABSTRACT, new Method("Lorg/mortbay/jetty/AbstractGenerator;","prepareUncheckedAddContent",new String[]{ },"I"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            mv.visitEnd();
        }
    }
    public static void m026_reset(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/AbstractGenerator;","reset",new String[]{ "Z"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"returnBuffers");
                DexLabel L5=new DexLabel();
                ddv.visitPrologue(L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(140,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(141,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(142,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(143,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(144,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(145,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(146,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(147,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(148,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(149,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(151,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(153,L17);
                ddv.visitLineNumber(155,L0);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(156,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(157,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(158,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(159,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(160,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(173,L23);
                ddv.visitLineNumber(174,L1);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(175,L24);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(176,L25);
                ddv.visitLineNumber(164,L3);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(165,L26);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(167,L27);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(169,L28);
                DexLabel L29=new DexLabel();
                ddv.visitLineNumber(170,L29);
                ddv.visitLineNumber(173,L2);
                code.visitLabel(L5);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L6);
                code.visitFieldStmt(IPUT,1,3,new Field("Lorg/mortbay/jetty/AbstractGenerator;","_state","I"));
                code.visitLabel(L7);
                code.visitFieldStmt(IPUT,1,3,new Field("Lorg/mortbay/jetty/AbstractGenerator;","_status","I"));
                code.visitLabel(L8);
                code.visitConstStmt(CONST_16,0, Integer.valueOf(11)); // int: 0x0000000b  float:0.000000
                code.visitFieldStmt(IPUT,0,3,new Field("Lorg/mortbay/jetty/AbstractGenerator;","_version","I"));
                code.visitLabel(L9);
                code.visitFieldStmt(IPUT_OBJECT,2,3,new Field("Lorg/mortbay/jetty/AbstractGenerator;","_reason","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L10);
                code.visitFieldStmt(IPUT_BOOLEAN,1,3,new Field("Lorg/mortbay/jetty/AbstractGenerator;","_last","Z"));
                code.visitLabel(L11);
                code.visitFieldStmt(IPUT_BOOLEAN,1,3,new Field("Lorg/mortbay/jetty/AbstractGenerator;","_head","Z"));
                code.visitLabel(L12);
                code.visitFieldStmt(IPUT_BOOLEAN,1,3,new Field("Lorg/mortbay/jetty/AbstractGenerator;","_noContent","Z"));
                code.visitLabel(L13);
                code.visitFieldStmt(IPUT_BOOLEAN,1,3,new Field("Lorg/mortbay/jetty/AbstractGenerator;","_close","Z"));
                code.visitLabel(L14);
                code.visitConstStmt(CONST_WIDE_16,0,Long.valueOf(0L)); // long: 0x0000000000000000  double:0.000000
                code.visitFieldStmt(IPUT_WIDE,0,3,new Field("Lorg/mortbay/jetty/AbstractGenerator;","_contentWritten","J"));
                code.visitLabel(L15);
                code.visitConstStmt(CONST_WIDE_16,0,Long.valueOf(-3L)); // long: 0xfffffffffffffffd  double:NaN
                code.visitFieldStmt(IPUT_WIDE,0,3,new Field("Lorg/mortbay/jetty/AbstractGenerator;","_contentLength","J"));
                code.visitLabel(L16);
                code.visitStmt1R(MONITOR_ENTER,3);
                code.visitLabel(L17);
                code.visitJumpStmt(IF_EQZ,4,-1,L3);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/jetty/AbstractGenerator;","_header","Lorg/mortbay/io/Buffer;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L19);
                code.visitLabel(L18);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/jetty/AbstractGenerator;","_buffers","Lorg/mortbay/io/Buffers;"));
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/jetty/AbstractGenerator;","_header","Lorg/mortbay/io/Buffer;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1},new Method("Lorg/mortbay/io/Buffers;","returnBuffer",new String[]{ "Lorg/mortbay/io/Buffer;"},"V"));
                code.visitLabel(L19);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_OBJECT,0,3,new Field("Lorg/mortbay/jetty/AbstractGenerator;","_header","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L20);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/jetty/AbstractGenerator;","_buffer","Lorg/mortbay/io/Buffer;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L22);
                code.visitLabel(L21);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/jetty/AbstractGenerator;","_buffers","Lorg/mortbay/io/Buffers;"));
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/jetty/AbstractGenerator;","_buffer","Lorg/mortbay/io/Buffer;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1},new Method("Lorg/mortbay/io/Buffers;","returnBuffer",new String[]{ "Lorg/mortbay/io/Buffer;"},"V"));
                code.visitLabel(L22);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_OBJECT,0,3,new Field("Lorg/mortbay/jetty/AbstractGenerator;","_buffer","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L23);
                code.visitStmt1R(MONITOR_EXIT,3);
                code.visitLabel(L1);
                code.visitFieldStmt(IPUT_OBJECT,2,3,new Field("Lorg/mortbay/jetty/AbstractGenerator;","_content","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L24);
                code.visitFieldStmt(IPUT_OBJECT,2,3,new Field("Lorg/mortbay/jetty/AbstractGenerator;","_method","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L25);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/jetty/AbstractGenerator;","_header","Lorg/mortbay/io/Buffer;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L27);
                code.visitLabel(L26);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/jetty/AbstractGenerator;","_header","Lorg/mortbay/io/Buffer;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Lorg/mortbay/io/Buffer;","clear",new String[]{ },"V"));
                code.visitLabel(L27);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/jetty/AbstractGenerator;","_buffer","Lorg/mortbay/io/Buffer;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L23);
                code.visitLabel(L28);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/jetty/AbstractGenerator;","_buffers","Lorg/mortbay/io/Buffers;"));
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/jetty/AbstractGenerator;","_buffer","Lorg/mortbay/io/Buffer;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1},new Method("Lorg/mortbay/io/Buffers;","returnBuffer",new String[]{ "Lorg/mortbay/io/Buffer;"},"V"));
                code.visitLabel(L29);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_OBJECT,0,3,new Field("Lorg/mortbay/jetty/AbstractGenerator;","_buffer","Lorg/mortbay/io/Buffer;"));
                code.visitJumpStmt(GOTO,-1,-1,L23);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,0);
                code.visitStmt1R(MONITOR_EXIT,3);
                code.visitLabel(L4);
                code.visitStmt1R(THROW,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m027_resetBuffer(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/AbstractGenerator;","resetBuffer",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(181,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(182,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(184,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(185,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(186,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(187,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(188,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(189,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(190,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(191,L10);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitFieldStmt(IGET,0,3,new Field("Lorg/mortbay/jetty/AbstractGenerator;","_state","I"));
                code.visitConstStmt(CONST_4,1, Integer.valueOf(3)); // int: 0x00000003  float:0.000000
                code.visitJumpStmt(IF_LT,0,1,L3);
                code.visitLabel(L2);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/IllegalStateException;");
                code.visitConstStmt(CONST_STRING,1,"Flushed");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Ljava/lang/IllegalStateException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,0);
                code.visitLabel(L3);
                code.visitFieldStmt(IPUT_BOOLEAN,2,3,new Field("Lorg/mortbay/jetty/AbstractGenerator;","_last","Z"));
                code.visitLabel(L4);
                code.visitFieldStmt(IPUT_BOOLEAN,2,3,new Field("Lorg/mortbay/jetty/AbstractGenerator;","_close","Z"));
                code.visitLabel(L5);
                code.visitConstStmt(CONST_WIDE_16,0,Long.valueOf(0L)); // long: 0x0000000000000000  double:0.000000
                code.visitFieldStmt(IPUT_WIDE,0,3,new Field("Lorg/mortbay/jetty/AbstractGenerator;","_contentWritten","J"));
                code.visitLabel(L6);
                code.visitConstStmt(CONST_WIDE_16,0,Long.valueOf(-3L)); // long: 0xfffffffffffffffd  double:NaN
                code.visitFieldStmt(IPUT_WIDE,0,3,new Field("Lorg/mortbay/jetty/AbstractGenerator;","_contentLength","J"));
                code.visitLabel(L7);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_OBJECT,0,3,new Field("Lorg/mortbay/jetty/AbstractGenerator;","_content","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L8);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/jetty/AbstractGenerator;","_buffer","Lorg/mortbay/io/Buffer;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L10);
                code.visitLabel(L9);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/jetty/AbstractGenerator;","_buffer","Lorg/mortbay/io/Buffer;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Lorg/mortbay/io/Buffer;","clear",new String[]{ },"V"));
                code.visitLabel(L10);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m028_sendError(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/AbstractGenerator;","sendError",new String[]{ "I","Ljava/lang/String;","Ljava/lang/String;","Z"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"code");
                ddv.visitParameterName(1,"reason");
                ddv.visitParameterName(2,"content");
                ddv.visitParameterName(3,"close");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(463,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(465,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(466,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(467,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(468,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(469,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(470,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(472,L7);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/AbstractGenerator;","isCommitted",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_NEZ,0,-1,L7);
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3,4},new Method("Lorg/mortbay/jetty/AbstractGenerator;","setResponse",new String[]{ "I","Ljava/lang/String;"},"V"));
                code.visitLabel(L2);
                code.visitFieldStmt(IPUT_BOOLEAN,6,2,new Field("Lorg/mortbay/jetty/AbstractGenerator;","_close","Z"));
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,0,1},new Method("Lorg/mortbay/jetty/AbstractGenerator;","completeHeader",new String[]{ "Lorg/mortbay/jetty/HttpFields;","Z"},"V"));
                code.visitLabel(L4);
                code.visitJumpStmt(IF_EQZ,5,-1,L6);
                code.visitLabel(L5);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/io/View;");
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Lorg/mortbay/io/ByteArrayBuffer;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,5},new Method("Lorg/mortbay/io/ByteArrayBuffer;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Lorg/mortbay/io/View;","<init>",new String[]{ "Lorg/mortbay/io/Buffer;"},"V"));
                code.visitConstStmt(CONST_4,1, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,0,1},new Method("Lorg/mortbay/jetty/AbstractGenerator;","addContent",new String[]{ "Lorg/mortbay/io/Buffer;","Z"},"V"));
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/AbstractGenerator;","complete",new String[]{ },"V"));
                code.visitLabel(L7);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m029_setContentLength(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/AbstractGenerator;","setContentLength",new String[]{ "J"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"value");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(281,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(282,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(285,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(284,L3);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_WIDE_16,0,Long.valueOf(0L)); // long: 0x0000000000000000  double:0.000000
                code.visitStmt3R(CMP_LONG,0,3,0);
                code.visitJumpStmt(IF_GEZ,0,-1,L3);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_WIDE_16,0,Long.valueOf(-3L)); // long: 0xfffffffffffffffd  double:NaN
                code.visitFieldStmt(IPUT_WIDE,0,2,new Field("Lorg/mortbay/jetty/AbstractGenerator;","_contentLength","J"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L3);
                code.visitFieldStmt(IPUT_WIDE,3,2,new Field("Lorg/mortbay/jetty/AbstractGenerator;","_contentLength","J"));
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m030_setHead(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/AbstractGenerator;","setHead",new String[]{ "Z"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"head");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(293,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(294,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_BOOLEAN,1,0,new Field("Lorg/mortbay/jetty/AbstractGenerator;","_head","Z"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m031_setPersistent(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/AbstractGenerator;","setPersistent",new String[]{ "Z"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"persistent");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(309,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(310,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(309,L2);
                code.visitLabel(L0);
                code.visitJumpStmt(IF_NEZ,2,-1,L2);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                DexLabel L3=new DexLabel();
                code.visitLabel(L3);
                code.visitFieldStmt(IPUT_BOOLEAN,0,1,new Field("Lorg/mortbay/jetty/AbstractGenerator;","_close","Z"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m032_setRequest(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/AbstractGenerator;","setRequest",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"method");
                ddv.visitParameterName(1,"uri");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(336,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(337,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(340,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(341,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(342,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(343,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(339,L6);
                code.visitLabel(L0);
                code.visitJumpStmt(IF_EQZ,3,-1,L1);
                code.visitConstStmt(CONST_STRING,0,"GET");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,3},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L6);
                code.visitLabel(L1);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpMethods;","GET_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/jetty/AbstractGenerator;","_method","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L2);
                code.visitFieldStmt(IPUT_OBJECT,4,2,new Field("Lorg/mortbay/jetty/AbstractGenerator;","_uri","Ljava/lang/String;"));
                code.visitLabel(L3);
                code.visitFieldStmt(IGET,0,2,new Field("Lorg/mortbay/jetty/AbstractGenerator;","_version","I"));
                code.visitConstStmt(CONST_16,1, Integer.valueOf(9)); // int: 0x00000009  float:0.000000
                code.visitJumpStmt(IF_NE,0,1,L5);
                code.visitLabel(L4);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitFieldStmt(IPUT_BOOLEAN,0,2,new Field("Lorg/mortbay/jetty/AbstractGenerator;","_noContent","Z"));
                code.visitLabel(L5);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L6);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpMethods;","CACHE","Lorg/mortbay/io/BufferCache;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,3},new Method("Lorg/mortbay/io/BufferCache;","lookup",new String[]{ "Ljava/lang/String;"},"Lorg/mortbay/io/Buffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/jetty/AbstractGenerator;","_method","Lorg/mortbay/io/Buffer;"));
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m033_setResponse(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/AbstractGenerator;","setResponse",new String[]{ "I","Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(8);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"status");
                ddv.visitParameterName(1,"reason");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(352,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(354,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(355,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(357,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(358,L4);
                ddv.visitStartLocal(2,L4,"len","I",null);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(359,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(360,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(361,L7);
                DexLabel L8=new DexLabel();
                ddv.visitStartLocal(1,L8,"i","I",null);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(363,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(364,L10);
                ddv.visitStartLocal(0,L10,"ch","C",null);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(365,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(361,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(367,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(370,L14);
                ddv.visitEndLocal(2,L14);
                ddv.visitEndLocal(1,L14);
                ddv.visitEndLocal(0,L14);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,3,5,new Field("Lorg/mortbay/jetty/AbstractGenerator;","_state","I"));
                code.visitJumpStmt(IF_EQZ,3,-1,L1);
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Ljava/lang/IllegalStateException;");
                code.visitConstStmt(CONST_STRING,4,"STATE!=START");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3,4},new Method("Ljava/lang/IllegalStateException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,3);
                code.visitLabel(L1);
                code.visitFieldStmt(IPUT,6,5,new Field("Lorg/mortbay/jetty/AbstractGenerator;","_status","I"));
                code.visitLabel(L2);
                code.visitJumpStmt(IF_EQZ,7,-1,L14);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitLabel(L4);
                code.visitFieldStmt(IGET,3,5,new Field("Lorg/mortbay/jetty/AbstractGenerator;","_headerBufferSize","I"));
                code.visitStmt2R1N(DIV_INT_LIT8,3,3,2);
                code.visitJumpStmt(IF_LE,2,3,L6);
                code.visitLabel(L5);
                code.visitFieldStmt(IGET,3,5,new Field("Lorg/mortbay/jetty/AbstractGenerator;","_headerBufferSize","I"));
                code.visitStmt2R1N(DIV_INT_LIT8,2,3,2);
                code.visitLabel(L6);
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Lorg/mortbay/io/ByteArrayBuffer;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3,2},new Method("Lorg/mortbay/io/ByteArrayBuffer;","<init>",new String[]{ "I"},"V"));
                code.visitFieldStmt(IPUT_OBJECT,3,5,new Field("Lorg/mortbay/jetty/AbstractGenerator;","_reason","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L7);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L8);
                code.visitJumpStmt(IF_GE,1,2,L14);
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,1},new Method("Ljava/lang/String;","charAt",new String[]{ "I"},"C"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitLabel(L10);
                code.visitConstStmt(CONST_16,3, Integer.valueOf(13)); // int: 0x0000000d  float:0.000000
                code.visitJumpStmt(IF_EQ,0,3,L13);
                code.visitConstStmt(CONST_16,3, Integer.valueOf(10)); // int: 0x0000000a  float:0.000000
                code.visitJumpStmt(IF_EQ,0,3,L13);
                code.visitLabel(L11);
                code.visitFieldStmt(IGET_OBJECT,3,5,new Field("Lorg/mortbay/jetty/AbstractGenerator;","_reason","Lorg/mortbay/io/Buffer;"));
                code.visitStmt2R(INT_TO_BYTE,4,0);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3,4},new Method("Lorg/mortbay/io/Buffer;","put",new String[]{ "B"},"V"));
                code.visitLabel(L12);
                code.visitStmt2R1N(ADD_INT_LIT8,1,1,1);
                code.visitJumpStmt(GOTO,-1,-1,L8);
                code.visitLabel(L13);
                code.visitFieldStmt(IGET_OBJECT,3,5,new Field("Lorg/mortbay/jetty/AbstractGenerator;","_reason","Lorg/mortbay/io/Buffer;"));
                code.visitConstStmt(CONST_16,4, Integer.valueOf(32)); // int: 0x00000020  float:0.000000
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3,4},new Method("Lorg/mortbay/io/Buffer;","put",new String[]{ "B"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L12);
                code.visitLabel(L14);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m034_setSendServerVersion(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/AbstractGenerator;","setSendServerVersion",new String[]{ "Z"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"sendServerVersion");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(236,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(237,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_BOOLEAN,1,0,new Field("Lorg/mortbay/jetty/AbstractGenerator;","_sendServerVersion","Z"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m035_setVersion(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/AbstractGenerator;","setVersion",new String[]{ "I"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"version");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(319,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(320,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(321,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(322,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(323,L4);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,2,new Field("Lorg/mortbay/jetty/AbstractGenerator;","_state","I"));
                code.visitJumpStmt(IF_EQZ,0,-1,L1);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/IllegalStateException;");
                code.visitConstStmt(CONST_STRING,1,"STATE!=START");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Ljava/lang/IllegalStateException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,0);
                code.visitLabel(L1);
                code.visitFieldStmt(IPUT,3,2,new Field("Lorg/mortbay/jetty/AbstractGenerator;","_version","I"));
                code.visitLabel(L2);
                code.visitFieldStmt(IGET,0,2,new Field("Lorg/mortbay/jetty/AbstractGenerator;","_version","I"));
                code.visitConstStmt(CONST_16,1, Integer.valueOf(9)); // int: 0x00000009  float:0.000000
                code.visitJumpStmt(IF_NE,0,1,L4);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/AbstractGenerator;","_method","Lorg/mortbay/io/Buffer;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L4);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitFieldStmt(IPUT_BOOLEAN,0,2,new Field("Lorg/mortbay/jetty/AbstractGenerator;","_noContent","Z"));
                code.visitLabel(L4);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m036_uncheckedAddContent(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(0, new Method("Lorg/mortbay/jetty/AbstractGenerator;","uncheckedAddContent",new String[]{ "I"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"b");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(383,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(384,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/AbstractGenerator;","_buffer","Lorg/mortbay/io/Buffer;"));
                code.visitStmt2R(INT_TO_BYTE,1,3);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1},new Method("Lorg/mortbay/io/Buffer;","put",new String[]{ "B"},"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
