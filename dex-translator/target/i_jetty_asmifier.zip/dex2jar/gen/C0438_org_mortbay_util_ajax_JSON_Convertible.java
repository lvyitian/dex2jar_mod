package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0438_org_mortbay_util_ajax_JSON_Convertible {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC|ACC_INTERFACE|ACC_ABSTRACT,"Lorg/mortbay/util/ajax/JSON$Convertible;","Ljava/lang/Object;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("JSON.java");
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/EnclosingClass;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("value", new DexType("Lorg/mortbay/util/ajax/JSON;"));
                av00.visitEnd();
            }
        }
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/InnerClass;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("accessFlags",  Integer.valueOf(1545));
                av00.visit("name", "Convertible");
                av00.visitEnd();
            }
        }
        m000_fromJSON(cv);
        m001_toJSON(cv);
    }
    public static void m000_fromJSON(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/util/ajax/JSON$Convertible;","fromJSON",new String[]{ "Ljava/util/Map;"},"V"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m001_toJSON(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/util/ajax/JSON$Convertible;","toJSON",new String[]{ "Lorg/mortbay/util/ajax/JSON$Output;"},"V"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
}
