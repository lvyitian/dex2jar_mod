package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0244_org_mortbay_jetty_handler_ContextHandler_SContext {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/jetty/handler/ContextHandler$SContext;","Ljava/lang/Object;",new String[]{ "Ljavax/servlet/ServletContext;"});
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("ContextHandler.java");
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/EnclosingClass;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("value", new DexType("Lorg/mortbay/jetty/handler/ContextHandler;"));
                av00.visitEnd();
            }
        }
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/InnerClass;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("accessFlags",  Integer.valueOf(1));
                av00.visit("name", "SContext");
                av00.visitEnd();
            }
        }
        f000_this$0(cv);
        m000__init_(cv);
        m001_getAttribute(cv);
        m002_getAttributeNames(cv);
        m003_getContext(cv);
        m004_getContextHandler(cv);
        m005_getContextPath(cv);
        m006_getInitParameter(cv);
        m007_getInitParameterNames(cv);
        m008_getMajorVersion(cv);
        m009_getMimeType(cv);
        m010_getMinorVersion(cv);
        m011_getNamedDispatcher(cv);
        m012_getRealPath(cv);
        m013_getRequestDispatcher(cv);
        m014_getResource(cv);
        m015_getResourceAsStream(cv);
        m016_getResourcePaths(cv);
        m017_getServerInfo(cv);
        m018_getServlet(cv);
        m019_getServletContextName(cv);
        m020_getServletNames(cv);
        m021_getServlets(cv);
        m022_log(cv);
        m023_log(cv);
        m024_log(cv);
        m025_removeAttribute(cv);
        m026_setAttribute(cv);
        m027_toString(cv);
    }
    public static void f000_this$0(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_FINAL|ACC_SYNTHETIC, new Field("Lorg/mortbay/jetty/handler/ContextHandler$SContext;","this$0","Lorg/mortbay/jetty/handler/ContextHandler;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/handler/ContextHandler$SContext;","<init>",new String[]{ "Lorg/mortbay/jetty/handler/ContextHandler;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1203,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(1204,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/handler/ContextHandler$SContext;","this$0","Lorg/mortbay/jetty/handler/ContextHandler;"));
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/Object;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001_getAttribute(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/handler/ContextHandler$SContext;","getAttribute",new String[]{ "Ljava/lang/String;"},"Ljava/lang/Object;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(1449,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(1450,L4);
                ddv.visitStartLocal(0,L4,"o","Ljava/lang/Object;",null);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(1451,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(1452,L6);
                ddv.visitLineNumber(1449,L2);
                ddv.visitEndLocal(0,L2);
                code.visitLabel(L3);
                code.visitStmt1R(MONITOR_ENTER,2);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/handler/ContextHandler$SContext;","this$0","Lorg/mortbay/jetty/handler/ContextHandler;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,3},new Method("Lorg/mortbay/jetty/handler/ContextHandler;","getAttribute",new String[]{ "Ljava/lang/String;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L4);
                code.visitJumpStmt(IF_NEZ,0,-1,L6);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/handler/ContextHandler$SContext;","this$0","Lorg/mortbay/jetty/handler/ContextHandler;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1},new Method("Lorg/mortbay/jetty/handler/ContextHandler;","access$200",new String[]{ "Lorg/mortbay/jetty/handler/ContextHandler;"},"Lorg/mortbay/util/AttributesMap;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitJumpStmt(IF_EQZ,1,-1,L6);
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/handler/ContextHandler$SContext;","this$0","Lorg/mortbay/jetty/handler/ContextHandler;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1},new Method("Lorg/mortbay/jetty/handler/ContextHandler;","access$200",new String[]{ "Lorg/mortbay/jetty/handler/ContextHandler;"},"Lorg/mortbay/util/AttributesMap;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,3},new Method("Lorg/mortbay/util/AttributesMap;","getAttribute",new String[]{ "Ljava/lang/String;"},"Ljava/lang/Object;"));
                code.visitLabel(L1);
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L6);
                code.visitStmt1R(MONITOR_EXIT,2);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitStmt1R(MONITOR_EXIT,2);
                code.visitStmt1R(THROW,1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_getAttributeNames(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/handler/ContextHandler$SContext;","getAttributeNames",new String[]{ },"Ljava/util/Enumeration;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L5=new DexLabel();
                ddv.visitPrologue(L5);
                ddv.visitLineNumber(1461,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(1462,L6);
                ddv.visitStartLocal(1,L6,"set","Ljava/util/HashSet;",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(1464,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(1465,L8);
                ddv.visitStartLocal(0,L8,"e","Ljava/util/Enumeration;",null);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(1466,L9);
                ddv.visitLineNumber(1461,L2);
                ddv.visitEndLocal(1,L2);
                ddv.visitEndLocal(0,L2);
                ddv.visitLineNumber(1468,L3);
                ddv.visitRestartLocal(1,L3);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(1469,L10);
                ddv.visitRestartLocal(0,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(1470,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(1472,L12);
                code.visitLabel(L5);
                code.visitStmt1R(MONITOR_ENTER,3);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/util/HashSet;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljava/util/HashSet;","<init>",new String[]{ },"V"));
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,2,3,new Field("Lorg/mortbay/jetty/handler/ContextHandler$SContext;","this$0","Lorg/mortbay/jetty/handler/ContextHandler;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2},new Method("Lorg/mortbay/jetty/handler/ContextHandler;","access$200",new String[]{ "Lorg/mortbay/jetty/handler/ContextHandler;"},"Lorg/mortbay/util/AttributesMap;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitJumpStmt(IF_EQZ,2,-1,L3);
                code.visitLabel(L7);
                code.visitFieldStmt(IGET_OBJECT,2,3,new Field("Lorg/mortbay/jetty/handler/ContextHandler$SContext;","this$0","Lorg/mortbay/jetty/handler/ContextHandler;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2},new Method("Lorg/mortbay/jetty/handler/ContextHandler;","access$200",new String[]{ "Lorg/mortbay/jetty/handler/ContextHandler;"},"Lorg/mortbay/util/AttributesMap;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/util/AttributesMap;","getAttributeNames",new String[]{ },"Ljava/util/Enumeration;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Ljava/util/Enumeration;","hasMoreElements",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_EQZ,2,-1,L3);
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Ljava/util/Enumeration;","nextElement",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/util/HashSet;","add",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitLabel(L1);
                code.visitJumpStmt(GOTO,-1,-1,L8);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,2);
                code.visitStmt1R(MONITOR_EXIT,3);
                code.visitStmt1R(THROW,2);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,2,3,new Field("Lorg/mortbay/jetty/handler/ContextHandler$SContext;","this$0","Lorg/mortbay/jetty/handler/ContextHandler;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2},new Method("Lorg/mortbay/jetty/handler/ContextHandler;","access$300",new String[]{ "Lorg/mortbay/jetty/handler/ContextHandler;"},"Lorg/mortbay/util/AttributesMap;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/util/AttributesMap;","getAttributeNames",new String[]{ },"Ljava/util/Enumeration;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Ljava/util/Enumeration;","hasMoreElements",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_EQZ,2,-1,L12);
                code.visitLabel(L11);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Ljava/util/Enumeration;","nextElement",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/util/HashSet;","add",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitJumpStmt(GOTO,-1,-1,L10);
                code.visitLabel(L12);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1},new Method("Ljava/util/Collections;","enumeration",new String[]{ "Ljava/util/Collection;"},"Ljava/util/Enumeration;"));
                code.visitLabel(L4);
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitStmt1R(MONITOR_EXIT,3);
                code.visitStmt1R(RETURN_OBJECT,2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_getContext(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/handler/ContextHandler$SContext;","getContext",new String[]{ "Ljava/lang/String;"},"Ljavax/servlet/ServletContext;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(9);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"uripath");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1221,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(1222,L1);
                ddv.visitStartLocal(1,L1,"context","Lorg/mortbay/jetty/handler/ContextHandler;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(1223,L2);
                ddv.visitStartLocal(3,L2,"handlers","[Lorg/mortbay/jetty/Handler;",null);
                DexLabel L3=new DexLabel();
                ddv.visitStartLocal(4,L3,"i","I",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(1225,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(1223,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(1227,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(1228,L7);
                ddv.visitStartLocal(0,L7,"ch","Lorg/mortbay/jetty/handler/ContextHandler;",null);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(1229,L8);
                ddv.visitStartLocal(2,L8,"context_path","Ljava/lang/String;",null);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(1231,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(1232,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(1236,L11);
                ddv.visitEndLocal(0,L11);
                ddv.visitEndLocal(2,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(1237,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(1238,L13);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,5,7,new Field("Lorg/mortbay/jetty/handler/ContextHandler$SContext;","this$0","Lorg/mortbay/jetty/handler/ContextHandler;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/jetty/handler/ContextHandler;","getServer",new String[]{ },"Lorg/mortbay/jetty/Server;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitConstStmt(CONST_CLASS,6,new DexType("Lorg/mortbay/jetty/handler/ContextHandler;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Lorg/mortbay/jetty/Server;","getChildHandlersByClass",new String[]{ "Ljava/lang/Class;"},"[Lorg/mortbay/jetty/Handler;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitLabel(L2);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L3);
                code.visitStmt2R(ARRAY_LENGTH,5,3);
                code.visitJumpStmt(IF_GE,4,5,L11);
                code.visitLabel(L4);
                code.visitStmt3R(AGET_OBJECT,5,3,4);
                code.visitJumpStmt(IF_EQZ,5,-1,L5);
                code.visitStmt3R(AGET_OBJECT,5,3,4);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 5},new Method("Lorg/mortbay/jetty/Handler;","isStarted",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitJumpStmt(IF_NEZ,5,-1,L6);
                code.visitLabel(L5);
                code.visitStmt2R1N(ADD_INT_LIT8,4,4,1);
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitLabel(L6);
                code.visitStmt3R(AGET_OBJECT,0,3,4);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Lorg/mortbay/jetty/handler/ContextHandler;");
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/handler/ContextHandler;","getContextPath",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,2},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitJumpStmt(IF_NEZ,5,-1,L9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,2},new Method("Ljava/lang/String;","startsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitJumpStmt(IF_EQZ,5,-1,L5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,5},new Method("Ljava/lang/String;","charAt",new String[]{ "I"},"C"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitConstStmt(CONST_16,6, Integer.valueOf(47)); // int: 0x0000002f  float:0.000000
                code.visitJumpStmt(IF_NE,5,6,L5);
                code.visitLabel(L9);
                code.visitJumpStmt(IF_EQZ,1,-1,L10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/jetty/handler/ContextHandler;","getContextPath",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitJumpStmt(IF_LE,5,6,L5);
                code.visitLabel(L10);
                code.visitStmt2R(MOVE_OBJECT,1,0);
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitLabel(L11);
                DexLabel L14=new DexLabel();
                code.visitJumpStmt(IF_EQZ,1,-1,L14);
                code.visitLabel(L12);
                code.visitFieldStmt(IGET_OBJECT,5,1,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_scontext","Lorg/mortbay/jetty/handler/ContextHandler$SContext;"));
                code.visitLabel(L13);
                code.visitStmt1R(RETURN_OBJECT,5);
                code.visitLabel(L14);
                code.visitConstStmt(CONST_4,5, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L13);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_getContextHandler(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/handler/ContextHandler$SContext;","getContextHandler",new String[]{ },"Lorg/mortbay/jetty/handler/ContextHandler;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1210,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/handler/ContextHandler$SContext;","this$0","Lorg/mortbay/jetty/handler/ContextHandler;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_getContextPath(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/handler/ContextHandler$SContext;","getContextPath",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1564,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(1565,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(1567,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/handler/ContextHandler$SContext;","this$0","Lorg/mortbay/jetty/handler/ContextHandler;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/jetty/handler/ContextHandler;","access$600",new String[]{ "Lorg/mortbay/jetty/handler/ContextHandler;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                DexLabel L3=new DexLabel();
                code.visitJumpStmt(IF_EQZ,0,-1,L3);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/handler/ContextHandler$SContext;","this$0","Lorg/mortbay/jetty/handler/ContextHandler;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/jetty/handler/ContextHandler;","access$600",new String[]{ "Lorg/mortbay/jetty/handler/ContextHandler;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitConstStmt(CONST_STRING,1,"/");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L3);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_STRING,0,"");
                code.visitLabel(L2);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/handler/ContextHandler$SContext;","this$0","Lorg/mortbay/jetty/handler/ContextHandler;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/jetty/handler/ContextHandler;","access$600",new String[]{ "Lorg/mortbay/jetty/handler/ContextHandler;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_getInitParameter(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/handler/ContextHandler$SContext;","getInitParameter",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1431,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/handler/ContextHandler$SContext;","this$0","Lorg/mortbay/jetty/handler/ContextHandler;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,2},new Method("Lorg/mortbay/jetty/handler/ContextHandler;","getInitParameter",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m007_getInitParameterNames(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/handler/ContextHandler$SContext;","getInitParameterNames",new String[]{ },"Ljava/util/Enumeration;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1440,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/handler/ContextHandler$SContext;","this$0","Lorg/mortbay/jetty/handler/ContextHandler;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/handler/ContextHandler;","getInitParameterNames",new String[]{ },"Ljava/util/Enumeration;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m008_getMajorVersion(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/handler/ContextHandler$SContext;","getMajorVersion",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1247,L0);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m009_getMimeType(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/handler/ContextHandler$SContext;","getMimeType",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"file");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(1256,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(1261,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(1258,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(1259,L4);
                ddv.visitStartLocal(0,L4,"mime","Lorg/mortbay/io/Buffer;",null);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(1260,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(1261,L6);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/jetty/handler/ContextHandler$SContext;","this$0","Lorg/mortbay/jetty/handler/ContextHandler;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1},new Method("Lorg/mortbay/jetty/handler/ContextHandler;","access$000",new String[]{ "Lorg/mortbay/jetty/handler/ContextHandler;"},"Lorg/mortbay/jetty/MimeTypes;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitJumpStmt(IF_NEZ,1,-1,L3);
                code.visitStmt2R(MOVE_OBJECT,1,2);
                code.visitLabel(L2);
                code.visitStmt1R(RETURN_OBJECT,1);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/jetty/handler/ContextHandler$SContext;","this$0","Lorg/mortbay/jetty/handler/ContextHandler;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1},new Method("Lorg/mortbay/jetty/handler/ContextHandler;","access$000",new String[]{ "Lorg/mortbay/jetty/handler/ContextHandler;"},"Lorg/mortbay/jetty/MimeTypes;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,4},new Method("Lorg/mortbay/jetty/MimeTypes;","getMimeByExtension",new String[]{ "Ljava/lang/String;"},"Lorg/mortbay/io/Buffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L4);
                DexLabel L7=new DexLabel();
                code.visitJumpStmt(IF_EQZ,0,-1,L7);
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/Object;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L7);
                code.visitStmt2R(MOVE_OBJECT,1,2);
                code.visitLabel(L6);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m010_getMinorVersion(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/handler/ContextHandler$SContext;","getMinorVersion",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1270,L0);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(5)); // int: 0x00000005  float:0.000000
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m011_getNamedDispatcher(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/handler/ContextHandler$SContext;","getNamedDispatcher",new String[]{ "Ljava/lang/String;"},"Ljavax/servlet/RequestDispatcher;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1279,L0);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m012_getRealPath(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/handler/ContextHandler$SContext;","getRealPath",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(8);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/lang/Exception;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"path");
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(1288,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(1310,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(1290,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(1291,L7);
                ddv.visitLineNumber(1297,L0);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(1298,L8);
                ddv.visitStartLocal(2,L8,"resource","Lorg/mortbay/resource/Resource;",null);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(1300,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(1301,L10);
                ddv.visitStartLocal(1,L10,"file","Ljava/io/File;",null);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(1302,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(1292,L12);
                ddv.visitEndLocal(2,L12);
                ddv.visitEndLocal(1,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(1293,L13);
                DexLabel L14=new DexLabel();
                ddv.visitRestartLocal(7,L14);
                ddv.visitLineNumber(1305,L2);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(1307,L15);
                ddv.visitStartLocal(0,L15,"e","Ljava/lang/Exception;",null);
                DexLabel L16=new DexLabel();
                ddv.visitEndLocal(0,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(1310,L17);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,5, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L4);
                code.visitJumpStmt(IF_NEZ,7,-1,L6);
                code.visitStmt2R(MOVE_OBJECT,3,5);
                code.visitLabel(L5);
                code.visitStmt1R(RETURN_OBJECT,3);
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_NEZ,3,-1,L12);
                code.visitLabel(L7);
                code.visitConstStmt(CONST_STRING,7,"/");
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,3,6,new Field("Lorg/mortbay/jetty/handler/ContextHandler$SContext;","this$0","Lorg/mortbay/jetty/handler/ContextHandler;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,7},new Method("Lorg/mortbay/jetty/handler/ContextHandler;","getResource",new String[]{ "Ljava/lang/String;"},"Lorg/mortbay/resource/Resource;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L8);
                code.visitJumpStmt(IF_EQZ,2,-1,L16);
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/resource/Resource;","getFile",new String[]{ },"Ljava/io/File;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L10);
                code.visitJumpStmt(IF_EQZ,1,-1,L16);
                code.visitLabel(L11);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/io/File;","getCanonicalPath",new String[]{ },"Ljava/lang/String;"));
                code.visitLabel(L1);
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitLabel(L12);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,3},new Method("Ljava/lang/String;","charAt",new String[]{ "I"},"C"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitConstStmt(CONST_16,4, Integer.valueOf(47)); // int: 0x0000002f  float:0.000000
                code.visitJumpStmt(IF_EQ,3,4,L0);
                code.visitLabel(L13);
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,4,"/");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,7},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitLabel(L14);
                code.visitJumpStmt(GOTO,-1,-1,L0);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,3);
                code.visitStmt2R(MOVE_OBJECT,0,3);
                code.visitLabel(L15);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/log/Log;","ignore",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitLabel(L16);
                code.visitStmt2R(MOVE_OBJECT,3,5);
                code.visitLabel(L17);
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m013_getRequestDispatcher(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/handler/ContextHandler$SContext;","getRequestDispatcher",new String[]{ "Ljava/lang/String;"},"Ljavax/servlet/RequestDispatcher;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"uriInContext");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1319,L0);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m014_getResource(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/handler/ContextHandler$SContext;","getResource",new String[]{ "Ljava/lang/String;"},"Ljava/net/URL;"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/net/MalformedURLException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"path");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1327,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(1328,L1);
                ddv.visitStartLocal(0,L1,"resource","Lorg/mortbay/resource/Resource;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(1329,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(1330,L3);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/handler/ContextHandler$SContext;","this$0","Lorg/mortbay/jetty/handler/ContextHandler;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,3},new Method("Lorg/mortbay/jetty/handler/ContextHandler;","getResource",new String[]{ "Ljava/lang/String;"},"Lorg/mortbay/resource/Resource;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L1);
                DexLabel L4=new DexLabel();
                code.visitJumpStmt(IF_EQZ,0,-1,L4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/resource/Resource;","exists",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_EQZ,1,-1,L4);
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/resource/Resource;","getURL",new String[]{ },"Ljava/net/URL;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L3);
                code.visitStmt1R(RETURN_OBJECT,1);
                code.visitLabel(L4);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m015_getResourceAsStream(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/handler/ContextHandler$SContext;","getResourceAsStream",new String[]{ "Ljava/lang/String;"},"Ljava/io/InputStream;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/lang/Exception;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"path");
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(1341,L0);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(1342,L4);
                ddv.visitStartLocal(1,L4,"url","Ljava/net/URL;",null);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(1349,L5);
                ddv.visitEndLocal(1,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(1344,L6);
                ddv.visitRestartLocal(1,L6);
                ddv.visitLineNumber(1346,L2);
                ddv.visitEndLocal(1,L2);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(1348,L7);
                ddv.visitStartLocal(0,L7,"e","Ljava/lang/Exception;",null);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(1349,L8);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Lorg/mortbay/jetty/handler/ContextHandler$SContext;","getResource",new String[]{ "Ljava/lang/String;"},"Ljava/net/URL;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L4);
                code.visitJumpStmt(IF_NEZ,1,-1,L6);
                code.visitStmt2R(MOVE_OBJECT,2,3);
                code.visitLabel(L5);
                code.visitStmt1R(RETURN_OBJECT,2);
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/net/URL;","openStream",new String[]{ },"Ljava/io/InputStream;"));
                code.visitLabel(L1);
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,2);
                code.visitStmt2R(MOVE_OBJECT,0,2);
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/log/Log;","ignore",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitStmt2R(MOVE_OBJECT,2,3);
                code.visitLabel(L8);
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m016_getResourcePaths(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/handler/ContextHandler$SContext;","getResourcePaths",new String[]{ "Ljava/lang/String;"},"Ljava/util/Set;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"path");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1359,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/handler/ContextHandler$SContext;","this$0","Lorg/mortbay/jetty/handler/ContextHandler;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,2},new Method("Lorg/mortbay/jetty/handler/ContextHandler;","getResourcePaths",new String[]{ "Ljava/lang/String;"},"Ljava/util/Set;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m017_getServerInfo(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/handler/ContextHandler$SContext;","getServerInfo",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1368,L0);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,1,"jetty/");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/jetty/Server;","getVersion",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m018_getServlet(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/handler/ContextHandler$SContext;","getServlet",new String[]{ "Ljava/lang/String;"},"Ljavax/servlet/Servlet;"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljavax/servlet/ServletException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1377,L0);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m019_getServletContextName(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/handler/ContextHandler$SContext;","getServletContextName",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1552,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(1553,L1);
                ddv.visitStartLocal(0,L1,"name","Ljava/lang/String;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(1554,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(1555,L3);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/handler/ContextHandler$SContext;","this$0","Lorg/mortbay/jetty/handler/ContextHandler;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/jetty/handler/ContextHandler;","getDisplayName",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L1);
                code.visitJumpStmt(IF_NEZ,0,-1,L3);
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/handler/ContextHandler$SContext;","this$0","Lorg/mortbay/jetty/handler/ContextHandler;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/jetty/handler/ContextHandler;","getContextPath",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L3);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m020_getServletNames(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/handler/ContextHandler$SContext;","getServletNames",new String[]{ },"Ljava/util/Enumeration;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1386,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Ljava/util/Collections;","EMPTY_LIST","Ljava/util/List;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Ljava/util/Collections;","enumeration",new String[]{ "Ljava/util/Collection;"},"Ljava/util/Enumeration;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m021_getServlets(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/handler/ContextHandler$SContext;","getServlets",new String[]{ },"Ljava/util/Enumeration;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1395,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Ljava/util/Collections;","EMPTY_LIST","Ljava/util/List;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Ljava/util/Collections;","enumeration",new String[]{ "Ljava/util/Collection;"},"Ljava/util/Enumeration;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m022_log(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/handler/ContextHandler$SContext;","log",new String[]{ "Ljava/lang/Exception;","Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"exception");
                ddv.visitParameterName(1,"msg");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1404,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(1405,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/handler/ContextHandler$SContext;","this$0","Lorg/mortbay/jetty/handler/ContextHandler;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/jetty/handler/ContextHandler;","access$100",new String[]{ "Lorg/mortbay/jetty/handler/ContextHandler;"},"Lorg/mortbay/log/Logger;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,3,2},new Method("Lorg/mortbay/log/Logger;","warn",new String[]{ "Ljava/lang/String;","Ljava/lang/Throwable;"},"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m023_log(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/handler/ContextHandler$SContext;","log",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"msg");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(1413,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(1414,L2);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/handler/ContextHandler$SContext;","this$0","Lorg/mortbay/jetty/handler/ContextHandler;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/jetty/handler/ContextHandler;","access$100",new String[]{ "Lorg/mortbay/jetty/handler/ContextHandler;"},"Lorg/mortbay/log/Logger;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,3,1,1},new Method("Lorg/mortbay/log/Logger;","info",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m024_log(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/handler/ContextHandler$SContext;","log",new String[]{ "Ljava/lang/String;","Ljava/lang/Throwable;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"message");
                ddv.visitParameterName(1,"throwable");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1422,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(1423,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/handler/ContextHandler$SContext;","this$0","Lorg/mortbay/jetty/handler/ContextHandler;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/jetty/handler/ContextHandler;","access$100",new String[]{ "Lorg/mortbay/jetty/handler/ContextHandler;"},"Lorg/mortbay/log/Logger;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,2,3},new Method("Lorg/mortbay/log/Logger;","warn",new String[]{ "Ljava/lang/String;","Ljava/lang/Throwable;"},"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m025_removeAttribute(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/handler/ContextHandler$SContext;","removeAttribute",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                DexLabel L5=new DexLabel();
                ddv.visitPrologue(L5);
                ddv.visitLineNumber(1522,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(1524,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(1527,L7);
                ddv.visitLineNumber(1544,L1);
                ddv.visitLineNumber(1531,L3);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(1532,L8);
                ddv.visitStartLocal(2,L8,"old_value","Ljava/lang/Object;",null);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(1533,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(1535,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(1537,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(1540,L12);
                ddv.visitStartLocal(0,L12,"event","Ljavax/servlet/ServletContextAttributeEvent;",null);
                DexLabel L13=new DexLabel();
                ddv.visitStartLocal(1,L13,"i","I",null);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(1541,L14);
                ddv.visitLineNumber(1540,L4);
                ddv.visitLineNumber(1522,L2);
                ddv.visitEndLocal(2,L2);
                ddv.visitEndLocal(0,L2);
                ddv.visitEndLocal(1,L2);
                code.visitLabel(L5);
                code.visitStmt1R(MONITOR_ENTER,5);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,3,5,new Field("Lorg/mortbay/jetty/handler/ContextHandler$SContext;","this$0","Lorg/mortbay/jetty/handler/ContextHandler;"));
                code.visitConstStmt(CONST_4,4, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3,6,4},new Method("Lorg/mortbay/jetty/handler/ContextHandler;","access$400",new String[]{ "Lorg/mortbay/jetty/handler/ContextHandler;","Ljava/lang/String;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,3,5,new Field("Lorg/mortbay/jetty/handler/ContextHandler$SContext;","this$0","Lorg/mortbay/jetty/handler/ContextHandler;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3},new Method("Lorg/mortbay/jetty/handler/ContextHandler;","access$200",new String[]{ "Lorg/mortbay/jetty/handler/ContextHandler;"},"Lorg/mortbay/util/AttributesMap;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitJumpStmt(IF_NEZ,3,-1,L3);
                code.visitLabel(L7);
                code.visitFieldStmt(IGET_OBJECT,3,5,new Field("Lorg/mortbay/jetty/handler/ContextHandler$SContext;","this$0","Lorg/mortbay/jetty/handler/ContextHandler;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3},new Method("Lorg/mortbay/jetty/handler/ContextHandler;","access$300",new String[]{ "Lorg/mortbay/jetty/handler/ContextHandler;"},"Lorg/mortbay/util/AttributesMap;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,6},new Method("Lorg/mortbay/util/AttributesMap;","removeAttribute",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L1);
                code.visitStmt1R(MONITOR_EXIT,5);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,3,5,new Field("Lorg/mortbay/jetty/handler/ContextHandler$SContext;","this$0","Lorg/mortbay/jetty/handler/ContextHandler;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3},new Method("Lorg/mortbay/jetty/handler/ContextHandler;","access$200",new String[]{ "Lorg/mortbay/jetty/handler/ContextHandler;"},"Lorg/mortbay/util/AttributesMap;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,6},new Method("Lorg/mortbay/util/AttributesMap;","getAttribute",new String[]{ "Ljava/lang/String;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L8);
                code.visitFieldStmt(IGET_OBJECT,3,5,new Field("Lorg/mortbay/jetty/handler/ContextHandler$SContext;","this$0","Lorg/mortbay/jetty/handler/ContextHandler;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3},new Method("Lorg/mortbay/jetty/handler/ContextHandler;","access$200",new String[]{ "Lorg/mortbay/jetty/handler/ContextHandler;"},"Lorg/mortbay/util/AttributesMap;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,6},new Method("Lorg/mortbay/util/AttributesMap;","removeAttribute",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L9);
                code.visitJumpStmt(IF_EQZ,2,-1,L1);
                code.visitLabel(L10);
                code.visitFieldStmt(IGET_OBJECT,3,5,new Field("Lorg/mortbay/jetty/handler/ContextHandler$SContext;","this$0","Lorg/mortbay/jetty/handler/ContextHandler;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3},new Method("Lorg/mortbay/jetty/handler/ContextHandler;","access$500",new String[]{ "Lorg/mortbay/jetty/handler/ContextHandler;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitJumpStmt(IF_EQZ,3,-1,L1);
                code.visitLabel(L11);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljavax/servlet/ServletContextAttributeEvent;");
                code.visitFieldStmt(IGET_OBJECT,3,5,new Field("Lorg/mortbay/jetty/handler/ContextHandler$SContext;","this$0","Lorg/mortbay/jetty/handler/ContextHandler;"));
                code.visitFieldStmt(IGET_OBJECT,3,3,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_scontext","Lorg/mortbay/jetty/handler/ContextHandler$SContext;"));
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,3,6,2},new Method("Ljavax/servlet/ServletContextAttributeEvent;","<init>",new String[]{ "Ljavax/servlet/ServletContext;","Ljava/lang/String;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L12);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L13);
                code.visitFieldStmt(IGET_OBJECT,3,5,new Field("Lorg/mortbay/jetty/handler/ContextHandler$SContext;","this$0","Lorg/mortbay/jetty/handler/ContextHandler;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3},new Method("Lorg/mortbay/jetty/handler/ContextHandler;","access$500",new String[]{ "Lorg/mortbay/jetty/handler/ContextHandler;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3},new Method("Lorg/mortbay/util/LazyList;","size",new String[]{ "Ljava/lang/Object;"},"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_GE,1,3,L1);
                code.visitLabel(L14);
                code.visitFieldStmt(IGET_OBJECT,3,5,new Field("Lorg/mortbay/jetty/handler/ContextHandler$SContext;","this$0","Lorg/mortbay/jetty/handler/ContextHandler;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3},new Method("Lorg/mortbay/jetty/handler/ContextHandler;","access$500",new String[]{ "Lorg/mortbay/jetty/handler/ContextHandler;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3,1},new Method("Lorg/mortbay/util/LazyList;","get",new String[]{ "Ljava/lang/Object;","I"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitTypeStmt(CHECK_CAST,3,-1,"Ljavax/servlet/ServletContextAttributeListener;");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3,0},new Method("Ljavax/servlet/ServletContextAttributeListener;","attributeRemoved",new String[]{ "Ljavax/servlet/ServletContextAttributeEvent;"},"V"));
                code.visitLabel(L4);
                code.visitStmt2R1N(ADD_INT_LIT8,1,1,1);
                code.visitJumpStmt(GOTO,-1,-1,L13);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,3);
                code.visitStmt1R(MONITOR_EXIT,5);
                code.visitStmt1R(THROW,3);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m026_setAttribute(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/handler/ContextHandler$SContext;","setAttribute",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(9);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L2},new String[]{ null});
                DexLabel L5=new DexLabel();
                DexLabel L6=new DexLabel();
                code.visitTryCatch(L5,L6,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                ddv.visitParameterName(1,"value");
                DexLabel L7=new DexLabel();
                ddv.visitPrologue(L7);
                ddv.visitLineNumber(1482,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(1485,L8);
                ddv.visitLineNumber(1514,L1);
                ddv.visitLineNumber(1489,L3);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(1490,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(1492,L10);
                ddv.visitStartLocal(3,L10,"old_value","Ljava/lang/Object;",null);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(1493,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(1497,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(1499,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(1502,L14);
                ddv.visitStartLocal(0,L14,"event","Ljavax/servlet/ServletContextAttributeEvent;",null);
                DexLabel L15=new DexLabel();
                ddv.visitStartLocal(1,L15,"i","I",null);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(1504,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(1506,L17);
                ddv.visitStartLocal(2,L17,"l","Ljavax/servlet/ServletContextAttributeListener;",null);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(1507,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(1502,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(1490,L20);
                ddv.visitEndLocal(3,L20);
                ddv.visitEndLocal(0,L20);
                ddv.visitEndLocal(1,L20);
                ddv.visitEndLocal(2,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(1495,L21);
                ddv.visitRestartLocal(3,L21);
                ddv.visitLineNumber(1482,L2);
                ddv.visitEndLocal(3,L2);
                DexLabel L22=new DexLabel();
                ddv.visitRestartLocal(3,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(1499,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(1508,L24);
                ddv.visitRestartLocal(0,L24);
                ddv.visitRestartLocal(1,L24);
                ddv.visitRestartLocal(2,L24);
                ddv.visitLineNumber(1509,L5);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(1511,L25);
                code.visitLabel(L7);
                code.visitStmt1R(MONITOR_ENTER,6);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,4,6,new Field("Lorg/mortbay/jetty/handler/ContextHandler$SContext;","this$0","Lorg/mortbay/jetty/handler/ContextHandler;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 4},new Method("Lorg/mortbay/jetty/handler/ContextHandler;","access$200",new String[]{ "Lorg/mortbay/jetty/handler/ContextHandler;"},"Lorg/mortbay/util/AttributesMap;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitJumpStmt(IF_NEZ,4,-1,L3);
                code.visitLabel(L8);
                code.visitFieldStmt(IGET_OBJECT,4,6,new Field("Lorg/mortbay/jetty/handler/ContextHandler$SContext;","this$0","Lorg/mortbay/jetty/handler/ContextHandler;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,7,8},new Method("Lorg/mortbay/jetty/handler/ContextHandler;","setAttribute",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L1);
                code.visitStmt1R(MONITOR_EXIT,6);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,4,6,new Field("Lorg/mortbay/jetty/handler/ContextHandler$SContext;","this$0","Lorg/mortbay/jetty/handler/ContextHandler;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 4,7,8},new Method("Lorg/mortbay/jetty/handler/ContextHandler;","access$400",new String[]{ "Lorg/mortbay/jetty/handler/ContextHandler;","Ljava/lang/String;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L9);
                code.visitFieldStmt(IGET_OBJECT,4,6,new Field("Lorg/mortbay/jetty/handler/ContextHandler$SContext;","this$0","Lorg/mortbay/jetty/handler/ContextHandler;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 4},new Method("Lorg/mortbay/jetty/handler/ContextHandler;","access$200",new String[]{ "Lorg/mortbay/jetty/handler/ContextHandler;"},"Lorg/mortbay/util/AttributesMap;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitJumpStmt(IF_NEZ,4,-1,L20);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt2R(MOVE_OBJECT,3,4);
                code.visitLabel(L10);
                code.visitJumpStmt(IF_NEZ,8,-1,L21);
                code.visitLabel(L11);
                code.visitFieldStmt(IGET_OBJECT,4,6,new Field("Lorg/mortbay/jetty/handler/ContextHandler$SContext;","this$0","Lorg/mortbay/jetty/handler/ContextHandler;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 4},new Method("Lorg/mortbay/jetty/handler/ContextHandler;","access$200",new String[]{ "Lorg/mortbay/jetty/handler/ContextHandler;"},"Lorg/mortbay/util/AttributesMap;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,7},new Method("Lorg/mortbay/util/AttributesMap;","removeAttribute",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L12);
                code.visitFieldStmt(IGET_OBJECT,4,6,new Field("Lorg/mortbay/jetty/handler/ContextHandler$SContext;","this$0","Lorg/mortbay/jetty/handler/ContextHandler;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 4},new Method("Lorg/mortbay/jetty/handler/ContextHandler;","access$500",new String[]{ "Lorg/mortbay/jetty/handler/ContextHandler;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitJumpStmt(IF_EQZ,4,-1,L1);
                code.visitLabel(L13);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljavax/servlet/ServletContextAttributeEvent;");
                code.visitFieldStmt(IGET_OBJECT,4,6,new Field("Lorg/mortbay/jetty/handler/ContextHandler$SContext;","this$0","Lorg/mortbay/jetty/handler/ContextHandler;"));
                code.visitFieldStmt(IGET_OBJECT,4,4,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_scontext","Lorg/mortbay/jetty/handler/ContextHandler$SContext;"));
                code.visitJumpStmt(IF_NEZ,3,-1,L22);
                code.visitStmt2R(MOVE_OBJECT,5,8);
                DexLabel L26=new DexLabel();
                code.visitLabel(L26);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,4,7,5},new Method("Ljavax/servlet/ServletContextAttributeEvent;","<init>",new String[]{ "Ljavax/servlet/ServletContext;","Ljava/lang/String;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L14);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L15);
                code.visitFieldStmt(IGET_OBJECT,4,6,new Field("Lorg/mortbay/jetty/handler/ContextHandler$SContext;","this$0","Lorg/mortbay/jetty/handler/ContextHandler;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 4},new Method("Lorg/mortbay/jetty/handler/ContextHandler;","access$500",new String[]{ "Lorg/mortbay/jetty/handler/ContextHandler;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 4},new Method("Lorg/mortbay/util/LazyList;","size",new String[]{ "Ljava/lang/Object;"},"I"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitJumpStmt(IF_GE,1,4,L1);
                code.visitLabel(L16);
                code.visitFieldStmt(IGET_OBJECT,4,6,new Field("Lorg/mortbay/jetty/handler/ContextHandler$SContext;","this$0","Lorg/mortbay/jetty/handler/ContextHandler;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 4},new Method("Lorg/mortbay/jetty/handler/ContextHandler;","access$500",new String[]{ "Lorg/mortbay/jetty/handler/ContextHandler;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 4,1},new Method("Lorg/mortbay/util/LazyList;","get",new String[]{ "Ljava/lang/Object;","I"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitTypeStmt(CHECK_CAST,2,-1,"Ljavax/servlet/ServletContextAttributeListener;");
                code.visitLabel(L17);
                code.visitJumpStmt(IF_NEZ,3,-1,L24);
                code.visitLabel(L18);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2,0},new Method("Ljavax/servlet/ServletContextAttributeListener;","attributeAdded",new String[]{ "Ljavax/servlet/ServletContextAttributeEvent;"},"V"));
                code.visitLabel(L19);
                code.visitStmt2R1N(ADD_INT_LIT8,1,1,1);
                code.visitJumpStmt(GOTO,-1,-1,L15);
                code.visitLabel(L20);
                code.visitFieldStmt(IGET_OBJECT,4,6,new Field("Lorg/mortbay/jetty/handler/ContextHandler$SContext;","this$0","Lorg/mortbay/jetty/handler/ContextHandler;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 4},new Method("Lorg/mortbay/jetty/handler/ContextHandler;","access$200",new String[]{ "Lorg/mortbay/jetty/handler/ContextHandler;"},"Lorg/mortbay/util/AttributesMap;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,7},new Method("Lorg/mortbay/util/AttributesMap;","getAttribute",new String[]{ "Ljava/lang/String;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitStmt2R(MOVE_OBJECT,3,4);
                code.visitJumpStmt(GOTO,-1,-1,L10);
                code.visitLabel(L21);
                code.visitFieldStmt(IGET_OBJECT,4,6,new Field("Lorg/mortbay/jetty/handler/ContextHandler$SContext;","this$0","Lorg/mortbay/jetty/handler/ContextHandler;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 4},new Method("Lorg/mortbay/jetty/handler/ContextHandler;","access$200",new String[]{ "Lorg/mortbay/jetty/handler/ContextHandler;"},"Lorg/mortbay/util/AttributesMap;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,7,8},new Method("Lorg/mortbay/util/AttributesMap;","setAttribute",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L4);
                code.visitJumpStmt(GOTO,-1,-1,L12);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,4);
                code.visitStmt1R(MONITOR_EXIT,6);
                code.visitStmt1R(THROW,4);
                code.visitLabel(L22);
                code.visitStmt2R(MOVE_OBJECT,5,3);
                code.visitLabel(L23);
                code.visitJumpStmt(GOTO,-1,-1,L26);
                code.visitLabel(L24);
                code.visitJumpStmt(IF_NEZ,8,-1,L25);
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2,0},new Method("Ljavax/servlet/ServletContextAttributeListener;","attributeRemoved",new String[]{ "Ljavax/servlet/ServletContextAttributeEvent;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L19);
                code.visitLabel(L25);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2,0},new Method("Ljavax/servlet/ServletContextAttributeListener;","attributeReplaced",new String[]{ "Ljavax/servlet/ServletContextAttributeEvent;"},"V"));
                code.visitLabel(L6);
                code.visitJumpStmt(GOTO,-1,-1,L19);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m027_toString(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/handler/ContextHandler$SContext;","toString",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1573,L0);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,1,"ServletContext@");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/lang/Object;","hashCode",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1},new Method("Ljava/lang/Integer;","toHexString",new String[]{ "I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitConstStmt(CONST_STRING,1,"{");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/jetty/handler/ContextHandler$SContext;","getContextPath",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitConstStmt(CONST_STRING,2,"");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,1);
                DexLabel L1=new DexLabel();
                code.visitJumpStmt(IF_EQZ,1,-1,L1);
                code.visitConstStmt(CONST_STRING,1,"/");
                DexLabel L2=new DexLabel();
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitConstStmt(CONST_STRING,1,",");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/jetty/handler/ContextHandler$SContext;","this$0","Lorg/mortbay/jetty/handler/ContextHandler;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/jetty/handler/ContextHandler;","getBaseResource",new String[]{ },"Lorg/mortbay/resource/Resource;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitConstStmt(CONST_STRING,1,"}");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/jetty/handler/ContextHandler$SContext;","getContextPath",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
