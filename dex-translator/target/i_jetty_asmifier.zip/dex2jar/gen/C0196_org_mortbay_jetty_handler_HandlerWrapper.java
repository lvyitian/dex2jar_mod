package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0196_org_mortbay_jetty_handler_HandlerWrapper {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/jetty/handler/HandlerWrapper;","Lorg/mortbay/jetty/handler/AbstractHandlerContainer;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("HandlerWrapper.java");
        f000__handler(cv);
        m000__init_(cv);
        m001_addHandler(cv);
        m002_doStart(cv);
        m003_doStop(cv);
        m004_expandChildren(cv);
        m005_getHandler(cv);
        m006_handle(cv);
        m007_removeHandler(cv);
        m008_setHandler(cv);
        m009_setServer(cv);
    }
    public static void f000__handler(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/handler/HandlerWrapper;","_handler","Lorg/mortbay/jetty/Handler;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/handler/HandlerWrapper;","<init>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(44,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(45,L1);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Lorg/mortbay/jetty/handler/AbstractHandlerContainer;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001_addHandler(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/handler/HandlerWrapper;","addHandler",new String[]{ "Lorg/mortbay/jetty/Handler;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"handler");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(102,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(103,L1);
                ddv.visitStartLocal(0,L1,"old","Lorg/mortbay/jetty/Handler;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(104,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(105,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(106,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(107,L5);
                DexLabel L6=new DexLabel();
                ddv.visitEndLocal(4,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(108,L7);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/jetty/handler/HandlerWrapper;","getHandler",new String[]{ },"Lorg/mortbay/jetty/Handler;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L1);
                code.visitJumpStmt(IF_EQZ,0,-1,L3);
                code.visitTypeStmt(INSTANCE_OF,1,4,"Lorg/mortbay/jetty/HandlerContainer;");
                code.visitJumpStmt(IF_NEZ,1,-1,L3);
                code.visitLabel(L2);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/lang/IllegalArgumentException;");
                code.visitConstStmt(CONST_STRING,2,"Cannot add");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,2},new Method("Ljava/lang/IllegalArgumentException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,1);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Lorg/mortbay/jetty/handler/HandlerWrapper;","setHandler",new String[]{ "Lorg/mortbay/jetty/Handler;"},"V"));
                code.visitLabel(L4);
                code.visitJumpStmt(IF_EQZ,0,-1,L7);
                code.visitLabel(L5);
                code.visitTypeStmt(CHECK_CAST,4,-1,"Lorg/mortbay/jetty/HandlerContainer;");
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 4,0},new Method("Lorg/mortbay/jetty/HandlerContainer;","addHandler",new String[]{ "Lorg/mortbay/jetty/Handler;"},"V"));
                code.visitLabel(L7);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_doStart(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/handler/HandlerWrapper;","doStart",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/Exception;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(129,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(130,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(131,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(132,L3);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/handler/HandlerWrapper;","_handler","Lorg/mortbay/jetty/Handler;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L2);
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/handler/HandlerWrapper;","_handler","Lorg/mortbay/jetty/Handler;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Lorg/mortbay/jetty/Handler;","start",new String[]{ },"V"));
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 1},new Method("Lorg/mortbay/jetty/handler/AbstractHandlerContainer;","doStart",new String[]{ },"V"));
                code.visitLabel(L3);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_doStop(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/handler/HandlerWrapper;","doStop",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/Exception;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(140,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(141,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(142,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(143,L3);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 1},new Method("Lorg/mortbay/jetty/handler/AbstractHandlerContainer;","doStop",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/handler/HandlerWrapper;","_handler","Lorg/mortbay/jetty/Handler;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L3);
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/handler/HandlerWrapper;","_handler","Lorg/mortbay/jetty/Handler;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Lorg/mortbay/jetty/Handler;","stop",new String[]{ },"V"));
                code.visitLabel(L3);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_expandChildren(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/handler/HandlerWrapper;","expandChildren",new String[]{ "Ljava/lang/Object;","Ljava/lang/Class;"},"Ljava/lang/Object;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"list");
                ddv.visitParameterName(1,"byClass");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(175,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/handler/HandlerWrapper;","_handler","Lorg/mortbay/jetty/Handler;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,0,2,3},new Method("Lorg/mortbay/jetty/handler/HandlerWrapper;","expandHandler",new String[]{ "Lorg/mortbay/jetty/Handler;","Ljava/lang/Object;","Ljava/lang/Class;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_getHandler(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/handler/HandlerWrapper;","getHandler",new String[]{ },"Lorg/mortbay/jetty/Handler;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(53,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/handler/HandlerWrapper;","_handler","Lorg/mortbay/jetty/Handler;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_handle(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/handler/HandlerWrapper;","handle",new String[]{ "Ljava/lang/String;","Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;","I"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visit(null, new DexType("Ljavax/servlet/ServletException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"target");
                ddv.visitParameterName(1,"request");
                ddv.visitParameterName(2,"response");
                ddv.visitParameterName(3,"dispatch");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(151,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(152,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(153,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/handler/HandlerWrapper;","_handler","Lorg/mortbay/jetty/Handler;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/jetty/handler/HandlerWrapper;","isStarted",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L2);
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/handler/HandlerWrapper;","_handler","Lorg/mortbay/jetty/Handler;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,2,3,4,5},new Method("Lorg/mortbay/jetty/Handler;","handle",new String[]{ "Ljava/lang/String;","Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;","I"},"V"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m007_removeHandler(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/handler/HandlerWrapper;","removeHandler",new String[]{ "Lorg/mortbay/jetty/Handler;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"handler");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(113,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(114,L1);
                ddv.visitStartLocal(0,L1,"old","Lorg/mortbay/jetty/Handler;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(115,L2);
                DexLabel L3=new DexLabel();
                ddv.visitEndLocal(0,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(120,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(116,L5);
                ddv.visitRestartLocal(0,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(117,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(119,L7);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/jetty/handler/HandlerWrapper;","getHandler",new String[]{ },"Lorg/mortbay/jetty/Handler;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L1);
                code.visitJumpStmt(IF_EQZ,0,-1,L5);
                code.visitTypeStmt(INSTANCE_OF,1,0,"Lorg/mortbay/jetty/HandlerContainer;");
                code.visitJumpStmt(IF_EQZ,1,-1,L5);
                code.visitLabel(L2);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Lorg/mortbay/jetty/HandlerContainer;");
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,4},new Method("Lorg/mortbay/jetty/HandlerContainer;","removeHandler",new String[]{ "Lorg/mortbay/jetty/Handler;"},"V"));
                code.visitLabel(L4);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L5);
                code.visitJumpStmt(IF_EQZ,0,-1,L7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,0},new Method("Ljava/lang/Object;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_EQZ,1,-1,L7);
                code.visitLabel(L6);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,1},new Method("Lorg/mortbay/jetty/handler/HandlerWrapper;","setHandler",new String[]{ "Lorg/mortbay/jetty/Handler;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitLabel(L7);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/lang/IllegalStateException;");
                code.visitConstStmt(CONST_STRING,2,"Cannot remove");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,2},new Method("Ljava/lang/IllegalStateException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m008_setHandler(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/handler/HandlerWrapper;","setHandler",new String[]{ "Lorg/mortbay/jetty/Handler;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/lang/Exception;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"handler");
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(64,L0);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(66,L3);
                ddv.visitStartLocal(2,L3,"old_handler","Lorg/mortbay/jetty/Handler;",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(67,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(69,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(71,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(74,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(76,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(78,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(79,L10);
                ddv.visitLineNumber(88,L1);
                ddv.visitLineNumber(82,L2);
                ddv.visitEndLocal(2,L2);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(84,L11);
                ddv.visitStartLocal(0,L11,"e","Ljava/lang/Exception;",null);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(85,L12);
                ddv.visitStartLocal(1,L12,"ise","Ljava/lang/IllegalStateException;",null);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(86,L13);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/jetty/handler/HandlerWrapper;","_handler","Lorg/mortbay/jetty/Handler;"));
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/jetty/handler/HandlerWrapper;","getServer",new String[]{ },"Lorg/mortbay/jetty/Server;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitJumpStmt(IF_EQZ,3,-1,L5);
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/jetty/handler/HandlerWrapper;","getServer",new String[]{ },"Lorg/mortbay/jetty/Server;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/jetty/Server;","getContainer",new String[]{ },"Lorg/mortbay/component/Container;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitConstStmt(CONST_STRING,4,"handler");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,5,2,6,4},new Method("Lorg/mortbay/component/Container;","update",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;","Ljava/lang/Object;","Ljava/lang/String;"},"V"));
                code.visitLabel(L5);
                code.visitJumpStmt(IF_EQZ,6,-1,L7);
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/jetty/handler/HandlerWrapper;","getServer",new String[]{ },"Lorg/mortbay/jetty/Server;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 6,3},new Method("Lorg/mortbay/jetty/Handler;","setServer",new String[]{ "Lorg/mortbay/jetty/Server;"},"V"));
                code.visitLabel(L7);
                code.visitFieldStmt(IPUT_OBJECT,6,5,new Field("Lorg/mortbay/jetty/handler/HandlerWrapper;","_handler","Lorg/mortbay/jetty/Handler;"));
                code.visitLabel(L8);
                code.visitJumpStmt(IF_EQZ,2,-1,L1);
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2},new Method("Lorg/mortbay/jetty/Handler;","isStarted",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_EQZ,3,-1,L1);
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2},new Method("Lorg/mortbay/jetty/Handler;","stop",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,3);
                code.visitStmt2R(MOVE_OBJECT,0,3);
                code.visitLabel(L11);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/lang/IllegalStateException;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljava/lang/IllegalStateException;","<init>",new String[]{ },"V"));
                code.visitLabel(L12);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,0},new Method("Ljava/lang/IllegalStateException;","initCause",new String[]{ "Ljava/lang/Throwable;"},"Ljava/lang/Throwable;"));
                code.visitLabel(L13);
                code.visitStmt1R(THROW,1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m009_setServer(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/handler/HandlerWrapper;","setServer",new String[]{ "Lorg/mortbay/jetty/Server;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(8);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"server");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(159,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(161,L1);
                ddv.visitStartLocal(1,L1,"old_server","Lorg/mortbay/jetty/Server;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(163,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(164,L3);
                ddv.visitStartLocal(0,L3,"h","Lorg/mortbay/jetty/Handler;",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(165,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(167,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(168,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(169,L7);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/handler/HandlerWrapper;","getServer",new String[]{ },"Lorg/mortbay/jetty/Server;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 6,7},new Method("Lorg/mortbay/jetty/handler/AbstractHandlerContainer;","setServer",new String[]{ "Lorg/mortbay/jetty/Server;"},"V"));
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/handler/HandlerWrapper;","getHandler",new String[]{ },"Lorg/mortbay/jetty/Handler;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L3);
                code.visitJumpStmt(IF_EQZ,0,-1,L5);
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,7},new Method("Lorg/mortbay/jetty/Handler;","setServer",new String[]{ "Lorg/mortbay/jetty/Server;"},"V"));
                code.visitLabel(L5);
                code.visitJumpStmt(IF_EQZ,7,-1,L7);
                code.visitJumpStmt(IF_EQ,7,1,L7);
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Lorg/mortbay/jetty/Server;","getContainer",new String[]{ },"Lorg/mortbay/component/Container;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IGET_OBJECT,4,6,new Field("Lorg/mortbay/jetty/handler/HandlerWrapper;","_handler","Lorg/mortbay/jetty/Handler;"));
                code.visitConstStmt(CONST_STRING,5,"handler");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,6,3,4,5},new Method("Lorg/mortbay/component/Container;","update",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;","Ljava/lang/Object;","Ljava/lang/String;"},"V"));
                code.visitLabel(L7);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
