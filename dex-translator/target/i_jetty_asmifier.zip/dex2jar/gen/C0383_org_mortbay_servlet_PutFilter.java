package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0383_org_mortbay_servlet_PutFilter {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/servlet/PutFilter;","Ljava/lang/Object;",new String[]{ "Ljavax/servlet/Filter;"});
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("PutFilter.java");
        f000___DELETE(cv);
        f001___MOVE(cv);
        f002___OPTIONS(cv);
        f003___PUT(cv);
        f004__baseURI(cv);
        f005__context(cv);
        f006__delAllowed(cv);
        f007__hidden(cv);
        f008__operations(cv);
        m000__init_(cv);
        m001_getInitBoolean(cv);
        m002_isHidden(cv);
        m003_destroy(cv);
        m004_doFilter(cv);
        m005_handleDelete(cv);
        m006_handleMove(cv);
        m007_handleOptions(cv);
        m008_handlePut(cv);
        m009_init(cv);
        m010_passConditionalHeaders(cv);
    }
    public static void f000___DELETE(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/servlet/PutFilter;","__DELETE","Ljava/lang/String;"), "DELETE");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001___MOVE(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/servlet/PutFilter;","__MOVE","Ljava/lang/String;"), "MOVE");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002___OPTIONS(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/servlet/PutFilter;","__OPTIONS","Ljava/lang/String;"), "OPTIONS");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003___PUT(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/servlet/PutFilter;","__PUT","Ljava/lang/String;"), "PUT");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f004__baseURI(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/servlet/PutFilter;","_baseURI","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f005__context(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/servlet/PutFilter;","_context","Ljavax/servlet/ServletContext;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f006__delAllowed(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/servlet/PutFilter;","_delAllowed","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f007__hidden(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/servlet/PutFilter;","_hidden","Ljava/util/concurrent/ConcurrentMap;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f008__operations(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/servlet/PutFilter;","_operations","Ljava/util/Set;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/servlet/PutFilter;","<init>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(56,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(63,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(64,L2);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljava/lang/Object;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/util/HashSet;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/util/HashSet;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/servlet/PutFilter;","_operations","Ljava/util/Set;"));
                code.visitLabel(L2);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/util/concurrent/ConcurrentHashMap;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/util/concurrent/ConcurrentHashMap;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/servlet/PutFilter;","_hidden","Ljava/util/concurrent/ConcurrentMap;"));
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001_getInitBoolean(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PRIVATE, new Method("Lorg/mortbay/servlet/PutFilter;","getInitBoolean",new String[]{ "Ljavax/servlet/FilterConfig;","Ljava/lang/String;"},"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"config");
                ddv.visitParameterName(1,"name");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(102,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(103,L1);
                ddv.visitStartLocal(0,L1,"value","Ljava/lang/String;",null);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3,4},new Method("Ljavax/servlet/FilterConfig;","getInitParameter",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L1);
                DexLabel L2=new DexLabel();
                code.visitJumpStmt(IF_EQZ,0,-1,L2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_LEZ,1,-1,L2);
                code.visitConstStmt(CONST_STRING,1,"t");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/String;","startsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,1);
                DexLabel L3=new DexLabel();
                code.visitJumpStmt(IF_NEZ,1,-1,L3);
                code.visitConstStmt(CONST_STRING,1,"T");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/String;","startsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_NEZ,1,-1,L3);
                code.visitConstStmt(CONST_STRING,1,"y");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/String;","startsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_NEZ,1,-1,L3);
                code.visitConstStmt(CONST_STRING,1,"Y");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/String;","startsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_NEZ,1,-1,L3);
                code.visitConstStmt(CONST_STRING,1,"1");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/String;","startsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_EQZ,1,-1,L2);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                DexLabel L4=new DexLabel();
                code.visitLabel(L4);
                code.visitStmt1R(RETURN,1);
                code.visitLabel(L2);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_isHidden(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PRIVATE, new Method("Lorg/mortbay/servlet/PutFilter;","isHidden",new String[]{ "Ljava/lang/String;"},"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"pathInContext");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(165,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/servlet/PutFilter;","_hidden","Ljava/util/concurrent/ConcurrentMap;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,2},new Method("Ljava/util/concurrent/ConcurrentMap;","containsKey",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_destroy(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/servlet/PutFilter;","destroy",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(171,L0);
                code.visitLabel(L0);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_doFilter(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/servlet/PutFilter;","doFilter",new String[]{ "Ljavax/servlet/ServletRequest;","Ljavax/servlet/ServletResponse;","Ljavax/servlet/FilterChain;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visit(null, new DexType("Ljavax/servlet/ServletException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(23);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/lang/Exception;"});
                DexLabel L3=new DexLabel();
                code.visitTryCatch(L1,L3,new DexLabel[]{L3},new String[]{ "Ljava/lang/Exception;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"req");
                ddv.visitParameterName(1,"res");
                ddv.visitParameterName(2,"chain");
                DexLabel L4=new DexLabel();
                ddv.visitPrologue(L4);
                ddv.visitLineNumber(110,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(111,L5);
                ddv.visitStartLocal(13,L5,"request","Ljavax/servlet/http/HttpServletRequest;",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(113,L6);
                ddv.visitStartLocal(15,L6,"response","Ljavax/servlet/http/HttpServletResponse;",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(114,L7);
                ddv.visitStartLocal(16,L7,"servletPath","Ljava/lang/String;",null);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(115,L8);
                ddv.visitStartLocal(12,L8,"pathInfo","Ljava/lang/String;",null);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(117,L9);
                ddv.visitStartLocal(11,L9,"pathInContext","Ljava/lang/String;",null);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(119,L10);
                ddv.visitStartLocal(14,L10,"resource","Ljava/lang/String;",null);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(120,L11);
                ddv.visitStartLocal(9,L11,"method","Ljava/lang/String;",null);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(122,L12);
                ddv.visitStartLocal(10,L12,"op","Z",null);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(124,L13);
                ddv.visitLineNumber(127,L0);
                ddv.visitStartLocal(7,L0,"file","Ljava/io/File;",null);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(128,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(160,L15);
                ddv.visitEndLocal(7,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(131,L16);
                ddv.visitRestartLocal(7,L16);
                ddv.visitLineNumber(132,L1);
                ddv.visitStartLocal(8,L1,"file","Ljava/io/File;",null);
                DexLabel L17=new DexLabel();
                ddv.visitEndLocal(7,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(133,L18);
                ddv.visitStartLocal(6,L18,"exists","Z",null);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(136,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(137,L20);
                DexLabel L21=new DexLabel();
                ddv.visitRestartLocal(7,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(138,L22);
                ddv.visitEndLocal(7,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(139,L23);
                DexLabel L24=new DexLabel();
                ddv.visitRestartLocal(7,L24);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(140,L25);
                ddv.visitEndLocal(7,L25);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(141,L26);
                DexLabel L27=new DexLabel();
                ddv.visitRestartLocal(7,L27);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(143,L28);
                ddv.visitEndLocal(7,L28);
                ddv.visitLineNumber(146,L3);
                ddv.visitEndLocal(6,L3);
                DexLabel L29=new DexLabel();
                ddv.visitLineNumber(148,L29);
                ddv.visitEndLocal(8,L29);
                ddv.visitRestartLocal(7,L29);
                ddv.visitStartLocal(5,L29,"e","Ljava/lang/Exception;",null);
                DexLabel L30=new DexLabel();
                ddv.visitLineNumber(149,L30);
                DexLabel L31=new DexLabel();
                ddv.visitLineNumber(154,L31);
                ddv.visitEndLocal(7,L31);
                ddv.visitEndLocal(5,L31);
                DexLabel L32=new DexLabel();
                ddv.visitLineNumber(155,L32);
                DexLabel L33=new DexLabel();
                ddv.visitLineNumber(157,L33);
                ddv.visitLineNumber(146,L2);
                ddv.visitRestartLocal(7,L2);
                code.visitLabel(L4);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,20);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Ljavax/servlet/http/HttpServletRequest;");
                code.visitStmt2R(MOVE_OBJECT,13,0);
                code.visitLabel(L5);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Ljavax/servlet/http/HttpServletResponse;");
                code.visitStmt2R(MOVE_OBJECT,15,0);
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 13},new Method("Ljavax/servlet/http/HttpServletRequest;","getServletPath",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,16);
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 13},new Method("Ljavax/servlet/http/HttpServletRequest;","getPathInfo",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,12);
                code.visitLabel(L8);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,16);
                code.visitStmt2R(MOVE_OBJECT,1,12);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,1},new Method("Lorg/mortbay/util/URIUtil;","addPaths",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,11);
                code.visitLabel(L9);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,19);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/servlet/PutFilter;","_baseURI","Ljava/lang/String;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,17,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,17);
                code.visitStmt2R(MOVE_OBJECT,1,11);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,1},new Method("Lorg/mortbay/util/URIUtil;","addPaths",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,14);
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 13},new Method("Ljavax/servlet/http/HttpServletRequest;","getMethod",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitLabel(L11);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,19);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/servlet/PutFilter;","_operations","Ljava/util/Set;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,17,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,17);
                code.visitStmt2R(MOVE_OBJECT,1,9);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1},new Method("Ljava/util/Set;","contains",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,10);
                code.visitLabel(L12);
                code.visitJumpStmt(IF_EQZ,10,-1,L31);
                code.visitLabel(L13);
                code.visitConstStmt(CONST_4,7, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L0);
                code.visitConstStmt(CONST_STRING,17,"OPTIONS");
                code.visitStmt2R(MOVE_OBJECT,0,9);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,17);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,17);
                code.visitJumpStmt(IF_EQZ,17,-1,L16);
                code.visitLabel(L14);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,19);
                code.visitStmt2R(MOVE_OBJECT,1,13);
                code.visitStmt2R(MOVE_OBJECT,2,15);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Lorg/mortbay/servlet/PutFilter;","handleOptions",new String[]{ "Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;"},"V"));
                code.visitLabel(L15);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L16);
                code.visitTypeStmt(NEW_INSTANCE,8,-1,"Ljava/io/File;");
                code.visitTypeStmt(NEW_INSTANCE,17,-1,"Ljava/net/URI;");
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,17);
                code.visitStmt2R(MOVE_OBJECT,1,14);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Ljava/net/URI;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt2R(MOVE_OBJECT,0,8);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,17);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Ljava/io/File;","<init>",new String[]{ "Ljava/net/URI;"},"V"));
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Ljava/io/File;","exists",new String[]{ },"Z"));
                code.visitLabel(L17);
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitLabel(L18);
                code.visitJumpStmt(IF_EQZ,6,-1,L19);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,19);
                code.visitStmt2R(MOVE_OBJECT,1,13);
                code.visitStmt2R(MOVE_OBJECT,2,15);
                code.visitStmt2R(MOVE_OBJECT,3,8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2,3},new Method("Lorg/mortbay/servlet/PutFilter;","passConditionalHeaders",new String[]{ "Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;","Ljava/io/File;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,17);
                code.visitJumpStmt(IF_EQZ,17,-1,L15);
                code.visitLabel(L19);
                code.visitConstStmt(CONST_STRING,17,"PUT");
                code.visitStmt2R(MOVE_OBJECT,0,9);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,17);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,17);
                code.visitJumpStmt(IF_EQZ,17,-1,L22);
                code.visitLabel(L20);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,19);
                code.visitStmt2R(MOVE_OBJECT,1,13);
                code.visitStmt2R(MOVE_OBJECT,2,15);
                code.visitStmt2R(MOVE_OBJECT,3,11);
                code.visitStmt2R(MOVE_OBJECT,4,8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2,3,4},new Method("Lorg/mortbay/servlet/PutFilter;","handlePut",new String[]{ "Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;","Ljava/lang/String;","Ljava/io/File;"},"V"));
                code.visitStmt2R(MOVE_OBJECT,7,8);
                code.visitLabel(L21);
                code.visitJumpStmt(GOTO,-1,-1,L15);
                code.visitLabel(L22);
                code.visitConstStmt(CONST_STRING,17,"DELETE");
                code.visitStmt2R(MOVE_OBJECT,0,9);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,17);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,17);
                code.visitJumpStmt(IF_EQZ,17,-1,L25);
                code.visitLabel(L23);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,19);
                code.visitStmt2R(MOVE_OBJECT,1,13);
                code.visitStmt2R(MOVE_OBJECT,2,15);
                code.visitStmt2R(MOVE_OBJECT,3,11);
                code.visitStmt2R(MOVE_OBJECT,4,8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2,3,4},new Method("Lorg/mortbay/servlet/PutFilter;","handleDelete",new String[]{ "Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;","Ljava/lang/String;","Ljava/io/File;"},"V"));
                code.visitStmt2R(MOVE_OBJECT,7,8);
                code.visitLabel(L24);
                code.visitJumpStmt(GOTO,-1,-1,L15);
                code.visitLabel(L25);
                code.visitConstStmt(CONST_STRING,17,"MOVE");
                code.visitStmt2R(MOVE_OBJECT,0,9);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,17);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,17);
                code.visitJumpStmt(IF_EQZ,17,-1,L28);
                code.visitLabel(L26);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,19);
                code.visitStmt2R(MOVE_OBJECT,1,13);
                code.visitStmt2R(MOVE_OBJECT,2,15);
                code.visitStmt2R(MOVE_OBJECT,3,11);
                code.visitStmt2R(MOVE_OBJECT,4,8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2,3,4},new Method("Lorg/mortbay/servlet/PutFilter;","handleMove",new String[]{ "Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;","Ljava/lang/String;","Ljava/io/File;"},"V"));
                code.visitStmt2R(MOVE_OBJECT,7,8);
                code.visitLabel(L27);
                code.visitJumpStmt(GOTO,-1,-1,L15);
                code.visitLabel(L28);
                code.visitTypeStmt(NEW_INSTANCE,17,-1,"Ljava/lang/IllegalStateException;");
                code.visitMethodStmt(INVOKE_DIRECT_RANGE,new int[]{ 17},new Method("Ljava/lang/IllegalStateException;","<init>",new String[]{ },"V"));
                code.visitStmt1R(THROW,17);
                code.visitLabel(L3);
                code.visitStmt1R(MOVE_EXCEPTION,17);
                code.visitStmt2R(MOVE_OBJECT_FROM16,5,17);
                code.visitStmt2R(MOVE_OBJECT,7,8);
                code.visitLabel(L29);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,19);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/servlet/PutFilter;","_context","Ljavax/servlet/ServletContext;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,17,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/lang/Exception;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,18);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,17);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,18);
                code.visitStmt2R(MOVE_OBJECT,2,5);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1,2},new Method("Ljavax/servlet/ServletContext;","log",new String[]{ "Ljava/lang/String;","Ljava/lang/Throwable;"},"V"));
                code.visitLabel(L30);
                code.visitConstStmt(CONST_16,17, Integer.valueOf(500)); // int: 0x000001f4  float:0.000000
                code.visitStmt2R(MOVE_OBJECT,0,15);
                code.visitStmt2R(MOVE_FROM16,1,17);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1},new Method("Ljavax/servlet/http/HttpServletResponse;","sendError",new String[]{ "I"},"V"));
                code.visitJumpStmt(GOTO_16,-1,-1,L15);
                code.visitLabel(L31);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,19);
                code.visitStmt2R(MOVE_OBJECT,1,11);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Lorg/mortbay/servlet/PutFilter;","isHidden",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,17);
                code.visitJumpStmt(IF_EQZ,17,-1,L33);
                code.visitLabel(L32);
                code.visitConstStmt(CONST_16,17, Integer.valueOf(404)); // int: 0x00000194  float:0.000000
                code.visitStmt2R(MOVE_OBJECT,0,15);
                code.visitStmt2R(MOVE_FROM16,1,17);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1},new Method("Ljavax/servlet/http/HttpServletResponse;","sendError",new String[]{ "I"},"V"));
                code.visitJumpStmt(GOTO_16,-1,-1,L15);
                code.visitLabel(L33);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,22);
                code.visitStmt2R(MOVE_OBJECT,1,13);
                code.visitStmt2R(MOVE_OBJECT,2,15);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1,2},new Method("Ljavax/servlet/FilterChain;","doFilter",new String[]{ "Ljavax/servlet/ServletRequest;","Ljavax/servlet/ServletResponse;"},"V"));
                code.visitJumpStmt(GOTO_16,-1,-1,L15);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,17);
                code.visitStmt2R(MOVE_OBJECT_FROM16,5,17);
                code.visitJumpStmt(GOTO,-1,-1,L29);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_handleDelete(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/servlet/PutFilter;","handleDelete",new String[]{ "Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;","Ljava/lang/String;","Ljava/io/File;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljavax/servlet/ServletException;"));
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(9);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/lang/SecurityException;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"request");
                ddv.visitParameterName(1,"response");
                ddv.visitParameterName(2,"pathInContext");
                ddv.visitParameterName(3,"file");
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(246,L0);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(248,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(249,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(259,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(252,L7);
                ddv.visitLineNumber(254,L2);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(256,L8);
                ddv.visitStartLocal(0,L8,"sex","Ljava/lang/SecurityException;",null);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(257,L9);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_16,3, Integer.valueOf(403)); // int: 0x00000193  float:0.000000
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Ljava/io/File;","delete",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_EQZ,1,-1,L7);
                code.visitLabel(L4);
                code.visitConstStmt(CONST_16,1, Integer.valueOf(204)); // int: 0x000000cc  float:0.000000
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 6,1},new Method("Ljavax/servlet/http/HttpServletResponse;","setStatus",new String[]{ "I"},"V"));
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 6},new Method("Ljavax/servlet/http/HttpServletResponse;","flushBuffer",new String[]{ },"V"));
                code.visitLabel(L6);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L7);
                code.visitConstStmt(CONST_16,1, Integer.valueOf(403)); // int: 0x00000193  float:0.000000
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 6,1},new Method("Ljavax/servlet/http/HttpServletResponse;","sendError",new String[]{ "I"},"V"));
                code.visitLabel(L1);
                code.visitJumpStmt(GOTO,-1,-1,L6);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitStmt2R(MOVE_OBJECT,0,1);
                code.visitLabel(L8);
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/servlet/PutFilter;","_context","Ljavax/servlet/ServletContext;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/SecurityException;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1,2,0},new Method("Ljavax/servlet/ServletContext;","log",new String[]{ "Ljava/lang/String;","Ljava/lang/Throwable;"},"V"));
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 6,3},new Method("Ljavax/servlet/http/HttpServletResponse;","sendError",new String[]{ "I"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L6);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_handleMove(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/servlet/PutFilter;","handleMove",new String[]{ "Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;","Ljava/lang/String;","Ljava/io/File;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljavax/servlet/ServletException;"));
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visit(null, new DexType("Ljava/net/URISyntaxException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(11);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"request");
                ddv.visitParameterName(1,"response");
                ddv.visitParameterName(2,"pathInContext");
                ddv.visitParameterName(3,"file");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(265,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(266,L1);
                ddv.visitStartLocal(2,L1,"newPath","Ljava/lang/String;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(268,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(291,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(272,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(273,L5);
                ddv.visitStartLocal(0,L5,"contextPath","Ljava/lang/String;",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(275,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(278,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(279,L8);
                ddv.visitStartLocal(1,L8,"newInfo","Ljava/lang/String;",null);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(280,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(282,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(283,L11);
                ddv.visitStartLocal(4,L11,"new_resource","Ljava/lang/String;",null);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(285,L12);
                ddv.visitStartLocal(3,L12,"new_file","Ljava/io/File;",null);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(287,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(288,L14);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_STRING,5,"new-uri");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 7,5},new Method("Ljavax/servlet/http/HttpServletRequest;","getHeader",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 5},new Method("Lorg/mortbay/util/URIUtil;","canonicalPath",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L1);
                code.visitJumpStmt(IF_NEZ,2,-1,L4);
                code.visitLabel(L2);
                code.visitConstStmt(CONST_16,5, Integer.valueOf(400)); // int: 0x00000190  float:0.000000
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 8,5},new Method("Ljavax/servlet/http/HttpServletResponse;","sendError",new String[]{ "I"},"V"));
                code.visitLabel(L3);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 7},new Method("Ljavax/servlet/http/HttpServletRequest;","getContextPath",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L5);
                code.visitJumpStmt(IF_EQZ,0,-1,L7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,0},new Method("Ljava/lang/String;","startsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitJumpStmt(IF_NEZ,5,-1,L7);
                code.visitLabel(L6);
                code.visitConstStmt(CONST_16,5, Integer.valueOf(405)); // int: 0x00000195  float:0.000000
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 8,5},new Method("Ljavax/servlet/http/HttpServletResponse;","sendError",new String[]{ "I"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitLabel(L7);
                code.visitStmt2R(MOVE_OBJECT,1,2);
                code.visitLabel(L8);
                code.visitJumpStmt(IF_EQZ,0,-1,L10);
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,5},new Method("Ljava/lang/String;","substring",new String[]{ "I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L10);
                code.visitFieldStmt(IGET_OBJECT,5,6,new Field("Lorg/mortbay/servlet/PutFilter;","_baseURI","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 5,1},new Method("Lorg/mortbay/util/URIUtil;","addPaths",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitLabel(L11);
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Ljava/io/File;");
                code.visitTypeStmt(NEW_INSTANCE,5,-1,"Ljava/net/URI;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 5,4},new Method("Ljava/net/URI;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3,5},new Method("Ljava/io/File;","<init>",new String[]{ "Ljava/net/URI;"},"V"));
                code.visitLabel(L12);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10,3},new Method("Ljava/io/File;","renameTo",new String[]{ "Ljava/io/File;"},"Z"));
                code.visitLabel(L13);
                code.visitConstStmt(CONST_16,5, Integer.valueOf(204)); // int: 0x000000cc  float:0.000000
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 8,5},new Method("Ljavax/servlet/http/HttpServletResponse;","setStatus",new String[]{ "I"},"V"));
                code.visitLabel(L14);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 8},new Method("Ljavax/servlet/http/HttpServletResponse;","flushBuffer",new String[]{ },"V"));
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m007_handleOptions(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/servlet/PutFilter;","handleOptions",new String[]{ "Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"request");
                ddv.visitParameterName(1,"response");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(297,L0);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/UnsupportedOperationException;");
                code.visitConstStmt(CONST_STRING,1,"Not Implemented");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Ljava/lang/UnsupportedOperationException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m008_handlePut(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/servlet/PutFilter;","handlePut",new String[]{ "Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;","Ljava/lang/String;","Ljava/io/File;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljavax/servlet/ServletException;"));
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(16);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                DexLabel L3=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2,L3},new String[]{ "Ljava/lang/Exception;",null});
                DexLabel L4=new DexLabel();
                DexLabel L5=new DexLabel();
                DexLabel L6=new DexLabel();
                code.visitTryCatch(L4,L5,new DexLabel[]{L6},new String[]{ "Ljava/lang/Exception;"});
                DexLabel L7=new DexLabel();
                DexLabel L8=new DexLabel();
                code.visitTryCatch(L7,L8,new DexLabel[]{L2,L3},new String[]{ "Ljava/lang/Exception;",null});
                DexLabel L9=new DexLabel();
                DexLabel L10=new DexLabel();
                code.visitTryCatch(L9,L10,new DexLabel[]{L3},new String[]{ null});
                DexLabel L11=new DexLabel();
                DexLabel L12=new DexLabel();
                DexLabel L13=new DexLabel();
                code.visitTryCatch(L11,L12,new DexLabel[]{L13},new String[]{ "Ljava/lang/Exception;"});
                DexLabel L14=new DexLabel();
                DexLabel L15=new DexLabel();
                DexLabel L16=new DexLabel();
                code.visitTryCatch(L14,L15,new DexLabel[]{L16},new String[]{ "Ljava/lang/Exception;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"request");
                ddv.visitParameterName(1,"response");
                ddv.visitParameterName(2,"pathInContext");
                ddv.visitParameterName(3,"file");
                DexLabel L17=new DexLabel();
                ddv.visitPrologue(L17);
                ddv.visitLineNumber(176,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(177,L18);
                ddv.visitStartLocal(2,L18,"exists","Z",null);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(179,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(181,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(182,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(238,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(185,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(186,L24);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(191,L25);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(192,L26);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(197,L27);
                ddv.visitLineNumber(200,L0);
                ddv.visitStartLocal(4,L0,"ok","Z",null);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(201,L28);
                DexLabel L29=new DexLabel();
                ddv.visitLineNumber(202,L29);
                ddv.visitStartLocal(6,L29,"parent","Ljava/io/File;",null);
                DexLabel L30=new DexLabel();
                ddv.visitLineNumber(203,L30);
                DexLabel L31=new DexLabel();
                ddv.visitLineNumber(204,L31);
                ddv.visitStartLocal(7,L31,"toRead","I",null);
                DexLabel L32=new DexLabel();
                ddv.visitLineNumber(205,L32);
                ddv.visitStartLocal(3,L32,"in","Ljava/io/InputStream;",null);
                DexLabel L33=new DexLabel();
                ddv.visitLineNumber(206,L33);
                ddv.visitStartLocal(5,L33,"out","Ljava/io/OutputStream;",null);
                DexLabel L34=new DexLabel();
                ddv.visitLineNumber(207,L34);
                DexLabel L35=new DexLabel();
                ddv.visitLineNumber(210,L35);
                DexLabel L36=new DexLabel();
                ddv.visitLineNumber(212,L36);
                DexLabel L37=new DexLabel();
                ddv.visitLineNumber(213,L37);
                ddv.visitLineNumber(214,L1);
                DexLabel L38=new DexLabel();
                ddv.visitLineNumber(223,L38);
                ddv.visitLineNumber(227,L4);
                DexLabel L39=new DexLabel();
                ddv.visitLineNumber(228,L39);
                ddv.visitLineNumber(235,L5);
                DexLabel L40=new DexLabel();
                ddv.visitEndLocal(6,L40);
                ddv.visitEndLocal(7,L40);
                ddv.visitEndLocal(3,L40);
                ddv.visitEndLocal(5,L40);
                ddv.visitLineNumber(209,L7);
                ddv.visitRestartLocal(3,L7);
                ddv.visitRestartLocal(5,L7);
                ddv.visitRestartLocal(6,L7);
                ddv.visitRestartLocal(7,L7);
                ddv.visitLineNumber(216,L2);
                ddv.visitEndLocal(3,L2);
                ddv.visitEndLocal(5,L2);
                ddv.visitEndLocal(6,L2);
                ddv.visitEndLocal(7,L2);
                ddv.visitLineNumber(218,L9);
                ddv.visitStartLocal(1,L9,"ex","Ljava/lang/Exception;",null);
                DexLabel L41=new DexLabel();
                ddv.visitLineNumber(219,L41);
                ddv.visitLineNumber(223,L10);
                ddv.visitLineNumber(227,L11);
                DexLabel L42=new DexLabel();
                ddv.visitLineNumber(228,L42);
                ddv.visitLineNumber(235,L12);
                DexLabel L43=new DexLabel();
                ddv.visitLineNumber(212,L43);
                ddv.visitEndLocal(1,L43);
                ddv.visitRestartLocal(3,L43);
                ddv.visitRestartLocal(5,L43);
                ddv.visitRestartLocal(6,L43);
                ddv.visitRestartLocal(7,L43);
                ddv.visitLineNumber(223,L3);
                ddv.visitEndLocal(3,L3);
                ddv.visitEndLocal(5,L3);
                ddv.visitEndLocal(6,L3);
                ddv.visitEndLocal(7,L3);
                ddv.visitLineNumber(227,L14);
                DexLabel L44=new DexLabel();
                ddv.visitLineNumber(228,L44);
                ddv.visitLineNumber(235,L15);
                DexLabel L45=new DexLabel();
                ddv.visitLineNumber(223,L45);
                ddv.visitLineNumber(230,L16);
                DexLabel L46=new DexLabel();
                ddv.visitLineNumber(232,L46);
                ddv.visitStartLocal(0,L46,"e","Ljava/lang/Exception;",null);
                ddv.visitLineNumber(230,L13);
                ddv.visitEndLocal(0,L13);
                ddv.visitRestartLocal(1,L13);
                DexLabel L47=new DexLabel();
                ddv.visitLineNumber(232,L47);
                ddv.visitRestartLocal(0,L47);
                ddv.visitLineNumber(230,L6);
                ddv.visitEndLocal(1,L6);
                ddv.visitEndLocal(0,L6);
                ddv.visitRestartLocal(3,L6);
                ddv.visitRestartLocal(5,L6);
                ddv.visitRestartLocal(6,L6);
                ddv.visitRestartLocal(7,L6);
                DexLabel L48=new DexLabel();
                ddv.visitLineNumber(232,L48);
                ddv.visitRestartLocal(0,L48);
                code.visitLabel(L17);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 15},new Method("Ljava/io/File;","exists",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitLabel(L18);
                code.visitConstStmt(CONST_STRING,8,"/");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 14,8},new Method("Ljava/lang/String;","endsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitJumpStmt(IF_EQZ,8,-1,L27);
                code.visitLabel(L19);
                code.visitJumpStmt(IF_NEZ,2,-1,L25);
                code.visitLabel(L20);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 15},new Method("Ljava/io/File;","mkdirs",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitJumpStmt(IF_NEZ,8,-1,L23);
                code.visitLabel(L21);
                code.visitConstStmt(CONST_16,8, Integer.valueOf(403)); // int: 0x00000193  float:0.000000
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 13,8},new Method("Ljavax/servlet/http/HttpServletResponse;","sendError",new String[]{ "I"},"V"));
                code.visitLabel(L22);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L23);
                code.visitConstStmt(CONST_16,8, Integer.valueOf(201)); // int: 0x000000c9  float:0.000000
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 13,8},new Method("Ljavax/servlet/http/HttpServletResponse;","setStatus",new String[]{ "I"},"V"));
                code.visitLabel(L24);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 13},new Method("Ljavax/servlet/http/HttpServletResponse;","flushBuffer",new String[]{ },"V"));
                code.visitJumpStmt(GOTO,-1,-1,L22);
                code.visitLabel(L25);
                code.visitConstStmt(CONST_16,8, Integer.valueOf(200)); // int: 0x000000c8  float:0.000000
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 13,8},new Method("Ljavax/servlet/http/HttpServletResponse;","setStatus",new String[]{ "I"},"V"));
                code.visitLabel(L26);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 13},new Method("Ljavax/servlet/http/HttpServletResponse;","flushBuffer",new String[]{ },"V"));
                code.visitJumpStmt(GOTO,-1,-1,L22);
                code.visitLabel(L27);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,8,11,new Field("Lorg/mortbay/servlet/PutFilter;","_hidden","Ljava/util/concurrent/ConcurrentMap;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 8,14,14},new Method("Ljava/util/concurrent/ConcurrentMap;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L28);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 15},new Method("Ljava/io/File;","getParentFile",new String[]{ },"Ljava/io/File;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitLabel(L29);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/io/File;","mkdirs",new String[]{ },"Z"));
                code.visitLabel(L30);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 12},new Method("Ljavax/servlet/http/HttpServletRequest;","getContentLength",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitLabel(L31);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 12},new Method("Ljavax/servlet/http/HttpServletRequest;","getInputStream",new String[]{ },"Ljavax/servlet/ServletInputStream;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitLabel(L32);
                code.visitTypeStmt(NEW_INSTANCE,5,-1,"Ljava/io/FileOutputStream;");
                code.visitConstStmt(CONST_4,8, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 5,15,8},new Method("Ljava/io/FileOutputStream;","<init>",new String[]{ "Ljava/io/File;","Z"},"V"));
                code.visitLabel(L33);
                code.visitJumpStmt(IF_LTZ,7,-1,L7);
                code.visitLabel(L34);
                code.visitStmt2R(INT_TO_LONG,8,7);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3,5,8,9},new Method("Lorg/mortbay/util/IO;","copy",new String[]{ "Ljava/io/InputStream;","Ljava/io/OutputStream;","J"},"V"));
                code.visitLabel(L35);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/io/OutputStream;","close",new String[]{ },"V"));
                code.visitLabel(L36);
                code.visitJumpStmt(IF_EQZ,2,-1,L43);
                code.visitConstStmt(CONST_16,8, Integer.valueOf(200)); // int: 0x000000c8  float:0.000000
                DexLabel L49=new DexLabel();
                code.visitLabel(L49);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 13,8},new Method("Ljavax/servlet/http/HttpServletResponse;","setStatus",new String[]{ "I"},"V"));
                code.visitLabel(L37);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 13},new Method("Ljavax/servlet/http/HttpServletResponse;","flushBuffer",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L38);
                code.visitJumpStmt(IF_NEZ,4,-1,L5);
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 15},new Method("Ljava/io/File;","exists",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitJumpStmt(IF_EQZ,8,-1,L5);
                code.visitLabel(L39);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 15},new Method("Ljava/io/File;","delete",new String[]{ },"Z"));
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,8,11,new Field("Lorg/mortbay/servlet/PutFilter;","_hidden","Ljava/util/concurrent/ConcurrentMap;"));
                code.visitLabel(L40);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 8,14},new Method("Ljava/util/concurrent/ConcurrentMap;","remove",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitJumpStmt(GOTO,-1,-1,L22);
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3,5},new Method("Lorg/mortbay/util/IO;","copy",new String[]{ "Ljava/io/InputStream;","Ljava/io/OutputStream;"},"V"));
                code.visitLabel(L8);
                code.visitJumpStmt(GOTO,-1,-1,L35);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,8);
                code.visitStmt2R(MOVE_OBJECT,1,8);
                code.visitLabel(L9);
                code.visitFieldStmt(IGET_OBJECT,8,11,new Field("Lorg/mortbay/servlet/PutFilter;","_context","Ljavax/servlet/ServletContext;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/lang/Exception;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 8,9,1},new Method("Ljavax/servlet/ServletContext;","log",new String[]{ "Ljava/lang/String;","Ljava/lang/Throwable;"},"V"));
                code.visitLabel(L41);
                code.visitConstStmt(CONST_16,8, Integer.valueOf(403)); // int: 0x00000193  float:0.000000
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 13,8},new Method("Ljavax/servlet/http/HttpServletResponse;","sendError",new String[]{ "I"},"V"));
                code.visitLabel(L10);
                code.visitJumpStmt(IF_NEZ,4,-1,L12);
                code.visitLabel(L11);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 15},new Method("Ljava/io/File;","exists",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitJumpStmt(IF_EQZ,8,-1,L12);
                code.visitLabel(L42);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 15},new Method("Ljava/io/File;","delete",new String[]{ },"Z"));
                code.visitLabel(L12);
                code.visitFieldStmt(IGET_OBJECT,8,11,new Field("Lorg/mortbay/servlet/PutFilter;","_hidden","Ljava/util/concurrent/ConcurrentMap;"));
                code.visitJumpStmt(GOTO,-1,-1,L40);
                code.visitLabel(L43);
                code.visitConstStmt(CONST_16,8, Integer.valueOf(201)); // int: 0x000000c9  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L49);
                code.visitLabel(L3);
                code.visitStmt1R(MOVE_EXCEPTION,8);
                code.visitJumpStmt(IF_NEZ,4,-1,L15);
                code.visitLabel(L14);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 15},new Method("Ljava/io/File;","exists",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,9);
                code.visitJumpStmt(IF_EQZ,9,-1,L15);
                code.visitLabel(L44);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 15},new Method("Ljava/io/File;","delete",new String[]{ },"Z"));
                code.visitLabel(L15);
                code.visitFieldStmt(IGET_OBJECT,9,11,new Field("Lorg/mortbay/servlet/PutFilter;","_hidden","Ljava/util/concurrent/ConcurrentMap;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 9,14},new Method("Ljava/util/concurrent/ConcurrentMap;","remove",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L45);
                code.visitStmt1R(THROW,8);
                code.visitLabel(L16);
                code.visitStmt1R(MOVE_EXCEPTION,9);
                code.visitStmt2R(MOVE_OBJECT,0,9);
                code.visitLabel(L46);
                code.visitFieldStmt(IGET_OBJECT,9,11,new Field("Lorg/mortbay/servlet/PutFilter;","_context","Ljavax/servlet/ServletContext;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/Exception;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,10);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 9,10,0},new Method("Ljavax/servlet/ServletContext;","log",new String[]{ "Ljava/lang/String;","Ljava/lang/Throwable;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L15);
                code.visitLabel(L13);
                code.visitStmt1R(MOVE_EXCEPTION,8);
                code.visitStmt2R(MOVE_OBJECT,0,8);
                code.visitLabel(L47);
                code.visitFieldStmt(IGET_OBJECT,8,11,new Field("Lorg/mortbay/servlet/PutFilter;","_context","Ljavax/servlet/ServletContext;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/Exception;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 8,9,0},new Method("Ljavax/servlet/ServletContext;","log",new String[]{ "Ljava/lang/String;","Ljava/lang/Throwable;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L12);
                code.visitLabel(L6);
                code.visitStmt1R(MOVE_EXCEPTION,8);
                code.visitStmt2R(MOVE_OBJECT,0,8);
                code.visitLabel(L48);
                code.visitFieldStmt(IGET_OBJECT,8,11,new Field("Lorg/mortbay/servlet/PutFilter;","_context","Ljavax/servlet/ServletContext;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/Exception;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 8,9,0},new Method("Ljavax/servlet/ServletContext;","log",new String[]{ "Ljava/lang/String;","Ljava/lang/Throwable;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m009_init(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/servlet/PutFilter;","init",new String[]{ "Ljavax/servlet/FilterConfig;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljavax/servlet/ServletException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"config");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(73,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(74,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(75,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(77,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(78,L5);
                ddv.visitStartLocal(0,L5,"b","Ljava/lang/String;",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(80,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(88,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(90,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(91,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(92,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(94,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(95,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(97,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(84,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(85,L15);
                ddv.visitStartLocal(1,L15,"base","Ljava/io/File;",null);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_STRING,4,"/");
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 6},new Method("Ljavax/servlet/FilterConfig;","getServletContext",new String[]{ },"Ljavax/servlet/ServletContext;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitFieldStmt(IPUT_OBJECT,2,5,new Field("Lorg/mortbay/servlet/PutFilter;","_context","Ljavax/servlet/ServletContext;"));
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/servlet/PutFilter;","_context","Ljavax/servlet/ServletContext;"));
                code.visitConstStmt(CONST_STRING,3,"/");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2,4},new Method("Ljavax/servlet/ServletContext;","getRealPath",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitJumpStmt(IF_NEZ,2,-1,L4);
                code.visitLabel(L3);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Ljavax/servlet/UnavailableException;");
                code.visitConstStmt(CONST_STRING,3,"Packed war");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2,3},new Method("Ljavax/servlet/UnavailableException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,2);
                code.visitLabel(L4);
                code.visitConstStmt(CONST_STRING,2,"baseURI");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 6,2},new Method("Ljavax/servlet/FilterConfig;","getInitParameter",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L5);
                code.visitJumpStmt(IF_EQZ,0,-1,L14);
                code.visitLabel(L6);
                code.visitFieldStmt(IPUT_OBJECT,0,5,new Field("Lorg/mortbay/servlet/PutFilter;","_baseURI","Ljava/lang/String;"));
                code.visitLabel(L7);
                code.visitConstStmt(CONST_STRING,2,"delAllowed");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 5,6,2},new Method("Lorg/mortbay/servlet/PutFilter;","getInitBoolean",new String[]{ "Ljavax/servlet/FilterConfig;","Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitFieldStmt(IPUT_BOOLEAN,2,5,new Field("Lorg/mortbay/servlet/PutFilter;","_delAllowed","Z"));
                code.visitLabel(L8);
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/servlet/PutFilter;","_operations","Ljava/util/Set;"));
                code.visitConstStmt(CONST_STRING,3,"OPTIONS");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2,3},new Method("Ljava/util/Set;","add",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitLabel(L9);
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/servlet/PutFilter;","_operations","Ljava/util/Set;"));
                code.visitConstStmt(CONST_STRING,3,"PUT");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2,3},new Method("Ljava/util/Set;","add",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitLabel(L10);
                code.visitFieldStmt(IGET_BOOLEAN,2,5,new Field("Lorg/mortbay/servlet/PutFilter;","_delAllowed","Z"));
                code.visitJumpStmt(IF_EQZ,2,-1,L13);
                code.visitLabel(L11);
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/servlet/PutFilter;","_operations","Ljava/util/Set;"));
                code.visitConstStmt(CONST_STRING,3,"DELETE");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2,3},new Method("Ljava/util/Set;","add",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitLabel(L12);
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/servlet/PutFilter;","_operations","Ljava/util/Set;"));
                code.visitConstStmt(CONST_STRING,3,"MOVE");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2,3},new Method("Ljava/util/Set;","add",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitLabel(L13);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L14);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/io/File;");
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/servlet/PutFilter;","_context","Ljavax/servlet/ServletContext;"));
                code.visitConstStmt(CONST_STRING,3,"/");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2,4},new Method("Ljavax/servlet/ServletContext;","getRealPath",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,2},new Method("Ljava/io/File;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L15);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/io/File;","toURI",new String[]{ },"Ljava/net/URI;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/net/URI;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitFieldStmt(IPUT_OBJECT,2,5,new Field("Lorg/mortbay/servlet/PutFilter;","_baseURI","Ljava/lang/String;"));
                code.visitJumpStmt(GOTO,-1,-1,L7);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m010_passConditionalHeaders(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/servlet/PutFilter;","passConditionalHeaders",new String[]{ "Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;","Ljava/io/File;"},"Z"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(15);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"request");
                ddv.visitParameterName(1,"response");
                ddv.visitParameterName(2,"file");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(306,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(308,L2);
                ddv.visitStartLocal(0,L2,"date","J",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(310,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(312,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(327,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(317,L6);
                DexLabel L7=new DexLabel();
                ddv.visitRestartLocal(0,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(319,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(321,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(322,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(323,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(324,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(327,L13);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_WIDE_16,9,Long.valueOf(0L)); // long: 0x0000000000000000  double:0.000000
                code.visitConstStmt(CONST_4,8, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitConstStmt(CONST_WIDE_16,6,Long.valueOf(1000L)); // long: 0x00000000000003e8  double:0.000000
                code.visitLabel(L1);
                code.visitConstStmt(CONST_WIDE_16,0,Long.valueOf(0L)); // long: 0x0000000000000000  double:0.000000
                code.visitLabel(L2);
                code.visitConstStmt(CONST_STRING,2,"if-unmodified-since");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 12,2},new Method("Ljavax/servlet/http/HttpServletRequest;","getDateHeader",new String[]{ "Ljava/lang/String;"},"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,0);
                code.visitStmt3R(CMP_LONG,2,0,9);
                code.visitJumpStmt(IF_LEZ,2,-1,L6);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 14},new Method("Ljava/io/File;","lastModified",new String[]{ },"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,2);
                code.visitStmt2R(DIV_LONG_2ADDR,2,6);
                code.visitStmt3R(DIV_LONG,4,0,6);
                code.visitStmt3R(CMP_LONG,2,2,4);
                code.visitJumpStmt(IF_LEZ,2,-1,L6);
                code.visitLabel(L4);
                code.visitConstStmt(CONST_16,2, Integer.valueOf(412)); // int: 0x0000019c  float:0.000000
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 13,2},new Method("Ljavax/servlet/http/HttpServletResponse;","sendError",new String[]{ "I"},"V"));
                code.visitStmt2R(MOVE,2,8);
                code.visitLabel(L5);
                code.visitStmt1R(RETURN,2);
                code.visitLabel(L6);
                code.visitConstStmt(CONST_STRING,2,"if-modified-since");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 12,2},new Method("Ljavax/servlet/http/HttpServletRequest;","getDateHeader",new String[]{ "Ljava/lang/String;"},"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,0);
                code.visitLabel(L7);
                code.visitStmt3R(CMP_LONG,2,0,9);
                code.visitJumpStmt(IF_LEZ,2,-1,L13);
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 14},new Method("Ljava/io/File;","lastModified",new String[]{ },"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,2);
                code.visitStmt2R(DIV_LONG_2ADDR,2,6);
                code.visitStmt3R(DIV_LONG,4,0,6);
                code.visitStmt3R(CMP_LONG,2,2,4);
                code.visitJumpStmt(IF_GTZ,2,-1,L13);
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 13},new Method("Ljavax/servlet/http/HttpServletResponse;","reset",new String[]{ },"V"));
                code.visitLabel(L10);
                code.visitConstStmt(CONST_16,2, Integer.valueOf(304)); // int: 0x00000130  float:0.000000
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 13,2},new Method("Ljavax/servlet/http/HttpServletResponse;","setStatus",new String[]{ "I"},"V"));
                code.visitLabel(L11);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 13},new Method("Ljavax/servlet/http/HttpServletResponse;","flushBuffer",new String[]{ },"V"));
                code.visitStmt2R(MOVE,2,8);
                code.visitLabel(L12);
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitLabel(L13);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
