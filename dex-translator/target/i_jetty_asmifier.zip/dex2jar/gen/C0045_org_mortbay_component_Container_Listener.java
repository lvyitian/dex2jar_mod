package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0045_org_mortbay_component_Container_Listener {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC|ACC_INTERFACE|ACC_ABSTRACT,"Lorg/mortbay/component/Container$Listener;","Ljava/lang/Object;",new String[]{ "Ljava/util/EventListener;"});
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("Container.java");
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/EnclosingClass;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("value", new DexType("Lorg/mortbay/component/Container;"));
                av00.visitEnd();
            }
        }
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/InnerClass;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("accessFlags",  Integer.valueOf(1545));
                av00.visit("name", "Listener");
                av00.visitEnd();
            }
        }
        m000_add(cv);
        m001_addBean(cv);
        m002_remove(cv);
        m003_removeBean(cv);
    }
    public static void m000_add(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/component/Container$Listener;","add",new String[]{ "Lorg/mortbay/component/Container$Relationship;"},"V"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m001_addBean(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/component/Container$Listener;","addBean",new String[]{ "Ljava/lang/Object;"},"V"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m002_remove(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/component/Container$Listener;","remove",new String[]{ "Lorg/mortbay/component/Container$Relationship;"},"V"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m003_removeBean(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/component/Container$Listener;","removeBean",new String[]{ "Ljava/lang/Object;"},"V"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
}
