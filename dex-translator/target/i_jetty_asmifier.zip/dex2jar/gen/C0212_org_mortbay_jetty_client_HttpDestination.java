package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0212_org_mortbay_jetty_client_HttpDestination {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/jetty/client/HttpDestination;","Ljava/lang/Object;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("HttpDestination.java");
        f000__address(cv);
        f001__authorizations(cv);
        f002__client(cv);
        f003__connections(cv);
        f004__cookies(cv);
        f005__hostHeader(cv);
        f006__idle(cv);
        f007__maxConnections(cv);
        f008__newConnection(cv);
        f009__newQueue(cv);
        f010__pendingConnections(cv);
        f011__proxy(cv);
        f012__proxyAuthentication(cv);
        f013__queue(cv);
        f014__ssl(cv);
        m000__init_(cv);
        m001_getConnection(cv);
        m002_addAuthorization(cv);
        m003_addCookie(cv);
        m004_close(cv);
        m005_doSend(cv);
        m006_dump(cv);
        m007_getAddress(cv);
        m008_getHostHeader(cv);
        m009_getHttpClient(cv);
        m010_getIdleConnection(cv);
        m011_getProxy(cv);
        m012_getProxyAuthentication(cv);
        m013_isProxied(cv);
        m014_isSecure(cv);
        m015_onConnectionFailed(cv);
        m016_onException(cv);
        m017_onNewConnection(cv);
        m018_resend(cv);
        m019_reserveConnection(cv);
        m020_returnConnection(cv);
        m021_send(cv);
        m022_setProxy(cv);
        m023_setProxyAuthentication(cv);
        m024_startNewConnection(cv);
        m025_toDetailString(cv);
        m026_toString(cv);
    }
    public static void f000__address(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_FINAL, new Field("Lorg/mortbay/jetty/client/HttpDestination;","_address","Lorg/mortbay/jetty/client/Address;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001__authorizations(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/client/HttpDestination;","_authorizations","Lorg/mortbay/jetty/servlet/PathMap;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002__client(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_FINAL, new Field("Lorg/mortbay/jetty/client/HttpDestination;","_client","Lorg/mortbay/jetty/client/HttpClient;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003__connections(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_FINAL, new Field("Lorg/mortbay/jetty/client/HttpDestination;","_connections","Ljava/util/LinkedList;"), null);
        if(fv != null) {
            if(fv!=null){
                DexAnnotationVisitor av00 = fv.visitAnnotation("Ldalvik/annotation/Signature;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, "Ljava/util/LinkedList");
                            av01.visit(null, "<");
                            av01.visit(null, "Lorg/mortbay/jetty/client/HttpConnection;");
                            av01.visit(null, ">;");
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            fv.visitEnd();
        }
    }
    public static void f004__cookies(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/client/HttpDestination;","_cookies","Ljava/util/List;"), null);
        if(fv != null) {
            if(fv!=null){
                DexAnnotationVisitor av00 = fv.visitAnnotation("Ldalvik/annotation/Signature;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, "Ljava/util/List");
                            av01.visit(null, "<");
                            av01.visit(null, "Ljavax/servlet/http/Cookie;");
                            av01.visit(null, ">;");
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            fv.visitEnd();
        }
    }
    public static void f005__hostHeader(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/client/HttpDestination;","_hostHeader","Lorg/mortbay/io/ByteArrayBuffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f006__idle(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_FINAL, new Field("Lorg/mortbay/jetty/client/HttpDestination;","_idle","Ljava/util/ArrayList;"), null);
        if(fv != null) {
            if(fv!=null){
                DexAnnotationVisitor av00 = fv.visitAnnotation("Ldalvik/annotation/Signature;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, "Ljava/util/ArrayList");
                            av01.visit(null, "<");
                            av01.visit(null, "Lorg/mortbay/jetty/client/HttpConnection;");
                            av01.visit(null, ">;");
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            fv.visitEnd();
        }
    }
    public static void f007__maxConnections(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/client/HttpDestination;","_maxConnections","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f008__newConnection(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/client/HttpDestination;","_newConnection","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f009__newQueue(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/client/HttpDestination;","_newQueue","Ljava/util/concurrent/ArrayBlockingQueue;"), null);
        if(fv != null) {
            if(fv!=null){
                DexAnnotationVisitor av00 = fv.visitAnnotation("Ldalvik/annotation/Signature;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, "Ljava/util/concurrent/ArrayBlockingQueue");
                            av01.visit(null, "<");
                            av01.visit(null, "Ljava/lang/Object;");
                            av01.visit(null, ">;");
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            fv.visitEnd();
        }
    }
    public static void f010__pendingConnections(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/client/HttpDestination;","_pendingConnections","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f011__proxy(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/client/HttpDestination;","_proxy","Lorg/mortbay/jetty/client/Address;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f012__proxyAuthentication(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/client/HttpDestination;","_proxyAuthentication","Lorg/mortbay/jetty/client/security/Authorization;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f013__queue(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/client/HttpDestination;","_queue","Ljava/util/LinkedList;"), null);
        if(fv != null) {
            if(fv!=null){
                DexAnnotationVisitor av00 = fv.visitAnnotation("Ldalvik/annotation/Signature;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, "Ljava/util/LinkedList");
                            av01.visit(null, "<");
                            av01.visit(null, "Lorg/mortbay/jetty/client/HttpExchange;");
                            av01.visit(null, ">;");
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            fv.visitEnd();
        }
    }
    public static void f014__ssl(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_FINAL, new Field("Lorg/mortbay/jetty/client/HttpDestination;","_ssl","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/client/HttpDestination;","<init>",new String[]{ "Lorg/mortbay/jetty/client/HttpClient;","Lorg/mortbay/jetty/client/Address;","Z","I"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(10);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"pool");
                ddv.visitParameterName(1,"address");
                ddv.visitParameterName(2,"ssl");
                ddv.visitParameterName(3,"maxConnections");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(76,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(42,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(43,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(47,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(48,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(49,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(72,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(77,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(78,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(79,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(80,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(81,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(82,L13);
                ddv.visitStartLocal(0,L13,"addressString","Ljava/lang/String;",null);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(83,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(84,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(82,L16);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 5},new Method("Ljava/lang/Object;","<init>",new String[]{ },"V"));
                code.visitLabel(L2);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/util/LinkedList;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljava/util/LinkedList;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,1,5,new Field("Lorg/mortbay/jetty/client/HttpDestination;","_connections","Ljava/util/LinkedList;"));
                code.visitLabel(L3);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/util/ArrayList;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljava/util/ArrayList;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,1,5,new Field("Lorg/mortbay/jetty/client/HttpDestination;","_idle","Ljava/util/ArrayList;"));
                code.visitLabel(L4);
                code.visitFieldStmt(IPUT,4,5,new Field("Lorg/mortbay/jetty/client/HttpDestination;","_pendingConnections","I"));
                code.visitLabel(L5);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/util/concurrent/ArrayBlockingQueue;");
                code.visitConstStmt(CONST_16,2, Integer.valueOf(10)); // int: 0x0000000a  float:0.000000
                code.visitConstStmt(CONST_4,3, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,2,3},new Method("Ljava/util/concurrent/ArrayBlockingQueue;","<init>",new String[]{ "I","Z"},"V"));
                code.visitFieldStmt(IPUT_OBJECT,1,5,new Field("Lorg/mortbay/jetty/client/HttpDestination;","_newQueue","Ljava/util/concurrent/ArrayBlockingQueue;"));
                code.visitLabel(L6);
                code.visitFieldStmt(IPUT,4,5,new Field("Lorg/mortbay/jetty/client/HttpDestination;","_newConnection","I"));
                code.visitLabel(L7);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/util/LinkedList;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljava/util/LinkedList;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,1,5,new Field("Lorg/mortbay/jetty/client/HttpDestination;","_queue","Ljava/util/LinkedList;"));
                code.visitLabel(L8);
                code.visitFieldStmt(IPUT_OBJECT,6,5,new Field("Lorg/mortbay/jetty/client/HttpDestination;","_client","Lorg/mortbay/jetty/client/HttpClient;"));
                code.visitLabel(L9);
                code.visitFieldStmt(IPUT_OBJECT,7,5,new Field("Lorg/mortbay/jetty/client/HttpDestination;","_address","Lorg/mortbay/jetty/client/Address;"));
                code.visitLabel(L10);
                code.visitFieldStmt(IPUT_BOOLEAN,8,5,new Field("Lorg/mortbay/jetty/client/HttpDestination;","_ssl","Z"));
                code.visitLabel(L11);
                code.visitFieldStmt(IPUT,9,5,new Field("Lorg/mortbay/jetty/client/HttpDestination;","_maxConnections","I"));
                code.visitLabel(L12);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Lorg/mortbay/jetty/client/Address;","getHost",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L13);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Lorg/mortbay/jetty/client/Address;","getPort",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitFieldStmt(IGET_BOOLEAN,2,5,new Field("Lorg/mortbay/jetty/client/HttpDestination;","_ssl","Z"));
                code.visitJumpStmt(IF_EQZ,2,-1,L16);
                code.visitConstStmt(CONST_16,2, Integer.valueOf(443)); // int: 0x000001bb  float:0.000000
                DexLabel L17=new DexLabel();
                code.visitLabel(L17);
                code.visitJumpStmt(IF_EQ,1,2,L14);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,0},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitConstStmt(CONST_STRING,2,":");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Lorg/mortbay/jetty/client/Address;","getPort",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "I"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L14);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Lorg/mortbay/io/ByteArrayBuffer;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,0},new Method("Lorg/mortbay/io/ByteArrayBuffer;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitFieldStmt(IPUT_OBJECT,1,5,new Field("Lorg/mortbay/jetty/client/HttpDestination;","_hostHeader","Lorg/mortbay/io/ByteArrayBuffer;"));
                code.visitLabel(L15);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L16);
                code.visitConstStmt(CONST_16,2, Integer.valueOf(80)); // int: 0x00000050  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L17);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001_getConnection(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PRIVATE, new Method("Lorg/mortbay/jetty/client/HttpDestination;","getConnection",new String[]{ "J"},"Lorg/mortbay/jetty/client/HttpConnection;"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(13);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                DexLabel L5=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L5},new String[]{ "Ljava/lang/InterruptedException;"});
                DexLabel L6=new DexLabel();
                DexLabel L7=new DexLabel();
                code.visitTryCatch(L6,L7,new DexLabel[]{L2},new String[]{ null});
                DexLabel L8=new DexLabel();
                DexLabel L9=new DexLabel();
                code.visitTryCatch(L8,L9,new DexLabel[]{L9},new String[]{ "Ljava/lang/InterruptedException;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"timeout");
                DexLabel L10=new DexLabel();
                ddv.visitPrologue(L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(147,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(149,L12);
                ddv.visitStartLocal(1,L12,"connection","Lorg/mortbay/jetty/client/HttpConnection;",null);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(151,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(152,L14);
                ddv.visitStartLocal(5,L14,"totalConnections","I",null);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(153,L15);
                ddv.visitStartLocal(4,L15,"starting","Z",null);
                ddv.visitLineNumber(155,L0);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(156,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(158,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(159,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(160,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(162,L20);
                ddv.visitLineNumber(164,L1);
                ddv.visitLineNumber(168,L3);
                ddv.visitLineNumber(169,L4);
                ddv.visitLineNumber(162,L2);
                ddv.visitLineNumber(171,L5);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(173,L21);
                ddv.visitStartLocal(2,L21,"e","Ljava/lang/InterruptedException;",null);
                ddv.visitLineNumber(180,L8);
                ddv.visitEndLocal(2,L8);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(181,L22);
                ddv.visitStartLocal(3,L22,"o","Ljava/lang/Object;",null);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(183,L23);
                DexLabel L24=new DexLabel();
                ddv.visitRestartLocal(1,L24);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(186,L25);
                DexLabel L26=new DexLabel();
                ddv.visitEndLocal(3,L26);
                ddv.visitLineNumber(188,L9);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(190,L27);
                ddv.visitRestartLocal(2,L27);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(194,L28);
                ddv.visitEndLocal(5,L28);
                ddv.visitEndLocal(4,L28);
                ddv.visitEndLocal(2,L28);
                code.visitLabel(L10);
                code.visitConstStmt(CONST_WIDE_16,8,Long.valueOf(200L)); // long: 0x00000000000000c8  double:0.000000
                code.visitLabel(L11);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L12);
                code.visitJumpStmt(IF_NEZ,1,-1,L28);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Lorg/mortbay/jetty/client/HttpDestination;","getIdleConnection",new String[]{ },"Lorg/mortbay/jetty/client/HttpConnection;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitJumpStmt(IF_NEZ,1,-1,L28);
                code.visitConstStmt(CONST_WIDE_16,6,Long.valueOf(0L)); // long: 0x0000000000000000  double:0.000000
                code.visitStmt3R(CMP_LONG,6,11,6);
                code.visitJumpStmt(IF_LEZ,6,-1,L28);
                code.visitLabel(L13);
                code.visitConstStmt(CONST_4,5, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L14);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L15);
                code.visitStmt1R(MONITOR_ENTER,10);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,6,10,new Field("Lorg/mortbay/jetty/client/HttpDestination;","_connections","Ljava/util/LinkedList;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/util/LinkedList;","size",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitFieldStmt(IGET,7,10,new Field("Lorg/mortbay/jetty/client/HttpDestination;","_pendingConnections","I"));
                code.visitStmt3R(ADD_INT,5,6,7);
                code.visitLabel(L16);
                code.visitFieldStmt(IGET,6,10,new Field("Lorg/mortbay/jetty/client/HttpDestination;","_maxConnections","I"));
                code.visitJumpStmt(IF_GE,5,6,L20);
                code.visitLabel(L17);
                code.visitFieldStmt(IGET,6,10,new Field("Lorg/mortbay/jetty/client/HttpDestination;","_newConnection","I"));
                code.visitStmt2R1N(ADD_INT_LIT8,6,6,1);
                code.visitFieldStmt(IPUT,6,10,new Field("Lorg/mortbay/jetty/client/HttpDestination;","_newConnection","I"));
                code.visitLabel(L18);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Lorg/mortbay/jetty/client/HttpDestination;","startNewConnection",new String[]{ },"V"));
                code.visitLabel(L19);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L20);
                code.visitStmt1R(MONITOR_EXIT,10);
                code.visitLabel(L1);
                code.visitJumpStmt(IF_NEZ,4,-1,L8);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Ljava/lang/Thread;","currentThread",new String[]{ },"Ljava/lang/Thread;"));
                code.visitConstStmt(CONST_WIDE_16,6,Long.valueOf(200L)); // long: 0x00000000000000c8  double:0.000000
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 6,7},new Method("Ljava/lang/Thread;","sleep",new String[]{ "J"},"V"));
                code.visitLabel(L4);
                code.visitStmt2R(SUB_LONG_2ADDR,11,8);
                code.visitJumpStmt(GOTO,-1,-1,L12);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,6);
                code.visitLabel(L6);
                code.visitStmt1R(MONITOR_EXIT,10);
                code.visitLabel(L7);
                code.visitStmt1R(THROW,6);
                code.visitLabel(L5);
                code.visitStmt1R(MOVE_EXCEPTION,6);
                code.visitStmt2R(MOVE_OBJECT,2,6);
                code.visitLabel(L21);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2},new Method("Lorg/mortbay/log/Log;","ignore",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L12);
                code.visitLabel(L8);
                code.visitFieldStmt(IGET_OBJECT,6,10,new Field("Lorg/mortbay/jetty/client/HttpDestination;","_newQueue","Ljava/util/concurrent/ArrayBlockingQueue;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/util/concurrent/ArrayBlockingQueue;","take",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitLabel(L22);
                code.visitTypeStmt(INSTANCE_OF,6,3,"Lorg/mortbay/jetty/client/HttpConnection;");
                code.visitJumpStmt(IF_EQZ,6,-1,L25);
                code.visitLabel(L23);
                code.visitStmt2R(MOVE_OBJECT,0,3);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Lorg/mortbay/jetty/client/HttpConnection;");
                code.visitStmt2R(MOVE_OBJECT,1,0);
                code.visitLabel(L24);
                code.visitJumpStmt(GOTO,-1,-1,L12);
                code.visitLabel(L25);
                code.visitTypeStmt(CHECK_CAST,3,-1,"Ljava/io/IOException;");
                code.visitLabel(L26);
                code.visitStmt1R(THROW,3);
                code.visitLabel(L9);
                code.visitStmt1R(MOVE_EXCEPTION,6);
                code.visitStmt2R(MOVE_OBJECT,2,6);
                code.visitLabel(L27);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2},new Method("Lorg/mortbay/log/Log;","ignore",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L12);
                code.visitLabel(L28);
                code.visitStmt1R(RETURN_OBJECT,1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_addAuthorization(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/client/HttpDestination;","addAuthorization",new String[]{ "Ljava/lang/String;","Lorg/mortbay/jetty/client/security/Authorization;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"pathSpec");
                ddv.visitParameterName(1,"authorization");
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(113,L3);
                ddv.visitLineNumber(115,L0);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(116,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(117,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(118,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(121,L7);
                ddv.visitLineNumber(118,L2);
                code.visitLabel(L3);
                code.visitStmt1R(MONITOR_ENTER,1);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/client/HttpDestination;","_authorizations","Lorg/mortbay/jetty/servlet/PathMap;"));
                code.visitJumpStmt(IF_NEZ,0,-1,L5);
                code.visitLabel(L4);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/jetty/servlet/PathMap;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Lorg/mortbay/jetty/servlet/PathMap;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/client/HttpDestination;","_authorizations","Lorg/mortbay/jetty/servlet/PathMap;"));
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/client/HttpDestination;","_authorizations","Lorg/mortbay/jetty/servlet/PathMap;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,2,3},new Method("Lorg/mortbay/jetty/servlet/PathMap;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L6);
                code.visitStmt1R(MONITOR_EXIT,1);
                code.visitLabel(L7);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,0);
                code.visitStmt1R(MONITOR_EXIT,1);
                code.visitLabel(L1);
                code.visitStmt1R(THROW,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_addCookie(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/client/HttpDestination;","addCookie",new String[]{ "Ljavax/servlet/http/Cookie;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"cookie");
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(126,L3);
                ddv.visitLineNumber(128,L0);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(129,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(130,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(131,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(134,L7);
                ddv.visitLineNumber(131,L2);
                code.visitLabel(L3);
                code.visitStmt1R(MONITOR_ENTER,1);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/client/HttpDestination;","_cookies","Ljava/util/List;"));
                code.visitJumpStmt(IF_NEZ,0,-1,L5);
                code.visitLabel(L4);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/util/ArrayList;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/util/ArrayList;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/client/HttpDestination;","_cookies","Ljava/util/List;"));
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/client/HttpDestination;","_cookies","Ljava/util/List;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,2},new Method("Ljava/util/List;","add",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitLabel(L6);
                code.visitStmt1R(MONITOR_EXIT,1);
                code.visitLabel(L7);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,0);
                code.visitStmt1R(MONITOR_EXIT,1);
                code.visitLabel(L1);
                code.visitStmt1R(THROW,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_close(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/client/HttpDestination;","close",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L5=new DexLabel();
                ddv.visitPrologue(L5);
                ddv.visitLineNumber(538,L5);
                ddv.visitLineNumber(540,L0);
                DexLabel L6=new DexLabel();
                ddv.visitStartLocal(1,L6,"i$","Ljava/util/Iterator;",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(542,L7);
                ddv.visitStartLocal(0,L7,"connection","Lorg/mortbay/jetty/client/HttpConnection;",null);
                ddv.visitLineNumber(544,L2);
                ddv.visitEndLocal(1,L2);
                ddv.visitEndLocal(0,L2);
                ddv.visitRestartLocal(1,L3);
                ddv.visitLineNumber(545,L4);
                code.visitLabel(L5);
                code.visitStmt1R(MONITOR_ENTER,3);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,2,3,new Field("Lorg/mortbay/jetty/client/HttpDestination;","_connections","Ljava/util/LinkedList;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/util/LinkedList;","iterator",new String[]{ },"Ljava/util/Iterator;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Ljava/util/Iterator;","hasNext",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_EQZ,2,-1,L3);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Ljava/util/Iterator;","next",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Lorg/mortbay/jetty/client/HttpConnection;");
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/client/HttpConnection;","close",new String[]{ },"V"));
                code.visitJumpStmt(GOTO,-1,-1,L6);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,2);
                code.visitStmt1R(MONITOR_EXIT,3);
                code.visitLabel(L1);
                code.visitStmt1R(THROW,2);
                code.visitLabel(L3);
                code.visitStmt1R(MONITOR_EXIT,3);
                code.visitLabel(L4);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_doSend(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/client/HttpDestination;","doSend",new String[]{ "Lorg/mortbay/jetty/client/HttpExchange;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(9);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"ex");
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(433,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(435,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(436,L5);
                ddv.visitStartLocal(1,L5,"buf","Ljava/lang/StringBuilder;",null);
                DexLabel L6=new DexLabel();
                ddv.visitStartLocal(4,L6,"i$","Ljava/util/Iterator;",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(438,L7);
                ddv.visitStartLocal(3,L7,"cookie","Ljavax/servlet/http/Cookie;",null);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(439,L8);
                DexLabel L9=new DexLabel();
                ddv.visitEndLocal(1,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(442,L10);
                ddv.visitRestartLocal(1,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(443,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(444,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(441,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(446,L14);
                ddv.visitEndLocal(3,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(447,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(451,L16);
                ddv.visitEndLocal(4,L16);
                ddv.visitEndLocal(1,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(453,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(454,L18);
                ddv.visitStartLocal(0,L18,"auth","Lorg/mortbay/jetty/client/security/Authorization;",null);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(455,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(458,L20);
                ddv.visitEndLocal(0,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(462,L21);
                ddv.visitLineNumber(463,L0);
                ddv.visitStartLocal(2,L0,"connection","Lorg/mortbay/jetty/client/HttpConnection;",null);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(465,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(466,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(468,L24);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(471,L25);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(472,L26);
                ddv.visitLineNumber(471,L2);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,5,7,new Field("Lorg/mortbay/jetty/client/HttpDestination;","_cookies","Ljava/util/List;"));
                code.visitJumpStmt(IF_EQZ,5,-1,L16);
                code.visitLabel(L4);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,5,7,new Field("Lorg/mortbay/jetty/client/HttpDestination;","_cookies","Ljava/util/List;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 5},new Method("Ljava/util/List;","iterator",new String[]{ },"Ljava/util/Iterator;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 4},new Method("Ljava/util/Iterator;","hasNext",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitJumpStmt(IF_EQZ,5,-1,L14);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 4},new Method("Ljava/util/Iterator;","next",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitTypeStmt(CHECK_CAST,3,-1,"Ljavax/servlet/http/Cookie;");
                code.visitLabel(L7);
                code.visitJumpStmt(IF_NEZ,1,-1,L13);
                code.visitLabel(L8);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/lang/StringBuilder;");
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljavax/servlet/http/Cookie;","getName",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitLabel(L11);
                code.visitConstStmt(CONST_STRING,5,"=");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitLabel(L12);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljavax/servlet/http/Cookie;","getValue",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitJumpStmt(GOTO,-1,-1,L6);
                code.visitLabel(L13);
                code.visitConstStmt(CONST_STRING,5,"; ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitJumpStmt(GOTO,-1,-1,L10);
                code.visitLabel(L14);
                code.visitJumpStmt(IF_EQZ,1,-1,L16);
                code.visitLabel(L15);
                code.visitConstStmt(CONST_STRING,5,"Cookie");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,5,6},new Method("Lorg/mortbay/jetty/client/HttpExchange;","addRequestHeader",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"V"));
                code.visitLabel(L16);
                code.visitFieldStmt(IGET_OBJECT,5,7,new Field("Lorg/mortbay/jetty/client/HttpDestination;","_authorizations","Lorg/mortbay/jetty/servlet/PathMap;"));
                code.visitJumpStmt(IF_EQZ,5,-1,L20);
                code.visitLabel(L17);
                code.visitFieldStmt(IGET_OBJECT,5,7,new Field("Lorg/mortbay/jetty/client/HttpDestination;","_authorizations","Lorg/mortbay/jetty/servlet/PathMap;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Lorg/mortbay/jetty/client/HttpExchange;","getURI",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Lorg/mortbay/jetty/servlet/PathMap;","match",new String[]{ "Ljava/lang/String;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Lorg/mortbay/jetty/client/security/Authorization;");
                code.visitLabel(L18);
                code.visitJumpStmt(IF_EQZ,0,-1,L20);
                code.visitLabel(L19);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,8},new Method("Lorg/mortbay/jetty/client/security/Authorization;","setCredentials",new String[]{ "Lorg/mortbay/jetty/client/HttpExchange;"},"V"));
                code.visitLabel(L20);
                code.visitStmt1R(MONITOR_ENTER,7);
                code.visitLabel(L21);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,5,7,new Field("Lorg/mortbay/jetty/client/HttpDestination;","_queue","Ljava/util/LinkedList;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/util/LinkedList;","size",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitJumpStmt(IF_GTZ,5,-1,L22);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Lorg/mortbay/jetty/client/HttpDestination;","getIdleConnection",new String[]{ },"Lorg/mortbay/jetty/client/HttpConnection;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitJumpStmt(IF_EQZ,2,-1,L22);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,8},new Method("Lorg/mortbay/jetty/client/HttpConnection;","send",new String[]{ "Lorg/mortbay/jetty/client/HttpExchange;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitJumpStmt(IF_NEZ,5,-1,L25);
                code.visitLabel(L22);
                code.visitFieldStmt(IGET_OBJECT,5,7,new Field("Lorg/mortbay/jetty/client/HttpDestination;","_queue","Ljava/util/LinkedList;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,8},new Method("Ljava/util/LinkedList;","add",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitLabel(L23);
                code.visitFieldStmt(IGET_OBJECT,5,7,new Field("Lorg/mortbay/jetty/client/HttpDestination;","_connections","Ljava/util/LinkedList;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/util/LinkedList;","size",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitFieldStmt(IGET,6,7,new Field("Lorg/mortbay/jetty/client/HttpDestination;","_pendingConnections","I"));
                code.visitStmt2R(ADD_INT_2ADDR,5,6);
                code.visitFieldStmt(IGET,6,7,new Field("Lorg/mortbay/jetty/client/HttpDestination;","_maxConnections","I"));
                code.visitJumpStmt(IF_GE,5,6,L25);
                code.visitLabel(L24);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Lorg/mortbay/jetty/client/HttpDestination;","startNewConnection",new String[]{ },"V"));
                code.visitLabel(L25);
                code.visitStmt1R(MONITOR_EXIT,7);
                code.visitLabel(L26);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,5);
                code.visitStmt1R(MONITOR_EXIT,7);
                code.visitLabel(L1);
                code.visitStmt1R(THROW,5);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_dump(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/client/HttpDestination;","dump",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L5=new DexLabel();
                ddv.visitPrologue(L5);
                ddv.visitLineNumber(57,L5);
                ddv.visitLineNumber(59,L0);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(60,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(61,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(62,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(63,L9);
                DexLabel L10=new DexLabel();
                ddv.visitStartLocal(1,L10,"i$","Ljava/util/Iterator;",null);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(65,L11);
                ddv.visitStartLocal(0,L11,"c","Lorg/mortbay/jetty/client/HttpConnection;",null);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(66,L12);
                ddv.visitLineNumber(68,L2);
                ddv.visitEndLocal(1,L2);
                ddv.visitEndLocal(0,L2);
                ddv.visitRestartLocal(1,L3);
                ddv.visitLineNumber(69,L4);
                code.visitLabel(L5);
                code.visitStmt1R(MONITOR_ENTER,5);
                code.visitLabel(L0);
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Ljava/lang/System;","err","Ljava/io/PrintStream;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,5},new Method("Ljava/io/PrintStream;","println",new String[]{ "Ljava/lang/Object;"},"V"));
                code.visitLabel(L6);
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Ljava/lang/System;","err","Ljava/io/PrintStream;"));
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,4,"connections=");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitFieldStmt(IGET_OBJECT,4,5,new Field("Lorg/mortbay/jetty/client/HttpDestination;","_connections","Ljava/util/LinkedList;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/util/LinkedList;","size",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "I"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/io/PrintStream;","println",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L7);
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Ljava/lang/System;","err","Ljava/io/PrintStream;"));
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,4,"idle=");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitFieldStmt(IGET_OBJECT,4,5,new Field("Lorg/mortbay/jetty/client/HttpDestination;","_idle","Ljava/util/ArrayList;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/util/ArrayList;","size",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "I"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/io/PrintStream;","println",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L8);
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Ljava/lang/System;","err","Ljava/io/PrintStream;"));
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,4,"pending=");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitFieldStmt(IGET,4,5,new Field("Lorg/mortbay/jetty/client/HttpDestination;","_pendingConnections","I"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "I"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/io/PrintStream;","println",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L9);
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/jetty/client/HttpDestination;","_connections","Ljava/util/LinkedList;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/util/LinkedList;","iterator",new String[]{ },"Ljava/util/Iterator;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Ljava/util/Iterator;","hasNext",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_EQZ,2,-1,L3);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Ljava/util/Iterator;","next",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Lorg/mortbay/jetty/client/HttpConnection;");
                code.visitLabel(L11);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/client/HttpConnection;","isIdle",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_NEZ,2,-1,L10);
                code.visitLabel(L12);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/client/HttpConnection;","dump",new String[]{ },"V"));
                code.visitJumpStmt(GOTO,-1,-1,L10);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,2);
                code.visitStmt1R(MONITOR_EXIT,5);
                code.visitLabel(L1);
                code.visitStmt1R(THROW,2);
                code.visitLabel(L3);
                code.visitStmt1R(MONITOR_EXIT,5);
                code.visitLabel(L4);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m007_getAddress(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/client/HttpDestination;","getAddress",new String[]{ },"Lorg/mortbay/jetty/client/Address;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(89,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/client/HttpDestination;","_address","Lorg/mortbay/jetty/client/Address;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m008_getHostHeader(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/client/HttpDestination;","getHostHeader",new String[]{ },"Lorg/mortbay/io/Buffer;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(95,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/client/HttpDestination;","_hostHeader","Lorg/mortbay/io/ByteArrayBuffer;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m009_getHttpClient(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/client/HttpDestination;","getHttpClient",new String[]{ },"Lorg/mortbay/jetty/client/HttpClient;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(101,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/client/HttpDestination;","_client","Lorg/mortbay/jetty/client/HttpClient;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m010_getIdleConnection(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/client/HttpDestination;","getIdleConnection",new String[]{ },"Lorg/mortbay/jetty/client/HttpConnection;"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(11);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L5=new DexLabel();
                ddv.visitPrologue(L5);
                ddv.visitLineNumber(209,L5);
                ddv.visitLineNumber(211,L0);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(212,L6);
                ddv.visitStartLocal(5,L6,"now","J",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(215,L7);
                ddv.visitStartLocal(1,L7,"idleTimeout","J",null);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(217,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(218,L9);
                ddv.visitStartLocal(0,L9,"connection","Lorg/mortbay/jetty/client/HttpConnection;",null);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(219,L10);
                ddv.visitStartLocal(3,L10,"last","J",null);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(220,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(228,L12);
                ddv.visitEndLocal(0,L12);
                ddv.visitEndLocal(3,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(223,L13);
                ddv.visitRestartLocal(0,L13);
                ddv.visitRestartLocal(3,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(224,L14);
                ddv.visitLineNumber(229,L2);
                ddv.visitEndLocal(5,L2);
                ddv.visitEndLocal(1,L2);
                ddv.visitEndLocal(0,L2);
                ddv.visitEndLocal(3,L2);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(228,L15);
                ddv.visitRestartLocal(1,L15);
                ddv.visitRestartLocal(5,L15);
                code.visitLabel(L5);
                code.visitStmt1R(MONITOR_ENTER,10);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Ljava/lang/System;","currentTimeMillis",new String[]{ },"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,5);
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,7,10,new Field("Lorg/mortbay/jetty/client/HttpDestination;","_client","Lorg/mortbay/jetty/client/HttpClient;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Lorg/mortbay/jetty/client/HttpClient;","getIdleTimeout",new String[]{ },"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,1);
                code.visitLabel(L7);
                code.visitFieldStmt(IGET_OBJECT,7,10,new Field("Lorg/mortbay/jetty/client/HttpDestination;","_idle","Ljava/util/ArrayList;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Ljava/util/ArrayList;","size",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitJumpStmt(IF_LEZ,7,-1,L15);
                code.visitLabel(L8);
                code.visitFieldStmt(IGET_OBJECT,7,10,new Field("Lorg/mortbay/jetty/client/HttpDestination;","_idle","Ljava/util/ArrayList;"));
                code.visitFieldStmt(IGET_OBJECT,8,10,new Field("Lorg/mortbay/jetty/client/HttpDestination;","_idle","Ljava/util/ArrayList;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Ljava/util/ArrayList;","size",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitConstStmt(CONST_4,9, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt2R(SUB_INT_2ADDR,8,9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,8},new Method("Ljava/util/ArrayList;","remove",new String[]{ "I"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Lorg/mortbay/jetty/client/HttpConnection;");
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/client/HttpConnection;","getLast",new String[]{ },"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,3);
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/client/HttpConnection;","getEndPoint",new String[]{ },"Lorg/mortbay/io/EndPoint;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 7},new Method("Lorg/mortbay/io/EndPoint;","isOpen",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitJumpStmt(IF_EQZ,7,-1,L13);
                code.visitConstStmt(CONST_WIDE_16,7,Long.valueOf(0L)); // long: 0x0000000000000000  double:0.000000
                code.visitStmt3R(CMP_LONG,7,3,7);
                code.visitJumpStmt(IF_EQZ,7,-1,L11);
                code.visitStmt3R(SUB_LONG,7,5,3);
                code.visitStmt3R(CMP_LONG,7,7,1);
                code.visitJumpStmt(IF_GEZ,7,-1,L13);
                code.visitLabel(L11);
                code.visitStmt1R(MONITOR_EXIT,10);
                code.visitStmt2R(MOVE_OBJECT,7,0);
                code.visitLabel(L12);
                code.visitStmt1R(RETURN_OBJECT,7);
                code.visitLabel(L13);
                code.visitFieldStmt(IGET_OBJECT,7,10,new Field("Lorg/mortbay/jetty/client/HttpDestination;","_connections","Ljava/util/LinkedList;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,0},new Method("Ljava/util/LinkedList;","remove",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitLabel(L14);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/client/HttpConnection;","getEndPoint",new String[]{ },"Lorg/mortbay/io/EndPoint;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 7},new Method("Lorg/mortbay/io/EndPoint;","close",new String[]{ },"V"));
                code.visitJumpStmt(GOTO,-1,-1,L7);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,7);
                code.visitStmt1R(MONITOR_EXIT,10);
                code.visitLabel(L1);
                code.visitStmt1R(THROW,7);
                code.visitLabel(L15);
                code.visitConstStmt(CONST_4,7, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L3);
                code.visitStmt1R(MONITOR_EXIT,10);
                code.visitLabel(L4);
                code.visitJumpStmt(GOTO,-1,-1,L12);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m011_getProxy(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/client/HttpDestination;","getProxy",new String[]{ },"Lorg/mortbay/jetty/client/Address;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(514,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/client/HttpDestination;","_proxy","Lorg/mortbay/jetty/client/Address;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m012_getProxyAuthentication(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/client/HttpDestination;","getProxyAuthentication",new String[]{ },"Lorg/mortbay/jetty/client/security/Authorization;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(520,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/client/HttpDestination;","_proxyAuthentication","Lorg/mortbay/jetty/client/security/Authorization;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m013_isProxied(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/client/HttpDestination;","isProxied",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(532,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/client/HttpDestination;","_proxy","Lorg/mortbay/jetty/client/Address;"));
                DexLabel L1=new DexLabel();
                code.visitJumpStmt(IF_EQZ,0,-1,L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                DexLabel L2=new DexLabel();
                code.visitLabel(L2);
                code.visitStmt1R(RETURN,0);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m014_isSecure(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/client/HttpDestination;","isSecure",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(107,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_BOOLEAN,0,1,new Field("Lorg/mortbay/jetty/client/HttpDestination;","_ssl","Z"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m015_onConnectionFailed(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/client/HttpDestination;","onConnectionFailed",new String[]{ "Ljava/lang/Throwable;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                DexLabel L5=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L5},new String[]{ "Ljava/lang/InterruptedException;"});
                DexLabel L6=new DexLabel();
                DexLabel L7=new DexLabel();
                code.visitTryCatch(L6,L7,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"throwable");
                DexLabel L8=new DexLabel();
                ddv.visitPrologue(L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(252,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(254,L10);
                ddv.visitStartLocal(0,L10,"connect_failure","Ljava/lang/Throwable;",null);
                ddv.visitLineNumber(256,L0);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(257,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(259,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(260,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(267,L14);
                ddv.visitLineNumber(269,L1);
                ddv.visitLineNumber(273,L3);
                ddv.visitLineNumber(280,L4);
                ddv.visitLineNumber(262,L6);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(264,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(265,L16);
                ddv.visitStartLocal(2,L16,"ex","Lorg/mortbay/jetty/client/HttpExchange;",null);
                ddv.visitLineNumber(267,L2);
                ddv.visitEndLocal(2,L2);
                ddv.visitLineNumber(275,L5);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(277,L17);
                ddv.visitStartLocal(1,L17,"e","Ljava/lang/InterruptedException;",null);
                code.visitLabel(L8);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L9);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L10);
                code.visitStmt1R(MONITOR_ENTER,5);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,3,5,new Field("Lorg/mortbay/jetty/client/HttpDestination;","_pendingConnections","I"));
                code.visitStmt2R(SUB_INT_2ADDR,3,4);
                code.visitFieldStmt(IPUT,3,5,new Field("Lorg/mortbay/jetty/client/HttpDestination;","_pendingConnections","I"));
                code.visitLabel(L11);
                code.visitFieldStmt(IGET,3,5,new Field("Lorg/mortbay/jetty/client/HttpDestination;","_newConnection","I"));
                code.visitJumpStmt(IF_LEZ,3,-1,L6);
                code.visitLabel(L12);
                code.visitStmt2R(MOVE_OBJECT,0,6);
                code.visitLabel(L13);
                code.visitFieldStmt(IGET,3,5,new Field("Lorg/mortbay/jetty/client/HttpDestination;","_newConnection","I"));
                code.visitStmt2R(SUB_INT_2ADDR,3,4);
                code.visitFieldStmt(IPUT,3,5,new Field("Lorg/mortbay/jetty/client/HttpDestination;","_newConnection","I"));
                code.visitLabel(L14);
                code.visitStmt1R(MONITOR_EXIT,5);
                code.visitLabel(L1);
                code.visitJumpStmt(IF_EQZ,0,-1,L4);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,3,5,new Field("Lorg/mortbay/jetty/client/HttpDestination;","_newQueue","Ljava/util/concurrent/ArrayBlockingQueue;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,0},new Method("Ljava/util/concurrent/ArrayBlockingQueue;","put",new String[]{ "Ljava/lang/Object;"},"V"));
                code.visitLabel(L4);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,3,5,new Field("Lorg/mortbay/jetty/client/HttpDestination;","_queue","Ljava/util/LinkedList;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/util/LinkedList;","size",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_LEZ,3,-1,L14);
                code.visitLabel(L15);
                code.visitFieldStmt(IGET_OBJECT,3,5,new Field("Lorg/mortbay/jetty/client/HttpDestination;","_queue","Ljava/util/LinkedList;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/util/LinkedList;","removeFirst",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitTypeStmt(CHECK_CAST,2,-1,"Lorg/mortbay/jetty/client/HttpExchange;");
                code.visitLabel(L16);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/client/HttpExchange;","getEventListener",new String[]{ },"Lorg/mortbay/jetty/client/HttpEventListener;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3,6},new Method("Lorg/mortbay/jetty/client/HttpEventListener;","onConnectionFailed",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L14);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,3);
                code.visitStmt1R(MONITOR_EXIT,5);
                code.visitLabel(L7);
                code.visitStmt1R(THROW,3);
                code.visitLabel(L5);
                code.visitStmt1R(MOVE_EXCEPTION,3);
                code.visitStmt2R(MOVE_OBJECT,1,3);
                code.visitLabel(L17);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1},new Method("Lorg/mortbay/log/Log;","ignore",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m016_onException(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/client/HttpDestination;","onException",new String[]{ "Ljava/lang/Throwable;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"throwable");
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(285,L3);
                ddv.visitLineNumber(287,L0);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(288,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(290,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(291,L6);
                ddv.visitStartLocal(0,L6,"ex","Lorg/mortbay/jetty/client/HttpExchange;",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(292,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(294,L8);
                ddv.visitEndLocal(0,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(295,L9);
                ddv.visitLineNumber(294,L2);
                code.visitLabel(L3);
                code.visitStmt1R(MONITOR_ENTER,3);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,1,3,new Field("Lorg/mortbay/jetty/client/HttpDestination;","_pendingConnections","I"));
                code.visitConstStmt(CONST_4,2, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt2R(SUB_INT_2ADDR,1,2);
                code.visitFieldStmt(IPUT,1,3,new Field("Lorg/mortbay/jetty/client/HttpDestination;","_pendingConnections","I"));
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/jetty/client/HttpDestination;","_queue","Ljava/util/LinkedList;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/util/LinkedList;","size",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_LEZ,1,-1,L8);
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/jetty/client/HttpDestination;","_queue","Ljava/util/LinkedList;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/util/LinkedList;","removeFirst",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Lorg/mortbay/jetty/client/HttpExchange;");
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/client/HttpExchange;","getEventListener",new String[]{ },"Lorg/mortbay/jetty/client/HttpEventListener;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1,4},new Method("Lorg/mortbay/jetty/client/HttpEventListener;","onException",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitLabel(L7);
                code.visitConstStmt(CONST_16,1, Integer.valueOf(9)); // int: 0x00000009  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/client/HttpExchange;","setStatus",new String[]{ "I"},"V"));
                code.visitLabel(L8);
                code.visitStmt1R(MONITOR_EXIT,3);
                code.visitLabel(L9);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitStmt1R(MONITOR_EXIT,3);
                code.visitLabel(L1);
                code.visitStmt1R(THROW,1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m017_onNewConnection(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/client/HttpDestination;","onNewConnection",new String[]{ "Lorg/mortbay/jetty/client/HttpConnection;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                DexLabel L5=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L5},new String[]{ "Ljava/lang/InterruptedException;"});
                DexLabel L6=new DexLabel();
                DexLabel L7=new DexLabel();
                code.visitTryCatch(L6,L7,new DexLabel[]{L2},new String[]{ null});
                DexLabel L8=new DexLabel();
                DexLabel L9=new DexLabel();
                code.visitTryCatch(L8,L9,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"connection");
                DexLabel L10=new DexLabel();
                ddv.visitPrologue(L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(300,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(302,L12);
                ddv.visitStartLocal(2,L12,"q_connection","Lorg/mortbay/jetty/client/HttpConnection;",null);
                ddv.visitLineNumber(304,L0);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(305,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(307,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(309,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(310,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(321,L17);
                ddv.visitLineNumber(323,L1);
                ddv.visitLineNumber(327,L3);
                ddv.visitLineNumber(334,L4);
                ddv.visitLineNumber(312,L6);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(314,L18);
                ddv.visitLineNumber(321,L2);
                ddv.visitLineNumber(318,L8);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(319,L19);
                ddv.visitStartLocal(1,L19,"ex","Lorg/mortbay/jetty/client/HttpExchange;",null);
                ddv.visitLineNumber(329,L5);
                ddv.visitEndLocal(1,L5);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(331,L20);
                ddv.visitStartLocal(0,L20,"e","Ljava/lang/InterruptedException;",null);
                code.visitLabel(L10);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L11);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L12);
                code.visitStmt1R(MONITOR_ENTER,5);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,3,5,new Field("Lorg/mortbay/jetty/client/HttpDestination;","_pendingConnections","I"));
                code.visitStmt2R(SUB_INT_2ADDR,3,4);
                code.visitFieldStmt(IPUT,3,5,new Field("Lorg/mortbay/jetty/client/HttpDestination;","_pendingConnections","I"));
                code.visitLabel(L13);
                code.visitFieldStmt(IGET_OBJECT,3,5,new Field("Lorg/mortbay/jetty/client/HttpDestination;","_connections","Ljava/util/LinkedList;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,6},new Method("Ljava/util/LinkedList;","add",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitLabel(L14);
                code.visitFieldStmt(IGET,3,5,new Field("Lorg/mortbay/jetty/client/HttpDestination;","_newConnection","I"));
                code.visitJumpStmt(IF_LEZ,3,-1,L6);
                code.visitLabel(L15);
                code.visitStmt2R(MOVE_OBJECT,2,6);
                code.visitLabel(L16);
                code.visitFieldStmt(IGET,3,5,new Field("Lorg/mortbay/jetty/client/HttpDestination;","_newConnection","I"));
                code.visitStmt2R(SUB_INT_2ADDR,3,4);
                code.visitFieldStmt(IPUT,3,5,new Field("Lorg/mortbay/jetty/client/HttpDestination;","_newConnection","I"));
                code.visitLabel(L17);
                code.visitStmt1R(MONITOR_EXIT,5);
                code.visitLabel(L1);
                code.visitJumpStmt(IF_EQZ,2,-1,L4);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,3,5,new Field("Lorg/mortbay/jetty/client/HttpDestination;","_newQueue","Ljava/util/concurrent/ArrayBlockingQueue;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,2},new Method("Ljava/util/concurrent/ArrayBlockingQueue;","put",new String[]{ "Ljava/lang/Object;"},"V"));
                code.visitLabel(L4);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,3,5,new Field("Lorg/mortbay/jetty/client/HttpDestination;","_queue","Ljava/util/LinkedList;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/util/LinkedList;","size",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_NEZ,3,-1,L8);
                code.visitLabel(L18);
                code.visitFieldStmt(IGET_OBJECT,3,5,new Field("Lorg/mortbay/jetty/client/HttpDestination;","_idle","Ljava/util/ArrayList;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,6},new Method("Ljava/util/ArrayList;","add",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitJumpStmt(GOTO,-1,-1,L17);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,3);
                code.visitStmt1R(MONITOR_EXIT,5);
                code.visitLabel(L7);
                code.visitStmt1R(THROW,3);
                code.visitLabel(L8);
                code.visitFieldStmt(IGET_OBJECT,3,5,new Field("Lorg/mortbay/jetty/client/HttpDestination;","_queue","Ljava/util/LinkedList;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/util/LinkedList;","removeFirst",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitTypeStmt(CHECK_CAST,1,-1,"Lorg/mortbay/jetty/client/HttpExchange;");
                code.visitLabel(L19);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,1},new Method("Lorg/mortbay/jetty/client/HttpConnection;","send",new String[]{ "Lorg/mortbay/jetty/client/HttpExchange;"},"Z"));
                code.visitLabel(L9);
                code.visitJumpStmt(GOTO,-1,-1,L17);
                code.visitLabel(L5);
                code.visitStmt1R(MOVE_EXCEPTION,3);
                code.visitStmt2R(MOVE_OBJECT,0,3);
                code.visitLabel(L20);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/log/Log;","ignore",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m018_resend(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/client/HttpDestination;","resend",new String[]{ "Lorg/mortbay/jetty/client/HttpExchange;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"ex");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(424,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(425,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(426,L2);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/client/HttpExchange;","getEventListener",new String[]{ },"Lorg/mortbay/jetty/client/HttpEventListener;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Lorg/mortbay/jetty/client/HttpEventListener;","onRetry",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Lorg/mortbay/jetty/client/HttpDestination;","doSend",new String[]{ "Lorg/mortbay/jetty/client/HttpExchange;"},"V"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m019_reserveConnection(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/client/HttpDestination;","reserveConnection",new String[]{ "J"},"Lorg/mortbay/jetty/client/HttpConnection;"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"timeout");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(200,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(201,L1);
                ddv.visitStartLocal(0,L1,"connection","Lorg/mortbay/jetty/client/HttpConnection;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(202,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(203,L3);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2,3,4},new Method("Lorg/mortbay/jetty/client/HttpDestination;","getConnection",new String[]{ "J"},"Lorg/mortbay/jetty/client/HttpConnection;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L1);
                code.visitJumpStmt(IF_EQZ,0,-1,L3);
                code.visitLabel(L2);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/client/HttpConnection;","setReserved",new String[]{ "Z"},"V"));
                code.visitLabel(L3);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m020_returnConnection(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/client/HttpDestination;","returnConnection",new String[]{ "Lorg/mortbay/jetty/client/HttpConnection;","Z"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/io/IOException;"});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                DexLabel L5=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L5},new String[]{ null});
                DexLabel L6=new DexLabel();
                DexLabel L7=new DexLabel();
                code.visitTryCatch(L6,L7,new DexLabel[]{L5},new String[]{ null});
                DexLabel L8=new DexLabel();
                DexLabel L9=new DexLabel();
                DexLabel L10=new DexLabel();
                code.visitTryCatch(L8,L9,new DexLabel[]{L10},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"connection");
                ddv.visitParameterName(1,"close");
                DexLabel L11=new DexLabel();
                ddv.visitPrologue(L11);
                ddv.visitLineNumber(339,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(340,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(342,L13);
                ddv.visitLineNumber(346,L0);
                ddv.visitLineNumber(354,L1);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(383,L14);
                ddv.visitLineNumber(348,L2);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(350,L15);
                ddv.visitStartLocal(0,L15,"e","Ljava/io/IOException;",null);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(357,L16);
                ddv.visitEndLocal(0,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(359,L17);
                ddv.visitLineNumber(361,L3);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(363,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(364,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(371,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(372,L21);
                ddv.visitLineNumber(368,L6);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(369,L22);
                ddv.visitStartLocal(1,L22,"ex","Lorg/mortbay/jetty/client/HttpExchange;",null);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(376,L23);
                ddv.visitEndLocal(1,L23);
                ddv.visitLineNumber(378,L8);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(379,L24);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(380,L25);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(381,L26);
                code.visitLabel(L11);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/jetty/client/HttpConnection;","isReserved",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_EQZ,2,-1,L13);
                code.visitLabel(L12);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,2},new Method("Lorg/mortbay/jetty/client/HttpConnection;","setReserved",new String[]{ "Z"},"V"));
                code.visitLabel(L13);
                code.visitJumpStmt(IF_EQZ,6,-1,L1);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/jetty/client/HttpConnection;","close",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,2,4,new Field("Lorg/mortbay/jetty/client/HttpDestination;","_client","Lorg/mortbay/jetty/client/HttpClient;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/client/HttpClient;","isStarted",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_NEZ,2,-1,L16);
                code.visitLabel(L14);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,0);
                code.visitLabel(L15);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/log/Log;","ignore",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitLabel(L16);
                code.visitJumpStmt(IF_NEZ,6,-1,L23);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/jetty/client/HttpConnection;","getEndPoint",new String[]{ },"Lorg/mortbay/io/EndPoint;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2},new Method("Lorg/mortbay/io/EndPoint;","isOpen",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_EQZ,2,-1,L23);
                code.visitLabel(L17);
                code.visitStmt1R(MONITOR_ENTER,4);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,2,4,new Field("Lorg/mortbay/jetty/client/HttpDestination;","_queue","Ljava/util/LinkedList;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/util/LinkedList;","size",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_NEZ,2,-1,L6);
                code.visitLabel(L18);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Ljava/lang/System;","currentTimeMillis",new String[]{ },"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,2,3},new Method("Lorg/mortbay/jetty/client/HttpConnection;","setLast",new String[]{ "J"},"V"));
                code.visitLabel(L19);
                code.visitFieldStmt(IGET_OBJECT,2,4,new Field("Lorg/mortbay/jetty/client/HttpDestination;","_idle","Ljava/util/ArrayList;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,5},new Method("Ljava/util/ArrayList;","add",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitLabel(L20);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/lang/Object;","notifyAll",new String[]{ },"V"));
                code.visitLabel(L21);
                code.visitStmt1R(MONITOR_EXIT,4);
                code.visitJumpStmt(GOTO,-1,-1,L14);
                code.visitLabel(L5);
                code.visitStmt1R(MOVE_EXCEPTION,2);
                code.visitStmt1R(MONITOR_EXIT,4);
                code.visitLabel(L4);
                code.visitStmt1R(THROW,2);
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,2,4,new Field("Lorg/mortbay/jetty/client/HttpDestination;","_queue","Ljava/util/LinkedList;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/util/LinkedList;","removeFirst",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitTypeStmt(CHECK_CAST,1,-1,"Lorg/mortbay/jetty/client/HttpExchange;");
                code.visitLabel(L22);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,1},new Method("Lorg/mortbay/jetty/client/HttpConnection;","send",new String[]{ "Lorg/mortbay/jetty/client/HttpExchange;"},"Z"));
                code.visitLabel(L7);
                code.visitJumpStmt(GOTO,-1,-1,L20);
                code.visitLabel(L23);
                code.visitStmt1R(MONITOR_ENTER,4);
                code.visitLabel(L8);
                code.visitFieldStmt(IGET_OBJECT,2,4,new Field("Lorg/mortbay/jetty/client/HttpDestination;","_connections","Ljava/util/LinkedList;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,5},new Method("Ljava/util/LinkedList;","remove",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitLabel(L24);
                code.visitFieldStmt(IGET_OBJECT,2,4,new Field("Lorg/mortbay/jetty/client/HttpDestination;","_queue","Ljava/util/LinkedList;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/util/LinkedList;","isEmpty",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_NEZ,2,-1,L26);
                code.visitLabel(L25);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/jetty/client/HttpDestination;","startNewConnection",new String[]{ },"V"));
                code.visitLabel(L26);
                code.visitStmt1R(MONITOR_EXIT,4);
                code.visitJumpStmt(GOTO,-1,-1,L14);
                code.visitLabel(L10);
                code.visitStmt1R(MOVE_EXCEPTION,2);
                code.visitStmt1R(MONITOR_EXIT,4);
                code.visitLabel(L9);
                code.visitStmt1R(THROW,2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m021_send(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/client/HttpDestination;","send",new String[]{ "Lorg/mortbay/jetty/client/HttpExchange;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(13);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/lang/Exception;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"ex");
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(388,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(390,L5);
                ddv.visitStartLocal(6,L5,"listeners","Ljava/util/LinkedList;","Ljava/util/LinkedList<Ljava/lang/String;>;");
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(393,L6);
                DexLabel L7=new DexLabel();
                ddv.visitStartLocal(3,L7,"i","I",null);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(395,L8);
                ddv.visitLineNumber(399,L0);
                ddv.visitStartLocal(5,L0,"listenerClass","Ljava/lang/String;",null);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(400,L9);
                ddv.visitStartLocal(4,L9,"listener","Ljava/lang/Class;",null);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(401,L10);
                ddv.visitStartLocal(0,L10,"constructor","Ljava/lang/reflect/Constructor;",null);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(402,L11);
                ddv.visitStartLocal(2,L11,"elistener","Lorg/mortbay/jetty/client/HttpEventListener;",null);
                ddv.visitLineNumber(393,L1);
                ddv.visitLineNumber(404,L2);
                ddv.visitEndLocal(4,L2);
                ddv.visitEndLocal(0,L2);
                ddv.visitEndLocal(2,L2);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(406,L12);
                ddv.visitStartLocal(1,L12,"e","Ljava/lang/Exception;",null);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(407,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(413,L14);
                ddv.visitEndLocal(3,L14);
                ddv.visitEndLocal(5,L14);
                ddv.visitEndLocal(1,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(415,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(418,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(419,L17);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,10, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,7,11,new Field("Lorg/mortbay/jetty/client/HttpDestination;","_client","Lorg/mortbay/jetty/client/HttpClient;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Lorg/mortbay/jetty/client/HttpClient;","getRegisteredListeners",new String[]{ },"Ljava/util/LinkedList;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitLabel(L5);
                code.visitJumpStmt(IF_EQZ,6,-1,L14);
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/util/LinkedList;","size",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitLabel(L7);
                code.visitJumpStmt(IF_LEZ,3,-1,L14);
                code.visitLabel(L8);
                code.visitStmt3R(SUB_INT,7,3,10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,7},new Method("Ljava/util/LinkedList;","get",new String[]{ "I"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitTypeStmt(CHECK_CAST,5,-1,"Ljava/lang/String;");
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 5},new Method("Ljava/lang/Class;","forName",new String[]{ "Ljava/lang/String;"},"Ljava/lang/Class;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitLabel(L9);
                code.visitConstStmt(CONST_4,7, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitTypeStmt(NEW_ARRAY,7,7,"[Ljava/lang/Class;");
                code.visitConstStmt(CONST_4,8, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitConstStmt(CONST_CLASS,9,new DexType("Lorg/mortbay/jetty/client/HttpDestination;"));
                code.visitStmt3R(APUT_OBJECT,9,7,8);
                code.visitConstStmt(CONST_4,8, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitConstStmt(CONST_CLASS,9,new DexType("Lorg/mortbay/jetty/client/HttpExchange;"));
                code.visitStmt3R(APUT_OBJECT,9,7,8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,7},new Method("Ljava/lang/Class;","getDeclaredConstructor",new String[]{ "[Ljava/lang/Class;"},"Ljava/lang/reflect/Constructor;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L10);
                code.visitConstStmt(CONST_4,7, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitTypeStmt(NEW_ARRAY,7,7,"[Ljava/lang/Object;");
                code.visitConstStmt(CONST_4,8, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt3R(APUT_OBJECT,11,7,8);
                code.visitConstStmt(CONST_4,8, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt3R(APUT_OBJECT,12,7,8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,7},new Method("Ljava/lang/reflect/Constructor;","newInstance",new String[]{ "[Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitTypeStmt(CHECK_CAST,2,-1,"Lorg/mortbay/jetty/client/HttpEventListener;");
                code.visitLabel(L11);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12,2},new Method("Lorg/mortbay/jetty/client/HttpExchange;","setEventListener",new String[]{ "Lorg/mortbay/jetty/client/HttpEventListener;"},"V"));
                code.visitLabel(L1);
                code.visitStmt2R1N(ADD_INT_LIT8,3,3,-1);
                code.visitJumpStmt(GOTO,-1,-1,L7);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,7);
                code.visitStmt2R(MOVE_OBJECT,1,7);
                code.visitLabel(L12);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitLabel(L13);
                code.visitTypeStmt(NEW_INSTANCE,7,-1,"Ljava/io/IOException;");
                code.visitTypeStmt(NEW_INSTANCE,8,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 8},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,9,"Unable to instantiate registered listener for destination: ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,9},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 7,8},new Method("Ljava/io/IOException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,7);
                code.visitLabel(L14);
                code.visitFieldStmt(IGET_OBJECT,7,11,new Field("Lorg/mortbay/jetty/client/HttpDestination;","_client","Lorg/mortbay/jetty/client/HttpClient;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Lorg/mortbay/jetty/client/HttpClient;","hasRealms",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitJumpStmt(IF_EQZ,7,-1,L16);
                code.visitLabel(L15);
                code.visitTypeStmt(NEW_INSTANCE,7,-1,"Lorg/mortbay/jetty/client/security/SecurityListener;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 7,11,12},new Method("Lorg/mortbay/jetty/client/security/SecurityListener;","<init>",new String[]{ "Lorg/mortbay/jetty/client/HttpDestination;","Lorg/mortbay/jetty/client/HttpExchange;"},"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12,7},new Method("Lorg/mortbay/jetty/client/HttpExchange;","setEventListener",new String[]{ "Lorg/mortbay/jetty/client/HttpEventListener;"},"V"));
                code.visitLabel(L16);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11,12},new Method("Lorg/mortbay/jetty/client/HttpDestination;","doSend",new String[]{ "Lorg/mortbay/jetty/client/HttpExchange;"},"V"));
                code.visitLabel(L17);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m022_setProxy(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/client/HttpDestination;","setProxy",new String[]{ "Lorg/mortbay/jetty/client/Address;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"proxy");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(508,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(509,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/client/HttpDestination;","_proxy","Lorg/mortbay/jetty/client/Address;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m023_setProxyAuthentication(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/client/HttpDestination;","setProxyAuthentication",new String[]{ "Lorg/mortbay/jetty/client/security/Authorization;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"authentication");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(526,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(527,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/client/HttpDestination;","_proxyAuthentication","Lorg/mortbay/jetty/client/security/Authorization;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m024_startNewConnection(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/client/HttpDestination;","startNewConnection",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/lang/Exception;"});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                code.visitTryCatch(L1,L3,new DexLabel[]{L4},new String[]{ null});
                DexLabel L5=new DexLabel();
                code.visitTryCatch(L3,L5,new DexLabel[]{L2},new String[]{ "Ljava/lang/Exception;"});
                DexLabel L6=new DexLabel();
                DexLabel L7=new DexLabel();
                code.visitTryCatch(L6,L7,new DexLabel[]{L4},new String[]{ null});
                code.visitTryCatch(L7,L2,new DexLabel[]{L2},new String[]{ "Ljava/lang/Exception;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(237,L0);
                ddv.visitLineNumber(239,L1);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(240,L8);
                ddv.visitLineNumber(241,L3);
                ddv.visitLineNumber(247,L5);
                ddv.visitLineNumber(240,L4);
                ddv.visitLineNumber(243,L2);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(245,L9);
                ddv.visitStartLocal(0,L9,"e","Ljava/lang/Exception;",null);
                code.visitLabel(L0);
                code.visitStmt1R(MONITOR_ENTER,2);
                code.visitLabel(L1);
                code.visitFieldStmt(IGET,1,2,new Field("Lorg/mortbay/jetty/client/HttpDestination;","_pendingConnections","I"));
                code.visitStmt2R1N(ADD_INT_LIT8,1,1,1);
                code.visitFieldStmt(IPUT,1,2,new Field("Lorg/mortbay/jetty/client/HttpDestination;","_pendingConnections","I"));
                code.visitLabel(L8);
                code.visitStmt1R(MONITOR_EXIT,2);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/client/HttpDestination;","_client","Lorg/mortbay/jetty/client/HttpClient;"));
                code.visitFieldStmt(IGET_OBJECT,1,1,new Field("Lorg/mortbay/jetty/client/HttpClient;","_connector","Lorg/mortbay/jetty/client/HttpClient$Connector;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1,2},new Method("Lorg/mortbay/jetty/client/HttpClient$Connector;","startConnection",new String[]{ "Lorg/mortbay/jetty/client/HttpDestination;"},"V"));
                code.visitLabel(L5);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L4);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitLabel(L6);
                code.visitStmt1R(MONITOR_EXIT,2);
                code.visitLabel(L7);
                code.visitStmt1R(THROW,1);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitStmt2R(MOVE_OBJECT,0,1);
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,0},new Method("Lorg/mortbay/jetty/client/HttpDestination;","onConnectionFailed",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m025_toDetailString(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/client/HttpDestination;","toDetailString",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                code.visitTryCatch(L1,L3,new DexLabel[]{L4},new String[]{ null});
                code.visitTryCatch(L3,L2,new DexLabel[]{L2},new String[]{ null});
                DexLabel L5=new DexLabel();
                DexLabel L6=new DexLabel();
                code.visitTryCatch(L5,L6,new DexLabel[]{L4},new String[]{ null});
                DexLabel L7=new DexLabel();
                code.visitTryCatch(L6,L7,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L8=new DexLabel();
                ddv.visitPrologue(L8);
                ddv.visitLineNumber(483,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(484,L9);
                ddv.visitStartLocal(0,L9,"b","Ljava/lang/StringBuilder;",null);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(485,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(486,L11);
                ddv.visitLineNumber(488,L1);
                DexLabel L12=new DexLabel();
                ddv.visitStartLocal(2,L12,"i$","Ljava/util/Iterator;",null);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(490,L13);
                ddv.visitStartLocal(1,L13,"connection","Lorg/mortbay/jetty/client/HttpConnection;",null);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(492,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(493,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(494,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(495,L17);
                ddv.visitLineNumber(498,L4);
                ddv.visitEndLocal(2,L4);
                ddv.visitEndLocal(1,L4);
                ddv.visitLineNumber(483,L2);
                ddv.visitEndLocal(0,L2);
                ddv.visitLineNumber(498,L5);
                ddv.visitRestartLocal(0,L5);
                ddv.visitRestartLocal(2,L5);
                ddv.visitLineNumber(499,L6);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(500,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(502,L19);
                code.visitLabel(L8);
                code.visitStmt1R(MONITOR_ENTER,4);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/jetty/client/HttpDestination;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitLabel(L10);
                code.visitConstStmt(CONST_16,3, Integer.valueOf(10)); // int: 0x0000000a  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "C"},"Ljava/lang/StringBuilder;"));
                code.visitLabel(L11);
                code.visitStmt1R(MONITOR_ENTER,4);
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,3,4,new Field("Lorg/mortbay/jetty/client/HttpDestination;","_connections","Ljava/util/LinkedList;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/util/LinkedList;","iterator",new String[]{ },"Ljava/util/Iterator;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L12);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2},new Method("Ljava/util/Iterator;","hasNext",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_EQZ,3,-1,L5);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2},new Method("Ljava/util/Iterator;","next",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitTypeStmt(CHECK_CAST,1,-1,"Lorg/mortbay/jetty/client/HttpConnection;");
                code.visitLabel(L13);
                code.visitFieldStmt(IGET_OBJECT,3,1,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_exchange","Lorg/mortbay/jetty/client/HttpExchange;"));
                code.visitJumpStmt(IF_EQZ,3,-1,L12);
                code.visitLabel(L14);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/jetty/client/HttpConnection;","toDetailString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitLabel(L15);
                code.visitFieldStmt(IGET_OBJECT,3,4,new Field("Lorg/mortbay/jetty/client/HttpDestination;","_idle","Ljava/util/ArrayList;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,1},new Method("Ljava/util/ArrayList;","contains",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_EQZ,3,-1,L17);
                code.visitLabel(L16);
                code.visitConstStmt(CONST_STRING,3," IDLE");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitLabel(L17);
                code.visitConstStmt(CONST_16,3, Integer.valueOf(10)); // int: 0x0000000a  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "C"},"Ljava/lang/StringBuilder;"));
                code.visitJumpStmt(GOTO,-1,-1,L12);
                code.visitLabel(L4);
                code.visitStmt1R(MOVE_EXCEPTION,3);
                code.visitStmt1R(MONITOR_EXIT,4);
                code.visitLabel(L3);
                code.visitStmt1R(THROW,3);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,3);
                code.visitStmt1R(MONITOR_EXIT,4);
                code.visitStmt1R(THROW,3);
                code.visitLabel(L5);
                code.visitStmt1R(MONITOR_EXIT,4);
                code.visitLabel(L6);
                code.visitConstStmt(CONST_STRING,3,"--");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitLabel(L18);
                code.visitConstStmt(CONST_16,3, Integer.valueOf(10)); // int: 0x0000000a  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "C"},"Ljava/lang/StringBuilder;"));
                code.visitLabel(L19);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitLabel(L7);
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitStmt1R(MONITOR_EXIT,4);
                code.visitStmt1R(RETURN_OBJECT,3);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m026_toString(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/client/HttpDestination;","toString",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(477,L4);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_STRING,0,",");
                code.visitLabel(L4);
                code.visitStmt1R(MONITOR_ENTER,2);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,1,"HttpDestination@");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/lang/Object;","hashCode",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "I"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitConstStmt(CONST_STRING,1,"//");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/client/HttpDestination;","_address","Lorg/mortbay/jetty/client/Address;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/jetty/client/Address;","getHost",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitConstStmt(CONST_STRING,1,":");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/client/HttpDestination;","_address","Lorg/mortbay/jetty/client/Address;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/jetty/client/Address;","getPort",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "I"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitConstStmt(CONST_STRING,1,"(");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/client/HttpDestination;","_connections","Ljava/util/LinkedList;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/util/LinkedList;","size",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "I"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitConstStmt(CONST_STRING,1,",");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/client/HttpDestination;","_idle","Ljava/util/ArrayList;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/util/ArrayList;","size",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "I"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitConstStmt(CONST_STRING,1,",");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/client/HttpDestination;","_queue","Ljava/util/LinkedList;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/util/LinkedList;","size",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "I"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitConstStmt(CONST_STRING,1,")");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitLabel(L1);
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt1R(MONITOR_EXIT,2);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,0);
                code.visitStmt1R(MONITOR_EXIT,2);
                code.visitStmt1R(THROW,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
