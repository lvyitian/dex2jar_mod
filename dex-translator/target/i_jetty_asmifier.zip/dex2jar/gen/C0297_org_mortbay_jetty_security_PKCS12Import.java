package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0297_org_mortbay_jetty_security_PKCS12Import {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/jetty/security/PKCS12Import;","Ljava/lang/Object;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("PKCS12Import.java");
        m000__init_(cv);
        m001_dumpChain(cv);
        m002_main(cv);
        m003_readPassphrase(cv);
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/security/PKCS12Import;","<init>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(57,L0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/Object;","<init>",new String[]{ },"V"));
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001_dumpChain(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC, new Method("Lorg/mortbay/jetty/security/PKCS12Import;","dumpChain",new String[]{ "[Ljava/security/cert/Certificate;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"chain");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(124,L0);
                DexLabel L1=new DexLabel();
                ddv.visitStartLocal(1,L1,"i","I",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(125,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(126,L3);
                ddv.visitStartLocal(0,L3,"cert","Ljava/security/cert/Certificate;",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(127,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(128,L5);
                ddv.visitStartLocal(2,L5,"x509","Ljava/security/cert/X509Certificate;",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(129,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(124,L7);
                ddv.visitEndLocal(2,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(132,L8);
                ddv.visitEndLocal(0,L8);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitStmt2R(ARRAY_LENGTH,3,6);
                code.visitJumpStmt(IF_GE,1,3,L8);
                code.visitLabel(L2);
                code.visitStmt3R(AGET_OBJECT,0,6,1);
                code.visitLabel(L3);
                code.visitTypeStmt(INSTANCE_OF,3,0,"Ljava/security/cert/X509Certificate;");
                code.visitJumpStmt(IF_EQZ,3,-1,L7);
                code.visitLabel(L4);
                code.visitStmt3R(AGET_OBJECT,2,6,1);
                code.visitTypeStmt(CHECK_CAST,2,-1,"Ljava/security/cert/X509Certificate;");
                code.visitLabel(L5);
                code.visitFieldStmt(SGET_OBJECT,3,-1,new Field("Ljava/lang/System;","err","Ljava/io/PrintStream;"));
                code.visitTypeStmt(NEW_INSTANCE,4,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,5,"subject: ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/security/cert/X509Certificate;","getSubjectDN",new String[]{ },"Ljava/security/Principal;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/io/PrintStream;","println",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L6);
                code.visitFieldStmt(SGET_OBJECT,3,-1,new Field("Ljava/lang/System;","err","Ljava/io/PrintStream;"));
                code.visitTypeStmt(NEW_INSTANCE,4,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,5,"issuer: ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/security/cert/X509Certificate;","getIssuerDN",new String[]{ },"Ljava/security/Principal;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/io/PrintStream;","println",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L7);
                code.visitStmt2R1N(ADD_INT_LIT8,1,1,1);
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitLabel(L8);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_main(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/jetty/security/PKCS12Import;","main",new String[]{ "[Ljava/lang/String;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/Exception;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(11);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"args");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(61,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(62,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(64,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(67,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(69,L4);
                ddv.visitStartLocal(0,L4,"fileIn","Ljava/io/File;",null);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(70,L5);
                DexLabel L6=new DexLabel();
                ddv.visitEndLocal(10,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(75,L7);
                ddv.visitStartLocal(1,L7,"fileOut","Ljava/io/File;",null);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(76,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(78,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(81,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(82,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(84,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(87,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(88,L14);
                ddv.visitStartLocal(5,L14,"kspkcs12","Ljava/security/KeyStore;",null);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(90,L15);
                ddv.visitStartLocal(4,L15,"ksjks","Ljava/security/KeyStore;",null);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(91,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(92,L17);
                ddv.visitStartLocal(2,L17,"inphrase","[C",null);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(93,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(95,L19);
                ddv.visitStartLocal(7,L19,"outphrase","[C",null);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(97,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(101,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(102,L22);
                ddv.visitStartLocal(0,L22,"eAliases","Ljava/util/Enumeration;",null);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(103,L23);
                ddv.visitStartLocal(10,L23,"n","I",null);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(104,L24);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(105,L25);
                ddv.visitStartLocal(8,L25,"strAlias","Ljava/lang/String;",null);
                DexLabel L26=new DexLabel();
                ddv.visitStartLocal(6,L26,"n","I",null);
                DexLabel L27=new DexLabel();
                ddv.visitEndLocal(10,L27);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(107,L28);
                DexLabel L29=new DexLabel();
                ddv.visitLineNumber(108,L29);
                DexLabel L30=new DexLabel();
                ddv.visitLineNumber(109,L30);
                DexLabel L31=new DexLabel();
                ddv.visitLineNumber(111,L31);
                ddv.visitStartLocal(3,L31,"key","Ljava/security/Key;",null);
                DexLabel L32=new DexLabel();
                ddv.visitLineNumber(113,L32);
                ddv.visitStartLocal(10,L32,"chain","[Ljava/security/cert/Certificate;",null);
                DexLabel L33=new DexLabel();
                ddv.visitEndLocal(3,L33);
                ddv.visitEndLocal(10,L33);
                DexLabel L34=new DexLabel();
                ddv.visitLineNumber(115,L34);
                ddv.visitStartLocal(10,L34,"n","I",null);
                DexLabel L35=new DexLabel();
                ddv.visitLineNumber(72,L35);
                ddv.visitEndLocal(1,L35);
                ddv.visitEndLocal(5,L35);
                ddv.visitEndLocal(4,L35);
                ddv.visitEndLocal(2,L35);
                ddv.visitEndLocal(7,L35);
                ddv.visitEndLocal(8,L35);
                ddv.visitEndLocal(6,L35);
                ddv.visitStartLocal(0,L35,"fileIn","Ljava/io/File;",null);
                ddv.visitStartLocal(10,L35,"args","[Ljava/lang/String;",null);
                DexLabel L36=new DexLabel();
                ddv.visitEndLocal(10,L36);
                DexLabel L37=new DexLabel();
                ddv.visitStartLocal(10,L37,"fileOut","Ljava/io/File;",null);
                DexLabel L38=new DexLabel();
                ddv.visitRestartLocal(1,L38);
                DexLabel L39=new DexLabel();
                ddv.visitLineNumber(97,L39);
                ddv.visitEndLocal(10,L39);
                ddv.visitRestartLocal(2,L39);
                ddv.visitRestartLocal(4,L39);
                ddv.visitRestartLocal(5,L39);
                ddv.visitRestartLocal(7,L39);
                DexLabel L40=new DexLabel();
                ddv.visitLineNumber(117,L40);
                ddv.visitStartLocal(0,L40,"eAliases","Ljava/util/Enumeration;",null);
                ddv.visitStartLocal(10,L40,"n","I",null);
                DexLabel L41=new DexLabel();
                ddv.visitEndLocal(10,L41);
                DexLabel L42=new DexLabel();
                ddv.visitLineNumber(118,L42);
                ddv.visitStartLocal(10,L42,"out","Ljava/io/OutputStream;",null);
                DexLabel L43=new DexLabel();
                ddv.visitLineNumber(119,L43);
                DexLabel L44=new DexLabel();
                ddv.visitLineNumber(120,L44);
                code.visitLabel(L0);
                code.visitStmt2R(ARRAY_LENGTH,0,10);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitJumpStmt(IF_GE,0,1,L3);
                code.visitLabel(L1);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Ljava/lang/System;","err","Ljava/io/PrintStream;"));
                code.visitConstStmt(CONST_STRING,1,"usage: java PKCS12Import {pkcs12file} [newjksfile]");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/io/PrintStream;","println",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L2);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Ljava/lang/System;","exit",new String[]{ "I"},"V"));
                code.visitLabel(L3);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/io/File;");
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt3R(AGET_OBJECT,1,10,1);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Ljava/io/File;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L4);
                code.visitStmt2R(ARRAY_LENGTH,1,10);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitJumpStmt(IF_LE,1,2,L35);
                code.visitLabel(L5);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/io/File;");
                code.visitConstStmt(CONST_4,2, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt3R(AGET_OBJECT,10,10,2);
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,10},new Method("Ljava/io/File;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/io/File;","canRead",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,10);
                code.visitJumpStmt(IF_NEZ,10,-1,L10);
                code.visitLabel(L8);
                code.visitFieldStmt(SGET_OBJECT,10,-1,new Field("Ljava/lang/System;","err","Ljava/io/PrintStream;"));
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,3,"Unable to access input keystore: ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/io/File;","getPath",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10,2},new Method("Ljava/io/PrintStream;","println",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L9);
                code.visitConstStmt(CONST_4,10, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 10},new Method("Ljava/lang/System;","exit",new String[]{ "I"},"V"));
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/io/File;","exists",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,10);
                code.visitJumpStmt(IF_EQZ,10,-1,L13);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/io/File;","canWrite",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,10);
                code.visitJumpStmt(IF_NEZ,10,-1,L13);
                code.visitLabel(L11);
                code.visitFieldStmt(SGET_OBJECT,10,-1,new Field("Ljava/lang/System;","err","Ljava/io/PrintStream;"));
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,3,"Output file is not writable: ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/io/File;","getPath",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10,2},new Method("Ljava/io/PrintStream;","println",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L12);
                code.visitConstStmt(CONST_4,10, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 10},new Method("Ljava/lang/System;","exit",new String[]{ "I"},"V"));
                code.visitLabel(L13);
                code.visitConstStmt(CONST_STRING,10,"pkcs12");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 10},new Method("Ljava/security/KeyStore;","getInstance",new String[]{ "Ljava/lang/String;"},"Ljava/security/KeyStore;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitLabel(L14);
                code.visitConstStmt(CONST_STRING,10,"jks");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 10},new Method("Ljava/security/KeyStore;","getInstance",new String[]{ "Ljava/lang/String;"},"Ljava/security/KeyStore;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitLabel(L15);
                code.visitFieldStmt(SGET_OBJECT,10,-1,new Field("Ljava/lang/System;","out","Ljava/io/PrintStream;"));
                code.visitConstStmt(CONST_STRING,2,"Enter input keystore passphrase: ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10,2},new Method("Ljava/io/PrintStream;","print",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L16);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/jetty/security/PKCS12Import;","readPassphrase",new String[]{ },"[C"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L17);
                code.visitFieldStmt(SGET_OBJECT,10,-1,new Field("Ljava/lang/System;","out","Ljava/io/PrintStream;"));
                code.visitConstStmt(CONST_STRING,3,"Enter output keystore passphrase: ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10,3},new Method("Ljava/io/PrintStream;","print",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L18);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/jetty/security/PKCS12Import;","readPassphrase",new String[]{ },"[C"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitLabel(L19);
                code.visitTypeStmt(NEW_INSTANCE,10,-1,"Ljava/io/FileInputStream;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 10,0},new Method("Ljava/io/FileInputStream;","<init>",new String[]{ "Ljava/io/File;"},"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,10,2},new Method("Ljava/security/KeyStore;","load",new String[]{ "Ljava/io/InputStream;","[C"},"V"));
                code.visitLabel(L20);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/io/File;","exists",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,10);
                code.visitJumpStmt(IF_EQZ,10,-1,L39);
                code.visitTypeStmt(NEW_INSTANCE,10,-1,"Ljava/io/FileInputStream;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 10,1},new Method("Ljava/io/FileInputStream;","<init>",new String[]{ "Ljava/io/File;"},"V"));
                DexLabel L45=new DexLabel();
                code.visitLabel(L45);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,10,7},new Method("Ljava/security/KeyStore;","load",new String[]{ "Ljava/io/InputStream;","[C"},"V"));
                code.visitLabel(L21);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/security/KeyStore;","aliases",new String[]{ },"Ljava/util/Enumeration;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L22);
                code.visitConstStmt(CONST_4,10, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L23);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Ljava/util/Enumeration;","hasMoreElements",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_EQZ,3,-1,L40);
                code.visitLabel(L24);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Ljava/util/Enumeration;","nextElement",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitTypeStmt(CHECK_CAST,8,-1,"Ljava/lang/String;");
                code.visitLabel(L25);
                code.visitFieldStmt(SGET_OBJECT,3,-1,new Field("Ljava/lang/System;","err","Ljava/io/PrintStream;"));
                code.visitTypeStmt(NEW_INSTANCE,6,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 6},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,9,"Alias ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,9},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitStmt2R1N(ADD_INT_LIT8,6,10,1);
                code.visitLabel(L26);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9,10},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "I"},"Ljava/lang/StringBuilder;"));
                code.visitLabel(L27);
                code.visitStmt1R(MOVE_RESULT_OBJECT,10);
                code.visitConstStmt(CONST_STRING,9,": ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10,9},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10,8},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,10},new Method("Ljava/io/PrintStream;","println",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L28);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,8},new Method("Ljava/security/KeyStore;","isKeyEntry",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,10);
                code.visitJumpStmt(IF_EQZ,10,-1,L33);
                code.visitLabel(L29);
                code.visitFieldStmt(SGET_OBJECT,10,-1,new Field("Ljava/lang/System;","err","Ljava/io/PrintStream;"));
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,9,"Adding key for alias ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,9},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,8},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10,3},new Method("Ljava/io/PrintStream;","println",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L30);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,8,2},new Method("Ljava/security/KeyStore;","getKey",new String[]{ "Ljava/lang/String;","[C"},"Ljava/security/Key;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitLabel(L31);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,8},new Method("Ljava/security/KeyStore;","getCertificateChain",new String[]{ "Ljava/lang/String;"},"[Ljava/security/cert/Certificate;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,10);
                code.visitLabel(L32);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,8,3,7,10},new Method("Ljava/security/KeyStore;","setKeyEntry",new String[]{ "Ljava/lang/String;","Ljava/security/Key;","[C","[Ljava/security/cert/Certificate;"},"V"));
                code.visitLabel(L33);
                code.visitStmt2R(MOVE,10,6);
                code.visitLabel(L34);
                code.visitJumpStmt(GOTO,-1,-1,L23);
                code.visitLabel(L35);
                code.visitTypeStmt(NEW_INSTANCE,10,-1,"Ljava/io/File;");
                code.visitLabel(L36);
                code.visitConstStmt(CONST_STRING,1,"newstore.jks");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 10,1},new Method("Ljava/io/File;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L37);
                code.visitStmt2R(MOVE_OBJECT,1,10);
                code.visitLabel(L38);
                code.visitJumpStmt(GOTO_16,-1,-1,L7);
                code.visitLabel(L39);
                code.visitConstStmt(CONST_4,10, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L45);
                code.visitLabel(L40);
                code.visitTypeStmt(NEW_INSTANCE,10,-1,"Ljava/io/FileOutputStream;");
                code.visitLabel(L41);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 10,1},new Method("Ljava/io/FileOutputStream;","<init>",new String[]{ "Ljava/io/File;"},"V"));
                code.visitLabel(L42);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,10,7},new Method("Ljava/security/KeyStore;","store",new String[]{ "Ljava/io/OutputStream;","[C"},"V"));
                code.visitLabel(L43);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Ljava/io/OutputStream;","close",new String[]{ },"V"));
                code.visitLabel(L44);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_readPassphrase(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC, new Method("Lorg/mortbay/jetty/security/PKCS12Import;","readPassphrase",new String[]{ },"[C"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(8);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(136,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(138,L2);
                ddv.visitStartLocal(4,L2,"in","Ljava/io/InputStreamReader;",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(139,L3);
                ddv.visitStartLocal(1,L3,"cbuf","[C",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(142,L4);
                ddv.visitStartLocal(2,L4,"i","I",null);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(143,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(144,L6);
                ddv.visitStartLocal(0,L6,"c","C",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(150,L7);
                DexLabel L8=new DexLabel();
                ddv.visitStartLocal(3,L8,"i","I",null);
                DexLabel L9=new DexLabel();
                ddv.visitEndLocal(2,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(152,L10);
                ddv.visitRestartLocal(2,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(154,L11);
                ddv.visitEndLocal(0,L11);
                ddv.visitEndLocal(3,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(155,L12);
                ddv.visitStartLocal(5,L12,"phrase","[C",null);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(156,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(144,L14);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,7, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,4,-1,"Ljava/io/InputStreamReader;");
                code.visitFieldStmt(SGET_OBJECT,6,-1,new Field("Ljava/lang/System;","in","Ljava/io/InputStream;"));
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4,6},new Method("Ljava/io/InputStreamReader;","<init>",new String[]{ "Ljava/io/InputStream;"},"V"));
                code.visitLabel(L2);
                code.visitConstStmt(CONST_16,6, Integer.valueOf(256)); // int: 0x00000100  float:0.000000
                code.visitTypeStmt(NEW_ARRAY,1,6,"[C");
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L4);
                code.visitStmt2R(ARRAY_LENGTH,6,1);
                code.visitJumpStmt(IF_GE,2,6,L11);
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/io/InputStreamReader;","read",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitStmt2R(INT_TO_CHAR,0,6);
                code.visitLabel(L6);
                code.visitSparseSwitchStmt(PACKED_SWITCH,0,10,new DexLabel[]{L11,L7,L7,L11});
                code.visitLabel(L7);
                code.visitStmt2R1N(ADD_INT_LIT8,3,2,1);
                code.visitLabel(L8);
                code.visitStmt3R(APUT_CHAR,0,1,2);
                code.visitLabel(L9);
                code.visitStmt2R(MOVE,2,3);
                code.visitLabel(L10);
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitLabel(L11);
                code.visitTypeStmt(NEW_ARRAY,5,2,"[C");
                code.visitLabel(L12);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1,7,5,7,2},new Method("Ljava/lang/System;","arraycopy",new String[]{ "Ljava/lang/Object;","I","Ljava/lang/Object;","I","I"},"V"));
                code.visitLabel(L13);
                code.visitStmt1R(RETURN_OBJECT,5);
                code.visitLabel(L14);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
