package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0260_org_mortbay_jetty_nio_BlockingChannelConnector_Connection {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(0,"Lorg/mortbay/jetty/nio/BlockingChannelConnector$Connection;","Lorg/mortbay/io/nio/ChannelEndPoint;",new String[]{ "Ljava/lang/Runnable;"});
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("BlockingChannelConnector.java");
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/EnclosingClass;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("value", new DexType("Lorg/mortbay/jetty/nio/BlockingChannelConnector;"));
                av00.visitEnd();
            }
        }
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/InnerClass;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("accessFlags",  Integer.valueOf(2));
                av00.visit("name", "Connection");
                av00.visitEnd();
            }
        }
        f000__connection(cv);
        f001__dispatched(cv);
        f002__sotimeout(cv);
        f003_this$0(cv);
        m000__init_(cv);
        m001_dispatch(cv);
        m002_run(cv);
    }
    public static void f000__connection(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/jetty/nio/BlockingChannelConnector$Connection;","_connection","Lorg/mortbay/jetty/HttpConnection;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001__dispatched(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/jetty/nio/BlockingChannelConnector$Connection;","_dispatched","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002__sotimeout(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/jetty/nio/BlockingChannelConnector$Connection;","_sotimeout","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003_this$0(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_FINAL|ACC_SYNTHETIC, new Field("Lorg/mortbay/jetty/nio/BlockingChannelConnector$Connection;","this$0","Lorg/mortbay/jetty/nio/BlockingChannelConnector;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/nio/BlockingChannelConnector$Connection;","<init>",new String[]{ "Lorg/mortbay/jetty/nio/BlockingChannelConnector;","Ljava/nio/channels/ByteChannel;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(1,"channel");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(130,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(131,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(125,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(132,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(133,L4);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,3,2,new Field("Lorg/mortbay/jetty/nio/BlockingChannelConnector$Connection;","this$0","Lorg/mortbay/jetty/nio/BlockingChannelConnector;"));
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2,4},new Method("Lorg/mortbay/io/nio/ChannelEndPoint;","<init>",new String[]{ "Ljava/nio/channels/ByteChannel;"},"V"));
                code.visitLabel(L2);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_BOOLEAN,0,2,new Field("Lorg/mortbay/jetty/nio/BlockingChannelConnector$Connection;","_dispatched","Z"));
                code.visitLabel(L3);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/jetty/HttpConnection;");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/jetty/nio/BlockingChannelConnector;","getServer",new String[]{ },"Lorg/mortbay/jetty/Server;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,3,2,1},new Method("Lorg/mortbay/jetty/HttpConnection;","<init>",new String[]{ "Lorg/mortbay/jetty/Connector;","Lorg/mortbay/io/EndPoint;","Lorg/mortbay/jetty/Server;"},"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/jetty/nio/BlockingChannelConnector$Connection;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitLabel(L4);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001_dispatch(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(0, new Method("Lorg/mortbay/jetty/nio/BlockingChannelConnector$Connection;","dispatch",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(137,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(139,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(140,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(142,L3);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/nio/BlockingChannelConnector$Connection;","this$0","Lorg/mortbay/jetty/nio/BlockingChannelConnector;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/nio/BlockingChannelConnector;","getThreadPool",new String[]{ },"Lorg/mortbay/thread/ThreadPool;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,2},new Method("Lorg/mortbay/thread/ThreadPool;","dispatch",new String[]{ "Ljava/lang/Runnable;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_NEZ,0,-1,L3);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_STRING,0,"dispatch failed for  {}");
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/nio/BlockingChannelConnector$Connection;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,1},new Method("Lorg/mortbay/log/Log;","warn",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/nio/BlockingChannelConnector$Connection;","close",new String[]{ },"V"));
                code.visitLabel(L3);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_run(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/nio/BlockingChannelConnector$Connection;","run",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                DexLabel L5=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2,L3,L4,L5},new String[]{ "Lorg/mortbay/jetty/EofException;","Lorg/mortbay/jetty/HttpException;","Ljava/lang/Throwable;",null});
                DexLabel L6=new DexLabel();
                DexLabel L7=new DexLabel();
                code.visitTryCatch(L6,L7,new DexLabel[]{L5},new String[]{ null});
                DexLabel L8=new DexLabel();
                DexLabel L9=new DexLabel();
                code.visitTryCatch(L7,L8,new DexLabel[]{L9,L5},new String[]{ "Ljava/io/IOException;",null});
                DexLabel L10=new DexLabel();
                DexLabel L11=new DexLabel();
                code.visitTryCatch(L10,L11,new DexLabel[]{L5},new String[]{ null});
                DexLabel L12=new DexLabel();
                DexLabel L13=new DexLabel();
                code.visitTryCatch(L12,L13,new DexLabel[]{L5},new String[]{ null});
                DexLabel L14=new DexLabel();
                DexLabel L15=new DexLabel();
                code.visitTryCatch(L13,L14,new DexLabel[]{L15,L5},new String[]{ "Ljava/io/IOException;",null});
                DexLabel L16=new DexLabel();
                DexLabel L17=new DexLabel();
                code.visitTryCatch(L16,L17,new DexLabel[]{L5},new String[]{ null});
                DexLabel L18=new DexLabel();
                DexLabel L19=new DexLabel();
                code.visitTryCatch(L17,L18,new DexLabel[]{L19,L5},new String[]{ "Ljava/io/IOException;",null});
                DexLabel L20=new DexLabel();
                DexLabel L21=new DexLabel();
                code.visitTryCatch(L20,L21,new DexLabel[]{L5},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(148,L0);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(150,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(152,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(154,L24);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(156,L25);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(158,L26);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(159,L27);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(163,L28);
                ddv.visitLineNumber(166,L2);
                ddv.visitLineNumber(168,L6);
                ddv.visitStartLocal(0,L6,"e","Lorg/mortbay/jetty/EofException;",null);
                ddv.visitLineNumber(169,L7);
                ddv.visitLineNumber(186,L8);
                DexLabel L29=new DexLabel();
                ddv.visitEndLocal(0,L29);
                DexLabel L30=new DexLabel();
                ddv.visitLineNumber(188,L30);
                ddv.visitLineNumber(170,L9);
                ddv.visitRestartLocal(0,L9);
                ddv.visitStartLocal(1,L10,"e2","Ljava/io/IOException;",null);
                ddv.visitLineNumber(186,L5);
                ddv.visitEndLocal(0,L5);
                ddv.visitEndLocal(1,L5);
                ddv.visitLineNumber(172,L3);
                ddv.visitLineNumber(174,L12);
                ddv.visitStartLocal(0,L12,"e","Lorg/mortbay/jetty/HttpException;",null);
                ddv.visitLineNumber(175,L13);
                ddv.visitLineNumber(186,L14);
                ddv.visitLineNumber(176,L15);
                ddv.visitRestartLocal(1,L16);
                ddv.visitLineNumber(178,L4);
                ddv.visitEndLocal(0,L4);
                ddv.visitEndLocal(1,L4);
                DexLabel L31=new DexLabel();
                ddv.visitLineNumber(180,L31);
                ddv.visitStartLocal(0,L31,"e","Ljava/lang/Throwable;",null);
                ddv.visitLineNumber(181,L17);
                ddv.visitLineNumber(186,L18);
                ddv.visitLineNumber(182,L19);
                ddv.visitRestartLocal(1,L20);
                DexLabel L32=new DexLabel();
                ddv.visitLineNumber(186,L32);
                ddv.visitEndLocal(0,L32);
                ddv.visitEndLocal(1,L32);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/jetty/nio/BlockingChannelConnector$Connection;","this$0","Lorg/mortbay/jetty/nio/BlockingChannelConnector;"));
                code.visitFieldStmt(IGET_OBJECT,3,5,new Field("Lorg/mortbay/jetty/nio/BlockingChannelConnector$Connection;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2,3},new Method("Lorg/mortbay/jetty/nio/BlockingChannelConnector;","access$000",new String[]{ "Lorg/mortbay/jetty/nio/BlockingChannelConnector;","Lorg/mortbay/jetty/HttpConnection;"},"V"));
                code.visitLabel(L22);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/jetty/nio/BlockingChannelConnector$Connection;","isOpen",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_EQZ,2,-1,L32);
                code.visitLabel(L23);
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/jetty/nio/BlockingChannelConnector$Connection;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/HttpConnection;","isIdle",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_EQZ,2,-1,L28);
                code.visitLabel(L24);
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/jetty/nio/BlockingChannelConnector$Connection;","this$0","Lorg/mortbay/jetty/nio/BlockingChannelConnector;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/nio/BlockingChannelConnector;","getServer",new String[]{ },"Lorg/mortbay/jetty/Server;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/Server;","getThreadPool",new String[]{ },"Lorg/mortbay/thread/ThreadPool;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2},new Method("Lorg/mortbay/thread/ThreadPool;","isLowOnThreads",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_EQZ,2,-1,L28);
                code.visitLabel(L25);
                code.visitFieldStmt(IGET,2,5,new Field("Lorg/mortbay/jetty/nio/BlockingChannelConnector$Connection;","_sotimeout","I"));
                code.visitFieldStmt(IGET_OBJECT,3,5,new Field("Lorg/mortbay/jetty/nio/BlockingChannelConnector$Connection;","this$0","Lorg/mortbay/jetty/nio/BlockingChannelConnector;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/jetty/nio/BlockingChannelConnector;","getLowResourceMaxIdleTime",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_EQ,2,3,L28);
                code.visitLabel(L26);
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/jetty/nio/BlockingChannelConnector$Connection;","this$0","Lorg/mortbay/jetty/nio/BlockingChannelConnector;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/nio/BlockingChannelConnector;","getLowResourceMaxIdleTime",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitFieldStmt(IPUT,2,5,new Field("Lorg/mortbay/jetty/nio/BlockingChannelConnector$Connection;","_sotimeout","I"));
                code.visitLabel(L27);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/jetty/nio/BlockingChannelConnector$Connection;","getTransport",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitTypeStmt(CHECK_CAST,2,-1,"Ljava/nio/channels/SocketChannel;");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/nio/channels/SocketChannel;","socket",new String[]{ },"Ljava/net/Socket;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitFieldStmt(IGET,3,5,new Field("Lorg/mortbay/jetty/nio/BlockingChannelConnector$Connection;","_sotimeout","I"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/net/Socket;","setSoTimeout",new String[]{ "I"},"V"));
                code.visitLabel(L28);
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/jetty/nio/BlockingChannelConnector$Connection;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/HttpConnection;","handle",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitJumpStmt(GOTO,-1,-1,L22);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,2);
                code.visitStmt2R(MOVE_OBJECT,0,2);
                code.visitLabel(L6);
                code.visitConstStmt(CONST_STRING,2,"EOF");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2,0},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/jetty/nio/BlockingChannelConnector$Connection;","close",new String[]{ },"V"));
                code.visitLabel(L8);
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/jetty/nio/BlockingChannelConnector$Connection;","this$0","Lorg/mortbay/jetty/nio/BlockingChannelConnector;"));
                code.visitFieldStmt(IGET_OBJECT,3,5,new Field("Lorg/mortbay/jetty/nio/BlockingChannelConnector$Connection;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitLabel(L29);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2,3},new Method("Lorg/mortbay/jetty/nio/BlockingChannelConnector;","access$100",new String[]{ "Lorg/mortbay/jetty/nio/BlockingChannelConnector;","Lorg/mortbay/jetty/HttpConnection;"},"V"));
                code.visitLabel(L30);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L9);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1},new Method("Lorg/mortbay/log/Log;","ignore",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitLabel(L11);
                code.visitJumpStmt(GOTO,-1,-1,L8);
                code.visitLabel(L5);
                code.visitStmt1R(MOVE_EXCEPTION,2);
                code.visitFieldStmt(IGET_OBJECT,3,5,new Field("Lorg/mortbay/jetty/nio/BlockingChannelConnector$Connection;","this$0","Lorg/mortbay/jetty/nio/BlockingChannelConnector;"));
                code.visitFieldStmt(IGET_OBJECT,4,5,new Field("Lorg/mortbay/jetty/nio/BlockingChannelConnector$Connection;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3,4},new Method("Lorg/mortbay/jetty/nio/BlockingChannelConnector;","access$100",new String[]{ "Lorg/mortbay/jetty/nio/BlockingChannelConnector;","Lorg/mortbay/jetty/HttpConnection;"},"V"));
                code.visitStmt1R(THROW,2);
                code.visitLabel(L3);
                code.visitStmt1R(MOVE_EXCEPTION,2);
                code.visitStmt2R(MOVE_OBJECT,0,2);
                code.visitLabel(L12);
                code.visitConstStmt(CONST_STRING,2,"BAD");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2,0},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L13);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/jetty/nio/BlockingChannelConnector$Connection;","close",new String[]{ },"V"));
                code.visitLabel(L14);
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/jetty/nio/BlockingChannelConnector$Connection;","this$0","Lorg/mortbay/jetty/nio/BlockingChannelConnector;"));
                code.visitFieldStmt(IGET_OBJECT,3,5,new Field("Lorg/mortbay/jetty/nio/BlockingChannelConnector$Connection;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitJumpStmt(GOTO,-1,-1,L29);
                code.visitLabel(L15);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitLabel(L16);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1},new Method("Lorg/mortbay/log/Log;","ignore",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L14);
                code.visitLabel(L4);
                code.visitStmt1R(MOVE_EXCEPTION,2);
                code.visitStmt2R(MOVE_OBJECT,0,2);
                code.visitLabel(L31);
                code.visitConstStmt(CONST_STRING,2,"handle failed");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2,0},new Method("Lorg/mortbay/log/Log;","warn",new String[]{ "Ljava/lang/String;","Ljava/lang/Throwable;"},"V"));
                code.visitLabel(L17);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/jetty/nio/BlockingChannelConnector$Connection;","close",new String[]{ },"V"));
                code.visitLabel(L18);
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/jetty/nio/BlockingChannelConnector$Connection;","this$0","Lorg/mortbay/jetty/nio/BlockingChannelConnector;"));
                code.visitFieldStmt(IGET_OBJECT,3,5,new Field("Lorg/mortbay/jetty/nio/BlockingChannelConnector$Connection;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitJumpStmt(GOTO,-1,-1,L29);
                code.visitLabel(L19);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitLabel(L20);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1},new Method("Lorg/mortbay/log/Log;","ignore",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitLabel(L21);
                code.visitJumpStmt(GOTO,-1,-1,L18);
                code.visitLabel(L32);
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/jetty/nio/BlockingChannelConnector$Connection;","this$0","Lorg/mortbay/jetty/nio/BlockingChannelConnector;"));
                code.visitFieldStmt(IGET_OBJECT,3,5,new Field("Lorg/mortbay/jetty/nio/BlockingChannelConnector$Connection;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitJumpStmt(GOTO,-1,-1,L29);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
