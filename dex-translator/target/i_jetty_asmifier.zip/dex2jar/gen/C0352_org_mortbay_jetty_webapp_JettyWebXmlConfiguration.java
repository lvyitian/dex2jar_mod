package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0352_org_mortbay_jetty_webapp_JettyWebXmlConfiguration {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/jetty/webapp/JettyWebXmlConfiguration;","Ljava/lang/Object;",new String[]{ "Lorg/mortbay/jetty/webapp/Configuration;"});
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("JettyWebXmlConfiguration.java");
        f000__context(cv);
        m000__init_(cv);
        m001_configureClassLoader(cv);
        m002_configureDefaults(cv);
        m003_configureWebApp(cv);
        m004_deconfigureWebApp(cv);
        m005_getWebAppContext(cv);
        m006_setWebAppContext(cv);
    }
    public static void f000__context(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/webapp/JettyWebXmlConfiguration;","_context","Lorg/mortbay/jetty/webapp/WebAppContext;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/webapp/JettyWebXmlConfiguration;","<init>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(32,L0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/Object;","<init>",new String[]{ },"V"));
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001_configureClassLoader(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/webapp/JettyWebXmlConfiguration;","configureClassLoader",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/Exception;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(56,L0);
                code.visitLabel(L0);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_configureDefaults(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/webapp/JettyWebXmlConfiguration;","configureDefaults",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/Exception;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(64,L0);
                code.visitLabel(L0);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_configureWebApp(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/webapp/JettyWebXmlConfiguration;","configureWebApp",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/Exception;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(73,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(75,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(112,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(79,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(80,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(82,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(84,L9);
                ddv.visitStartLocal(3,L9,"web_inf","Lorg/mortbay/resource/Resource;",null);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(87,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(88,L11);
                ddv.visitStartLocal(0,L11,"jetty","Lorg/mortbay/resource/Resource;",null);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(89,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(90,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(91,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(93,L15);
                ddv.visitRestartLocal(0,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(96,L16);
                ddv.visitLineNumber(99,L0);
                ddv.visitStartLocal(2,L0,"old_server_classes","[Ljava/lang/String;",null);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(100,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(101,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(102,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(103,L20);
                ddv.visitStartLocal(1,L20,"jetty_config","Lorg/mortbay/xml/XmlConfiguration;",null);
                ddv.visitLineNumber(107,L1);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(108,L21);
                ddv.visitLineNumber(107,L2);
                ddv.visitEndLocal(1,L2);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(108,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(107,L23);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,4,6,new Field("Lorg/mortbay/jetty/webapp/JettyWebXmlConfiguration;","_context","Lorg/mortbay/jetty/webapp/WebAppContext;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","isStarted",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitJumpStmt(IF_EQZ,4,-1,L6);
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/log/Log;","isDebugEnabled",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitJumpStmt(IF_EQZ,4,-1,L5);
                code.visitConstStmt(CONST_STRING,4,"Cannot configure webapp after it is started");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 4},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L5);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/log/Log;","isDebugEnabled",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitJumpStmt(IF_EQZ,4,-1,L8);
                code.visitLabel(L7);
                code.visitConstStmt(CONST_STRING,4,"Configuring web-jetty.xml");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 4},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/webapp/JettyWebXmlConfiguration;","getWebAppContext",new String[]{ },"Lorg/mortbay/jetty/webapp/WebAppContext;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","getWebInf",new String[]{ },"Lorg/mortbay/resource/Resource;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitLabel(L9);
                code.visitJumpStmt(IF_EQZ,3,-1,L5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/resource/Resource;","isDirectory",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitJumpStmt(IF_EQZ,4,-1,L5);
                code.visitLabel(L10);
                code.visitConstStmt(CONST_STRING,4,"jetty6-web.xml");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Lorg/mortbay/resource/Resource;","addPath",new String[]{ "Ljava/lang/String;"},"Lorg/mortbay/resource/Resource;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L11);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/resource/Resource;","exists",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitJumpStmt(IF_NEZ,4,-1,L13);
                code.visitLabel(L12);
                code.visitConstStmt(CONST_STRING,4,"jetty-web.xml");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Lorg/mortbay/resource/Resource;","addPath",new String[]{ "Ljava/lang/String;"},"Lorg/mortbay/resource/Resource;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L13);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/resource/Resource;","exists",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitJumpStmt(IF_NEZ,4,-1,L15);
                code.visitLabel(L14);
                code.visitConstStmt(CONST_STRING,4,"web-jetty.xml");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Lorg/mortbay/resource/Resource;","addPath",new String[]{ "Ljava/lang/String;"},"Lorg/mortbay/resource/Resource;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L15);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/resource/Resource;","exists",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitJumpStmt(IF_EQZ,4,-1,L5);
                code.visitLabel(L16);
                code.visitFieldStmt(IGET_OBJECT,4,6,new Field("Lorg/mortbay/jetty/webapp/JettyWebXmlConfiguration;","_context","Lorg/mortbay/jetty/webapp/WebAppContext;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","getServerClasses",new String[]{ },"[Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,4,6,new Field("Lorg/mortbay/jetty/webapp/JettyWebXmlConfiguration;","_context","Lorg/mortbay/jetty/webapp/WebAppContext;"));
                code.visitConstStmt(CONST_4,5, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","setServerClasses",new String[]{ "[Ljava/lang/String;"},"V"));
                code.visitLabel(L17);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/log/Log;","isDebugEnabled",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitJumpStmt(IF_EQZ,4,-1,L19);
                code.visitLabel(L18);
                code.visitTypeStmt(NEW_INSTANCE,4,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,5,"Configure: ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,0},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 4},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L19);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Lorg/mortbay/xml/XmlConfiguration;");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/resource/Resource;","getURL",new String[]{ },"Ljava/net/URL;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,4},new Method("Lorg/mortbay/xml/XmlConfiguration;","<init>",new String[]{ "Ljava/net/URL;"},"V"));
                code.visitLabel(L20);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/webapp/JettyWebXmlConfiguration;","getWebAppContext",new String[]{ },"Lorg/mortbay/jetty/webapp/WebAppContext;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,4},new Method("Lorg/mortbay/xml/XmlConfiguration;","configure",new String[]{ "Ljava/lang/Object;"},"V"));
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,4,6,new Field("Lorg/mortbay/jetty/webapp/JettyWebXmlConfiguration;","_context","Lorg/mortbay/jetty/webapp/WebAppContext;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","getServerClasses",new String[]{ },"[Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitJumpStmt(IF_NEZ,4,-1,L5);
                code.visitLabel(L21);
                code.visitFieldStmt(IGET_OBJECT,4,6,new Field("Lorg/mortbay/jetty/webapp/JettyWebXmlConfiguration;","_context","Lorg/mortbay/jetty/webapp/WebAppContext;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,2},new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","setServerClasses",new String[]{ "[Ljava/lang/String;"},"V"));
                code.visitJumpStmt(GOTO_16,-1,-1,L5);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,4);
                code.visitFieldStmt(IGET_OBJECT,5,6,new Field("Lorg/mortbay/jetty/webapp/JettyWebXmlConfiguration;","_context","Lorg/mortbay/jetty/webapp/WebAppContext;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","getServerClasses",new String[]{ },"[Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitJumpStmt(IF_NEZ,5,-1,L23);
                code.visitLabel(L22);
                code.visitFieldStmt(IGET_OBJECT,5,6,new Field("Lorg/mortbay/jetty/webapp/JettyWebXmlConfiguration;","_context","Lorg/mortbay/jetty/webapp/WebAppContext;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,2},new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","setServerClasses",new String[]{ "[Ljava/lang/String;"},"V"));
                code.visitLabel(L23);
                code.visitStmt1R(THROW,4);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_deconfigureWebApp(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/webapp/JettyWebXmlConfiguration;","deconfigureWebApp",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/Exception;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(121,L0);
                code.visitLabel(L0);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_getWebAppContext(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/webapp/JettyWebXmlConfiguration;","getWebAppContext",new String[]{ },"Lorg/mortbay/jetty/webapp/WebAppContext;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(47,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/webapp/JettyWebXmlConfiguration;","_context","Lorg/mortbay/jetty/webapp/WebAppContext;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_setWebAppContext(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/webapp/JettyWebXmlConfiguration;","setWebAppContext",new String[]{ "Lorg/mortbay/jetty/webapp/WebAppContext;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"context");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(42,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(43,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/webapp/JettyWebXmlConfiguration;","_context","Lorg/mortbay/jetty/webapp/WebAppContext;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
