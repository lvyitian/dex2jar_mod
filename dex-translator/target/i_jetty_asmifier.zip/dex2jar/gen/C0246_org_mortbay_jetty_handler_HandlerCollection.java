package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0246_org_mortbay_jetty_handler_HandlerCollection {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/jetty/handler/HandlerCollection;","Lorg/mortbay/jetty/handler/AbstractHandlerContainer;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("HandlerCollection.java");
        f000__handlers(cv);
        m000__init_(cv);
        m001_addHandler(cv);
        m002_doStart(cv);
        m003_doStop(cv);
        m004_expandChildren(cv);
        m005_getHandlers(cv);
        m006_handle(cv);
        m007_removeHandler(cv);
        m008_setHandlers(cv);
        m009_setServer(cv);
    }
    public static void f000__handlers(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/handler/HandlerCollection;","_handlers","[Lorg/mortbay/jetty/Handler;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/handler/HandlerCollection;","<init>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(45,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(46,L1);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Lorg/mortbay/jetty/handler/AbstractHandlerContainer;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001_addHandler(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/handler/HandlerCollection;","addHandler",new String[]{ "Lorg/mortbay/jetty/Handler;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"handler");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(197,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(198,L1);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/handler/HandlerCollection;","getHandlers",new String[]{ },"[Lorg/mortbay/jetty/Handler;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitConstStmt(CONST_CLASS,1,new DexType("Lorg/mortbay/jetty/Handler;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,3,1},new Method("Lorg/mortbay/util/LazyList;","addToArray",new String[]{ "[Ljava/lang/Object;","Ljava/lang/Object;","Ljava/lang/Class;"},"[Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitTypeStmt(CHECK_CAST,0,-1,"[Lorg/mortbay/jetty/Handler;");
                code.visitTypeStmt(CHECK_CAST,0,-1,"[Lorg/mortbay/jetty/Handler;");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,0},new Method("Lorg/mortbay/jetty/handler/HandlerCollection;","setHandlers",new String[]{ "[Lorg/mortbay/jetty/Handler;"},"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_doStart(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/handler/HandlerCollection;","doStart",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/Exception;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/lang/Throwable;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(148,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(149,L4);
                ddv.visitStartLocal(2,L4,"mex","Lorg/mortbay/util/MultiException;",null);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(151,L5);
                DexLabel L6=new DexLabel();
                ddv.visitStartLocal(1,L6,"i","I",null);
                ddv.visitLineNumber(152,L0);
                ddv.visitLineNumber(151,L1);
                ddv.visitLineNumber(152,L2);
                DexLabel L7=new DexLabel();
                ddv.visitStartLocal(0,L7,"e","Ljava/lang/Throwable;",null);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(154,L8);
                ddv.visitEndLocal(1,L8);
                ddv.visitEndLocal(0,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(155,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(156,L10);
                code.visitLabel(L3);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Lorg/mortbay/util/MultiException;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2},new Method("Lorg/mortbay/util/MultiException;","<init>",new String[]{ },"V"));
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,3,4,new Field("Lorg/mortbay/jetty/handler/HandlerCollection;","_handlers","[Lorg/mortbay/jetty/Handler;"));
                code.visitJumpStmt(IF_EQZ,3,-1,L8);
                code.visitLabel(L5);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,3,4,new Field("Lorg/mortbay/jetty/handler/HandlerCollection;","_handlers","[Lorg/mortbay/jetty/Handler;"));
                code.visitStmt2R(ARRAY_LENGTH,3,3);
                code.visitJumpStmt(IF_GE,1,3,L8);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,3,4,new Field("Lorg/mortbay/jetty/handler/HandlerCollection;","_handlers","[Lorg/mortbay/jetty/Handler;"));
                code.visitStmt3R(AGET_OBJECT,3,3,1);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3},new Method("Lorg/mortbay/jetty/Handler;","start",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitStmt2R1N(ADD_INT_LIT8,1,1,1);
                code.visitJumpStmt(GOTO,-1,-1,L6);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,3);
                code.visitStmt2R(MOVE_OBJECT,0,3);
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,0},new Method("Lorg/mortbay/util/MultiException;","add",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 4},new Method("Lorg/mortbay/jetty/handler/AbstractHandlerContainer;","doStart",new String[]{ },"V"));
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/util/MultiException;","ifExceptionThrow",new String[]{ },"V"));
                code.visitLabel(L10);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_doStop(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/handler/HandlerCollection;","doStop",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/Exception;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/lang/Throwable;"});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                DexLabel L5=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L5},new String[]{ "Ljava/lang/Throwable;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L6=new DexLabel();
                ddv.visitPrologue(L6);
                ddv.visitLineNumber(164,L6);
                ddv.visitLineNumber(165,L0);
                ddv.visitStartLocal(3,L0,"mex","Lorg/mortbay/util/MultiException;",null);
                ddv.visitLineNumber(166,L1);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(168,L7);
                DexLabel L8=new DexLabel();
                ddv.visitStartLocal(1,L8,"i","I",null);
                DexLabel L9=new DexLabel();
                ddv.visitEndLocal(1,L9);
                ddv.visitStartLocal(2,L9,"i","I",null);
                DexLabel L10=new DexLabel();
                ddv.visitRestartLocal(1,L10);
                ddv.visitLineNumber(169,L3);
                ddv.visitEndLocal(2,L3);
                DexLabel L11=new DexLabel();
                ddv.visitRestartLocal(2,L11);
                ddv.visitLineNumber(165,L2);
                ddv.visitEndLocal(1,L2);
                ddv.visitEndLocal(2,L2);
                DexLabel L12=new DexLabel();
                ddv.visitStartLocal(0,L12,"e","Ljava/lang/Throwable;",null);
                ddv.visitLineNumber(169,L5);
                ddv.visitEndLocal(0,L5);
                ddv.visitRestartLocal(1,L5);
                DexLabel L13=new DexLabel();
                ddv.visitRestartLocal(0,L13);
                DexLabel L14=new DexLabel();
                ddv.visitRestartLocal(2,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(171,L15);
                ddv.visitEndLocal(1,L15);
                ddv.visitEndLocal(0,L15);
                ddv.visitEndLocal(2,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(172,L16);
                code.visitLabel(L6);
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Lorg/mortbay/util/MultiException;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3},new Method("Lorg/mortbay/util/MultiException;","<init>",new String[]{ },"V"));
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 5},new Method("Lorg/mortbay/jetty/handler/AbstractHandlerContainer;","doStop",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,4,5,new Field("Lorg/mortbay/jetty/handler/HandlerCollection;","_handlers","[Lorg/mortbay/jetty/Handler;"));
                code.visitJumpStmt(IF_EQZ,4,-1,L15);
                code.visitLabel(L7);
                code.visitFieldStmt(IGET_OBJECT,4,5,new Field("Lorg/mortbay/jetty/handler/HandlerCollection;","_handlers","[Lorg/mortbay/jetty/Handler;"));
                code.visitStmt2R(ARRAY_LENGTH,1,4);
                code.visitLabel(L8);
                code.visitStmt2R(MOVE,2,1);
                code.visitLabel(L9);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt3R(SUB_INT,1,2,4);
                code.visitLabel(L10);
                code.visitJumpStmt(IF_LEZ,2,-1,L15);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,4,5,new Field("Lorg/mortbay/jetty/handler/HandlerCollection;","_handlers","[Lorg/mortbay/jetty/Handler;"));
                code.visitStmt3R(AGET_OBJECT,4,4,1);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 4},new Method("Lorg/mortbay/jetty/Handler;","stop",new String[]{ },"V"));
                code.visitLabel(L4);
                code.visitStmt2R(MOVE,2,1);
                code.visitLabel(L11);
                code.visitJumpStmt(GOTO,-1,-1,L9);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,0);
                code.visitLabel(L12);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,0},new Method("Lorg/mortbay/util/MultiException;","add",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitLabel(L5);
                code.visitStmt1R(MOVE_EXCEPTION,4);
                code.visitStmt2R(MOVE_OBJECT,0,4);
                code.visitLabel(L13);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,0},new Method("Lorg/mortbay/util/MultiException;","add",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitStmt2R(MOVE,2,1);
                code.visitLabel(L14);
                code.visitJumpStmt(GOTO,-1,-1,L9);
                code.visitLabel(L15);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/util/MultiException;","ifExceptionThrow",new String[]{ },"V"));
                code.visitLabel(L16);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_expandChildren(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/handler/HandlerCollection;","expandChildren",new String[]{ "Ljava/lang/Object;","Ljava/lang/Class;"},"Ljava/lang/Object;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"list");
                ddv.visitParameterName(1,"byClass");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(212,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(213,L1);
                ddv.visitStartLocal(0,L1,"handlers","[Lorg/mortbay/jetty/Handler;",null);
                DexLabel L2=new DexLabel();
                ddv.visitStartLocal(1,L2,"i","I",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(214,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(213,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(215,L5);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/jetty/handler/HandlerCollection;","getHandlers",new String[]{ },"[Lorg/mortbay/jetty/Handler;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L2);
                code.visitJumpStmt(IF_EQZ,0,-1,L5);
                code.visitStmt2R(ARRAY_LENGTH,2,0);
                code.visitJumpStmt(IF_GE,1,2,L5);
                code.visitLabel(L3);
                code.visitStmt3R(AGET_OBJECT,2,0,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,2,4,5},new Method("Lorg/mortbay/jetty/handler/HandlerCollection;","expandHandler",new String[]{ "Lorg/mortbay/jetty/Handler;","Ljava/lang/Object;","Ljava/lang/Class;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitLabel(L4);
                code.visitStmt2R1N(ADD_INT_LIT8,1,1,1);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L5);
                code.visitStmt1R(RETURN_OBJECT,4);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_getHandlers(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/handler/HandlerCollection;","getHandlers",new String[]{ },"[Lorg/mortbay/jetty/Handler;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(54,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/handler/HandlerCollection;","_handlers","[Lorg/mortbay/jetty/Handler;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_handle(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/handler/HandlerCollection;","handle",new String[]{ "Ljava/lang/String;","Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;","I"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visit(null, new DexType("Ljavax/servlet/ServletException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(10);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2,L3,L4},new String[]{ "Ljava/io/IOException;","Ljava/lang/RuntimeException;","Ljava/lang/Exception;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"target");
                ddv.visitParameterName(1,"request");
                ddv.visitParameterName(2,"response");
                ddv.visitParameterName(3,"dispatch");
                DexLabel L5=new DexLabel();
                ddv.visitPrologue(L5);
                ddv.visitLineNumber(106,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(108,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(110,L7);
                ddv.visitStartLocal(2,L7,"mex","Lorg/mortbay/util/MultiException;",null);
                DexLabel L8=new DexLabel();
                ddv.visitStartLocal(1,L8,"i","I",null);
                ddv.visitLineNumber(114,L0);
                ddv.visitLineNumber(110,L1);
                ddv.visitLineNumber(116,L2);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(118,L9);
                ddv.visitStartLocal(0,L9,"e","Ljava/io/IOException;",null);
                ddv.visitLineNumber(120,L3);
                ddv.visitEndLocal(0,L3);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(122,L10);
                ddv.visitStartLocal(0,L10,"e","Ljava/lang/RuntimeException;",null);
                ddv.visitLineNumber(124,L4);
                ddv.visitEndLocal(0,L4);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(126,L11);
                ddv.visitStartLocal(0,L11,"e","Ljava/lang/Exception;",null);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(127,L12);
                DexLabel L13=new DexLabel();
                ddv.visitEndLocal(2,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(128,L14);
                ddv.visitRestartLocal(2,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(131,L15);
                ddv.visitEndLocal(0,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(133,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(134,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(136,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(140,L19);
                ddv.visitEndLocal(1,L19);
                ddv.visitEndLocal(2,L19);
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,3,5,new Field("Lorg/mortbay/jetty/handler/HandlerCollection;","_handlers","[Lorg/mortbay/jetty/Handler;"));
                code.visitJumpStmt(IF_EQZ,3,-1,L19);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/jetty/handler/HandlerCollection;","isStarted",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_EQZ,3,-1,L19);
                code.visitLabel(L6);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L7);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L8);
                code.visitFieldStmt(IGET_OBJECT,3,5,new Field("Lorg/mortbay/jetty/handler/HandlerCollection;","_handlers","[Lorg/mortbay/jetty/Handler;"));
                code.visitStmt2R(ARRAY_LENGTH,3,3);
                code.visitJumpStmt(IF_GE,1,3,L15);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,3,5,new Field("Lorg/mortbay/jetty/handler/HandlerCollection;","_handlers","[Lorg/mortbay/jetty/Handler;"));
                code.visitStmt3R(AGET_OBJECT,3,3,1);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3,6,7,8,9},new Method("Lorg/mortbay/jetty/Handler;","handle",new String[]{ "Ljava/lang/String;","Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;","I"},"V"));
                code.visitLabel(L1);
                code.visitStmt2R1N(ADD_INT_LIT8,1,1,1);
                code.visitJumpStmt(GOTO,-1,-1,L8);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,3);
                code.visitStmt2R(MOVE_OBJECT,0,3);
                code.visitLabel(L9);
                code.visitStmt1R(THROW,0);
                code.visitLabel(L3);
                code.visitStmt1R(MOVE_EXCEPTION,3);
                code.visitStmt2R(MOVE_OBJECT,0,3);
                code.visitLabel(L10);
                code.visitStmt1R(THROW,0);
                code.visitLabel(L4);
                code.visitStmt1R(MOVE_EXCEPTION,3);
                code.visitStmt2R(MOVE_OBJECT,0,3);
                code.visitLabel(L11);
                code.visitJumpStmt(IF_NEZ,2,-1,L14);
                code.visitLabel(L12);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Lorg/mortbay/util/MultiException;");
                code.visitLabel(L13);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2},new Method("Lorg/mortbay/util/MultiException;","<init>",new String[]{ },"V"));
                code.visitLabel(L14);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,0},new Method("Lorg/mortbay/util/MultiException;","add",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitLabel(L15);
                code.visitJumpStmt(IF_EQZ,2,-1,L19);
                code.visitLabel(L16);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/util/MultiException;","size",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitJumpStmt(IF_NE,3,4,L18);
                code.visitLabel(L17);
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Ljavax/servlet/ServletException;");
                code.visitConstStmt(CONST_4,4, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,4},new Method("Lorg/mortbay/util/MultiException;","getThrowable",new String[]{ "I"},"Ljava/lang/Throwable;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3,4},new Method("Ljavax/servlet/ServletException;","<init>",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitStmt1R(THROW,3);
                code.visitLabel(L18);
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Ljavax/servlet/ServletException;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3,2},new Method("Ljavax/servlet/ServletException;","<init>",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitStmt1R(THROW,3);
                code.visitLabel(L19);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m007_removeHandler(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/handler/HandlerCollection;","removeHandler",new String[]{ "Lorg/mortbay/jetty/Handler;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"handler");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(203,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(205,L1);
                ddv.visitStartLocal(0,L1,"handlers","[Lorg/mortbay/jetty/Handler;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(206,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(207,L3);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/handler/HandlerCollection;","getHandlers",new String[]{ },"[Lorg/mortbay/jetty/Handler;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L1);
                code.visitJumpStmt(IF_EQZ,0,-1,L3);
                code.visitStmt2R(ARRAY_LENGTH,1,0);
                code.visitJumpStmt(IF_LEZ,1,-1,L3);
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,3},new Method("Lorg/mortbay/util/LazyList;","removeFromArray",new String[]{ "[Ljava/lang/Object;","Ljava/lang/Object;"},"[Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitTypeStmt(CHECK_CAST,1,-1,"[Lorg/mortbay/jetty/Handler;");
                code.visitTypeStmt(CHECK_CAST,1,-1,"[Lorg/mortbay/jetty/Handler;");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,1},new Method("Lorg/mortbay/jetty/handler/HandlerCollection;","setHandlers",new String[]{ "[Lorg/mortbay/jetty/Handler;"},"V"));
                code.visitLabel(L3);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m008_setHandlers(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/handler/HandlerCollection;","setHandlers",new String[]{ "[Lorg/mortbay/jetty/Handler;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(9);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/lang/Throwable;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"handlers");
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(64,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(66,L4);
                ddv.visitStartLocal(3,L4,"old_handlers","[Lorg/mortbay/jetty/Handler;",null);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(67,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(69,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(70,L7);
                ddv.visitStartLocal(4,L7,"server","Lorg/mortbay/jetty/Server;",null);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(71,L8);
                ddv.visitStartLocal(2,L8,"mex","Lorg/mortbay/util/MultiException;",null);
                DexLabel L9=new DexLabel();
                ddv.visitStartLocal(1,L9,"i","I",null);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(73,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(74,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(71,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(64,L13);
                ddv.visitEndLocal(3,L13);
                ddv.visitEndLocal(4,L13);
                ddv.visitEndLocal(2,L13);
                ddv.visitEndLocal(1,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(78,L14);
                ddv.visitRestartLocal(1,L14);
                ddv.visitRestartLocal(2,L14);
                ddv.visitRestartLocal(3,L14);
                ddv.visitRestartLocal(4,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(80,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(82,L16);
                ddv.visitLineNumber(86,L0);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(87,L17);
                ddv.visitLineNumber(80,L1);
                ddv.visitLineNumber(89,L2);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(91,L18);
                ddv.visitStartLocal(0,L18,"e","Ljava/lang/Throwable;",null);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(96,L19);
                ddv.visitEndLocal(0,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(97,L20);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,5,7,new Field("Lorg/mortbay/jetty/handler/HandlerCollection;","_handlers","[Lorg/mortbay/jetty/Handler;"));
                code.visitJumpStmt(IF_NEZ,5,-1,L13);
                code.visitConstStmt(CONST_4,5, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt2R(MOVE_OBJECT,3,5);
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Lorg/mortbay/jetty/handler/HandlerCollection;","getServer",new String[]{ },"Lorg/mortbay/jetty/Server;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitJumpStmt(IF_EQZ,5,-1,L6);
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Lorg/mortbay/jetty/handler/HandlerCollection;","getServer",new String[]{ },"Lorg/mortbay/jetty/Server;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/jetty/Server;","getContainer",new String[]{ },"Lorg/mortbay/component/Container;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitConstStmt(CONST_STRING,6,"handler");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,7,3,8,6},new Method("Lorg/mortbay/component/Container;","update",new String[]{ "Ljava/lang/Object;","[Ljava/lang/Object;","[Ljava/lang/Object;","Ljava/lang/String;"},"V"));
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Lorg/mortbay/jetty/handler/HandlerCollection;","getServer",new String[]{ },"Lorg/mortbay/jetty/Server;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitLabel(L7);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Lorg/mortbay/util/MultiException;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2},new Method("Lorg/mortbay/util/MultiException;","<init>",new String[]{ },"V"));
                code.visitLabel(L8);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L9);
                code.visitJumpStmt(IF_EQZ,8,-1,L14);
                code.visitStmt2R(ARRAY_LENGTH,5,8);
                code.visitJumpStmt(IF_GE,1,5,L14);
                code.visitLabel(L10);
                code.visitStmt3R(AGET_OBJECT,5,8,1);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 5},new Method("Lorg/mortbay/jetty/Handler;","getServer",new String[]{ },"Lorg/mortbay/jetty/Server;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitJumpStmt(IF_EQ,5,4,L12);
                code.visitLabel(L11);
                code.visitStmt3R(AGET_OBJECT,5,8,1);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 5,4},new Method("Lorg/mortbay/jetty/Handler;","setServer",new String[]{ "Lorg/mortbay/jetty/Server;"},"V"));
                code.visitLabel(L12);
                code.visitStmt2R1N(ADD_INT_LIT8,1,1,1);
                code.visitJumpStmt(GOTO,-1,-1,L9);
                code.visitLabel(L13);
                code.visitFieldStmt(IGET_OBJECT,5,7,new Field("Lorg/mortbay/jetty/handler/HandlerCollection;","_handlers","[Lorg/mortbay/jetty/Handler;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("[Lorg/mortbay/jetty/Handler;","clone",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitTypeStmt(CHECK_CAST,5,-1,"[Lorg/mortbay/jetty/Handler;");
                code.visitTypeStmt(CHECK_CAST,5,-1,"[Lorg/mortbay/jetty/Handler;");
                code.visitStmt2R(MOVE_OBJECT,3,5);
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitLabel(L14);
                code.visitFieldStmt(IPUT_OBJECT,8,7,new Field("Lorg/mortbay/jetty/handler/HandlerCollection;","_handlers","[Lorg/mortbay/jetty/Handler;"));
                code.visitLabel(L15);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                DexLabel L21=new DexLabel();
                code.visitLabel(L21);
                code.visitJumpStmt(IF_EQZ,3,-1,L19);
                code.visitStmt2R(ARRAY_LENGTH,5,3);
                code.visitJumpStmt(IF_GE,1,5,L19);
                code.visitLabel(L16);
                code.visitStmt3R(AGET_OBJECT,5,3,1);
                code.visitJumpStmt(IF_EQZ,5,-1,L1);
                code.visitLabel(L0);
                code.visitStmt3R(AGET_OBJECT,5,3,1);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 5},new Method("Lorg/mortbay/jetty/Handler;","isStarted",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitJumpStmt(IF_EQZ,5,-1,L1);
                code.visitLabel(L17);
                code.visitStmt3R(AGET_OBJECT,5,3,1);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 5},new Method("Lorg/mortbay/jetty/Handler;","stop",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitStmt2R1N(ADD_INT_LIT8,1,1,1);
                code.visitJumpStmt(GOTO,-1,-1,L21);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,5);
                code.visitStmt2R(MOVE_OBJECT,0,5);
                code.visitLabel(L18);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,0},new Method("Lorg/mortbay/util/MultiException;","add",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitLabel(L19);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/util/MultiException;","ifExceptionThrowRuntime",new String[]{ },"V"));
                code.visitLabel(L20);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m009_setServer(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/handler/HandlerCollection;","setServer",new String[]{ "Lorg/mortbay/jetty/Server;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(9);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"server");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(177,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(179,L1);
                ddv.visitStartLocal(2,L1,"old_server","Lorg/mortbay/jetty/Server;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(181,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(182,L3);
                ddv.visitStartLocal(0,L3,"h","[Lorg/mortbay/jetty/Handler;",null);
                DexLabel L4=new DexLabel();
                ddv.visitStartLocal(1,L4,"i","I",null);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(183,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(182,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(185,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(186,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(188,L9);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Lorg/mortbay/jetty/handler/HandlerCollection;","getServer",new String[]{ },"Lorg/mortbay/jetty/Server;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 7,8},new Method("Lorg/mortbay/jetty/handler/AbstractHandlerContainer;","setServer",new String[]{ "Lorg/mortbay/jetty/Server;"},"V"));
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Lorg/mortbay/jetty/handler/HandlerCollection;","getHandlers",new String[]{ },"[Lorg/mortbay/jetty/Handler;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L4);
                code.visitJumpStmt(IF_EQZ,0,-1,L7);
                code.visitStmt2R(ARRAY_LENGTH,3,0);
                code.visitJumpStmt(IF_GE,1,3,L7);
                code.visitLabel(L5);
                code.visitStmt3R(AGET_OBJECT,3,0,1);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3,8},new Method("Lorg/mortbay/jetty/Handler;","setServer",new String[]{ "Lorg/mortbay/jetty/Server;"},"V"));
                code.visitLabel(L6);
                code.visitStmt2R1N(ADD_INT_LIT8,1,1,1);
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitLabel(L7);
                code.visitJumpStmt(IF_EQZ,8,-1,L9);
                code.visitJumpStmt(IF_EQ,8,2,L9);
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Lorg/mortbay/jetty/Server;","getContainer",new String[]{ },"Lorg/mortbay/component/Container;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IGET_OBJECT,5,7,new Field("Lorg/mortbay/jetty/handler/HandlerCollection;","_handlers","[Lorg/mortbay/jetty/Handler;"));
                code.visitConstStmt(CONST_STRING,6,"handler");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,7,4,5,6},new Method("Lorg/mortbay/component/Container;","update",new String[]{ "Ljava/lang/Object;","[Ljava/lang/Object;","[Ljava/lang/Object;","Ljava/lang/String;"},"V"));
                code.visitLabel(L9);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
