package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0345_org_mortbay_jetty_servlet_ServletHandler {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/jetty/servlet/ServletHandler;","Lorg/mortbay/jetty/handler/AbstractHandler;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("ServletHandler.java");
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/MemberClasses;", Visibility.SYSTEM);
            if(av00 != null) {
                {
                    DexAnnotationVisitor av01 = av00.visitArray("value");
                    if(av01 != null) {
                        av01.visit(null, new DexType("Lorg/mortbay/jetty/servlet/ServletHandler$Chain;"));
                        av01.visit(null, new DexType("Lorg/mortbay/jetty/servlet/ServletHandler$CachedChain;"));
                        av01.visitEnd();
                    }
                }
                av00.visitEnd();
            }
        }
        f000___DEFAULT_SERVLET(cv);
        f001___J_S_CONTEXT_TEMPDIR(cv);
        f002___J_S_ERROR_EXCEPTION(cv);
        f003___J_S_ERROR_EXCEPTION_TYPE(cv);
        f004___J_S_ERROR_MESSAGE(cv);
        f005___J_S_ERROR_REQUEST_URI(cv);
        f006___J_S_ERROR_SERVLET_NAME(cv);
        f007___J_S_ERROR_STATUS_CODE(cv);
        f008__chainCache(cv);
        f009__contextHandler(cv);
        f010__filterChainsCached(cv);
        f011__filterMappings(cv);
        f012__filterNameMap(cv);
        f013__filterNameMappings(cv);
        f014__filterPathMappings(cv);
        f015__filters(cv);
        f016__maxFilterChainsCacheSize(cv);
        f017__servletContext(cv);
        f018__servletMappings(cv);
        f019__servletNameMap(cv);
        f020__servletPathMap(cv);
        f021__servlets(cv);
        f022__startWithUnavailable(cv);
        m000__init_(cv);
        m001_getFilterChain(cv);
        m002_addFilter(cv);
        m003_addFilter(cv);
        m004_addFilter(cv);
        m005_addFilterMapping(cv);
        m006_addFilterWithMapping(cv);
        m007_addFilterWithMapping(cv);
        m008_addFilterWithMapping(cv);
        m009_addServlet(cv);
        m010_addServlet(cv);
        m011_addServletMapping(cv);
        m012_addServletWithMapping(cv);
        m013_addServletWithMapping(cv);
        m014_addServletWithMapping(cv);
        m015_customizeFilter(cv);
        m016_customizeFilterDestroy(cv);
        m017_customizeServlet(cv);
        m018_customizeServletDestroy(cv);
        m019_doStart(cv);
        m020_doStop(cv);
        m021_getContextLog(cv);
        m022_getFilter(cv);
        m023_getFilterMappings(cv);
        m024_getFilters(cv);
        m025_getHolderEntry(cv);
        m026_getMaxFilterChainsCacheSize(cv);
        m027_getRequestDispatcher(cv);
        m028_getServlet(cv);
        m029_getServletContext(cv);
        m030_getServletMappings(cv);
        m031_getServlets(cv);
        m032_handle(cv);
        m033_initialize(cv);
        m034_isAvailable(cv);
        m035_isFilterChainsCached(cv);
        m036_isInitializeAtStart(cv);
        m037_isStartWithUnavailable(cv);
        m038_matchesPath(cv);
        m039_newFilterHolder(cv);
        m040_newFilterHolder(cv);
        m041_newServletHolder(cv);
        m042_newServletHolder(cv);
        m043_notFound(cv);
        m044_setFilterChainsCached(cv);
        m045_setFilterMappings(cv);
        m046_setFilters(cv);
        m047_setInitializeAtStart(cv);
        m048_setMaxFilterChainsCacheSize(cv);
        m049_setServer(cv);
        m050_setServletMappings(cv);
        m051_setServlets(cv);
        m052_setStartWithUnavailable(cv);
        m053_updateMappings(cv);
        m054_updateNameMappings(cv);
    }
    public static void f000___DEFAULT_SERVLET(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","__DEFAULT_SERVLET","Ljava/lang/String;"), "default");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001___J_S_CONTEXT_TEMPDIR(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","__J_S_CONTEXT_TEMPDIR","Ljava/lang/String;"), "javax.servlet.context.tempdir");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002___J_S_ERROR_EXCEPTION(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","__J_S_ERROR_EXCEPTION","Ljava/lang/String;"), "javax.servlet.error.exception");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003___J_S_ERROR_EXCEPTION_TYPE(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","__J_S_ERROR_EXCEPTION_TYPE","Ljava/lang/String;"), "javax.servlet.error.exception_type");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f004___J_S_ERROR_MESSAGE(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","__J_S_ERROR_MESSAGE","Ljava/lang/String;"), "javax.servlet.error.message");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f005___J_S_ERROR_REQUEST_URI(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","__J_S_ERROR_REQUEST_URI","Ljava/lang/String;"), "javax.servlet.error.request_uri");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f006___J_S_ERROR_SERVLET_NAME(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","__J_S_ERROR_SERVLET_NAME","Ljava/lang/String;"), "javax.servlet.error.servlet_name");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f007___J_S_ERROR_STATUS_CODE(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","__J_S_ERROR_STATUS_CODE","Ljava/lang/String;"), "javax.servlet.error.status_code");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f008__chainCache(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED|ACC_TRANSIENT, new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_chainCache","[Ljava/util/HashMap;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f009__contextHandler(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_contextHandler","Lorg/mortbay/jetty/handler/ContextHandler;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f010__filterChainsCached(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_filterChainsCached","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f011__filterMappings(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_filterMappings","[Lorg/mortbay/jetty/servlet/FilterMapping;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f012__filterNameMap(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_TRANSIENT, new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_filterNameMap","Ljava/util/Map;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f013__filterNameMappings(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_TRANSIENT, new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_filterNameMappings","Lorg/mortbay/util/MultiMap;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f014__filterPathMappings(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_TRANSIENT, new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_filterPathMappings","Ljava/util/List;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f015__filters(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_filters","[Lorg/mortbay/jetty/servlet/FilterHolder;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f016__maxFilterChainsCacheSize(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_maxFilterChainsCacheSize","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f017__servletContext(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_servletContext","Lorg/mortbay/jetty/handler/ContextHandler$SContext;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f018__servletMappings(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_servletMappings","[Lorg/mortbay/jetty/servlet/ServletMapping;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f019__servletNameMap(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_TRANSIENT, new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_servletNameMap","Ljava/util/Map;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f020__servletPathMap(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_TRANSIENT, new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_servletPathMap","Lorg/mortbay/jetty/servlet/PathMap;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f021__servlets(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_servlets","[Lorg/mortbay/jetty/servlet/ServletHolder;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f022__startWithUnavailable(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_startWithUnavailable","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","<init>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(107,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(86,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(87,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(88,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(93,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(97,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(108,L7);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2},new Method("Lorg/mortbay/jetty/handler/AbstractHandler;","<init>",new String[]{ },"V"));
                code.visitLabel(L2);
                code.visitFieldStmt(IPUT_BOOLEAN,1,2,new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_filterChainsCached","Z"));
                code.visitLabel(L3);
                code.visitConstStmt(CONST_16,0, Integer.valueOf(1000)); // int: 0x000003e8  float:0.000000
                code.visitFieldStmt(IPUT,0,2,new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_maxFilterChainsCacheSize","I"));
                code.visitLabel(L4);
                code.visitFieldStmt(IPUT_BOOLEAN,1,2,new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_startWithUnavailable","Z"));
                code.visitLabel(L5);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/util/HashMap;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/util/HashMap;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_filterNameMap","Ljava/util/Map;"));
                code.visitLabel(L6);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/util/HashMap;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/util/HashMap;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_servletNameMap","Ljava/util/Map;"));
                code.visitLabel(L7);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001_getFilterChain(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PRIVATE, new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","getFilterChain",new String[]{ "I","Ljava/lang/String;","Lorg/mortbay/jetty/servlet/ServletHolder;"},"Ljavax/servlet/FilterChain;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(13);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L2},new String[]{ null});
                DexLabel L5=new DexLabel();
                DexLabel L6=new DexLabel();
                DexLabel L7=new DexLabel();
                code.visitTryCatch(L5,L6,new DexLabel[]{L7},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"requestType");
                ddv.visitParameterName(1,"pathInContext");
                ddv.visitParameterName(2,"servletHolder");
                DexLabel L8=new DexLabel();
                ddv.visitPrologue(L8);
                ddv.visitLineNumber(513,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(515,L9);
                ddv.visitStartLocal(3,L9,"key","Ljava/lang/String;",null);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(517,L10);
                ddv.visitLineNumber(519,L0);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(520,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(580,L12);
                DexLabel L13=new DexLabel();
                ddv.visitEndLocal(3,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(513,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(521,L15);
                ddv.visitRestartLocal(3,L15);
                ddv.visitLineNumber(525,L1);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(528,L16);
                ddv.visitStartLocal(1,L16,"filters","Ljava/lang/Object;",null);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(530,L17);
                DexLabel L18=new DexLabel();
                ddv.visitStartLocal(2,L18,"i","I",null);
                DexLabel L19=new DexLabel();
                ddv.visitEndLocal(1,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(532,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(533,L21);
                ddv.visitStartLocal(4,L21,"mapping","Lorg/mortbay/jetty/servlet/FilterMapping;",null);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(534,L22);
                DexLabel L23=new DexLabel();
                ddv.visitStartLocal(1,L23,"filters","Ljava/lang/Object;",null);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(530,L24);
                ddv.visitEndLocal(1,L24);
                ddv.visitLineNumber(521,L2);
                ddv.visitEndLocal(2,L2);
                ddv.visitEndLocal(4,L2);
                DexLabel L25=new DexLabel();
                ddv.visitStartLocal(1,L25,"filters","Ljava/lang/Object;",null);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(539,L26);
                ddv.visitEndLocal(1,L26);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(542,L27);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(544,L28);
                DexLabel L29=new DexLabel();
                ddv.visitLineNumber(545,L29);
                ddv.visitStartLocal(5,L29,"o","Ljava/lang/Object;",null);
                DexLabel L30=new DexLabel();
                ddv.visitRestartLocal(2,L30);
                DexLabel L31=new DexLabel();
                ddv.visitLineNumber(547,L31);
                DexLabel L32=new DexLabel();
                ddv.visitLineNumber(548,L32);
                ddv.visitRestartLocal(4,L32);
                DexLabel L33=new DexLabel();
                ddv.visitLineNumber(549,L33);
                DexLabel L34=new DexLabel();
                ddv.visitStartLocal(1,L34,"filters","Ljava/lang/Object;",null);
                DexLabel L35=new DexLabel();
                ddv.visitLineNumber(545,L35);
                ddv.visitEndLocal(1,L35);
                DexLabel L36=new DexLabel();
                ddv.visitLineNumber(552,L36);
                ddv.visitEndLocal(4,L36);
                DexLabel L37=new DexLabel();
                ddv.visitLineNumber(553,L37);
                DexLabel L38=new DexLabel();
                ddv.visitLineNumber(555,L38);
                DexLabel L39=new DexLabel();
                ddv.visitLineNumber(556,L39);
                ddv.visitRestartLocal(4,L39);
                DexLabel L40=new DexLabel();
                ddv.visitLineNumber(557,L40);
                DexLabel L41=new DexLabel();
                ddv.visitRestartLocal(1,L41);
                DexLabel L42=new DexLabel();
                ddv.visitLineNumber(553,L42);
                ddv.visitEndLocal(1,L42);
                DexLabel L43=new DexLabel();
                ddv.visitLineNumber(562,L43);
                ddv.visitEndLocal(2,L43);
                ddv.visitEndLocal(5,L43);
                ddv.visitEndLocal(4,L43);
                DexLabel L44=new DexLabel();
                ddv.visitLineNumber(563,L44);
                DexLabel L45=new DexLabel();
                ddv.visitLineNumber(565,L45);
                DexLabel L46=new DexLabel();
                ddv.visitLineNumber(566,L46);
                ddv.visitStartLocal(0,L46,"chain","Ljavax/servlet/FilterChain;",null);
                DexLabel L47=new DexLabel();
                ddv.visitLineNumber(568,L47);
                DexLabel L48=new DexLabel();
                ddv.visitLineNumber(569,L48);
                DexLabel L49=new DexLabel();
                ddv.visitEndLocal(0,L49);
                DexLabel L50=new DexLabel();
                ddv.visitLineNumber(570,L50);
                ddv.visitRestartLocal(0,L50);
                ddv.visitLineNumber(572,L5);
                DexLabel L51=new DexLabel();
                ddv.visitLineNumber(573,L51);
                DexLabel L52=new DexLabel();
                ddv.visitLineNumber(574,L52);
                DexLabel L53=new DexLabel();
                ddv.visitLineNumber(575,L53);
                DexLabel L54=new DexLabel();
                ddv.visitLineNumber(580,L54);
                ddv.visitLineNumber(575,L7);
                DexLabel L55=new DexLabel();
                ddv.visitLineNumber(577,L55);
                DexLabel L56=new DexLabel();
                ddv.visitLineNumber(578,L56);
                DexLabel L57=new DexLabel();
                ddv.visitEndLocal(0,L57);
                DexLabel L58=new DexLabel();
                ddv.visitRestartLocal(0,L58);
                code.visitLabel(L8);
                code.visitJumpStmt(IF_NEZ,11,-1,L13);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12},new Method("Lorg/mortbay/jetty/servlet/ServletHolder;","getName",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitStmt2R(MOVE_OBJECT,3,6);
                code.visitLabel(L9);
                code.visitFieldStmt(IGET_BOOLEAN,6,9,new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_filterChainsCached","Z"));
                code.visitJumpStmt(IF_EQZ,6,-1,L1);
                code.visitFieldStmt(IGET_OBJECT,6,9,new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_chainCache","[Ljava/util/HashMap;"));
                code.visitJumpStmt(IF_EQZ,6,-1,L1);
                code.visitLabel(L10);
                code.visitStmt1R(MONITOR_ENTER,9);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,6,9,new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_chainCache","[Ljava/util/HashMap;"));
                code.visitStmt3R(AGET_OBJECT,6,6,10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,3},new Method("Ljava/util/HashMap;","containsKey",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitJumpStmt(IF_EQZ,6,-1,L15);
                code.visitLabel(L11);
                code.visitFieldStmt(IGET_OBJECT,6,9,new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_chainCache","[Ljava/util/HashMap;"));
                code.visitStmt3R(AGET_OBJECT,6,6,10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,3},new Method("Ljava/util/HashMap;","get",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitTypeStmt(CHECK_CAST,6,-1,"Ljavax/servlet/FilterChain;");
                code.visitStmt1R(MONITOR_EXIT,9);
                code.visitLabel(L12);
                code.visitStmt1R(RETURN_OBJECT,6);
                code.visitLabel(L13);
                code.visitStmt2R(MOVE_OBJECT,3,11);
                code.visitLabel(L14);
                code.visitJumpStmt(GOTO,-1,-1,L9);
                code.visitLabel(L15);
                code.visitStmt1R(MONITOR_EXIT,9);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L16);
                code.visitJumpStmt(IF_EQZ,11,-1,L25);
                code.visitFieldStmt(IGET_OBJECT,6,9,new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_filterPathMappings","Ljava/util/List;"));
                code.visitJumpStmt(IF_EQZ,6,-1,L25);
                code.visitLabel(L17);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L18);
                code.visitStmt2R(MOVE_OBJECT,6,1);
                code.visitLabel(L19);
                code.visitFieldStmt(IGET_OBJECT,7,9,new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_filterPathMappings","Ljava/util/List;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 7},new Method("Ljava/util/List;","size",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitJumpStmt(IF_GE,2,7,L26);
                code.visitLabel(L20);
                code.visitFieldStmt(IGET_OBJECT,7,9,new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_filterPathMappings","Ljava/util/List;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 7,2},new Method("Ljava/util/List;","get",new String[]{ "I"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitTypeStmt(CHECK_CAST,4,-1,"Lorg/mortbay/jetty/servlet/FilterMapping;");
                code.visitLabel(L21);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,11,10},new Method("Lorg/mortbay/jetty/servlet/FilterMapping;","appliesTo",new String[]{ "Ljava/lang/String;","I"},"Z"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitJumpStmt(IF_EQZ,7,-1,L24);
                code.visitLabel(L22);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/jetty/servlet/FilterMapping;","getFilterHolder",new String[]{ },"Lorg/mortbay/jetty/servlet/FilterHolder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 6,7},new Method("Lorg/mortbay/util/LazyList;","add",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L23);
                code.visitStmt2R(MOVE_OBJECT,6,1);
                code.visitLabel(L24);
                code.visitStmt2R1N(ADD_INT_LIT8,2,2,1);
                code.visitJumpStmt(GOTO,-1,-1,L19);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,6);
                code.visitLabel(L3);
                code.visitStmt1R(MONITOR_EXIT,9);
                code.visitLabel(L4);
                code.visitStmt1R(THROW,6);
                code.visitLabel(L25);
                code.visitStmt2R(MOVE_OBJECT,6,1);
                code.visitLabel(L26);
                code.visitJumpStmt(IF_EQZ,12,-1,L43);
                code.visitFieldStmt(IGET_OBJECT,7,9,new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_filterNameMappings","Lorg/mortbay/util/MultiMap;"));
                code.visitJumpStmt(IF_EQZ,7,-1,L43);
                code.visitFieldStmt(IGET_OBJECT,7,9,new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_filterNameMappings","Lorg/mortbay/util/MultiMap;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Lorg/mortbay/util/MultiMap;","size",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitJumpStmt(IF_LEZ,7,-1,L43);
                code.visitLabel(L27);
                code.visitFieldStmt(IGET_OBJECT,7,9,new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_filterNameMappings","Lorg/mortbay/util/MultiMap;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Lorg/mortbay/util/MultiMap;","size",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitJumpStmt(IF_LEZ,7,-1,L43);
                code.visitLabel(L28);
                code.visitFieldStmt(IGET_OBJECT,7,9,new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_filterNameMappings","Lorg/mortbay/util/MultiMap;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12},new Method("Lorg/mortbay/jetty/servlet/ServletHolder;","getName",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,8},new Method("Lorg/mortbay/util/MultiMap;","get",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitLabel(L29);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L30);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 5},new Method("Lorg/mortbay/util/LazyList;","size",new String[]{ "Ljava/lang/Object;"},"I"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitJumpStmt(IF_GE,2,7,L36);
                code.visitLabel(L31);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 5,2},new Method("Lorg/mortbay/util/LazyList;","get",new String[]{ "Ljava/lang/Object;","I"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitTypeStmt(CHECK_CAST,4,-1,"Lorg/mortbay/jetty/servlet/FilterMapping;");
                code.visitLabel(L32);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,10},new Method("Lorg/mortbay/jetty/servlet/FilterMapping;","appliesTo",new String[]{ "I"},"Z"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitJumpStmt(IF_EQZ,7,-1,L35);
                code.visitLabel(L33);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/jetty/servlet/FilterMapping;","getFilterHolder",new String[]{ },"Lorg/mortbay/jetty/servlet/FilterHolder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 6,7},new Method("Lorg/mortbay/util/LazyList;","add",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L34);
                code.visitStmt2R(MOVE_OBJECT,6,1);
                code.visitLabel(L35);
                code.visitStmt2R1N(ADD_INT_LIT8,2,2,1);
                code.visitJumpStmt(GOTO,-1,-1,L30);
                code.visitLabel(L36);
                code.visitFieldStmt(IGET_OBJECT,7,9,new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_filterNameMappings","Lorg/mortbay/util/MultiMap;"));
                code.visitConstStmt(CONST_STRING,8,"*");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,8},new Method("Lorg/mortbay/util/MultiMap;","get",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitLabel(L37);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                DexLabel L59=new DexLabel();
                code.visitLabel(L59);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 5},new Method("Lorg/mortbay/util/LazyList;","size",new String[]{ "Ljava/lang/Object;"},"I"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitJumpStmt(IF_GE,2,7,L43);
                code.visitLabel(L38);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 5,2},new Method("Lorg/mortbay/util/LazyList;","get",new String[]{ "Ljava/lang/Object;","I"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitTypeStmt(CHECK_CAST,4,-1,"Lorg/mortbay/jetty/servlet/FilterMapping;");
                code.visitLabel(L39);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,10},new Method("Lorg/mortbay/jetty/servlet/FilterMapping;","appliesTo",new String[]{ "I"},"Z"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitJumpStmt(IF_EQZ,7,-1,L42);
                code.visitLabel(L40);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/jetty/servlet/FilterMapping;","getFilterHolder",new String[]{ },"Lorg/mortbay/jetty/servlet/FilterHolder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 6,7},new Method("Lorg/mortbay/util/LazyList;","add",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L41);
                code.visitStmt2R(MOVE_OBJECT,6,1);
                code.visitLabel(L42);
                code.visitStmt2R1N(ADD_INT_LIT8,2,2,1);
                code.visitJumpStmt(GOTO,-1,-1,L59);
                code.visitLabel(L43);
                code.visitJumpStmt(IF_NEZ,6,-1,L45);
                code.visitLabel(L44);
                code.visitConstStmt(CONST_4,6, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO_16,-1,-1,L12);
                code.visitLabel(L45);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L46);
                code.visitFieldStmt(IGET_BOOLEAN,7,9,new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_filterChainsCached","Z"));
                code.visitJumpStmt(IF_EQZ,7,-1,L55);
                code.visitLabel(L47);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 6},new Method("Lorg/mortbay/util/LazyList;","size",new String[]{ "Ljava/lang/Object;"},"I"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitJumpStmt(IF_LEZ,7,-1,L50);
                code.visitLabel(L48);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/jetty/servlet/ServletHandler$CachedChain;");
                code.visitLabel(L49);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,9,6,12},new Method("Lorg/mortbay/jetty/servlet/ServletHandler$CachedChain;","<init>",new String[]{ "Lorg/mortbay/jetty/servlet/ServletHandler;","Ljava/lang/Object;","Lorg/mortbay/jetty/servlet/ServletHolder;"},"V"));
                code.visitLabel(L50);
                code.visitStmt1R(MONITOR_ENTER,9);
                code.visitLabel(L5);
                code.visitFieldStmt(IGET,6,9,new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_maxFilterChainsCacheSize","I"));
                code.visitJumpStmt(IF_LEZ,6,-1,L52);
                code.visitFieldStmt(IGET_OBJECT,6,9,new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_chainCache","[Ljava/util/HashMap;"));
                code.visitStmt3R(AGET_OBJECT,6,6,10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/util/HashMap;","size",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitFieldStmt(IGET,7,9,new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_maxFilterChainsCacheSize","I"));
                code.visitJumpStmt(IF_LE,6,7,L52);
                code.visitLabel(L51);
                code.visitFieldStmt(IGET_OBJECT,6,9,new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_chainCache","[Ljava/util/HashMap;"));
                code.visitStmt3R(AGET_OBJECT,6,6,10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/util/HashMap;","clear",new String[]{ },"V"));
                code.visitLabel(L52);
                code.visitFieldStmt(IGET_OBJECT,6,9,new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_chainCache","[Ljava/util/HashMap;"));
                code.visitStmt3R(AGET_OBJECT,6,6,10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,3,0},new Method("Ljava/util/HashMap;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L53);
                code.visitStmt1R(MONITOR_EXIT,9);
                DexLabel L60=new DexLabel();
                code.visitLabel(L60);
                code.visitStmt2R(MOVE_OBJECT,6,0);
                code.visitLabel(L54);
                code.visitJumpStmt(GOTO_16,-1,-1,L12);
                code.visitLabel(L7);
                code.visitStmt1R(MOVE_EXCEPTION,6);
                code.visitStmt1R(MONITOR_EXIT,9);
                code.visitLabel(L6);
                code.visitStmt1R(THROW,6);
                code.visitLabel(L55);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 6},new Method("Lorg/mortbay/util/LazyList;","size",new String[]{ "Ljava/lang/Object;"},"I"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitJumpStmt(IF_LEZ,7,-1,L60);
                code.visitLabel(L56);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/jetty/servlet/ServletHandler$Chain;");
                code.visitLabel(L57);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,9,6,12},new Method("Lorg/mortbay/jetty/servlet/ServletHandler$Chain;","<init>",new String[]{ "Lorg/mortbay/jetty/servlet/ServletHandler;","Ljava/lang/Object;","Lorg/mortbay/jetty/servlet/ServletHolder;"},"V"));
                code.visitLabel(L58);
                code.visitJumpStmt(GOTO,-1,-1,L60);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_addFilter(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","addFilter",new String[]{ "Ljava/lang/String;","Ljava/lang/String;","I"},"Lorg/mortbay/jetty/servlet/FilterHolder;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"className");
                ddv.visitParameterName(1,"pathSpec");
                ddv.visitParameterName(2,"dispatches");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(905,L0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2,3,4},new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","addFilterWithMapping",new String[]{ "Ljava/lang/String;","Ljava/lang/String;","I"},"Lorg/mortbay/jetty/servlet/FilterHolder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_addFilter(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","addFilter",new String[]{ "Lorg/mortbay/jetty/servlet/FilterHolder;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"filter");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(928,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(929,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(930,L2);
                code.visitLabel(L0);
                code.visitJumpStmt(IF_EQZ,3,-1,L2);
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","getFilters",new String[]{ },"[Lorg/mortbay/jetty/servlet/FilterHolder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitConstStmt(CONST_CLASS,1,new DexType("Lorg/mortbay/jetty/servlet/FilterHolder;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,3,1},new Method("Lorg/mortbay/util/LazyList;","addToArray",new String[]{ "[Ljava/lang/Object;","Ljava/lang/Object;","Ljava/lang/Class;"},"[Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitTypeStmt(CHECK_CAST,0,-1,"[Lorg/mortbay/jetty/servlet/FilterHolder;");
                code.visitTypeStmt(CHECK_CAST,0,-1,"[Lorg/mortbay/jetty/servlet/FilterHolder;");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,0},new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","setFilters",new String[]{ "[Lorg/mortbay/jetty/servlet/FilterHolder;"},"V"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_addFilter(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","addFilter",new String[]{ "Lorg/mortbay/jetty/servlet/FilterHolder;","Lorg/mortbay/jetty/servlet/FilterMapping;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"filter");
                ddv.visitParameterName(1,"filterMapping");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(916,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(917,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(918,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(919,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(920,L4);
                code.visitLabel(L0);
                code.visitJumpStmt(IF_EQZ,3,-1,L2);
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","getFilters",new String[]{ },"[Lorg/mortbay/jetty/servlet/FilterHolder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitConstStmt(CONST_CLASS,1,new DexType("Lorg/mortbay/jetty/servlet/FilterHolder;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,3,1},new Method("Lorg/mortbay/util/LazyList;","addToArray",new String[]{ "[Ljava/lang/Object;","Ljava/lang/Object;","Ljava/lang/Class;"},"[Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitTypeStmt(CHECK_CAST,0,-1,"[Lorg/mortbay/jetty/servlet/FilterHolder;");
                code.visitTypeStmt(CHECK_CAST,0,-1,"[Lorg/mortbay/jetty/servlet/FilterHolder;");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,0},new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","setFilters",new String[]{ "[Lorg/mortbay/jetty/servlet/FilterHolder;"},"V"));
                code.visitLabel(L2);
                code.visitJumpStmt(IF_EQZ,4,-1,L4);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","getFilterMappings",new String[]{ },"[Lorg/mortbay/jetty/servlet/FilterMapping;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitConstStmt(CONST_CLASS,1,new DexType("Lorg/mortbay/jetty/servlet/FilterMapping;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,4,1},new Method("Lorg/mortbay/util/LazyList;","addToArray",new String[]{ "[Ljava/lang/Object;","Ljava/lang/Object;","Ljava/lang/Class;"},"[Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitTypeStmt(CHECK_CAST,0,-1,"[Lorg/mortbay/jetty/servlet/FilterMapping;");
                code.visitTypeStmt(CHECK_CAST,0,-1,"[Lorg/mortbay/jetty/servlet/FilterMapping;");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,0},new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","setFilterMappings",new String[]{ "[Lorg/mortbay/jetty/servlet/FilterMapping;"},"V"));
                code.visitLabel(L4);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_addFilterMapping(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","addFilterMapping",new String[]{ "Lorg/mortbay/jetty/servlet/FilterMapping;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"mapping");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(938,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(939,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(940,L2);
                code.visitLabel(L0);
                code.visitJumpStmt(IF_EQZ,3,-1,L2);
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","getFilterMappings",new String[]{ },"[Lorg/mortbay/jetty/servlet/FilterMapping;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitConstStmt(CONST_CLASS,1,new DexType("Lorg/mortbay/jetty/servlet/FilterMapping;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,3,1},new Method("Lorg/mortbay/util/LazyList;","addToArray",new String[]{ "[Ljava/lang/Object;","Ljava/lang/Object;","Ljava/lang/Class;"},"[Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitTypeStmt(CHECK_CAST,0,-1,"[Lorg/mortbay/jetty/servlet/FilterMapping;");
                code.visitTypeStmt(CHECK_CAST,0,-1,"[Lorg/mortbay/jetty/servlet/FilterMapping;");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,0},new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","setFilterMappings",new String[]{ "[Lorg/mortbay/jetty/servlet/FilterMapping;"},"V"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_addFilterWithMapping(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","addFilterWithMapping",new String[]{ "Ljava/lang/Class;","Ljava/lang/String;","I"},"Lorg/mortbay/jetty/servlet/FilterHolder;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"filter");
                ddv.visitParameterName(1,"pathSpec");
                ddv.visitParameterName(2,"dispatches");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(834,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(835,L1);
                ddv.visitStartLocal(0,L1,"holder","Lorg/mortbay/jetty/servlet/FilterHolder;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(837,L2);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","newFilterHolder",new String[]{ "Ljava/lang/Class;"},"Lorg/mortbay/jetty/servlet/FilterHolder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,0,3,4},new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","addFilterWithMapping",new String[]{ "Lorg/mortbay/jetty/servlet/FilterHolder;","Ljava/lang/String;","I"},"V"));
                code.visitLabel(L2);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m007_addFilterWithMapping(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","addFilterWithMapping",new String[]{ "Ljava/lang/String;","Ljava/lang/String;","I"},"Lorg/mortbay/jetty/servlet/FilterHolder;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"className");
                ddv.visitParameterName(1,"pathSpec");
                ddv.visitParameterName(2,"dispatches");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(850,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(851,L1);
                ddv.visitStartLocal(0,L1,"holder","Lorg/mortbay/jetty/servlet/FilterHolder;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(852,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(854,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(855,L4);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,1},new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","newFilterHolder",new String[]{ "Ljava/lang/Class;"},"Lorg/mortbay/jetty/servlet/FilterHolder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitConstStmt(CONST_STRING,2,"-");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/Object;","hashCode",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "I"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/servlet/FilterHolder;","setName",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,4},new Method("Lorg/mortbay/jetty/servlet/FilterHolder;","setClassName",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,0,5,6},new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","addFilterWithMapping",new String[]{ "Lorg/mortbay/jetty/servlet/FilterHolder;","Ljava/lang/String;","I"},"V"));
                code.visitLabel(L4);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m008_addFilterWithMapping(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","addFilterWithMapping",new String[]{ "Lorg/mortbay/jetty/servlet/FilterHolder;","Ljava/lang/String;","I"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(10);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                DexLabel L3=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2,L3},new String[]{ "Ljava/lang/RuntimeException;","Ljava/lang/Error;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"holder");
                ddv.visitParameterName(1,"pathSpec");
                ddv.visitParameterName(2,"dispatches");
                DexLabel L4=new DexLabel();
                ddv.visitPrologue(L4);
                ddv.visitLineNumber(868,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(869,L5);
                ddv.visitStartLocal(2,L5,"holders","[Lorg/mortbay/jetty/servlet/FilterHolder;",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(870,L6);
                ddv.visitLineNumber(874,L0);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(876,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(877,L8);
                ddv.visitStartLocal(3,L8,"mapping","Lorg/mortbay/jetty/servlet/FilterMapping;",null);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(878,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(879,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(880,L11);
                ddv.visitLineNumber(893,L1);
                ddv.visitLineNumber(882,L2);
                ddv.visitEndLocal(3,L2);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(884,L12);
                ddv.visitStartLocal(1,L12,"e","Ljava/lang/RuntimeException;",null);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(885,L13);
                ddv.visitLineNumber(887,L3);
                ddv.visitEndLocal(1,L3);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(889,L14);
                ddv.visitStartLocal(1,L14,"e","Ljava/lang/Error;",null);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(890,L15);
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","getFilters",new String[]{ },"[Lorg/mortbay/jetty/servlet/FilterHolder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L5);
                code.visitJumpStmt(IF_EQZ,2,-1,L0);
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("[Lorg/mortbay/jetty/servlet/FilterHolder;","clone",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitTypeStmt(CHECK_CAST,4,-1,"[Lorg/mortbay/jetty/servlet/FilterHolder;");
                code.visitStmt2R(MOVE_OBJECT,0,4);
                code.visitTypeStmt(CHECK_CAST,0,-1,"[Lorg/mortbay/jetty/servlet/FilterHolder;");
                code.visitStmt2R(MOVE_OBJECT,2,0);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_CLASS,4,new DexType("Lorg/mortbay/jetty/servlet/FilterHolder;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2,7,4},new Method("Lorg/mortbay/util/LazyList;","addToArray",new String[]{ "[Ljava/lang/Object;","Ljava/lang/Object;","Ljava/lang/Class;"},"[Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitTypeStmt(CHECK_CAST,4,-1,"[Lorg/mortbay/jetty/servlet/FilterHolder;");
                code.visitTypeStmt(CHECK_CAST,4,-1,"[Lorg/mortbay/jetty/servlet/FilterHolder;");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,4},new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","setFilters",new String[]{ "[Lorg/mortbay/jetty/servlet/FilterHolder;"},"V"));
                code.visitLabel(L7);
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Lorg/mortbay/jetty/servlet/FilterMapping;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3},new Method("Lorg/mortbay/jetty/servlet/FilterMapping;","<init>",new String[]{ },"V"));
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Lorg/mortbay/jetty/servlet/FilterHolder;","getName",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Lorg/mortbay/jetty/servlet/FilterMapping;","setFilterName",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,8},new Method("Lorg/mortbay/jetty/servlet/FilterMapping;","setPathSpec",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,9},new Method("Lorg/mortbay/jetty/servlet/FilterMapping;","setDispatches",new String[]{ "I"},"V"));
                code.visitLabel(L11);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","getFilterMappings",new String[]{ },"[Lorg/mortbay/jetty/servlet/FilterMapping;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitConstStmt(CONST_CLASS,5,new DexType("Lorg/mortbay/jetty/servlet/FilterMapping;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 4,3,5},new Method("Lorg/mortbay/util/LazyList;","addToArray",new String[]{ "[Ljava/lang/Object;","Ljava/lang/Object;","Ljava/lang/Class;"},"[Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitTypeStmt(CHECK_CAST,4,-1,"[Lorg/mortbay/jetty/servlet/FilterMapping;");
                code.visitTypeStmt(CHECK_CAST,4,-1,"[Lorg/mortbay/jetty/servlet/FilterMapping;");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,4},new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","setFilterMappings",new String[]{ "[Lorg/mortbay/jetty/servlet/FilterMapping;"},"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,4);
                code.visitStmt2R(MOVE_OBJECT,1,4);
                code.visitLabel(L12);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,2},new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","setFilters",new String[]{ "[Lorg/mortbay/jetty/servlet/FilterHolder;"},"V"));
                code.visitLabel(L13);
                code.visitStmt1R(THROW,1);
                code.visitLabel(L3);
                code.visitStmt1R(MOVE_EXCEPTION,4);
                code.visitStmt2R(MOVE_OBJECT,1,4);
                code.visitLabel(L14);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,2},new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","setFilters",new String[]{ "[Lorg/mortbay/jetty/servlet/FilterHolder;"},"V"));
                code.visitLabel(L15);
                code.visitStmt1R(THROW,1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m009_addServlet(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","addServlet",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"Lorg/mortbay/jetty/servlet/ServletHolder;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"className");
                ddv.visitParameterName(1,"pathSpec");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(781,L0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2,3},new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","addServletWithMapping",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"Lorg/mortbay/jetty/servlet/ServletHolder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m010_addServlet(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","addServlet",new String[]{ "Lorg/mortbay/jetty/servlet/ServletHolder;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"holder");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(791,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(792,L1);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","getServlets",new String[]{ },"[Lorg/mortbay/jetty/servlet/ServletHolder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitConstStmt(CONST_CLASS,1,new DexType("Lorg/mortbay/jetty/servlet/ServletHolder;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,3,1},new Method("Lorg/mortbay/util/LazyList;","addToArray",new String[]{ "[Ljava/lang/Object;","Ljava/lang/Object;","Ljava/lang/Class;"},"[Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitTypeStmt(CHECK_CAST,0,-1,"[Lorg/mortbay/jetty/servlet/ServletHolder;");
                code.visitTypeStmt(CHECK_CAST,0,-1,"[Lorg/mortbay/jetty/servlet/ServletHolder;");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,0},new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","setServlets",new String[]{ "[Lorg/mortbay/jetty/servlet/ServletHolder;"},"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m011_addServletMapping(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","addServletMapping",new String[]{ "Lorg/mortbay/jetty/servlet/ServletMapping;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"mapping");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(800,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(801,L1);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","getServletMappings",new String[]{ },"[Lorg/mortbay/jetty/servlet/ServletMapping;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitConstStmt(CONST_CLASS,1,new DexType("Lorg/mortbay/jetty/servlet/ServletMapping;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,3,1},new Method("Lorg/mortbay/util/LazyList;","addToArray",new String[]{ "[Ljava/lang/Object;","Ljava/lang/Object;","Ljava/lang/Class;"},"[Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitTypeStmt(CHECK_CAST,0,-1,"[Lorg/mortbay/jetty/servlet/ServletMapping;");
                code.visitTypeStmt(CHECK_CAST,0,-1,"[Lorg/mortbay/jetty/servlet/ServletMapping;");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,0},new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","setServletMappings",new String[]{ "[Lorg/mortbay/jetty/servlet/ServletMapping;"},"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m012_addServletWithMapping(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","addServletWithMapping",new String[]{ "Ljava/lang/Class;","Ljava/lang/String;"},"Lorg/mortbay/jetty/servlet/ServletHolder;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"servlet");
                ddv.visitParameterName(1,"pathSpec");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(733,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(734,L1);
                ddv.visitStartLocal(0,L1,"holder","Lorg/mortbay/jetty/servlet/ServletHolder;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(736,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(738,L3);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","newServletHolder",new String[]{ "Ljava/lang/Class;"},"Lorg/mortbay/jetty/servlet/ServletHolder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","getServlets",new String[]{ },"[Lorg/mortbay/jetty/servlet/ServletHolder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitConstStmt(CONST_CLASS,2,new DexType("Lorg/mortbay/jetty/servlet/ServletHolder;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1,0,2},new Method("Lorg/mortbay/util/LazyList;","addToArray",new String[]{ "[Ljava/lang/Object;","Ljava/lang/Object;","Ljava/lang/Class;"},"[Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitTypeStmt(CHECK_CAST,1,-1,"[Lorg/mortbay/jetty/servlet/ServletHolder;");
                code.visitTypeStmt(CHECK_CAST,1,-1,"[Lorg/mortbay/jetty/servlet/ServletHolder;");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,1},new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","setServlets",new String[]{ "[Lorg/mortbay/jetty/servlet/ServletHolder;"},"V"));
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,0,5},new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","addServletWithMapping",new String[]{ "Lorg/mortbay/jetty/servlet/ServletHolder;","Ljava/lang/String;"},"V"));
                code.visitLabel(L3);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m013_addServletWithMapping(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","addServletWithMapping",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"Lorg/mortbay/jetty/servlet/ServletHolder;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"className");
                ddv.visitParameterName(1,"pathSpec");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(718,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(719,L1);
                ddv.visitStartLocal(0,L1,"holder","Lorg/mortbay/jetty/servlet/ServletHolder;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(720,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(722,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(724,L4);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,1},new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","newServletHolder",new String[]{ "Ljava/lang/Class;"},"Lorg/mortbay/jetty/servlet/ServletHolder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitConstStmt(CONST_STRING,2,"-");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/servlet/ServletHolder;","hashCode",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "I"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/servlet/ServletHolder;","setName",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,4},new Method("Lorg/mortbay/jetty/servlet/ServletHolder;","setClassName",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,0,5},new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","addServletWithMapping",new String[]{ "Lorg/mortbay/jetty/servlet/ServletHolder;","Ljava/lang/String;"},"V"));
                code.visitLabel(L4);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m014_addServletWithMapping(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","addServletWithMapping",new String[]{ "Lorg/mortbay/jetty/servlet/ServletHolder;","Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(9);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/lang/Exception;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"servlet");
                ddv.visitParameterName(1,"pathSpec");
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(750,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(751,L4);
                ddv.visitStartLocal(2,L4,"holders","[Lorg/mortbay/jetty/servlet/ServletHolder;",null);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(752,L5);
                ddv.visitLineNumber(756,L0);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(758,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(759,L7);
                ddv.visitStartLocal(3,L7,"mapping","Lorg/mortbay/jetty/servlet/ServletMapping;",null);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(760,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(761,L9);
                ddv.visitLineNumber(770,L1);
                ddv.visitLineNumber(763,L2);
                ddv.visitEndLocal(3,L2);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(765,L10);
                ddv.visitStartLocal(1,L10,"e","Ljava/lang/Exception;",null);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(766,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(767,L12);
                DexLabel L13=new DexLabel();
                ddv.visitEndLocal(1,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(768,L14);
                ddv.visitRestartLocal(1,L14);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","getServlets",new String[]{ },"[Lorg/mortbay/jetty/servlet/ServletHolder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L4);
                code.visitJumpStmt(IF_EQZ,2,-1,L0);
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("[Lorg/mortbay/jetty/servlet/ServletHolder;","clone",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitTypeStmt(CHECK_CAST,4,-1,"[Lorg/mortbay/jetty/servlet/ServletHolder;");
                code.visitStmt2R(MOVE_OBJECT,0,4);
                code.visitTypeStmt(CHECK_CAST,0,-1,"[Lorg/mortbay/jetty/servlet/ServletHolder;");
                code.visitStmt2R(MOVE_OBJECT,2,0);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_CLASS,4,new DexType("Lorg/mortbay/jetty/servlet/ServletHolder;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2,7,4},new Method("Lorg/mortbay/util/LazyList;","addToArray",new String[]{ "[Ljava/lang/Object;","Ljava/lang/Object;","Ljava/lang/Class;"},"[Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitTypeStmt(CHECK_CAST,4,-1,"[Lorg/mortbay/jetty/servlet/ServletHolder;");
                code.visitTypeStmt(CHECK_CAST,4,-1,"[Lorg/mortbay/jetty/servlet/ServletHolder;");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,4},new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","setServlets",new String[]{ "[Lorg/mortbay/jetty/servlet/ServletHolder;"},"V"));
                code.visitLabel(L6);
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Lorg/mortbay/jetty/servlet/ServletMapping;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3},new Method("Lorg/mortbay/jetty/servlet/ServletMapping;","<init>",new String[]{ },"V"));
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Lorg/mortbay/jetty/servlet/ServletHolder;","getName",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Lorg/mortbay/jetty/servlet/ServletMapping;","setServletName",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,8},new Method("Lorg/mortbay/jetty/servlet/ServletMapping;","setPathSpec",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","getServletMappings",new String[]{ },"[Lorg/mortbay/jetty/servlet/ServletMapping;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitConstStmt(CONST_CLASS,5,new DexType("Lorg/mortbay/jetty/servlet/ServletMapping;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 4,3,5},new Method("Lorg/mortbay/util/LazyList;","addToArray",new String[]{ "[Ljava/lang/Object;","Ljava/lang/Object;","Ljava/lang/Class;"},"[Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitTypeStmt(CHECK_CAST,4,-1,"[Lorg/mortbay/jetty/servlet/ServletMapping;");
                code.visitTypeStmt(CHECK_CAST,4,-1,"[Lorg/mortbay/jetty/servlet/ServletMapping;");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,4},new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","setServletMappings",new String[]{ "[Lorg/mortbay/jetty/servlet/ServletMapping;"},"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,4);
                code.visitStmt2R(MOVE_OBJECT,1,4);
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,2},new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","setServlets",new String[]{ "[Lorg/mortbay/jetty/servlet/ServletHolder;"},"V"));
                code.visitLabel(L11);
                code.visitTypeStmt(INSTANCE_OF,4,1,"Ljava/lang/RuntimeException;");
                code.visitJumpStmt(IF_EQZ,4,-1,L14);
                code.visitLabel(L12);
                code.visitTypeStmt(CHECK_CAST,1,-1,"Ljava/lang/RuntimeException;");
                code.visitLabel(L13);
                code.visitStmt1R(THROW,1);
                code.visitLabel(L14);
                code.visitTypeStmt(NEW_INSTANCE,4,-1,"Ljava/lang/RuntimeException;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4,1},new Method("Ljava/lang/RuntimeException;","<init>",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitStmt1R(THROW,4);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m015_customizeFilter(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","customizeFilter",new String[]{ "Ljavax/servlet/Filter;"},"Ljavax/servlet/Filter;"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/Exception;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"filter");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1288,L0);
                code.visitLabel(L0);
                code.visitStmt1R(RETURN_OBJECT,1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m016_customizeFilterDestroy(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","customizeFilterDestroy",new String[]{ "Ljavax/servlet/Filter;"},"Ljavax/servlet/Filter;"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/Exception;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"filter");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1295,L0);
                code.visitLabel(L0);
                code.visitStmt1R(RETURN_OBJECT,1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m017_customizeServlet(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","customizeServlet",new String[]{ "Ljavax/servlet/Servlet;"},"Ljavax/servlet/Servlet;"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/Exception;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"servlet");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1263,L0);
                code.visitLabel(L0);
                code.visitStmt1R(RETURN_OBJECT,1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m018_customizeServletDestroy(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","customizeServletDestroy",new String[]{ "Ljavax/servlet/Servlet;"},"Ljavax/servlet/Servlet;"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/Exception;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"servlet");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1270,L0);
                code.visitLabel(L0);
                code.visitStmt1R(RETURN_OBJECT,1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m019_doStart(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","doStart",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/Exception;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L5=new DexLabel();
                ddv.visitPrologue(L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(138,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(139,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(141,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(142,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(144,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(145,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(147,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(149,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(150,L14);
                ddv.visitLineNumber(151,L1);
                ddv.visitLineNumber(139,L3);
                ddv.visitLineNumber(138,L2);
                code.visitLabel(L5);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L6);
                code.visitStmt1R(MONITOR_ENTER,3);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/jetty/handler/ContextHandler;","getCurrentContext",new String[]{ },"Lorg/mortbay/jetty/handler/ContextHandler$SContext;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IPUT_OBJECT,0,3,new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_servletContext","Lorg/mortbay/jetty/handler/ContextHandler$SContext;"));
                code.visitLabel(L7);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_servletContext","Lorg/mortbay/jetty/handler/ContextHandler$SContext;"));
                code.visitJumpStmt(IF_NEZ,0,-1,L3);
                code.visitStmt2R(MOVE_OBJECT,0,1);
                DexLabel L15=new DexLabel();
                code.visitLabel(L15);
                code.visitFieldStmt(IPUT_OBJECT,0,3,new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_contextHandler","Lorg/mortbay/jetty/handler/ContextHandler;"));
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","updateNameMappings",new String[]{ },"V"));
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","updateMappings",new String[]{ },"V"));
                code.visitLabel(L10);
                code.visitFieldStmt(IGET_BOOLEAN,0,3,new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_filterChainsCached","Z"));
                code.visitJumpStmt(IF_EQZ,0,-1,L12);
                code.visitLabel(L11);
                code.visitConstStmt(CONST_16,0, Integer.valueOf(9)); // int: 0x00000009  float:0.000000
                code.visitTypeStmt(NEW_ARRAY,0,0,"[Ljava/util/HashMap;");
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt3R(APUT_OBJECT,2,0,1);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Ljava/util/HashMap;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2},new Method("Ljava/util/HashMap;","<init>",new String[]{ },"V"));
                code.visitStmt3R(APUT_OBJECT,2,0,1);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Ljava/util/HashMap;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2},new Method("Ljava/util/HashMap;","<init>",new String[]{ },"V"));
                code.visitStmt3R(APUT_OBJECT,2,0,1);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(3)); // int: 0x00000003  float:0.000000
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt3R(APUT_OBJECT,2,0,1);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(4)); // int: 0x00000004  float:0.000000
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Ljava/util/HashMap;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2},new Method("Ljava/util/HashMap;","<init>",new String[]{ },"V"));
                code.visitStmt3R(APUT_OBJECT,2,0,1);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(5)); // int: 0x00000005  float:0.000000
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt3R(APUT_OBJECT,2,0,1);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(6)); // int: 0x00000006  float:0.000000
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt3R(APUT_OBJECT,2,0,1);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(7)); // int: 0x00000007  float:0.000000
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt3R(APUT_OBJECT,2,0,1);
                code.visitConstStmt(CONST_16,1, Integer.valueOf(8)); // int: 0x00000008  float:0.000000
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Ljava/util/HashMap;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2},new Method("Ljava/util/HashMap;","<init>",new String[]{ },"V"));
                code.visitStmt3R(APUT_OBJECT,2,0,1);
                code.visitFieldStmt(IPUT_OBJECT,0,3,new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_chainCache","[Ljava/util/HashMap;"));
                code.visitLabel(L12);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 3},new Method("Lorg/mortbay/jetty/handler/AbstractHandler;","doStart",new String[]{ },"V"));
                code.visitLabel(L13);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_contextHandler","Lorg/mortbay/jetty/handler/ContextHandler;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L14);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_contextHandler","Lorg/mortbay/jetty/handler/ContextHandler;"));
                code.visitTypeStmt(INSTANCE_OF,0,0,"Lorg/mortbay/jetty/servlet/Context;");
                code.visitJumpStmt(IF_NEZ,0,-1,L1);
                code.visitLabel(L14);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","initialize",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitStmt1R(MONITOR_EXIT,3);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_servletContext","Lorg/mortbay/jetty/handler/ContextHandler$SContext;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/handler/ContextHandler$SContext;","getContextHandler",new String[]{ },"Lorg/mortbay/jetty/handler/ContextHandler;"));
                code.visitLabel(L4);
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitJumpStmt(GOTO,-1,-1,L15);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,0);
                code.visitStmt1R(MONITOR_EXIT,3);
                code.visitStmt1R(THROW,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m020_doStop(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","doStop",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/Exception;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                DexLabel L5=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L5,L2},new String[]{ "Ljava/lang/Exception;",null});
                DexLabel L6=new DexLabel();
                DexLabel L7=new DexLabel();
                code.visitTryCatch(L6,L7,new DexLabel[]{L2},new String[]{ null});
                DexLabel L8=new DexLabel();
                DexLabel L9=new DexLabel();
                DexLabel L10=new DexLabel();
                code.visitTryCatch(L8,L9,new DexLabel[]{L10,L2},new String[]{ "Ljava/lang/Exception;",null});
                DexLabel L11=new DexLabel();
                DexLabel L12=new DexLabel();
                code.visitTryCatch(L11,L12,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L13=new DexLabel();
                ddv.visitPrologue(L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(157,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(160,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(162,L16);
                ddv.visitStartLocal(1,L1,"i","I",null);
                DexLabel L17=new DexLabel();
                ddv.visitEndLocal(1,L17);
                ddv.visitStartLocal(2,L17,"i","I",null);
                DexLabel L18=new DexLabel();
                ddv.visitRestartLocal(1,L18);
                ddv.visitLineNumber(164,L3);
                ddv.visitEndLocal(2,L3);
                DexLabel L19=new DexLabel();
                ddv.visitRestartLocal(2,L19);
                ddv.visitEndLocal(2,L5);
                ddv.visitStartLocal(0,L6,"e","Ljava/lang/Exception;",null);
                DexLabel L20=new DexLabel();
                ddv.visitRestartLocal(2,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(169,L21);
                ddv.visitEndLocal(1,L21);
                ddv.visitEndLocal(0,L21);
                ddv.visitEndLocal(2,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(171,L22);
                ddv.visitRestartLocal(1,L7);
                DexLabel L23=new DexLabel();
                ddv.visitEndLocal(1,L23);
                ddv.visitRestartLocal(2,L23);
                DexLabel L24=new DexLabel();
                ddv.visitRestartLocal(1,L24);
                ddv.visitLineNumber(173,L8);
                ddv.visitEndLocal(2,L8);
                DexLabel L25=new DexLabel();
                ddv.visitRestartLocal(2,L25);
                ddv.visitEndLocal(2,L10);
                ddv.visitRestartLocal(0,L11);
                DexLabel L26=new DexLabel();
                ddv.visitRestartLocal(2,L26);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(177,L27);
                ddv.visitEndLocal(1,L27);
                ddv.visitEndLocal(0,L27);
                ddv.visitEndLocal(2,L27);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(178,L28);
                DexLabel L29=new DexLabel();
                ddv.visitLineNumber(180,L29);
                DexLabel L30=new DexLabel();
                ddv.visitLineNumber(181,L30);
                ddv.visitLineNumber(182,L12);
                ddv.visitLineNumber(157,L2);
                code.visitLabel(L13);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitConstStmt(CONST_STRING,3,"EXCEPTION ");
                code.visitLabel(L14);
                code.visitStmt1R(MONITOR_ENTER,5);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 5},new Method("Lorg/mortbay/jetty/handler/AbstractHandler;","doStop",new String[]{ },"V"));
                code.visitLabel(L15);
                code.visitFieldStmt(IGET_OBJECT,3,5,new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_filters","[Lorg/mortbay/jetty/servlet/FilterHolder;"));
                code.visitJumpStmt(IF_EQZ,3,-1,L21);
                code.visitLabel(L16);
                code.visitFieldStmt(IGET_OBJECT,3,5,new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_filters","[Lorg/mortbay/jetty/servlet/FilterHolder;"));
                code.visitStmt2R(ARRAY_LENGTH,1,3);
                code.visitLabel(L1);
                code.visitStmt2R(MOVE,2,1);
                code.visitLabel(L17);
                code.visitStmt3R(SUB_INT,1,2,4);
                code.visitLabel(L18);
                code.visitJumpStmt(IF_LEZ,2,-1,L21);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,3,5,new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_filters","[Lorg/mortbay/jetty/servlet/FilterHolder;"));
                code.visitStmt3R(AGET_OBJECT,3,3,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/jetty/servlet/FilterHolder;","stop",new String[]{ },"V"));
                code.visitLabel(L4);
                code.visitStmt2R(MOVE,2,1);
                code.visitLabel(L19);
                code.visitJumpStmt(GOTO,-1,-1,L17);
                code.visitLabel(L5);
                code.visitStmt1R(MOVE_EXCEPTION,3);
                code.visitStmt2R(MOVE_OBJECT,0,3);
                code.visitLabel(L6);
                code.visitConstStmt(CONST_STRING,3,"EXCEPTION ");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3,0},new Method("Lorg/mortbay/log/Log;","warn",new String[]{ "Ljava/lang/String;","Ljava/lang/Throwable;"},"V"));
                code.visitStmt2R(MOVE,2,1);
                code.visitLabel(L20);
                code.visitJumpStmt(GOTO,-1,-1,L17);
                code.visitLabel(L21);
                code.visitFieldStmt(IGET_OBJECT,3,5,new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_servlets","[Lorg/mortbay/jetty/servlet/ServletHolder;"));
                code.visitJumpStmt(IF_EQZ,3,-1,L27);
                code.visitLabel(L22);
                code.visitFieldStmt(IGET_OBJECT,3,5,new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_servlets","[Lorg/mortbay/jetty/servlet/ServletHolder;"));
                code.visitStmt2R(ARRAY_LENGTH,1,3);
                code.visitLabel(L7);
                code.visitStmt2R(MOVE,2,1);
                code.visitLabel(L23);
                code.visitStmt3R(SUB_INT,1,2,4);
                code.visitLabel(L24);
                code.visitJumpStmt(IF_LEZ,2,-1,L27);
                code.visitLabel(L8);
                code.visitFieldStmt(IGET_OBJECT,3,5,new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_servlets","[Lorg/mortbay/jetty/servlet/ServletHolder;"));
                code.visitStmt3R(AGET_OBJECT,3,3,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/jetty/servlet/ServletHolder;","stop",new String[]{ },"V"));
                code.visitLabel(L9);
                code.visitStmt2R(MOVE,2,1);
                code.visitLabel(L25);
                code.visitJumpStmt(GOTO,-1,-1,L23);
                code.visitLabel(L10);
                code.visitStmt1R(MOVE_EXCEPTION,3);
                code.visitStmt2R(MOVE_OBJECT,0,3);
                code.visitLabel(L11);
                code.visitConstStmt(CONST_STRING,3,"EXCEPTION ");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3,0},new Method("Lorg/mortbay/log/Log;","warn",new String[]{ "Ljava/lang/String;","Ljava/lang/Throwable;"},"V"));
                code.visitStmt2R(MOVE,2,1);
                code.visitLabel(L26);
                code.visitJumpStmt(GOTO,-1,-1,L23);
                code.visitLabel(L27);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_OBJECT,3,5,new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_filterPathMappings","Ljava/util/List;"));
                code.visitLabel(L28);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_OBJECT,3,5,new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_filterNameMappings","Lorg/mortbay/util/MultiMap;"));
                code.visitLabel(L29);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_OBJECT,3,5,new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_servletPathMap","Lorg/mortbay/jetty/servlet/PathMap;"));
                code.visitLabel(L30);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_OBJECT,3,5,new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_chainCache","[Ljava/util/HashMap;"));
                code.visitLabel(L12);
                code.visitStmt1R(MONITOR_EXIT,5);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,3);
                code.visitStmt1R(MONITOR_EXIT,5);
                code.visitStmt1R(THROW,3);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m021_getContextLog(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","getContextLog",new String[]{ },"Ljava/lang/Object;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(191,L0);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m022_getFilter(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","getFilter",new String[]{ "Ljava/lang/String;"},"Lorg/mortbay/jetty/servlet/FilterHolder;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(821,L0);
                DexLabel L1=new DexLabel();
                ddv.visitEndLocal(1,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_filterNameMap","Ljava/util/Map;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,2},new Method("Ljava/util/Map;","get",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L1);
                code.visitTypeStmt(CHECK_CAST,1,-1,"Lorg/mortbay/jetty/servlet/FilterHolder;");
                code.visitStmt1R(RETURN_OBJECT,1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m023_getFilterMappings(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","getFilterMappings",new String[]{ },"[Lorg/mortbay/jetty/servlet/FilterMapping;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(199,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_filterMappings","[Lorg/mortbay/jetty/servlet/FilterMapping;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m024_getFilters(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","getFilters",new String[]{ },"[Lorg/mortbay/jetty/servlet/FilterHolder;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(208,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_filters","[Lorg/mortbay/jetty/servlet/FilterHolder;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m025_getHolderEntry(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","getHolderEntry",new String[]{ "Ljava/lang/String;"},"Lorg/mortbay/jetty/servlet/PathMap$Entry;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"pathInContext");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(218,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(219,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(220,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_servletPathMap","Lorg/mortbay/jetty/servlet/PathMap;"));
                DexLabel L3=new DexLabel();
                code.visitJumpStmt(IF_NEZ,0,-1,L3);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L2);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_servletPathMap","Lorg/mortbay/jetty/servlet/PathMap;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,2},new Method("Lorg/mortbay/jetty/servlet/PathMap;","getMatch",new String[]{ "Ljava/lang/String;"},"Lorg/mortbay/jetty/servlet/PathMap$Entry;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m026_getMaxFilterChainsCacheSize(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","getMaxFilterChainsCacheSize",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1234,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,1,new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_maxFilterChainsCacheSize","I"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m027_getRequestDispatcher(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","getRequestDispatcher",new String[]{ "Ljava/lang/String;"},"Ljavax/servlet/RequestDispatcher;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(10);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/lang/Exception;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"uriInContext");
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(239,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(265,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(242,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(243,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(247,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(248,L9);
                ddv.visitStartLocal(3,L9,"query","Ljava/lang/String;",null);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(249,L10);
                ddv.visitStartLocal(2,L10,"q","I",null);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(251,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(252,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(254,L13);
                DexLabel L14=new DexLabel();
                ddv.visitRestartLocal(2,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(255,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(257,L16);
                ddv.visitRestartLocal(9,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(258,L17);
                ddv.visitStartLocal(1,L17,"pathInContext","Ljava/lang/String;",null);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(259,L18);
                ddv.visitStartLocal(4,L18,"uri","Ljava/lang/String;",null);
                ddv.visitLineNumber(261,L2);
                ddv.visitEndLocal(1,L2);
                ddv.visitEndLocal(4,L2);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(263,L19);
                ddv.visitStartLocal(0,L19,"e","Ljava/lang/Exception;",null);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(265,L20);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,7, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L4);
                code.visitJumpStmt(IF_NEZ,9,-1,L6);
                code.visitStmt2R(MOVE_OBJECT,5,7);
                code.visitLabel(L5);
                code.visitStmt1R(RETURN_OBJECT,5);
                code.visitLabel(L6);
                code.visitConstStmt(CONST_STRING,5,"/");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9,5},new Method("Ljava/lang/String;","startsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitJumpStmt(IF_NEZ,5,-1,L8);
                code.visitStmt2R(MOVE_OBJECT,5,7);
                code.visitLabel(L7);
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitLabel(L8);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L9);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L10);
                code.visitConstStmt(CONST_16,5, Integer.valueOf(63)); // int: 0x0000003f  float:0.000000
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9,5},new Method("Ljava/lang/String;","indexOf",new String[]{ "I"},"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_LEZ,2,-1,L13);
                code.visitLabel(L11);
                code.visitStmt2R1N(ADD_INT_LIT8,5,2,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9,5},new Method("Ljava/lang/String;","substring",new String[]{ "I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitLabel(L12);
                code.visitConstStmt(CONST_4,5, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9,5,2},new Method("Ljava/lang/String;","substring",new String[]{ "I","I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitLabel(L13);
                code.visitConstStmt(CONST_16,5, Integer.valueOf(59)); // int: 0x0000003b  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9,5},new Method("Ljava/lang/String;","indexOf",new String[]{ "I"},"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitLabel(L14);
                code.visitJumpStmt(IF_LEZ,2,-1,L16);
                code.visitLabel(L15);
                code.visitConstStmt(CONST_4,5, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9,5,2},new Method("Ljava/lang/String;","substring",new String[]{ "I","I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitLabel(L16);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 9},new Method("Lorg/mortbay/util/URIUtil;","decodePath",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 5},new Method("Lorg/mortbay/util/URIUtil;","canonicalPath",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L17);
                code.visitFieldStmt(IGET_OBJECT,5,8,new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_contextHandler","Lorg/mortbay/jetty/handler/ContextHandler;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/jetty/handler/ContextHandler;","getContextPath",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 5,9},new Method("Lorg/mortbay/util/URIUtil;","addPaths",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitLabel(L18);
                code.visitTypeStmt(NEW_INSTANCE,5,-1,"Lorg/mortbay/jetty/servlet/Dispatcher;");
                code.visitFieldStmt(IGET_OBJECT,6,8,new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_contextHandler","Lorg/mortbay/jetty/handler/ContextHandler;"));
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 5,6,4,1,3},new Method("Lorg/mortbay/jetty/servlet/Dispatcher;","<init>",new String[]{ "Lorg/mortbay/jetty/handler/ContextHandler;","Ljava/lang/String;","Ljava/lang/String;","Ljava/lang/String;"},"V"));
                code.visitLabel(L1);
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,5);
                code.visitStmt2R(MOVE_OBJECT,0,5);
                code.visitLabel(L19);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/log/Log;","ignore",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitStmt2R(MOVE_OBJECT,5,7);
                code.visitLabel(L20);
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m028_getServlet(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","getServlet",new String[]{ "Ljava/lang/String;"},"Lorg/mortbay/jetty/servlet/ServletHolder;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(294,L0);
                DexLabel L1=new DexLabel();
                ddv.visitEndLocal(1,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_servletNameMap","Ljava/util/Map;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,2},new Method("Ljava/util/Map;","get",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L1);
                code.visitTypeStmt(CHECK_CAST,1,-1,"Lorg/mortbay/jetty/servlet/ServletHolder;");
                code.visitStmt1R(RETURN_OBJECT,1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m029_getServletContext(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","getServletContext",new String[]{ },"Ljavax/servlet/ServletContext;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(271,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_servletContext","Lorg/mortbay/jetty/handler/ContextHandler$SContext;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m030_getServletMappings(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","getServletMappings",new String[]{ },"[Lorg/mortbay/jetty/servlet/ServletMapping;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(279,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_servletMappings","[Lorg/mortbay/jetty/servlet/ServletMapping;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m031_getServlets(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","getServlets",new String[]{ },"[Lorg/mortbay/jetty/servlet/ServletHolder;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(288,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_servlets","[Lorg/mortbay/jetty/servlet/ServletHolder;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m032_handle(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","handle",new String[]{ "Ljava/lang/String;","Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;","I"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visit(null, new DexType("Ljavax/servlet/ServletException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(34);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                DexLabel L5=new DexLabel();
                DexLabel L6=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2,L3,L4,L5,L6},new String[]{ "Lorg/mortbay/jetty/RetryRequest;","Lorg/mortbay/jetty/EofException;","Ljava/lang/Exception;","Ljava/lang/Error;",null});
                DexLabel L7=new DexLabel();
                DexLabel L8=new DexLabel();
                DexLabel L9=new DexLabel();
                code.visitTryCatch(L7,L8,new DexLabel[]{L2,L3,L4,L5,L9},new String[]{ "Lorg/mortbay/jetty/RetryRequest;","Lorg/mortbay/jetty/EofException;","Ljava/lang/Exception;","Ljava/lang/Error;",null});
                DexLabel L10=new DexLabel();
                DexLabel L11=new DexLabel();
                DexLabel L12=new DexLabel();
                DexLabel L13=new DexLabel();
                DexLabel L14=new DexLabel();
                DexLabel L15=new DexLabel();
                code.visitTryCatch(L8,L10,new DexLabel[]{L11,L12,L13,L14,L15},new String[]{ "Lorg/mortbay/jetty/RetryRequest;","Lorg/mortbay/jetty/EofException;","Ljava/lang/Exception;","Ljava/lang/Error;",null});
                DexLabel L16=new DexLabel();
                DexLabel L17=new DexLabel();
                code.visitTryCatch(L16,L17,new DexLabel[]{L2,L3,L4,L5,L6},new String[]{ "Lorg/mortbay/jetty/RetryRequest;","Lorg/mortbay/jetty/EofException;","Ljava/lang/Exception;","Ljava/lang/Error;",null});
                DexLabel L18=new DexLabel();
                DexLabel L19=new DexLabel();
                code.visitTryCatch(L18,L19,new DexLabel[]{L19},new String[]{ null});
                DexLabel L20=new DexLabel();
                DexLabel L21=new DexLabel();
                code.visitTryCatch(L20,L21,new DexLabel[]{L2,L3,L4,L5,L6},new String[]{ "Lorg/mortbay/jetty/RetryRequest;","Lorg/mortbay/jetty/EofException;","Ljava/lang/Exception;","Ljava/lang/Error;",null});
                DexLabel L22=new DexLabel();
                DexLabel L23=new DexLabel();
                code.visitTryCatch(L22,L23,new DexLabel[]{L2,L3,L4,L5,L9},new String[]{ "Lorg/mortbay/jetty/RetryRequest;","Lorg/mortbay/jetty/EofException;","Ljava/lang/Exception;","Ljava/lang/Error;",null});
                DexLabel L24=new DexLabel();
                DexLabel L25=new DexLabel();
                code.visitTryCatch(L24,L25,new DexLabel[]{L2,L3,L4,L5,L9},new String[]{ "Lorg/mortbay/jetty/RetryRequest;","Lorg/mortbay/jetty/EofException;","Ljava/lang/Exception;","Ljava/lang/Error;",null});
                DexLabel L26=new DexLabel();
                DexLabel L27=new DexLabel();
                code.visitTryCatch(L26,L27,new DexLabel[]{L19},new String[]{ null});
                DexLabel L28=new DexLabel();
                code.visitTryCatch(L27,L28,new DexLabel[]{L2,L3,L4,L5,L9},new String[]{ "Lorg/mortbay/jetty/RetryRequest;","Lorg/mortbay/jetty/EofException;","Ljava/lang/Exception;","Ljava/lang/Error;",null});
                DexLabel L29=new DexLabel();
                DexLabel L30=new DexLabel();
                code.visitTryCatch(L29,L30,new DexLabel[]{L19},new String[]{ null});
                DexLabel L31=new DexLabel();
                DexLabel L32=new DexLabel();
                code.visitTryCatch(L31,L32,new DexLabel[]{L19},new String[]{ null});
                DexLabel L33=new DexLabel();
                DexLabel L34=new DexLabel();
                code.visitTryCatch(L33,L34,new DexLabel[]{L19},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"target");
                ddv.visitParameterName(1,"request");
                ddv.visitParameterName(2,"response");
                ddv.visitParameterName(3,"type");
                DexLabel L35=new DexLabel();
                ddv.visitPrologue(L35);
                ddv.visitLineNumber(304,L35);
                DexLabel L36=new DexLabel();
                ddv.visitLineNumber(507,L36);
                DexLabel L37=new DexLabel();
                ddv.visitLineNumber(308,L37);
                DexLabel L38=new DexLabel();
                ddv.visitLineNumber(309,L38);
                ddv.visitStartLocal(4,L38,"base_request","Lorg/mortbay/jetty/Request;",null);
                DexLabel L39=new DexLabel();
                ddv.visitLineNumber(310,L39);
                ddv.visitStartLocal(14,L39,"old_servlet_name","Ljava/lang/String;",null);
                DexLabel L40=new DexLabel();
                ddv.visitLineNumber(311,L40);
                ddv.visitStartLocal(15,L40,"old_servlet_path","Ljava/lang/String;",null);
                DexLabel L41=new DexLabel();
                ddv.visitLineNumber(312,L41);
                ddv.visitStartLocal(12,L41,"old_path_info","Ljava/lang/String;",null);
                DexLabel L42=new DexLabel();
                ddv.visitLineNumber(313,L42);
                ddv.visitStartLocal(13,L42,"old_role_map","Ljava/util/Map;",null);
                DexLabel L43=new DexLabel();
                ddv.visitLineNumber(314,L43);
                ddv.visitStartLocal(19,L43,"request_listeners","Ljava/lang/Object;",null);
                DexLabel L44=new DexLabel();
                ddv.visitLineNumber(318,L44);
                ddv.visitStartLocal(17,L44,"request_event","Ljavax/servlet/ServletRequestEvent;",null);
                DexLabel L45=new DexLabel();
                ddv.visitLineNumber(319,L45);
                ddv.visitStartLocal(21,L45,"servlet_holder","Lorg/mortbay/jetty/servlet/ServletHolder;",null);
                ddv.visitLineNumber(322,L0);
                ddv.visitStartLocal(6,L0,"chain","Ljavax/servlet/FilterChain;",null);
                DexLabel L46=new DexLabel();
                ddv.visitLineNumber(325,L46);
                DexLabel L47=new DexLabel();
                ddv.visitLineNumber(326,L47);
                ddv.visitStartLocal(8,L47,"entry","Lorg/mortbay/jetty/servlet/PathMap$Entry;",null);
                DexLabel L48=new DexLabel();
                ddv.visitLineNumber(328,L48);
                DexLabel L49=new DexLabel();
                ddv.visitLineNumber(329,L49);
                DexLabel L50=new DexLabel();
                ddv.visitLineNumber(330,L50);
                DexLabel L51=new DexLabel();
                ddv.visitLineNumber(331,L51);
                DexLabel L52=new DexLabel();
                ddv.visitLineNumber(333,L52);
                DexLabel L53=new DexLabel();
                ddv.visitLineNumber(334,L53);
                ddv.visitStartLocal(23,L53,"servlet_path_spec","Ljava/lang/String;",null);
                DexLabel L54=new DexLabel();
                ddv.visitLineNumber(335,L54);
                ddv.visitStartLocal(22,L54,"servlet_path","Ljava/lang/String;",null);
                DexLabel L55=new DexLabel();
                ddv.visitLineNumber(337,L55);
                ddv.visitStartLocal(16,L55,"path_info","Ljava/lang/String;",null);
                DexLabel L56=new DexLabel();
                ddv.visitLineNumber(339,L56);
                DexLabel L57=new DexLabel();
                ddv.visitLineNumber(340,L57);
                DexLabel L58=new DexLabel();
                ddv.visitLineNumber(348,L58);
                DexLabel L59=new DexLabel();
                ddv.visitLineNumber(349,L59);
                DexLabel L60=new DexLabel();
                ddv.visitLineNumber(363,L60);
                ddv.visitEndLocal(8,L60);
                ddv.visitEndLocal(23,L60);
                ddv.visitEndLocal(22,L60);
                ddv.visitEndLocal(16,L60);
                DexLabel L61=new DexLabel();
                ddv.visitLineNumber(365,L61);
                DexLabel L62=new DexLabel();
                ddv.visitLineNumber(366,L62);
                DexLabel L63=new DexLabel();
                ddv.visitLineNumber(370,L63);
                DexLabel L64=new DexLabel();
                ddv.visitLineNumber(371,L64);
                ddv.visitStartLocal(19,L64,"request_listeners","Ljava/lang/Object;",null);
                ddv.visitLineNumber(373,L7);
                ddv.visitLineNumber(374,L8);
                ddv.visitStartLocal(18,L8,"request_event","Ljavax/servlet/ServletRequestEvent;",null);
                DexLabel L65=new DexLabel();
                ddv.visitEndLocal(17,L65);
                DexLabel L66=new DexLabel();
                ddv.visitLineNumber(375,L66);
                ddv.visitStartLocal(20,L66,"s","I",null);
                DexLabel L67=new DexLabel();
                ddv.visitStartLocal(9,L67,"i","I",null);
                DexLabel L68=new DexLabel();
                ddv.visitLineNumber(377,L68);
                DexLabel L69=new DexLabel();
                ddv.visitLineNumber(378,L69);
                ddv.visitStartLocal(11,L69,"listener","Ljavax/servlet/ServletRequestListener;",null);
                ddv.visitLineNumber(375,L10);
                DexLabel L70=new DexLabel();
                ddv.visitLineNumber(308,L70);
                ddv.visitEndLocal(4,L70);
                ddv.visitEndLocal(14,L70);
                ddv.visitEndLocal(15,L70);
                ddv.visitEndLocal(12,L70);
                ddv.visitEndLocal(13,L70);
                ddv.visitEndLocal(21,L70);
                ddv.visitEndLocal(6,L70);
                ddv.visitEndLocal(19,L70);
                ddv.visitEndLocal(18,L70);
                ddv.visitEndLocal(20,L70);
                ddv.visitEndLocal(9,L70);
                ddv.visitEndLocal(11,L70);
                ddv.visitLineNumber(334,L16);
                ddv.visitRestartLocal(4,L16);
                ddv.visitRestartLocal(6,L16);
                ddv.visitRestartLocal(8,L16);
                ddv.visitRestartLocal(12,L16);
                ddv.visitRestartLocal(13,L16);
                ddv.visitRestartLocal(14,L16);
                ddv.visitRestartLocal(15,L16);
                ddv.visitRestartLocal(17,L16);
                ddv.visitStartLocal(19,L16,"request_listeners","Ljava/lang/Object;",null);
                ddv.visitRestartLocal(21,L16);
                ddv.visitRestartLocal(23,L16);
                DexLabel L71=new DexLabel();
                ddv.visitLineNumber(344,L71);
                ddv.visitRestartLocal(16,L71);
                ddv.visitRestartLocal(22,L71);
                DexLabel L72=new DexLabel();
                ddv.visitLineNumber(345,L72);
                ddv.visitLineNumber(394,L2);
                ddv.visitEndLocal(8,L2);
                ddv.visitEndLocal(19,L2);
                ddv.visitEndLocal(23,L2);
                ddv.visitEndLocal(16,L2);
                ddv.visitEndLocal(22,L2);
                DexLabel L73=new DexLabel();
                ddv.visitLineNumber(396,L73);
                ddv.visitStartLocal(7,L73,"e","Lorg/mortbay/jetty/RetryRequest;",null);
                DexLabel L74=new DexLabel();
                ddv.visitLineNumber(397,L74);
                ddv.visitLineNumber(490,L19);
                ddv.visitEndLocal(7,L19);
                DexLabel L75=new DexLabel();
                ddv.visitLineNumber(492,L75);
                DexLabel L76=new DexLabel();
                ddv.visitRestartLocal(9,L76);
                DexLabel L77=new DexLabel();
                ddv.visitEndLocal(9,L77);
                ddv.visitStartLocal(10,L77,"i","I",null);
                DexLabel L78=new DexLabel();
                ddv.visitRestartLocal(9,L78);
                DexLabel L79=new DexLabel();
                ddv.visitLineNumber(494,L79);
                ddv.visitEndLocal(10,L79);
                DexLabel L80=new DexLabel();
                ddv.visitLineNumber(495,L80);
                ddv.visitRestartLocal(11,L80);
                DexLabel L81=new DexLabel();
                ddv.visitLineNumber(496,L81);
                ddv.visitRestartLocal(10,L81);
                ddv.visitLineNumber(355,L20);
                ddv.visitEndLocal(9,L20);
                ddv.visitEndLocal(11,L20);
                ddv.visitEndLocal(10,L20);
                ddv.visitRestartLocal(19,L20);
                DexLabel L82=new DexLabel();
                ddv.visitLineNumber(356,L82);
                ddv.visitRestartLocal(21,L82);
                DexLabel L83=new DexLabel();
                ddv.visitLineNumber(358,L83);
                DexLabel L84=new DexLabel();
                ddv.visitLineNumber(359,L84);
                DexLabel L85=new DexLabel();
                ddv.visitRestartLocal(6,L85);
                DexLabel L86=new DexLabel();
                ddv.visitEndLocal(17,L86);
                ddv.visitRestartLocal(9,L86);
                ddv.visitRestartLocal(18,L86);
                ddv.visitStartLocal(19,L86,"request_listeners","Ljava/lang/Object;",null);
                ddv.visitRestartLocal(20,L86);
                DexLabel L87=new DexLabel();
                ddv.visitLineNumber(383,L87);
                ddv.visitEndLocal(9,L87);
                ddv.visitEndLocal(18,L87);
                ddv.visitEndLocal(20,L87);
                ddv.visitRestartLocal(17,L87);
                DexLabel L88=new DexLabel();
                ddv.visitLineNumber(385,L88);
                DexLabel L89=new DexLabel();
                ddv.visitLineNumber(386,L89);
                DexLabel L90=new DexLabel();
                ddv.visitLineNumber(387,L90);
                ddv.visitLineNumber(490,L23);
                DexLabel L91=new DexLabel();
                ddv.visitLineNumber(492,L91);
                DexLabel L92=new DexLabel();
                ddv.visitRestartLocal(9,L92);
                DexLabel L93=new DexLabel();
                ddv.visitEndLocal(9,L93);
                ddv.visitRestartLocal(10,L93);
                DexLabel L94=new DexLabel();
                ddv.visitRestartLocal(9,L94);
                DexLabel L95=new DexLabel();
                ddv.visitLineNumber(494,L95);
                ddv.visitEndLocal(10,L95);
                DexLabel L96=new DexLabel();
                ddv.visitLineNumber(495,L96);
                ddv.visitRestartLocal(11,L96);
                DexLabel L97=new DexLabel();
                ddv.visitLineNumber(496,L97);
                ddv.visitRestartLocal(10,L97);
                ddv.visitLineNumber(389,L24);
                ddv.visitEndLocal(9,L24);
                ddv.visitEndLocal(11,L24);
                ddv.visitEndLocal(10,L24);
                ddv.visitLineNumber(399,L3);
                ddv.visitEndLocal(19,L3);
                ddv.visitLineNumber(401,L26);
                ddv.visitStartLocal(7,L26,"e","Lorg/mortbay/jetty/EofException;",null);
                ddv.visitLineNumber(392,L27);
                ddv.visitEndLocal(7,L27);
                ddv.visitRestartLocal(19,L27);
                ddv.visitLineNumber(403,L4);
                ddv.visitEndLocal(19,L4);
                DexLabel L98=new DexLabel();
                ddv.visitLineNumber(405,L98);
                ddv.visitStartLocal(7,L98,"e","Ljava/lang/Exception;",null);
                ddv.visitLineNumber(407,L29);
                DexLabel L99=new DexLabel();
                ddv.visitLineNumber(408,L99);
                DexLabel L100=new DexLabel();
                ddv.visitEndLocal(7,L100);
                DexLabel L101=new DexLabel();
                ddv.visitLineNumber(409,L101);
                ddv.visitRestartLocal(7,L101);
                DexLabel L102=new DexLabel();
                ddv.visitLineNumber(410,L102);
                DexLabel L103=new DexLabel();
                ddv.visitEndLocal(7,L103);
                DexLabel L104=new DexLabel();
                ddv.visitLineNumber(411,L104);
                ddv.visitRestartLocal(7,L104);
                DexLabel L105=new DexLabel();
                ddv.visitLineNumber(412,L105);
                DexLabel L106=new DexLabel();
                ddv.visitEndLocal(7,L106);
                DexLabel L107=new DexLabel();
                ddv.visitLineNumber(417,L107);
                ddv.visitRestartLocal(7,L107);
                DexLabel L108=new DexLabel();
                ddv.visitLineNumber(418,L108);
                ddv.visitStartLocal(24,L108,"th","Ljava/lang/Throwable;",null);
                DexLabel L109=new DexLabel();
                ddv.visitLineNumber(420,L109);
                DexLabel L110=new DexLabel();
                ddv.visitLineNumber(431,L110);
                DexLabel L111=new DexLabel();
                ddv.visitLineNumber(433,L111);
                DexLabel L112=new DexLabel();
                ddv.visitLineNumber(434,L112);
                DexLabel L113=new DexLabel();
                ddv.visitEndLocal(24,L113);
                DexLabel L114=new DexLabel();
                ddv.visitLineNumber(422,L114);
                ddv.visitRestartLocal(24,L114);
                DexLabel L115=new DexLabel();
                ddv.visitLineNumber(424,L115);
                DexLabel L116=new DexLabel();
                ddv.visitLineNumber(425,L116);
                DexLabel L117=new DexLabel();
                ddv.visitLineNumber(426,L117);
                ddv.visitStartLocal(5,L117,"cause","Ljava/lang/Throwable;",null);
                DexLabel L118=new DexLabel();
                ddv.visitLineNumber(427,L118);
                DexLabel L119=new DexLabel();
                ddv.visitLineNumber(436,L119);
                ddv.visitEndLocal(5,L119);
                DexLabel L120=new DexLabel();
                ddv.visitLineNumber(437,L120);
                DexLabel L121=new DexLabel();
                ddv.visitEndLocal(24,L121);
                DexLabel L122=new DexLabel();
                ddv.visitLineNumber(438,L122);
                ddv.visitRestartLocal(24,L122);
                DexLabel L123=new DexLabel();
                ddv.visitLineNumber(440,L123);
                DexLabel L124=new DexLabel();
                ddv.visitLineNumber(441,L124);
                DexLabel L125=new DexLabel();
                ddv.visitLineNumber(453,L125);
                DexLabel L126=new DexLabel();
                ddv.visitLineNumber(455,L126);
                DexLabel L127=new DexLabel();
                ddv.visitLineNumber(456,L127);
                DexLabel L128=new DexLabel();
                ddv.visitLineNumber(457,L128);
                DexLabel L129=new DexLabel();
                ddv.visitLineNumber(459,L129);
                DexLabel L130=new DexLabel();
                ddv.visitLineNumber(460,L130);
                ddv.visitStartLocal(25,L130,"ue","Ljavax/servlet/UnavailableException;",null);
                DexLabel L131=new DexLabel();
                ddv.visitLineNumber(461,L131);
                ddv.visitLineNumber(490,L30);
                ddv.visitEndLocal(25,L30);
                DexLabel L132=new DexLabel();
                ddv.visitLineNumber(492,L132);
                DexLabel L133=new DexLabel();
                ddv.visitRestartLocal(9,L133);
                DexLabel L134=new DexLabel();
                ddv.visitEndLocal(9,L134);
                ddv.visitRestartLocal(10,L134);
                DexLabel L135=new DexLabel();
                ddv.visitRestartLocal(9,L135);
                DexLabel L136=new DexLabel();
                ddv.visitLineNumber(494,L136);
                ddv.visitEndLocal(10,L136);
                DexLabel L137=new DexLabel();
                ddv.visitLineNumber(495,L137);
                ddv.visitRestartLocal(11,L137);
                DexLabel L138=new DexLabel();
                ddv.visitLineNumber(496,L138);
                ddv.visitRestartLocal(10,L138);
                ddv.visitLineNumber(443,L31);
                ddv.visitEndLocal(9,L31);
                ddv.visitEndLocal(11,L31);
                ddv.visitEndLocal(10,L31);
                DexLabel L139=new DexLabel();
                ddv.visitLineNumber(445,L139);
                DexLabel L140=new DexLabel();
                ddv.visitLineNumber(449,L140);
                DexLabel L141=new DexLabel();
                ddv.visitLineNumber(463,L141);
                ddv.visitRestartLocal(25,L141);
                DexLabel L142=new DexLabel();
                ddv.visitLineNumber(466,L142);
                ddv.visitEndLocal(25,L142);
                DexLabel L143=new DexLabel();
                ddv.visitLineNumber(469,L143);
                ddv.visitLineNumber(471,L5);
                ddv.visitEndLocal(7,L5);
                ddv.visitEndLocal(24,L5);
                DexLabel L144=new DexLabel();
                ddv.visitLineNumber(473,L144);
                ddv.visitStartLocal(7,L144,"e","Ljava/lang/Error;",null);
                DexLabel L145=new DexLabel();
                ddv.visitLineNumber(474,L145);
                DexLabel L146=new DexLabel();
                ddv.visitLineNumber(475,L146);
                DexLabel L147=new DexLabel();
                ddv.visitLineNumber(476,L147);
                DexLabel L148=new DexLabel();
                ddv.visitLineNumber(479,L148);
                DexLabel L149=new DexLabel();
                ddv.visitLineNumber(481,L149);
                DexLabel L150=new DexLabel();
                ddv.visitLineNumber(482,L150);
                DexLabel L151=new DexLabel();
                ddv.visitLineNumber(483,L151);
                ddv.visitLineNumber(490,L32);
                DexLabel L152=new DexLabel();
                ddv.visitLineNumber(492,L152);
                DexLabel L153=new DexLabel();
                ddv.visitRestartLocal(9,L153);
                DexLabel L154=new DexLabel();
                ddv.visitEndLocal(9,L154);
                ddv.visitRestartLocal(10,L154);
                DexLabel L155=new DexLabel();
                ddv.visitRestartLocal(9,L155);
                DexLabel L156=new DexLabel();
                ddv.visitLineNumber(494,L156);
                ddv.visitEndLocal(10,L156);
                DexLabel L157=new DexLabel();
                ddv.visitLineNumber(495,L157);
                ddv.visitRestartLocal(11,L157);
                DexLabel L158=new DexLabel();
                ddv.visitLineNumber(496,L158);
                ddv.visitRestartLocal(10,L158);
                ddv.visitLineNumber(486,L33);
                ddv.visitEndLocal(9,L33);
                ddv.visitEndLocal(11,L33);
                ddv.visitEndLocal(10,L33);
                DexLabel L159=new DexLabel();
                ddv.visitLineNumber(499,L159);
                ddv.visitEndLocal(7,L159);
                DexLabel L160=new DexLabel();
                ddv.visitLineNumber(500,L160);
                DexLabel L161=new DexLabel();
                ddv.visitLineNumber(501,L161);
                DexLabel L162=new DexLabel();
                ddv.visitLineNumber(503,L162);
                DexLabel L163=new DexLabel();
                ddv.visitLineNumber(504,L163);
                DexLabel L164=new DexLabel();
                ddv.visitLineNumber(490,L164);
                DexLabel L165=new DexLabel();
                ddv.visitLineNumber(499,L165);
                ddv.visitStartLocal(7,L165,"e","Ljava/lang/Exception;",null);
                ddv.visitRestartLocal(24,L165);
                DexLabel L166=new DexLabel();
                ddv.visitLineNumber(500,L166);
                DexLabel L167=new DexLabel();
                ddv.visitLineNumber(501,L167);
                DexLabel L168=new DexLabel();
                ddv.visitLineNumber(503,L168);
                DexLabel L169=new DexLabel();
                ddv.visitLineNumber(504,L169);
                ddv.visitEndLocal(7,L169);
                ddv.visitEndLocal(24,L169);
                DexLabel L170=new DexLabel();
                ddv.visitLineNumber(499,L170);
                ddv.visitStartLocal(7,L170,"e","Ljava/lang/Error;",null);
                DexLabel L171=new DexLabel();
                ddv.visitLineNumber(500,L171);
                DexLabel L172=new DexLabel();
                ddv.visitLineNumber(501,L172);
                DexLabel L173=new DexLabel();
                ddv.visitLineNumber(503,L173);
                DexLabel L174=new DexLabel();
                ddv.visitLineNumber(499,L174);
                ddv.visitEndLocal(7,L174);
                ddv.visitRestartLocal(19,L174);
                DexLabel L175=new DexLabel();
                ddv.visitLineNumber(500,L175);
                DexLabel L176=new DexLabel();
                ddv.visitLineNumber(501,L176);
                DexLabel L177=new DexLabel();
                ddv.visitLineNumber(503,L177);
                ddv.visitLineNumber(490,L6);
                ddv.visitStartLocal(19,L6,"request_listeners","Ljava/lang/Object;",null);
                ddv.visitStartLocal(19,L9,"request_listeners","Ljava/lang/Object;",null);
                ddv.visitEndLocal(17,L15);
                ddv.visitRestartLocal(18,L15);
                DexLabel L178=new DexLabel();
                ddv.visitRestartLocal(17,L178);
                ddv.visitLineNumber(471,L14);
                ddv.visitEndLocal(17,L14);
                DexLabel L179=new DexLabel();
                ddv.visitRestartLocal(17,L179);
                ddv.visitLineNumber(403,L13);
                ddv.visitEndLocal(17,L13);
                DexLabel L180=new DexLabel();
                ddv.visitRestartLocal(17,L180);
                ddv.visitLineNumber(399,L12);
                ddv.visitEndLocal(17,L12);
                DexLabel L181=new DexLabel();
                ddv.visitRestartLocal(17,L181);
                ddv.visitLineNumber(394,L11);
                ddv.visitEndLocal(17,L11);
                DexLabel L182=new DexLabel();
                ddv.visitRestartLocal(17,L182);
                code.visitLabel(L35);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 29},new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","isStarted",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,26);
                code.visitJumpStmt(IF_NEZ,26,-1,L37);
                code.visitLabel(L36);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L37);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,31);
                code.visitTypeStmt(INSTANCE_OF,0,0,"Lorg/mortbay/jetty/Request;");
                code.visitStmt2R(MOVE_FROM16,26,0);
                code.visitJumpStmt(IF_EQZ,26,-1,L70);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,31);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Lorg/mortbay/jetty/Request;");
                code.visitStmt2R(MOVE_OBJECT,4,0);
                code.visitLabel(L38);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/jetty/Request;","getServletName",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,14);
                code.visitLabel(L39);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/jetty/Request;","getServletPath",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,15);
                code.visitLabel(L40);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/jetty/Request;","getPathInfo",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,12);
                code.visitLabel(L41);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/jetty/Request;","getRoleMap",new String[]{ },"Ljava/util/Map;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,13);
                code.visitLabel(L42);
                code.visitConstStmt(CONST_16,19, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L43);
                code.visitConstStmt(CONST_16,17, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L44);
                code.visitConstStmt(CONST_16,21, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L45);
                code.visitConstStmt(CONST_4,6, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L0);
                code.visitConstStmt(CONST_STRING,26,"/");
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,30);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,26);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/String;","startsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,26);
                code.visitJumpStmt(IF_EQZ,26,-1,L20);
                code.visitLabel(L46);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 29,30},new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","getHolderEntry",new String[]{ "Ljava/lang/String;"},"Lorg/mortbay/jetty/servlet/PathMap$Entry;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitLabel(L47);
                code.visitJumpStmt(IF_EQZ,8,-1,L60);
                code.visitLabel(L48);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Lorg/mortbay/jetty/servlet/PathMap$Entry;","getValue",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,22);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Lorg/mortbay/jetty/servlet/ServletHolder;");
                code.visitStmt2R(MOVE_OBJECT_FROM16,21,0);
                code.visitLabel(L49);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 21},new Method("Lorg/mortbay/jetty/servlet/ServletHolder;","getName",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,26);
                code.visitStmt2R(MOVE_OBJECT,0,4);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,26);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/Request;","setServletName",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L50);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 21},new Method("Lorg/mortbay/jetty/servlet/ServletHolder;","getRoleMap",new String[]{ },"Ljava/util/Map;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,26);
                code.visitStmt2R(MOVE_OBJECT,0,4);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,26);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/Request;","setRoleMap",new String[]{ "Ljava/util/Map;"},"V"));
                code.visitLabel(L51);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/log/Log;","isDebugEnabled",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,26);
                code.visitJumpStmt(IF_EQZ,26,-1,L52);
                code.visitTypeStmt(NEW_INSTANCE,26,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT_RANGE,new int[]{ 26},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,27,"servlet=");
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 26,27},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,26);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,26);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,21);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,26);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 26},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,26);
                code.visitMethodStmt(INVOKE_STATIC_RANGE,new int[]{ 26},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L52);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Lorg/mortbay/jetty/servlet/PathMap$Entry;","getKey",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,23);
                code.visitTypeStmt(CHECK_CAST,23,-1,"Ljava/lang/String;");
                code.visitLabel(L53);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Lorg/mortbay/jetty/servlet/PathMap$Entry;","getMapped",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,26);
                code.visitJumpStmt(IF_EQZ,26,-1,L16);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Lorg/mortbay/jetty/servlet/PathMap$Entry;","getMapped",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,26);
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,26);
                code.visitLabel(L54);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,23);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,30);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/servlet/PathMap;","pathInfo",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,16);
                code.visitLabel(L55);
                code.visitConstStmt(CONST_16,26, Integer.valueOf(4)); // int: 0x00000004  float:0.000000
                code.visitStmt2R(MOVE_FROM16,0,33);
                code.visitStmt2R(MOVE_FROM16,1,26);
                code.visitJumpStmt(IF_NE,0,1,L71);
                code.visitLabel(L56);
                code.visitConstStmt(CONST_STRING,26,"javax.servlet.include.servlet_path");
                code.visitStmt2R(MOVE_OBJECT,0,4);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,26);
                code.visitStmt2R(MOVE_OBJECT_FROM16,2,22);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Lorg/mortbay/jetty/Request;","setAttribute",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L57);
                code.visitConstStmt(CONST_STRING,26,"javax.servlet.include.path_info");
                code.visitStmt2R(MOVE_OBJECT,0,4);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,26);
                code.visitStmt2R(MOVE_OBJECT_FROM16,2,16);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Lorg/mortbay/jetty/Request;","setAttribute",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L58);
                code.visitJumpStmt(IF_EQZ,21,-1,L60);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,29);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_filterMappings","[Lorg/mortbay/jetty/servlet/FilterMapping;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,26,0);
                code.visitJumpStmt(IF_EQZ,26,-1,L60);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,29);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_filterMappings","[Lorg/mortbay/jetty/servlet/FilterMapping;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,26,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,26);
                code.visitStmt2R(ARRAY_LENGTH,0,0);
                code.visitStmt2R(MOVE_FROM16,26,0);
                code.visitJumpStmt(IF_LEZ,26,-1,L60);
                code.visitLabel(L59);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,29);
                code.visitStmt2R(MOVE_FROM16,1,33);
                code.visitStmt2R(MOVE_OBJECT_FROM16,2,30);
                code.visitStmt2R(MOVE_OBJECT_FROM16,3,21);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1,2,3},new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","getFilterChain",new String[]{ "I","Ljava/lang/String;","Lorg/mortbay/jetty/servlet/ServletHolder;"},"Ljavax/servlet/FilterChain;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitLabel(L60);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/log/Log;","isDebugEnabled",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,26);
                code.visitJumpStmt(IF_EQZ,26,-1,L63);
                code.visitLabel(L61);
                code.visitTypeStmt(NEW_INSTANCE,26,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT_RANGE,new int[]{ 26},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,27,"chain=");
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 26,27},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,26);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,26);
                code.visitStmt2R(MOVE_OBJECT,1,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,26);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 26},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,26);
                code.visitMethodStmt(INVOKE_STATIC_RANGE,new int[]{ 26},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L62);
                code.visitTypeStmt(NEW_INSTANCE,26,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT_RANGE,new int[]{ 26},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,27,"servlet holder=");
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 26,27},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,26);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,26);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,21);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,26);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 26},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,26);
                code.visitMethodStmt(INVOKE_STATIC_RANGE,new int[]{ 26},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L63);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/jetty/Request;","takeRequestListeners",new String[]{ },"Ljava/lang/Object;"));
                code.visitLabel(L1);
                code.visitStmt1R(MOVE_RESULT_OBJECT,19);
                code.visitLabel(L64);
                code.visitJumpStmt(IF_EQZ,19,-1,L87);
                code.visitLabel(L7);
                code.visitTypeStmt(NEW_INSTANCE,18,-1,"Ljavax/servlet/ServletRequestEvent;");
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 29},new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","getServletContext",new String[]{ },"Ljavax/servlet/ServletContext;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,26);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,18);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,26);
                code.visitStmt2R(MOVE_OBJECT_FROM16,2,31);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1,2},new Method("Ljavax/servlet/ServletRequestEvent;","<init>",new String[]{ "Ljavax/servlet/ServletContext;","Ljavax/servlet/ServletRequest;"},"V"));
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_STATIC_RANGE,new int[]{ 19},new Method("Lorg/mortbay/util/LazyList;","size",new String[]{ "Ljava/lang/Object;"},"I"));
                code.visitLabel(L65);
                code.visitStmt1R(MOVE_RESULT,20);
                code.visitLabel(L66);
                code.visitConstStmt(CONST_4,9, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L67);
                code.visitStmt2R(MOVE,0,9);
                code.visitStmt2R(MOVE_FROM16,1,20);
                code.visitJumpStmt(IF_GE,0,1,L86);
                code.visitLabel(L68);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,19);
                code.visitStmt2R(MOVE,1,9);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,1},new Method("Lorg/mortbay/util/LazyList;","get",new String[]{ "Ljava/lang/Object;","I"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,11);
                code.visitTypeStmt(CHECK_CAST,11,-1,"Ljavax/servlet/ServletRequestListener;");
                code.visitLabel(L69);
                code.visitStmt2R(MOVE_OBJECT,0,11);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,18);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1},new Method("Ljavax/servlet/ServletRequestListener;","requestInitialized",new String[]{ "Ljavax/servlet/ServletRequestEvent;"},"V"));
                code.visitLabel(L10);
                code.visitStmt2R1N(ADD_INT_LIT8,9,9,1);
                code.visitJumpStmt(GOTO,-1,-1,L67);
                code.visitLabel(L70);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/jetty/HttpConnection;","getCurrentConnection",new String[]{ },"Lorg/mortbay/jetty/HttpConnection;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,26);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 26},new Method("Lorg/mortbay/jetty/HttpConnection;","getRequest",new String[]{ },"Lorg/mortbay/jetty/Request;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,26);
                code.visitStmt2R(MOVE_OBJECT_FROM16,4,26);
                code.visitJumpStmt(GOTO_16,-1,-1,L38);
                code.visitLabel(L16);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,23);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,30);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/servlet/PathMap;","pathMatch",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,26);
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,26);
                code.visitJumpStmt(GOTO_16,-1,-1,L54);
                code.visitLabel(L71);
                code.visitStmt2R(MOVE_OBJECT,0,4);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,22);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/Request;","setServletPath",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L72);
                code.visitStmt2R(MOVE_OBJECT,0,4);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,16);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/Request;","setPathInfo",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L17);
                code.visitJumpStmt(GOTO_16,-1,-1,L58);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,26);
                code.visitStmt2R(MOVE_OBJECT_FROM16,7,26);
                code.visitLabel(L73);
                code.visitConstStmt(CONST_16,26, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L18);
                code.visitStmt2R(MOVE_OBJECT,0,4);
                code.visitStmt2R(MOVE_FROM16,1,26);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/Request;","setHandled",new String[]{ "Z"},"V"));
                code.visitLabel(L74);
                code.visitStmt1R(THROW,7);
                code.visitLabel(L19);
                code.visitStmt1R(MOVE_EXCEPTION,26);
                code.visitStmt2R(MOVE_OBJECT_FROM16,27,19);
                DexLabel L183=new DexLabel();
                code.visitLabel(L183);
                code.visitJumpStmt(IF_EQZ,27,-1,L159);
                code.visitLabel(L75);
                code.visitMethodStmt(INVOKE_STATIC_RANGE,new int[]{ 27},new Method("Lorg/mortbay/util/LazyList;","size",new String[]{ "Ljava/lang/Object;"},"I"));
                code.visitStmt1R(MOVE_RESULT,9);
                code.visitLabel(L76);
                code.visitStmt2R(MOVE,10,9);
                code.visitLabel(L77);
                code.visitConstStmt(CONST_16,28, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt3R(SUB_INT,9,10,28);
                code.visitLabel(L78);
                code.visitJumpStmt(IF_LEZ,10,-1,L159);
                code.visitLabel(L79);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitStmt2R(MOVE,1,9);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,1},new Method("Lorg/mortbay/util/LazyList;","get",new String[]{ "Ljava/lang/Object;","I"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,11);
                code.visitTypeStmt(CHECK_CAST,11,-1,"Ljavax/servlet/ServletRequestListener;");
                code.visitLabel(L80);
                code.visitStmt2R(MOVE_OBJECT,0,11);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,17);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1},new Method("Ljavax/servlet/ServletRequestListener;","requestDestroyed",new String[]{ "Ljavax/servlet/ServletRequestEvent;"},"V"));
                code.visitStmt2R(MOVE,10,9);
                code.visitLabel(L81);
                code.visitJumpStmt(GOTO,-1,-1,L77);
                code.visitLabel(L20);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,29);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_servletNameMap","Ljava/util/Map;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,26,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,26);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,30);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1},new Method("Ljava/util/Map;","get",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,22);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Lorg/mortbay/jetty/servlet/ServletHolder;");
                code.visitStmt2R(MOVE_OBJECT_FROM16,21,0);
                code.visitLabel(L82);
                code.visitJumpStmt(IF_EQZ,21,-1,L60);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,29);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_filterMappings","[Lorg/mortbay/jetty/servlet/FilterMapping;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,26,0);
                code.visitJumpStmt(IF_EQZ,26,-1,L60);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,29);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_filterMappings","[Lorg/mortbay/jetty/servlet/FilterMapping;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,26,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,26);
                code.visitStmt2R(ARRAY_LENGTH,0,0);
                code.visitStmt2R(MOVE_FROM16,26,0);
                code.visitJumpStmt(IF_LEZ,26,-1,L60);
                code.visitLabel(L83);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 21},new Method("Lorg/mortbay/jetty/servlet/ServletHolder;","getName",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,26);
                code.visitStmt2R(MOVE_OBJECT,0,4);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,26);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/Request;","setServletName",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L84);
                code.visitConstStmt(CONST_16,26, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,29);
                code.visitStmt2R(MOVE_FROM16,1,33);
                code.visitStmt2R(MOVE_OBJECT_FROM16,2,26);
                code.visitStmt2R(MOVE_OBJECT_FROM16,3,21);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1,2,3},new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","getFilterChain",new String[]{ "I","Ljava/lang/String;","Lorg/mortbay/jetty/servlet/ServletHolder;"},"Ljavax/servlet/FilterChain;"));
                code.visitLabel(L21);
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitLabel(L85);
                code.visitJumpStmt(GOTO_16,-1,-1,L60);
                code.visitLabel(L86);
                code.visitStmt2R(MOVE_OBJECT_FROM16,17,18);
                code.visitLabel(L87);
                code.visitJumpStmt(IF_EQZ,21,-1,L27);
                code.visitLabel(L88);
                code.visitConstStmt(CONST_16,26, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L22);
                code.visitStmt2R(MOVE_OBJECT,0,4);
                code.visitStmt2R(MOVE_FROM16,1,26);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/Request;","setHandled",new String[]{ "Z"},"V"));
                code.visitLabel(L89);
                code.visitJumpStmt(IF_EQZ,6,-1,L24);
                code.visitLabel(L90);
                code.visitStmt2R(MOVE_OBJECT,0,6);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,31);
                code.visitStmt2R(MOVE_OBJECT_FROM16,2,32);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1,2},new Method("Ljavax/servlet/FilterChain;","doFilter",new String[]{ "Ljavax/servlet/ServletRequest;","Ljavax/servlet/ServletResponse;"},"V"));
                code.visitLabel(L23);
                code.visitJumpStmt(IF_EQZ,19,-1,L174);
                code.visitLabel(L91);
                code.visitMethodStmt(INVOKE_STATIC_RANGE,new int[]{ 19},new Method("Lorg/mortbay/util/LazyList;","size",new String[]{ "Ljava/lang/Object;"},"I"));
                code.visitStmt1R(MOVE_RESULT,9);
                code.visitLabel(L92);
                code.visitStmt2R(MOVE,10,9);
                code.visitLabel(L93);
                code.visitConstStmt(CONST_16,26, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt3R(SUB_INT,9,10,26);
                code.visitLabel(L94);
                code.visitJumpStmt(IF_LEZ,10,-1,L174);
                code.visitLabel(L95);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,19);
                code.visitStmt2R(MOVE,1,9);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,1},new Method("Lorg/mortbay/util/LazyList;","get",new String[]{ "Ljava/lang/Object;","I"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,11);
                code.visitTypeStmt(CHECK_CAST,11,-1,"Ljavax/servlet/ServletRequestListener;");
                code.visitLabel(L96);
                code.visitStmt2R(MOVE_OBJECT,0,11);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,17);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1},new Method("Ljavax/servlet/ServletRequestListener;","requestDestroyed",new String[]{ "Ljavax/servlet/ServletRequestEvent;"},"V"));
                code.visitStmt2R(MOVE,10,9);
                code.visitLabel(L97);
                code.visitJumpStmt(GOTO,-1,-1,L93);
                code.visitLabel(L24);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,31);
                code.visitStmt2R(MOVE_OBJECT_FROM16,2,32);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Lorg/mortbay/jetty/servlet/ServletHolder;","handle",new String[]{ "Ljavax/servlet/ServletRequest;","Ljavax/servlet/ServletResponse;"},"V"));
                code.visitLabel(L25);
                code.visitJumpStmt(GOTO,-1,-1,L23);
                code.visitLabel(L3);
                code.visitStmt1R(MOVE_EXCEPTION,26);
                code.visitStmt2R(MOVE_OBJECT_FROM16,7,26);
                code.visitLabel(L26);
                code.visitStmt1R(THROW,7);
                code.visitLabel(L27);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,29);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,31);
                code.visitStmt2R(MOVE_OBJECT_FROM16,2,32);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","notFound",new String[]{ "Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;"},"V"));
                code.visitLabel(L28);
                code.visitJumpStmt(GOTO,-1,-1,L23);
                code.visitLabel(L4);
                code.visitStmt1R(MOVE_EXCEPTION,26);
                code.visitStmt2R(MOVE_OBJECT_FROM16,7,26);
                code.visitLabel(L98);
                code.visitConstStmt(CONST_16,26, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt2R(MOVE_FROM16,0,33);
                code.visitStmt2R(MOVE_FROM16,1,26);
                code.visitJumpStmt(IF_EQ,0,1,L107);
                code.visitLabel(L29);
                code.visitStmt2R(MOVE_OBJECT,0,7);
                code.visitTypeStmt(INSTANCE_OF,0,0,"Ljava/io/IOException;");
                code.visitStmt2R(MOVE_FROM16,26,0);
                code.visitJumpStmt(IF_EQZ,26,-1,L101);
                code.visitLabel(L99);
                code.visitTypeStmt(CHECK_CAST,7,-1,"Ljava/io/IOException;");
                code.visitLabel(L100);
                code.visitStmt1R(THROW,7);
                code.visitLabel(L101);
                code.visitStmt2R(MOVE_OBJECT,0,7);
                code.visitTypeStmt(INSTANCE_OF,0,0,"Ljava/lang/RuntimeException;");
                code.visitStmt2R(MOVE_FROM16,26,0);
                code.visitJumpStmt(IF_EQZ,26,-1,L104);
                code.visitLabel(L102);
                code.visitTypeStmt(CHECK_CAST,7,-1,"Ljava/lang/RuntimeException;");
                code.visitLabel(L103);
                code.visitStmt1R(THROW,7);
                code.visitLabel(L104);
                code.visitStmt2R(MOVE_OBJECT,0,7);
                code.visitTypeStmt(INSTANCE_OF,0,0,"Ljavax/servlet/ServletException;");
                code.visitStmt2R(MOVE_FROM16,26,0);
                code.visitJumpStmt(IF_EQZ,26,-1,L107);
                code.visitLabel(L105);
                code.visitTypeStmt(CHECK_CAST,7,-1,"Ljavax/servlet/ServletException;");
                code.visitLabel(L106);
                code.visitStmt1R(THROW,7);
                code.visitLabel(L107);
                code.visitStmt2R(MOVE_OBJECT_FROM16,24,7);
                code.visitLabel(L108);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,24);
                code.visitTypeStmt(INSTANCE_OF,0,0,"Ljavax/servlet/UnavailableException;");
                code.visitStmt2R(MOVE_FROM16,26,0);
                code.visitJumpStmt(IF_EQZ,26,-1,L114);
                code.visitLabel(L109);
                code.visitMethodStmt(INVOKE_STATIC_RANGE,new int[]{ 24},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitLabel(L110);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,24);
                code.visitTypeStmt(INSTANCE_OF,0,0,"Lorg/mortbay/jetty/RetryRequest;");
                code.visitStmt2R(MOVE_FROM16,26,0);
                code.visitJumpStmt(IF_EQZ,26,-1,L119);
                code.visitLabel(L111);
                code.visitConstStmt(CONST_16,26, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt2R(MOVE_OBJECT,0,4);
                code.visitStmt2R(MOVE_FROM16,1,26);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/Request;","setHandled",new String[]{ "Z"},"V"));
                code.visitLabel(L112);
                code.visitTypeStmt(CHECK_CAST,24,-1,"Lorg/mortbay/jetty/RetryRequest;");
                code.visitLabel(L113);
                code.visitStmt1R(THROW,24);
                code.visitLabel(L114);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,24);
                code.visitTypeStmt(INSTANCE_OF,0,0,"Ljavax/servlet/ServletException;");
                code.visitStmt2R(MOVE_FROM16,26,0);
                code.visitJumpStmt(IF_EQZ,26,-1,L110);
                code.visitLabel(L115);
                code.visitMethodStmt(INVOKE_STATIC_RANGE,new int[]{ 24},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitLabel(L116);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,24);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Ljavax/servlet/ServletException;");
                code.visitStmt2R(MOVE_OBJECT_FROM16,25,0);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 25},new Method("Ljavax/servlet/ServletException;","getRootCause",new String[]{ },"Ljava/lang/Throwable;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitLabel(L117);
                code.visitStmt2R(MOVE_OBJECT,0,5);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,24);
                code.visitJumpStmt(IF_EQ,0,1,L110);
                code.visitJumpStmt(IF_EQZ,5,-1,L110);
                code.visitLabel(L118);
                code.visitStmt2R(MOVE_OBJECT_FROM16,24,5);
                code.visitJumpStmt(GOTO,-1,-1,L110);
                code.visitLabel(L119);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,24);
                code.visitTypeStmt(INSTANCE_OF,0,0,"Lorg/mortbay/jetty/HttpException;");
                code.visitStmt2R(MOVE_FROM16,26,0);
                code.visitJumpStmt(IF_EQZ,26,-1,L122);
                code.visitLabel(L120);
                code.visitTypeStmt(CHECK_CAST,24,-1,"Lorg/mortbay/jetty/HttpException;");
                code.visitLabel(L121);
                code.visitStmt1R(THROW,24);
                code.visitLabel(L122);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/log/Log;","isDebugEnabled",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,26);
                code.visitJumpStmt(IF_EQZ,26,-1,L31);
                code.visitLabel(L123);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 31},new Method("Ljavax/servlet/http/HttpServletRequest;","getRequestURI",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,26);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,26);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,24);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,1},new Method("Lorg/mortbay/log/Log;","warn",new String[]{ "Ljava/lang/String;","Ljava/lang/Throwable;"},"V"));
                code.visitLabel(L124);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 31},new Method("Ljava/lang/Object;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,26);
                code.visitMethodStmt(INVOKE_STATIC_RANGE,new int[]{ 26},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L125);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 32},new Method("Ljavax/servlet/http/HttpServletResponse;","isCommitted",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,26);
                code.visitJumpStmt(IF_NEZ,26,-1,L143);
                code.visitLabel(L126);
                code.visitConstStmt(CONST_STRING,26,"javax.servlet.error.exception_type");
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 24},new Method("Ljava/lang/Object;","getClass",new String[]{ },"Ljava/lang/Class;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,27);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,31);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,26);
                code.visitStmt2R(MOVE_OBJECT_FROM16,2,27);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1,2},new Method("Ljavax/servlet/http/HttpServletRequest;","setAttribute",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L127);
                code.visitConstStmt(CONST_STRING,26,"javax.servlet.error.exception");
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,31);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,26);
                code.visitStmt2R(MOVE_OBJECT_FROM16,2,24);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1,2},new Method("Ljavax/servlet/http/HttpServletRequest;","setAttribute",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L128);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,24);
                code.visitTypeStmt(INSTANCE_OF,0,0,"Ljavax/servlet/UnavailableException;");
                code.visitStmt2R(MOVE_FROM16,26,0);
                code.visitJumpStmt(IF_EQZ,26,-1,L142);
                code.visitLabel(L129);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,24);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Ljavax/servlet/UnavailableException;");
                code.visitStmt2R(MOVE_OBJECT_FROM16,25,0);
                code.visitLabel(L130);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 25},new Method("Ljavax/servlet/UnavailableException;","isPermanent",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,26);
                code.visitJumpStmt(IF_EQZ,26,-1,L141);
                code.visitLabel(L131);
                code.visitConstStmt(CONST_16,26, Integer.valueOf(404)); // int: 0x00000194  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 24},new Method("Ljava/lang/Throwable;","getMessage",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,27);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,32);
                code.visitStmt2R(MOVE_FROM16,1,26);
                code.visitStmt2R(MOVE_OBJECT_FROM16,2,27);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1,2},new Method("Ljavax/servlet/http/HttpServletResponse;","sendError",new String[]{ "I","Ljava/lang/String;"},"V"));
                code.visitLabel(L30);
                code.visitJumpStmt(IF_EQZ,19,-1,L165);
                code.visitLabel(L132);
                code.visitMethodStmt(INVOKE_STATIC_RANGE,new int[]{ 19},new Method("Lorg/mortbay/util/LazyList;","size",new String[]{ "Ljava/lang/Object;"},"I"));
                code.visitStmt1R(MOVE_RESULT,9);
                code.visitLabel(L133);
                code.visitStmt2R(MOVE,10,9);
                code.visitLabel(L134);
                code.visitConstStmt(CONST_16,26, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt3R(SUB_INT,9,10,26);
                code.visitLabel(L135);
                code.visitJumpStmt(IF_LEZ,10,-1,L165);
                code.visitLabel(L136);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,19);
                code.visitStmt2R(MOVE,1,9);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,1},new Method("Lorg/mortbay/util/LazyList;","get",new String[]{ "Ljava/lang/Object;","I"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,11);
                code.visitTypeStmt(CHECK_CAST,11,-1,"Ljavax/servlet/ServletRequestListener;");
                code.visitLabel(L137);
                code.visitStmt2R(MOVE_OBJECT,0,11);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,17);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1},new Method("Ljavax/servlet/ServletRequestListener;","requestDestroyed",new String[]{ "Ljavax/servlet/ServletRequestEvent;"},"V"));
                code.visitStmt2R(MOVE,10,9);
                code.visitLabel(L138);
                code.visitJumpStmt(GOTO,-1,-1,L134);
                code.visitLabel(L31);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,24);
                code.visitTypeStmt(INSTANCE_OF,0,0,"Ljava/io/IOException;");
                code.visitStmt2R(MOVE_FROM16,26,0);
                code.visitJumpStmt(IF_NEZ,26,-1,L139);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,24);
                code.visitTypeStmt(INSTANCE_OF,0,0,"Ljavax/servlet/UnavailableException;");
                code.visitStmt2R(MOVE_FROM16,26,0);
                code.visitJumpStmt(IF_EQZ,26,-1,L140);
                code.visitLabel(L139);
                code.visitTypeStmt(NEW_INSTANCE,26,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT_RANGE,new int[]{ 26},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 31},new Method("Ljavax/servlet/http/HttpServletRequest;","getRequestURI",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,27);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 26,27},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,26);
                code.visitConstStmt(CONST_STRING,27,": ");
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 26,27},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,26);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,26);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,24);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,26);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 26},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,26);
                code.visitMethodStmt(INVOKE_STATIC_RANGE,new int[]{ 26},new Method("Lorg/mortbay/log/Log;","warn",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitJumpStmt(GOTO_16,-1,-1,L125);
                code.visitLabel(L140);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 31},new Method("Ljavax/servlet/http/HttpServletRequest;","getRequestURI",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,26);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,26);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,24);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,1},new Method("Lorg/mortbay/log/Log;","warn",new String[]{ "Ljava/lang/String;","Ljava/lang/Throwable;"},"V"));
                code.visitJumpStmt(GOTO_16,-1,-1,L125);
                code.visitLabel(L141);
                code.visitConstStmt(CONST_16,26, Integer.valueOf(503)); // int: 0x000001f7  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 24},new Method("Ljava/lang/Throwable;","getMessage",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,27);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,32);
                code.visitStmt2R(MOVE_FROM16,1,26);
                code.visitStmt2R(MOVE_OBJECT_FROM16,2,27);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1,2},new Method("Ljavax/servlet/http/HttpServletResponse;","sendError",new String[]{ "I","Ljava/lang/String;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L30);
                code.visitLabel(L142);
                code.visitConstStmt(CONST_16,26, Integer.valueOf(500)); // int: 0x000001f4  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 24},new Method("Ljava/lang/Throwable;","getMessage",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,27);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,32);
                code.visitStmt2R(MOVE_FROM16,1,26);
                code.visitStmt2R(MOVE_OBJECT_FROM16,2,27);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1,2},new Method("Ljavax/servlet/http/HttpServletResponse;","sendError",new String[]{ "I","Ljava/lang/String;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L30);
                code.visitLabel(L143);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/log/Log;","isDebugEnabled",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,26);
                code.visitJumpStmt(IF_EQZ,26,-1,L30);
                code.visitTypeStmt(NEW_INSTANCE,26,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT_RANGE,new int[]{ 26},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,27,"Response already committed for handling ");
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 26,27},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,26);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,26);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,24);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,26);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 26},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,26);
                code.visitMethodStmt(INVOKE_STATIC_RANGE,new int[]{ 26},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitJumpStmt(GOTO_16,-1,-1,L30);
                code.visitLabel(L5);
                code.visitStmt1R(MOVE_EXCEPTION,26);
                code.visitStmt2R(MOVE_OBJECT_FROM16,7,26);
                code.visitLabel(L144);
                code.visitConstStmt(CONST_16,26, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt2R(MOVE_FROM16,0,33);
                code.visitStmt2R(MOVE_FROM16,1,26);
                code.visitJumpStmt(IF_EQ,0,1,L146);
                code.visitLabel(L145);
                code.visitStmt1R(THROW,7);
                code.visitLabel(L146);
                code.visitTypeStmt(NEW_INSTANCE,26,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT_RANGE,new int[]{ 26},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,27,"Error for ");
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 26,27},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,26);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 31},new Method("Ljavax/servlet/http/HttpServletRequest;","getRequestURI",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,27);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 26,27},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,26);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 26},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,26);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,26);
                code.visitStmt2R(MOVE_OBJECT,1,7);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,1},new Method("Lorg/mortbay/log/Log;","warn",new String[]{ "Ljava/lang/String;","Ljava/lang/Throwable;"},"V"));
                code.visitLabel(L147);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/log/Log;","isDebugEnabled",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,26);
                code.visitJumpStmt(IF_EQZ,26,-1,L148);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 31},new Method("Ljava/lang/Object;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,26);
                code.visitMethodStmt(INVOKE_STATIC_RANGE,new int[]{ 26},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L148);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 32},new Method("Ljavax/servlet/http/HttpServletResponse;","isCommitted",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,26);
                code.visitJumpStmt(IF_NEZ,26,-1,L33);
                code.visitLabel(L149);
                code.visitConstStmt(CONST_STRING,26,"javax.servlet.error.exception_type");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Ljava/lang/Object;","getClass",new String[]{ },"Ljava/lang/Class;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,27);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,31);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,26);
                code.visitStmt2R(MOVE_OBJECT_FROM16,2,27);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1,2},new Method("Ljavax/servlet/http/HttpServletRequest;","setAttribute",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L150);
                code.visitConstStmt(CONST_STRING,26,"javax.servlet.error.exception");
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,31);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,26);
                code.visitStmt2R(MOVE_OBJECT,2,7);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1,2},new Method("Ljavax/servlet/http/HttpServletRequest;","setAttribute",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L151);
                code.visitConstStmt(CONST_16,26, Integer.valueOf(500)); // int: 0x000001f4  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Ljava/lang/Error;","getMessage",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,27);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,32);
                code.visitStmt2R(MOVE_FROM16,1,26);
                code.visitStmt2R(MOVE_OBJECT_FROM16,2,27);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1,2},new Method("Ljavax/servlet/http/HttpServletResponse;","sendError",new String[]{ "I","Ljava/lang/String;"},"V"));
                code.visitLabel(L32);
                code.visitJumpStmt(IF_EQZ,19,-1,L170);
                code.visitLabel(L152);
                code.visitMethodStmt(INVOKE_STATIC_RANGE,new int[]{ 19},new Method("Lorg/mortbay/util/LazyList;","size",new String[]{ "Ljava/lang/Object;"},"I"));
                code.visitStmt1R(MOVE_RESULT,9);
                code.visitLabel(L153);
                code.visitStmt2R(MOVE,10,9);
                code.visitLabel(L154);
                code.visitConstStmt(CONST_16,26, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt3R(SUB_INT,9,10,26);
                code.visitLabel(L155);
                code.visitJumpStmt(IF_LEZ,10,-1,L170);
                code.visitLabel(L156);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,19);
                code.visitStmt2R(MOVE,1,9);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,1},new Method("Lorg/mortbay/util/LazyList;","get",new String[]{ "Ljava/lang/Object;","I"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,11);
                code.visitTypeStmt(CHECK_CAST,11,-1,"Ljavax/servlet/ServletRequestListener;");
                code.visitLabel(L157);
                code.visitStmt2R(MOVE_OBJECT,0,11);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,17);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1},new Method("Ljavax/servlet/ServletRequestListener;","requestDestroyed",new String[]{ "Ljavax/servlet/ServletRequestEvent;"},"V"));
                code.visitStmt2R(MOVE,10,9);
                code.visitLabel(L158);
                code.visitJumpStmt(GOTO,-1,-1,L154);
                code.visitLabel(L33);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/log/Log;","isDebugEnabled",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,26);
                code.visitJumpStmt(IF_EQZ,26,-1,L32);
                code.visitConstStmt(CONST_STRING,26,"Response already committed for handling ");
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,26);
                code.visitStmt2R(MOVE_OBJECT,1,7);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,1},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L34);
                code.visitJumpStmt(GOTO,-1,-1,L32);
                code.visitLabel(L159);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,14},new Method("Lorg/mortbay/jetty/Request;","setServletName",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L160);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,13},new Method("Lorg/mortbay/jetty/Request;","setRoleMap",new String[]{ "Ljava/util/Map;"},"V"));
                code.visitLabel(L161);
                code.visitConstStmt(CONST_16,27, Integer.valueOf(4)); // int: 0x00000004  float:0.000000
                code.visitStmt2R(MOVE_FROM16,0,33);
                code.visitStmt2R(MOVE_FROM16,1,27);
                code.visitJumpStmt(IF_EQ,0,1,L164);
                code.visitLabel(L162);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,15},new Method("Lorg/mortbay/jetty/Request;","setServletPath",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L163);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,12},new Method("Lorg/mortbay/jetty/Request;","setPathInfo",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L164);
                code.visitStmt1R(THROW,26);
                code.visitLabel(L165);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,14},new Method("Lorg/mortbay/jetty/Request;","setServletName",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L166);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,13},new Method("Lorg/mortbay/jetty/Request;","setRoleMap",new String[]{ "Ljava/util/Map;"},"V"));
                code.visitLabel(L167);
                code.visitConstStmt(CONST_16,26, Integer.valueOf(4)); // int: 0x00000004  float:0.000000
                code.visitStmt2R(MOVE_FROM16,0,33);
                code.visitStmt2R(MOVE_FROM16,1,26);
                code.visitJumpStmt(IF_EQ,0,1,L36);
                code.visitLabel(L168);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,15},new Method("Lorg/mortbay/jetty/Request;","setServletPath",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L169);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,12},new Method("Lorg/mortbay/jetty/Request;","setPathInfo",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitJumpStmt(GOTO_16,-1,-1,L36);
                code.visitLabel(L170);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,14},new Method("Lorg/mortbay/jetty/Request;","setServletName",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L171);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,13},new Method("Lorg/mortbay/jetty/Request;","setRoleMap",new String[]{ "Ljava/util/Map;"},"V"));
                code.visitLabel(L172);
                code.visitConstStmt(CONST_16,26, Integer.valueOf(4)); // int: 0x00000004  float:0.000000
                code.visitStmt2R(MOVE_FROM16,0,33);
                code.visitStmt2R(MOVE_FROM16,1,26);
                code.visitJumpStmt(IF_EQ,0,1,L36);
                code.visitLabel(L173);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,15},new Method("Lorg/mortbay/jetty/Request;","setServletPath",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L169);
                code.visitLabel(L174);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,14},new Method("Lorg/mortbay/jetty/Request;","setServletName",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L175);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,13},new Method("Lorg/mortbay/jetty/Request;","setRoleMap",new String[]{ "Ljava/util/Map;"},"V"));
                code.visitLabel(L176);
                code.visitConstStmt(CONST_16,26, Integer.valueOf(4)); // int: 0x00000004  float:0.000000
                code.visitStmt2R(MOVE_FROM16,0,33);
                code.visitStmt2R(MOVE_FROM16,1,26);
                code.visitJumpStmt(IF_EQ,0,1,L36);
                code.visitLabel(L177);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,15},new Method("Lorg/mortbay/jetty/Request;","setServletPath",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L169);
                code.visitLabel(L6);
                code.visitStmt1R(MOVE_EXCEPTION,26);
                code.visitStmt2R(MOVE_OBJECT_FROM16,27,19);
                code.visitJumpStmt(GOTO_16,-1,-1,L183);
                code.visitLabel(L9);
                code.visitStmt1R(MOVE_EXCEPTION,26);
                code.visitStmt2R(MOVE_OBJECT_FROM16,27,19);
                code.visitJumpStmt(GOTO_16,-1,-1,L183);
                code.visitLabel(L15);
                code.visitStmt1R(MOVE_EXCEPTION,26);
                code.visitStmt2R(MOVE_OBJECT_FROM16,17,18);
                code.visitLabel(L178);
                code.visitStmt2R(MOVE_OBJECT_FROM16,27,19);
                code.visitJumpStmt(GOTO_16,-1,-1,L183);
                code.visitLabel(L14);
                code.visitStmt1R(MOVE_EXCEPTION,26);
                code.visitStmt2R(MOVE_OBJECT_FROM16,7,26);
                code.visitStmt2R(MOVE_OBJECT_FROM16,17,18);
                code.visitLabel(L179);
                code.visitJumpStmt(GOTO_16,-1,-1,L144);
                code.visitLabel(L13);
                code.visitStmt1R(MOVE_EXCEPTION,26);
                code.visitStmt2R(MOVE_OBJECT_FROM16,7,26);
                code.visitStmt2R(MOVE_OBJECT_FROM16,17,18);
                code.visitLabel(L180);
                code.visitJumpStmt(GOTO_16,-1,-1,L98);
                code.visitLabel(L12);
                code.visitStmt1R(MOVE_EXCEPTION,26);
                code.visitStmt2R(MOVE_OBJECT_FROM16,7,26);
                code.visitStmt2R(MOVE_OBJECT_FROM16,17,18);
                code.visitLabel(L181);
                code.visitJumpStmt(GOTO_16,-1,-1,L26);
                code.visitLabel(L11);
                code.visitStmt1R(MOVE_EXCEPTION,26);
                code.visitStmt2R(MOVE_OBJECT_FROM16,7,26);
                code.visitStmt2R(MOVE_OBJECT_FROM16,17,18);
                code.visitLabel(L182);
                code.visitJumpStmt(GOTO_16,-1,-1,L73);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m033_initialize(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","initialize",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/Exception;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(10);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/lang/Throwable;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(647,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(650,L4);
                ddv.visitStartLocal(4,L4,"mx","Lorg/mortbay/util/MultiException;",null);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(652,L5);
                DexLabel L6=new DexLabel();
                ddv.visitStartLocal(3,L6,"i","I",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(653,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(652,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(656,L9);
                ddv.visitEndLocal(3,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(659,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(660,L11);
                ddv.visitStartLocal(5,L11,"servlets","[Lorg/mortbay/jetty/servlet/ServletHolder;",null);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(661,L12);
                DexLabel L13=new DexLabel();
                ddv.visitRestartLocal(3,L13);
                ddv.visitLineNumber(665,L0);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(667,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(668,L15);
                ddv.visitStartLocal(2,L15,"forced_holder","Lorg/mortbay/jetty/servlet/ServletHolder;",null);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(670,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(661,L17);
                ddv.visitEndLocal(2,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(673,L18);
                ddv.visitRestartLocal(2,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(676,L19);
                ddv.visitEndLocal(2,L19);
                ddv.visitLineNumber(678,L2);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(680,L20);
                ddv.visitStartLocal(1,L20,"e","Ljava/lang/Throwable;",null);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(681,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(684,L22);
                ddv.visitEndLocal(1,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(686,L23);
                ddv.visitEndLocal(5,L23);
                ddv.visitEndLocal(3,L23);
                code.visitLabel(L3);
                code.visitTypeStmt(NEW_INSTANCE,4,-1,"Lorg/mortbay/util/MultiException;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4},new Method("Lorg/mortbay/util/MultiException;","<init>",new String[]{ },"V"));
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,6,9,new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_filters","[Lorg/mortbay/jetty/servlet/FilterHolder;"));
                code.visitJumpStmt(IF_EQZ,6,-1,L9);
                code.visitLabel(L5);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,6,9,new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_filters","[Lorg/mortbay/jetty/servlet/FilterHolder;"));
                code.visitStmt2R(ARRAY_LENGTH,6,6);
                code.visitJumpStmt(IF_GE,3,6,L9);
                code.visitLabel(L7);
                code.visitFieldStmt(IGET_OBJECT,6,9,new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_filters","[Lorg/mortbay/jetty/servlet/FilterHolder;"));
                code.visitStmt3R(AGET_OBJECT,6,6,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/servlet/FilterHolder;","start",new String[]{ },"V"));
                code.visitLabel(L8);
                code.visitStmt2R1N(ADD_INT_LIT8,3,3,1);
                code.visitJumpStmt(GOTO,-1,-1,L6);
                code.visitLabel(L9);
                code.visitFieldStmt(IGET_OBJECT,6,9,new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_servlets","[Lorg/mortbay/jetty/servlet/ServletHolder;"));
                code.visitJumpStmt(IF_EQZ,6,-1,L23);
                code.visitLabel(L10);
                code.visitFieldStmt(IGET_OBJECT,6,9,new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_servlets","[Lorg/mortbay/jetty/servlet/ServletHolder;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("[Lorg/mortbay/jetty/servlet/ServletHolder;","clone",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitTypeStmt(CHECK_CAST,6,-1,"[Lorg/mortbay/jetty/servlet/ServletHolder;");
                code.visitStmt2R(MOVE_OBJECT,0,6);
                code.visitTypeStmt(CHECK_CAST,0,-1,"[Lorg/mortbay/jetty/servlet/ServletHolder;");
                code.visitStmt2R(MOVE_OBJECT,5,0);
                code.visitLabel(L11);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 5},new Method("Ljava/util/Arrays;","sort",new String[]{ "[Ljava/lang/Object;"},"V"));
                code.visitLabel(L12);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L13);
                code.visitStmt2R(ARRAY_LENGTH,6,5);
                code.visitJumpStmt(IF_GE,3,6,L22);
                code.visitLabel(L0);
                code.visitStmt3R(AGET_OBJECT,6,5,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/servlet/ServletHolder;","getClassName",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitJumpStmt(IF_NEZ,6,-1,L19);
                code.visitStmt3R(AGET_OBJECT,6,5,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/servlet/ServletHolder;","getForcedPath",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitJumpStmt(IF_EQZ,6,-1,L19);
                code.visitLabel(L14);
                code.visitFieldStmt(IGET_OBJECT,6,9,new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_servletPathMap","Lorg/mortbay/jetty/servlet/PathMap;"));
                code.visitStmt3R(AGET_OBJECT,7,5,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Lorg/mortbay/jetty/servlet/ServletHolder;","getForcedPath",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,7},new Method("Lorg/mortbay/jetty/servlet/PathMap;","match",new String[]{ "Ljava/lang/String;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitTypeStmt(CHECK_CAST,2,-1,"Lorg/mortbay/jetty/servlet/ServletHolder;");
                code.visitLabel(L15);
                code.visitJumpStmt(IF_EQZ,2,-1,L16);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/servlet/ServletHolder;","getClassName",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitJumpStmt(IF_NEZ,6,-1,L18);
                code.visitLabel(L16);
                code.visitTypeStmt(NEW_INSTANCE,6,-1,"Ljava/lang/IllegalStateException;");
                code.visitTypeStmt(NEW_INSTANCE,7,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 7},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,8,"No forced path servlet for ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,8},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitStmt3R(AGET_OBJECT,8,5,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Lorg/mortbay/jetty/servlet/ServletHolder;","getForcedPath",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,8},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 6,7},new Method("Ljava/lang/IllegalStateException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,6},new Method("Lorg/mortbay/util/MultiException;","add",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitLabel(L17);
                code.visitStmt2R1N(ADD_INT_LIT8,3,3,1);
                code.visitJumpStmt(GOTO,-1,-1,L13);
                code.visitLabel(L18);
                code.visitStmt3R(AGET_OBJECT,6,5,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/servlet/ServletHolder;","getClassName",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,7},new Method("Lorg/mortbay/jetty/servlet/ServletHolder;","setClassName",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L19);
                code.visitStmt3R(AGET_OBJECT,6,5,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/servlet/ServletHolder;","start",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitJumpStmt(GOTO,-1,-1,L17);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,6);
                code.visitStmt2R(MOVE_OBJECT,1,6);
                code.visitLabel(L20);
                code.visitConstStmt(CONST_STRING,6,"EXCEPTION ");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 6,1},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L21);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,1},new Method("Lorg/mortbay/util/MultiException;","add",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L17);
                code.visitLabel(L22);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/util/MultiException;","ifExceptionThrow",new String[]{ },"V"));
                code.visitLabel(L23);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m034_isAvailable(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","isAvailable",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(608,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(617,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(610,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(611,L4);
                ddv.visitStartLocal(1,L4,"holders","[Lorg/mortbay/jetty/servlet/ServletHolder;",null);
                DexLabel L5=new DexLabel();
                ddv.visitStartLocal(2,L5,"i","I",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(613,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(614,L7);
                ddv.visitStartLocal(0,L7,"holder","Lorg/mortbay/jetty/servlet/ServletHolder;",null);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(615,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(611,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(617,L10);
                ddv.visitEndLocal(0,L10);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","isStarted",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_NEZ,3,-1,L3);
                code.visitStmt2R(MOVE,3,4);
                code.visitLabel(L2);
                code.visitStmt1R(RETURN,3);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","getServlets",new String[]{ },"[Lorg/mortbay/jetty/servlet/ServletHolder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L4);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L5);
                code.visitStmt2R(ARRAY_LENGTH,3,1);
                code.visitJumpStmt(IF_GE,2,3,L10);
                code.visitLabel(L6);
                code.visitStmt3R(AGET_OBJECT,0,1,2);
                code.visitLabel(L7);
                code.visitJumpStmt(IF_EQZ,0,-1,L9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/servlet/ServletHolder;","isAvailable",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_NEZ,3,-1,L9);
                code.visitStmt2R(MOVE,3,4);
                code.visitLabel(L8);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L9);
                code.visitStmt2R1N(ADD_INT_LIT8,2,2,1);
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitLabel(L10);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m035_isFilterChainsCached(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","isFilterChainsCached",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(694,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_BOOLEAN,0,1,new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_filterChainsCached","Z"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m036_isInitializeAtStart(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","isInitializeAtStart",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(590,L0);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m037_isStartWithUnavailable(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","isStartWithUnavailable",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(635,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_BOOLEAN,0,1,new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_startWithUnavailable","Z"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m038_matchesPath(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","matchesPath",new String[]{ "Ljava/lang/String;"},"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"pathInContext");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(230,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_servletPathMap","Lorg/mortbay/jetty/servlet/PathMap;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,2},new Method("Lorg/mortbay/jetty/servlet/PathMap;","containsMatch",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m039_newFilterHolder(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","newFilterHolder",new String[]{ },"Lorg/mortbay/jetty/servlet/FilterHolder;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(815,L0);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/jetty/servlet/FilterHolder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Lorg/mortbay/jetty/servlet/FilterHolder;","<init>",new String[]{ },"V"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m040_newFilterHolder(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","newFilterHolder",new String[]{ "Ljava/lang/Class;"},"Lorg/mortbay/jetty/servlet/FilterHolder;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"filter");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(806,L0);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/jetty/servlet/FilterHolder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,2},new Method("Lorg/mortbay/jetty/servlet/FilterHolder;","<init>",new String[]{ "Ljava/lang/Class;"},"V"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m041_newServletHolder(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","newServletHolder",new String[]{ },"Lorg/mortbay/jetty/servlet/ServletHolder;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(703,L0);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/jetty/servlet/ServletHolder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Lorg/mortbay/jetty/servlet/ServletHolder;","<init>",new String[]{ },"V"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m042_newServletHolder(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","newServletHolder",new String[]{ "Ljava/lang/Class;"},"Lorg/mortbay/jetty/servlet/ServletHolder;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"servlet");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(709,L0);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/jetty/servlet/ServletHolder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,2},new Method("Lorg/mortbay/jetty/servlet/ServletHolder;","<init>",new String[]{ "Ljava/lang/Class;"},"V"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m043_notFound(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","notFound",new String[]{ "Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"request");
                ddv.visitParameterName(1,"response");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1058,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(1059,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(1060,L2);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/log/Log;","isDebugEnabled",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L1);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,1,"Not Found ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3},new Method("Ljavax/servlet/http/HttpServletRequest;","getRequestURI",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L1);
                code.visitConstStmt(CONST_16,0, Integer.valueOf(404)); // int: 0x00000194  float:0.000000
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 4,0},new Method("Ljavax/servlet/http/HttpServletResponse;","sendError",new String[]{ "I"},"V"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m044_setFilterChainsCached(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","setFilterChainsCached",new String[]{ "Z"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"filterChainsCached");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1068,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(1069,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_BOOLEAN,1,0,new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_filterChainsCached","Z"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m045_setFilterMappings(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","setFilterMappings",new String[]{ "[Lorg/mortbay/jetty/servlet/FilterMapping;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(8);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"filterMappings");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1077,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(1078,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(1079,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(1080,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(1081,L4);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","getServer",new String[]{ },"Lorg/mortbay/jetty/Server;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L2);
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","getServer",new String[]{ },"Lorg/mortbay/jetty/Server;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/Server;","getContainer",new String[]{ },"Lorg/mortbay/component/Container;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IGET_OBJECT,2,6,new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_filterMappings","[Lorg/mortbay/jetty/servlet/FilterMapping;"));
                code.visitConstStmt(CONST_STRING,4,"filterMapping");
                code.visitConstStmt(CONST_4,5, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt2R(MOVE_OBJECT,1,6);
                code.visitStmt2R(MOVE_OBJECT,3,7);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 0,1,2,3,4,5},new Method("Lorg/mortbay/component/Container;","update",new String[]{ "Ljava/lang/Object;","[Ljava/lang/Object;","[Ljava/lang/Object;","Ljava/lang/String;","Z"},"V"));
                code.visitLabel(L2);
                code.visitFieldStmt(IPUT_OBJECT,7,6,new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_filterMappings","[Lorg/mortbay/jetty/servlet/FilterMapping;"));
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","updateMappings",new String[]{ },"V"));
                code.visitLabel(L4);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m046_setFilters(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","setFilters",new String[]{ "[Lorg/mortbay/jetty/servlet/FilterHolder;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(8);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"holders");
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(1086,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(1087,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(1088,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(1089,L6);
                ddv.visitLineNumber(1090,L1);
                ddv.visitLineNumber(1086,L2);
                code.visitLabel(L3);
                code.visitStmt1R(MONITOR_ENTER,6);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","getServer",new String[]{ },"Lorg/mortbay/jetty/Server;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L5);
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","getServer",new String[]{ },"Lorg/mortbay/jetty/Server;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/Server;","getContainer",new String[]{ },"Lorg/mortbay/component/Container;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IGET_OBJECT,2,6,new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_filters","[Lorg/mortbay/jetty/servlet/FilterHolder;"));
                code.visitConstStmt(CONST_STRING,4,"filter");
                code.visitConstStmt(CONST_4,5, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt2R(MOVE_OBJECT,1,6);
                code.visitStmt2R(MOVE_OBJECT,3,7);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 0,1,2,3,4,5},new Method("Lorg/mortbay/component/Container;","update",new String[]{ "Ljava/lang/Object;","[Ljava/lang/Object;","[Ljava/lang/Object;","Ljava/lang/String;","Z"},"V"));
                code.visitLabel(L5);
                code.visitFieldStmt(IPUT_OBJECT,7,6,new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_filters","[Lorg/mortbay/jetty/servlet/FilterHolder;"));
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","updateNameMappings",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitStmt1R(MONITOR_EXIT,6);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,0);
                code.visitStmt1R(MONITOR_EXIT,6);
                code.visitStmt1R(THROW,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m047_setInitializeAtStart(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","setInitializeAtStart",new String[]{ "Z"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"initializeAtStart");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(600,L0);
                code.visitLabel(L0);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m048_setMaxFilterChainsCacheSize(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","setMaxFilterChainsCacheSize",new String[]{ "I"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"maxFilterChainsCacheSize");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1246,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(1247,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT,1,0,new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_maxFilterChainsCacheSize","I"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m049_setServer(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","setServer",new String[]{ "Lorg/mortbay/jetty/Server;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(8);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"server");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(116,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(118,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(119,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(120,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(121,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(123,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(125,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(126,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(127,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(128,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(130,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(132,L11);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","getServer",new String[]{ },"Lorg/mortbay/jetty/Server;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","getServer",new String[]{ },"Lorg/mortbay/jetty/Server;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitJumpStmt(IF_EQ,0,7,L5);
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","getServer",new String[]{ },"Lorg/mortbay/jetty/Server;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/Server;","getContainer",new String[]{ },"Lorg/mortbay/component/Container;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IGET_OBJECT,2,6,new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_filters","[Lorg/mortbay/jetty/servlet/FilterHolder;"));
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitConstStmt(CONST_STRING,4,"filter");
                code.visitConstStmt(CONST_4,5, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt2R(MOVE_OBJECT,1,6);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 0,1,2,3,4,5},new Method("Lorg/mortbay/component/Container;","update",new String[]{ "Ljava/lang/Object;","[Ljava/lang/Object;","[Ljava/lang/Object;","Ljava/lang/String;","Z"},"V"));
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","getServer",new String[]{ },"Lorg/mortbay/jetty/Server;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/Server;","getContainer",new String[]{ },"Lorg/mortbay/component/Container;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IGET_OBJECT,2,6,new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_filterMappings","[Lorg/mortbay/jetty/servlet/FilterMapping;"));
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitConstStmt(CONST_STRING,4,"filterMapping");
                code.visitConstStmt(CONST_4,5, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt2R(MOVE_OBJECT,1,6);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 0,1,2,3,4,5},new Method("Lorg/mortbay/component/Container;","update",new String[]{ "Ljava/lang/Object;","[Ljava/lang/Object;","[Ljava/lang/Object;","Ljava/lang/String;","Z"},"V"));
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","getServer",new String[]{ },"Lorg/mortbay/jetty/Server;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/Server;","getContainer",new String[]{ },"Lorg/mortbay/component/Container;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IGET_OBJECT,2,6,new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_servlets","[Lorg/mortbay/jetty/servlet/ServletHolder;"));
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitConstStmt(CONST_STRING,4,"servlet");
                code.visitConstStmt(CONST_4,5, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt2R(MOVE_OBJECT,1,6);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 0,1,2,3,4,5},new Method("Lorg/mortbay/component/Container;","update",new String[]{ "Ljava/lang/Object;","[Ljava/lang/Object;","[Ljava/lang/Object;","Ljava/lang/String;","Z"},"V"));
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","getServer",new String[]{ },"Lorg/mortbay/jetty/Server;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/Server;","getContainer",new String[]{ },"Lorg/mortbay/component/Container;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IGET_OBJECT,2,6,new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_servletMappings","[Lorg/mortbay/jetty/servlet/ServletMapping;"));
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitConstStmt(CONST_STRING,4,"servletMapping");
                code.visitConstStmt(CONST_4,5, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt2R(MOVE_OBJECT,1,6);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 0,1,2,3,4,5},new Method("Lorg/mortbay/component/Container;","update",new String[]{ "Ljava/lang/Object;","[Ljava/lang/Object;","[Ljava/lang/Object;","Ljava/lang/String;","Z"},"V"));
                code.visitLabel(L5);
                code.visitJumpStmt(IF_EQZ,7,-1,L10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","getServer",new String[]{ },"Lorg/mortbay/jetty/Server;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitJumpStmt(IF_EQ,0,7,L10);
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Lorg/mortbay/jetty/Server;","getContainer",new String[]{ },"Lorg/mortbay/component/Container;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IGET_OBJECT,3,6,new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_filters","[Lorg/mortbay/jetty/servlet/FilterHolder;"));
                code.visitConstStmt(CONST_STRING,4,"filter");
                code.visitConstStmt(CONST_4,5, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt2R(MOVE_OBJECT,1,6);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 0,1,2,3,4,5},new Method("Lorg/mortbay/component/Container;","update",new String[]{ "Ljava/lang/Object;","[Ljava/lang/Object;","[Ljava/lang/Object;","Ljava/lang/String;","Z"},"V"));
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Lorg/mortbay/jetty/Server;","getContainer",new String[]{ },"Lorg/mortbay/component/Container;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IGET_OBJECT,3,6,new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_filterMappings","[Lorg/mortbay/jetty/servlet/FilterMapping;"));
                code.visitConstStmt(CONST_STRING,4,"filterMapping");
                code.visitConstStmt(CONST_4,5, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt2R(MOVE_OBJECT,1,6);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 0,1,2,3,4,5},new Method("Lorg/mortbay/component/Container;","update",new String[]{ "Ljava/lang/Object;","[Ljava/lang/Object;","[Ljava/lang/Object;","Ljava/lang/String;","Z"},"V"));
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Lorg/mortbay/jetty/Server;","getContainer",new String[]{ },"Lorg/mortbay/component/Container;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IGET_OBJECT,3,6,new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_servlets","[Lorg/mortbay/jetty/servlet/ServletHolder;"));
                code.visitConstStmt(CONST_STRING,4,"servlet");
                code.visitConstStmt(CONST_4,5, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt2R(MOVE_OBJECT,1,6);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 0,1,2,3,4,5},new Method("Lorg/mortbay/component/Container;","update",new String[]{ "Ljava/lang/Object;","[Ljava/lang/Object;","[Ljava/lang/Object;","Ljava/lang/String;","Z"},"V"));
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Lorg/mortbay/jetty/Server;","getContainer",new String[]{ },"Lorg/mortbay/component/Container;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IGET_OBJECT,3,6,new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_servletMappings","[Lorg/mortbay/jetty/servlet/ServletMapping;"));
                code.visitConstStmt(CONST_STRING,4,"servletMapping");
                code.visitConstStmt(CONST_4,5, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt2R(MOVE_OBJECT,1,6);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 0,1,2,3,4,5},new Method("Lorg/mortbay/component/Container;","update",new String[]{ "Ljava/lang/Object;","[Ljava/lang/Object;","[Ljava/lang/Object;","Ljava/lang/String;","Z"},"V"));
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 6,7},new Method("Lorg/mortbay/jetty/handler/AbstractHandler;","setServer",new String[]{ "Lorg/mortbay/jetty/Server;"},"V"));
                code.visitLabel(L11);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m050_setServletMappings(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","setServletMappings",new String[]{ "[Lorg/mortbay/jetty/servlet/ServletMapping;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(8);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"servletMappings");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1098,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(1099,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(1100,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(1101,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(1102,L4);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","getServer",new String[]{ },"Lorg/mortbay/jetty/Server;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L2);
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","getServer",new String[]{ },"Lorg/mortbay/jetty/Server;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/Server;","getContainer",new String[]{ },"Lorg/mortbay/component/Container;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IGET_OBJECT,2,6,new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_servletMappings","[Lorg/mortbay/jetty/servlet/ServletMapping;"));
                code.visitConstStmt(CONST_STRING,4,"servletMapping");
                code.visitConstStmt(CONST_4,5, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt2R(MOVE_OBJECT,1,6);
                code.visitStmt2R(MOVE_OBJECT,3,7);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 0,1,2,3,4,5},new Method("Lorg/mortbay/component/Container;","update",new String[]{ "Ljava/lang/Object;","[Ljava/lang/Object;","[Ljava/lang/Object;","Ljava/lang/String;","Z"},"V"));
                code.visitLabel(L2);
                code.visitFieldStmt(IPUT_OBJECT,7,6,new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_servletMappings","[Lorg/mortbay/jetty/servlet/ServletMapping;"));
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","updateMappings",new String[]{ },"V"));
                code.visitLabel(L4);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m051_setServlets(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","setServlets",new String[]{ "[Lorg/mortbay/jetty/servlet/ServletHolder;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(8);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"holders");
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(1110,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(1111,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(1112,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(1113,L6);
                ddv.visitLineNumber(1114,L1);
                ddv.visitLineNumber(1110,L2);
                code.visitLabel(L3);
                code.visitStmt1R(MONITOR_ENTER,6);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","getServer",new String[]{ },"Lorg/mortbay/jetty/Server;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L5);
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","getServer",new String[]{ },"Lorg/mortbay/jetty/Server;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/Server;","getContainer",new String[]{ },"Lorg/mortbay/component/Container;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IGET_OBJECT,2,6,new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_servlets","[Lorg/mortbay/jetty/servlet/ServletHolder;"));
                code.visitConstStmt(CONST_STRING,4,"servlet");
                code.visitConstStmt(CONST_4,5, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt2R(MOVE_OBJECT,1,6);
                code.visitStmt2R(MOVE_OBJECT,3,7);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 0,1,2,3,4,5},new Method("Lorg/mortbay/component/Container;","update",new String[]{ "Ljava/lang/Object;","[Ljava/lang/Object;","[Ljava/lang/Object;","Ljava/lang/String;","Z"},"V"));
                code.visitLabel(L5);
                code.visitFieldStmt(IPUT_OBJECT,7,6,new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_servlets","[Lorg/mortbay/jetty/servlet/ServletHolder;"));
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","updateNameMappings",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitStmt1R(MONITOR_EXIT,6);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,0);
                code.visitStmt1R(MONITOR_EXIT,6);
                code.visitStmt1R(THROW,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m052_setStartWithUnavailable(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","setStartWithUnavailable",new String[]{ "Z"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"start");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(626,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(627,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_BOOLEAN,1,0,new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_startWithUnavailable","Z"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m053_updateMappings(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","updateMappings",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(12);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                code.visitTryCatch(L1,L3,new DexLabel[]{L4,L2},new String[]{ "Ljava/lang/Exception;",null});
                DexLabel L5=new DexLabel();
                code.visitTryCatch(L5,L2,new DexLabel[]{L2},new String[]{ null});
                DexLabel L6=new DexLabel();
                DexLabel L7=new DexLabel();
                code.visitTryCatch(L6,L7,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L8=new DexLabel();
                ddv.visitPrologue(L8);
                ddv.visitLineNumber(973,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(975,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(976,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(1004,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(1006,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(1032,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(1034,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(1035,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(1036,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(1037,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(1038,L18);
                ddv.visitLineNumber(1043,L1);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(1044,L19);
                ddv.visitLineNumber(1050,L3);
                ddv.visitLineNumber(980,L5);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(981,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(982,L21);
                DexLabel L22=new DexLabel();
                ddv.visitStartLocal(2,L22,"i","I",null);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(984,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(985,L24);
                ddv.visitStartLocal(1,L24,"filter_holder","Lorg/mortbay/jetty/servlet/FilterHolder;",null);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(986,L25);
                ddv.visitLineNumber(973,L2);
                ddv.visitEndLocal(2,L2);
                ddv.visitEndLocal(1,L2);
                ddv.visitLineNumber(987,L6);
                ddv.visitRestartLocal(1,L6);
                ddv.visitRestartLocal(2,L6);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(988,L26);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(989,L27);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(991,L28);
                DexLabel L29=new DexLabel();
                ddv.visitLineNumber(993,L29);
                DexLabel L30=new DexLabel();
                ddv.visitLineNumber(994,L30);
                ddv.visitStartLocal(4,L30,"names","[Ljava/lang/String;",null);
                DexLabel L31=new DexLabel();
                ddv.visitStartLocal(3,L31,"j","I",null);
                DexLabel L32=new DexLabel();
                ddv.visitLineNumber(996,L32);
                DexLabel L33=new DexLabel();
                ddv.visitLineNumber(997,L33);
                DexLabel L34=new DexLabel();
                ddv.visitLineNumber(994,L34);
                DexLabel L35=new DexLabel();
                ddv.visitLineNumber(982,L35);
                ddv.visitEndLocal(4,L35);
                ddv.visitEndLocal(3,L35);
                DexLabel L36=new DexLabel();
                ddv.visitLineNumber(1010,L36);
                ddv.visitEndLocal(1,L36);
                ddv.visitEndLocal(2,L36);
                DexLabel L37=new DexLabel();
                ddv.visitLineNumber(1013,L37);
                ddv.visitStartLocal(6,L37,"pm","Lorg/mortbay/jetty/servlet/PathMap;",null);
                DexLabel L38=new DexLabel();
                ddv.visitRestartLocal(2,L38);
                DexLabel L39=new DexLabel();
                ddv.visitLineNumber(1015,L39);
                DexLabel L40=new DexLabel();
                ddv.visitLineNumber(1016,L40);
                ddv.visitStartLocal(7,L40,"servlet_holder","Lorg/mortbay/jetty/servlet/ServletHolder;",null);
                DexLabel L41=new DexLabel();
                ddv.visitLineNumber(1017,L41);
                DexLabel L42=new DexLabel();
                ddv.visitLineNumber(1018,L42);
                DexLabel L43=new DexLabel();
                ddv.visitLineNumber(1020,L43);
                DexLabel L44=new DexLabel();
                ddv.visitLineNumber(1021,L44);
                ddv.visitStartLocal(5,L44,"pathSpecs","[Ljava/lang/String;",null);
                DexLabel L45=new DexLabel();
                ddv.visitRestartLocal(3,L45);
                DexLabel L46=new DexLabel();
                ddv.visitLineNumber(1022,L46);
                DexLabel L47=new DexLabel();
                ddv.visitLineNumber(1023,L47);
                DexLabel L48=new DexLabel();
                ddv.visitLineNumber(1021,L48);
                DexLabel L49=new DexLabel();
                ddv.visitLineNumber(1013,L49);
                ddv.visitEndLocal(5,L49);
                ddv.visitEndLocal(3,L49);
                DexLabel L50=new DexLabel();
                ddv.visitLineNumber(1027,L50);
                ddv.visitEndLocal(7,L50);
                ddv.visitLineNumber(1046,L4);
                ddv.visitEndLocal(6,L4);
                ddv.visitEndLocal(2,L4);
                DexLabel L51=new DexLabel();
                ddv.visitLineNumber(1048,L51);
                ddv.visitStartLocal(0,L51,"e","Ljava/lang/Exception;",null);
                code.visitLabel(L8);
                code.visitStmt1R(MONITOR_ENTER,11);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,8,11,new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_filterMappings","[Lorg/mortbay/jetty/servlet/FilterMapping;"));
                code.visitJumpStmt(IF_NEZ,8,-1,L5);
                code.visitLabel(L9);
                code.visitConstStmt(CONST_4,8, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_OBJECT,8,11,new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_filterPathMappings","Ljava/util/List;"));
                code.visitLabel(L10);
                code.visitConstStmt(CONST_4,8, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_OBJECT,8,11,new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_filterNameMappings","Lorg/mortbay/util/MultiMap;"));
                code.visitLabel(L11);
                code.visitFieldStmt(IGET_OBJECT,8,11,new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_servletMappings","[Lorg/mortbay/jetty/servlet/ServletMapping;"));
                code.visitJumpStmt(IF_EQZ,8,-1,L12);
                code.visitFieldStmt(IGET_OBJECT,8,11,new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_servletNameMap","Ljava/util/Map;"));
                code.visitJumpStmt(IF_NEZ,8,-1,L36);
                code.visitLabel(L12);
                code.visitConstStmt(CONST_4,8, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_OBJECT,8,11,new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_servletPathMap","Lorg/mortbay/jetty/servlet/PathMap;"));
                code.visitLabel(L13);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/log/Log;","isDebugEnabled",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitJumpStmt(IF_EQZ,8,-1,L1);
                code.visitLabel(L14);
                code.visitTypeStmt(NEW_INSTANCE,8,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 8},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,9,"filterNameMap=");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,9},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitFieldStmt(IGET_OBJECT,9,11,new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_filterNameMap","Ljava/util/Map;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,9},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 8},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L15);
                code.visitTypeStmt(NEW_INSTANCE,8,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 8},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,9,"pathFilters=");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,9},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitFieldStmt(IGET_OBJECT,9,11,new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_filterPathMappings","Ljava/util/List;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,9},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 8},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L16);
                code.visitTypeStmt(NEW_INSTANCE,8,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 8},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,9,"servletFilterMap=");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,9},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitFieldStmt(IGET_OBJECT,9,11,new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_filterNameMappings","Lorg/mortbay/util/MultiMap;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,9},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 8},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L17);
                code.visitTypeStmt(NEW_INSTANCE,8,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 8},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,9,"servletPathMap=");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,9},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitFieldStmt(IGET_OBJECT,9,11,new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_servletPathMap","Lorg/mortbay/jetty/servlet/PathMap;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,9},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 8},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L18);
                code.visitTypeStmt(NEW_INSTANCE,8,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 8},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,9,"servletNameMap=");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,9},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitFieldStmt(IGET_OBJECT,9,11,new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_servletNameMap","Ljava/util/Map;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,9},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 8},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11},new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","isStarted",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitJumpStmt(IF_EQZ,8,-1,L3);
                code.visitLabel(L19);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11},new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","initialize",new String[]{ },"V"));
                code.visitLabel(L3);
                code.visitStmt1R(MONITOR_EXIT,11);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L5);
                code.visitTypeStmt(NEW_INSTANCE,8,-1,"Ljava/util/ArrayList;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 8},new Method("Ljava/util/ArrayList;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,8,11,new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_filterPathMappings","Ljava/util/List;"));
                code.visitLabel(L20);
                code.visitTypeStmt(NEW_INSTANCE,8,-1,"Lorg/mortbay/util/MultiMap;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 8},new Method("Lorg/mortbay/util/MultiMap;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,8,11,new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_filterNameMappings","Lorg/mortbay/util/MultiMap;"));
                code.visitLabel(L21);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L22);
                code.visitFieldStmt(IGET_OBJECT,8,11,new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_filterMappings","[Lorg/mortbay/jetty/servlet/FilterMapping;"));
                code.visitStmt2R(ARRAY_LENGTH,8,8);
                code.visitJumpStmt(IF_GE,2,8,L11);
                code.visitLabel(L23);
                code.visitFieldStmt(IGET_OBJECT,8,11,new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_filterNameMap","Ljava/util/Map;"));
                code.visitFieldStmt(IGET_OBJECT,9,11,new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_filterMappings","[Lorg/mortbay/jetty/servlet/FilterMapping;"));
                code.visitStmt3R(AGET_OBJECT,9,9,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9},new Method("Lorg/mortbay/jetty/servlet/FilterMapping;","getFilterName",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 8,9},new Method("Ljava/util/Map;","get",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitTypeStmt(CHECK_CAST,1,-1,"Lorg/mortbay/jetty/servlet/FilterHolder;");
                code.visitLabel(L24);
                code.visitJumpStmt(IF_NEZ,1,-1,L6);
                code.visitLabel(L25);
                code.visitTypeStmt(NEW_INSTANCE,8,-1,"Ljava/lang/IllegalStateException;");
                code.visitTypeStmt(NEW_INSTANCE,9,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 9},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,10,"No filter named ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9,10},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitFieldStmt(IGET_OBJECT,10,11,new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_filterMappings","[Lorg/mortbay/jetty/servlet/FilterMapping;"));
                code.visitStmt3R(AGET_OBJECT,10,10,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Lorg/mortbay/jetty/servlet/FilterMapping;","getFilterName",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9,10},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 8,9},new Method("Ljava/lang/IllegalStateException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,8);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,8);
                code.visitStmt1R(MONITOR_EXIT,11);
                code.visitStmt1R(THROW,8);
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,8,11,new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_filterMappings","[Lorg/mortbay/jetty/servlet/FilterMapping;"));
                code.visitStmt3R(AGET_OBJECT,8,8,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,1},new Method("Lorg/mortbay/jetty/servlet/FilterMapping;","setFilterHolder",new String[]{ "Lorg/mortbay/jetty/servlet/FilterHolder;"},"V"));
                code.visitLabel(L26);
                code.visitFieldStmt(IGET_OBJECT,8,11,new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_filterMappings","[Lorg/mortbay/jetty/servlet/FilterMapping;"));
                code.visitStmt3R(AGET_OBJECT,8,8,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Lorg/mortbay/jetty/servlet/FilterMapping;","getPathSpecs",new String[]{ },"[Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitJumpStmt(IF_EQZ,8,-1,L28);
                code.visitLabel(L27);
                code.visitFieldStmt(IGET_OBJECT,8,11,new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_filterPathMappings","Ljava/util/List;"));
                code.visitFieldStmt(IGET_OBJECT,9,11,new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_filterMappings","[Lorg/mortbay/jetty/servlet/FilterMapping;"));
                code.visitStmt3R(AGET_OBJECT,9,9,2);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 8,9},new Method("Ljava/util/List;","add",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitLabel(L28);
                code.visitFieldStmt(IGET_OBJECT,8,11,new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_filterMappings","[Lorg/mortbay/jetty/servlet/FilterMapping;"));
                code.visitStmt3R(AGET_OBJECT,8,8,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Lorg/mortbay/jetty/servlet/FilterMapping;","getServletNames",new String[]{ },"[Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitJumpStmt(IF_EQZ,8,-1,L35);
                code.visitLabel(L29);
                code.visitFieldStmt(IGET_OBJECT,8,11,new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_filterMappings","[Lorg/mortbay/jetty/servlet/FilterMapping;"));
                code.visitStmt3R(AGET_OBJECT,8,8,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Lorg/mortbay/jetty/servlet/FilterMapping;","getServletNames",new String[]{ },"[Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitLabel(L30);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L31);
                code.visitStmt2R(ARRAY_LENGTH,8,4);
                code.visitJumpStmt(IF_GE,3,8,L35);
                code.visitLabel(L32);
                code.visitStmt3R(AGET_OBJECT,8,4,3);
                code.visitJumpStmt(IF_EQZ,8,-1,L34);
                code.visitLabel(L33);
                code.visitFieldStmt(IGET_OBJECT,8,11,new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_filterNameMappings","Lorg/mortbay/util/MultiMap;"));
                code.visitStmt3R(AGET_OBJECT,9,4,3);
                code.visitFieldStmt(IGET_OBJECT,10,11,new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_filterMappings","[Lorg/mortbay/jetty/servlet/FilterMapping;"));
                code.visitStmt3R(AGET_OBJECT,10,10,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,9,10},new Method("Lorg/mortbay/util/MultiMap;","add",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L34);
                code.visitStmt2R1N(ADD_INT_LIT8,3,3,1);
                code.visitJumpStmt(GOTO,-1,-1,L31);
                code.visitLabel(L35);
                code.visitStmt2R1N(ADD_INT_LIT8,2,2,1);
                code.visitJumpStmt(GOTO,-1,-1,L22);
                code.visitLabel(L36);
                code.visitTypeStmt(NEW_INSTANCE,6,-1,"Lorg/mortbay/jetty/servlet/PathMap;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 6},new Method("Lorg/mortbay/jetty/servlet/PathMap;","<init>",new String[]{ },"V"));
                code.visitLabel(L37);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L38);
                code.visitFieldStmt(IGET_OBJECT,8,11,new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_servletMappings","[Lorg/mortbay/jetty/servlet/ServletMapping;"));
                code.visitStmt2R(ARRAY_LENGTH,8,8);
                code.visitJumpStmt(IF_GE,2,8,L50);
                code.visitLabel(L39);
                code.visitFieldStmt(IGET_OBJECT,8,11,new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_servletNameMap","Ljava/util/Map;"));
                code.visitFieldStmt(IGET_OBJECT,9,11,new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_servletMappings","[Lorg/mortbay/jetty/servlet/ServletMapping;"));
                code.visitStmt3R(AGET_OBJECT,9,9,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9},new Method("Lorg/mortbay/jetty/servlet/ServletMapping;","getServletName",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 8,9},new Method("Ljava/util/Map;","get",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitTypeStmt(CHECK_CAST,7,-1,"Lorg/mortbay/jetty/servlet/ServletHolder;");
                code.visitLabel(L40);
                code.visitJumpStmt(IF_NEZ,7,-1,L42);
                code.visitLabel(L41);
                code.visitTypeStmt(NEW_INSTANCE,8,-1,"Ljava/lang/IllegalStateException;");
                code.visitTypeStmt(NEW_INSTANCE,9,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 9},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,10,"No such servlet: ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9,10},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitFieldStmt(IGET_OBJECT,10,11,new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_servletMappings","[Lorg/mortbay/jetty/servlet/ServletMapping;"));
                code.visitStmt3R(AGET_OBJECT,10,10,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Lorg/mortbay/jetty/servlet/ServletMapping;","getServletName",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9,10},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 8,9},new Method("Ljava/lang/IllegalStateException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,8);
                code.visitLabel(L42);
                code.visitFieldStmt(IGET_OBJECT,8,11,new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_servletMappings","[Lorg/mortbay/jetty/servlet/ServletMapping;"));
                code.visitStmt3R(AGET_OBJECT,8,8,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Lorg/mortbay/jetty/servlet/ServletMapping;","getPathSpecs",new String[]{ },"[Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitJumpStmt(IF_EQZ,8,-1,L49);
                code.visitLabel(L43);
                code.visitFieldStmt(IGET_OBJECT,8,11,new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_servletMappings","[Lorg/mortbay/jetty/servlet/ServletMapping;"));
                code.visitStmt3R(AGET_OBJECT,8,8,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Lorg/mortbay/jetty/servlet/ServletMapping;","getPathSpecs",new String[]{ },"[Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitLabel(L44);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L45);
                code.visitStmt2R(ARRAY_LENGTH,8,5);
                code.visitJumpStmt(IF_GE,3,8,L49);
                code.visitLabel(L46);
                code.visitStmt3R(AGET_OBJECT,8,5,3);
                code.visitJumpStmt(IF_EQZ,8,-1,L48);
                code.visitLabel(L47);
                code.visitStmt3R(AGET_OBJECT,8,5,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,8,7},new Method("Lorg/mortbay/jetty/servlet/PathMap;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L48);
                code.visitStmt2R1N(ADD_INT_LIT8,3,3,1);
                code.visitJumpStmt(GOTO,-1,-1,L45);
                code.visitLabel(L49);
                code.visitStmt2R1N(ADD_INT_LIT8,2,2,1);
                code.visitJumpStmt(GOTO,-1,-1,L38);
                code.visitLabel(L50);
                code.visitFieldStmt(IPUT_OBJECT,6,11,new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_servletPathMap","Lorg/mortbay/jetty/servlet/PathMap;"));
                code.visitJumpStmt(GOTO_16,-1,-1,L13);
                code.visitLabel(L4);
                code.visitStmt1R(MOVE_EXCEPTION,8);
                code.visitStmt2R(MOVE_OBJECT,0,8);
                code.visitLabel(L51);
                code.visitTypeStmt(NEW_INSTANCE,8,-1,"Ljava/lang/RuntimeException;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 8,0},new Method("Ljava/lang/RuntimeException;","<init>",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitStmt1R(THROW,8);
                code.visitLabel(L7);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m054_updateNameMappings(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","updateNameMappings",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(946,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(947,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(949,L5);
                DexLabel L6=new DexLabel();
                ddv.visitStartLocal(0,L6,"i","I",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(951,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(952,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(949,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(957,L10);
                ddv.visitEndLocal(0,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(958,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(961,L12);
                DexLabel L13=new DexLabel();
                ddv.visitRestartLocal(0,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(963,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(964,L15);
                ddv.visitLineNumber(961,L1);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(967,L16);
                ddv.visitEndLocal(0,L16);
                ddv.visitLineNumber(946,L2);
                code.visitLabel(L3);
                code.visitStmt1R(MONITOR_ENTER,4);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_filterNameMap","Ljava/util/Map;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Ljava/util/Map;","clear",new String[]{ },"V"));
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_filters","[Lorg/mortbay/jetty/servlet/FilterHolder;"));
                code.visitJumpStmt(IF_EQZ,1,-1,L10);
                code.visitLabel(L5);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_filters","[Lorg/mortbay/jetty/servlet/FilterHolder;"));
                code.visitStmt2R(ARRAY_LENGTH,1,1);
                code.visitJumpStmt(IF_GE,0,1,L10);
                code.visitLabel(L7);
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_filterNameMap","Ljava/util/Map;"));
                code.visitFieldStmt(IGET_OBJECT,2,4,new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_filters","[Lorg/mortbay/jetty/servlet/FilterHolder;"));
                code.visitStmt3R(AGET_OBJECT,2,2,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/servlet/FilterHolder;","getName",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitFieldStmt(IGET_OBJECT,3,4,new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_filters","[Lorg/mortbay/jetty/servlet/FilterHolder;"));
                code.visitStmt3R(AGET_OBJECT,3,3,0);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1,2,3},new Method("Ljava/util/Map;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L8);
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_filters","[Lorg/mortbay/jetty/servlet/FilterHolder;"));
                code.visitStmt3R(AGET_OBJECT,1,1,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,4},new Method("Lorg/mortbay/jetty/servlet/FilterHolder;","setServletHandler",new String[]{ "Lorg/mortbay/jetty/servlet/ServletHandler;"},"V"));
                code.visitLabel(L9);
                code.visitStmt2R1N(ADD_INT_LIT8,0,0,1);
                code.visitJumpStmt(GOTO,-1,-1,L6);
                code.visitLabel(L10);
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_servletNameMap","Ljava/util/Map;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Ljava/util/Map;","clear",new String[]{ },"V"));
                code.visitLabel(L11);
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_servlets","[Lorg/mortbay/jetty/servlet/ServletHolder;"));
                code.visitJumpStmt(IF_EQZ,1,-1,L16);
                code.visitLabel(L12);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L13);
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_servlets","[Lorg/mortbay/jetty/servlet/ServletHolder;"));
                code.visitStmt2R(ARRAY_LENGTH,1,1);
                code.visitJumpStmt(IF_GE,0,1,L16);
                code.visitLabel(L14);
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_servletNameMap","Ljava/util/Map;"));
                code.visitFieldStmt(IGET_OBJECT,2,4,new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_servlets","[Lorg/mortbay/jetty/servlet/ServletHolder;"));
                code.visitStmt3R(AGET_OBJECT,2,2,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/servlet/ServletHolder;","getName",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitFieldStmt(IGET_OBJECT,3,4,new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_servlets","[Lorg/mortbay/jetty/servlet/ServletHolder;"));
                code.visitStmt3R(AGET_OBJECT,3,3,0);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1,2,3},new Method("Ljava/util/Map;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L15);
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/jetty/servlet/ServletHandler;","_servlets","[Lorg/mortbay/jetty/servlet/ServletHolder;"));
                code.visitStmt3R(AGET_OBJECT,1,1,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,4},new Method("Lorg/mortbay/jetty/servlet/ServletHolder;","setServletHandler",new String[]{ "Lorg/mortbay/jetty/servlet/ServletHandler;"},"V"));
                code.visitLabel(L1);
                code.visitStmt2R1N(ADD_INT_LIT8,0,0,1);
                code.visitJumpStmt(GOTO,-1,-1,L13);
                code.visitLabel(L16);
                code.visitStmt1R(MONITOR_EXIT,4);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitStmt1R(MONITOR_EXIT,4);
                code.visitStmt1R(THROW,1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
