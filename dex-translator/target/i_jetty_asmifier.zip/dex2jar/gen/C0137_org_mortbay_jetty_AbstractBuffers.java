package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0137_org_mortbay_jetty_AbstractBuffers {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC|ACC_ABSTRACT,"Lorg/mortbay/jetty/AbstractBuffers;","Lorg/mortbay/component/AbstractLifeCycle;",new String[]{ "Lorg/mortbay/io/Buffers;"});
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("AbstractBuffers.java");
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/MemberClasses;", Visibility.SYSTEM);
            if(av00 != null) {
                {
                    DexAnnotationVisitor av01 = av00.visitArray("value");
                    if(av01 != null) {
                        av01.visit(null, new DexType("Lorg/mortbay/jetty/AbstractBuffers$ThreadBuffers;"));
                        av01.visitEnd();
                    }
                }
                av00.visitEnd();
            }
        }
        f000___HEADER(cv);
        f001___OTHER(cv);
        f002___REQUEST(cv);
        f003___RESPONSE(cv);
        f004__buffers(cv);
        f005__headerBufferSize(cv);
        f006__pool(cv);
        f007__requestBufferSize(cv);
        f008__responseBufferSize(cv);
        m000__init_(cv);
        m001_access$000(cv);
        m002_doStart(cv);
        m003_getBuffer(cv);
        m004_getHeaderBufferSize(cv);
        m005_getRequestBufferSize(cv);
        m006_getResponseBufferSize(cv);
        m007_newBuffer(cv);
        m008_returnBuffer(cv);
        m009_setHeaderBufferSize(cv);
        m010_setRequestBufferSize(cv);
        m011_setResponseBufferSize(cv);
    }
    public static void f000___HEADER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/AbstractBuffers;","__HEADER","I"),  Integer.valueOf(0));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001___OTHER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/AbstractBuffers;","__OTHER","I"),  Integer.valueOf(3));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002___REQUEST(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/AbstractBuffers;","__REQUEST","I"),  Integer.valueOf(1));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003___RESPONSE(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/AbstractBuffers;","__RESPONSE","I"),  Integer.valueOf(2));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f004__buffers(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_FINAL, new Field("Lorg/mortbay/jetty/AbstractBuffers;","_buffers","Ljava/lang/ThreadLocal;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f005__headerBufferSize(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/AbstractBuffers;","_headerBufferSize","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f006__pool(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_FINAL, new Field("Lorg/mortbay/jetty/AbstractBuffers;","_pool","[I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f007__requestBufferSize(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/AbstractBuffers;","_requestBufferSize","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f008__responseBufferSize(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/AbstractBuffers;","_responseBufferSize","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/AbstractBuffers;","<init>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(51,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(31,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(32,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(33,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(39,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(41,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(52,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(39,L7);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Lorg/mortbay/component/AbstractLifeCycle;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitConstStmt(CONST_16,0, Integer.valueOf(4096)); // int: 0x00001000  float:0.000000
                code.visitFieldStmt(IPUT,0,1,new Field("Lorg/mortbay/jetty/AbstractBuffers;","_headerBufferSize","I"));
                code.visitLabel(L2);
                code.visitConstStmt(CONST_16,0, Integer.valueOf(8192)); // int: 0x00002000  float:0.000000
                code.visitFieldStmt(IPUT,0,1,new Field("Lorg/mortbay/jetty/AbstractBuffers;","_requestBufferSize","I"));
                code.visitLabel(L3);
                code.visitConstStmt(CONST_16,0, Integer.valueOf(24576)); // int: 0x00006000  float:0.000000
                code.visitFieldStmt(IPUT,0,1,new Field("Lorg/mortbay/jetty/AbstractBuffers;","_responseBufferSize","I"));
                code.visitLabel(L4);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(4)); // int: 0x00000004  float:0.000000
                code.visitTypeStmt(NEW_ARRAY,0,0,"[I");
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/AbstractBuffers;","_pool","[I"));
                code.visitLabel(L5);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/jetty/AbstractBuffers$1;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/AbstractBuffers$1;","<init>",new String[]{ "Lorg/mortbay/jetty/AbstractBuffers;"},"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/AbstractBuffers;","_buffers","Ljava/lang/ThreadLocal;"));
                code.visitLabel(L6);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L7);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001_access$000(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_SYNTHETIC, new Method("Lorg/mortbay/jetty/AbstractBuffers;","access$000",new String[]{ "Lorg/mortbay/jetty/AbstractBuffers;"},"[I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"x0");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(29,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/AbstractBuffers;","_pool","[I"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_doStart(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/AbstractBuffers;","doStart",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/Exception;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(8);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(105,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(106,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(108,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(109,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(110,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(128,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(112,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(114,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(115,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(117,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(119,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(120,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(122,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(124,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(125,L15);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,6, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitConstStmt(CONST_4,5, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitConstStmt(CONST_4,4, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 7},new Method("Lorg/mortbay/component/AbstractLifeCycle;","doStart",new String[]{ },"V"));
                code.visitLabel(L2);
                code.visitFieldStmt(IGET,0,7,new Field("Lorg/mortbay/jetty/AbstractBuffers;","_headerBufferSize","I"));
                code.visitFieldStmt(IGET,1,7,new Field("Lorg/mortbay/jetty/AbstractBuffers;","_requestBufferSize","I"));
                code.visitJumpStmt(IF_NE,0,1,L7);
                code.visitFieldStmt(IGET,0,7,new Field("Lorg/mortbay/jetty/AbstractBuffers;","_headerBufferSize","I"));
                code.visitFieldStmt(IGET,1,7,new Field("Lorg/mortbay/jetty/AbstractBuffers;","_responseBufferSize","I"));
                code.visitJumpStmt(IF_NE,0,1,L7);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,7,new Field("Lorg/mortbay/jetty/AbstractBuffers;","_pool","[I"));
                code.visitStmt3R(AGET,1,0,4);
                code.visitFieldStmt(IGET_OBJECT,2,7,new Field("Lorg/mortbay/jetty/AbstractBuffers;","_pool","[I"));
                code.visitStmt3R(AGET,2,2,5);
                code.visitFieldStmt(IGET_OBJECT,3,7,new Field("Lorg/mortbay/jetty/AbstractBuffers;","_pool","[I"));
                code.visitStmt3R(AGET,3,3,6);
                code.visitStmt2R(ADD_INT_2ADDR,2,3);
                code.visitStmt2R(ADD_INT_2ADDR,1,2);
                code.visitStmt3R(APUT,1,0,4);
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,0,7,new Field("Lorg/mortbay/jetty/AbstractBuffers;","_pool","[I"));
                code.visitStmt3R(APUT,4,0,5);
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,0,7,new Field("Lorg/mortbay/jetty/AbstractBuffers;","_pool","[I"));
                code.visitStmt3R(APUT,4,0,6);
                code.visitLabel(L6);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L7);
                code.visitFieldStmt(IGET,0,7,new Field("Lorg/mortbay/jetty/AbstractBuffers;","_headerBufferSize","I"));
                code.visitFieldStmt(IGET,1,7,new Field("Lorg/mortbay/jetty/AbstractBuffers;","_requestBufferSize","I"));
                code.visitJumpStmt(IF_NE,0,1,L10);
                code.visitLabel(L8);
                code.visitFieldStmt(IGET_OBJECT,0,7,new Field("Lorg/mortbay/jetty/AbstractBuffers;","_pool","[I"));
                code.visitStmt3R(AGET,1,0,4);
                code.visitFieldStmt(IGET_OBJECT,2,7,new Field("Lorg/mortbay/jetty/AbstractBuffers;","_pool","[I"));
                code.visitStmt3R(AGET,2,2,5);
                code.visitStmt2R(ADD_INT_2ADDR,1,2);
                code.visitStmt3R(APUT,1,0,4);
                code.visitLabel(L9);
                code.visitFieldStmt(IGET_OBJECT,0,7,new Field("Lorg/mortbay/jetty/AbstractBuffers;","_pool","[I"));
                code.visitStmt3R(APUT,4,0,5);
                code.visitJumpStmt(GOTO,-1,-1,L6);
                code.visitLabel(L10);
                code.visitFieldStmt(IGET,0,7,new Field("Lorg/mortbay/jetty/AbstractBuffers;","_headerBufferSize","I"));
                code.visitFieldStmt(IGET,1,7,new Field("Lorg/mortbay/jetty/AbstractBuffers;","_responseBufferSize","I"));
                code.visitJumpStmt(IF_NE,0,1,L13);
                code.visitLabel(L11);
                code.visitFieldStmt(IGET_OBJECT,0,7,new Field("Lorg/mortbay/jetty/AbstractBuffers;","_pool","[I"));
                code.visitStmt3R(AGET,1,0,4);
                code.visitFieldStmt(IGET_OBJECT,2,7,new Field("Lorg/mortbay/jetty/AbstractBuffers;","_pool","[I"));
                code.visitStmt3R(AGET,2,2,6);
                code.visitStmt2R(ADD_INT_2ADDR,1,2);
                code.visitStmt3R(APUT,1,0,4);
                code.visitLabel(L12);
                code.visitFieldStmt(IGET_OBJECT,0,7,new Field("Lorg/mortbay/jetty/AbstractBuffers;","_pool","[I"));
                code.visitStmt3R(APUT,4,0,6);
                code.visitJumpStmt(GOTO,-1,-1,L6);
                code.visitLabel(L13);
                code.visitFieldStmt(IGET,0,7,new Field("Lorg/mortbay/jetty/AbstractBuffers;","_requestBufferSize","I"));
                code.visitFieldStmt(IGET,1,7,new Field("Lorg/mortbay/jetty/AbstractBuffers;","_responseBufferSize","I"));
                code.visitJumpStmt(IF_NE,0,1,L6);
                code.visitLabel(L14);
                code.visitFieldStmt(IGET_OBJECT,0,7,new Field("Lorg/mortbay/jetty/AbstractBuffers;","_pool","[I"));
                code.visitStmt3R(AGET,1,0,6);
                code.visitFieldStmt(IGET_OBJECT,2,7,new Field("Lorg/mortbay/jetty/AbstractBuffers;","_pool","[I"));
                code.visitStmt3R(AGET,2,2,5);
                code.visitStmt2R(ADD_INT_2ADDR,1,2);
                code.visitStmt3R(APUT,1,0,6);
                code.visitLabel(L15);
                code.visitFieldStmt(IGET_OBJECT,0,7,new Field("Lorg/mortbay/jetty/AbstractBuffers;","_pool","[I"));
                code.visitStmt3R(APUT,4,0,5);
                code.visitJumpStmt(GOTO,-1,-1,L6);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_getBuffer(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/AbstractBuffers;","getBuffer",new String[]{ "I"},"Lorg/mortbay/io/Buffer;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(8);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"size");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(58,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(62,L1);
                ddv.visitStartLocal(3,L1,"set","I",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(64,L2);
                ddv.visitStartLocal(4,L2,"thread_buffers","Lorg/mortbay/jetty/AbstractBuffers$ThreadBuffers;",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(65,L3);
                ddv.visitStartLocal(1,L3,"buffers","[Lorg/mortbay/io/Buffer;",null);
                DexLabel L4=new DexLabel();
                ddv.visitStartLocal(2,L4,"i","I",null);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(67,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(68,L6);
                ddv.visitStartLocal(0,L6,"b","Lorg/mortbay/io/Buffer;",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(70,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(75,L8);
                ddv.visitEndLocal(0,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(58,L9);
                ddv.visitEndLocal(3,L9);
                ddv.visitEndLocal(4,L9);
                ddv.visitEndLocal(1,L9);
                ddv.visitEndLocal(2,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(65,L10);
                ddv.visitRestartLocal(0,L10);
                ddv.visitRestartLocal(1,L10);
                ddv.visitRestartLocal(2,L10);
                ddv.visitRestartLocal(3,L10);
                ddv.visitRestartLocal(4,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(75,L11);
                ddv.visitEndLocal(0,L11);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,5,6,new Field("Lorg/mortbay/jetty/AbstractBuffers;","_headerBufferSize","I"));
                code.visitJumpStmt(IF_NE,7,5,L9);
                code.visitConstStmt(CONST_4,5, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt2R(MOVE,3,5);
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,5,6,new Field("Lorg/mortbay/jetty/AbstractBuffers;","_buffers","Ljava/lang/ThreadLocal;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/lang/ThreadLocal;","get",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitTypeStmt(CHECK_CAST,4,-1,"Lorg/mortbay/jetty/AbstractBuffers$ThreadBuffers;");
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,5,4,new Field("Lorg/mortbay/jetty/AbstractBuffers$ThreadBuffers;","_buffers","[[Lorg/mortbay/io/Buffer;"));
                code.visitStmt3R(AGET_OBJECT,1,5,3);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L4);
                code.visitStmt2R(ARRAY_LENGTH,5,1);
                code.visitJumpStmt(IF_GE,2,5,L11);
                code.visitLabel(L5);
                code.visitStmt3R(AGET_OBJECT,0,1,2);
                code.visitLabel(L6);
                code.visitJumpStmt(IF_EQZ,0,-1,L10);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Lorg/mortbay/io/Buffer;","capacity",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitJumpStmt(IF_NE,5,7,L10);
                code.visitLabel(L7);
                code.visitConstStmt(CONST_4,5, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt3R(APUT_OBJECT,5,1,2);
                code.visitStmt2R(MOVE_OBJECT,5,0);
                code.visitLabel(L8);
                code.visitStmt1R(RETURN_OBJECT,5);
                code.visitLabel(L9);
                code.visitFieldStmt(IGET,5,6,new Field("Lorg/mortbay/jetty/AbstractBuffers;","_responseBufferSize","I"));
                DexLabel L12=new DexLabel();
                code.visitJumpStmt(IF_NE,7,5,L12);
                code.visitConstStmt(CONST_4,5, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitStmt2R(MOVE,3,5);
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitLabel(L12);
                code.visitFieldStmt(IGET,5,6,new Field("Lorg/mortbay/jetty/AbstractBuffers;","_requestBufferSize","I"));
                DexLabel L13=new DexLabel();
                code.visitJumpStmt(IF_NE,7,5,L13);
                code.visitConstStmt(CONST_4,5, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt2R(MOVE,3,5);
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitLabel(L13);
                code.visitConstStmt(CONST_4,5, Integer.valueOf(3)); // int: 0x00000003  float:0.000000
                code.visitStmt2R(MOVE,3,5);
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitLabel(L10);
                code.visitStmt2R1N(ADD_INT_LIT8,2,2,1);
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitLabel(L11);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,7},new Method("Lorg/mortbay/jetty/AbstractBuffers;","newBuffer",new String[]{ "I"},"Lorg/mortbay/io/Buffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitJumpStmt(GOTO,-1,-1,L8);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_getHeaderBufferSize(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/AbstractBuffers;","getHeaderBufferSize",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(135,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,1,new Field("Lorg/mortbay/jetty/AbstractBuffers;","_headerBufferSize","I"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_getRequestBufferSize(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/AbstractBuffers;","getRequestBufferSize",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(153,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,1,new Field("Lorg/mortbay/jetty/AbstractBuffers;","_requestBufferSize","I"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_getResponseBufferSize(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/AbstractBuffers;","getResponseBufferSize",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(171,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,1,new Field("Lorg/mortbay/jetty/AbstractBuffers;","_responseBufferSize","I"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m007_newBuffer(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED|ACC_ABSTRACT, new Method("Lorg/mortbay/jetty/AbstractBuffers;","newBuffer",new String[]{ "I"},"Lorg/mortbay/io/Buffer;"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m008_returnBuffer(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/AbstractBuffers;","returnBuffer",new String[]{ "Lorg/mortbay/io/Buffer;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(8);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"buffer");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(80,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(81,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(100,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(84,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(85,L4);
                ddv.visitStartLocal(3,L4,"size","I",null);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(89,L5);
                ddv.visitStartLocal(2,L5,"set","I",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(90,L6);
                ddv.visitStartLocal(4,L6,"thread_buffers","Lorg/mortbay/jetty/AbstractBuffers$ThreadBuffers;",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(91,L7);
                ddv.visitStartLocal(0,L7,"buffers","[Lorg/mortbay/io/Buffer;",null);
                DexLabel L8=new DexLabel();
                ddv.visitStartLocal(1,L8,"i","I",null);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(93,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(95,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(85,L11);
                ddv.visitEndLocal(2,L11);
                ddv.visitEndLocal(4,L11);
                ddv.visitEndLocal(0,L11);
                ddv.visitEndLocal(1,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(91,L12);
                ddv.visitRestartLocal(0,L12);
                ddv.visitRestartLocal(1,L12);
                ddv.visitRestartLocal(2,L12);
                ddv.visitRestartLocal(4,L12);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 7},new Method("Lorg/mortbay/io/Buffer;","clear",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 7},new Method("Lorg/mortbay/io/Buffer;","isVolatile",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitJumpStmt(IF_NEZ,5,-1,L2);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 7},new Method("Lorg/mortbay/io/Buffer;","isImmutable",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitJumpStmt(IF_EQZ,5,-1,L3);
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 7},new Method("Lorg/mortbay/io/Buffer;","capacity",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitLabel(L4);
                code.visitFieldStmt(IGET,5,6,new Field("Lorg/mortbay/jetty/AbstractBuffers;","_headerBufferSize","I"));
                code.visitJumpStmt(IF_NE,3,5,L11);
                code.visitConstStmt(CONST_4,5, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt2R(MOVE,2,5);
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,5,6,new Field("Lorg/mortbay/jetty/AbstractBuffers;","_buffers","Ljava/lang/ThreadLocal;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/lang/ThreadLocal;","get",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitTypeStmt(CHECK_CAST,4,-1,"Lorg/mortbay/jetty/AbstractBuffers$ThreadBuffers;");
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,5,4,new Field("Lorg/mortbay/jetty/AbstractBuffers$ThreadBuffers;","_buffers","[[Lorg/mortbay/io/Buffer;"));
                code.visitStmt3R(AGET_OBJECT,0,5,2);
                code.visitLabel(L7);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L8);
                code.visitStmt2R(ARRAY_LENGTH,5,0);
                code.visitJumpStmt(IF_GE,1,5,L2);
                code.visitLabel(L9);
                code.visitStmt3R(AGET_OBJECT,5,0,1);
                code.visitJumpStmt(IF_NEZ,5,-1,L12);
                code.visitLabel(L10);
                code.visitStmt3R(APUT_OBJECT,7,0,1);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L11);
                code.visitFieldStmt(IGET,5,6,new Field("Lorg/mortbay/jetty/AbstractBuffers;","_responseBufferSize","I"));
                DexLabel L13=new DexLabel();
                code.visitJumpStmt(IF_NE,3,5,L13);
                code.visitConstStmt(CONST_4,5, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitStmt2R(MOVE,2,5);
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitLabel(L13);
                code.visitFieldStmt(IGET,5,6,new Field("Lorg/mortbay/jetty/AbstractBuffers;","_requestBufferSize","I"));
                DexLabel L14=new DexLabel();
                code.visitJumpStmt(IF_NE,3,5,L14);
                code.visitConstStmt(CONST_4,5, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt2R(MOVE,2,5);
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitLabel(L14);
                code.visitConstStmt(CONST_4,5, Integer.valueOf(3)); // int: 0x00000003  float:0.000000
                code.visitStmt2R(MOVE,2,5);
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitLabel(L12);
                code.visitStmt2R1N(ADD_INT_LIT8,1,1,1);
                code.visitJumpStmt(GOTO,-1,-1,L8);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m009_setHeaderBufferSize(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/AbstractBuffers;","setHeaderBufferSize",new String[]{ "I"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"headerBufferSize");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(143,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(144,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(145,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(146,L3);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/jetty/AbstractBuffers;","isStarted",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L2);
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/IllegalStateException;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/IllegalStateException;","<init>",new String[]{ },"V"));
                code.visitStmt1R(THROW,0);
                code.visitLabel(L2);
                code.visitFieldStmt(IPUT,2,1,new Field("Lorg/mortbay/jetty/AbstractBuffers;","_headerBufferSize","I"));
                code.visitLabel(L3);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m010_setRequestBufferSize(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/AbstractBuffers;","setRequestBufferSize",new String[]{ "I"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"requestBufferSize");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(161,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(162,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(163,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(164,L3);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/jetty/AbstractBuffers;","isStarted",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L2);
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/IllegalStateException;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/IllegalStateException;","<init>",new String[]{ },"V"));
                code.visitStmt1R(THROW,0);
                code.visitLabel(L2);
                code.visitFieldStmt(IPUT,2,1,new Field("Lorg/mortbay/jetty/AbstractBuffers;","_requestBufferSize","I"));
                code.visitLabel(L3);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m011_setResponseBufferSize(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/AbstractBuffers;","setResponseBufferSize",new String[]{ "I"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"responseBufferSize");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(179,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(180,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(181,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(182,L3);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/jetty/AbstractBuffers;","isStarted",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L2);
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/IllegalStateException;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/IllegalStateException;","<init>",new String[]{ },"V"));
                code.visitStmt1R(THROW,0);
                code.visitLabel(L2);
                code.visitFieldStmt(IPUT,2,1,new Field("Lorg/mortbay/jetty/AbstractBuffers;","_responseBufferSize","I"));
                code.visitLabel(L3);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
