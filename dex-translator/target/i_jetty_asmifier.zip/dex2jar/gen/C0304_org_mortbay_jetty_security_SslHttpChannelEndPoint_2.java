package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0304_org_mortbay_jetty_security_SslHttpChannelEndPoint_2 {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(0,"Lorg/mortbay/jetty/security/SslHttpChannelEndPoint$2;","Ljava/lang/Object;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("SslHttpChannelEndPoint.java");
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/EnclosingClass;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("value", new DexType("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;"));
                av00.visitEnd();
            }
        }
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/InnerClass;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("accessFlags",  Integer.valueOf(4104));
                av00.visit("name", null);
                av00.visitEnd();
            }
        }
        f000_$SwitchMap$javax$net$ssl$SSLEngineResult$HandshakeStatus(cv);
        f001_$SwitchMap$javax$net$ssl$SSLEngineResult$Status(cv);
        m000__clinit_(cv);
    }
    public static void f000_$SwitchMap$javax$net$ssl$SSLEngineResult$HandshakeStatus(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_STATIC|ACC_FINAL|ACC_SYNTHETIC, new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint$2;","$SwitchMap$javax$net$ssl$SSLEngineResult$HandshakeStatus","[I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001_$SwitchMap$javax$net$ssl$SSLEngineResult$Status(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_STATIC|ACC_FINAL|ACC_SYNTHETIC, new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint$2;","$SwitchMap$javax$net$ssl$SSLEngineResult$Status","[I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__clinit_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint$2;","<clinit>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/lang/NoSuchFieldError;"});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                code.visitTryCatch(L1,L3,new DexLabel[]{L4},new String[]{ "Ljava/lang/NoSuchFieldError;"});
                DexLabel L5=new DexLabel();
                DexLabel L6=new DexLabel();
                code.visitTryCatch(L3,L5,new DexLabel[]{L6},new String[]{ "Ljava/lang/NoSuchFieldError;"});
                DexLabel L7=new DexLabel();
                DexLabel L8=new DexLabel();
                code.visitTryCatch(L5,L7,new DexLabel[]{L8},new String[]{ "Ljava/lang/NoSuchFieldError;"});
                DexLabel L9=new DexLabel();
                DexLabel L10=new DexLabel();
                DexLabel L11=new DexLabel();
                code.visitTryCatch(L9,L10,new DexLabel[]{L11},new String[]{ "Ljava/lang/NoSuchFieldError;"});
                DexLabel L12=new DexLabel();
                DexLabel L13=new DexLabel();
                code.visitTryCatch(L10,L12,new DexLabel[]{L13},new String[]{ "Ljava/lang/NoSuchFieldError;"});
                DexLabel L14=new DexLabel();
                DexLabel L15=new DexLabel();
                code.visitTryCatch(L12,L14,new DexLabel[]{L15},new String[]{ "Ljava/lang/NoSuchFieldError;"});
                DexLabel L16=new DexLabel();
                DexLabel L17=new DexLabel();
                code.visitTryCatch(L14,L16,new DexLabel[]{L17},new String[]{ "Ljava/lang/NoSuchFieldError;"});
                DexLabel L18=new DexLabel();
                DexLabel L19=new DexLabel();
                code.visitTryCatch(L16,L18,new DexLabel[]{L19},new String[]{ "Ljava/lang/NoSuchFieldError;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L20=new DexLabel();
                ddv.visitPrologue(L20);
                ddv.visitLineNumber(322,L20);
                ddv.visitLineNumber(159,L7);
                ddv.visitLineNumber(322,L8);
                code.visitLabel(L20);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Ljavax/net/ssl/SSLEngineResult$Status;","values",new String[]{ },"[Ljavax/net/ssl/SSLEngineResult$Status;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt2R(ARRAY_LENGTH,0,0);
                code.visitTypeStmt(NEW_ARRAY,0,0,"[I");
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint$2;","$SwitchMap$javax$net$ssl$SSLEngineResult$Status","[I"));
                code.visitLabel(L0);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint$2;","$SwitchMap$javax$net$ssl$SSLEngineResult$Status","[I"));
                code.visitFieldStmt(SGET_OBJECT,1,-1,new Field("Ljavax/net/ssl/SSLEngineResult$Status;","BUFFER_OVERFLOW","Ljavax/net/ssl/SSLEngineResult$Status;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljavax/net/ssl/SSLEngineResult$Status;","ordinal",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt3R(APUT,2,0,1);
                code.visitLabel(L1);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint$2;","$SwitchMap$javax$net$ssl$SSLEngineResult$Status","[I"));
                code.visitFieldStmt(SGET_OBJECT,1,-1,new Field("Ljavax/net/ssl/SSLEngineResult$Status;","BUFFER_UNDERFLOW","Ljavax/net/ssl/SSLEngineResult$Status;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljavax/net/ssl/SSLEngineResult$Status;","ordinal",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitStmt3R(APUT,2,0,1);
                code.visitLabel(L3);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint$2;","$SwitchMap$javax$net$ssl$SSLEngineResult$Status","[I"));
                code.visitFieldStmt(SGET_OBJECT,1,-1,new Field("Ljavax/net/ssl/SSLEngineResult$Status;","CLOSED","Ljavax/net/ssl/SSLEngineResult$Status;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljavax/net/ssl/SSLEngineResult$Status;","ordinal",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(3)); // int: 0x00000003  float:0.000000
                code.visitStmt3R(APUT,2,0,1);
                code.visitLabel(L5);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint$2;","$SwitchMap$javax$net$ssl$SSLEngineResult$Status","[I"));
                code.visitFieldStmt(SGET_OBJECT,1,-1,new Field("Ljavax/net/ssl/SSLEngineResult$Status;","OK","Ljavax/net/ssl/SSLEngineResult$Status;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljavax/net/ssl/SSLEngineResult$Status;","ordinal",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(4)); // int: 0x00000004  float:0.000000
                code.visitStmt3R(APUT,2,0,1);
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Ljavax/net/ssl/SSLEngineResult$HandshakeStatus;","values",new String[]{ },"[Ljavax/net/ssl/SSLEngineResult$HandshakeStatus;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt2R(ARRAY_LENGTH,0,0);
                code.visitTypeStmt(NEW_ARRAY,0,0,"[I");
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint$2;","$SwitchMap$javax$net$ssl$SSLEngineResult$HandshakeStatus","[I"));
                code.visitLabel(L9);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint$2;","$SwitchMap$javax$net$ssl$SSLEngineResult$HandshakeStatus","[I"));
                code.visitFieldStmt(SGET_OBJECT,1,-1,new Field("Ljavax/net/ssl/SSLEngineResult$HandshakeStatus;","FINISHED","Ljavax/net/ssl/SSLEngineResult$HandshakeStatus;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljavax/net/ssl/SSLEngineResult$HandshakeStatus;","ordinal",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt3R(APUT,2,0,1);
                code.visitLabel(L10);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint$2;","$SwitchMap$javax$net$ssl$SSLEngineResult$HandshakeStatus","[I"));
                code.visitFieldStmt(SGET_OBJECT,1,-1,new Field("Ljavax/net/ssl/SSLEngineResult$HandshakeStatus;","NOT_HANDSHAKING","Ljavax/net/ssl/SSLEngineResult$HandshakeStatus;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljavax/net/ssl/SSLEngineResult$HandshakeStatus;","ordinal",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitStmt3R(APUT,2,0,1);
                code.visitLabel(L12);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint$2;","$SwitchMap$javax$net$ssl$SSLEngineResult$HandshakeStatus","[I"));
                code.visitFieldStmt(SGET_OBJECT,1,-1,new Field("Ljavax/net/ssl/SSLEngineResult$HandshakeStatus;","NEED_UNWRAP","Ljavax/net/ssl/SSLEngineResult$HandshakeStatus;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljavax/net/ssl/SSLEngineResult$HandshakeStatus;","ordinal",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(3)); // int: 0x00000003  float:0.000000
                code.visitStmt3R(APUT,2,0,1);
                code.visitLabel(L14);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint$2;","$SwitchMap$javax$net$ssl$SSLEngineResult$HandshakeStatus","[I"));
                code.visitFieldStmt(SGET_OBJECT,1,-1,new Field("Ljavax/net/ssl/SSLEngineResult$HandshakeStatus;","NEED_TASK","Ljavax/net/ssl/SSLEngineResult$HandshakeStatus;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljavax/net/ssl/SSLEngineResult$HandshakeStatus;","ordinal",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(4)); // int: 0x00000004  float:0.000000
                code.visitStmt3R(APUT,2,0,1);
                code.visitLabel(L16);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint$2;","$SwitchMap$javax$net$ssl$SSLEngineResult$HandshakeStatus","[I"));
                code.visitFieldStmt(SGET_OBJECT,1,-1,new Field("Ljavax/net/ssl/SSLEngineResult$HandshakeStatus;","NEED_WRAP","Ljavax/net/ssl/SSLEngineResult$HandshakeStatus;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljavax/net/ssl/SSLEngineResult$HandshakeStatus;","ordinal",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(5)); // int: 0x00000005  float:0.000000
                code.visitStmt3R(APUT,2,0,1);
                code.visitLabel(L18);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L19);
                code.visitStmt1R(MOVE_EXCEPTION,0);
                code.visitJumpStmt(GOTO,-1,-1,L18);
                code.visitLabel(L17);
                code.visitStmt1R(MOVE_EXCEPTION,0);
                code.visitJumpStmt(GOTO,-1,-1,L16);
                code.visitLabel(L15);
                code.visitStmt1R(MOVE_EXCEPTION,0);
                code.visitJumpStmt(GOTO,-1,-1,L14);
                code.visitLabel(L13);
                code.visitStmt1R(MOVE_EXCEPTION,0);
                code.visitJumpStmt(GOTO,-1,-1,L12);
                code.visitLabel(L11);
                code.visitStmt1R(MOVE_EXCEPTION,0);
                code.visitJumpStmt(GOTO,-1,-1,L10);
                code.visitLabel(L8);
                code.visitStmt1R(MOVE_EXCEPTION,0);
                code.visitJumpStmt(GOTO,-1,-1,L7);
                code.visitLabel(L6);
                code.visitStmt1R(MOVE_EXCEPTION,0);
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitLabel(L4);
                code.visitStmt1R(MOVE_EXCEPTION,0);
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,0);
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
