package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.dj2.visitors.*;
public class Main {
    public static void accept(DexFileVisitor v) {
        C0000_dex038.accept(v);
    }
}
