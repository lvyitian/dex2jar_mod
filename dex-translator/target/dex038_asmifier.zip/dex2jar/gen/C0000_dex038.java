package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0000_dex038 {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Ldex038;","Ljava/lang/Object;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        m000__init_(cv);
        m001_invoke_custom(cv);
        m002_invoke_custom_range(cv);
        m003_invoke_polymorphic(cv);
        m004_invoke_polymorphic_range(cv);
        m005_main(cv);
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Ldex038;","<init>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/Object;","<init>",new String[]{ },"V"));
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001_invoke_custom(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Ldex038;","invoke_custom",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(0);
                code.visitMethodStmt(INVOKE_CUSTOM,new int[]{ },new CallSite("call_site_0", new MethodHandle(MethodHandle.INVOKE_STATIC,new Method("L038;","bsm",new String[]{ "Ljava/lang/invoke/MethodHandles$Lookup;","Ljava/lang/String;","Ljava/lang/invoke/MethodType;"},"Ljava/lang/invoke/CallSite;")), "runDynamic", new Proto(new String[]{ },"V")));
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_invoke_custom_range(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Ldex038;","invoke_custom_range",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt2R(MOVE,1,0);
                code.visitStmt2R(MOVE,2,0);
                code.visitStmt2R(MOVE,3,0);
                code.visitStmt2R(MOVE,4,0);
                code.visitStmt2R(MOVE,5,0);
                code.visitMethodStmt(INVOKE_CUSTOM_RANGE,new int[]{ 0,1,2,3,4,5},new CallSite("call_site_1", new MethodHandle(MethodHandle.INVOKE_STATIC,new Method("L038;","bsm",new String[]{ "Ljava/lang/invoke/MethodHandles$Lookup;","Ljava/lang/String;","Ljava/lang/invoke/MethodType;","I"},"Ljava/lang/invoke/CallSite;")), "runDynamic", new Proto(new String[]{ "I","I","I","I","I","I"},"V"),  Integer.valueOf(888)));
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_invoke_polymorphic(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Ldex038;","invoke_polymorphic",new String[]{ "Ljava/lang/invoke/MethodHandle;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitMethodStmt(INVOKE_POLYMORPHIC,new int[]{ 1,0},new Method("Ljava/lang/invoke/MethodHandle;","invoke",new String[]{ "[Ljava/lang/Object;"},"Ljava/lang/Object;"),new Proto(new String[]{ "I"},"V"));
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_invoke_polymorphic_range(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Ldex038;","invoke_polymorphic_range",new String[]{ "Ljava/lang/invoke/MethodHandle;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(8);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt2R(MOVE_OBJECT,0,7);
                code.visitStmt2R(MOVE,2,1);
                code.visitStmt2R(MOVE,3,1);
                code.visitStmt2R(MOVE,4,1);
                code.visitStmt2R(MOVE,5,1);
                code.visitStmt2R(MOVE,6,1);
                code.visitMethodStmt(INVOKE_POLYMORPHIC_RANGE,new int[]{ 0,1,2,3,4,5,6},new Method("Ljava/lang/invoke/MethodHandle;","invoke",new String[]{ "[Ljava/lang/Object;"},"Ljava/lang/Object;"),new Proto(new String[]{ "I","I","I","I","I","I"},"V"));
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_main(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Ldex038;","main",new String[]{ "[Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
